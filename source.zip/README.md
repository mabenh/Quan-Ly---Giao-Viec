# Việc Đến — Quản lý & Giám sát việc

Ứng dụng quản lý nhóm, giao việc và đánh giá hiệu suất (MVP).

Hiện thực theo tài liệu *“Hồ sơ yêu cầu sản phẩm và đặc tả kỹ thuật” v1.0 (12/11/2026)*.

| Thành phần | Công nghệ | Thư mục |
|---|---|---|
| Backend API `/api/v1` | NestJS + TypeScript (modular monolith), PostgreSQL | `backend/` |
| Ứng dụng di động | PWA React (mobile-first, cài lên màn hình chính Android/iOS) | `mobile-web/` |
| Background jobs | Scheduler trong tiến trình (`@nestjs/schedule`), chạy mỗi phút | `backend/src/modules/scheduler.service.ts` |

## Chạy nhanh

Cần Node 22 và PostgreSQL 16.

```bash
# 1. Backend
cd backend
npm install
export DATABASE_URL=postgresql://app:app@localhost:5432/teamapp   # các biến khác: xem .env.example
npm run seed                      # tạo schema + dữ liệu demo (XÓA dữ liệu cũ)
npm run dev                       # API: http://localhost:3000/api/v1

# 2. Giao diện (terminal khác)
cd mobile-web
npm install
npm run dev                       # http://localhost:5173 (proxy /api -> :3000)
```

Bản production: `cd mobile-web && npm run build`, rồi `cd backend && npm run build && npm start` — API sẽ phục vụ luôn PWA tại `http://localhost:3000`.
Hoặc dùng Docker: `docker compose up --build` (sau đó chạy seed nếu muốn dữ liệu demo).

**Tài khoản demo** — đăng nhập bằng số điện thoại, mật khẩu `Demo@123`:

| SĐT | Vai trò | SĐT | Vai trò |
|---|---|---|---|
| 0901000001 | Chủ doanh nghiệp | 0901000007 | Nhân viên 1 (Vũ Thị Giang) |
| 0901000002 | Quản trị | 0901000008 | Nhân viên 2 |
| 0901000003 | Quản lý nhóm Vận hành | 0901000009 | Nhân viên 3 |
| 0901000004 | Quản lý nhóm Kinh doanh | 0901000010 | Nhân viên 4 |
| 0901000005 | Trưởng bộ phận Kỹ thuật | 0901000011 | Reviewer độc lập |
| 0901000006 | Kỹ thuật viên | 0901000012 | Quản lý nhân sự |
| 0901000013 | Trưởng ca bảo vệ (bộ phận Bảo vệ) | 0901000014 | Thủ kho (bộ phận Kho vận) |
| 0900000000 | Quản trị nền tảng Việc Đến (xác nhận thanh toán gói) | | |

**Kiểm thử:** `cd backend && npm test` — 53 test (lịch làm việc, bộ máy tính điểm, và e2e theo tiêu chí nghiệm thu mục 16/16.1) chạy trên PostgreSQL thật (DB `teamapp_test`, đổi bằng `TEST_DATABASE_URL`).

## Triển khai lên server `viecden.nhavanmon.com.vn`

1. Tạo bản ghi DNS **A**: `viecden` → IP của VPS (trong trang quản lý DNS của `nhavanmon.com.vn`).
2. Đảm bảo repo GitHub có mã nguồn mới nhất (thư mục `backend`, `mobile-web`, `deploy` hoặc đúng **một** file `source.zip`).
3. SSH vào VPS (Ubuntu 22.04/24.04) và chạy:
   ```bash
   curl -fsSL https://raw.githubusercontent.com/mabenh/Quan-Ly---Giao-Viec/main/deploy/install.sh -o install.sh && sudo bash install.sh --seed
   ```
   (`--seed` nạp dữ liệu demo — bỏ đi khi dùng thật.) Script cài Node 22, PostgreSQL, tạo CSDL riêng `viecden`, build app, chạy dịch vụ `viecden` (systemd), gắn tên miền vào Nginx/Caddy đang có (hoặc cài Caddy) và cấp HTTPS. Chạy lại script để cập nhật phiên bản mới; mật khẩu CSDL và JWT được giữ nguyên.
4. Workflow GitHub build APK mặc định trỏ về `https://viecden.nhavanmon.com.vn/api/v1`. Nếu repo đang có biến `API_URL` cũ thì xóa hoặc sửa biến đó.

## Tính năng bổ sung v3

| # | Tính năng | Hiện thực |
|---|---|---|
| 1 | Điều chuyển, thăng chức, thôi việc: quyết định (PDF), hạn bàn giao; nhân viên thấy quyết định ở Trang chủ, lập bàn giao từng việc; **chỉ khi quản lý xác nhận bàn giao** quyết định mới hiệu lực và người đó mới nhận việc mới | `decisions.controller.ts` (`assertAssignable` chặn giao việc/khai việc nhanh cho người đang bàn giao), `DecisionDetail.tsx`, nút trong *Thành viên* |
| 2 | Tab **Giao việc**: danh sách thành viên theo nhóm, thu gọn được; số việc dưới avatar; bấm avatar → giao việc nhanh; **15 mẫu việc** (nhập kho, xuất kho, xử lý nguyên liệu, giao hàng, hàng tồn, bảo vệ ca trực, khiếu nại khách hàng, hàng lỗi, kiểm kê, đóng gói, bảo trì, vệ sinh 5S, mua vật tư, tiếp khách, báo cáo) có trường khai báo nhanh | `Assign.tsx`, `TaskForm.tsx`, `library.ts` |
| 3 | Giấy phép mẫu chuẩn: ra vào cổng, mang hàng ra cổng, sử dụng xe, sử dụng thiết bị (xe nâng, máy móc), vào khu vực hạn chế. Người giao việc lập kèm công việc; bộ phận phụ trách xem thông tin việc và cấp phép; **cấp tự động bằng đơn khai báo**, bộ phận hậu kiểm nhận–trả, ra–vào; sai quy trình → người giao chịu trách nhiệm (thông báo + báo cáo điểm nghẽn). Thẻ giấy phép có mã QR | `permits.controller.ts`, `PermitDetail.tsx`, `PermitForm.tsx`, cấu hình bộ phận trong *Cấu hình → Giấy phép* |
| 4 | Thủ tục công ty: thư viện 11 quy trình (bản **chuẩn hóa cho công ty** + bản **tham khảo** từ các phương pháp quản trị phổ biến SMART, RACI, PDCA, 5W2H, DRI); **tin vắn nhắc quy trình theo bộ phận** theo chu kỳ; **sơ đồ tổ chức** dạng cây; tình trạng nhân sự tuần nằm trong *Hệ thống nhân sự*; **sơ đồ đường đi quy trình giao việc**; hướng dẫn giao việc | `hr.controller.ts` (tin vắn mỗi ngày làm việc sau 8:30, tối đa 1 tin/người/ngày), `HrHub.tsx`, `OrgChart.tsx`, `Procedures.tsx`, `AssignFlow.tsx`, `AssignGuide.tsx` |
| 5 | Biểu tượng chuyên nghiệp (Lucide), font Be Vietnam Pro, thẻ chào, ô chức năng có biểu tượng màu, menu dạng danh sách | `icons.tsx`, `styles.css` |
| 6 | Script triển khai cho `viecden.nhavanmon.com.vn` | `deploy/install.sh`, workflow mặc định `API_URL` |

## Tính năng bổ sung v2 (Việc Đến)

| # | Tính năng | Hiện thực |
|---|---|---|
| 1 | Đăng nhập/đăng ký bằng SĐT, tên hiển thị là họ tên đầy đủ; thêm thành viên bằng SĐT; ảnh đại diện quét gương mặt; hồ sơ xin việc (thông tin cá nhân, kinh nghiệm, lịch sử làm việc) + phần **app tự cập nhật** (việc hoàn thành, đúng hạn, điểm nghiệm thu, điểm hiệu suất đã chốt, tăng ca, nghỉ phép…) | `auth.controller.ts`, `profile.controller.ts`, `FaceCapture.tsx`, `ProfilePage.tsx`, `PersonProfile.tsx`. SĐT chưa có tài khoản được tạo ở trạng thái “chờ kích hoạt”; người đó **Đăng ký bằng đúng SĐT** để vào thẳng công ty. Lịch sử tự động ở doanh nghiệp cũ chỉ hiện cho nhà tuyển dụng khi người lao động bật đồng ý chia sẻ |
| 2 | Chủ doanh nghiệp nâng cấp: gói Nhỏ/Vừa/Lớn (hạn mức 20/100/500 thành viên), tên công ty, email liên hệ; phân vai trò; Quản lý thêm thành viên bằng SĐT → **Quản lý nhân sự kiểm duyệt** | `subscriptions.controller.ts`, `plans.ts`, `company.controller.ts` (`POST /company/members`, `/members/:id/hr-review`), vai trò mới `hr` |
| 3 | Lịch tuần/tháng ở đầu Trang chủ, nút mở rộng/thu nhỏ, danh sách việc trong ngày; việc chưa xác nhận hoàn thành **tự chuyển sang ngày hôm sau** | `calendar.controller.ts`, `Calendar.tsx`, `tasks.plan_date` + scheduler |
| 4 | “Việc của tôi”/“Cần tôi xử lý” chỉ hiện mục có số liệu và tài khoản có quyền thao tác | `Home.tsx` |
| 5 | Logo và tên app **Việc Đến** | `mobile-web/public/*`, `mobile-web/resources/android/res` (sinh bằng `scripts/gen-icons.py`), `capacitor.config.json` |
| 6 | Giao việc qua gọi điện/tin nhắn: nút Gọi/SMS/Zalo trong app, quay lại app sau cuộc gọi → gợi ý khai việc điền sẵn; **link khai việc** gửi kèm tin nhắn mở mẫu đã điền sẵn; ghi âm; ai khai trước thì người kia chỉ cần xác nhận (chống khai trùng) → tạo nhiệm vụ chính thức | `quick-claims.controller.ts`, `QuickClaimForm.tsx`, `ContactReturnPrompt.tsx`, `AudioRecorder.tsx`, route `/q?c=…` |
| 7 | Đánh dấu & **ghim việc gấp** lên đầu danh sách; quản lý đổi trạng thái/gỡ ghim; nhân viên nhận thông báo | `POST /tasks/:id/pin` |
| 8 | Xin nghỉ đột xuất/theo giờ/theo ca/theo ngày, báo trước (cảnh báo nếu ít hơn quy định); quản lý duyệt → **xuất đơn PDF, gửi tự động sang Nhân sự** (thông báo trong app + email nếu cấu hình SMTP); tình trạng nhân viên trong tuần; bước chọn nhân viên khi giao việc hiển thị trạng thái (nghỉ phép, khối lượng, quá hạn) | `leaves.controller.ts`, `team/availability`, `TeamWeek.tsx`, `TaskForm.tsx` (2 bước) |

**Biến môi trường mới**

| Biến | Ý nghĩa |
|---|---|
| `PLAN_ACTIVATION` | `auto` (mặc định, dùng thử — kích hoạt gói ngay) hoặc `manual` (chờ quản trị nền tảng xác nhận thanh toán) |
| `PAYMENT_INSTRUCTIONS` | Nội dung hướng dẫn chuyển khoản hiện cho chủ doanh nghiệp |
| `PLAN_SMALL_LIMIT`, `PLAN_SMALL_PRICE`, … `PLAN_LARGE_PRICE` | Hạn mức & giá gói (giá mặc định chỉ là giá minh họa) |
| `SMTP_URL`, `SMTP_FROM` | Gửi email đơn nghỉ (kèm PDF) cho nhân sự. Không cấu hình thì chỉ gửi thông báo trong app |

**Giới hạn cần biết của v2**

- **Không có OTP SMS**: đăng ký chỉ cần SĐT + mật khẩu, nên ai biết một SĐT “chờ kích hoạt” có thể đăng ký trước chủ số. Cần tích hợp nhà cung cấp OTP (ví dụ eSMS, Stringee, Firebase Phone Auth) trước khi dùng thật.
- **Thanh toán gói chưa tích hợp cổng thanh toán**: chế độ `auto` kích hoạt ngay; chế độ `manual` cần quản trị nền tảng bấm xác nhận sau khi nhận chuyển khoản.
- **Ghi âm cuộc gọi & lịch sử cuộc gọi**: Android/iOS không cho ứng dụng thường tự ghi âm cuộc gọi hay đọc nhật ký cuộc gọi. App thay bằng: gọi/nhắn từ trong app rồi gợi ý khai việc khi quay lại, link khai việc trong tin nhắn, ghi âm bằng micro (loa ngoài/trao đổi trực tiếp) hoặc đính kèm file ghi âm có sẵn của máy.
- **Quét gương mặt**: chụp trực tiếp từ camera trước với khung gương mặt; nếu trình duyệt hỗ trợ FaceDetector thì kiểm tra có gương mặt. Đây **không phải** xác thực sinh trắc học/chống giả mạo.
- Thời gian hiển thị theo múi giờ của điện thoại; lịch & SLA tính theo múi giờ công ty.

## Đối chiếu đặc tả → hiện thực

| Mục | Nội dung | Hiện thực |
|---|---|---|
| 2 | 6 vai trò, phân quyền công ty ≠ vai trò trong nhóm | `company_members.role` + `groups.manager_member_id`; kiểm tra quyền server-side mọi endpoint; cách ly `company_id` |
| 3.1 | Điều hướng Trang chủ / Công việc / Nhóm / Đánh giá / Cá nhân, chuông thông báo | `mobile-web/src/App.tsx` |
| 4 | Nhiệm vụ: đầu vào/đầu ra, độ khó, mức yêu cầu, thời lượng, deadline, 6 trạng thái, quá hạn là cờ tính toán | `tasks.controller.ts`; tiêu chí lưu **phiên bản** (`task_criteria.version`); đổi phạm vi/deadline sau khi bắt đầu **bắt buộc lý do** + audit |
| 4.3 | Khung thời lượng; deadline theo giờ làm việc | Gợi ý deadline `GET /company/calendar/suggest-due` theo lịch công ty |
| 5 | Việc đột xuất (4 loại), yêu cầu chung/đa dạng, yêu cầu con có phiên bản, bộ tiêu chí 35/20/20/15/10 riêng | `unexpected_tasks`, `task_subitems`; điểm tách riêng trong báo cáo |
| 6 | Tăng ca: 5 loại, ghi nhận cả khi chưa duyệt, không xóa, không tính lương, không cộng điểm | `overtime.controller.ts` |
| 7 | Tự khai báo; xác nhận / một phần / từ chối / yêu cầu bổ sung; tranh chấp; **khiếu nại từ lần từ chối thứ 4**; khiếu nại sớm; cấp giải quyết cao hơn người bị khiếu nại; quá SLA → chuyển cấp, không coi im lặng là đồng ý | `work-records.controller.ts`; lịch sử quyết định **bất biến** (trigger DB) |
| 8 | Báo cáo trở ngại: 6 nhóm, 4 mức, luồng 6 bước, 10 trạng thái, SLA 8.4, chuyển cấp, kênh độc lập, cảnh báo an toàn | `workplace-reports.controller.ts` + scheduler |
| 9 | Điểm nhiệm vụ 40/30/20/10; W = hệ số phức tạp × yêu cầu; P = ΣC/ΣW; E = 0.25V+0.20T+0.30Q+0.15D+0.10R | `performance.service.ts` (`scoreMembers` là hàm thuần, có unit test) |
| 10 | Báo cáo tháng/quý/năm theo cá nhân/nhóm/công ty, điểm nghẽn, so sánh kỳ trước, **snapshot** giữ nguyên khi công thức đổi, xuất PDF/Excel | `performance.controller.ts` |
| 11 | Thông báo có liên kết đúng bản ghi, chống gửi trùng (dedupe), lưu trạng thái gửi | `common/notify.ts`, bảng `notifications` |
| 12 | Mô hình dữ liệu (UUID, `company_id`, UTC, soft delete nhóm, bản ghi bất biến) | `backend/src/db/schema.sql` |
| 13 | REST API `/api/v1`, mã lỗi nghiệp vụ ổn định, phân trang/lọc, giới hạn upload, idempotency | Header `Idempotency-Key` cho mọi POST; lỗi dạng `{error:{code,message}}` |
| 14.2 | RBAC, audit, khóa tài khoản & thu hồi phiên, quyền xem tệp theo đối tượng | `audit_logs`, refresh token xoay vòng, khóa sau 10 lần sai mật khẩu |
| 16 / 16.1 | Tiêu chí nghiệm thu & tình huống biên | `backend/test/e2e.test.ts` |

### Giá trị mặc định đã áp dụng cho các quyết định mục 18 (đều cấu hình được trong *Cá nhân → Cấu hình*)

D01 nhân viên được tham gia nhiều nhóm · D02 xem toàn bộ nhiệm vụ nhóm mình · D03 giao chéo nhóm chỉ khi được cấp quyền (theo từng người) · D04 khiếu nại từ lần từ chối thứ 4 · D05 hạn xác nhận 1 ngày làm việc (480 phút) · D06 lịch T2–T6, 08:00–17:00, nghỉ trưa 12–13, ngày lễ cấu hình · D07 tuyến: cấp trên trực tiếp → … → Admin → Owner → reviewer độc lập · D08 SLA theo bảng 8.4 · D09 trọng số đề xuất, mỗi lần đổi tạo phiên bản mới · D10 điểm chỉ tham khảo · D11 không tính lương tăng ca · D12 PDF + Excel.

### Diễn giải công thức (cần chủ sản phẩm xác nhận khi chạy pilot)

Tài liệu nêu thành phần nhưng chưa định nghĩa chi tiết cách đo; bản MVP dùng cách sau:

- **Ghi nhận khi có cộng tác viên:** người chịu trách nhiệm nhận 60% trọng số nhiệm vụ, cộng tác viên chia đều 40% (tổng không vượt 100% — không nhân đôi điểm).
- **V** = khối lượng có trọng số, chuẩn hóa về 0–100 so với người cao nhất **cùng vai trò** trong công ty trong kỳ.
- **T** = tỷ lệ đúng hạn theo lần bàn giao đầu tiên; việc trễ có trở ngại **đã được quản lý xác nhận** thì không tính.
- **Q** = 0.7 × điểm nghiệm thu bình quân có trọng số + 0.3 × tỷ lệ đạt lần đầu.
- **D** = hệ số W bình quân, quy đổi tuyến tính về 0–100.
- **R** = điểm “quá trình/cập nhật/phối hợp” do người nghiệm thu chấm.
- Thành phần thiếu dữ liệu được bỏ qua và chia lại trọng số; báo cáo gắn nhãn “chưa đủ dữ liệu”.
- Bản ghi tự khai báo được chấp nhận được thống kê (số lượng, giờ) nhưng **chưa** cộng vào điểm.

## Khác biệt so với đề xuất kỹ thuật (mục 14) — cần lưu ý

- **Mobile: PWA React thay vì Flutter.** Môi trường xây dựng không có Flutter/Android SDK để build và kiểm thử. PWA chạy trên trình duyệt di động và cài được lên màn hình chính; toàn bộ nghiệp vụ nằm ở API nên app Flutter có thể làm sau trên cùng API mà không đổi backend.
- **Push notification (FCM):** đã có bản ghi thông báo in-app, chống trùng và cột `push_status`; **chưa** gửi FCM thật (cần khóa Firebase + worker gửi).
- **Lưu tệp:** driver lưu đĩa cục bộ (`UPLOAD_DIR`) sau một lớp trừu tượng; chưa có driver S3.
- **Background jobs:** dùng scheduler trong tiến trình thay vì BullMQ/Redis. An toàn khi chạy nhiều instance (khóa `SKIP LOCKED`, khóa duy nhất cho chuyển cấp, dedupe thông báo); nếu tách worker, đặt `DISABLE_SCHEDULER=true` trên các instance API.
- **Đăng nhập:** email + mật khẩu (JWT 30 phút + refresh token xoay vòng). Admin mời thành viên và nhận mật khẩu tạm thời; chưa gửi email mời.
- Docker/Docker Compose đã viết nhưng **chưa build thử** trong môi trường này; cách chạy bằng Node + PostgreSQL ở trên đã được kiểm chứng.

## Cấu trúc mã

```
backend/src
  common/        auth guard, RBAC/tuyến cấp trên, lịch làm việc, audit, thông báo, idempotency, lỗi
  db/            schema.sql, migrate, seed (seed chạy qua chính REST API)
  modules/       auth, company (cấu hình), groups, tasks, overtime, work-records, workplace-reports,
                 escalation(s), performance (tính điểm + báo cáo + xuất), notifications, files, dashboard, scheduler
mobile-web/src
  api.ts         gọi API, tự làm mới token, Idempotency-Key, retry khi mất mạng
  pages/         Trang chủ theo vai trò, Công việc (nhiệm vụ/tự khai báo/tăng ca/trở ngại), Nhóm,
                 Đánh giá & báo cáo, Cá nhân, Bảng kỹ thuật, Chuyển cấp, Quản trị thành viên & cấu hình
```

## Build trên GitHub Actions

File workflow: `.github/workflows/build.yml`. Đẩy mã lên GitHub (nhánh `main`/`master`) hoặc vào tab **Actions → Build → Run workflow**. Có 3 job:

1. **test** — chạy 30 test backend trên PostgreSQL 16 (service container).
2. **server** — build backend + PWA, tải về ở artifact `server-bundle` (xem `START.txt` bên trong).
3. **android** — đóng gói PWA thành app Android bằng Capacitor, ra file APK debug ở artifact `android-apk`.

App Android cần biết địa chỉ API: nhập `api_url` khi chạy tay, hoặc tạo biến repo `API_URL` (Settings → Secrets and variables → Actions → Variables), ví dụ `https://api.congty.vn/api/v1`. Mặc định `http://10.0.2.2:3000/api/v1` (chỉ dùng cho máy ảo Android trỏ về máy chạy server).

Hạn chế của bản APK: là bản debug (chưa ký phát hành); nút xuất PDF/Excel trong WebView Android có thể không tải được tệp — dùng bản web để xuất báo cáo.
