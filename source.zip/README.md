# Ứng dụng quản lý nhóm, giao việc và đánh giá hiệu suất (MVP)

Hiện thực theo tài liệu *“Hồ sơ yêu cầu sản phẩm và đặc tả kỹ thuật” v1.0 (12/11/2026)*.

| Thành phần | Công nghệ | Thư mục |
|---|---|---|
| Backend API `/api/v1` | NestJS + TypeScript (modular monolith), PostgreSQL | `backend/` |
| Ứng dụng di động | PWA React (mobile-first, cài lên màn hình chính Android/iOS) | `mobile-web/` |
| Background jobs | Scheduler trong tiến trình (`@nestjs/schedule`), chạy mỗi phút | `backend/src/modules/scheduler.service.ts` |

## Chạy nhanh

Cần Node 22 và PostgreSQL 16.

```bash
# 1. Backend
cd backend
npm install
export DATABASE_URL=postgresql://app:app@localhost:5432/teamapp   # các biến khác: xem .env.example
npm run seed                      # tạo schema + dữ liệu demo (XÓA dữ liệu cũ)
npm run dev                       # API: http://localhost:3000/api/v1

# 2. Giao diện (terminal khác)
cd mobile-web
npm install
npm run dev                       # http://localhost:5173 (proxy /api -> :3000)
```

Bản production: `cd mobile-web && npm run build`, rồi `cd backend && npm run build && npm start` — API sẽ phục vụ luôn PWA tại `http://localhost:3000`.
Hoặc dùng Docker: `docker compose up --build` (sau đó chạy seed nếu muốn dữ liệu demo).

**Tài khoản demo** (mật khẩu `Demo@123`): `owner@demo.vn`, `admin@demo.vn`, `quanly1@demo.vn`, `quanly2@demo.vn`, `truongkt@demo.vn` (trưởng Kỹ thuật), `kythuat@demo.vn`, `nv1..nv4@demo.vn`, `reviewer@demo.vn` (reviewer độc lập).

**Kiểm thử:** `cd backend && npm test` — 30 test (lịch làm việc, bộ máy tính điểm, và e2e theo tiêu chí nghiệm thu mục 16/16.1) chạy trên PostgreSQL thật (DB `teamapp_test`, đổi bằng `TEST_DATABASE_URL`).

## Đối chiếu đặc tả → hiện thực

| Mục | Nội dung | Hiện thực |
|---|---|---|
| 2 | 6 vai trò, phân quyền công ty ≠ vai trò trong nhóm | `company_members.role` + `groups.manager_member_id`; kiểm tra quyền server-side mọi endpoint; cách ly `company_id` |
| 3.1 | Điều hướng Trang chủ / Công việc / Nhóm / Đánh giá / Cá nhân, chuông thông báo | `mobile-web/src/App.tsx` |
| 4 | Nhiệm vụ: đầu vào/đầu ra, độ khó, mức yêu cầu, thời lượng, deadline, 6 trạng thái, quá hạn là cờ tính toán | `tasks.controller.ts`; tiêu chí lưu **phiên bản** (`task_criteria.version`); đổi phạm vi/deadline sau khi bắt đầu **bắt buộc lý do** + audit |
| 4.3 | Khung thời lượng; deadline theo giờ làm việc | Gợi ý deadline `GET /company/calendar/suggest-due` theo lịch công ty |
| 5 | Việc đột xuất (4 loại), yêu cầu chung/đa dạng, yêu cầu con có phiên bản, bộ tiêu chí 35/20/20/15/10 riêng | `unexpected_tasks`, `task_subitems`; điểm tách riêng trong báo cáo |
| 6 | Tăng ca: 5 loại, ghi nhận cả khi chưa duyệt, không xóa, không tính lương, không cộng điểm | `overtime.controller.ts` |
| 7 | Tự khai báo; xác nhận / một phần / từ chối / yêu cầu bổ sung; tranh chấp; **khiếu nại từ lần từ chối thứ 4**; khiếu nại sớm; cấp giải quyết cao hơn người bị khiếu nại; quá SLA → chuyển cấp, không coi im lặng là đồng ý | `work-records.controller.ts`; lịch sử quyết định **bất biến** (trigger DB) |
| 8 | Báo cáo trở ngại: 6 nhóm, 4 mức, luồng 6 bước, 10 trạng thái, SLA 8.4, chuyển cấp, kênh độc lập, cảnh báo an toàn | `workplace-reports.controller.ts` + scheduler |
| 9 | Điểm nhiệm vụ 40/30/20/10; W = hệ số phức tạp × yêu cầu; P = ΣC/ΣW; E = 0.25V+0.20T+0.30Q+0.15D+0.10R | `performance.service.ts` (`scoreMembers` là hàm thuần, có unit test) |
| 10 | Báo cáo tháng/quý/năm theo cá nhân/nhóm/công ty, điểm nghẽn, so sánh kỳ trước, **snapshot** giữ nguyên khi công thức đổi, xuất PDF/Excel | `performance.controller.ts` |
| 11 | Thông báo có liên kết đúng bản ghi, chống gửi trùng (dedupe), lưu trạng thái gửi | `common/notify.ts`, bảng `notifications` |
| 12 | Mô hình dữ liệu (UUID, `company_id`, UTC, soft delete nhóm, bản ghi bất biến) | `backend/src/db/schema.sql` |
| 13 | REST API `/api/v1`, mã lỗi nghiệp vụ ổn định, phân trang/lọc, giới hạn upload, idempotency | Header `Idempotency-Key` cho mọi POST; lỗi dạng `{error:{code,message}}` |
| 14.2 | RBAC, audit, khóa tài khoản & thu hồi phiên, quyền xem tệp theo đối tượng | `audit_logs`, refresh token xoay vòng, khóa sau 10 lần sai mật khẩu |
| 16 / 16.1 | Tiêu chí nghiệm thu & tình huống biên | `backend/test/e2e.test.ts` |

### Giá trị mặc định đã áp dụng cho các quyết định mục 18 (đều cấu hình được trong *Cá nhân → Cấu hình*)

D01 nhân viên được tham gia nhiều nhóm · D02 xem toàn bộ nhiệm vụ nhóm mình · D03 giao chéo nhóm chỉ khi được cấp quyền (theo từng người) · D04 khiếu nại từ lần từ chối thứ 4 · D05 hạn xác nhận 1 ngày làm việc (480 phút) · D06 lịch T2–T6, 08:00–17:00, nghỉ trưa 12–13, ngày lễ cấu hình · D07 tuyến: cấp trên trực tiếp → … → Admin → Owner → reviewer độc lập · D08 SLA theo bảng 8.4 · D09 trọng số đề xuất, mỗi lần đổi tạo phiên bản mới · D10 điểm chỉ tham khảo · D11 không tính lương tăng ca · D12 PDF + Excel.

### Diễn giải công thức (cần chủ sản phẩm xác nhận khi chạy pilot)

Tài liệu nêu thành phần nhưng chưa định nghĩa chi tiết cách đo; bản MVP dùng cách sau:

- **Ghi nhận khi có cộng tác viên:** người chịu trách nhiệm nhận 60% trọng số nhiệm vụ, cộng tác viên chia đều 40% (tổng không vượt 100% — không nhân đôi điểm).
- **V** = khối lượng có trọng số, chuẩn hóa về 0–100 so với người cao nhất **cùng vai trò** trong công ty trong kỳ.
- **T** = tỷ lệ đúng hạn theo lần bàn giao đầu tiên; việc trễ có trở ngại **đã được quản lý xác nhận** thì không tính.
- **Q** = 0.7 × điểm nghiệm thu bình quân có trọng số + 0.3 × tỷ lệ đạt lần đầu.
- **D** = hệ số W bình quân, quy đổi tuyến tính về 0–100.
- **R** = điểm “quá trình/cập nhật/phối hợp” do người nghiệm thu chấm.
- Thành phần thiếu dữ liệu được bỏ qua và chia lại trọng số; báo cáo gắn nhãn “chưa đủ dữ liệu”.
- Bản ghi tự khai báo được chấp nhận được thống kê (số lượng, giờ) nhưng **chưa** cộng vào điểm.

## Khác biệt so với đề xuất kỹ thuật (mục 14) — cần lưu ý

- **Mobile: PWA React thay vì Flutter.** Môi trường xây dựng không có Flutter/Android SDK để build và kiểm thử. PWA chạy trên trình duyệt di động và cài được lên màn hình chính; toàn bộ nghiệp vụ nằm ở API nên app Flutter có thể làm sau trên cùng API mà không đổi backend.
- **Push notification (FCM):** đã có bản ghi thông báo in-app, chống trùng và cột `push_status`; **chưa** gửi FCM thật (cần khóa Firebase + worker gửi).
- **Lưu tệp:** driver lưu đĩa cục bộ (`UPLOAD_DIR`) sau một lớp trừu tượng; chưa có driver S3.
- **Background jobs:** dùng scheduler trong tiến trình thay vì BullMQ/Redis. An toàn khi chạy nhiều instance (khóa `SKIP LOCKED`, khóa duy nhất cho chuyển cấp, dedupe thông báo); nếu tách worker, đặt `DISABLE_SCHEDULER=true` trên các instance API.
- **Đăng nhập:** email + mật khẩu (JWT 30 phút + refresh token xoay vòng). Admin mời thành viên và nhận mật khẩu tạm thời; chưa gửi email mời.
- Docker/Docker Compose đã viết nhưng **chưa build thử** trong môi trường này; cách chạy bằng Node + PostgreSQL ở trên đã được kiểm chứng.

## Cấu trúc mã

```
backend/src
  common/        auth guard, RBAC/tuyến cấp trên, lịch làm việc, audit, thông báo, idempotency, lỗi
  db/            schema.sql, migrate, seed (seed chạy qua chính REST API)
  modules/       auth, company (cấu hình), groups, tasks, overtime, work-records, workplace-reports,
                 escalation(s), performance (tính điểm + báo cáo + xuất), notifications, files, dashboard, scheduler
mobile-web/src
  api.ts         gọi API, tự làm mới token, Idempotency-Key, retry khi mất mạng
  pages/         Trang chủ theo vai trò, Công việc (nhiệm vụ/tự khai báo/tăng ca/trở ngại), Nhóm,
                 Đánh giá & báo cáo, Cá nhân, Bảng kỹ thuật, Chuyển cấp, Quản trị thành viên & cấu hình
```

## Build trên GitHub Actions

File workflow: `.github/workflows/build.yml`. Đẩy mã lên GitHub (nhánh `main`/`master`) hoặc vào tab **Actions → Build → Run workflow**. Có 3 job:

1. **test** — chạy 30 test backend trên PostgreSQL 16 (service container).
2. **server** — build backend + PWA, tải về ở artifact `server-bundle` (xem `START.txt` bên trong).
3. **android** — đóng gói PWA thành app Android bằng Capacitor, ra file APK debug ở artifact `android-apk`.

App Android cần biết địa chỉ API: nhập `api_url` khi chạy tay, hoặc tạo biến repo `API_URL` (Settings → Secrets and variables → Actions → Variables), ví dụ `https://api.congty.vn/api/v1`. Mặc định `http://10.0.2.2:3000/api/v1` (chỉ dùng cho máy ảo Android trỏ về máy chạy server).

Hạn chế của bản APK: là bản debug (chưa ký phát hành); nút xuất PDF/Excel trong WebView Android có thể không tải được tệp — dùng bản web để xuất báo cáo.
