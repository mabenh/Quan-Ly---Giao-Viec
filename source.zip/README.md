# Việc Đến — Quản lý & Giám sát việc

Ứng dụng quản lý nhóm, giao việc và đánh giá hiệu suất (MVP).

Hiện thực theo tài liệu *“Hồ sơ yêu cầu sản phẩm và đặc tả kỹ thuật” v1.0 (12/11/2026)*.

| Thành phần | Công nghệ | Thư mục |
|---|---|---|
| Backend API `/api/v1` | NestJS + TypeScript (modular monolith), PostgreSQL | `backend/` |
| Ứng dụng di động | PWA React (mobile-first, cài lên màn hình chính Android/iOS) | `mobile-web/` |
| Background jobs | Scheduler trong tiến trình (`@nestjs/schedule`), chạy mỗi phút | `backend/src/modules/scheduler.service.ts` |

## Chạy nhanh

Cần Node 22 và PostgreSQL 16.

```bash
# 1. Backend
cd backend
npm install
export DATABASE_URL=postgresql://app:app@localhost:5432/teamapp   # các biến khác: xem .env.example
npm run seed                      # tạo schema + dữ liệu demo (XÓA dữ liệu cũ)
npm run dev                       # API: http://localhost:3000/api/v1

# 2. Giao diện (terminal khác)
cd mobile-web
npm install
npm run dev                       # http://localhost:5173 (proxy /api -> :3000)
```

Bản production: `cd mobile-web && npm run build`, rồi `cd backend && npm run build && npm start` — API sẽ phục vụ luôn PWA tại `http://localhost:3000`.
Hoặc dùng Docker: `docker compose up --build` (sau đó chạy seed nếu muốn dữ liệu demo).

**Tài khoản demo** — đăng nhập bằng số điện thoại, mật khẩu `Demo@123`:

| SĐT | Vai trò | SĐT | Vai trò |
|---|---|---|---|
| 0901000001 | Chủ doanh nghiệp | 0901000007 | Nhân viên 1 (Vũ Thị Giang) |
| 0901000002 | Quản trị | 0901000008 | Nhân viên 2 |
| 0901000003 | Quản lý nhóm Vận hành | 0901000009 | Nhân viên 3 |
| 0901000004 | Quản lý nhóm Kinh doanh | 0901000010 | Nhân viên 4 |
| 0901000005 | Trưởng bộ phận Kỹ thuật | 0901000011 | Reviewer độc lập |
| 0901000006 | Kỹ thuật viên | 0901000012 | Quản lý nhân sự |
| 0901000013 | Trưởng ca bảo vệ (bộ phận Bảo vệ) | 0901000014 | Thủ kho (bộ phận Kho vận) |
| 0900000000 | Quản trị nền tảng Việc Đến (xác nhận thanh toán gói) | | |

**Kiểm thử:** `cd backend && npm test` — 53 test (lịch làm việc, bộ máy tính điểm, và e2e theo tiêu chí nghiệm thu mục 16/16.1) chạy trên PostgreSQL thật (DB `teamapp_test`, đổi bằng `TEST_DATABASE_URL`).

## Triển khai lên server `viecden.nhavanmon.com.vn`

1. Tạo bản ghi DNS **A**: `viecden` → IP của VPS (trong trang quản lý DNS của `nhavanmon.com.vn`).
2. Đảm bảo repo GitHub có mã nguồn mới nhất (thư mục `backend`, `mobile-web`, `deploy` hoặc đúng **một** file `source.zip`).
3. SSH vào VPS (Ubuntu 22.04/24.04) và chạy:
   ```bash
   curl -fsSL https://raw.githubusercontent.com/mabenh/Quan-Ly---Giao-Viec/main/deploy/install.sh -o install.sh && sudo bash install.sh --seed
   ```
   (`--seed` nạp dữ liệu demo — bỏ đi khi dùng thật.) Script cài Node 22, PostgreSQL, tạo CSDL riêng `viecden`, build app, chạy dịch vụ `viecden` (systemd), gắn tên miền vào Nginx/Caddy đang có (hoặc cài Caddy) và cấp HTTPS. Chạy lại script để cập nhật phiên bản mới; mật khẩu CSDL và JWT được giữ nguyên.
4. Workflow GitHub build APK mặc định trỏ về `https://viecden.nhavanmon.com.vn/api/v1`. Nếu repo đang có biến `API_URL` cũ thì xóa hoặc sửa biến đó.

## Phiên bản v7

1. **Giờ làm/tăng ca ngoại lệ** (`/overtime/new`): khi máy chấm công không hoạt động hoặc làm ngoài công ty/xưởng; người ghi nhận là người yêu cầu và phải cao hơn người được ghi nhận (cấp trên, trưởng nhóm/quản lý nhóm, hoặc vai trò cao hơn); có hiệu lực ngay, lưu vết.
2. **Chia giai đoạn con**: không chọn được giai đoạn đã hoàn thành (kiểm tra cả ở server).
3. **Giao việc**: chọn loại ở đầu form — Việc đơn lẻ / Đơn hàng mới (tự tạo hoặc nhập mã đơn, không trùng) / Thuộc đơn hàng có sẵn (tạo nhiệm vụ con, chọn phân đoạn) / Nhiệm vụ thường trực.
4. **Mẫu có số phiếu/mã đơn**: chọn "Không có số phiếu" hoặc nhập số.
5. **Tự động bắt đầu**: Thủ công / Khi nhận bàn giao của công đoạn trước (nhiệm vụ tự chuyển "đang thực hiện"; nếu người làm đang trong phiên của công đoạn trước thì phiên chuyển theo) / Theo lịch đặt trước (bộ lập lịch bắt đầu đúng giờ; chưa đủ điều kiện thì báo trưởng nhóm).
6. **Trang Công việc**: bỏ tab Khai nhanh, Tự khai báo, Tăng ca; nút dưới tab đổi thành "Tự khai báo" (Giao việc vẫn ở thanh điều hướng).
7. **Mã hiển thị trước tên**: `NV-00023 - Kiểm kê kho`; công đoạn đơn hàng `DH-00001_NV-00043 - Nhập hàng`; phần việc con `NV-00043.1 - …`.
8. **Nhiệm vụ**: bàn giao kết quả/gửi bàn giao kèm tài liệu và đường link; chỉ người được giao mới ghi nhận sản lượng và gửi bàn giao; người giao việc chỉ điều chỉnh, chỉnh ưu tiên (gồm ghim việc gấp), hủy; bỏ nút ghi tăng ca — tăng ca nằm trong ghi nhận sản lượng (chỉ trưởng nhóm), ghi thời gian làm việc và tăng ca của từng người; "Chia phần việc con" nằm dưới nhiệm vụ; "Điều kiện tiếp nhận" thay bằng **phương thức bàn giao** (nghiệm thu trực tiếp, xác nhận khách hàng, kiểm tra tài liệu, xác nhận của trưởng nhóm (tên), khác).
9. **Bỏ tăng ca chờ xác nhận**: tăng ca chỉ là tham số hiệu suất (thời gian thực hiện = làm việc + tăng ca).
10. **Bắt đầu phiên**: chọn Nhiệm vụ được giao (số hiệu) hoặc Nhiệm vụ thường trực của nhóm (kèm công đoạn). Nhiệm vụ thường trực không có hạn, không tính vào danh sách việc/điểm/quá hạn.

Kiểm thử: `test/v7.test.ts`. Tổng 91 test.

## Phiên bản v6 — Giám sát, điều phối & báo cáo hiệu suất (Đặc tả nghiệp vụ v2.0)

Giao diện cũ giữ nguyên làm trục; phân hệ mới gắn vào **Trang chủ** (thẻ Phiên làm việc + lối vào theo vai trò), **Chi tiết nhiệm vụ** (phần Vận hành), **Cá nhân → Vận hành & hiệu suất** và **Cấu hình**.

| Mục đặc tả | Hiện thực |
|---|---|
| 4. Phiên làm việc | Bắt đầu / Hoãn / Chuyển việc / Tiếp tục / Kết thúc (`/sessions/*`); **1 phiên đang chạy/người** (ràng buộc DB + kiểm tra); chuyển việc đóng & lưu phiên cũ trước; thời gian tách: thực hiện, chuẩn bị, chuyển đổi, chờ việc, hoãn khách quan/chủ quan, nghỉ bổ sung, bàn giao, chưa xác định; tăng ca riêng. Hoãn khách quan do trưởng nhóm xác nhận, không tính vào mẫu số hiệu quả. Phiên quên kết thúc tự đóng, phần sau ghi "chưa xác định" |
| 4.4 Vị trí | Danh mục vị trí (Cấu hình → Vị trí), không GPS; chỉ bắt buộc khi nhiệm vụ đặt `location_required`; tự khai công việc bắt buộc chọn vị trí / Ngoài công ty / Không xác định |
| 5. Sản lượng & chất lượng | Trưởng nhóm (mới: *Trưởng nhóm* của nhóm, mặc định = quản lý nhóm) ghi nhận theo phiên/công đoạn hoặc bàn giao một lần: kế hoạch, thực tế, đạt chuẩn, lỗi, làm lại, tồn, người tham gia; định mức có phiên bản; **không sửa đè** (trigger DB) — điều chỉnh tạo phiên bản mới có lý do. Hiệu suất = thời gian chuẩn quy đổi ÷ thời gian thực hiện; chất lượng tính riêng |
| 6. Quỹ nghỉ tích lũy | Sổ quỹ nghỉ (tích lũy/sử dụng/điều chỉnh); mặc định **tắt** — bật & đặt thông số tại Cấu hình → Thời gian & quỹ nghỉ; chỉ dùng khi đang hoãn khách quan/chờ việc và được trưởng nhóm cho phép; trừ số phút thực tế; tách khỏi nghỉ theo luật và tăng ca, không quy đổi |
| 7. Chuỗi đơn hàng liên bộ phận | Việc gốc đánh dấu đơn hàng → mã `DH-xxxxx`; công đoạn con mã riêng, nhánh song song; **bàn giao liên bộ phận** tự tạo khi công đoạn sau mở (kế thừa kết quả, sản lượng), bên nhận tiếp nhận/từ chối, bên gửi bổ sung; chưa tiếp nhận thì chưa bắt đầu phiên (trừ khi được cho phép bắt đầu sớm có lý do); deadline tính ngược theo lịch làm việc (nhánh dài nhất + dự phòng); cảnh báo Bình thường/Sắp hạn/Nguy cơ trễ/Quá hạn tổng hợp lên chuỗi, chỉ ra công đoạn gây tắc; ưu tiên chỉnh tay có lý do; giá bán/lợi nhuận chỉ Ban quản trị & người tạo chuỗi |
| 8–9. Dashboard theo vai trò | `/board` Ban quản trị (tổng quan, nhóm, đơn hàng, nhân lực, chất lượng, rủi ro, so sánh kỳ trước); `/scope` Quản lý (phạm vi nhóm được giao, thành viên có căn cứ); `/team-live` Trưởng nhóm (ai đang làm gì, sản lượng hôm nay, bàn giao, hoãn/nghỉ, duyệt nghỉ, xác nhận hoãn); `/my-time` Nhân viên (thời gian & nghỉ, kết quả, lịch sử, phản hồi dữ liệu sai). Drill-down mở trang chi tiết vẫn kiểm tra quyền từng đối tượng; công thức hiển thị kèm; không xếp hạng công khai |
| 10–11. Phân quyền & audit | Phạm vi tính ở server (`common/scope.ts`); quản lý nhóm A không xem chi tiết nhóm B; mọi thay đổi sản lượng/định mức/ưu tiên/deadline/xác nhận có lịch sử trước–sau, người, lý do; xem dashboard quản lý ghi nhật ký truy cập |

Kiểm thử: `test/v6.test.ts` (10 nhóm tình huống theo mục 15). Tổng: 85 test.

**Điểm cần Product Owner chốt (mục 16)** — app đã có cấu hình nhưng không tự biến thành chính sách: D-01/D-02 quỹ nghỉ (mặc định tắt), D-03 một trưởng nhóm xác nhận (chưa có người đối soát thứ hai), D-04 định mức theo công đoạn, D-05 thời lượng chuẩn/dự phòng mỗi công đoạn, D-06 trường nhạy cảm (hiện: giá trị đơn & lợi nhuận), D-07 quản lý xem thành viên các nhóm mình quản lý + cấp dưới, D-08 Ban quản trị xem cá nhân (hiện: tổng hợp, truy xuất có nhật ký), D-09 không xếp hạng công khai, D-10 danh mục vị trí, D-11 phụ cấp trưởng nhóm (không gắn điểm), D-12 vai trò kiêm nhiệm (mỗi thành viên một vai trò + vai trò trưởng nhóm theo nhóm). Tích hợp PLC/cảm biến/cân/mã quét: trường `source` đã sẵn, chưa có kết nối thiết bị.

## Bảo mật, quyền riêng tư & chống lạm dụng (v5 — SEC-01, UX-ABUSE-01)

**Đã hiện thực trong app**

| Yêu cầu | Hiện thực |
|---|---|
| Cách ly doanh nghiệp, kiểm tra quyền từng đối tượng (SEC-T01) | Mọi truy vấn lấy `company_id` từ token đã xác thực; tệp/ảnh/hồ sơ kiểm tra quyền khi tải; từ chối trả 404 (không lộ sự tồn tại) và ghi nhật ký `denied` |
| Trường dữ liệu theo vai trò (SEC-T02) | Danh sách thành viên/nhóm/sơ đồ tổ chức che SĐT, email theo mức hiển thị chủ thể chọn (`only_me` / `related` / `company`); chỉ Nhân sự tìm theo SĐT/email; bỏ ghi chú HR khỏi API của người khác |
| Tối thiểu hóa dữ liệu | Bỏ số CCCD, giới tính khỏi hồ sơ; ngày sinh/địa chỉ/email liên hệ không bắt buộc, mặc định "chỉ mình tôi" |
| Phạm vi quản lý (SEC-T03) | Quản lý chỉ xem hồ sơ người trong nhóm mình quản lý / cấp dưới / người mình đề nghị thêm; đánh giá hiệu suất theo phạm vi được giao; hồ sơ có yêu cầu hạn chế chỉ Nhân sự xem |
| Xuất dữ liệu có kiểm soát (SEC-T04) | Xuất báo cáo của người khác phải nêu lý do (hộp cảnh báo trước hành động), giới hạn 20 lần/giờ, ghi nhật ký, đóng dấu người xuất trên PDF/Excel |
| Trung tâm quyền riêng tư (SEC-T05/06/07) | *Cá nhân → Quyền riêng tư*: mức hiển thị theo trường, đồng ý theo từng mục đích (chụp ảnh gương mặt, ghi âm cuộc gọi, chia sẻ CV), danh mục dữ liệu + mục đích + thời hạn lưu + bên nhận, tải dữ liệu của tôi (nhập lại mật khẩu, tệp tự hết hạn), yêu cầu đính chính/xóa/hạn chế (Nhân sự xử lý trong hạn, không tự xử lý yêu cầu của mình, không xóa mù — nêu phần tiếp tục lưu), lịch sử truy cập vào dữ liệu của tôi, giới hạn liên hệ |
| Chống dò quét, chiếm tài khoản (SEC-T08/T16) | Giới hạn tốc độ theo IP và cho đăng nhập; sai mật khẩu 5 lần → tạm khóa 15 phút (không khóa vĩnh viễn); đếm 403/404 để phát hiện dò ID, xem nhiều hồ sơ, xuất nhiều → **cảnh báo** cho Quản trị rà soát (không tự kết luận) |
| Thu hồi phiên (SEC-T09) | Token kiểm tra lại trạng thái tài khoản/thành viên mỗi request; không nhận token qua URL |
| Truy cập đặc quyền (SEC-T10) | Hỗ trợ nền tảng không đọc dữ liệu mặc định; xin quyền theo phạm vi, lý do, phiếu, ≤24 giờ; doanh nghiệp duyệt (người yêu cầu không tự duyệt); khẩn cấp 1 giờ + hậu kiểm; mọi lần xem ghi nhật ký |
| Nhật ký | `data_access_logs` chỉ ghi thêm (trigger chặn sửa/xóa, chỉ job lưu trữ được xóa khi quá hạn); không ghi giá trị nhạy cảm |
| Thông báo (SEC-T14, AB-12) | Báo cáo hành vi chỉ gửi thông báo tối thiểu (mã hồ sơ, không nội dung/danh tính); bỏ lý do nghỉ khỏi thông báo |
| Lưu trữ & xóa | Doanh nghiệp đặt thời hạn (thông báo, ghi âm, nhật ký, tệp xuất, hồ sơ hành vi); job mỗi giờ xóa và ghi `data_deletion_jobs` |
| Báo cáo hành vi cần xem xét (UX-ABUSE-01) | Luồng 4 bước (nhóm vấn đề + "Tôi không chắc", mô tả ngắn, bằng chứng tùy chọn, nguy cơ hiện tại, liên hệ an toàn, ẩn danh có giải thích giới hạn) từ hồ sơ, bình luận, lịch sử truy cập; định tuyến tới đầu mối không xung đột lợi ích (không bao giờ là người được báo cáo); người báo cáo thấy mã + trạng thái + cập nhật, không thấy tên người xử lý; người được báo cáo chỉ thấy tóm tắt khi được mời giải trình, không thấy danh tính/bằng chứng; người xử lý: sàng lọc, xác minh, yêu cầu bổ sung, mời giải trình, mức ưu tiên S0–S4 (không phải kết luận), ghi chú nội bộ, kết quả trung tính, chuyển đơn vị, khai báo xung đột lợi ích → tự chuyển người khác; "Tôi lo ngại bị trả đũa" + danh sách thay đổi do người được báo cáo thực hiện liên quan người báo cáo sau thời điểm báo cáo; yêu cầu xem xét lại → người độc lập; Chủ DN có sổ theo dõi không nội dung |

Kiểm thử: `test/v5.test.ts` (SEC-T01–T10, lưu trữ, AB-02/03/04/06/07/08/09/12/13/15).

**Cần đơn vị vận hành / pháp chế hoàn thiện (ngoài mã nguồn)**
- TLS: `deploy/install.sh` cấp HTTPS (certbot/caddy). Mã hóa ổ đĩa/sao lưu Postgres, quản lý khóa (KMS/secret manager), luân chuyển `JWT_SECRET`: thực hiện trên hạ tầng.
- Băm mật khẩu đang dùng bcrypt (cost 10); có thể nâng lên Argon2id khi chạy trên hạ tầng hỗ trợ module native.
- Quét mã độc tệp tải lên (ClamAV…), pentest độc lập, giám sát tập trung.
- Chính sách quyền riêng tư, thông báo xử lý dữ liệu, thỏa thuận xử lý dữ liệu với doanh nghiệp, thời hạn lưu chính thức, quy trình ứng phó sự cố — theo Luật 91/2025/QH15 và Nghị định 356/2025/NĐ-CP (cần luật sư rà soát).
- Quyết định cần Product Owner chốt (Phụ lục B / mục 18): đầu mối báo cáo hành vi, có cho ẩn danh với người xử lý không, thời hạn lưu từng loại.

## Tính năng bổ sung v4

1. **Dấu hiệu màu thay chữ**: ghim = việc gấp, đỏ = quá hạn, vàng = chờ nghiệm thu, xanh lá = hoàn thành, xanh lam = đang thực hiện, tím = đột xuất, đen = hủy (xám = chưa bắt đầu, vòng rỗng = chờ giai đoạn trước / chờ duyệt). Bộ lọc ở trang Công việc là hàng dấu tròn nhỏ (`src/marks.tsx`).
2. **Trở ngại**: bỏ tab Trở ngại ở trang Công việc (báo trở ngại từ từng công việc). Trang `/reports`: quản lý nhận báo cáo do nhân viên mình gửi, chọn *Chuyển lên cấp*, *Thông báo nhóm kỹ thuật* hoặc *Tự giải quyết — giao việc* (form giao việc điền sẵn tiêu đề, mô tả, `sourceReportId`). Tab *Cấp dưới đã quyết định* cho cấp trên xem trạng thái ("A chuyển đến B", "A giao cho C"), đổi bộ phận hoặc đổi người xử lý (`POST /workplace-reports/:id/override-owner`); không đổi thì mặc nhiên chấp nhận, người chịu trách nhiệm cuối cùng hiển thị trên báo cáo. Việc xử lý xong → báo cáo chờ người báo xác nhận.
3. **Nhóm**: bỏ "Khai việc", giữ Gọi / Nhắn / Zalo; ai cũng xem được số việc đang làm, chờ nghiệm thu, xong trong tháng, quá hạn của từng thành viên.
4. **Việc nhiều lớp / giai đoạn**: phần việc con có `stage_no`; cùng giai đoạn chạy song song, giai đoạn sau tự mở (`waiting` → `not_started`) và báo người phụ trách khi giai đoạn trước xong; việc khung tự chuyển chờ nghiệm thu khi mọi phần con xong. Nghiệm thu không nhảy cấp: quản lý trực tiếp của nhóm (nếu chính họ phụ trách thì người giao việc, rồi cấp trên trực tiếp). Mỗi người chỉ thấy phần việc của mình trong chuỗi. Giao phần việc sang nhóm mình không quản lý → `pending_approval`, cấp quản lý cao hơn duyệt. Mẫu "Nhập hàng" / "Xử lý đơn hàng" có sẵn giai đoạn. Tự khai báo có 3 chế độ nhanh: *thêm vào việc đang có*, *việc thường ngày* (được yêu cầu / tự chủ động, chỉ cần mô tả), *việc ngoài vai trò* (người giao, lý do, bằng chứng).
5. **Mô tả công việc theo vai trò** (`/hr/roles`, gán ở Thành viên): căn cứ gợi ý việc trong / ngoài vai trò; người xác nhận có thể đổi phân loại.
6. **Quyền sửa việc**: người giao việc sửa mô tả, deadline, tiêu chí, người vận hành khi chưa nghiệm thu; quản lý lớp dưới trong chuỗi chỉ thêm / đổi người phụ trách.
7. **Điểm mới**: `E = min(100, E_cơ bản + w_O × O)`, E_cơ bản = 0.25V + 0.20T + 0.30Q + 0.10D + 0.05R. Việc khung không tính (tránh trùng); giờ việc thường ngày / nhánh được xác nhận cộng vào V với hệ số 0,8; O = giờ việc ngoài vai trò được xác nhận (16 giờ = 100), w_O = 0,10 — chỉ cộng, không trừ ai. Việc chờ giai đoạn / chờ duyệt không tính vào tiến độ.

## Tính năng bổ sung v3

| # | Tính năng | Hiện thực |
|---|---|---|
| 1 | Điều chuyển, thăng chức, thôi việc: quyết định (PDF), hạn bàn giao; nhân viên thấy quyết định ở Trang chủ, lập bàn giao từng việc; **chỉ khi quản lý xác nhận bàn giao** quyết định mới hiệu lực và người đó mới nhận việc mới | `decisions.controller.ts` (`assertAssignable` chặn giao việc/khai việc nhanh cho người đang bàn giao), `DecisionDetail.tsx`, nút trong *Thành viên* |
| 2 | Tab **Giao việc**: danh sách thành viên theo nhóm, thu gọn được; số việc dưới avatar; bấm avatar → giao việc nhanh; **15 mẫu việc** (nhập kho, xuất kho, xử lý nguyên liệu, giao hàng, hàng tồn, bảo vệ ca trực, khiếu nại khách hàng, hàng lỗi, kiểm kê, đóng gói, bảo trì, vệ sinh 5S, mua vật tư, tiếp khách, báo cáo) có trường khai báo nhanh | `Assign.tsx`, `TaskForm.tsx`, `library.ts` |
| 3 | Giấy phép mẫu chuẩn: ra vào cổng, mang hàng ra cổng, sử dụng xe, sử dụng thiết bị (xe nâng, máy móc), vào khu vực hạn chế. Người giao việc lập kèm công việc; bộ phận phụ trách xem thông tin việc và cấp phép; **cấp tự động bằng đơn khai báo**, bộ phận hậu kiểm nhận–trả, ra–vào; sai quy trình → người giao chịu trách nhiệm (thông báo + báo cáo điểm nghẽn). Thẻ giấy phép có mã QR | `permits.controller.ts`, `PermitDetail.tsx`, `PermitForm.tsx`, cấu hình bộ phận trong *Cấu hình → Giấy phép* |
| 4 | Thủ tục công ty: thư viện 11 quy trình (bản **chuẩn hóa cho công ty** + bản **tham khảo** từ các phương pháp quản trị phổ biến SMART, RACI, PDCA, 5W2H, DRI); **tin vắn nhắc quy trình theo bộ phận** theo chu kỳ; **sơ đồ tổ chức** dạng cây; tình trạng nhân sự tuần nằm trong *Hệ thống nhân sự*; **sơ đồ đường đi quy trình giao việc**; hướng dẫn giao việc | `hr.controller.ts` (tin vắn mỗi ngày làm việc sau 8:30, tối đa 1 tin/người/ngày), `HrHub.tsx`, `OrgChart.tsx`, `Procedures.tsx`, `AssignFlow.tsx`, `AssignGuide.tsx` |
| 5 | Biểu tượng chuyên nghiệp (Lucide), font Be Vietnam Pro, thẻ chào, ô chức năng có biểu tượng màu, menu dạng danh sách | `icons.tsx`, `styles.css` |
| 6 | Script triển khai cho `viecden.nhavanmon.com.vn` | `deploy/install.sh`, workflow mặc định `API_URL` |

## Tính năng bổ sung v2 (Việc Đến)

| # | Tính năng | Hiện thực |
|---|---|---|
| 1 | Đăng nhập/đăng ký bằng SĐT, tên hiển thị là họ tên đầy đủ; thêm thành viên bằng SĐT; ảnh đại diện quét gương mặt; hồ sơ xin việc (thông tin cá nhân, kinh nghiệm, lịch sử làm việc) + phần **app tự cập nhật** (việc hoàn thành, đúng hạn, điểm nghiệm thu, điểm hiệu suất đã chốt, tăng ca, nghỉ phép…) | `auth.controller.ts`, `profile.controller.ts`, `FaceCapture.tsx`, `ProfilePage.tsx`, `PersonProfile.tsx`. SĐT chưa có tài khoản được tạo ở trạng thái “chờ kích hoạt”; người đó **Đăng ký bằng đúng SĐT** để vào thẳng công ty. Lịch sử tự động ở doanh nghiệp cũ chỉ hiện cho nhà tuyển dụng khi người lao động bật đồng ý chia sẻ |
| 2 | Chủ doanh nghiệp nâng cấp: gói Nhỏ/Vừa/Lớn (hạn mức 20/100/500 thành viên), tên công ty, email liên hệ; phân vai trò; Quản lý thêm thành viên bằng SĐT → **Quản lý nhân sự kiểm duyệt** | `subscriptions.controller.ts`, `plans.ts`, `company.controller.ts` (`POST /company/members`, `/members/:id/hr-review`), vai trò mới `hr` |
| 3 | Lịch tuần/tháng ở đầu Trang chủ, nút mở rộng/thu nhỏ, danh sách việc trong ngày; việc chưa xác nhận hoàn thành **tự chuyển sang ngày hôm sau** | `calendar.controller.ts`, `Calendar.tsx`, `tasks.plan_date` + scheduler |
| 4 | “Việc của tôi”/“Cần tôi xử lý” chỉ hiện mục có số liệu và tài khoản có quyền thao tác | `Home.tsx` |
| 5 | Logo và tên app **Việc Đến** | `mobile-web/public/*`, `mobile-web/resources/android/res` (sinh bằng `scripts/gen-icons.py`), `capacitor.config.json` |
| 6 | Giao việc qua gọi điện/tin nhắn: nút Gọi/SMS/Zalo trong app, quay lại app sau cuộc gọi → gợi ý khai việc điền sẵn; **link khai việc** gửi kèm tin nhắn mở mẫu đã điền sẵn; ghi âm; ai khai trước thì người kia chỉ cần xác nhận (chống khai trùng) → tạo nhiệm vụ chính thức | `quick-claims.controller.ts`, `QuickClaimForm.tsx`, `ContactReturnPrompt.tsx`, `AudioRecorder.tsx`, route `/q?c=…` |
| 7 | Đánh dấu & **ghim việc gấp** lên đầu danh sách; quản lý đổi trạng thái/gỡ ghim; nhân viên nhận thông báo | `POST /tasks/:id/pin` |
| 8 | Xin nghỉ đột xuất/theo giờ/theo ca/theo ngày, báo trước (cảnh báo nếu ít hơn quy định); quản lý duyệt → **xuất đơn PDF, gửi tự động sang Nhân sự** (thông báo trong app + email nếu cấu hình SMTP); tình trạng nhân viên trong tuần; bước chọn nhân viên khi giao việc hiển thị trạng thái (nghỉ phép, khối lượng, quá hạn) | `leaves.controller.ts`, `team/availability`, `TeamWeek.tsx`, `TaskForm.tsx` (2 bước) |

**Biến môi trường mới**

| Biến | Ý nghĩa |
|---|---|
| `PLAN_ACTIVATION` | `auto` (mặc định, dùng thử — kích hoạt gói ngay) hoặc `manual` (chờ quản trị nền tảng xác nhận thanh toán) |
| `PAYMENT_INSTRUCTIONS` | Nội dung hướng dẫn chuyển khoản hiện cho chủ doanh nghiệp |
| `PLAN_SMALL_LIMIT`, `PLAN_SMALL_PRICE`, … `PLAN_LARGE_PRICE` | Hạn mức & giá gói (giá mặc định chỉ là giá minh họa) |
| `SMTP_URL`, `SMTP_FROM` | Gửi email đơn nghỉ (kèm PDF) cho nhân sự. Không cấu hình thì chỉ gửi thông báo trong app |

**Giới hạn cần biết của v2**

- **Không có OTP SMS**: đăng ký chỉ cần SĐT + mật khẩu, nên ai biết một SĐT “chờ kích hoạt” có thể đăng ký trước chủ số. Cần tích hợp nhà cung cấp OTP (ví dụ eSMS, Stringee, Firebase Phone Auth) trước khi dùng thật.
- **Thanh toán gói chưa tích hợp cổng thanh toán**: chế độ `auto` kích hoạt ngay; chế độ `manual` cần quản trị nền tảng bấm xác nhận sau khi nhận chuyển khoản.
- **Ghi âm cuộc gọi & lịch sử cuộc gọi**: Android/iOS không cho ứng dụng thường tự ghi âm cuộc gọi hay đọc nhật ký cuộc gọi. App thay bằng: gọi/nhắn từ trong app rồi gợi ý khai việc khi quay lại, link khai việc trong tin nhắn, ghi âm bằng micro (loa ngoài/trao đổi trực tiếp) hoặc đính kèm file ghi âm có sẵn của máy.
- **Quét gương mặt**: chụp trực tiếp từ camera trước với khung gương mặt; nếu trình duyệt hỗ trợ FaceDetector thì kiểm tra có gương mặt. Đây **không phải** xác thực sinh trắc học/chống giả mạo.
- Thời gian hiển thị theo múi giờ của điện thoại; lịch & SLA tính theo múi giờ công ty.

## Đối chiếu đặc tả → hiện thực

| Mục | Nội dung | Hiện thực |
|---|---|---|
| 2 | 6 vai trò, phân quyền công ty ≠ vai trò trong nhóm | `company_members.role` + `groups.manager_member_id`; kiểm tra quyền server-side mọi endpoint; cách ly `company_id` |
| 3.1 | Điều hướng Trang chủ / Công việc / Nhóm / Đánh giá / Cá nhân, chuông thông báo | `mobile-web/src/App.tsx` |
| 4 | Nhiệm vụ: đầu vào/đầu ra, độ khó, mức yêu cầu, thời lượng, deadline, 6 trạng thái, quá hạn là cờ tính toán | `tasks.controller.ts`; tiêu chí lưu **phiên bản** (`task_criteria.version`); đổi phạm vi/deadline sau khi bắt đầu **bắt buộc lý do** + audit |
| 4.3 | Khung thời lượng; deadline theo giờ làm việc | Gợi ý deadline `GET /company/calendar/suggest-due` theo lịch công ty |
| 5 | Việc đột xuất (4 loại), yêu cầu chung/đa dạng, yêu cầu con có phiên bản, bộ tiêu chí 35/20/20/15/10 riêng | `unexpected_tasks`, `task_subitems`; điểm tách riêng trong báo cáo |
| 6 | Tăng ca: 5 loại, ghi nhận cả khi chưa duyệt, không xóa, không tính lương, không cộng điểm | `overtime.controller.ts` |
| 7 | Tự khai báo; xác nhận / một phần / từ chối / yêu cầu bổ sung; tranh chấp; **khiếu nại từ lần từ chối thứ 4**; khiếu nại sớm; cấp giải quyết cao hơn người bị khiếu nại; quá SLA → chuyển cấp, không coi im lặng là đồng ý | `work-records.controller.ts`; lịch sử quyết định **bất biến** (trigger DB) |
| 8 | Báo cáo trở ngại: 6 nhóm, 4 mức, luồng 6 bước, 10 trạng thái, SLA 8.4, chuyển cấp, kênh độc lập, cảnh báo an toàn | `workplace-reports.controller.ts` + scheduler |
| 9 | Điểm nhiệm vụ 40/30/20/10; W = hệ số phức tạp × yêu cầu; P = ΣC/ΣW; E = 0.25V+0.20T+0.30Q+0.15D+0.10R | `performance.service.ts` (`scoreMembers` là hàm thuần, có unit test) |
| 10 | Báo cáo tháng/quý/năm theo cá nhân/nhóm/công ty, điểm nghẽn, so sánh kỳ trước, **snapshot** giữ nguyên khi công thức đổi, xuất PDF/Excel | `performance.controller.ts` |
| 11 | Thông báo có liên kết đúng bản ghi, chống gửi trùng (dedupe), lưu trạng thái gửi | `common/notify.ts`, bảng `notifications` |
| 12 | Mô hình dữ liệu (UUID, `company_id`, UTC, soft delete nhóm, bản ghi bất biến) | `backend/src/db/schema.sql` |
| 13 | REST API `/api/v1`, mã lỗi nghiệp vụ ổn định, phân trang/lọc, giới hạn upload, idempotency | Header `Idempotency-Key` cho mọi POST; lỗi dạng `{error:{code,message}}` |
| 14.2 | RBAC, audit, khóa tài khoản & thu hồi phiên, quyền xem tệp theo đối tượng | `audit_logs`, refresh token xoay vòng, khóa sau 10 lần sai mật khẩu |
| 16 / 16.1 | Tiêu chí nghiệm thu & tình huống biên | `backend/test/e2e.test.ts` |

### Giá trị mặc định đã áp dụng cho các quyết định mục 18 (đều cấu hình được trong *Cá nhân → Cấu hình*)

D01 nhân viên được tham gia nhiều nhóm · D02 xem toàn bộ nhiệm vụ nhóm mình · D03 giao chéo nhóm chỉ khi được cấp quyền (theo từng người) · D04 khiếu nại từ lần từ chối thứ 4 · D05 hạn xác nhận 1 ngày làm việc (480 phút) · D06 lịch T2–T6, 08:00–17:00, nghỉ trưa 12–13, ngày lễ cấu hình · D07 tuyến: cấp trên trực tiếp → … → Admin → Owner → reviewer độc lập · D08 SLA theo bảng 8.4 · D09 trọng số đề xuất, mỗi lần đổi tạo phiên bản mới · D10 điểm chỉ tham khảo · D11 không tính lương tăng ca · D12 PDF + Excel.

### Diễn giải công thức (cần chủ sản phẩm xác nhận khi chạy pilot)

Tài liệu nêu thành phần nhưng chưa định nghĩa chi tiết cách đo; bản MVP dùng cách sau:

- **Ghi nhận khi có cộng tác viên:** người chịu trách nhiệm nhận 60% trọng số nhiệm vụ, cộng tác viên chia đều 40% (tổng không vượt 100% — không nhân đôi điểm).
- **V** = khối lượng có trọng số, chuẩn hóa về 0–100 so với người cao nhất **cùng vai trò** trong công ty trong kỳ.
- **T** = tỷ lệ đúng hạn theo lần bàn giao đầu tiên; việc trễ có trở ngại **đã được quản lý xác nhận** thì không tính.
- **Q** = 0.7 × điểm nghiệm thu bình quân có trọng số + 0.3 × tỷ lệ đạt lần đầu.
- **D** = hệ số W bình quân, quy đổi tuyến tính về 0–100.
- **R** = điểm “quá trình/cập nhật/phối hợp” do người nghiệm thu chấm.
- Thành phần thiếu dữ liệu được bỏ qua và chia lại trọng số; báo cáo gắn nhãn “chưa đủ dữ liệu”.
- Bản ghi tự khai báo được chấp nhận được thống kê (số lượng, giờ) nhưng **chưa** cộng vào điểm.

## Khác biệt so với đề xuất kỹ thuật (mục 14) — cần lưu ý

- **Mobile: PWA React thay vì Flutter.** Môi trường xây dựng không có Flutter/Android SDK để build và kiểm thử. PWA chạy trên trình duyệt di động và cài được lên màn hình chính; toàn bộ nghiệp vụ nằm ở API nên app Flutter có thể làm sau trên cùng API mà không đổi backend.
- **Push notification (FCM):** đã có bản ghi thông báo in-app, chống trùng và cột `push_status`; **chưa** gửi FCM thật (cần khóa Firebase + worker gửi).
- **Lưu tệp:** driver lưu đĩa cục bộ (`UPLOAD_DIR`) sau một lớp trừu tượng; chưa có driver S3.
- **Background jobs:** dùng scheduler trong tiến trình thay vì BullMQ/Redis. An toàn khi chạy nhiều instance (khóa `SKIP LOCKED`, khóa duy nhất cho chuyển cấp, dedupe thông báo); nếu tách worker, đặt `DISABLE_SCHEDULER=true` trên các instance API.
- **Đăng nhập:** email + mật khẩu (JWT 30 phút + refresh token xoay vòng). Admin mời thành viên và nhận mật khẩu tạm thời; chưa gửi email mời.
- Docker/Docker Compose đã viết nhưng **chưa build thử** trong môi trường này; cách chạy bằng Node + PostgreSQL ở trên đã được kiểm chứng.

## Cấu trúc mã

```
backend/src
  common/        auth guard, RBAC/tuyến cấp trên, lịch làm việc, audit, thông báo, idempotency, lỗi
  db/            schema.sql, migrate, seed (seed chạy qua chính REST API)
  modules/       auth, company (cấu hình), groups, tasks, overtime, work-records, workplace-reports,
                 escalation(s), performance (tính điểm + báo cáo + xuất), notifications, files, dashboard, scheduler
mobile-web/src
  api.ts         gọi API, tự làm mới token, Idempotency-Key, retry khi mất mạng
  pages/         Trang chủ theo vai trò, Công việc (nhiệm vụ/tự khai báo/tăng ca/trở ngại), Nhóm,
                 Đánh giá & báo cáo, Cá nhân, Bảng kỹ thuật, Chuyển cấp, Quản trị thành viên & cấu hình
```

## Build trên GitHub Actions

File workflow: `.github/workflows/build.yml`. Đẩy mã lên GitHub (nhánh `main`/`master`) hoặc vào tab **Actions → Build → Run workflow**. Có 3 job:

1. **test** — chạy 30 test backend trên PostgreSQL 16 (service container).
2. **server** — build backend + PWA, tải về ở artifact `server-bundle` (xem `START.txt` bên trong).
3. **android** — đóng gói PWA thành app Android bằng Capacitor, ra file APK debug ở artifact `android-apk`.

App Android cần biết địa chỉ API: nhập `api_url` khi chạy tay, hoặc tạo biến repo `API_URL` (Settings → Secrets and variables → Actions → Variables), ví dụ `https://api.congty.vn/api/v1`. Mặc định `http://10.0.2.2:3000/api/v1` (chỉ dùng cho máy ảo Android trỏ về máy chạy server).

Hạn chế của bản APK: là bản debug (chưa ký phát hành); nút xuất PDF/Excel trong WebView Android có thể không tải được tệp — dùng bản web để xuất báo cáo.
