# Việc Đến — Quản lý & Giám sát việc

Ứng dụng quản lý nhóm, giao việc và đánh giá hiệu suất (MVP).

Hiện thực theo tài liệu *“Hồ sơ yêu cầu sản phẩm và đặc tả kỹ thuật” v1.0 (12/11/2026)*.

| Thành phần | Công nghệ | Thư mục |
|---|---|---|
| Backend API `/api/v1` | NestJS + TypeScript (modular monolith), PostgreSQL | `backend/` |
| Ứng dụng di động | PWA React (mobile-first, cài lên màn hình chính Android/iOS) | `mobile-web/` |
| Background jobs | Scheduler trong tiến trình (`@nestjs/schedule`), chạy mỗi phút | `backend/src/modules/scheduler.service.ts` |

## Chạy nhanh

Cần Node 22 và PostgreSQL 16.

```bash
# 1. Backend
cd backend
npm install
export DATABASE_URL=postgresql://app:app@localhost:5432/teamapp   # các biến khác: xem .env.example
npm run seed                      # tạo schema + dữ liệu demo (XÓA dữ liệu cũ)
npm run dev                       # API: http://localhost:3000/api/v1

# 2. Giao diện (terminal khác)
cd mobile-web
npm install
npm run dev                       # http://localhost:5173 (proxy /api -> :3000)
```

Bản production: `cd mobile-web && npm run build`, rồi `cd backend && npm run build && npm start` — API sẽ phục vụ luôn PWA tại `http://localhost:3000`.
Hoặc dùng Docker: `docker compose up --build` (sau đó chạy seed nếu muốn dữ liệu demo).

**Tài khoản demo** — đăng nhập bằng số điện thoại, mật khẩu `Demo@123`:

| SĐT | Vai trò | SĐT | Vai trò |
|---|---|---|---|
| 0901000001 | Chủ doanh nghiệp | 0901000007 | Nhân viên 1 (Vũ Thị Giang) |
| 0901000002 | Quản trị | 0901000008 | Nhân viên 2 |
| 0901000003 | Quản lý nhóm Vận hành | 0901000009 | Nhân viên 3 |
| 0901000004 | Quản lý nhóm Kinh doanh | 0901000010 | Nhân viên 4 |
| 0901000005 | Trưởng bộ phận Kỹ thuật | 0901000011 | Reviewer độc lập |
| 0901000006 | Kỹ thuật viên | 0901000012 | Quản lý nhân sự |
| 0901000013 | Trưởng ca bảo vệ (bộ phận Bảo vệ) | 0901000014 | Thủ kho (bộ phận Kho vận) |
| 0900000000 | Quản trị nền tảng Việc Đến (xác nhận thanh toán gói) | | |

**Kiểm thử:** `cd backend && npm test` — 53 test (lịch làm việc, bộ máy tính điểm, và e2e theo tiêu chí nghiệm thu mục 16/16.1) chạy trên PostgreSQL thật (DB `teamapp_test`, đổi bằng `TEST_DATABASE_URL`).

## Triển khai lên server `viecden.nhavanmon.com.vn`

1. Tạo bản ghi DNS **A**: `viecden` → IP của VPS (trong trang quản lý DNS của `nhavanmon.com.vn`).
2. Đảm bảo repo GitHub có mã nguồn mới nhất (thư mục `backend`, `mobile-web`, `deploy` hoặc đúng **một** file `source.zip`).
3. SSH vào VPS (Ubuntu 22.04/24.04) và chạy:
   ```bash
   curl -fsSL https://raw.githubusercontent.com/mabenh/Quan-Ly---Giao-Viec/main/deploy/install.sh -o install.sh && sudo bash install.sh --seed
   ```
   (`--seed` chỉ nạp dữ liệu demo khi CSDL còn trống — không bao giờ xóa dữ liệu đang dùng; các lần cập nhật sau chạy không cần `--seed`.) Script cài Node 22, PostgreSQL, tạo CSDL riêng `viecden`, build app, chạy dịch vụ `viecden` (systemd), gắn tên miền vào Nginx/Caddy đang có (hoặc cài Caddy) và cấp HTTPS. Chạy lại script để cập nhật phiên bản mới; mật khẩu CSDL và JWT được giữ nguyên.
4. Workflow GitHub build APK mặc định trỏ về `https://viecden.nhavanmon.com.vn/api/v1`. Nếu repo đang có biến `API_URL` cũ thì xóa hoặc sửa biến đó.

## Phiên bản v14 — Không mất tài khoản khi cập nhật, OTP qua SMS, tên công ty gọn, tối ưu tốc độ

**1. Tài khoản đăng ký và đăng nhập được giữ qua các lần cập nhật**
- Nguyên nhân mất tài khoản: các lần trước cập nhật bằng `install.sh --seed`, lệnh này **xóa sạch CSDL** rồi nạp lại dữ liệu demo.
- Từ v14:
  - `--seed` chỉ nạp demo khi CSDL **còn trống**. Đã có tài khoản thì bỏ qua và giữ nguyên dữ liệu.
  - Muốn xóa sạch phải chạy `--reset-demo` và gõ `XOA` để xác nhận.
  - Trước mỗi lần cập nhật, script **tự sao lưu CSDL** vào `/opt/viecden/backups` (giữ 14 bản).
- **Cập nhật từ nay chỉ cần:** `sudo bash /opt/viecden/src/deploy/install.sh` (không thêm `--seed`).
- Khôi phục từ bản sao lưu (nếu cần):
  `gunzip -c /opt/viecden/backups/<tệp>.sql.gz | sudo -u postgres psql viecden`
- Giữ đăng nhập 90 ngày; mỗi lần dùng app lại gia hạn thêm. Đổi được qua biến `REFRESH_DAYS`.
- Khi máy chủ đang khởi động lại hoặc mạng rớt, app hiện "Đang kết nối lại máy chủ…" và tự thử lại, **không đăng xuất**.
- App nhớ số điện thoại đăng nhập lần trước.

**2. OTP qua SMS**
- **Đăng ký:** bấm "Gửi mã" → nhập mã 6 số → tạo tài khoản. Số điện thoại được đánh dấu đã xác thực.
- **Đăng nhập:** chọn "Bằng mật khẩu" hoặc "Bằng mã OTP".
- **Quên mật khẩu:** nhập số điện thoại → nhận mã → đặt mật khẩu mới → đăng nhập luôn. Các thiết bị khác đang đăng nhập bị đăng xuất.
- **Đổi mật khẩu** (Cá nhân › Đổi mật khẩu): dùng mật khẩu hiện tại *hoặc* mã OTP.
- **Bảo vệ chống lạm dụng:**
  - Mã hết hạn sau 5 phút; nhập sai 5 lần thì mã bị khóa.
  - Gửi lại mã sau 60 giây; mỗi số tối đa 5 mã/giờ, mỗi mạng (IP) tối đa 20 mã/giờ.
  - Số chưa đăng ký vẫn nhận phản hồi giống hệt, nhưng không gửi SMS thật (để người khác không dò được số nào đã đăng ký).
- **Cấu hình nhà cung cấp SMS** (thêm vào `/opt/viecden/.env`, rồi chạy `sudo systemctl restart viecden`; các lần cập nhật sau script giữ nguyên các biến này):

| Nhà cung cấp | Biến cần đặt |
|---|---|
| eSMS.vn | `SMS_PROVIDER=esms`, `ESMS_API_KEY`, `ESMS_SECRET_KEY`, `ESMS_BRANDNAME` (tùy chọn `ESMS_SMS_TYPE`, mặc định 2) |
| SpeedSMS.vn | `SMS_PROVIDER=speedsms`, `SPEEDSMS_TOKEN`, `SPEEDSMS_SENDER` (tùy chọn `SPEEDSMS_TYPE`, mặc định 5) |
| Twilio | `SMS_PROVIDER=twilio`, `TWILIO_SID`, `TWILIO_TOKEN`, `TWILIO_FROM` |
| Hệ thống riêng | `SMS_PROVIDER=webhook`, `SMS_WEBHOOK_URL` (nhận JSON `{phone, text}`), `SMS_WEBHOOK_TOKEN` |

- **Khi đã cấu hình SMS**, đăng ký bắt buộc OTP. Muốn bật/tắt thủ công thì đặt `OTP_REQUIRED=true` hoặc `OTP_REQUIRED=false`.
- **Khi chưa cấu hình SMS**:
  - Đăng ký không bắt buộc OTP.
  - Quên mật khẩu và đăng nhập bằng mã vẫn dùng được: mã hiện ở **Quản trị nền tảng › Mã OTP**, quản trị đọc mã cho khách qua điện thoại sau khi đã xác minh đúng chủ số.
  - Mã cũng hiện ở đó khi SMS gửi lỗi.
- Nội dung SMS viết không dấu để tiết kiệm phí:
  "Ma xac thuc Viec Den cua ban la 123456. Het han sau 5 phut…".
  Brandname cần đăng ký mẫu nội dung này với nhà mạng.

**3. Logo và tên công ty**
- Logo trên thanh trên cùng to hơn: 34px → 46px.
- Tên công ty hiển thị gọn theo tên trọng điểm, ví dụ "Công ty TNHH Demo Việt" → **"Cty … Demo Việt"**. Hệ thống tự bỏ các phần "Công ty", "TNHH", "MTV", "Cổ phần"…
- Bấm vào tên sẽ hiện **tên đầy đủ** ở đầu bảng "Doanh nghiệp của tôi" (kèm đổi công ty).
- Quản trị đặt tên rút gọn tùy ý ở Cấu hình công ty › **Thông tin công ty**.
- Dòng tên người dùng chỉ còn một dòng.

**4. Tối ưu tốc độ (app treo)**
- **Tách mã theo trang:**
  - Tệp chính giảm từ 988KB xuống 611KB; chỉ tải trang đang xem.
  - Máy chủ nén gzip (đã thêm vào cấu hình Nginx/Caddy), nên tệp chính tải về chỉ khoảng 194KB.
- **Service worker mới:**
  - Tệp giao diện được lưu trên máy sau lần mở đầu, các lần sau không tải lại.
  - Trang chính quá 4 giây chưa tải xong thì mở bằng bản đã lưu.
- **Thời gian chờ ngắn hơn:**
  - Yêu cầu đọc dữ liệu tối đa 15 giây, chỉ thử lại 1 lần. Trước đây có thể chờ tới hơn 1 phút.
  - Số thông báo không còn tải lại mỗi lần chuyển trang.
- **Máy chủ:**
  - Mở tối đa 20 kết nối CSDL; truy vấn treo quá 20 giây sẽ bị hủy.
  - Thêm chỉ mục cho các truy vấn thăm dò thường xuyên.
  - **Bỏ giới hạn làm mới phiên theo IP.** Trước đây cả xưởng dùng chung một IP, làm mới phiên quá 30 lần/phút sẽ bị chặn — đây là một nguyên nhân gây "lỗi kết nối".
  - Giới hạn đăng nhập theo IP nâng lên 120 lần/phút.
- **Quản trị nền tảng › Kết nối & tốc độ:** liệt kê các yêu cầu chậm trên máy chủ (từ 1,5 giây) và lỗi kết nối phía app, để tìm đúng chỗ còn chậm.

**Cập nhật lên v14:**
1. Đưa `source.zip` mới lên GitHub.
2. Chạy `sudo bash /opt/viecden/src/deploy/install.sh` (**không** thêm `--seed`).
3. APK đã cài từ v13 tự nhận giao diện mới, không cần cài lại.

**Kiểm thử:** `backend/test/v14.test.ts` gồm các ca:
- Đăng ký bắt buộc OTP.
- Sai mã 5 lần thì khóa.
- Đăng nhập bằng OTP.
- Quên mật khẩu và thu hồi phiên cũ.
- Đổi mật khẩu bằng OTP.
- Nhật ký OTP của quản trị nền tảng.
- Tên rút gọn công ty.

## Phiên bản v13 — Gọi nhóm & nhắn tin nhóm, nhiều doanh nghiệp, sửa lỗi "chưa đổi" và lỗi kết nối

**1. Vì sao ứng dụng "chưa đổi" (vẫn chưa thấy gói cộng thêm)**
- Nguyên nhân: bản APK cũ **đóng gói sẵn giao diện** lúc build. Server cập nhật rồi nhưng app trên điện thoại vẫn chạy giao diện cũ.
- Từ v13, APK **tải giao diện trực tiếp từ `https://viecden.nhavanmon.com.vn`**. Mỗi lần server cập nhật, app có bản mới ngay, không cần cài lại.
  - Khi mất mạng, app mở giao diện dự phòng có sẵn trong APK.
- **Cần làm một lần duy nhất:** chạy lại GitHub Actions để build APK mới (đã sửa trong `.github/workflows/build.yml`), rồi **gỡ app cũ và cài APK mới** trên điện thoại.
- Server gửi `index.html` kèm `Cache-Control: no-store`; service worker đổi lên `shell-v3`. Trình duyệt và PWA không còn giữ bản cũ.
- Banner **"Đã có phiên bản mới — Cập nhật ngay"** hiện khi app phát hiện server đã được cập nhật (kiểm tra mỗi 5 phút và mỗi lần mở lại app).

**2. Nhóm liên lạc: nhắn tin nhóm + gọi nhóm** (Liên lạc › tab **Nhóm**)
- **Ai được lập nhóm:**
  - Trưởng nhóm / tổ trưởng (tầng 6): chỉ thêm thành viên các nhóm mình phụ trách.
  - Trưởng phòng (tầng 5): chỉ thêm thành viên trong phòng ban mình.
  - Ban điều hành (tầng 3–4) và quản trị: thêm được người toàn công ty.
  - Nhân viên tầng 7 không lập nhóm, chỉ được thêm vào nhóm.
- **Quyền hạn nhóm** (chủ nhóm / quản trị nhóm thiết lập):
  - Ai được nhắn tin.
  - Ai được bắt đầu gọi nhóm.
  - Ai được thêm thành viên.
  - Mỗi quyền trên chọn được: *mọi thành viên* hoặc *chỉ quản trị nhóm*.
  - Thời lượng tối đa mỗi cuộc gọi: 3–30 phút, mặc định 10 phút.
  - Chủ nhóm có thể cấp hoặc bỏ quyền quản trị nhóm, xóa thành viên, giải tán nhóm. Thành viên tự rời nhóm được.
- **Nhắn tin nhóm:** có đếm tin chưa đọc (cộng vào biểu tượng 📞 trên cùng). Tin nhắn tự xóa sau 30 ngày như tin nhắn riêng.
- **Gọi nhóm trong app:**
  - Không qua nhà mạng, không hiện số; tối đa 8 người.
  - Mọi thành viên nhóm nhận thông báo và **banner "… đang gọi nhóm — Tham gia"** trên mọi màn hình.
  - Trong cuộc gọi: tắt/bật mic, rời cuộc gọi, thu nhỏ để xem tin nhắn nhóm.
  - Người rớt mạng quá 20 giây tự được tính là đã rời. Cuộc gọi tự kết thúc khi hết giờ hoặc không còn ai.
  - Mạng 4G chặn kết nối trực tiếp thì cần máy chủ TURN (biến `TURN_URL/TURN_USER/TURN_PASS`, giống gọi 1-1).

**3. Lỗi kết nối**
- Mỗi yêu cầu bị treo quá 25 giây sẽ tự hủy và thử lại, nên app không còn bị "đứng".
  - Mất mạng: app chờ có mạng lại rồi gửi tiếp.
  - Server đang khởi động lại khi cập nhật (lỗi 502/503/504): app tự thử lại.
- Thanh trạng thái **"Mạng yếu — đang kết nối lại…" / "Điện thoại đang mất mạng"** thay cho thông báo lỗi đỏ liên tục.
- **Chẩn đoán kết nối:** app tự gửi về các lỗi mất mạng, quá thời gian, lỗi 5xx, 429.
  - Xem tại Cấu hình công ty › tab **Chẩn đoán kết nối** (quản trị nền tảng xem tất cả công ty).
  - Bảng cho biết lỗi xảy ra ở chức năng nào, bao nhiêu người, trên app Android hay web. Dữ liệu lưu 7 ngày.
  - Nếu vẫn có lỗi, hãy gửi ảnh chụp bảng này để tìm đúng nguyên nhân (mạng nhà máy, máy chủ, hay TURN).

**4. Nhiều doanh nghiệp cho một tài khoản**
- **Đổi doanh nghiệp/công ty ngay trên thanh trên cùng:** bấm **tên công ty ▾**. Bảng nổi hiện ra gồm:
  - Các công ty bạn đang làm (bấm để chuyển).
  - Các yêu cầu gia nhập đang chờ (hủy được).
  - Ô **Gia nhập công ty khác**.
  - Nút **Mở doanh nghiệp mới**.
- **Mở doanh nghiệp thứ 2:** Chủ doanh nghiệp (hoặc bất kỳ ai) bấm "Mở doanh nghiệp mới" và mua gói như bình thường. Công ty mới có dữ liệu, thành viên và gói riêng.
- **Nhân viên gia nhập công ty thứ 2:**
  1. Ban quản trị / Nhân sự lấy **mã gia nhập 8 ký tự** ở Thành viên › *Mã gia nhập công ty*. Có thể đổi mã; mã cũ hết hiệu lực ngay.
  2. Nhân viên đã có tài khoản Việc Đến nhập mã. App hiện tên công ty để xác nhận rồi gửi yêu cầu.
  3. Nhân sự công ty đó duyệt như thành viên mới và xếp chức vụ, phòng ban.
  4. Sau khi được duyệt, nhân viên đổi qua lại giữa hai công ty bằng nút tên công ty.
- Gia nhập vẫn tính vào hạn mức thành viên của gói công ty đó.

**Kiểm thử:** `backend/test/v13.test.ts` gồm các ca:
- Quyền lập nhóm theo tầng và phạm vi.
- Nhắn tin, đếm tin chưa đọc, quyền nhắn tin, rời nhóm.
- Gọi nhóm: tham gia, báo hiệu, rời, quyền gọi.
- Mở doanh nghiệp thứ 2, mã gia nhập → nhân sự duyệt → đổi công ty, đổi mã.
- Nhật ký lỗi kết nối.

## Phiên bản v12 — Gói cộng thêm, gia hạn / chuyển / hủy gói có hoàn tiền; chức danh theo danh mục; Khối → Phòng ban → Bộ phận → Nhóm

**1. Gói doanh nghiệp** (Cá nhân › Gói doanh nghiệp, dành cho Chủ doanh nghiệp)
- Mua mới theo 3 bước: **Gói cơ bản → Gói cộng thêm → Xác nhận**.
- Gói cộng thêm (giá cho kỳ 12 tháng, đổi được qua biến `ADDON_*_PRICE`):

| Gói | Gói cơ bản | Mỗi gói cộng thêm | Tổng thành viên tối đa |
|---|---|---|---|
| Doanh nghiệp nhỏ | 20 người | +10 người · 500.000đ | 90 |
| Doanh nghiệp vừa | 100 người | +50 người · 2.000.000đ | 450 |
| Doanh nghiệp lớn | 500 người | +100 người · 3.500.000đ | không giới hạn |

- **Gia hạn**: thêm một kỳ, tính theo **tổng gói cơ bản + các gói cộng thêm** đang dùng; hạn mới cộng tiếp từ ngày hết hạn cũ.
- **Mua thêm gói cộng thêm** giữa kỳ: chỉ trả theo số ngày còn lại của kỳ.
- **Chuyển gói** (lên hoặc xuống): giá trị còn lại của gói hiện tại được trừ vào gói mới; nếu còn dư thì hoàn phần dư; kỳ mới tính từ hôm nay. Không cho chuyển nếu số thành viên hiện có vượt hạn mức gói mới.
- **Hủy gói**: hoàn giá trị còn lại theo số ngày chưa dùng; gói ngừng hiệu lực ngay và không thêm được thành viên mới.
- Cách tính giá trị còn lại: (gói cơ bản + gói cộng thêm) × số ngày còn lại / 365.
- Màn hình hiện báo giá trước khi xác nhận và có lịch sử giao dịch.
- Quản trị nền tảng có thêm tab **"Chờ hoàn tiền"** để xác nhận đã hoàn kèm mã giao dịch.

**2. Chức vụ – cấp bậc – chức danh**
- Form thêm/sửa thành viên: **bỏ ô "Vai trò"**; **Chức vụ (tầng) và Cấp bậc nghề nghiệp** đặt lên đầu.
- Vai trò hệ thống tự xác định theo chức vụ và phòng ban. Quản trị vẫn chỉnh được trong mục "Nâng cao".
- **Cấp bậc ghi tiếng Việt**: Thực tập sinh, Nhân sự mới, Nhân sự có kinh nghiệm, Nhân sự chuyên môn cao, Chuyên viên chuyên sâu, Chuyên gia, Chuyên gia cấp cao, Kỹ sư cấp cao, Quản lý, Quản lý cấp cao. Dữ liệu cũ đang ghi tiếng Anh được tự chuyển đổi.
- **Chức danh là ô chọn** từ danh mục **205 chức danh** lấy theo tài liệu *Hệ thống phân cấp doanh nghiệp tầng 3–7* (gồm tầng 3–7 và các phòng ban chức năng). Danh sách được gợi ý theo tầng của chức vụ đã chọn.
- Chọn chức danh nào sẽ hiện **vai trò & nhiệm vụ** của chức danh đó. Vẫn nhập được chức danh khác ngoài danh mục.

**3. "Bộ phận" đổi thành "Phòng ban"; thêm cấp Bộ phận và Nhóm bên dưới**
- Cơ cấu: **Khối → Phòng ban → Bộ phận → Nhóm**.
- Cấu hình công ty › **Phòng ban**:
  - Phòng ban hiển thị theo 4 khối, kèm mô tả chức năng, các bộ phận và nhóm bên dưới.
  - Nút **"Thêm phòng ban từ danh mục chuẩn"**: chọn trong 17 phòng ban của danh mục, hệ thống tạo luôn bộ phận và nhóm chuẩn theo danh sách đã gửi (7 phòng có bộ phận/nhóm chi tiết).
  - Chọn lại một phòng ban đã có thì không tạo trùng.
  - Thêm bộ phận thủ công được; nhóm gắn vào bộ phận.
- Khi thêm nhân viên: chọn **Phòng ban → Bộ phận → Nhóm**.
- Các chỗ trước đây gọi "bộ phận" theo nghĩa phòng ban (giấy phép, trở ngại, sơ đồ tổ chức, SLA…) nay ghi "phòng ban".

## Phiên bản v11 — Sửa lỗi kết nối, Kêu gọi hỗ trợ, Báo cáo phản ánh ẩn danh, Dòng thời gian nhiệm vụ, Bình luận, Thiết bị

**1. Sửa lỗi trang Liên lạc & lỗi kết nối thường xuyên.** Nguyên nhân và cách sửa:
- *Bị đăng xuất / báo lỗi khi mạng chập chờn hoặc mở 2 tab:* mỗi lần làm mới phiên, mã cũ bị hủy ngay; nếu phản hồi bị rơi (4G yếu, app chạy nền) thì lần sau bị từ chối và app tự đăng xuất. Nay mã vừa đổi vẫn dùng được thêm 60 giây; lỗi mạng tạm thời không còn làm đăng xuất; tab khác đã có mã mới thì dùng luôn.
- *Bị chặn "Quá nhiều yêu cầu" (429):* trước đây giới hạn tính theo IP, cả xưởng dùng chung wifi nên chung 1 IP. Nay giới hạn tính **theo người dùng** (`RATE_LIMIT_USER_PER_MIN=600`); chỉ yêu cầu chưa đăng nhập mới tính theo IP.
- *Thăm dò cuộc gọi quá dày:* 4 giây/lần khi rảnh, tạm dừng khi app chạy nền, không tự thử lại liên tục.
- *Trang tin nhắn:* làm mới nền im lặng, không hiện lỗi đỏ khi rớt một lượt mạng; bỏ tiếng "ping" ngay lúc mở app.

**2. Kêu gọi hỗ trợ** (Yêu cầu hỗ trợ › "Kêu gọi toàn nhóm / toàn phòng")
- Người gửi: quản lý phòng (toàn phòng) hoặc trưởng nhóm (toàn nhóm). Yêu cầu nằm trong **Việc của tôi** trên trang chủ của người gửi.
- Thành viên nhận thông báo và chọn **Đồng ý** hoặc **Từ chối**. Người đồng ý có tên trong **Danh sách hỗ trợ**.
- Hỗ trợ **không bắt buộc**, không tạo việc mới, không phải khai việc, nhưng được ghi nhận đầy đủ:
  - "Bắt đầu hỗ trợ" → thẻ phiên làm việc hiện **"Đang hỗ trợ <người yêu cầu>"**; "Kết thúc hỗ trợ" → thời gian được cộng dồn.
  - **Lịch sử hỗ trợ và thời gian hỗ trợ** xem ở Vị trí phiên làm việc (quản lý xem được của nhân viên trong phòng).
- Người yêu cầu **hủy được** yêu cầu; người đã đồng ý nhận tin báo kèm lý do.
- Khi **gửi bàn giao chờ nghiệm thu** có mục chọn **tên người hỗ trợ**; họ được ghi nhận và nhận thông báo.
- Đến hỗ trợ mà không có tên: mở nhiệm vụ › **Báo cáo / phản ánh** › chọn "Hỗ trợ không được ghi nhận".

**3. Báo cáo / phản ánh** (nút trong nhiệm vụ, Tổng quan; xử lý ở Cần xử lý › Báo cáo)
- Lý do: gian dối về kết quả, tự ý rời vị trí, không đúng tác phong – trang phục, mang đồ ăn – thức uống vào khu sản xuất, hỗ trợ không được ghi nhận, vi phạm an toàn, khác.
- Chọn **công bố tên** hoặc **ẩn danh**. Ẩn danh thì hệ thống **không lưu danh tính** (chỉ lưu dạng băm để chống báo trùng), nên quản lý cũng không thấy được tên.
- Thời gian và nội dung được ghi lại, gửi tới người phụ trách tầng 5 (trưởng phòng).
- Nhiều người báo cùng một việc và cùng lý do được gộp vào một hồ sơ, hiển thị tên công việc, người phụ trách, lý do và **số người báo cáo**.
- Người phụ trách kết luận (có ảnh hưởng tiến độ/chất lượng không, xử lý thế nào). Nếu có ảnh hưởng, hồ sơ được đưa vào dòng thời gian của nhiệm vụ.

**4. "Cần tôi xử lý" đổi thành "Cần xử lý"**
- Thứ tự mục: Quyết định · **Báo cáo** · Bàn giao · Giấy phép · Nghỉ phép.
- **Xác nhận hỗ trợ** hiện trong mục Quyết định.

**5. Dòng thời gian & điểm vướng** (trong mọi nhiệm vụ và đơn hàng, đang làm hoặc đã xong)
- Hiển thị chuỗi sự kiện từ khi bắt đầu tới hiện tại kèm thời gian chi tiết: các công đoạn, phiên làm việc, đoạn bị vướng (chờ/hoãn, trở ngại, chờ tiếp nhận bàn giao) với nguyên nhân, thời lượng và cách giải quyết, các lần hỗ trợ, phản ánh có ảnh hưởng.
- Phần tóm tắt cho biết: tổng thời gian, thời gian bị vướng, 3 điểm vướng lâu nhất, thời gian từng công đoạn. Có lọc "Chỉ điểm vướng".

**6. Bình luận**
- Bình luận mới **đẩy nhiệm vụ lên đầu danh sách**; thẻ nhiệm vụ hiện "💬 n mới" (số bình luận chưa đọc).
- **Trả lời trích dẫn** bình luận trước (người được trích dẫn nhận thông báo).
- Chỉ hiện 3 bình luận mới nhất, nút **Xem thêm** để đọc toàn bộ lịch sử.

**7. Giấy phép & thiết bị**
- Mục giấy phép trong form giao việc có nút **Thu gọn** (mặc định thu gọn).
- Thiết bị dùng trong phòng ban/vị trí thực hiện không cần giấy phép; **mang ra – vào phải chọn giấy phép** của nhiệm vụ.
- Nhiệm vụ có mục **Thiết bị sử dụng**: người nhận nhiệm vụ khai báo, ghi **vị trí ban đầu** (sửa/bổ sung được sau).
- Kiểm kê **cuối ngày** hoặc **khi hoàn thành**; không kiểm kê khi đổi phiên/khu vực (mặc định không mang theo thiết bị).
- **Hoàn thành nhiệm vụ bắt buộc có vị trí hiện tại của mọi thiết bị.**

## Phiên bản v10 — Nhân sự theo tầng/phòng ban, Cần tôi xử lý, Ghi nhận chấm công, Giấy phép tự tạo

**1. Thêm nhân viên** (Cá nhân › Thành viên, hoặc Nhân sự › Thành viên)
- Có thêm các trường: **phòng ban**, **bộ phận/nhóm** (lọc theo phòng ban), **chức vụ (tầng)**, **cấp bậc**.
- Ai được thêm:
  - Tầng 3, 4 (và Chủ DN/Quản trị/Quản lý nhân sự): thêm vào mọi phòng ban, có hiệu lực ngay.
  - **Tầng 5: chỉ thêm vào phòng ban của mình**; nhân sự kiểm duyệt trước khi có hiệu lực.
  - Tầng 6–7: không được thêm.
- Chỉ gán được chức vụ thấp hơn tầng của người thêm.

**2. Danh sách thành viên**
- Phân loại **theo tầng chức vụ** hoặc **theo phòng ban**, các nhóm thu gọn được.
- Tầng 5 chỉ thấy phòng ban của mình và **chỉ định trưởng nhóm** cho các nhóm thuộc đơn vị mình quản lý; tầng 3–4 chỉ định cho mọi nhóm.

**3. Quyết định nhân sự** (Nhân sự › Quyết định)
- Trang chính là **danh sách nhân sự theo tầng 3 → 7**; bấm vào một người để **Điều chuyển / Thăng chức / Thôi việc**.
- Quyết định có thể đổi **chức vụ (tầng)**; chức vụ mới được áp dụng khi bàn giao được xác nhận.
- Người ra quyết định: tầng 3–4 và Quản lý nhân sự.

**4. Sửa lỗi nút quay lại bị lặp** khi vào tin nhắn: nút quay lại không còn tạo thêm lịch sử, nên không còn nhảy qua lại giữa Liên lạc và Tin nhắn.

**5. Ghi nhận chấm công** (Công việc › Khai báo công việc › Chấm công) — thay cho "Ghi nhận giờ làm ngoài máy chấm công"
- Quản lý dùng **"Ghi nhận chấm công"** cho nhân viên: có hiệu lực ngay, nhân viên nhận thông báo "Thời gian làm việc của bạn đã được ghi nhận".
- Nhân viên dùng **"Tự khai báo chấm công"**: quản lý trực tiếp xác nhận hoặc từ chối.
- Chỉ ghi giờ bắt đầu – kết thúc, **không tự tính tăng ca**.
- **Đối chiếu trùng** trên cùng người được ghi nhận. Bị từ chối, kèm thông báo "đã được ghi nhận bởi…", khi:
  - trùng thời gian;
  - cùng nhiệm vụ trong ngày;
  - người khai là chính người giao nhiệm vụ đó;
  - tự khai báo công việc trùng giờ với bản quản lý đã ghi nhận.
- Không thể có cả quản lý lẫn nhân viên cùng khai một công việc.

**6. Công việc › Cần tôi xử lý** (đứng cạnh Nhiệm vụ)
- Gồm các mục **Quyết định**, **Bàn giao**, **Giấy phép**, **Nghỉ phép**.
- Mục Bàn giao gồm bàn giao liên bộ phận (chuyển từ trang Cá nhân sang) và giải trình bàn giao bên ngoài đang chờ duyệt.
- Đã bỏ "Mục khác" ở chân trang. Đường dẫn cũ `/handovers`, `?tab=permits`, `?tab=leaves` tự chuyển về đây.

**7. Tạo nhóm**
- Tầng 3–4 **chọn phòng ban trước**, danh sách thành viên tự lọc theo phòng ban đó, rồi chọn người quản lý và thành viên.
- Tầng 5 mặc định phòng ban của mình, chỉ chọn người quản lý và thành viên trong phòng (hoặc người chưa thuộc phòng ban nào).

**8. Lập đơn hàng**
- **Tầng 3, 4, 5** được lập đơn (trừ Quản lý nhân sự); tầng 3–4 duyệt.
- "Nhóm lập đơn" đổi thành **Nhóm phụ trách điều hành** cộng **Người phụ trách điều hành** (có thể là chính người lập). Thành viên nhóm này nhận thông báo khi đơn được lập.
- Loại công việc cố định là **"Chuỗi công việc sản xuất"**.
- Nút **"Dùng chuỗi sản xuất chuẩn"** điền sẵn: Tính toán nguyên liệu → Thiết kế lại bao bì (nếu cần) → Mua nguyên liệu → Sản xuất → Đóng gói → Giao hàng.
- Mỗi công đoạn chọn nhóm nhỏ phụ trách. Thành viên nhóm công đoạn nhận **2 thông báo**: khi đơn được duyệt và khi công đoạn của họ bắt đầu.

**9. Giấy phép** (Cấu hình công ty › Giấy phép › **Tạo giấy phép**)
- Khi tạo loại giấy phép, khai báo:
  - tên và bộ phận tiếp nhận;
  - **dùng 1 lần / dùng nhiều lần**;
  - cách theo dõi (cổng / thiết bị / không);
  - có cho người đi cùng không;
  - các **thông tin người lập cần điền**.
- Trong mỗi giấy phép có **người cấp phép** (người giao việc), **người sử dụng** (người được giao việc) và **người đi cùng** (nếu có).
- Nhân viên bộ phận xử lý nhận thông tin, nhưng **chỉ cấp quản lý của bộ phận** (trưởng bộ phận, tầng 3–5) mới duyệt.
- Loại dùng 1 lần tự đóng sau lần sử dụng đầu; loại dùng nhiều lần thì đếm số lượt.

**10. Mẫu công việc**: có nút **Thu gọn / Mở rộng** danh sách mẫu khi giao việc; lựa chọn được nhớ trên máy.

**11. Trang Cá nhân chỉ còn các mục thiết lập**
- Cá nhân: hồ sơ, quyền riêng tư, âm thanh & thông báo.
- Vận hành & hiệu suất: chỉ còn **Tổng quan công ty** và **Khu vực & mã QR**.
- Bàn giao: chỉ còn **thiết lập** (Cấu hình công ty › tab **Bàn giao**):
  - liên bộ phận: bắt buộc tiếp nhận, thời hạn tiếp nhận;
  - bàn giao chờ duyệt: hạn QR, cho phép từ chối, nghiệm thu sau bàn giao, SLA duyệt giải trình, bằng chứng bắt buộc.
- Quản trị: thành viên, mẫu công việc, cấu hình, an toàn dữ liệu, gói.
- Các danh sách đã chuyển sang Công việc › Cần tôi xử lý và tab Nhân sự.

## Phiên bản v9 — Liên lạc trong app, Yêu cầu hỗ trợ, hai luồng QR (Đặc tả v2.1)

**Trang chủ**
- Có nút **Thu gọn / Mở rộng** cho danh sách "Việc hôm nay"; lựa chọn được nhớ trên máy.
- Đã bỏ ô "Ghi nhận công việc" (khai báo làm ở phần Công việc).
- Ô **Vị trí phiên làm việc** (`/my-area`) đặt cạnh **Đơn hàng**, thay chỗ "Thời gian & kết quả" và giữ nguyên toàn bộ nội dung cũ.
- Dưới phiên làm việc có dòng **lịch sử khu vực đã qua trong ngày** kèm thời gian ở lại (VD: Kho nguyên liệu 40p → Khu đóng gói 1g20), cùng nút **Quét QR**.

**Phần Công việc** có 4 mục ngang hàng, trang chính là **Tổng quan** (đã sửa lỗi tự nhảy sang Khai báo):
- **Tổng quan** gồm:
  - Mô tả công việc của vai trò được giao: chức vụ, tầng, mô tả và nhiệm vụ chính.
  - Phòng ban và nhóm đang làm việc.
  - **Tin chính của phòng**: Trưởng phòng và Ban điều hành đăng được, có ghim và báo cho cả phòng.
  - **Thông báo**: trở ngại vừa được báo và nhiệm vụ đang cần hỗ trợ trong nhóm/phòng.
- **Nhiệm vụ**: danh sách nhiệm vụ như trước.
- **Khai báo công việc**: các thẻ Của tôi / **Nhật ký liên lạc** / Cần tôi xác nhận / Phòng ban. Đã bỏ "Việc thường ngày" (đã có trong Tự khai báo) và "Việc giao qua điện thoại" (thay bằng Nhật ký liên lạc).
- **Báo cáo trở ngại**: Chưa xử lý / Đã xử lý.

**Yêu cầu hỗ trợ** (`/support/new`, có nút trong Tổng quan, Nhiệm vụ và chi tiết nhiệm vụ)
- Yêu cầu được đẩy ra thông báo của các thành viên khác trong nhóm.
- Người cùng nhóm bấm **Tiếp nhận**, làm xong thì khai số phút.
- Công chỉ được ghi nhận khi **người yêu cầu xác nhận**: lúc đó hệ thống tạo bản ghi "hỗ trợ" đã chấp nhận cho người hỗ trợ và thêm họ làm cộng tác viên của nhiệm vụ. Không xác nhận thì bắt buộc ghi lý do.

**Liên lạc trong app** (`/contacts`, biểu tượng điện thoại trên thanh trên cùng)
- **Ẩn số điện thoại**: trang nhóm, sơ đồ tổ chức, giao việc, hồ sơ đồng nghiệp chỉ còn tên. Nhân sự vẫn xem số trong trang quản trị thành viên.
- **Gọi thoại qua app (WebRTC)**: không qua nhà mạng, không hiện số. **Mỗi cuộc tối đa 3 phút**: app đếm ngược và báo trước 30 giây, máy chủ tự kết thúc khi hết giờ.
- **Ghi âm cuộc gọi**:
  - Trộn tiếng cả hai bên; bên kia luôn thấy dòng "đang ghi âm".
  - Người ghi phải đồng ý mục đích *Ghi âm cuộc gọi khai việc* (Cá nhân › Quyền riêng tư).
  - Gọi xong có nút **Khai báo công việc từ cuộc gọi**: bản khai điền sẵn người giao và thời gian; ghi âm được sao sang bản khai làm tài liệu.
- **Nhắn tin trực tiếp** trong app.
- **Zalo**: máy chủ cấp liên kết dùng một lần (hết hạn sau 60 giây) rồi chuyển hướng, app không bao giờ nhận số.
- **Âm thanh & thông báo** (`/settings/sound`): bật/tắt chuông, âm lượng, rung, âm báo tin nhắn/thông báo, tắt tiếng theo loại, giờ yên lặng.
- **Nhật ký cuộc gọi, tin nhắn, ghi âm tự xóa sau 30 ngày** (chạy mỗi giờ). Ghi âm đã sao sang bản khai công việc vẫn được giữ.
- Lưu ý vận hành: gọi giữa hai điện thoại dùng 4G thường cần máy chủ **TURN**. Cài coturn rồi thêm `TURN_URL=turn:viecden.nhavanmon.com.vn:3478`, `TURN_USER`, `TURN_PASS` vào `/opt/viecden/.env` (install.sh giữ lại các dòng này khi cập nhật). Cùng mạng wifi thì không cần. Gọi chỉ hoạt động trên HTTPS và khi mở app (chưa có đổ chuông nền khi đóng app).

**QR luồng A — kết nối khu vực làm việc** (quản trị tại `/admin/areas`, quét tại `/scan`)
- Cấu trúc Cơ sở → Khu vực → Trạm (tùy chọn) → QR.
- Token ngẫu nhiên 192 bit, DB chỉ lưu bản băm. Có thể in tem, thu hồi, cấp lại (mã cũ tự thu hồi) và tạm khóa khu vực.
- Quét QR → hiện khu vực để xác nhận → tạo phiên khu vực:
  - Quét lại cùng mã không tạo phiên trùng; hai lần gửi đồng thời vẫn chỉ ra một phiên.
  - Quét mã khác phải **xác nhận chuyển khu vực**; phiên cũ chuyển sang TRANSFERRED và giữ lịch sử.
- Sau khi kết nối, app mở mẫu **bắt đầu phiên làm việc mới** với **vị trí điền sẵn** theo khu vực; nhiệm vụ do nhân viên tự chọn.
- Quản lý được **ghi nhận hộ** (bắt buộc lý do, nguồn ghi là "quản lý ghi hộ").
- Phiên quá 12 giờ chuyển sang EXPIRED (không coi là vắng mặt).
- Sự kiện khu vực là bất biến. Phiên khu vực **không phải chấm công** và không dùng đánh giá năng suất.

**QR luồng B — bàn giao nhiệm vụ bên ngoài**
- Khi giao việc chọn loại **"Chuyển giao bên ngoài"** và nhập: người nhận, liên hệ (mã hóa AES-GCM), nội dung, địa điểm, có cho từ chối không, có nghiệm thu sau không.
- Người thực hiện bấm **Đề nghị bàn giao** để tạo QR/link (hạn 7 ngày): đưa người nhận quét hoặc gửi liên kết.
- Người nhận mở **trang công khai `/h/<mã>`**, không cần cài app; trang chỉ hiện thông tin tối thiểu, tên người nhận được che bớt.
  - Xác nhận: idempotent, bấm lặp vẫn chỉ ra một bản ghi xác nhận.
  - **Không tiếp nhận**: bắt buộc lý do.
- Nhiệm vụ loại này **không thể bấm "Bàn giao kết quả"**. Chỉ hoàn thành khi người nhận xác nhận, hoặc **giải trình bỏ qua QR** được người giao chấp nhận:
  - Giải trình bắt buộc ghi lý do, kèm bằng chứng nếu có; nhiệm vụ chuyển **Treo — chờ duyệt**.
  - Nhân viên không tự duyệt được giải trình của mình.
  - Từ chối giải trình bắt buộc lý do; nhiệm vụ quay lại xử lý; gửi giải trình lần nữa tạo bản ghi mới.
- Danh sách chờ duyệt tại `/handover-exceptions`. Bản ghi xác nhận/duyệt/sự kiện là bất biến.

**Biến môi trường mới**: `PUBLIC_URL` (install.sh tự đặt), `FIELD_ENCRYPTION_KEY` (tự sinh), `TURN_URL/TURN_USER/TURN_PASS`, `CALL_LIMIT_SECONDS=180`, `COMMS_RETENTION_DAYS=30`, `AREA_SESSION_HOURS=12`, `HANDOVER_QR_DAYS=7`.

**Các quyết định QR-01…QR-10** đang dùng mặc định đề xuất của tài liệu:
- Phiên khu vực tự hết hạn sau 12 giờ; mỗi người một phiên chính.
- QR khu vực tĩnh, có thu hồi; người ngoài xác nhận bằng link/token.
- QR bàn giao hạn 7 ngày; người duyệt là người giao việc, quản lý nhóm hoặc Ban quản trị.
- Người nhận được phép từ chối; chưa có giao từng phần; nghiệm thu sau bàn giao tùy chọn theo nhiệm vụ.
- SLA duyệt ngoại lệ chưa cấu hình.

Cần chủ sản phẩm chốt lại các mục này trước khi áp dụng chính thức.

## Phiên bản v8 — Phân cấp doanh nghiệp tầng 3–7, quy trình đơn hàng, mẫu theo phòng ban

**Ai lập, ai xem xét, ai duyệt đơn hàng?**

| Bước | Ai được làm | Ghi chú |
|---|---|---|
| Lập đơn (và thêm công đoạn/đơn con) | Ban điều hành (tầng 3), quản lý cấp cao (tầng 4), Chủ sở hữu/Quản trị; Trưởng/Phó phòng (tầng 5) của phòng **Kinh doanh, Kế hoạch, Sản xuất** | Quản lý nhân sự **không** lập đơn/đơn con |
| Xem xét năng lực | Tầng 3–4; Trưởng/Phó phòng **Kế hoạch, Sản xuất** | Người lập không tự xem xét đơn của mình |
| Duyệt & phát hành | Tầng 3–4, Chủ sở hữu/Quản trị | Người lập không tự duyệt; người có quyền duyệt lập đơn thì đơn phát hành ngay |

Luồng: **Lập → Chờ xem xét → Đã xem xét → Đã duyệt** (hoặc Trả lại → người lập sửa và Gửi lại). Khi chưa duyệt, các công đoạn ở trạng thái chờ và trưởng nhóm chưa nhận thông báo. Sau khi duyệt, **trưởng nhóm nhận công đoạn lần lượt**: giai đoạn 1 mở trước, giai đoạn sau mở khi giai đoạn trước xong (cùng giai đoạn thì chạy song song).

- **Lập đơn hàng** = nhiệm vụ chuỗi sản xuất, **không chọn mẫu công việc**. Bắt buộc chọn **vị trí làm việc** (Xưởng số 1/2/3, Công ty, Thuê ngoài…, khai báo ở Cài đặt › Vị trí). Mỗi công đoạn chọn **một hoặc nhiều nhóm**, trưởng nhóm của từng nhóm nhận việc (giao cho nhiều trưởng nhóm cùng lúc).
- **Việc đơn lẻ**: ở bước chọn nhân viên có thêm chế độ **"Nhiều trưởng nhóm"**, dành cho quản lý phòng ban và cấp cao: mỗi nhóm được chọn nhận một nhiệm vụ riêng.
- **Phân cấp & quyền hạn** (Cài đặt › Chức vụ & quyền hạn): tách riêng chức vụ, tầng (3 Điều hành → 7 Nhân sự thực thi), vai trò hệ thống và cấp bậc nghề nghiệp. Quyền lập/xem xét/duyệt đơn, giao việc (toàn công ty / phòng ban / nhóm), quản lý mẫu và xem báo cáo có mặc định theo tầng và bật/tắt được riêng cho từng chức vụ (có ghi nhật ký). Gán chức vụ và cấp bậc ở Thành viên; gán chức năng cho phòng ban; gán nhóm vào phòng ban ở trang nhóm.
- **Giao việc theo vai trò**: tầng 3–4 giao toàn công ty; tầng 5 giao cho các nhóm trong phòng ban mình và xem việc của các nhóm đó; tầng 6 (trưởng nhóm/tổ trưởng/trưởng ca) chỉ giao trong nhóm mình; tầng 7 không giao việc. **Quản lý nhân sự** chỉ thấy và giao việc cho các nhóm thuộc phòng Nhân sự.
- **Mẫu công việc theo phòng ban**: người giao việc chỉ thấy mẫu của phòng ban mình được giao việc, cộng với mẫu dùng chung. Quản lý phòng ban tạo và sửa mẫu của phòng mình (trường khai báo, tiêu chí, giờ chuẩn) tại *Giao việc › Mẫu công việc*. Bổ sung sẵn mẫu cho Nhân sự, Hành chính, Tài chính, Kinh doanh, QA, Sản xuất, IT, An toàn, Marketing.
- **Phần Công việc** gồm 2 mục chính:
  - **Khai báo công việc**: gộp Tự khai báo, việc thường ngày và việc được giao qua điện thoại. Có các thẻ Của tôi / Cần tôi xác nhận / Phòng ban (hoặc Toàn đơn vị); mô tả hướng dẫn thay đổi theo tầng và theo phòng Nhân sự.
  - **Báo cáo trở ngại**: hai tầng con **Chưa xử lý** / **Đã xử lý**. Phạm vi xem gồm Cần tôi xử lý / Cấp dưới đã quyết định / Tôi báo cáo / Toàn đơn vị, tùy vai trò.
  - Danh sách nhiệm vụ, giấy phép và nghỉ phép chuyển sang `/tasks`, mở được từ "Mục khác" và từ trang Giao việc.

## Phiên bản v7

1. **Giờ làm/tăng ca ngoại lệ** (`/overtime/new`): khi máy chấm công không hoạt động hoặc làm ngoài công ty/xưởng; người ghi nhận là người yêu cầu và phải cao hơn người được ghi nhận (cấp trên, trưởng nhóm/quản lý nhóm, hoặc vai trò cao hơn); có hiệu lực ngay, lưu vết.
2. **Chia giai đoạn con**: không chọn được giai đoạn đã hoàn thành (kiểm tra cả ở server).
3. **Giao việc**: chọn loại ở đầu form — Việc đơn lẻ / Đơn hàng mới (tự tạo hoặc nhập mã đơn, không trùng) / Thuộc đơn hàng có sẵn (tạo nhiệm vụ con, chọn phân đoạn) / Nhiệm vụ thường trực.
4. **Mẫu có số phiếu/mã đơn**: chọn "Không có số phiếu" hoặc nhập số.
5. **Tự động bắt đầu**: Thủ công / Khi nhận bàn giao của công đoạn trước (nhiệm vụ tự chuyển "đang thực hiện"; nếu người làm đang trong phiên của công đoạn trước thì phiên chuyển theo) / Theo lịch đặt trước (bộ lập lịch bắt đầu đúng giờ; chưa đủ điều kiện thì báo trưởng nhóm).
6. **Trang Công việc**: bỏ tab Khai nhanh, Tự khai báo, Tăng ca; nút dưới tab đổi thành "Tự khai báo" (Giao việc vẫn ở thanh điều hướng).
7. **Mã hiển thị trước tên**: `NV-00023 - Kiểm kê kho`; công đoạn đơn hàng `DH-00001_NV-00043 - Nhập hàng`; phần việc con `NV-00043.1 - …`.
8. **Nhiệm vụ**: bàn giao kết quả/gửi bàn giao kèm tài liệu và đường link; chỉ người được giao mới ghi nhận sản lượng và gửi bàn giao; người giao việc chỉ điều chỉnh, chỉnh ưu tiên (gồm ghim việc gấp), hủy; bỏ nút ghi tăng ca — tăng ca nằm trong ghi nhận sản lượng (chỉ trưởng nhóm), ghi thời gian làm việc và tăng ca của từng người; "Chia phần việc con" nằm dưới nhiệm vụ; "Điều kiện tiếp nhận" thay bằng **phương thức bàn giao** (nghiệm thu trực tiếp, xác nhận khách hàng, kiểm tra tài liệu, xác nhận của trưởng nhóm (tên), khác).
9. **Bỏ tăng ca chờ xác nhận**: tăng ca chỉ là tham số hiệu suất (thời gian thực hiện = làm việc + tăng ca).
10. **Bắt đầu phiên**: chọn Nhiệm vụ được giao (số hiệu) hoặc Nhiệm vụ thường trực của nhóm (kèm công đoạn). Nhiệm vụ thường trực không có hạn, không tính vào danh sách việc/điểm/quá hạn.

Kiểm thử: `test/v7.test.ts`. Tổng 91 test.

## Phiên bản v6 — Giám sát, điều phối & báo cáo hiệu suất (Đặc tả nghiệp vụ v2.0)

Giao diện cũ giữ nguyên làm trục; phân hệ mới gắn vào **Trang chủ** (thẻ Phiên làm việc + lối vào theo vai trò), **Chi tiết nhiệm vụ** (phần Vận hành), **Cá nhân → Vận hành & hiệu suất** và **Cấu hình**.

| Mục đặc tả | Hiện thực |
|---|---|
| 4. Phiên làm việc | Bắt đầu / Hoãn / Chuyển việc / Tiếp tục / Kết thúc (`/sessions/*`); **1 phiên đang chạy/người** (ràng buộc DB + kiểm tra); chuyển việc đóng & lưu phiên cũ trước; thời gian tách: thực hiện, chuẩn bị, chuyển đổi, chờ việc, hoãn khách quan/chủ quan, nghỉ bổ sung, bàn giao, chưa xác định; tăng ca riêng. Hoãn khách quan do trưởng nhóm xác nhận, không tính vào mẫu số hiệu quả. Phiên quên kết thúc tự đóng, phần sau ghi "chưa xác định" |
| 4.4 Vị trí | Danh mục vị trí (Cấu hình → Vị trí), không GPS; chỉ bắt buộc khi nhiệm vụ đặt `location_required`; tự khai công việc bắt buộc chọn vị trí / Ngoài công ty / Không xác định |
| 5. Sản lượng & chất lượng | Trưởng nhóm (mới: *Trưởng nhóm* của nhóm, mặc định = quản lý nhóm) ghi nhận theo phiên/công đoạn hoặc bàn giao một lần: kế hoạch, thực tế, đạt chuẩn, lỗi, làm lại, tồn, người tham gia; định mức có phiên bản; **không sửa đè** (trigger DB) — điều chỉnh tạo phiên bản mới có lý do. Hiệu suất = thời gian chuẩn quy đổi ÷ thời gian thực hiện; chất lượng tính riêng |
| 6. Quỹ nghỉ tích lũy | Sổ quỹ nghỉ (tích lũy/sử dụng/điều chỉnh); mặc định **tắt** — bật & đặt thông số tại Cấu hình → Thời gian & quỹ nghỉ; chỉ dùng khi đang hoãn khách quan/chờ việc và được trưởng nhóm cho phép; trừ số phút thực tế; tách khỏi nghỉ theo luật và tăng ca, không quy đổi |
| 7. Chuỗi đơn hàng liên bộ phận | Việc gốc đánh dấu đơn hàng → mã `DH-xxxxx`; công đoạn con mã riêng, nhánh song song; **bàn giao liên bộ phận** tự tạo khi công đoạn sau mở (kế thừa kết quả, sản lượng), bên nhận tiếp nhận/từ chối, bên gửi bổ sung; chưa tiếp nhận thì chưa bắt đầu phiên (trừ khi được cho phép bắt đầu sớm có lý do); deadline tính ngược theo lịch làm việc (nhánh dài nhất + dự phòng); cảnh báo Bình thường/Sắp hạn/Nguy cơ trễ/Quá hạn tổng hợp lên chuỗi, chỉ ra công đoạn gây tắc; ưu tiên chỉnh tay có lý do; giá bán/lợi nhuận chỉ Ban quản trị & người tạo chuỗi |
| 8–9. Dashboard theo vai trò | `/board` Ban quản trị (tổng quan, nhóm, đơn hàng, nhân lực, chất lượng, rủi ro, so sánh kỳ trước); `/scope` Quản lý (phạm vi nhóm được giao, thành viên có căn cứ); `/team-live` Trưởng nhóm (ai đang làm gì, sản lượng hôm nay, bàn giao, hoãn/nghỉ, duyệt nghỉ, xác nhận hoãn); `/my-time` Nhân viên (thời gian & nghỉ, kết quả, lịch sử, phản hồi dữ liệu sai). Drill-down mở trang chi tiết vẫn kiểm tra quyền từng đối tượng; công thức hiển thị kèm; không xếp hạng công khai |
| 10–11. Phân quyền & audit | Phạm vi tính ở server (`common/scope.ts`); quản lý nhóm A không xem chi tiết nhóm B; mọi thay đổi sản lượng/định mức/ưu tiên/deadline/xác nhận có lịch sử trước–sau, người, lý do; xem dashboard quản lý ghi nhật ký truy cập |

Kiểm thử: `test/v6.test.ts` (10 nhóm tình huống theo mục 15). Tổng: 85 test.

**Điểm cần Product Owner chốt (mục 16)** — app đã có cấu hình nhưng không tự biến thành chính sách: D-01/D-02 quỹ nghỉ (mặc định tắt), D-03 một trưởng nhóm xác nhận (chưa có người đối soát thứ hai), D-04 định mức theo công đoạn, D-05 thời lượng chuẩn/dự phòng mỗi công đoạn, D-06 trường nhạy cảm (hiện: giá trị đơn & lợi nhuận), D-07 quản lý xem thành viên các nhóm mình quản lý + cấp dưới, D-08 Ban quản trị xem cá nhân (hiện: tổng hợp, truy xuất có nhật ký), D-09 không xếp hạng công khai, D-10 danh mục vị trí, D-11 phụ cấp trưởng nhóm (không gắn điểm), D-12 vai trò kiêm nhiệm (mỗi thành viên một vai trò + vai trò trưởng nhóm theo nhóm). Tích hợp PLC/cảm biến/cân/mã quét: trường `source` đã sẵn, chưa có kết nối thiết bị.

## Bảo mật, quyền riêng tư & chống lạm dụng (v5 — SEC-01, UX-ABUSE-01)

**Đã hiện thực trong app**

| Yêu cầu | Hiện thực |
|---|---|
| Cách ly doanh nghiệp, kiểm tra quyền từng đối tượng (SEC-T01) | Mọi truy vấn lấy `company_id` từ token đã xác thực; tệp/ảnh/hồ sơ kiểm tra quyền khi tải; từ chối trả 404 (không lộ sự tồn tại) và ghi nhật ký `denied` |
| Trường dữ liệu theo vai trò (SEC-T02) | Danh sách thành viên/nhóm/sơ đồ tổ chức che SĐT, email theo mức hiển thị chủ thể chọn (`only_me` / `related` / `company`); chỉ Nhân sự tìm theo SĐT/email; bỏ ghi chú HR khỏi API của người khác |
| Tối thiểu hóa dữ liệu | Bỏ số CCCD, giới tính khỏi hồ sơ; ngày sinh/địa chỉ/email liên hệ không bắt buộc, mặc định "chỉ mình tôi" |
| Phạm vi quản lý (SEC-T03) | Quản lý chỉ xem hồ sơ người trong nhóm mình quản lý / cấp dưới / người mình đề nghị thêm; đánh giá hiệu suất theo phạm vi được giao; hồ sơ có yêu cầu hạn chế chỉ Nhân sự xem |
| Xuất dữ liệu có kiểm soát (SEC-T04) | Xuất báo cáo của người khác phải nêu lý do (hộp cảnh báo trước hành động), giới hạn 20 lần/giờ, ghi nhật ký, đóng dấu người xuất trên PDF/Excel |
| Trung tâm quyền riêng tư (SEC-T05/06/07) | *Cá nhân → Quyền riêng tư*: mức hiển thị theo trường, đồng ý theo từng mục đích (chụp ảnh gương mặt, ghi âm cuộc gọi, chia sẻ CV), danh mục dữ liệu + mục đích + thời hạn lưu + bên nhận, tải dữ liệu của tôi (nhập lại mật khẩu, tệp tự hết hạn), yêu cầu đính chính/xóa/hạn chế (Nhân sự xử lý trong hạn, không tự xử lý yêu cầu của mình, không xóa mù — nêu phần tiếp tục lưu), lịch sử truy cập vào dữ liệu của tôi, giới hạn liên hệ |
| Chống dò quét, chiếm tài khoản (SEC-T08/T16) | Giới hạn tốc độ theo IP và cho đăng nhập; sai mật khẩu 5 lần → tạm khóa 15 phút (không khóa vĩnh viễn); đếm 403/404 để phát hiện dò ID, xem nhiều hồ sơ, xuất nhiều → **cảnh báo** cho Quản trị rà soát (không tự kết luận) |
| Thu hồi phiên (SEC-T09) | Token kiểm tra lại trạng thái tài khoản/thành viên mỗi request; không nhận token qua URL |
| Truy cập đặc quyền (SEC-T10) | Hỗ trợ nền tảng không đọc dữ liệu mặc định; xin quyền theo phạm vi, lý do, phiếu, ≤24 giờ; doanh nghiệp duyệt (người yêu cầu không tự duyệt); khẩn cấp 1 giờ + hậu kiểm; mọi lần xem ghi nhật ký |
| Nhật ký | `data_access_logs` chỉ ghi thêm (trigger chặn sửa/xóa, chỉ job lưu trữ được xóa khi quá hạn); không ghi giá trị nhạy cảm |
| Thông báo (SEC-T14, AB-12) | Báo cáo hành vi chỉ gửi thông báo tối thiểu (mã hồ sơ, không nội dung/danh tính); bỏ lý do nghỉ khỏi thông báo |
| Lưu trữ & xóa | Doanh nghiệp đặt thời hạn (thông báo, ghi âm, nhật ký, tệp xuất, hồ sơ hành vi); job mỗi giờ xóa và ghi `data_deletion_jobs` |
| Báo cáo hành vi cần xem xét (UX-ABUSE-01) | Luồng 4 bước (nhóm vấn đề + "Tôi không chắc", mô tả ngắn, bằng chứng tùy chọn, nguy cơ hiện tại, liên hệ an toàn, ẩn danh có giải thích giới hạn) từ hồ sơ, bình luận, lịch sử truy cập; định tuyến tới đầu mối không xung đột lợi ích (không bao giờ là người được báo cáo); người báo cáo thấy mã + trạng thái + cập nhật, không thấy tên người xử lý; người được báo cáo chỉ thấy tóm tắt khi được mời giải trình, không thấy danh tính/bằng chứng; người xử lý: sàng lọc, xác minh, yêu cầu bổ sung, mời giải trình, mức ưu tiên S0–S4 (không phải kết luận), ghi chú nội bộ, kết quả trung tính, chuyển đơn vị, khai báo xung đột lợi ích → tự chuyển người khác; "Tôi lo ngại bị trả đũa" + danh sách thay đổi do người được báo cáo thực hiện liên quan người báo cáo sau thời điểm báo cáo; yêu cầu xem xét lại → người độc lập; Chủ DN có sổ theo dõi không nội dung |

Kiểm thử: `test/v5.test.ts` (SEC-T01–T10, lưu trữ, AB-02/03/04/06/07/08/09/12/13/15).

**Cần đơn vị vận hành / pháp chế hoàn thiện (ngoài mã nguồn)**
- TLS: `deploy/install.sh` cấp HTTPS (certbot/caddy). Mã hóa ổ đĩa/sao lưu Postgres, quản lý khóa (KMS/secret manager), luân chuyển `JWT_SECRET`: thực hiện trên hạ tầng.
- Băm mật khẩu đang dùng bcrypt (cost 10); có thể nâng lên Argon2id khi chạy trên hạ tầng hỗ trợ module native.
- Quét mã độc tệp tải lên (ClamAV…), pentest độc lập, giám sát tập trung.
- Chính sách quyền riêng tư, thông báo xử lý dữ liệu, thỏa thuận xử lý dữ liệu với doanh nghiệp, thời hạn lưu chính thức, quy trình ứng phó sự cố — theo Luật 91/2025/QH15 và Nghị định 356/2025/NĐ-CP (cần luật sư rà soát).
- Quyết định cần Product Owner chốt (Phụ lục B / mục 18): đầu mối báo cáo hành vi, có cho ẩn danh với người xử lý không, thời hạn lưu từng loại.

## Tính năng bổ sung v4

1. **Dấu hiệu màu thay chữ**: ghim = việc gấp, đỏ = quá hạn, vàng = chờ nghiệm thu, xanh lá = hoàn thành, xanh lam = đang thực hiện, tím = đột xuất, đen = hủy (xám = chưa bắt đầu, vòng rỗng = chờ giai đoạn trước / chờ duyệt). Bộ lọc ở trang Công việc là hàng dấu tròn nhỏ (`src/marks.tsx`).
2. **Trở ngại**: bỏ tab Trở ngại ở trang Công việc (báo trở ngại từ từng công việc). Trang `/reports`: quản lý nhận báo cáo do nhân viên mình gửi, chọn *Chuyển lên cấp*, *Thông báo nhóm kỹ thuật* hoặc *Tự giải quyết — giao việc* (form giao việc điền sẵn tiêu đề, mô tả, `sourceReportId`). Tab *Cấp dưới đã quyết định* cho cấp trên xem trạng thái ("A chuyển đến B", "A giao cho C"), đổi bộ phận hoặc đổi người xử lý (`POST /workplace-reports/:id/override-owner`); không đổi thì mặc nhiên chấp nhận, người chịu trách nhiệm cuối cùng hiển thị trên báo cáo. Việc xử lý xong → báo cáo chờ người báo xác nhận.
3. **Nhóm**: bỏ "Khai việc", giữ Gọi / Nhắn / Zalo; ai cũng xem được số việc đang làm, chờ nghiệm thu, xong trong tháng, quá hạn của từng thành viên.
4. **Việc nhiều lớp / giai đoạn**: phần việc con có `stage_no`; cùng giai đoạn chạy song song, giai đoạn sau tự mở (`waiting` → `not_started`) và báo người phụ trách khi giai đoạn trước xong; việc khung tự chuyển chờ nghiệm thu khi mọi phần con xong. Nghiệm thu không nhảy cấp: quản lý trực tiếp của nhóm (nếu chính họ phụ trách thì người giao việc, rồi cấp trên trực tiếp). Mỗi người chỉ thấy phần việc của mình trong chuỗi. Giao phần việc sang nhóm mình không quản lý → `pending_approval`, cấp quản lý cao hơn duyệt. Mẫu "Nhập hàng" / "Xử lý đơn hàng" có sẵn giai đoạn. Tự khai báo có 3 chế độ nhanh: *thêm vào việc đang có*, *việc thường ngày* (được yêu cầu / tự chủ động, chỉ cần mô tả), *việc ngoài vai trò* (người giao, lý do, bằng chứng).
5. **Mô tả công việc theo vai trò** (`/hr/roles`, gán ở Thành viên): căn cứ gợi ý việc trong / ngoài vai trò; người xác nhận có thể đổi phân loại.
6. **Quyền sửa việc**: người giao việc sửa mô tả, deadline, tiêu chí, người vận hành khi chưa nghiệm thu; quản lý lớp dưới trong chuỗi chỉ thêm / đổi người phụ trách.
7. **Điểm mới**: `E = min(100, E_cơ bản + w_O × O)`, E_cơ bản = 0.25V + 0.20T + 0.30Q + 0.10D + 0.05R. Việc khung không tính (tránh trùng); giờ việc thường ngày / nhánh được xác nhận cộng vào V với hệ số 0,8; O = giờ việc ngoài vai trò được xác nhận (16 giờ = 100), w_O = 0,10 — chỉ cộng, không trừ ai. Việc chờ giai đoạn / chờ duyệt không tính vào tiến độ.

## Tính năng bổ sung v3

| # | Tính năng | Hiện thực |
|---|---|---|
| 1 | Điều chuyển, thăng chức, thôi việc: quyết định (PDF), hạn bàn giao; nhân viên thấy quyết định ở Trang chủ, lập bàn giao từng việc; **chỉ khi quản lý xác nhận bàn giao** quyết định mới hiệu lực và người đó mới nhận việc mới | `decisions.controller.ts` (`assertAssignable` chặn giao việc/khai việc nhanh cho người đang bàn giao), `DecisionDetail.tsx`, nút trong *Thành viên* |
| 2 | Tab **Giao việc**: danh sách thành viên theo nhóm, thu gọn được; số việc dưới avatar; bấm avatar → giao việc nhanh; **15 mẫu việc** (nhập kho, xuất kho, xử lý nguyên liệu, giao hàng, hàng tồn, bảo vệ ca trực, khiếu nại khách hàng, hàng lỗi, kiểm kê, đóng gói, bảo trì, vệ sinh 5S, mua vật tư, tiếp khách, báo cáo) có trường khai báo nhanh | `Assign.tsx`, `TaskForm.tsx`, `library.ts` |
| 3 | Giấy phép mẫu chuẩn: ra vào cổng, mang hàng ra cổng, sử dụng xe, sử dụng thiết bị (xe nâng, máy móc), vào khu vực hạn chế. Người giao việc lập kèm công việc; bộ phận phụ trách xem thông tin việc và cấp phép; **cấp tự động bằng đơn khai báo**, bộ phận hậu kiểm nhận–trả, ra–vào; sai quy trình → người giao chịu trách nhiệm (thông báo + báo cáo điểm nghẽn). Thẻ giấy phép có mã QR | `permits.controller.ts`, `PermitDetail.tsx`, `PermitForm.tsx`, cấu hình bộ phận trong *Cấu hình → Giấy phép* |
| 4 | Thủ tục công ty: thư viện 11 quy trình (bản **chuẩn hóa cho công ty** + bản **tham khảo** từ các phương pháp quản trị phổ biến SMART, RACI, PDCA, 5W2H, DRI); **tin vắn nhắc quy trình theo bộ phận** theo chu kỳ; **sơ đồ tổ chức** dạng cây; tình trạng nhân sự tuần nằm trong *Hệ thống nhân sự*; **sơ đồ đường đi quy trình giao việc**; hướng dẫn giao việc | `hr.controller.ts` (tin vắn mỗi ngày làm việc sau 8:30, tối đa 1 tin/người/ngày), `HrHub.tsx`, `OrgChart.tsx`, `Procedures.tsx`, `AssignFlow.tsx`, `AssignGuide.tsx` |
| 5 | Biểu tượng chuyên nghiệp (Lucide), font Be Vietnam Pro, thẻ chào, ô chức năng có biểu tượng màu, menu dạng danh sách | `icons.tsx`, `styles.css` |
| 6 | Script triển khai cho `viecden.nhavanmon.com.vn` | `deploy/install.sh`, workflow mặc định `API_URL` |

## Tính năng bổ sung v2 (Việc Đến)

| # | Tính năng | Hiện thực |
|---|---|---|
| 1 | Đăng nhập/đăng ký bằng SĐT, tên hiển thị là họ tên đầy đủ; thêm thành viên bằng SĐT; ảnh đại diện quét gương mặt; hồ sơ xin việc (thông tin cá nhân, kinh nghiệm, lịch sử làm việc) + phần **app tự cập nhật** (việc hoàn thành, đúng hạn, điểm nghiệm thu, điểm hiệu suất đã chốt, tăng ca, nghỉ phép…) | `auth.controller.ts`, `profile.controller.ts`, `FaceCapture.tsx`, `ProfilePage.tsx`, `PersonProfile.tsx`. SĐT chưa có tài khoản được tạo ở trạng thái “chờ kích hoạt”; người đó **Đăng ký bằng đúng SĐT** để vào thẳng công ty. Lịch sử tự động ở doanh nghiệp cũ chỉ hiện cho nhà tuyển dụng khi người lao động bật đồng ý chia sẻ |
| 2 | Chủ doanh nghiệp nâng cấp: gói Nhỏ/Vừa/Lớn (hạn mức 20/100/500 thành viên), tên công ty, email liên hệ; phân vai trò; Quản lý thêm thành viên bằng SĐT → **Quản lý nhân sự kiểm duyệt** | `subscriptions.controller.ts`, `plans.ts`, `company.controller.ts` (`POST /company/members`, `/members/:id/hr-review`), vai trò mới `hr` |
| 3 | Lịch tuần/tháng ở đầu Trang chủ, nút mở rộng/thu nhỏ, danh sách việc trong ngày; việc chưa xác nhận hoàn thành **tự chuyển sang ngày hôm sau** | `calendar.controller.ts`, `Calendar.tsx`, `tasks.plan_date` + scheduler |
| 4 | “Việc của tôi”/“Cần tôi xử lý” chỉ hiện mục có số liệu và tài khoản có quyền thao tác | `Home.tsx` |
| 5 | Logo và tên app **Việc Đến** | `mobile-web/public/*`, `mobile-web/resources/android/res` (sinh bằng `scripts/gen-icons.py`), `capacitor.config.json` |
| 6 | Giao việc qua gọi điện/tin nhắn: nút Gọi/SMS/Zalo trong app, quay lại app sau cuộc gọi → gợi ý khai việc điền sẵn; **link khai việc** gửi kèm tin nhắn mở mẫu đã điền sẵn; ghi âm; ai khai trước thì người kia chỉ cần xác nhận (chống khai trùng) → tạo nhiệm vụ chính thức | `quick-claims.controller.ts`, `QuickClaimForm.tsx`, `ContactReturnPrompt.tsx`, `AudioRecorder.tsx`, route `/q?c=…` |
| 7 | Đánh dấu & **ghim việc gấp** lên đầu danh sách; quản lý đổi trạng thái/gỡ ghim; nhân viên nhận thông báo | `POST /tasks/:id/pin` |
| 8 | Xin nghỉ đột xuất/theo giờ/theo ca/theo ngày, báo trước (cảnh báo nếu ít hơn quy định); quản lý duyệt → **xuất đơn PDF, gửi tự động sang Nhân sự** (thông báo trong app + email nếu cấu hình SMTP); tình trạng nhân viên trong tuần; bước chọn nhân viên khi giao việc hiển thị trạng thái (nghỉ phép, khối lượng, quá hạn) | `leaves.controller.ts`, `team/availability`, `TeamWeek.tsx`, `TaskForm.tsx` (2 bước) |

**Biến môi trường mới**

| Biến | Ý nghĩa |
|---|---|
| `PLAN_ACTIVATION` | `auto` (mặc định, dùng thử — kích hoạt gói ngay) hoặc `manual` (chờ quản trị nền tảng xác nhận thanh toán) |
| `PAYMENT_INSTRUCTIONS` | Nội dung hướng dẫn chuyển khoản hiện cho chủ doanh nghiệp |
| `PLAN_SMALL_LIMIT`, `PLAN_SMALL_PRICE`, … `PLAN_LARGE_PRICE` | Hạn mức & giá gói (giá mặc định chỉ là giá minh họa) |
| `SMTP_URL`, `SMTP_FROM` | Gửi email đơn nghỉ (kèm PDF) cho nhân sự. Không cấu hình thì chỉ gửi thông báo trong app |

**Giới hạn cần biết của v2**

- **Không có OTP SMS**: đăng ký chỉ cần SĐT + mật khẩu, nên ai biết một SĐT “chờ kích hoạt” có thể đăng ký trước chủ số. Cần tích hợp nhà cung cấp OTP (ví dụ eSMS, Stringee, Firebase Phone Auth) trước khi dùng thật.
- **Thanh toán gói chưa tích hợp cổng thanh toán**: chế độ `auto` kích hoạt ngay; chế độ `manual` cần quản trị nền tảng bấm xác nhận sau khi nhận chuyển khoản.
- **Ghi âm cuộc gọi & lịch sử cuộc gọi**: Android/iOS không cho ứng dụng thường tự ghi âm cuộc gọi hay đọc nhật ký cuộc gọi. App thay bằng: gọi/nhắn từ trong app rồi gợi ý khai việc khi quay lại, link khai việc trong tin nhắn, ghi âm bằng micro (loa ngoài/trao đổi trực tiếp) hoặc đính kèm file ghi âm có sẵn của máy.
- **Quét gương mặt**: chụp trực tiếp từ camera trước với khung gương mặt; nếu trình duyệt hỗ trợ FaceDetector thì kiểm tra có gương mặt. Đây **không phải** xác thực sinh trắc học/chống giả mạo.
- Thời gian hiển thị theo múi giờ của điện thoại; lịch & SLA tính theo múi giờ công ty.

## Đối chiếu đặc tả → hiện thực

| Mục | Nội dung | Hiện thực |
|---|---|---|
| 2 | 6 vai trò, phân quyền công ty ≠ vai trò trong nhóm | `company_members.role` + `groups.manager_member_id`; kiểm tra quyền server-side mọi endpoint; cách ly `company_id` |
| 3.1 | Điều hướng Trang chủ / Công việc / Nhóm / Đánh giá / Cá nhân, chuông thông báo | `mobile-web/src/App.tsx` |
| 4 | Nhiệm vụ: đầu vào/đầu ra, độ khó, mức yêu cầu, thời lượng, deadline, 6 trạng thái, quá hạn là cờ tính toán | `tasks.controller.ts`; tiêu chí lưu **phiên bản** (`task_criteria.version`); đổi phạm vi/deadline sau khi bắt đầu **bắt buộc lý do** + audit |
| 4.3 | Khung thời lượng; deadline theo giờ làm việc | Gợi ý deadline `GET /company/calendar/suggest-due` theo lịch công ty |
| 5 | Việc đột xuất (4 loại), yêu cầu chung/đa dạng, yêu cầu con có phiên bản, bộ tiêu chí 35/20/20/15/10 riêng | `unexpected_tasks`, `task_subitems`; điểm tách riêng trong báo cáo |
| 6 | Tăng ca: 5 loại, ghi nhận cả khi chưa duyệt, không xóa, không tính lương, không cộng điểm | `overtime.controller.ts` |
| 7 | Tự khai báo; xác nhận / một phần / từ chối / yêu cầu bổ sung; tranh chấp; **khiếu nại từ lần từ chối thứ 4**; khiếu nại sớm; cấp giải quyết cao hơn người bị khiếu nại; quá SLA → chuyển cấp, không coi im lặng là đồng ý | `work-records.controller.ts`; lịch sử quyết định **bất biến** (trigger DB) |
| 8 | Báo cáo trở ngại: 6 nhóm, 4 mức, luồng 6 bước, 10 trạng thái, SLA 8.4, chuyển cấp, kênh độc lập, cảnh báo an toàn | `workplace-reports.controller.ts` + scheduler |
| 9 | Điểm nhiệm vụ 40/30/20/10; W = hệ số phức tạp × yêu cầu; P = ΣC/ΣW; E = 0.25V+0.20T+0.30Q+0.15D+0.10R | `performance.service.ts` (`scoreMembers` là hàm thuần, có unit test) |
| 10 | Báo cáo tháng/quý/năm theo cá nhân/nhóm/công ty, điểm nghẽn, so sánh kỳ trước, **snapshot** giữ nguyên khi công thức đổi, xuất PDF/Excel | `performance.controller.ts` |
| 11 | Thông báo có liên kết đúng bản ghi, chống gửi trùng (dedupe), lưu trạng thái gửi | `common/notify.ts`, bảng `notifications` |
| 12 | Mô hình dữ liệu (UUID, `company_id`, UTC, soft delete nhóm, bản ghi bất biến) | `backend/src/db/schema.sql` |
| 13 | REST API `/api/v1`, mã lỗi nghiệp vụ ổn định, phân trang/lọc, giới hạn upload, idempotency | Header `Idempotency-Key` cho mọi POST; lỗi dạng `{error:{code,message}}` |
| 14.2 | RBAC, audit, khóa tài khoản & thu hồi phiên, quyền xem tệp theo đối tượng | `audit_logs`, refresh token xoay vòng, khóa sau 10 lần sai mật khẩu |
| 16 / 16.1 | Tiêu chí nghiệm thu & tình huống biên | `backend/test/e2e.test.ts` |

### Giá trị mặc định đã áp dụng cho các quyết định mục 18 (đều cấu hình được trong *Cá nhân → Cấu hình*)

D01 nhân viên được tham gia nhiều nhóm · D02 xem toàn bộ nhiệm vụ nhóm mình · D03 giao chéo nhóm chỉ khi được cấp quyền (theo từng người) · D04 khiếu nại từ lần từ chối thứ 4 · D05 hạn xác nhận 1 ngày làm việc (480 phút) · D06 lịch T2–T6, 08:00–17:00, nghỉ trưa 12–13, ngày lễ cấu hình · D07 tuyến: cấp trên trực tiếp → … → Admin → Owner → reviewer độc lập · D08 SLA theo bảng 8.4 · D09 trọng số đề xuất, mỗi lần đổi tạo phiên bản mới · D10 điểm chỉ tham khảo · D11 không tính lương tăng ca · D12 PDF + Excel.

### Diễn giải công thức (cần chủ sản phẩm xác nhận khi chạy pilot)

Tài liệu nêu thành phần nhưng chưa định nghĩa chi tiết cách đo; bản MVP dùng cách sau:

- **Ghi nhận khi có cộng tác viên:** người chịu trách nhiệm nhận 60% trọng số nhiệm vụ, cộng tác viên chia đều 40% (tổng không vượt 100% — không nhân đôi điểm).
- **V** = khối lượng có trọng số, chuẩn hóa về 0–100 so với người cao nhất **cùng vai trò** trong công ty trong kỳ.
- **T** = tỷ lệ đúng hạn theo lần bàn giao đầu tiên; việc trễ có trở ngại **đã được quản lý xác nhận** thì không tính.
- **Q** = 0.7 × điểm nghiệm thu bình quân có trọng số + 0.3 × tỷ lệ đạt lần đầu.
- **D** = hệ số W bình quân, quy đổi tuyến tính về 0–100.
- **R** = điểm “quá trình/cập nhật/phối hợp” do người nghiệm thu chấm.
- Thành phần thiếu dữ liệu được bỏ qua và chia lại trọng số; báo cáo gắn nhãn “chưa đủ dữ liệu”.
- Bản ghi tự khai báo được chấp nhận được thống kê (số lượng, giờ) nhưng **chưa** cộng vào điểm.

## Khác biệt so với đề xuất kỹ thuật (mục 14) — cần lưu ý

- **Mobile: PWA React thay vì Flutter.** Môi trường xây dựng không có Flutter/Android SDK để build và kiểm thử. PWA chạy trên trình duyệt di động và cài được lên màn hình chính; toàn bộ nghiệp vụ nằm ở API nên app Flutter có thể làm sau trên cùng API mà không đổi backend.
- **Push notification (FCM):** đã có bản ghi thông báo in-app, chống trùng và cột `push_status`; **chưa** gửi FCM thật (cần khóa Firebase + worker gửi).
- **Lưu tệp:** driver lưu đĩa cục bộ (`UPLOAD_DIR`) sau một lớp trừu tượng; chưa có driver S3.
- **Background jobs:** dùng scheduler trong tiến trình thay vì BullMQ/Redis. An toàn khi chạy nhiều instance (khóa `SKIP LOCKED`, khóa duy nhất cho chuyển cấp, dedupe thông báo); nếu tách worker, đặt `DISABLE_SCHEDULER=true` trên các instance API.
- **Đăng nhập:** email + mật khẩu (JWT 30 phút + refresh token xoay vòng). Admin mời thành viên và nhận mật khẩu tạm thời; chưa gửi email mời.
- Docker/Docker Compose đã viết nhưng **chưa build thử** trong môi trường này; cách chạy bằng Node + PostgreSQL ở trên đã được kiểm chứng.

## Cấu trúc mã

```
backend/src
  common/        auth guard, RBAC/tuyến cấp trên, lịch làm việc, audit, thông báo, idempotency, lỗi
  db/            schema.sql, migrate, seed (seed chạy qua chính REST API)
  modules/       auth, company (cấu hình), groups, tasks, overtime, work-records, workplace-reports,
                 escalation(s), performance (tính điểm + báo cáo + xuất), notifications, files, dashboard, scheduler
mobile-web/src
  api.ts         gọi API, tự làm mới token, Idempotency-Key, retry khi mất mạng
  pages/         Trang chủ theo vai trò, Công việc (nhiệm vụ/tự khai báo/tăng ca/trở ngại), Nhóm,
                 Đánh giá & báo cáo, Cá nhân, Bảng kỹ thuật, Chuyển cấp, Quản trị thành viên & cấu hình
```

## Build trên GitHub Actions

File workflow: `.github/workflows/build.yml`. Đẩy mã lên GitHub (nhánh `main`/`master`) hoặc vào tab **Actions → Build → Run workflow**. Có 3 job:

1. **test** — chạy 30 test backend trên PostgreSQL 16 (service container).
2. **server** — build backend + PWA, tải về ở artifact `server-bundle` (xem `START.txt` bên trong).
3. **android** — đóng gói PWA thành app Android bằng Capacitor, ra file APK debug ở artifact `android-apk`.

App Android cần biết địa chỉ API: nhập `api_url` khi chạy tay, hoặc tạo biến repo `API_URL` (Settings → Secrets and variables → Actions → Variables), ví dụ `https://api.congty.vn/api/v1`. Mặc định `http://10.0.2.2:3000/api/v1` (chỉ dùng cho máy ảo Android trỏ về máy chạy server).

Hạn chế của bản APK: là bản debug (chưa ký phát hành); nút xuất PDF/Excel trong WebView Android có thể không tải được tệp — dùng bản web để xuất báo cáo.
