import { Body, Controller, Get, Param, Patch, Post } from '@nestjs/common';
import { getPool, q, q1 } from '../db/db';
import { CurrentCtx, Ctx, isHR } from '../common/context';
import { Errors } from '../common/errors';
import { parse, z } from '../common/validate';
import { audit } from '../common/audit';

const norm = (s: string) => (s || '').toLowerCase().normalize('NFC');

/** Gợi ý việc trong/ngoài vai trò dựa trên mô tả công việc của vai trò (từ khóa + nhiệm vụ). null = chưa gán vai trò. */
export async function suggestInRole(db: any, memberId: string, text: string): Promise<boolean | null> {
  const r = await q1(`SELECT jr.duties, jr.keywords FROM company_members cm JOIN job_roles jr ON jr.id=cm.job_role_id WHERE cm.id=$1 AND jr.active`, [memberId], db);
  if (!r) return null;
  const t = norm(text);
  const kws: string[] = [...(r.keywords || []), ...((r.duties || []) as string[]).flatMap((d) => norm(d).split(/[,;]/).map((x) => x.trim()).filter((x) => x.length >= 6))];
  return kws.some((k) => k && t.includes(norm(k)));
}

const BODY = z.object({
  name: z.string().trim().min(2), description: z.string().trim().optional().nullable(),
  duties: z.array(z.string().trim().min(2)).default([]), keywords: z.array(z.string().trim().min(2)).default([]), active: z.boolean().optional(),
});

@Controller('company/job-roles')
export class JobRolesController {
  @Get()
  async list(@CurrentCtx() ctx: Ctx) {
    return q(`SELECT jr.*, (SELECT count(*) FROM company_members cm WHERE cm.job_role_id=jr.id AND cm.status='active')::int AS member_count
               FROM job_roles jr WHERE jr.company_id=$1 ORDER BY jr.active DESC, jr.name`, [ctx.companyId]);
  }

  @Post()
  async create(@Body() body: any, @CurrentCtx() ctx: Ctx) {
    if (!isHR(ctx)) throw Errors.forbidden();
    const b = parse(BODY, body);
    const r = await q1(`INSERT INTO job_roles(company_id, name, description, duties, keywords) VALUES ($1,$2,$3,$4,$5) RETURNING *`,
      [ctx.companyId, b.name, b.description ?? null, JSON.stringify(b.duties), JSON.stringify(b.keywords)]);
    await audit(getPool(), ctx, 'job_role', r.id, 'job_role.created');
    return r;
  }

  @Patch(':id')
  async update(@Param('id') id: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    if (!isHR(ctx)) throw Errors.forbidden();
    const b = parse(BODY.partial(), body);
    const r = await q1(`UPDATE job_roles SET name=COALESCE($3,name), description=CASE WHEN $4::boolean THEN $5 ELSE description END,
                          duties=COALESCE($6,duties), keywords=COALESCE($7,keywords), active=COALESCE($8,active), updated_at=now()
                        WHERE id=$1 AND company_id=$2 RETURNING *`,
      [id, ctx.companyId, b.name ?? null, 'description' in b, b.description ?? null, b.duties ? JSON.stringify(b.duties) : null,
       b.keywords ? JSON.stringify(b.keywords) : null, b.active ?? null]);
    if (!r) throw Errors.notFound('Vai trò');
    await audit(getPool(), ctx, 'job_role', id, 'job_role.updated');
    return r;
  }
}
