import { Injectable, Logger } from '@nestjs/common';
import { Cron, CronExpression } from '@nestjs/schedule';
import { runRetention } from './privacy.controller';
import { runCommsRetention } from './comms.controller';
import { runRoomsRetention } from './rooms.controller';
import { runDiagRetention } from './join.controller';
import { runQrHousekeeping } from './qr.controller';
import { runRiskScan, runScheduledStarts } from './operations.controller';
import { DateTime } from 'luxon';
import { getPool, q, q1, tx } from '../db/db';
import { getCompany, companyAdmins } from '../common/access';
import { notify } from '../common/notify';
import { addWorkingMinutes, slaDue, workingMinutesBetween } from '../common/calendar';
import { escalate } from './escalation';
import { sendProcedureTips } from './hr.controller';

/**
 * Background job: nhắc hạn, SLA, tự động chuyển cấp. Chạy mỗi phút; mỗi hồ sơ xử lý trong transaction riêng
 * với khóa SKIP LOCKED (an toàn khi nhiều instance), idempotent nhờ unique key chuyển cấp + dedupe thông báo;
 * lỗi từng hồ sơ được log và tự retry ở lượt chạy sau.
 */
@Injectable()
export class SchedulerService {
  private log = new Logger('Scheduler');
  private running = false;

  @Cron(CronExpression.EVERY_MINUTE)
  async tick() {
    if (process.env.DISABLE_SCHEDULER === 'true' || this.running) return;
    this.running = true;
    try {
      const r = await runSchedulerOnce(new Date());
      if (r.escalations || r.reminders) this.log.log(`escalations=${r.escalations} reminders=${r.reminders} errors=${r.errors}`);
    } catch (e: any) {
      this.log.error(e?.message || e);
    } finally {
      this.running = false;
    }
  }

  /** Chính sách lưu trữ: xóa thông báo cũ, ghi âm hết hạn, tệp xuất dữ liệu, nhật ký truy cập quá hạn (SEC-01 mục 11). */
  @Cron(CronExpression.EVERY_HOUR)
  async retention() {
    if (process.env.DISABLE_SCHEDULER === 'true') return;
    try { const r = await runRetention(); this.log.log(`retention ${JSON.stringify(r)}`); } catch (e: any) { this.log.error(e?.message || e); }
    try { const r = await runQrHousekeeping(); if (r.area_sessions_expired || r.handover_qr_expired) this.log.log(`qr ${JSON.stringify(r)}`); } catch (e: any) { this.log.error(e?.message || e); }
    try { const r = await runCommsRetention(); this.log.log(`comms retention ${JSON.stringify(r)}`); } catch (e: any) { this.log.error(e?.message || e); }
    try { const r = { ...(await runRoomsRetention()), ...(await runDiagRetention()) }; this.log.log(`rooms/diag retention ${JSON.stringify(r)}`); } catch (e: any) { this.log.error(e?.message || e); }
  }
}

export async function runSchedulerOnce(now: Date) {
  const stats = { escalations: 0, reminders: 0, errors: 0, carried: 0 };
  const safe = async (fn: () => Promise<void>) => {
    try { await fn(); } catch (e: any) { stats.errors++; new Logger('Scheduler').error(e?.message || e); }
  };
  const companies = await q(`SELECT id FROM companies`);
  for (const { id: companyId } of companies) {
    const company = await getCompany(companyId);
    const { calendar, policies } = company.settings;
    const tz = company.timezone;

    // v6: cảnh báo rủi ro chuỗi/công đoạn theo quy tắc; tự đóng phiên quên kết thúc (thời gian sau đó ghi "chưa xác định", không quy lỗi)
    await safe(async () => { await runRiskScan(companyId); });
    await safe(async () => { await runScheduledStarts(companyId); });
    await safe(async () => {
      const hrs = company.settings.workTime.autoCloseSessionHours;
      const stale = await q(`UPDATE work_sessions SET ended_at=started_at + ($2 || ' hours')::interval, end_reason='auto' WHERE company_id=$1 AND ended_at IS NULL
                              AND started_at < $3::timestamptz - ($2 || ' hours')::interval RETURNING member_id, task_id, ended_at`, [companyId, String(hrs), now]);
      for (const s of stale) {
        await q(`INSERT INTO work_time_records(company_id, member_id, task_id, category, reason, started_at, ended_at) VALUES ($1,$2,$3,'unknown','Phiên tự đóng do quá thời gian — cần trưởng nhóm đối chiếu',$4,$5)
                 ON CONFLICT DO NOTHING`, [companyId, s.member_id, s.task_id, s.ended_at, now]);
      }
    });

    // 0) Việc chưa xác nhận hoàn thành: hết ngày tự động chuyển sang danh sách ngày hôm sau
    await safe(async () => {
      const today = DateTime.fromJSDate(now, { zone: tz }).toISODate();
      const moved = await q(
        `UPDATE tasks SET plan_date=$2::date, carry_count=carry_count+1
          WHERE company_id=$1 AND plan_date < $2::date AND status IN ('not_started','in_progress','pending_review','revision_requested') RETURNING id`,
        [companyId, today]);
      stats.carried += moved.length;
    });

    // 0b) Khai việc nhanh chờ xác nhận quá 4 giờ: nhắc người cần xác nhận (một lần/ngày)
    await safe(async () => {
      const pend = await q(`SELECT id, counterpart_id, title FROM quick_claims WHERE company_id=$1 AND status='pending' AND created_at < $2::timestamptz - interval '4 hours'`, [companyId, now]);
      for (const p of pend) {
        stats.reminders += await notify(getPool(), { companyId, memberIds: [p.counterpart_id], type: 'quick_claim.reminder',
          title: `Nhắc: xác nhận khai việc "${p.title}"`, refType: 'quick_claim', refId: p.id, dedupeKey: `qc-remind-${p.id}-${now.toISOString().slice(0, 10)}` });
      }
    });

    // 0c) Tin vắn quy trình theo bộ phận
    await safe(async () => { stats.reminders += await sendProcedureTips(companyId, now); });

    // 1) Nhiệm vụ sắp đến hạn / quá hạn
    const soon = new Date(now.getTime() + policies.taskDueSoonMinutes * 60000);
    const tasks = await q(
      `SELECT t.id, t.title, t.due_at, t.group_id, g.manager_member_id, o.company_member_id AS owner_id
         FROM tasks t JOIN groups g ON g.id=t.group_id
         LEFT JOIN task_assignees o ON o.task_id=t.id AND o.assignment_type='owner' AND o.active
        WHERE t.company_id=$1 AND t.status IN ('not_started','in_progress','revision_requested') AND t.due_at < $2`, [companyId, soon]);
    for (const t of tasks) {
      await safe(async () => {
        const overdue = new Date(t.due_at) < now;
        const key = `${overdue ? 'task-overdue' : 'task-due-soon'}-${t.id}-${new Date(t.due_at).getTime()}`;
        stats.reminders += await notify(getPool(), {
          companyId, memberIds: overdue ? [t.owner_id, t.manager_member_id] : [t.owner_id], type: overdue ? 'task.overdue' : 'task.due_soon',
          title: overdue ? `Nhiệm vụ quá hạn: ${t.title}` : `Nhiệm vụ sắp đến hạn: ${t.title}`, refType: 'task', refId: t.id, dedupeKey: key,
        });
      });
    }

    // 2) Bản ghi công việc tự khai báo: quản lý bắt buộc phản hồi trong SLA
    const records = await q(
      `SELECT id FROM employee_work_records WHERE company_id=$1 AND status IN ('submitted','disputed') AND review_due_at IS NOT NULL`, [companyId]);
    for (const { id } of records) {
      await safe(() => tx(async (c) => {
        const r = await q1(`SELECT * FROM employee_work_records WHERE id=$1 AND status IN ('submitted','disputed') FOR UPDATE SKIP LOCKED`, [id], c);
        if (!r || !r.review_due_at) return;
        const due = new Date(r.review_due_at);
        if (due > now) {
          const left = workingMinutesBetween(now, due, calendar, tz);
          if (left <= policies.workRecordReviewMinutes * policies.reminderRatio) {
            const holders = r.escalation_level > 0
              ? (await q(`SELECT to_member_id FROM escalations WHERE parent_type='work_record' AND parent_id=$1 AND status='open'`, [id], c)).map((x) => x.to_member_id)
              : [r.reviewer_member_id];
            stats.reminders += await notify(c, { companyId, memberIds: holders, type: 'work_record.reminder',
              title: `Sắp hết hạn xác nhận bản ghi công việc: ${r.title}`, refType: 'work_record', refId: id,
              dedupeKey: `wr-remind-${id}-${r.sla_cycle}-${r.escalation_level}` });
          }
          return;
        }
        // Quá SLA: không coi im lặng là đồng ý/từ chối -> đánh dấu Overdue và chuyển cấp
        const level = r.escalation_level + 1;
        const newDue = addWorkingMinutes(now, policies.workRecordReviewMinutes, calendar, tz);
        const prevHolder = r.escalation_level > 0
          ? (await q1(`SELECT to_member_id FROM escalations WHERE parent_type='work_record' AND parent_id=$1 AND stage='review' AND cycle=$2 AND level=$3`,
              [id, r.sla_cycle, r.escalation_level], c))?.to_member_id ?? r.reviewer_member_id
          : r.reviewer_member_id;
        const e = await escalate(c, {
          companyId, parentType: 'work_record', parentId: id, stage: 'review', cycle: r.sla_cycle, level,
          fromMemberId: prevHolder, baseMemberId: r.reviewer_member_id, reason: 'Quá hạn xác nhận bản ghi công việc (SLA phản hồi của quản lý)',
          newDueAt: newDue, exclude: [r.employee_id], title: `Chuyển cấp: bản ghi công việc quá hạn xác nhận — ${r.title}`, notifyAlso: [r.employee_id, prevHolder],
        });
        if (e) {
          stats.escalations++;
          await q(`UPDATE employee_work_records SET overdue=true, escalation_level=$2, review_due_at=$3, updated_at=now() WHERE id=$1`, [id, level, newDue], c);
        } else {
          // hết tuyến: giữ cờ quá hạn, nhắc Admin/Owner mỗi ngày (dedupe theo ngày)
          await q(`UPDATE employee_work_records SET overdue=true WHERE id=$1`, [id], c);
          stats.reminders += await notify(c, { companyId, memberIds: await companyAdmins(companyId, c), type: 'work_record.overdue_top',
            title: `Bản ghi công việc quá hạn ở cấp cao nhất: ${r.title}`, refType: 'work_record', refId: id,
            dedupeKey: `wr-top-${id}-${now.toISOString().slice(0, 10)}` });
        }
      }));
    }

    // 3) Báo cáo trở ngại: SLA tiếp nhận / chuyển / xử lý
    const reports = await q(
      `SELECT id FROM workplace_reports WHERE company_id=$1 AND stage IN ('manager_review','department_ack','resolution') AND stage_due_at IS NOT NULL`, [companyId]);
    for (const { id } of reports) {
      await safe(() => tx(async (c) => {
        const w = await q1(`SELECT * FROM workplace_reports WHERE id=$1 FOR UPDATE SKIP LOCKED`, [id], c);
        if (!w || !w.stage_due_at || !['manager_review', 'department_ack', 'resolution'].includes(w.stage)) return;
        const due = new Date(w.stage_due_at);
        const window = w.stage_window_minutes || 60;
        const stageLabel: Record<string, string> = { manager_review: 'tiếp nhận/chuyển', department_ack: 'xác nhận tiếp nhận', resolution: 'xử lý' };
        if (due > now) {
          const left = w.severity === 'critical' ? (due.getTime() - now.getTime()) / 60000 : workingMinutesBetween(now, due, calendar, tz);
          if (left <= window * policies.reminderRatio) {
            stats.reminders += await notify(c, { companyId, memberIds: [w.current_holder_id], type: 'report.sla_warning',
              title: `[${w.code}] SLA ${stageLabel[w.stage]} sắp hết hạn`, refType: 'workplace_report', refId: id,
              dedupeKey: `wp-remind-${id}-${w.sla_cycle}-${w.escalation_level}` });
          }
          return;
        }
        let base = w.current_holder_id;
        if (w.stage === 'manager_review') base = w.manager_member_id;
        if (w.stage === 'department_ack' && w.department_id) base = (await q1(`SELECT head_member_id FROM departments WHERE id=$1`, [w.department_id], c))?.head_member_id || base;
        if (w.stage === 'resolution') base = w.assignee_id || base;
        const level = w.escalation_level + 1;
        const newDue = slaDue(now, window, w.severity, calendar, tz);
        const prev = w.escalation_level > 0
          ? (await q1(`SELECT to_member_id FROM escalations WHERE parent_type='workplace_report' AND parent_id=$1 AND stage=$2 AND cycle=$3 AND level=$4`,
              [id, w.stage, w.sla_cycle, w.escalation_level], c))?.to_member_id ?? w.current_holder_id
          : w.current_holder_id;
        const e = await escalate(c, {
          companyId, parentType: 'workplace_report', parentId: id, stage: w.stage, cycle: w.sla_cycle, level,
          fromMemberId: prev, baseMemberId: base, reason: `Quá SLA ${stageLabel[w.stage]} (mức ${w.severity})`, newDueAt: newDue,
          exclude: [w.reporter_id], title: `[${w.code}] Chuyển cấp do quá SLA ${stageLabel[w.stage]}`, notifyAlso: [w.reporter_id, prev],
        });
        if (e) {
          stats.escalations++;
          await q(`UPDATE workplace_reports SET status='escalated', escalation_level=$2, stage_due_at=$3 WHERE id=$1`, [id, level, newDue], c);
          await q(`INSERT INTO report_updates(report_id, actor_id, status, comment, new_due_at) VALUES ($1,NULL,'escalated',$2,$3)`,
            [id, `Tự động chuyển cấp ${level}: quá SLA ${stageLabel[w.stage]}`, newDue], c);
        } else {
          stats.reminders += await notify(c, { companyId, memberIds: await companyAdmins(companyId, c), type: 'report.overdue_top',
            title: `[${w.code}] Quá SLA ở cấp cao nhất`, refType: 'workplace_report', refId: id, dedupeKey: `wp-top-${id}-${now.toISOString().slice(0, 10)}` });
        }
      }));
    }
  }
  return stats;
}
