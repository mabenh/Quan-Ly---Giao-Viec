import { Body, Controller, Get, Param, Patch, Post, Put, Query } from '@nestjs/common';
import { getPool, q, q1, tx } from '../db/db';
import { Roles } from '../common/auth.guard';
import { CurrentCtx, Ctx, isAdmin, isHR } from '../common/context';
import { normalizePhone } from '../common/phone';
import { notify } from '../common/notify';
import { AppError, Errors } from '../common/errors';
import { parse, z } from '../common/validate';
import { getCompany, getMember } from '../common/access';
import { audit } from '../common/audit';
import { DEFAULT_PERFORMANCE, DURATION_GUIDE, mergeSettings } from '../common/defaults';
import { addWorkingMinutes } from '../common/calendar';
import { IANAZone } from 'luxon';
import { relinkLibraryDepartments } from './library';

const ROLE = z.enum(['owner', 'admin', 'manager', 'employee', 'handler', 'reviewer', 'hr']);

@Controller('company')
export class CompanyController {
  @Get()
  async get(@CurrentCtx() ctx: Ctx) {
    const c = await getCompany(ctx.companyId);
    return { id: c.id, name: c.name, timezone: c.timezone, settings: c.settings };
  }

  @Patch('settings')
  @Roles('owner', 'admin')
  async updateSettings(@Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({
      name: z.string().min(2).optional(),
      timezone: z.string().refine((v) => IANAZone.isValidZone(v), 'Múi giờ không hợp lệ (vd Asia/Ho_Chi_Minh)').optional(),
      calendar: z.object({
        workdays: z.array(z.number().int().min(1).max(7)).min(1),
        start: z.string().regex(/^\d\d:\d\d$/), end: z.string().regex(/^\d\d:\d\d$/),
        breakStart: z.string().regex(/^\d\d:\d\d$/).optional().nullable(), breakEnd: z.string().regex(/^\d\d:\d\d$/).optional().nullable(),
        holidays: z.array(z.string().regex(/^\d{4}-\d\d-\d\d$/)),
      }).partial().optional(),
      policies: z.object({
        multiGroup: z.boolean(), employeeTaskVisibility: z.enum(['group', 'related']),
        appealThreshold: z.number().int().min(1).max(20), workRecordReviewMinutes: z.number().int().min(30),
        overtimeReviewMinutes: z.number().int().min(30), taskDueSoonMinutes: z.number().int().min(15),
        reminderRatio: z.number().min(0.05).max(0.9), resetChainOnAccept: z.boolean(), lunchBreakLimitMinutes: z.number().int().min(0),
      }).partial().optional(),
    }), body);
    const c = await getCompany(ctx.companyId);
    const next = mergeSettings({
      calendar: { ...c.settings.calendar, ...(b.calendar || {}) },
      policies: { ...c.settings.policies, ...(b.policies || {}) },
    });
    await q(`UPDATE companies SET settings=$2, name=COALESCE($3,name), timezone=COALESCE($4,timezone) WHERE id=$1`,
      [ctx.companyId, JSON.stringify(next), b.name ?? null, b.timezone ?? null]);
    await audit(getPool(), ctx, 'company', ctx.companyId, 'settings.updated', c.settings, next);
    return this.get(ctx);
  }

  // ---------- Thành viên ----------
  @Get('members')
  async members(@CurrentCtx() ctx: Ctx, @Query('q') search?: string, @Query('role') role?: string, @Query('status') status?: string) {
    return q(
      `SELECT cm.id, cm.user_id, cm.role, cm.title, cm.status, cm.department_id, d.name AS department_name, cm.supervisor_member_id,
              su.name AS supervisor_name, cm.can_cross_group_assign, u.name, u.email, u.phone, u.status AS user_status, cm.joined_at,
              au.name AS added_by_name, cm.hr_note, EXISTS (SELECT 1 FROM user_avatars a WHERE a.user_id=u.id) AS has_avatar
         FROM company_members cm JOIN users u ON u.id=cm.user_id
         LEFT JOIN departments d ON d.id=cm.department_id
         LEFT JOIN company_members scm ON scm.id=cm.supervisor_member_id LEFT JOIN users su ON su.id=scm.user_id
         LEFT JOIN company_members acm ON acm.id=cm.added_by LEFT JOIN users au ON au.id=acm.user_id
        WHERE cm.company_id=$1 AND ($2::text IS NULL OR u.name ILIKE '%'||$2||'%' OR u.email ILIKE '%'||$2||'%' OR u.phone LIKE '%'||$2||'%')
          AND ($3::text IS NULL OR cm.role=$3)
          AND (CASE WHEN $4::text IS NULL THEN cm.status IN ('active','inactive','pending_hr') ELSE cm.status=$4 END)
        ORDER BY (cm.status='pending_hr') DESC, u.name`, [ctx.companyId, search || null, role || null, status || null]);
  }

  /**
   * Thêm thành viên bằng SĐT. Owner/Admin/HR thêm trực tiếp (kích hoạt ngay); Quản lý thêm thì chờ HR kiểm duyệt.
   * Nếu SĐT chưa có tài khoản, hệ thống tạo tài khoản "chờ kích hoạt": người đó tải app và Đăng ký bằng đúng SĐT này.
   */
  @Post('members')
  @Roles('owner', 'admin', 'hr', 'manager')
  async invite(@Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({
      phone: z.string().min(9, 'Nhập số điện thoại'), name: z.string().trim().min(4, 'Nhập họ và tên đầy đủ').optional(),
      role: ROLE.default('employee'), title: z.string().optional(), departmentId: z.string().uuid().optional().nullable(),
      supervisorMemberId: z.string().uuid().optional().nullable(), canCrossGroupAssign: z.boolean().optional(),
      groupId: z.string().uuid().optional(), note: z.string().optional(),
    }), body);
    const phone = normalizePhone(b.phone);
    const direct = isHR(ctx);
    if (!direct && b.role !== 'employee') throw Errors.forbidden('Quản lý chỉ được thêm thành viên vai trò Nhân viên');
    if (b.role === 'owner' && ctx.role !== 'owner') throw Errors.forbidden('Chỉ Owner mới có thể thêm Owner');
    if (b.role !== 'employee' && !isAdmin(ctx)) throw Errors.forbidden('Chỉ Owner/Admin được phân vai trò quản lý');
    if (b.supervisorMemberId) await getMember(ctx, b.supervisorMemberId);
    if (b.departmentId) await this.dept(ctx, b.departmentId);
    const company = await getCompany(ctx.companyId);
    if (!company.plan) throw new AppError('PLAN_REQUIRED', 'Doanh nghiệp chưa có gói. Chủ doanh nghiệp cần nâng cấp tài khoản.', 402);
    if (b.groupId) {
      const g = await q1(`SELECT manager_member_id FROM groups WHERE id=$1 AND company_id=$2 AND deleted_at IS NULL`, [b.groupId, ctx.companyId]);
      if (!g) throw Errors.notFound('Nhóm');
      if (!isAdmin(ctx) && g.manager_member_id !== ctx.memberId && ctx.role !== 'hr') throw Errors.forbidden('Bạn không quản lý nhóm này');
    }
    return tx(async (c) => {
      await c.query(`SELECT 1 FROM companies WHERE id=$1 FOR UPDATE`, [ctx.companyId]);
      if (company.member_limit) {
        const used = await q1(`SELECT count(*)::int AS n FROM company_members WHERE company_id=$1 AND status IN ('active','pending_hr')`, [ctx.companyId], c);
        if (used.n >= company.member_limit) throw new AppError('PLAN_LIMIT', `Đã đạt hạn mức ${company.member_limit} thành viên của gói. Chủ doanh nghiệp cần nâng cấp gói lớn hơn.`, 402);
      }
      let user = await q1(`SELECT id, name, status FROM users WHERE phone=$1`, [phone], c);
      let invited = false;
      if (!user) {
        if (!b.name) throw Errors.validation('SĐT chưa có tài khoản — nhập họ và tên đầy đủ của thành viên');
        user = await q1(`INSERT INTO users(name, phone, status) VALUES ($1,$2,'invited') RETURNING id, name, status`, [b.name, phone], c);
        invited = true;
      } else if (user.status === 'invited') invited = true;
      const status = direct ? 'active' : 'pending_hr';
      const dup = await q1(`SELECT id, status FROM company_members WHERE company_id=$1 AND user_id=$2`, [ctx.companyId, user.id], c);
      let id: string;
      if (dup) {
        if (['active', 'pending_hr'].includes(dup.status)) throw new AppError('ALREADY_MEMBER', dup.status === 'active' ? 'Người này đã là thành viên công ty' : 'Người này đang chờ nhân sự duyệt', 409);
        await q(`UPDATE company_members SET status=$2, role=$3, title=$4, department_id=$5, supervisor_member_id=$6, added_by=$7, left_at=NULL,
                   hr_reviewed_by=NULL, hr_reviewed_at=NULL, hr_note=$8 WHERE id=$1`,
          [dup.id, status, b.role, b.title ?? null, b.departmentId ?? null, b.supervisorMemberId ?? (direct ? null : ctx.memberId), ctx.memberId, b.note ?? null], c);
        id = dup.id;
      } else {
        const m = await q1(
          `INSERT INTO company_members(company_id,user_id,role,title,department_id,supervisor_member_id,can_cross_group_assign,status,added_by,hr_note)
           VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) RETURNING id`,
          [ctx.companyId, user.id, b.role, b.title ?? null, b.departmentId ?? null, b.supervisorMemberId ?? (direct ? null : ctx.memberId),
           !!b.canCrossGroupAssign, status, ctx.memberId, b.note ?? null], c);
        id = m.id;
      }
      if (b.groupId) await q(`INSERT INTO group_members(group_id, company_member_id) VALUES ($1,$2) ON CONFLICT DO NOTHING`, [b.groupId, id], c);
      await audit(c, ctx, 'member', id, direct ? 'member.added' : 'member.pending_hr', null, { role: b.role, phone, group: b.groupId });
      if (!direct) {
        const hrs = await q(`SELECT id FROM company_members WHERE company_id=$1 AND status='active' AND role IN ('hr','admin','owner')
                              ORDER BY array_position(ARRAY['hr','admin','owner'], role)`, [ctx.companyId], c);
        await notify(c, { companyId: ctx.companyId, memberIds: hrs.map((h) => h.id), excludeMemberId: ctx.memberId, type: 'member.pending_hr',
          title: `${ctx.name} đề nghị thêm thành viên ${user.name} (${phone})`, body: 'Cần nhân sự kiểm duyệt', refType: 'member', refId: id });
      } else {
        await notify(c, { companyId: ctx.companyId, memberIds: [id], type: 'member.added', title: `Bạn đã được thêm vào ${company.name}` });
      }
      return { id, status, invited, name: user.name, message: invited ? 'Thành viên cần tải app Việc Đến và Đăng ký bằng đúng SĐT này để kích hoạt.' : undefined };
    });
  }

  /** Nhân sự kiểm duyệt thành viên do Quản lý đề nghị. */
  @Post('members/:id/hr-review')
  @Roles('owner', 'admin', 'hr')
  async hrReview(@Param('id') id: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({ decision: z.enum(['approve', 'reject']), note: z.string().trim().optional() }), body);
    if (b.decision === 'reject' && (!b.note || b.note.length < 5)) throw Errors.reasonRequired('Từ chối phải nêu lý do');
    const m = await getMember(ctx, id);
    if (m.status !== 'pending_hr') throw Errors.invalidState('Thành viên không ở trạng thái chờ duyệt');
    await tx(async (c) => {
      await q(`UPDATE company_members SET status=$2, hr_reviewed_by=$3, hr_reviewed_at=now(), hr_note=COALESCE($4, hr_note), joined_at=CASE WHEN $2='active' THEN now() ELSE joined_at END WHERE id=$1`,
        [id, b.decision === 'approve' ? 'active' : 'rejected', ctx.memberId, b.note ?? null], c);
      if (b.decision === 'reject') await q(`DELETE FROM group_members WHERE company_member_id=$1`, [id], c);
      await audit(c, ctx, 'member', id, 'member.hr_' + b.decision, { status: 'pending_hr' }, null, b.note ?? null);
      await notify(c, { companyId: ctx.companyId, memberIds: [m.added_by], type: 'member.hr_' + b.decision,
        title: b.decision === 'approve' ? `Nhân sự đã duyệt thành viên ${m.name}` : `Nhân sự từ chối thành viên ${m.name}`, body: b.note, refType: 'member', refId: id });
      if (b.decision === 'approve') {
        const company = await getCompany(ctx.companyId, c);
        await notify(c, { companyId: ctx.companyId, memberIds: [id], type: 'member.added', title: `Bạn đã được thêm vào ${company.name}` });
      }
    });
    return { ok: true };
  }

  @Patch('members/:id')
  @Roles('owner', 'admin')
  async updateMember(@Param('id') id: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({
      role: ROLE.optional(), title: z.string().optional().nullable(), departmentId: z.string().uuid().nullable().optional(),
      supervisorMemberId: z.string().uuid().nullable().optional(), status: z.enum(['active', 'inactive']).optional(),
      canCrossGroupAssign: z.boolean().optional(), lockUser: z.boolean().optional(),
    }), body);
    const m = await getMember(ctx, id);
    if ((m.role === 'owner' || b.role === 'owner') && ctx.role !== 'owner') throw Errors.forbidden('Chỉ Owner mới đổi quyền Owner');
    if (b.supervisorMemberId === id) throw Errors.validation('Không thể tự làm cấp trên của chính mình');
    if (b.supervisorMemberId) {
      // chống vòng lặp tuyến cấp trên
      let cur: string | null = b.supervisorMemberId;
      for (let i = 0; i < 20 && cur; i++) {
        if (cur === id) throw Errors.validation('Tuyến cấp trên tạo thành vòng lặp');
        const r = await q1(`SELECT supervisor_member_id FROM company_members WHERE id=$1 AND company_id=$2`, [cur, ctx.companyId]);
        if (!r) throw Errors.notFound('Cấp trên');
        cur = r.supervisor_member_id;
      }
    }
    const upd = await q1(
      `UPDATE company_members SET role=COALESCE($3,role), title=CASE WHEN $4::boolean THEN $5 ELSE title END,
              department_id=CASE WHEN $6::boolean THEN $7::uuid ELSE department_id END,
              supervisor_member_id=CASE WHEN $8::boolean THEN $9::uuid ELSE supervisor_member_id END,
              status=COALESCE($10,status), can_cross_group_assign=COALESCE($11,can_cross_group_assign)
        WHERE id=$1 AND company_id=$2 RETURNING *`,
      [id, ctx.companyId, b.role ?? null, 'title' in b, b.title ?? null, 'departmentId' in b, b.departmentId ?? null,
       'supervisorMemberId' in b, b.supervisorMemberId ?? null, b.status ?? null, b.canCrossGroupAssign ?? null]);
    if (b.lockUser !== undefined) {
      await q(`UPDATE users SET status=$2, failed_logins=0 WHERE id=$1`, [m.user_id, b.lockUser ? 'locked' : 'active']);
      if (b.lockUser) await q(`UPDATE refresh_tokens SET revoked_at=now() WHERE user_id=$1 AND revoked_at IS NULL`, [m.user_id]);
    }
    await audit(getPool(), ctx, 'member', id, 'member.updated',
      { role: m.role, status: m.status, supervisor: m.supervisor_member_id }, { ...b });
    return upd;
  }

  // ---------- Bộ phận ----------
  private async dept(ctx: Ctx, id: string) {
    const d = await q1(`SELECT * FROM departments WHERE id=$1 AND company_id=$2`, [id, ctx.companyId]);
    if (!d) throw Errors.notFound('Bộ phận');
    return d;
  }

  @Get('departments')
  async departments(@CurrentCtx() ctx: Ctx) {
    return q(`SELECT d.*, u.name AS head_name,
                (SELECT count(*) FROM company_members m WHERE m.department_id=d.id AND m.status='active')::int AS member_count
               FROM departments d LEFT JOIN company_members cm ON cm.id=d.head_member_id LEFT JOIN users u ON u.id=cm.user_id
              WHERE d.company_id=$1 ORDER BY d.name`, [ctx.companyId]);
  }

  @Post('departments')
  @Roles('owner', 'admin')
  async createDept(@Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({ name: z.string().trim().min(2), headMemberId: z.string().uuid().optional().nullable() }), body);
    if (b.headMemberId) await getMember(ctx, b.headMemberId);
    const d = await q1(`INSERT INTO departments(company_id,name,head_member_id) VALUES ($1,$2,$3) RETURNING *`, [ctx.companyId, b.name, b.headMemberId ?? null]);
    await relinkLibraryDepartments(getPool(), ctx.companyId);
    return d;
  }

  @Patch('departments/:id')
  @Roles('owner', 'admin')
  async updateDept(@Param('id') id: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({ name: z.string().trim().min(2).optional(), headMemberId: z.string().uuid().nullable().optional() }), body);
    await this.dept(ctx, id);
    if (b.headMemberId) await getMember(ctx, b.headMemberId);
    return q1(`UPDATE departments SET name=COALESCE($3,name), head_member_id=CASE WHEN $4::boolean THEN $5::uuid ELSE head_member_id END
                WHERE id=$1 AND company_id=$2 RETURNING *`, [id, ctx.companyId, b.name ?? null, 'headMemberId' in b, b.headMemberId ?? null]);
  }

  // ---------- Danh mục công việc & mẫu ----------
  @Get('task-types')
  async taskTypes(@CurrentCtx() ctx: Ctx) {
    return q(`SELECT * FROM task_types WHERE company_id=$1 ORDER BY active DESC, name`, [ctx.companyId]);
  }

  @Post('task-types')
  @Roles('owner', 'admin')
  async createTaskType(@Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({ name: z.string().trim().min(2), category: z.string().optional() }), body);
    return q1(`INSERT INTO task_types(company_id,name,category) VALUES ($1,$2,$3) RETURNING *`, [ctx.companyId, b.name, b.category ?? null]);
  }

  @Patch('task-types/:id')
  @Roles('owner', 'admin')
  async updateTaskType(@Param('id') id: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({ name: z.string().trim().min(2).optional(), active: z.boolean().optional() }), body);
    const r = await q1(`UPDATE task_types SET name=COALESCE($3,name), active=COALESCE($4,active) WHERE id=$1 AND company_id=$2 RETURNING *`,
      [id, ctx.companyId, b.name ?? null, b.active ?? null]);
    if (!r) throw Errors.notFound('Loại công việc');
    return r;
  }

  @Get('task-templates')
  async templates(@CurrentCtx() ctx: Ctx) {
    return q(`SELECT tt.*, ty.name AS task_type_name FROM task_templates tt LEFT JOIN task_types ty ON ty.id=tt.task_type_id
               WHERE tt.company_id=$1 AND tt.active ORDER BY tt.sort, tt.name`, [ctx.companyId]);
  }

  @Post('task-templates')
  @Roles('owner', 'admin', 'manager')
  async createTemplate(@Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({
      name: z.string().trim().min(2), taskTypeId: z.string().uuid(), description: z.string().optional(),
      complexity: z.enum(['simple', 'medium', 'complex', 'very_complex']), requirementLevel: z.enum(['normal', 'high', 'very_high']),
      estimatedHours: z.number().positive(),
      criteria: z.array(z.object({ direction: z.enum(['input', 'output']), criterion: z.string().min(2) })).default([]),
    }), body);
    const tt = await q1(`SELECT id FROM task_types WHERE id=$1 AND company_id=$2`, [b.taskTypeId, ctx.companyId]);
    if (!tt) throw Errors.notFound('Loại công việc');
    return q1(`INSERT INTO task_templates(company_id,name,task_type_id,description,complexity,requirement_level,estimated_hours,criteria)
               VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *`,
      [ctx.companyId, b.name, b.taskTypeId, b.description ?? null, b.complexity, b.requirementLevel, b.estimatedHours, JSON.stringify(b.criteria)]);
  }

  // ---------- SLA ----------
  @Get('sla')
  async sla(@CurrentCtx() ctx: Ctx) {
    return q(`SELECT * FROM sla_configs WHERE company_id=$1 ORDER BY array_position(ARRAY['low','medium','high','critical'], severity)`, [ctx.companyId]);
  }

  @Put('sla')
  @Roles('owner', 'admin')
  async putSla(@Body() body: any, @CurrentCtx() ctx: Ctx) {
    const rows = parse(z.array(z.object({
      severity: z.enum(['low', 'medium', 'high', 'critical']),
      manager_review_minutes: z.number().int().min(1), acknowledge_minutes: z.number().int().min(1), resolve_minutes: z.number().int().min(1),
    })), body);
    const old = await this.sla(ctx);
    await tx(async (c) => {
      for (const r of rows) {
        await q(`INSERT INTO sla_configs(company_id,severity,manager_review_minutes,acknowledge_minutes,resolve_minutes) VALUES ($1,$2,$3,$4,$5)
                 ON CONFLICT (company_id,severity) DO UPDATE SET manager_review_minutes=$3, acknowledge_minutes=$4, resolve_minutes=$5`,
          [ctx.companyId, r.severity, r.manager_review_minutes, r.acknowledge_minutes, r.resolve_minutes], c);
      }
      await audit(c, ctx, 'company', ctx.companyId, 'sla.updated', old, rows);
    });
    return this.sla(ctx);
  }

  // ---------- Cấu hình đánh giá (có phiên bản) ----------
  @Get('performance-config')
  async perfConfig(@CurrentCtx() ctx: Ctx) {
    const rows = await q(`SELECT * FROM performance_configs WHERE company_id=$1 ORDER BY version DESC`, [ctx.companyId]);
    return { current: rows[0], history: rows };
  }

  @Post('performance-config')
  @Roles('owner', 'admin')
  async newPerfConfig(@Body() body: any, @CurrentCtx() ctx: Ctx) {
    const w = (keys: string[]) => z.object(Object.fromEntries(keys.map((k) => [k, z.number().min(0).max(1)])));
    const b = parse(z.object({
      regularWeights: w(['output', 'quality', 'schedule', 'process']),
      unexpectedWeights: w(['requirement', 'response', 'handling', 'quality', 'coordination']),
      complexityFactors: z.object({ simple: z.number().positive(), medium: z.number().positive(), complex: z.number().positive(), very_complex: z.number().positive() }),
      requirementFactors: z.object({ normal: z.number().positive(), high: z.number().positive(), very_high: z.number().positive() }),
      employeeWeights: w(['V', 'T', 'Q', 'D', 'R']),
      ownerShare: z.number().min(0.1).max(1),
      qualityMix: w(['score', 'firstPass']),
    }).partial(), body);
    const cur = await q1(`SELECT * FROM performance_configs WHERE company_id=$1 ORDER BY version DESC LIMIT 1`, [ctx.companyId]);
    const next = { ...DEFAULT_PERFORMANCE, ...(cur?.config || {}), ...b };
    for (const key of ['regularWeights', 'unexpectedWeights', 'employeeWeights', 'qualityMix'] as const) {
      const sum = Object.values(next[key] as Record<string, number>).reduce((a, x) => a + x, 0);
      if (Math.abs(sum - 1) > 0.001) throw Errors.validation(`Tổng trọng số ${key} phải bằng 1 (hiện tại ${sum.toFixed(2)})`);
    }
    const version = (cur?.version || 0) + 1;
    const r = await q1(`INSERT INTO performance_configs(company_id,version,config,created_by) VALUES ($1,$2,$3,$4) RETURNING *`,
      [ctx.companyId, version, JSON.stringify(next), ctx.memberId]);
    await audit(getPool(), ctx, 'company', ctx.companyId, 'performance_config.created', cur?.config, next);
    return r;
  }

  // ---------- Lịch làm việc ----------
  @Get('calendar/suggest-due')
  async suggestDue(@CurrentCtx() ctx: Ctx, @Query('hours') hours: string, @Query('from') from?: string) {
    const h = Number(hours);
    if (!(h > 0)) throw Errors.validation('hours phải > 0');
    const c = await getCompany(ctx.companyId);
    const due = addWorkingMinutes(from ? new Date(from) : new Date(), Math.round(h * 60), c.settings.calendar, c.timezone);
    return { due_at: due.toISOString(), guide: DURATION_GUIDE };
  }

  // ---------- Audit ----------
  @Get('audit-logs')
  async auditLogs(@CurrentCtx() ctx: Ctx, @Query('entityType') et?: string, @Query('entityId') eid?: string, @Query('limit') limit = '100') {
    if (!isAdmin(ctx) && !eid) throw Errors.forbidden();
    const rows = await q(
      `SELECT a.*, u.name AS actor_name FROM audit_logs a LEFT JOIN company_members cm ON cm.id=a.actor_id LEFT JOIN users u ON u.id=cm.user_id
        WHERE a.company_id=$1 AND ($2::text IS NULL OR a.entity_type=$2) AND ($3::uuid IS NULL OR a.entity_id=$3)
        ORDER BY a.id DESC LIMIT $4`, [ctx.companyId, et || null, eid || null, Math.min(Number(limit) || 100, 500)]);
    return rows;
  }
}
