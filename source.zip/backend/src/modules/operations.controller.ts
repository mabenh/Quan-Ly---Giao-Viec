/**
 * Điều phối vận hành (Đặc tả v2.0 mục 5, 7, 8):
 * - Sản lượng & chất lượng theo phiên/công đoạn do trưởng nhóm ghi nhận; định mức; điều chỉnh = phiên bản mới có lý do (không sửa đè).
 * - Bàn giao liên bộ phận (handover context): tự tạo khi công đoạn sau được mở; bên nhận tiếp nhận/từ chối; bên gửi bổ sung.
 * - Chuỗi đơn hàng: mã chuỗi chung, nhiệm vụ con mã riêng, nhánh song song; tính deadline ngược theo lịch làm việc;
 *   cảnh báo theo quy tắc (bình thường / sắp hạn / nguy cơ trễ / quá hạn) tổng hợp lên chuỗi; ưu tiên chỉnh tay có lý do; cho phép bắt đầu sớm có lý do.
 * - Phản hồi dữ liệu sai.
 * Điều phối do con người quyết định — không có phân công tự động.
 */
import { Body, Controller, Get, Param, Patch, Post, Query } from '@nestjs/common';
import { PoolClient } from 'pg';
import { getPool, q, q1, tx } from '../db/db';
import { CurrentCtx, Ctx, isAdmin } from '../common/context';
import { AppError, Errors } from '../common/errors';
import { parse, z } from '../common/validate';
import { notify } from '../common/notify';
import { audit } from '../common/audit';
import { getCompany } from '../common/access';
import { subtractWorkingMinutes, workingMinutesBetween } from '../common/calendar';
import { canLeadGroup, isBoard, leaderOf, managedGroupIds } from '../common/scope';
import { editScope } from './task-flow';
import { taskVisibilitySql } from './tasks.controller';

const OPEN = ['not_started', 'in_progress', 'revision_requested', 'waiting', 'pending_approval'];
export const RISK_ORDER = ['normal', 'due_soon', 'at_risk', 'overdue'];
const worst = (a: string, b: string) => (RISK_ORDER.indexOf(a) >= RISK_ORDER.indexOf(b) ? a : b);

/** Mức cảnh báo theo quy tắc xác định (không AI). */
export function riskOf(t: any, now: Date, executedMin: number, company: any, blocked = false): string {
  if (['completed', 'cancelled'].includes(t.status)) return 'done';
  if (t.status === 'pending_review') return new Date(t.due_at) < now ? 'overdue' : 'normal';
  const due = new Date(t.due_at);
  if (due < now) return 'overdue';
  const cal = company.settings.calendar; const tz = company.timezone;
  const need = Math.max(0, (t.standard_minutes || Number(t.estimated_hours) * 60) - executedMin) * company.settings.workTime.atRiskBufferRatio;
  const startFrom = t.status === 'waiting' && t.planned_start_at && new Date(t.planned_start_at) > now ? new Date(t.planned_start_at) : now;
  const avail = workingMinutesBetween(startFrom, due, cal, tz);
  if (blocked || need > avail) return 'at_risk';
  if (workingMinutesBetween(now, due, cal, tz) <= company.settings.policies.taskDueSoonMinutes / 3) return 'due_soon';
  return 'normal';
}

async function executedByTask(taskIds: string[], db: any = getPool()): Promise<Record<string, number>> {
  if (!taskIds.length) return {};
  const r = await q(`SELECT task_id, sum(EXTRACT(EPOCH FROM (COALESCE(ended_at, now()) - started_at)) / 60)::numeric AS m FROM work_sessions WHERE task_id = ANY($1::uuid[]) GROUP BY 1`, [taskIds], db);
  return Object.fromEntries(r.map((x) => [x.task_id, Math.round(Number(x.m))]));
}

/** Tính rủi ro cho các phần việc của một chuỗi + tổng hợp lên chuỗi; công đoạn gây tắc. */
export async function chainRisk(rootId: string, db: any = getPool()) {
  const root = await q1(`SELECT * FROM tasks WHERE id=$1`, [rootId], db);
  const company = await getCompany(root.company_id, db);
  const kids = await q(`SELECT t.*, g.name AS group_name, o.company_member_id AS owner_id, u.name AS owner_name
                          FROM tasks t JOIN groups g ON g.id=t.group_id LEFT JOIN task_assignees o ON o.task_id=t.id AND o.assignment_type='owner' AND o.active
                          LEFT JOIN company_members cm ON cm.id=o.company_member_id LEFT JOIN users u ON u.id=cm.user_id
                         WHERE t.root_id=$1 AND t.status<>'cancelled' ORDER BY t.stage_no, t.created_at`, [rootId], db);
  const exec = await executedByTask(kids.map((k) => k.id), db);
  const rejected = new Set((await q(`SELECT to_task_id FROM handover_contexts WHERE root_id=$1 AND status='rejected'`, [rootId], db)).map((r) => r.to_task_id));
  const now = new Date();
  let chain = 'normal'; let bottleneck: any = null;
  const stageRisk: Record<number, string> = {};
  for (const k of kids) {
    const prevBad = Object.entries(stageRisk).some(([s, r]) => Number(s) < k.stage_no && ['at_risk', 'overdue'].includes(r));
    k.executed_minutes = exec[k.id] || 0;
    k.risk = riskOf(k, now, k.executed_minutes, company, rejected.has(k.id) || (k.status === 'waiting' && prevBad));
    if (k.risk !== 'done') {
      stageRisk[k.stage_no] = worst(stageRisk[k.stage_no] || 'normal', k.risk);
      chain = worst(chain, k.risk);
      if (!bottleneck || RISK_ORDER.indexOf(k.risk) > RISK_ORDER.indexOf(bottleneck.risk) || (k.risk === bottleneck.risk && new Date(k.due_at) < new Date(bottleneck.due_at))) {
        if (k.status !== 'waiting' || k.risk !== 'normal') bottleneck = k;
      }
    }
  }
  if (!kids.length) chain = riskOf(root, now, (await executedByTask([rootId], db))[rootId] || 0, company);
  const done = kids.filter((k) => k.status === 'completed').length;
  return { root, kids, chain_risk: root.status === 'completed' ? 'done' : chain, bottleneck: bottleneck && bottleneck.risk !== 'normal' ? bottleneck : (bottleneck && kids.find((k) => ['in_progress', 'not_started'].includes(k.status))) || null,
    progress: kids.length ? Math.round((100 * done) / kids.length) : root.status === 'completed' ? 100 : 0, done, total: kids.length };
}

/** Khi công đoạn sau được mở: tạo bàn giao từ các phần việc đã xong của công đoạn trước (kế thừa nội dung, không bắt nhập lại). */
export async function createStageHandovers(c: PoolClient, companyId: string, parentId: string, stage: number, toTasks: { id: string; group_id: string; title: string }[]) {
  const prev = await q(`SELECT t.id, t.title, t.group_id, t.root_id,
                               (SELECT output_description FROM task_submissions s WHERE s.task_id=t.id ORDER BY created_at DESC LIMIT 1) AS output,
                               (SELECT string_agg(accepted_qty::text || ' ' || unit, ', ') FROM production_records p WHERE p.task_id=t.id AND p.status='confirmed') AS qty,
                               (SELECT sum(accepted_qty) FROM production_records p WHERE p.task_id=t.id AND p.status='confirmed') AS accepted,
                               (SELECT max(unit) FROM production_records p WHERE p.task_id=t.id AND p.status='confirmed') AS unit,
                               (SELECT criterion FROM task_criteria cr WHERE cr.task_id=t.id AND cr.direction='output' ORDER BY version DESC, created_at LIMIT 1) AS crit,
                               o.company_member_id AS owner_id
                          FROM tasks t LEFT JOIN task_assignees o ON o.task_id=t.id AND o.assignment_type='owner' AND o.active
                         WHERE t.parent_id=$1 AND t.status='completed'
                           AND t.stage_no = (SELECT max(stage_no) FROM tasks WHERE parent_id=$1 AND stage_no < $2 AND status='completed')`, [parentId, stage], c);
  for (const to of toTasks) {
    const tc = await q1(`SELECT due_at, (SELECT string_agg(criterion, '; ') FROM task_criteria WHERE task_id=$1 AND direction='input') AS input_crit FROM tasks WHERE id=$1`, [to.id], c);
    for (const p of prev) {
      const h = await q1(`INSERT INTO handover_contexts(company_id, root_id, from_task_id, to_task_id, from_group_id, to_group_id, content, acceptance_criteria, quantity, unit, due_at, submitted_by, auto)
                          VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,true) RETURNING id`,
        [companyId, p.root_id || parentId, p.id, to.id, p.group_id, to.group_id,
         `Kết quả "${p.title}": ${p.output || 'đã hoàn thành'}${p.qty ? ` · Sản lượng đạt: ${p.qty}` : ''}`, tc?.input_crit || p.crit || null,
         p.accepted ?? null, p.unit ?? null, tc?.due_at ?? null, p.owner_id], c);
      await q(`UPDATE handover_contexts SET method='leader_confirmation', links=COALESCE((SELECT links FROM task_submissions s WHERE s.task_id=$2 ORDER BY created_at DESC LIMIT 1), '[]'::jsonb) WHERE id=$1`, [h.id, p.id], c);
      await q(`INSERT INTO handover_events(handover_id, actor_member_id, kind, note) VALUES ($1,$2,'submitted','Tự động khi công đoạn trước hoàn thành')`, [h.id, p.owner_id], c);
    }
    if (prev.length) {
      const own = await q1(`SELECT company_member_id FROM task_assignees WHERE task_id=$1 AND assignment_type='owner' AND active`, [to.id], c);
      await notify(c, { companyId, memberIds: [own?.company_member_id, await leaderOf(to.group_id, c)], type: 'handover.incoming', title: `Có bàn giao cần tiếp nhận: ${to.title}`, refType: 'task', refId: to.id });
    }
  }
}

/** Thông tin vận hành trên trang chi tiết nhiệm vụ. */
export async function taskOps(ctx: Ctx, t: any) {
  const [hin, hout, prod, time, loc, root, std] = await Promise.all([
    q(`SELECT h.*, ft.title AS from_title, ft.code AS from_code, fg.name AS from_group, su.name AS submitted_by_name, au.name AS accepted_by_name
         FROM handover_contexts h LEFT JOIN tasks ft ON ft.id=h.from_task_id LEFT JOIN groups fg ON fg.id=h.from_group_id
         LEFT JOIN company_members s ON s.id=h.submitted_by LEFT JOIN users su ON su.id=s.user_id LEFT JOIN company_members a ON a.id=h.accepted_by LEFT JOIN users au ON au.id=a.user_id
        WHERE h.to_task_id=$1 ORDER BY h.created_at`, [t.id]),
    q(`SELECT h.*, tt.title AS to_title, tt.code AS to_code, tg.name AS to_group, au.name AS accepted_by_name FROM handover_contexts h LEFT JOIN tasks tt ON tt.id=h.to_task_id
         LEFT JOIN groups tg ON tg.id=h.to_group_id LEFT JOIN company_members a ON a.id=h.accepted_by LEFT JOIN users au ON au.id=a.user_id WHERE h.from_task_id=$1 ORDER BY h.created_at`, [t.id]),
    productionRows(`p.task_id=$1`, [t.id]),
    q(`SELECT s.member_id, u.name, round(sum(EXTRACT(EPOCH FROM (COALESCE(s.ended_at, now()) - s.started_at)) / 60))::int AS minutes, bool_or(s.ended_at IS NULL) AS active
         FROM work_sessions s JOIN company_members cm ON cm.id=s.member_id JOIN users u ON u.id=cm.user_id WHERE s.task_id=$1 GROUP BY 1,2 ORDER BY 3 DESC`, [t.id]),
    t.work_location_id ? q1(`SELECT id, name FROM work_locations WHERE id=$1`, [t.work_location_id]) : null,
    t.root_id ? q1(`SELECT id, code, chain_code, title, is_chain FROM tasks WHERE id=$1`, [t.root_id]) : null,
    t.production_standard_id ? q1(`SELECT * FROM production_standards WHERE id=$1`, [t.production_standard_id]) : null,
  ]);
  const pauses = await q(`SELECT r.id, r.category, r.reason, r.started_at, r.ended_at, r.confirmed_by, u.name FROM work_time_records r JOIN company_members cm ON cm.id=r.member_id JOIN users u ON u.id=cm.user_id
                           WHERE r.task_id=$1 AND r.category IN ('objective_pause','subjective_pause','waiting') ORDER BY r.started_at DESC LIMIT 20`, [t.id]);
  const company = await getCompany(ctx.companyId);
  const executed = time.reduce((a: number, x: any) => a + x.minutes, 0);
  const lead = await canLeadGroup(ctx, t.group_id);
  const scope = await editScope(getPool(), ctx, t);
  const receiver = t.owner_id === ctx.memberId || lead;
  const isAssignee = !!(await q1(`SELECT 1 FROM task_assignees WHERE task_id=$1 AND company_member_id=$2 AND active`, [t.id, ctx.memberId]));
  const leaderName = (await q1(`SELECT u.name FROM groups g JOIN company_members cm ON cm.id=COALESCE(g.leader_member_id, g.manager_member_id) JOIN users u ON u.id=cm.user_id WHERE g.id=$1`, [t.group_id]))?.name;
  let chain: any = null;
  if (t.is_chain || t.root_id) {
    const rid = t.is_chain ? t.id : t.root_id;
    const r = await q1(`SELECT is_chain FROM tasks WHERE id=$1`, [rid]);
    if (r?.is_chain) { const cr = await chainRisk(rid); chain = { id: rid, code: cr.root.chain_code, title: cr.root.title, risk: cr.chain_risk, progress: cr.progress, bottleneck: cr.bottleneck ? { id: cr.bottleneck.id, title: cr.bottleneck.title, group_name: cr.bottleneck.group_name } : null }; }
  }
  return {
    handovers_in: hin, handovers_out: hout, production: prod, time_by_member: time, executed_minutes: executed, pauses,
    location: loc, root_task: root, production_standard: std, chain, group_leader_name: leaderName,
    risk: riskOf(t, new Date(), executed, company, hin.some((h: any) => h.status === 'rejected')),
    ops_permissions: {
      // Chỉ người được giao việc mới ghi nhận sản lượng, gửi bàn giao; tăng ca trong ghi nhận sản lượng chỉ dành cho trưởng nhóm.
      // Người giao việc (không thực hiện) chỉ điều chỉnh ưu tiên / hủy nhiệm vụ.
      is_assignee: isAssignee,
      can_record_production: isAssignee && !['cancelled'].includes(t.status),
      can_record_overtime: isAssignee && lead,
      can_accept_handover: receiver,
      can_send_handover: isAssignee && !['cancelled'].includes(t.status),
      can_early_start: t.status === 'waiting' && (isBoard(ctx) || scope === 'full' || lead),
      can_set_priority: !!scope || isBoard(ctx),
      can_confirm_pause: lead,
      can_session: !!(await q1(`SELECT 1 FROM task_assignees WHERE task_id=$1 AND company_member_id=$2 AND active`, [t.id, ctx.memberId])) && !['completed', 'cancelled', 'pending_review'].includes(t.status) && t.child_count === 0,
    },
  };
}

async function productionRows(where: string, params: any[], db: any = getPool()) {
  const rows = await q(
    `SELECT p.*, t.title AS task_title, t.code AS task_code, g.name AS group_name, ru.name AS recorded_by_name, s.name AS standard_name, s.quantity AS std_qty, s.minutes AS std_min, s.unit AS std_unit,
            (SELECT array_agg(u2.name) FROM company_members c2 JOIN users u2 ON u2.id=c2.user_id WHERE c2.id = ANY(p.participants)) AS participant_names
       FROM production_records p JOIN tasks t ON t.id=p.task_id LEFT JOIN groups g ON g.id=p.group_id
       JOIN company_members r ON r.id=p.recorded_by JOIN users ru ON ru.id=r.user_id LEFT JOIN production_standards s ON s.id=p.standard_id
      WHERE ${where} ORDER BY p.created_at DESC LIMIT 300`, params, db);
  return rows.map(withEfficiency);
}
/** Hiệu suất công đoạn = thời gian chuẩn quy đổi từ sản lượng đạt chuẩn / thời gian thực hiện; tỷ lệ đạt chuẩn tính riêng. */
export function withEfficiency(p: any) {
  const std = p.std_qty && p.std_min ? (Number(p.accepted_qty) / Number(p.std_qty)) * Number(p.std_min) : null;
  return {
    ...p,
    standard_minutes: std !== null ? Math.round(std) : null,
    efficiency: std !== null && Number(p.execution_minutes) > 0 ? Math.round((100 * std) / Number(p.execution_minutes)) : null,
    quality_rate: Number(p.actual_qty) > 0 ? Math.round((100 * Number(p.accepted_qty)) / Number(p.actual_qty)) : null,
  };
}

const PROD = z.object({
  taskId: z.string().uuid(), mode: z.enum(['stage', 'single']).default('stage'), sessionId: z.string().uuid().optional().nullable(),
  standardId: z.string().uuid().optional().nullable(), participants: z.array(z.string().uuid()).default([]), unit: z.string().max(40).optional(),
  inputQty: z.number().min(0).optional().nullable(), plannedQty: z.number().min(0).optional().nullable(),
  actualQty: z.number().min(0), acceptedQty: z.number().min(0), rejectedQty: z.number().min(0).default(0), reworkQty: z.number().min(0).default(0), backlogQty: z.number().min(0).default(0),
  executionMinutes: z.number().min(0).optional().nullable(), startedAt: z.coerce.date().optional().nullable(), endedAt: z.coerce.date().optional().nullable(),
  source: z.enum(['leader', 'device', 'scan', 'scale', 'batch']).default('leader'), note: z.string().max(2000).optional(), issues: z.string().max(2000).optional(),
  // Thời gian làm việc và thời gian tăng ca của từng người để có kết quả này (tăng ca chỉ trưởng nhóm ghi)
  participantTimes: z.array(z.object({ memberId: z.string().uuid(), workMinutes: z.number().min(0).max(1440), otMinutes: z.number().min(0).max(960).default(0) })).max(100).optional(),
});

@Controller()
export class OperationsController {
  // ---------------- Sản lượng ----------------
  @Post('production')
  async record(@Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(PROD, body);
    const t = await q1(`SELECT * FROM tasks WHERE id=$1 AND company_id=$2`, [b.taskId, ctx.companyId]);
    if (!t) throw Errors.notFound('Nhiệm vụ');
    await this.assertCanRecord(ctx, t, b);
    if (b.acceptedQty + b.rejectedQty > b.actualQty) throw Errors.validation('Số đạt chuẩn + lỗi không được vượt số lượng thực tế');
    const id = await tx(async (c) => this.insertRecord(c, ctx, t, b, 1, null, null));
    return (await productionRows(`p.id=$1`, [id]))[0];
  }

  /** Chỉ người được giao nhiệm vụ ghi nhận sản lượng; có giờ tăng ca thì phải là trưởng nhóm. */
  private async assertCanRecord(ctx: Ctx, t: any, b: any) {
    const assignee = !!(await q1(`SELECT 1 FROM task_assignees WHERE task_id=$1 AND company_member_id=$2 AND active`, [t.id, ctx.memberId]));
    if (!assignee) throw Errors.forbidden('Chỉ người được giao nhiệm vụ mới ghi nhận sản lượng');
    if ((b.participantTimes || []).some((p: any) => p.otMinutes > 0) && !(await canLeadGroup(ctx, t.group_id))) throw Errors.forbidden('Chỉ trưởng nhóm được ghi nhận giờ tăng ca trong sản lượng');
  }

  private async insertRecord(c: PoolClient, ctx: Ctx, t: any, b: z.infer<typeof PROD>, version: number, supersedes: string | null, reason: string | null) {
    const std = b.standardId || t.production_standard_id || null;
    const unit = b.unit || (std ? (await q1(`SELECT unit FROM production_standards WHERE id=$1`, [std], c))?.unit : null) || 'sản phẩm';
    const times = b.participantTimes || [];
    const participants = times.length ? times.map((p) => p.memberId) : b.participants.length ? b.participants : (await q(`SELECT company_member_id AS id FROM task_assignees WHERE task_id=$1 AND active`, [t.id], c)).map((r) => r.id);
    const otTotal = times.reduce((a, p) => a + (p.otMinutes || 0), 0);
    let exec = times.length ? times.reduce((a, p) => a + p.workMinutes + (p.otMinutes || 0), 0) : (b.executionMinutes ?? null);
    if (exec === null) {
      const r = await q1(`SELECT COALESCE(sum(EXTRACT(EPOCH FROM (LEAST(COALESCE(ended_at, now()), COALESCE($4::timestamptz, now())) - GREATEST(started_at, COALESCE($3::timestamptz, started_at)))) / 60), 0)::numeric AS m
                          FROM work_sessions WHERE task_id=$1 AND member_id = ANY($2::uuid[]) AND started_at < COALESCE($4::timestamptz, now())`, [t.id, participants, b.startedAt ?? null, b.endedAt ?? null], c);
      exec = Math.max(0, Math.round(Number(r.m)));
    }
    const r = await q1(
      `INSERT INTO production_records(company_id, task_id, root_id, group_id, session_id, mode, standard_id, participants, unit, input_qty, planned_qty, actual_qty, accepted_qty,
         rejected_qty, rework_qty, backlog_qty, execution_minutes, started_at, ended_at, source, note, issues, version, supersedes_id, recorded_by, confirmed_by, confirmed_at, change_reason,
         participant_times, overtime_minutes)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25,$25, now(), $26, $27, $28) RETURNING id`,
      [ctx.companyId, t.id, t.root_id || t.id, t.group_id, b.sessionId ?? null, b.mode, std, participants, unit, b.inputQty ?? null, b.plannedQty ?? null, b.actualQty, b.acceptedQty,
       b.rejectedQty, b.reworkQty, b.backlogQty, exec, b.startedAt ?? null, b.endedAt ?? null, b.source, b.note ?? null, b.issues ?? null, version, supersedes, ctx.memberId, reason,
       JSON.stringify(times.map((p) => ({ member_id: p.memberId, work_minutes: p.workMinutes, ot_minutes: p.otMinutes || 0 }))), otTotal], c);
    if (times.length) {
      // Tăng ca là tham số hiệu suất (app không tính lương): ghi kèm bản ghi tăng ca đã xác nhận cho từng người
      const end = b.endedAt || new Date();
      for (const p of times.filter((x) => x.otMinutes > 0)) {
        await q(`INSERT INTO overtime_records(company_id, member_id, group_id, task_id, start_at, end_at, minutes, ot_type, cause, requested_by_member_id, approval_status, reviewer_id, reviewed_at, created_by, source, production_record_id, work_minutes)
                 VALUES ($1,$2,$3,$4,$5,$6,$7,'production',$8,$9,'confirmed',$9,now(),$9,'production',$10,$11)`,
          [ctx.companyId, p.memberId, t.group_id, t.id, new Date(new Date(end).getTime() - p.otMinutes * 60000), end, Math.round(p.otMinutes), `Tăng ca để hoàn thành sản lượng "${t.title}"`, ctx.memberId, r.id, Math.round(p.workMinutes)], c);
      }
    }
    await audit(c, ctx, 'task', t.id, supersedes ? 'production.adjusted' : 'production.recorded', null,
      { record: r.id, actual: b.actualQty, accepted: b.acceptedQty, rejected: b.rejectedQty, rework: b.reworkQty, version }, reason);
    return r.id;
  }

  /** Điều chỉnh bản ghi đã xác nhận: tạo phiên bản mới, giữ bản cũ (superseded), bắt buộc lý do. */
  @Post('production/:id/adjust')
  async adjust(@Param('id') id: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(PROD.omit({ taskId: true }).extend({ reason: z.string().trim().min(5, 'Nêu lý do điều chỉnh') }), body);
    const old = await q1(`SELECT * FROM production_records WHERE id=$1 AND company_id=$2`, [id, ctx.companyId]);
    if (!old) throw Errors.notFound('Bản ghi sản lượng');
    if (old.status !== 'confirmed') throw Errors.invalidState('Bản ghi đã được thay bằng phiên bản mới hơn');
    const t = await q1(`SELECT * FROM tasks WHERE id=$1`, [old.task_id]);
    await this.assertCanRecord(ctx, t, b);
    if (b.acceptedQty + b.rejectedQty > b.actualQty) throw Errors.validation('Số đạt chuẩn + lỗi không được vượt số lượng thực tế');
    const nid = await tx(async (c) => {
      await q(`UPDATE overtime_records SET approval_status='superseded' WHERE production_record_id=$1`, [id], c);
      const n = await this.insertRecord(c, ctx, t, { ...b, taskId: t.id, participants: b.participants.length ? b.participants : old.participants, standardId: b.standardId ?? old.standard_id,
        participantTimes: b.participantTimes ?? (old.participant_times || []).map((p: any) => ({ memberId: p.member_id, workMinutes: p.work_minutes, otMinutes: p.ot_minutes })) }, old.version + 1, id, b.reason);
      await q(`UPDATE production_records SET status='superseded' WHERE id=$1`, [id], c);
      return n;
    });
    return (await productionRows(`p.id=$1`, [nid]))[0];
  }

  @Get('production')
  async listProduction(@CurrentCtx() ctx: Ctx, @Query() qs: any) {
    const f = parse(z.object({ taskId: z.string().uuid().optional(), groupId: z.string().uuid().optional(), rootId: z.string().uuid().optional(),
      from: z.coerce.date().optional(), to: z.coerce.date().optional(), history: z.enum(['true', 'false']).optional() }), qs);
    const vis = await taskVisibilitySql(ctx);
    const where = [`p.company_id=$1`, `$2::uuid IS NOT NULL`, `EXISTS (SELECT 1 FROM tasks t WHERE t.id=p.task_id AND (${vis} OR $2 = ANY(p.participants)))`];
    const params: any[] = [ctx.companyId, ctx.memberId];
    const add = (sql: string, v: any) => { params.push(v); where.push(sql.replace('?', `$${params.length}`)); };
    if (f.history !== 'true') where.push(`p.status='confirmed'`);
    if (f.taskId) add(`p.task_id=?`, f.taskId);
    if (f.groupId) add(`p.group_id=?`, f.groupId);
    if (f.rootId) add(`p.root_id=?`, f.rootId);
    if (f.from) add(`p.created_at>=?`, f.from);
    if (f.to) add(`p.created_at<?`, f.to);
    return productionRows(where.join(' AND '), params);
  }

  // ---------------- Định mức ----------------
  @Get('company/production-standards')
  async standards(@CurrentCtx() ctx: Ctx) {
    return q(`SELECT s.*, tt.name AS task_type_name FROM production_standards s LEFT JOIN task_types tt ON tt.id=s.task_type_id WHERE s.company_id=$1 ORDER BY s.active DESC, s.name, s.version DESC`, [ctx.companyId]);
  }
  @Post('company/production-standards')
  async addStandard(@Body() body: any, @CurrentCtx() ctx: Ctx) {
    if (!isAdmin(ctx) && ctx.role !== 'manager') throw Errors.forbidden();
    const b = parse(z.object({ name: z.string().trim().min(2), unit: z.string().trim().min(1).default('sản phẩm'), quantity: z.number().positive(), minutes: z.number().positive(),
      taskTypeId: z.string().uuid().optional().nullable(), note: z.string().max(500).optional() }), body);
    const r = await q1(`INSERT INTO production_standards(company_id, name, unit, quantity, minutes, task_type_id, note, created_by) VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *`,
      [ctx.companyId, b.name, b.unit, b.quantity, b.minutes, b.taskTypeId ?? null, b.note ?? null, ctx.memberId]);
    await audit(getPool(), ctx, 'production_standard', r.id, 'standard.created', null, b);
    return r;
  }
  /** Đổi định mức: tạo phiên bản mới (bản cũ ngừng dùng), có lý do — các bản ghi cũ vẫn tính theo định mức tại thời điểm ghi nhận. */
  @Patch('company/production-standards/:id')
  async editStandard(@Param('id') id: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    if (!isAdmin(ctx) && ctx.role !== 'manager') throw Errors.forbidden();
    const b = parse(z.object({ quantity: z.number().positive().optional(), minutes: z.number().positive().optional(), name: z.string().trim().min(2).optional(),
      active: z.boolean().optional(), reason: z.string().trim().min(5, 'Nêu lý do thay đổi định mức') }), body);
    const old = await q1(`SELECT * FROM production_standards WHERE id=$1 AND company_id=$2`, [id, ctx.companyId]);
    if (!old) throw Errors.notFound('Định mức');
    return tx(async (c) => {
      await q(`UPDATE production_standards SET active=false WHERE id=$1`, [id], c);
      if (b.active === false && b.quantity === undefined && b.minutes === undefined) { await audit(c, ctx, 'production_standard', id, 'standard.deactivated', null, null, b.reason); return { ...old, active: false }; }
      const n = await q1(`INSERT INTO production_standards(company_id, name, unit, quantity, minutes, task_type_id, note, version, created_by) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING *`,
        [ctx.companyId, b.name ?? old.name, old.unit, b.quantity ?? old.quantity, b.minutes ?? old.minutes, old.task_type_id, old.note, old.version + 1, ctx.memberId], c);
      await q(`UPDATE tasks SET production_standard_id=$2 WHERE production_standard_id=$1 AND status NOT IN ('completed','cancelled')`, [id, n.id], c);
      await audit(c, ctx, 'production_standard', n.id, 'standard.changed', { quantity: old.quantity, minutes: old.minutes }, { quantity: n.quantity, minutes: n.minutes }, b.reason);
      return n;
    });
  }

  // ---------------- Bàn giao ----------------
  @Post('handovers')
  async createHandover(@Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({
      fromTaskId: z.string().uuid(), toTaskId: z.string().uuid().optional().nullable(), toGroupId: z.string().uuid().optional().nullable(),
      content: z.string().trim().min(5, 'Nhập nội dung bàn giao'), acceptanceCriteria: z.string().max(2000).optional(),
      method: z.enum(['direct_inspection', 'customer_confirmation', 'document_check', 'leader_confirmation', 'other']).default('direct_inspection'),
      methodNote: z.string().max(300).optional(), links: z.array(z.string().trim().url('Đường link không hợp lệ').max(500)).max(10).default([]),
      quantity: z.number().min(0).optional().nullable(), unit: z.string().max(40).optional(), dueAt: z.coerce.date().optional().nullable(),
    }), body);
    const from = await q1(`SELECT t.*, o.company_member_id AS owner_id FROM tasks t LEFT JOIN task_assignees o ON o.task_id=t.id AND o.assignment_type='owner' AND o.active WHERE t.id=$1 AND t.company_id=$2`, [b.fromTaskId, ctx.companyId]);
    if (!from) throw Errors.notFound('Nhiệm vụ');
    if (!(await q1(`SELECT 1 FROM task_assignees WHERE task_id=$1 AND company_member_id=$2 AND active`, [from.id, ctx.memberId]))) throw Errors.forbidden('Chỉ người được giao nhiệm vụ mới gửi bàn giao');
    let to: any = null;
    if (b.toTaskId) { to = await q1(`SELECT id, group_id, title FROM tasks WHERE id=$1 AND company_id=$2`, [b.toTaskId, ctx.companyId]); if (!to) throw Errors.notFound('Nhiệm vụ nhận'); }
    const toGroup = to?.group_id || b.toGroupId;
    if (!toGroup) throw Errors.validation('Chọn nhiệm vụ hoặc nhóm nhận bàn giao');
    const id = await tx(async (c) => {
      const h = await q1(`INSERT INTO handover_contexts(company_id, root_id, from_task_id, to_task_id, from_group_id, to_group_id, content, acceptance_criteria, quantity, unit, due_at, submitted_by)
                          VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12) RETURNING id`,
        [ctx.companyId, from.root_id || from.id, from.id, to?.id ?? null, from.group_id, toGroup, b.content, b.acceptanceCriteria ?? null, b.quantity ?? null, b.unit ?? null, b.dueAt ?? null, ctx.memberId], c);
      await q(`UPDATE handover_contexts SET method=$2, method_note=$3, links=$4 WHERE id=$1`, [h.id, b.method, b.methodNote ?? null, JSON.stringify(b.links)], c);
      await q(`INSERT INTO handover_events(handover_id, actor_member_id, kind) VALUES ($1,$2,'submitted')`, [h.id, ctx.memberId], c);
      const own = to ? await q1(`SELECT company_member_id FROM task_assignees WHERE task_id=$1 AND assignment_type='owner' AND active`, [to.id], c) : null;
      await notify(c, { companyId: ctx.companyId, memberIds: [own?.company_member_id, await leaderOf(toGroup, c)], excludeMemberId: ctx.memberId, type: 'handover.incoming',
        title: `Có bàn giao cần tiếp nhận từ "${from.title}"`, refType: 'task', refId: to?.id || from.id });
      return h.id;
    });
    return this.handover(id, ctx);
  }

  private async loadHo(ctx: Ctx, id: string) {
    const h = await q1(`SELECT h.*, o.company_member_id AS to_owner, fo.company_member_id AS from_owner FROM handover_contexts h
                          LEFT JOIN task_assignees o ON o.task_id=h.to_task_id AND o.assignment_type='owner' AND o.active
                          LEFT JOIN task_assignees fo ON fo.task_id=h.from_task_id AND fo.assignment_type='owner' AND fo.active
                         WHERE h.id=$1 AND h.company_id=$2`, [id, ctx.companyId]);
    if (!h) throw Errors.notFound('Bàn giao');
    const receiver = h.to_owner === ctx.memberId || (await canLeadGroup(ctx, h.to_group_id));
    const sender = h.from_owner === ctx.memberId || h.submitted_by === ctx.memberId || (await canLeadGroup(ctx, h.from_group_id));
    if (!receiver && !sender && !isBoard(ctx)) throw Errors.notFound('Bàn giao');
    return { h, receiver, sender };
  }

  @Get('handovers/:id')
  async handover(@Param('id') id: string, @CurrentCtx() ctx: Ctx) {
    const { h, receiver, sender } = await this.loadHo(ctx, id);
    const events = await q(`SELECT e.*, u.name FROM handover_events e LEFT JOIN company_members cm ON cm.id=e.actor_member_id LEFT JOIN users u ON u.id=cm.user_id WHERE e.handover_id=$1 ORDER BY e.created_at`, [id]);
    const files = await q(`SELECT id, filename, mime, size, created_at FROM files WHERE parent_type='handover' AND parent_id=$1 ORDER BY created_at`, [id]);
    return { ...h, events, files, can_accept: receiver && h.status === 'submitted', can_reject: receiver && h.status === 'submitted', can_supplement: sender && h.status === 'rejected' };
  }

  @Post('handovers/:id/decide')
  async decide(@Param('id') id: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({ decision: z.enum(['accept', 'reject']), reason: z.string().trim().max(2000).optional() }), body);
    const { h, receiver } = await this.loadHo(ctx, id);
    if (!receiver) throw Errors.forbidden('Chỉ bên nhận mới tiếp nhận/từ chối bàn giao');
    if (h.status !== 'submitted') throw Errors.invalidState('Bàn giao không ở trạng thái chờ tiếp nhận');
    if (b.decision === 'reject' && (!b.reason || b.reason.length < 5)) throw Errors.reasonRequired('Nêu lý do không tiếp nhận / cần bổ sung gì');
    await tx(async (c) => {
      if (b.decision === 'accept') await q(`UPDATE handover_contexts SET status='accepted', accepted_by=$2, accepted_at=now() WHERE id=$1`, [id, ctx.memberId], c);
      else await q(`UPDATE handover_contexts SET status='rejected', rejection_reason=$2, reject_count=reject_count+1 WHERE id=$1`, [id, b.reason], c);
      await q(`INSERT INTO handover_events(handover_id, actor_member_id, kind, note) VALUES ($1,$2,$3,$4)`, [id, ctx.memberId, b.decision === 'accept' ? 'accepted' : 'rejected', b.reason ?? null], c);
      if (h.to_task_id) await audit(c, ctx, 'task', h.to_task_id, b.decision === 'accept' ? 'handover.accepted' : 'handover.rejected', null, { handover: id }, b.reason ?? null);
      if (b.decision === 'accept' && h.to_task_id) await autoStartTask(c, ctx.companyId, h.to_task_id, 'on_handover', h.from_task_id);
      await notify(c, { companyId: ctx.companyId, memberIds: [h.from_owner, h.submitted_by, await leaderOf(h.from_group_id, c)], excludeMemberId: ctx.memberId, type: 'handover.decided',
        title: b.decision === 'accept' ? 'Bàn giao đã được tiếp nhận' : 'Bàn giao chưa đạt — cần bổ sung', body: b.reason, refType: 'task', refId: h.from_task_id });
    });
    return this.handover(id, ctx);
  }

  @Post('handovers/:id/supplement')
  async supplement(@Param('id') id: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({ content: z.string().trim().min(5), quantity: z.number().min(0).optional().nullable(), links: z.array(z.string().trim().url().max(500)).max(10).default([]) }), body);
    const { h, sender } = await this.loadHo(ctx, id);
    if (!sender) throw Errors.forbidden();
    if (h.status !== 'rejected') throw Errors.invalidState('Chỉ bổ sung khi bàn giao bị từ chối');
    await tx(async (c) => {
      await q(`UPDATE handover_contexts SET status='submitted', content=content || E'\\n— Bổ sung: ' || $2, quantity=COALESCE($3, quantity), links=links || $4::jsonb, submitted_at=now() WHERE id=$1`, [id, b.content, b.quantity ?? null, JSON.stringify(b.links)], c);
      await q(`INSERT INTO handover_events(handover_id, actor_member_id, kind, note) VALUES ($1,$2,'supplemented',$3)`, [id, ctx.memberId, b.content], c);
      await notify(c, { companyId: ctx.companyId, memberIds: [h.to_owner, await leaderOf(h.to_group_id, c)], excludeMemberId: ctx.memberId, type: 'handover.incoming', title: 'Bàn giao đã được bổ sung — cần tiếp nhận', refType: 'task', refId: h.to_task_id || h.from_task_id });
    });
    return this.handover(id, ctx);
  }

  @Get('handovers')
  async handovers(@CurrentCtx() ctx: Ctx, @Query('scope') scope = 'incoming') {
    const groups = await managedGroupIds(ctx);
    const cond = scope === 'outgoing'
      ? `(fo.company_member_id=$2 OR h.submitted_by=$2 OR h.from_group_id = ANY($3::uuid[]))`
      : `(o.company_member_id=$2 OR h.to_group_id = ANY($3::uuid[]))`;
    return q(`SELECT h.id, h.status, h.content, h.quantity, h.unit, h.due_at, h.submitted_at, h.rejection_reason, h.auto, h.from_task_id, h.to_task_id,
                     ft.title AS from_title, tt.title AS to_title, fg.name AS from_group, tg.name AS to_group, r.chain_code
                FROM handover_contexts h LEFT JOIN tasks ft ON ft.id=h.from_task_id LEFT JOIN tasks tt ON tt.id=h.to_task_id LEFT JOIN tasks r ON r.id=h.root_id
                LEFT JOIN groups fg ON fg.id=h.from_group_id LEFT JOIN groups tg ON tg.id=h.to_group_id
                LEFT JOIN task_assignees o ON o.task_id=h.to_task_id AND o.assignment_type='owner' AND o.active
                LEFT JOIN task_assignees fo ON fo.task_id=h.from_task_id AND fo.assignment_type='owner' AND fo.active
               WHERE h.company_id=$1 AND ${cond} ORDER BY (h.status IN ('submitted','rejected')) DESC, h.submitted_at DESC LIMIT 200`, [ctx.companyId, ctx.memberId, groups]);
  }

  // ---------------- Chuỗi đơn hàng ----------------
  @Get('chains')
  async chains(@CurrentCtx() ctx: Ctx) {
    const vis = await taskVisibilitySql(ctx);
    const roots = await q(`SELECT t.id FROM tasks t WHERE t.is_chain AND t.status<>'cancelled' AND (${vis}
                              OR EXISTS (SELECT 1 FROM tasks x WHERE x.root_id=t.id AND EXISTS (SELECT 1 FROM task_assignees a WHERE a.task_id=x.id AND a.company_member_id=$2 AND a.active)))
                           ORDER BY t.due_at`, [ctx.companyId, ctx.memberId]);
    const out: any[] = [];
    for (const r of roots) {
      const c = await chainRisk(r.id);
      const full = isBoard(ctx) || c.root.created_by === ctx.memberId;
      out.push({
        id: c.root.id, chain_code: c.root.chain_code, title: c.root.title, customer_name: c.root.customer_name, due_at: c.root.due_at, importance: c.root.importance, priority: c.root.priority,
        status: c.root.status, risk: c.chain_risk, progress: c.progress, done: c.done, total: c.total,
        current_stage: Math.min(...c.kids.filter((k: any) => !['completed'].includes(k.status)).map((k: any) => k.stage_no), 99),
        bottleneck: c.bottleneck ? { id: c.bottleneck.id, title: c.bottleneck.title, group_name: c.bottleneck.group_name, risk: c.bottleneck.risk } : null,
        ...(full ? { order_value: c.root.order_value } : {}),
      });
    }
    return out;
  }

  @Get('chains/:id')
  async chain(@Param('id') id: string, @CurrentCtx() ctx: Ctx) {
    const root = await q1(`SELECT * FROM tasks WHERE id=$1 AND company_id=$2 AND is_chain`, [id, ctx.companyId]);
    if (!root) throw Errors.notFound('Chuỗi đơn hàng');
    const vis = await taskVisibilitySql(ctx);
    const visibleIds = new Set((await q(`SELECT t.id FROM tasks t WHERE (t.id=$3 OR t.root_id=$3) AND ${vis}`, [ctx.companyId, ctx.memberId, id])).map((r) => r.id));
    const mine = await q1(`SELECT 1 FROM tasks x JOIN task_assignees a ON a.task_id=x.id AND a.active AND a.company_member_id=$2 WHERE x.root_id=$1`, [id, ctx.memberId]);
    if (!visibleIds.has(id) && !visibleIds.size && !mine) throw Errors.notFound('Chuỗi đơn hàng');
    const c = await chainRisk(id);
    const fullView = isBoard(ctx) || root.created_by === ctx.memberId || visibleIds.has(id);
    const sensitive = isBoard(ctx) || root.created_by === ctx.memberId;
    const kids = c.kids.map((k: any) => visibleIds.has(k.id) || fullView
      ? { id: k.id, code: k.code, title: k.title, stage_no: k.stage_no, status: k.status, group_name: k.group_name, owner_name: k.owner_name, due_at: k.due_at, planned_start_at: k.planned_start_at,
          standard_minutes: k.standard_minutes, executed_minutes: k.executed_minutes, risk: k.risk, can_open: visibleIds.has(k.id) }
      : { id: null, title: k.title, stage_no: k.stage_no, status: k.status, group_name: k.group_name, risk: k.risk, can_open: false }); // nhân viên: chỉ thấy bối cảnh cần thiết
    const handovers = fullView ? await q(`SELECT h.id, h.status, h.from_task_id, h.to_task_id, h.submitted_at, h.accepted_at, h.reject_count, h.rejection_reason, ft.title AS from_title, tt.title AS to_title
                                            FROM handover_contexts h LEFT JOIN tasks ft ON ft.id=h.from_task_id LEFT JOIN tasks tt ON tt.id=h.to_task_id WHERE h.root_id=$1 ORDER BY h.submitted_at`, [id]) : [];
    const prod = fullView ? await q(`SELECT t.stage_no, sum(p.actual_qty) AS actual, sum(p.accepted_qty) AS accepted, sum(p.rejected_qty) AS rejected, sum(p.rework_qty) AS rework, max(p.unit) AS unit
                                       FROM production_records p JOIN tasks t ON t.id=p.task_id WHERE p.root_id=$1 AND p.status='confirmed' GROUP BY 1 ORDER BY 1`, [id]) : [];
    const time = fullView ? await q(`SELECT t.stage_no, r.category, round(sum(EXTRACT(EPOCH FROM (COALESCE(r.ended_at, now()) - r.started_at)) / 60))::int AS minutes
                                       FROM work_time_records r JOIN tasks t ON t.id=r.task_id WHERE t.root_id=$1 GROUP BY 1,2`, [id]) : [];
    return {
      id: root.id, chain_code: root.chain_code, title: root.title, description: root.description, customer_name: root.customer_name, due_at: root.due_at,
      importance: root.importance, priority: root.priority, status: root.status, risk: c.chain_risk, progress: c.progress, done: c.done, total: c.total,
      bottleneck: c.bottleneck ? { id: visibleIds.has(c.bottleneck.id) || fullView ? c.bottleneck.id : null, title: c.bottleneck.title, group_name: c.bottleneck.group_name, risk: c.bottleneck.risk } : null,
      stages: kids, handovers, production: prod, time, full_view: fullView,
      ...(sensitive ? { order_value: root.order_value, margin_note: root.margin_note } : {}),
      permissions: { can_schedule: isBoard(ctx) || root.created_by === ctx.memberId, can_set_priority: fullView },
    };
  }

  /** Tính deadline ngược từ hạn đơn hàng: giai đoạn sau → trước; nhánh song song lấy nhánh dài nhất; theo lịch làm việc + dự phòng. */
  @Post('chains/:id/schedule')
  async schedule(@Param('id') id: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({ apply: z.boolean().default(true) }), body || {});
    const root = await q1(`SELECT * FROM tasks WHERE id=$1 AND company_id=$2 AND is_chain`, [id, ctx.companyId]);
    if (!root) throw Errors.notFound('Chuỗi đơn hàng');
    if (!isBoard(ctx) && root.created_by !== ctx.memberId) throw Errors.forbidden();
    const company = await getCompany(ctx.companyId);
    const kids = await q(`SELECT id, title, stage_no, status, standard_minutes, estimated_hours, buffer_minutes FROM tasks WHERE parent_id=$1 AND status<>'cancelled' ORDER BY stage_no`, [id]);
    const stages = [...new Set(kids.map((k) => k.stage_no))].sort((a, b) => b - a);
    let cursor = new Date(root.due_at);
    const plan: any[] = [];
    for (const s of stages) {
      const items = kids.filter((k) => k.stage_no === s);
      const dur = Math.max(...items.map((k) => (k.standard_minutes || Number(k.estimated_hours) * 60) + (k.buffer_minutes || 0)));
      const start = subtractWorkingMinutes(cursor, dur, company.settings.calendar, company.timezone);
      for (const k of items) plan.push({ id: k.id, title: k.title, stage_no: s, due_at: cursor, planned_start_at: start, minutes: dur, locked: ['completed'].includes(k.status) });
      cursor = start;
    }
    const feasible = cursor >= new Date();
    if (b.apply) {
      await tx(async (c) => {
        for (const p of plan.filter((x) => !x.locked)) {
          await q(`UPDATE tasks SET due_at=$2, planned_start_at=$3, updated_at=now() WHERE id=$1`, [p.id, p.due_at, p.planned_start_at], c);
        }
        await audit(c, ctx, 'task', id, 'chain.scheduled', null, { stages: stages.length, earliest_start: cursor, feasible });
      });
    }
    return { plan: plan.sort((a, b) => a.stage_no - b.stage_no), earliest_start: cursor, feasible,
      note: feasible ? 'Lịch khả thi theo thời lượng chuẩn và lịch làm việc.' : 'Không đủ thời gian: mốc bắt đầu cần thiết đã qua — chuỗi có nguy cơ trễ, cần điều chỉnh.' };
  }

  /** Quản lý chỉnh ưu tiên thủ công, có lý do. */
  @Post('tasks/:id/priority')
  async priority(@Param('id') id: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({ priority: z.enum(['low', 'normal', 'high', 'urgent']).optional(), importance: z.enum(['normal', 'high', 'critical']).optional(), pinned: z.boolean().optional(),
      reason: z.string().trim().min(5, 'Nêu lý do thay đổi ưu tiên') }), body);
    const t = await q1(`SELECT t.*, o.company_member_id AS owner_id FROM tasks t LEFT JOIN task_assignees o ON o.task_id=t.id AND o.assignment_type='owner' AND o.active WHERE t.id=$1 AND t.company_id=$2`, [id, ctx.companyId]);
    if (!t) throw Errors.notFound('Nhiệm vụ');
    if (!isBoard(ctx) && !(await editScope(getPool(), ctx, t))) throw Errors.forbidden();
    await q(`UPDATE tasks SET priority=COALESCE($2,priority), importance=COALESCE($3,importance), pinned=COALESCE($4,pinned), urgent=CASE WHEN $4::boolean IS NULL THEN urgent ELSE $4 OR priority='urgent' END,
               pinned_at=CASE WHEN $4 THEN now() WHEN $4 = false THEN NULL ELSE pinned_at END, pinned_by=CASE WHEN $4 THEN $5::uuid ELSE pinned_by END, updated_at=now() WHERE id=$1`,
      [id, b.priority ?? null, b.importance ?? null, b.pinned ?? null, ctx.memberId]);
    if (b.pinned && t.owner_id) await notify(getPool(), { companyId: ctx.companyId, memberIds: [t.owner_id], excludeMemberId: ctx.memberId, type: 'task.pinned', title: `📌 Việc gấp: ${t.code} - ${t.title}`, body: b.reason, refType: 'task', refId: id });
    await audit(getPool(), ctx, 'task', id, 'task.priority_changed', { priority: t.priority, importance: t.importance }, { priority: b.priority ?? t.priority, importance: b.importance ?? t.importance }, b.reason);
    return { ok: true };
  }

  /** Cho phép ngoại lệ: bắt đầu công đoạn trước khi phụ thuộc hoàn thành (người có quyền, có lý do). */
  @Post('tasks/:id/early-start')
  async earlyStart(@Param('id') id: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({ reason: z.string().trim().min(5, 'Nêu lý do cho phép bắt đầu sớm') }), body);
    const t = await q1(`SELECT t.*, o.company_member_id AS owner_id FROM tasks t LEFT JOIN task_assignees o ON o.task_id=t.id AND o.assignment_type='owner' AND o.active WHERE t.id=$1 AND t.company_id=$2`, [id, ctx.companyId]);
    if (!t) throw Errors.notFound('Nhiệm vụ');
    if (t.status !== 'waiting') throw Errors.invalidState('Chỉ áp dụng cho công đoạn đang chờ công đoạn trước');
    if (!isBoard(ctx) && (await editScope(getPool(), ctx, t)) !== 'full' && !(await canLeadGroup(ctx, t.group_id))) throw Errors.forbidden();
    await tx(async (c) => {
      await q(`UPDATE tasks SET status='not_started', early_start_reason=$2, updated_at=now() WHERE id=$1`, [id, b.reason], c);
      await audit(c, ctx, 'task', id, 'task.early_start', { status: 'waiting' }, { status: 'not_started' }, b.reason);
      await notify(c, { companyId: ctx.companyId, memberIds: [t.owner_id], excludeMemberId: ctx.memberId, type: 'task.stage_started', title: `▶ Được phép bắt đầu sớm: ${t.title}`, body: b.reason, refType: 'task', refId: id });
    });
    return { ok: true };
  }

  // ---------------- Phản hồi dữ liệu sai ----------------
  @Post('feedback')
  async feedback(@Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({ targetType: z.enum(['session', 'time_record', 'production', 'task', 'evaluation', 'performance']), targetId: z.string().uuid().optional().nullable(),
      content: z.string().trim().min(10, 'Mô tả dữ liệu sai và giá trị đúng theo bạn').max(3000) }), body);
    let group: string | null = null;
    if (b.targetId) {
      const map: Record<string, string> = { session: `SELECT t.group_id FROM work_sessions s JOIN tasks t ON t.id=s.task_id WHERE s.id=$1 AND s.member_id=$2`,
        time_record: `SELECT t.group_id FROM work_time_records r LEFT JOIN tasks t ON t.id=r.task_id WHERE r.id=$1 AND r.member_id=$2`,
        production: `SELECT p.group_id FROM production_records p WHERE p.id=$1 AND $2 = ANY(p.participants)`,
        task: `SELECT t.group_id FROM tasks t JOIN task_assignees a ON a.task_id=t.id AND a.company_member_id=$2 WHERE t.id=$1`,
        evaluation: `SELECT t.group_id FROM task_evaluations e JOIN tasks t ON t.id=e.task_id JOIN task_assignees a ON a.task_id=t.id AND a.company_member_id=$2 WHERE e.id=$1`,
        performance: `SELECT NULL::uuid AS group_id WHERE $1::uuid IS NOT NULL AND $2::uuid IS NOT NULL` };
      const r = await q1(map[b.targetType], [b.targetId, ctx.memberId]);
      if (!r) throw Errors.notFound('Dữ liệu liên quan đến bạn');
      group = r.group_id;
    }
    const assignee = (await leaderOf(group)) || (await q1(`SELECT supervisor_member_id AS id FROM company_members WHERE id=$1`, [ctx.memberId]))?.id || null;
    const r = await q1(`INSERT INTO data_feedback(company_id, member_id, target_type, target_id, content, assigned_to) VALUES ($1,$2,$3,$4,$5,$6) RETURNING *`,
      [ctx.companyId, ctx.memberId, b.targetType, b.targetId ?? null, b.content, assignee === ctx.memberId ? null : assignee]);
    await notify(getPool(), { companyId: ctx.companyId, memberIds: [r.assigned_to], type: 'feedback.new', title: `${ctx.name} phản hồi dữ liệu chưa chính xác`, refType: 'feedback', refId: r.id });
    return r;
  }

  @Get('feedback')
  async feedbacks(@CurrentCtx() ctx: Ctx, @Query('scope') scope = 'mine') {
    const where = scope === 'handling' ? (isBoard(ctx) ? `f.company_id=$1 AND f.member_id<>$2` : `f.company_id=$1 AND f.assigned_to=$2 AND f.member_id<>$2`) : `f.company_id=$1 AND f.member_id=$2`;
    return q(`SELECT f.*, u.name AS member_name, ru.name AS resolved_by_name FROM data_feedback f JOIN company_members cm ON cm.id=f.member_id JOIN users u ON u.id=cm.user_id
               LEFT JOIN company_members r ON r.id=f.resolved_by LEFT JOIN users ru ON ru.id=r.user_id WHERE ${where}
               ORDER BY (f.status='open') DESC, f.created_at DESC LIMIT 200`, [ctx.companyId, ctx.memberId]);
  }

  @Post('feedback/:id/resolve')
  async resolveFeedback(@Param('id') id: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({ status: z.enum(['resolved', 'rejected']), resolution: z.string().trim().min(5) }), body);
    const f = await q1(`SELECT * FROM data_feedback WHERE id=$1 AND company_id=$2`, [id, ctx.companyId]);
    if (!f) throw Errors.notFound('Phản hồi');
    if (f.member_id === ctx.memberId) throw new AppError('CONFLICT_OF_INTEREST', 'Không tự xử lý phản hồi của mình', 403);
    if (f.assigned_to !== ctx.memberId && !isBoard(ctx)) throw Errors.forbidden();
    await q(`UPDATE data_feedback SET status=$2, resolution=$3, resolved_by=$4, resolved_at=now() WHERE id=$1`, [id, b.status, b.resolution, ctx.memberId]);
    await notify(getPool(), { companyId: ctx.companyId, memberIds: [f.member_id], type: 'feedback.resolved', title: b.status === 'resolved' ? 'Phản hồi dữ liệu của bạn đã được xử lý' : 'Phản hồi dữ liệu chưa được chấp nhận', body: b.resolution, refType: 'feedback', refId: id });
    return { ok: true };
  }
}

/** Quét rủi ro (scheduler): cập nhật risk_level, nhắc khi chuyển sang nguy cơ trễ / quá hạn (mỗi mức một lần). */
export async function runRiskScan(companyId: string) {
  const company = await getCompany(companyId);
  const tasks = await q(`SELECT t.*, o.company_member_id AS owner_id FROM tasks t LEFT JOIN task_assignees o ON o.task_id=t.id AND o.assignment_type='owner' AND o.active
                          WHERE t.company_id=$1 AND t.status = ANY($2::text[]) AND (t.root_id IS NOT NULL OR t.is_chain)`, [companyId, OPEN]);
  const exec = await executedByTask(tasks.map((t) => t.id));
  let n = 0;
  for (const t of tasks) {
    const r = riskOf(t, new Date(), exec[t.id] || 0, company);
    if (r !== t.risk_level) await q(`UPDATE tasks SET risk_level=$2 WHERE id=$1`, [t.id, r]);
    if (['at_risk', 'overdue'].includes(r) && t.risk_notified !== r) {
      const root = t.root_id ? await q1(`SELECT created_by, title, chain_code FROM tasks WHERE id=$1`, [t.root_id]) : null;
      await notify(getPool(), { companyId, memberIds: [t.owner_id, await leaderOf(t.group_id), r === 'overdue' || t.importance !== 'normal' ? root?.created_by : null],
        type: 'task.risk', title: `${r === 'overdue' ? '⏰ Quá hạn' : '⚠ Nguy cơ trễ'}: ${t.title}${root?.chain_code ? ` (${root.chain_code})` : ''}`, refType: 'task', refId: t.id, dedupeKey: `risk:${t.id}:${r}` });
      await q(`UPDATE tasks SET risk_notified=$2 WHERE id=$1`, [t.id, r]);
      n++;
    }
  }
  return n;
}

/**
 * Tự động bắt đầu nhiệm vụ (đặt lịch): khi nhận bàn giao xong (on_handover) hoặc đến giờ đặt trước (scheduled).
 * Nhiệm vụ chuyển "đang thực hiện" và báo người làm; nếu người làm đang trong phiên của công đoạn trước thì phiên tự chuyển sang việc mới.
 * Không tự mở phiên cho người đang không làm việc (tránh ghi nhận thời gian không có thật).
 */
export async function autoStartTask(c: PoolClient, companyId: string, taskId: string, trigger: 'on_handover' | 'scheduled', fromTaskId?: string | null) {
  const t = await q1(`SELECT t.*, o.company_member_id AS owner_id FROM tasks t LEFT JOIN task_assignees o ON o.task_id=t.id AND o.assignment_type='owner' AND o.active WHERE t.id=$1`, [taskId], c);
  if (!t || t.auto_start !== trigger || t.status !== 'not_started') return false;
  if (await q1(`SELECT 1 FROM handover_contexts WHERE to_task_id=$1 AND status IN ('submitted','rejected')`, [taskId], c)) return false;
  await q(`UPDATE tasks SET status='in_progress', started_at=COALESCE(started_at, now()), auto_started_at=now(), updated_at=now() WHERE id=$1`, [taskId], c);
  await audit(c, { companyId, memberId: null }, 'task', taskId, 'task.auto_started', { status: 'not_started' }, { status: 'in_progress', trigger });
  let switched = false;
  if (t.owner_id && fromTaskId) {
    const s = await q1(`SELECT id FROM work_sessions WHERE member_id=$1 AND task_id=$2 AND ended_at IS NULL`, [t.owner_id, fromTaskId], c);
    if (s) {
      await q(`UPDATE work_sessions SET ended_at=now(), end_reason='switch' WHERE id=$1`, [s.id], c);
      await q(`INSERT INTO work_sessions(company_id, member_id, task_id, source) VALUES ($1,$2,$3,'auto')`, [companyId, t.owner_id, taskId], c);
      switched = true;
    }
  }
  await notify(c, { companyId, memberIds: [t.owner_id], type: 'task.auto_started', title: `▶ Tự động bắt đầu: ${t.code} - ${t.title}`,
    body: trigger === 'scheduled' ? 'Theo lịch đã đặt' : switched ? 'Đã nhận bàn giao — phiên làm việc đã chuyển sang việc này' : 'Đã nhận bàn giao — bấm Bắt đầu phiên khi bạn vào việc', refType: 'task', refId: taskId });
  return true;
}

/** Scheduler: bắt đầu các nhiệm vụ đặt lịch đến giờ; nếu chưa đủ điều kiện (công đoạn trước chưa xong/chưa nhận bàn giao) thì báo trưởng nhóm một lần. */
export async function runScheduledStarts(companyId: string) {
  const due = await q(`SELECT id, status, title, code, group_id FROM tasks WHERE company_id=$1 AND auto_start='scheduled' AND scheduled_start_at <= now() AND status IN ('not_started','waiting') AND auto_started_at IS NULL`, [companyId]);
  let n = 0;
  for (const t of due) {
    const ok = await tx(async (c) => autoStartTask(c, companyId, t.id, 'scheduled'));
    if (ok) { n++; continue; }
    const flag = await q1(`UPDATE tasks SET schedule_notified=true WHERE id=$1 AND NOT schedule_notified RETURNING id`, [t.id]);
    if (flag) await notify(getPool(), { companyId, memberIds: [await leaderOf(t.group_id)], type: 'task.schedule_blocked', title: `Đến giờ bắt đầu nhưng chưa đủ điều kiện: ${t.code} - ${t.title}`, body: 'Công đoạn trước chưa xong hoặc chưa tiếp nhận bàn giao', refType: 'task', refId: t.id });
  }
  return n;
}
