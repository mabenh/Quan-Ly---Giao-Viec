import { DateTime } from 'luxon';
import { q, q1 } from '../db/db';
import { getCompany } from '../common/access';
import { Errors } from '../common/errors';
import { PerformanceConfig } from '../common/defaults';
import { perfConfig } from './tasks.controller';

export type PeriodType = 'month' | 'quarter' | 'year';

export interface Period { type: PeriodType; key: string; start: Date; end: Date; startDate: string; endDate: string; label: string }

/** key: month=YYYY-MM, quarter=YYYY-Qn, year=YYYY (theo timezone công ty) */
export function resolvePeriod(type: PeriodType, key: string | undefined, tz: string): Period {
  const now = DateTime.now().setZone(tz);
  let s: DateTime;
  if (type === 'month') {
    s = key ? DateTime.fromFormat(key, 'yyyy-MM', { zone: tz }) : now.startOf('month');
  } else if (type === 'quarter') {
    if (key) {
      const m = /^(\d{4})-Q([1-4])$/.exec(key);
      if (!m) throw Errors.validation('Kỳ quý phải có dạng YYYY-Qn');
      s = DateTime.fromObject({ year: +m[1], month: (+m[2] - 1) * 3 + 1, day: 1 }, { zone: tz });
    } else s = now.startOf('quarter');
  } else {
    s = key ? DateTime.fromObject({ year: +key, month: 1, day: 1 }, { zone: tz }) : now.startOf('year');
  }
  if (!s.isValid) throw Errors.validation('Kỳ báo cáo không hợp lệ');
  const e = s.plus(type === 'month' ? { months: 1 } : type === 'quarter' ? { months: 3 } : { years: 1 });
  const k = type === 'month' ? s.toFormat('yyyy-MM') : type === 'quarter' ? `${s.year}-Q${Math.ceil(s.month / 3)}` : `${s.year}`;
  const label = type === 'month' ? `Tháng ${s.toFormat('MM/yyyy')}` : type === 'quarter' ? `Quý ${Math.ceil(s.month / 3)}/${s.year}` : `Năm ${s.year}`;
  return { type, key: k, start: s.toJSDate(), end: e.toJSDate(), startDate: s.toISODate()!, endDate: e.minus({ days: 1 }).toISODate()!, label };
}

export function previousPeriod(p: Period, tz: string): Period {
  const s = DateTime.fromJSDate(p.start, { zone: tz }).minus(p.type === 'month' ? { months: 1 } : p.type === 'quarter' ? { months: 3 } : { years: 1 });
  const key = p.type === 'month' ? s.toFormat('yyyy-MM') : p.type === 'quarter' ? `${s.year}-Q${Math.ceil(s.month / 3)}` : `${s.year}`;
  return resolvePeriod(p.type, key, tz);
}

const CAT_VI: Record<string, string> = { equipment: 'máy móc, thiết bị', software: 'phần mềm, hệ thống', facility: 'cơ sở vật chất', supplies: 'vật tư, nguyên liệu', process: 'quy trình, phối hợp', other: 'khác' };
const OT_VI: Record<string, string> = { incident: 'sự cố', workload: 'khối lượng vượt khả năng', ad_hoc: 'yêu cầu đột xuất' };
const STAGE_VI: Record<string, string> = { department_ack: 'tiếp nhận', resolution: 'xử lý' };

const r2 = (x: number | null | undefined) => (x === null || x === undefined || Number.isNaN(x) ? null : Math.round(x * 100) / 100);

export interface TaskRow {
  task_id: string; member_id: string; assignment_type: 'owner' | 'collaborator'; n_collab: number;
  complexity: string; requirement_level: string; is_unexpected: boolean; requirement_structure: string | null;
  status: string; due_at: Date; first_submitted_at: Date | null; completed_at: Date | null; revision_count: number;
  impediment_confirmed: boolean; total_score: number | null; scores: any;
}

/**
 * Bộ máy tính điểm (mục 9). Hàm thuần — dễ kiểm thử.
 * - W = hệ số phức tạp × hệ số yêu cầu; C = điểm × W; P = ΣC/ΣW (tách thường xuyên / đột xuất).
 * - Ghi nhận theo vai trò: người chịu trách nhiệm ownerShare, cộng tác viên chia phần còn lại (không nhân đôi điểm toàn phần).
 * - E = Σ w_k·X_k trên các thành phần có dữ liệu (chuẩn hóa 0–100).
 */
export function scoreMembers(rows: TaskRow[], members: { member_id: string; role: string }[], cfg: PerformanceConfig, cohortMaxV?: Record<string, number>) {
  const cf = cfg.complexityFactors; const rf = cfg.requirementFactors;
  const minW = Math.min(...Object.values(cf)) * Math.min(...Object.values(rf));
  const maxW = Math.max(...Object.values(cf)) * Math.max(...Object.values(rf));
  const out: Record<string, any> = {};
  for (const m of members) {
    const mine = rows.filter((r) => r.member_id === m.member_id);
    const completed = mine.filter((r) => r.status === 'completed' && r.total_score !== null);
    let vRaw = 0; let sumWc = 0; let sumWcD = 0;
    const cat = { regular: { count: 0, sumW: 0, sumC: 0 }, unexpected: { count: 0, sumW: 0, sumC: 0, common: 0, diverse: 0 } };
    const procScores: number[] = [];
    for (const r of completed) {
      const W = (cf[r.complexity] ?? 1) * (rf[r.requirement_level] ?? 1);
      const credit = r.n_collab > 0 ? (r.assignment_type === 'owner' ? cfg.ownerShare : (1 - cfg.ownerShare) / r.n_collab) : (r.assignment_type === 'owner' ? 1 : 0);
      const wc = W * credit;
      vRaw += wc; sumWc += wc; sumWcD += W * wc;
      const k = r.is_unexpected ? cat.unexpected : cat.regular;
      k.count++; k.sumW += wc; k.sumC += (r.total_score as number) * wc;
      if (r.is_unexpected) (r.requirement_structure === 'diverse' ? cat.unexpected.diverse++ : cat.unexpected.common++);
      const p = r.is_unexpected ? r.scores?.coordination : r.scores?.process;
      if (typeof p === 'number') procScores.push(p);
    }
    const owned = mine.filter((r) => r.assignment_type === 'owner');
    // Tiến độ: nhiệm vụ đã bàn giao (hoặc quá hạn chưa bàn giao); trễ có căn cứ (trở ngại đã xác nhận) không tính
    let onTime = 0; let considered = 0; let excusedLate = 0;
    for (const r of owned) {
      if (r.status === 'cancelled') continue;
      const submitted = r.first_submitted_at ? new Date(r.first_submitted_at) : null;
      const due = new Date(r.due_at);
      const late = submitted ? submitted > due : (r.status !== 'completed' && due < new Date());
      if (!submitted && !late) continue;
      if (late && r.impediment_confirmed) { excusedLate++; continue; }
      considered++;
      if (!late) onTime++;
    }
    const ownedCompleted = owned.filter((r) => r.status === 'completed');
    const firstPass = ownedCompleted.length ? ownedCompleted.filter((r) => r.revision_count === 0).length / ownedCompleted.length : null;
    const P = sumWc > 0 ? (cat.regular.sumC + cat.unexpected.sumC) / sumWc : null;
    const T = considered > 0 ? (100 * onTime) / considered : null;
    const Q = P === null ? null : firstPass === null ? P : cfg.qualityMix.score * P + cfg.qualityMix.firstPass * 100 * firstPass;
    const avgW = sumWc > 0 ? sumWcD / sumWc : null;
    const D = avgW === null ? null : maxW > minW ? (100 * (avgW - minW)) / (maxW - minW) : 100;
    const R = procScores.length ? procScores.reduce((a, b) => a + b, 0) / procScores.length : null;
    out[m.member_id] = {
      member_id: m.member_id, role: m.role, v_raw: r2(vRaw), T: r2(T), Q: r2(Q), D: r2(D), R: r2(R), P: r2(P),
      regular: { count: cat.regular.count, weight: r2(cat.regular.sumW), P: r2(cat.regular.sumW ? cat.regular.sumC / cat.regular.sumW : null) },
      unexpected: { count: cat.unexpected.count, weight: r2(cat.unexpected.sumW), P: r2(cat.unexpected.sumW ? cat.unexpected.sumC / cat.unexpected.sumW : null),
        common: cat.unexpected.common, diverse: cat.unexpected.diverse },
      contribution_share: sumWc ? { regular: r2((100 * cat.regular.sumW) / sumWc), unexpected: r2((100 * cat.unexpected.sumW) / sumWc) } : null,
      on_time: onTime, timeliness_considered: considered, excused_late: excusedLate, first_pass_rate: firstPass === null ? null : r2(100 * firstPass),
      completed_count: completed.length, owned_count: owned.length,
    };
  }
  // Chuẩn hóa khối lượng theo nhóm vai trò (so với giá trị lớn nhất cùng vai trò)
  const maxByRole: Record<string, number> = { ...(cohortMaxV || {}) };
  if (!cohortMaxV) for (const s of Object.values(out)) maxByRole[s.role] = Math.max(maxByRole[s.role] || 0, s.v_raw || 0);
  const w = cfg.employeeWeights;
  for (const s of Object.values(out)) {
    const mx = maxByRole[s.role] || 0;
    s.V = s.completed_count > 0 && mx > 0 ? r2((100 * s.v_raw) / mx) : null;
    const comps: [number, number | null][] = [[w.V, s.V], [w.T, s.T], [w.Q, s.Q], [w.D, s.D], [w.R, s.R]];
    const avail = comps.filter(([, v]) => v !== null) as [number, number][];
    const wsum = avail.reduce((a, [k]) => a + k, 0);
    s.E = s.completed_count > 0 && wsum > 0 ? r2(avail.reduce((a, [k, v]) => a + k * v, 0) / wsum) : null;
    s.insufficient_data = s.completed_count === 0 || avail.length < 5;
  }
  return { scores: out, maxByRole };
}

export interface ReportScope { type: 'company' | 'group' | 'member'; id?: string | null }

/** Tổng hợp báo cáo kỳ (mục 10). */
export async function buildReport(companyId: string, period: Period, scope: ReportScope, opts: { light?: boolean } = {}) {
  const company = await getCompany(companyId);
  const { version, config } = await perfConfig(companyId);
  const P = [companyId, period.start, period.end];

  // Phạm vi thành viên
  let memberFilter = 'TRUE'; const scopeParams: any[] = [];
  if (scope.type === 'group') { memberFilter = `(cm.id IN (SELECT company_member_id FROM group_members WHERE group_id=$4) OR cm.id=(SELECT manager_member_id FROM groups WHERE id=$4))`; scopeParams.push(scope.id); }
  if (scope.type === 'member') { memberFilter = `cm.id=$4`; scopeParams.push(scope.id); }
  const members = await q(
    `SELECT cm.id AS member_id, cm.role, u.name, cm.title FROM company_members cm JOIN users u ON u.id=cm.user_id
      WHERE cm.company_id=$1 AND cm.status='active' AND cm.role IN ('employee','manager','handler','admin','owner','reviewer') AND ${memberFilter.replace(/\$4/g, '$2')}
      ORDER BY u.name`, [companyId, ...scopeParams]);
  // Nhiệm vụ liên quan kỳ: hoàn thành trong kỳ, hoặc deadline trong kỳ
  const taskScope = scope.type === 'group' ? `AND t.group_id=$4` : '';
  const rows: TaskRow[] = await q(
    `SELECT t.id AS task_id, ta.company_member_id AS member_id, ta.assignment_type,
            (SELECT count(*) FROM task_assignees x WHERE x.task_id=t.id AND x.active AND x.assignment_type='collaborator')::int AS n_collab,
            t.complexity, t.requirement_level, t.is_unexpected, ut.requirement_structure, t.status, t.due_at, t.first_submitted_at, t.completed_at,
            t.revision_count, EXISTS (SELECT 1 FROM workplace_reports wr WHERE wr.affected_task_id=t.id AND wr.impact_confirmed) AS impediment_confirmed,
            ev.total_score, ev.scores
       FROM tasks t JOIN task_assignees ta ON ta.task_id=t.id AND ta.active
       LEFT JOIN unexpected_tasks ut ON ut.task_id=t.id
       LEFT JOIN LATERAL (SELECT total_score, scores FROM task_evaluations e WHERE e.task_id=t.id AND e.decision='approved' ORDER BY created_at DESC LIMIT 1) ev ON true
      WHERE t.company_id=$1 AND ((t.completed_at >= $2 AND t.completed_at < $3) OR (t.due_at >= $2 AND t.due_at < $3)) ${taskScope}`,
    scope.type === 'group' ? [...P, scope.id] : P);
  // Chuẩn hóa V theo cùng vai trò trong toàn công ty (không phụ thuộc phạm vi đang xem)
  let cohort: Record<string, number> | undefined;
  if (scope.type !== 'company') {
    const all = await buildCohortMax(companyId, period, config);
    cohort = all;
  }
  const { scores } = scoreMembers(rows, members, config, cohort);

  // Tổng hợp nhiệm vụ
  const tsum = await q1(
    `SELECT count(*) FILTER (WHERE t.created_at >= $2 AND t.created_at < $3)::int AS assigned,
            count(*) FILTER (WHERE t.status='completed' AND t.completed_at >= $2 AND t.completed_at < $3)::int AS completed,
            count(*) FILTER (WHERE t.status='cancelled' AND t.updated_at >= $2 AND t.updated_at < $3)::int AS cancelled,
            count(*) FILTER (WHERE t.status IN ('not_started','in_progress','pending_review','revision_requested') AND t.due_at < LEAST(now(), $3))::int AS overdue,
            count(*) FILTER (WHERE t.status IN ('not_started','in_progress','pending_review','revision_requested'))::int AS in_progress,
            count(*) FILTER (WHERE t.status='completed' AND t.completed_at >= $2 AND t.completed_at < $3 AND t.first_submitted_at > t.due_at)::int AS completed_late
       FROM tasks t WHERE t.company_id=$1 ${taskScope}
        ${scope.type === 'member' ? `AND EXISTS (SELECT 1 FROM task_assignees x WHERE x.task_id=t.id AND x.active AND x.company_member_id=$4)` : ''}`,
    scope.type === 'company' ? P : [...P, scope.id]);

  const memberIds = members.map((m) => m.member_id);
  const ot = await q(
    `SELECT o.ot_type, o.approval_status, sum(o.minutes)::int AS minutes, count(*)::int AS n, ru.name AS requester
       FROM overtime_records o LEFT JOIN company_members r ON r.id=o.requested_by_member_id LEFT JOIN users ru ON ru.id=r.user_id
      WHERE o.company_id=$1 AND o.start_at >= $2 AND o.start_at < $3 AND o.member_id = ANY($4::uuid[])
      GROUP BY o.ot_type, o.approval_status, ru.name`, [...P, memberIds]);
  const otByMember = await q(`SELECT member_id, sum(minutes)::int AS minutes FROM overtime_records WHERE company_id=$1 AND start_at >= $2 AND start_at < $3 GROUP BY member_id`, P);

  const wrRows = await q(
    `SELECT employee_id, status, final_decision, overdue, claimed_minutes, accepted_minutes FROM employee_work_records
      WHERE company_id=$1 AND start_at >= $2 AND start_at < $3 AND employee_id = ANY($4::uuid[])`, [...P, memberIds]);
  const wrStats = (list: any[]) => ({
    submitted: list.length,
    accepted: list.filter((r) => r.final_decision === 'accepted').length,
    partially_accepted: list.filter((r) => r.final_decision === 'partially_accepted').length,
    rejected: list.filter((r) => r.final_decision === 'rejected').length,
    disputed: list.filter((r) => r.status === 'disputed').length,
    appealed: list.filter((r) => r.status === 'appealed').length,
    unresolved: list.filter((r) => !['resolved', 'accepted'].includes(r.status)).length,
    overdue: list.filter((r) => r.overdue && !['resolved', 'accepted'].includes(r.status)).length,
    claimed_minutes: list.reduce((a, r) => a + r.claimed_minutes, 0),
    accepted_minutes: list.reduce((a, r) => a + (r.accepted_minutes || 0), 0),
  });

  const repScope = scope.type === 'group' ? `AND w.group_id=$4` : scope.type === 'member' ? `AND w.reporter_id=$4` : '';
  const repParams = scope.type === 'company' ? P : [...P, scope.id];
  const reports = await q(
    `SELECT w.id, w.severity, w.status, w.stage, w.category, w.asset, w.reporter_id, d.name AS department, w.stage_due_at, w.escalation_level, w.affected_task_id
       FROM workplace_reports w LEFT JOIN departments d ON d.id=w.department_id
      WHERE w.company_id=$1 AND w.created_at >= $2 AND w.created_at < $3 ${repScope}`, repParams);
  const breaches = await q(
    `SELECT e.stage, d.name AS department, fu.name AS from_name, count(DISTINCT e.parent_id)::int AS n
       FROM escalations e JOIN workplace_reports w ON w.id=e.parent_id
       LEFT JOIN departments d ON d.id=w.department_id LEFT JOIN company_members f ON f.id=e.from_member_id LEFT JOIN users fu ON fu.id=f.user_id
      WHERE e.company_id=$1 AND e.parent_type='workplace_report' AND e.auto AND e.created_at >= $2 AND e.created_at < $3 ${repScope}
      GROUP BY e.stage, d.name, fu.name`, repParams);
  const wrEsc = await q(
    `SELECT fu.name AS from_name, count(DISTINCT e.parent_id)::int AS n FROM escalations e
       LEFT JOIN company_members f ON f.id=e.from_member_id LEFT JOIN users fu ON fu.id=f.user_id
      WHERE e.company_id=$1 AND e.parent_type='work_record' AND e.auto AND e.created_at >= $2 AND e.created_at < $3 GROUP BY fu.name`, P);
  const countBy = (list: any[], key: string) => list.reduce((m: Record<string, number>, r) => { const k = r[key] ?? 'Chưa phân'; m[k] = (m[k] || 0) + 1; return m; }, {});

  const involved = new Set(rows.map((r) => r.member_id));
  const memberList = members.filter((m) => scope.type === 'member' || m.role === 'employee' || involved.has(m.member_id)).map((m) => {
    const s = scores[m.member_id];
    const otm = otByMember.find((o) => o.member_id === m.member_id)?.minutes || 0;
    return {
      ...m, ...s, overtime_minutes: otm,
      workplace_reports: reports.filter((r) => r.reporter_id === m.member_id).length,
      work_records: wrStats(wrRows.filter((r) => r.employee_id === m.member_id)),
    };
  });

  // Nhóm
  let groups: any[] = [];
  if (scope.type !== 'member') {
    const gs = await q(`SELECT g.id, g.name, g.manager_member_id FROM groups g WHERE g.company_id=$1 AND g.deleted_at IS NULL ${scope.type === 'group' ? 'AND g.id=$2' : ''} ORDER BY g.name`,
      scope.type === 'group' ? [companyId, scope.id] : [companyId]);
    for (const g of gs) {
      const gm = (await q(`SELECT company_member_id AS id FROM group_members WHERE group_id=$1`, [g.id])).map((x) => x.id);
      const gt = await q1(
        `SELECT count(*) FILTER (WHERE status='completed' AND completed_at >= $2 AND completed_at < $3)::int AS completed,
                count(*) FILTER (WHERE status IN ('not_started','in_progress','pending_review','revision_requested'))::int AS backlog,
                count(*) FILTER (WHERE status IN ('not_started','in_progress','pending_review','revision_requested') AND due_at < now())::int AS overdue,
                COALESCE(sum(CASE WHEN status='completed' AND completed_at >= $2 AND completed_at < $3 THEN 1 ELSE 0 END),0)::int AS n
           FROM tasks WHERE group_id=$1`, [g.id, period.start, period.end]);
      const ms = memberList.filter((m) => gm.includes(m.member_id));
      const es = ms.map((m) => m.E).filter((x) => x !== null) as number[];
      const weighted = await q1(
        `SELECT COALESCE(sum(($4::jsonb->>t.complexity)::numeric * ($5::jsonb->>t.requirement_level)::numeric),0) AS w FROM tasks t
          WHERE t.group_id=$1 AND t.status='completed' AND t.completed_at >= $2 AND t.completed_at < $3`,
        [g.id, period.start, period.end, JSON.stringify(config.complexityFactors), JSON.stringify(config.requirementFactors)]);
      groups.push({
        id: g.id, name: g.name, member_count: gm.length, ...gt, weighted_volume: r2(weighted.w),
        avg_E: es.length ? r2(es.reduce((a, b) => a + b, 0) / es.length) : null,
        overtime_minutes: ms.reduce((a, m) => a + m.overtime_minutes, 0),
        workplace_reports: reports.filter((r) => ms.some((m) => m.member_id === r.reporter_id)).length,
        distribution: ms.map((m) => ({ member_id: m.member_id, name: m.name, completed: m.completed_count, v_raw: m.v_raw })),
      });
    }
  }

  const unexpectedAgg = { common: { count: 0, sumC: 0, sumW: 0 }, diverse: { count: 0, sumC: 0, sumW: 0 } };
  const seenTask = new Set<string>();
  for (const r of rows) {
    if (!r.is_unexpected || r.status !== 'completed' || r.total_score === null || seenTask.has(r.task_id)) continue;
    seenTask.add(r.task_id);
    const k = r.requirement_structure === 'diverse' ? unexpectedAgg.diverse : unexpectedAgg.common;
    const W = (config.complexityFactors[r.complexity] ?? 1) * (config.requirementFactors[r.requirement_level] ?? 1);
    k.count++; k.sumW += W; k.sumC += r.total_score * W;
  }

  const overtime = {
    total_minutes: ot.reduce((a, o) => a + o.minutes, 0),
    unconfirmed_minutes: ot.filter((o) => o.approval_status !== 'confirmed').reduce((a, o) => a + o.minutes, 0),
    by_cause: Object.entries(ot.reduce((m: any, o) => { m[o.ot_type] = (m[o.ot_type] || 0) + o.minutes; return m; }, {})).map(([ot_type, minutes]) => ({ ot_type, minutes })),
    by_requester: Object.entries(ot.reduce((m: any, o) => { const k = o.requester || 'Không ghi nhận'; m[k] = (m[k] || 0) + o.minutes; return m; }, {})).map(([requester, minutes]) => ({ requester, minutes })),
  };
  const openReports = reports.filter((r) => r.stage !== 'closed');
  const workplace = {
    total: reports.length, by_severity: countBy(reports, 'severity'), by_status: countBy(reports, 'status'),
    by_department: countBy(reports, 'department'), by_category: countBy(reports, 'category'),
    open: openReports.length, overdue_open: openReports.filter((r) => r.stage_due_at && new Date(r.stage_due_at) < new Date()).length,
    sla_breaches: breaches,
  };

  // Điểm nghẽn vận hành (10.2)
  const bottlenecks: { type: string; title: string; detail: string; action: string }[] = [];
  const impededLate = await q(
    `SELECT w.category, count(DISTINCT t.id)::int AS n FROM tasks t JOIN workplace_reports w ON w.affected_task_id=t.id AND w.impact_confirmed
      WHERE t.company_id=$1 AND t.due_at >= $2 AND t.due_at < $3 AND (t.first_submitted_at > t.due_at OR (t.first_submitted_at IS NULL AND t.due_at < now()))
      GROUP BY w.category`, P);
  for (const x of impededLate) bottlenecks.push({ type: 'impediment_delay', title: `Nhiệm vụ chậm do trở ngại: ${CAT_VI[x.category] || x.category}`, detail: `${x.n} nhiệm vụ bị chậm có trở ngại đã xác nhận`, action: 'Ưu tiên khắc phục nguồn gây trở ngại; xem xét bảo trì/dự phòng thiết bị, vật tư.' });
  const otIssue = overtime.by_cause.filter((c: any) => ['incident', 'workload', 'ad_hoc'].includes(c.ot_type) && c.minutes >= 240);
  for (const c of otIssue as any[]) bottlenecks.push({ type: 'overtime', title: `Tăng ca do ${OT_VI[c.ot_type] || c.ot_type}`, detail: `${Math.round(c.minutes / 6) / 10} giờ trong kỳ`, action: c.ot_type === 'workload' ? 'Rà soát phân bổ nguồn lực/khối lượng.' : 'Phân tích nguyên nhân gốc, giảm sự cố/yêu cầu đột xuất.' });
  for (const b of breaches.filter((x) => x.stage !== 'manager_review')) bottlenecks.push({ type: 'department_sla', title: `Bộ phận ${b.department || 'chưa phân'} vi phạm SLA ${STAGE_VI[b.stage] || b.stage}`, detail: `${b.n} báo cáo bị chuyển cấp tự động`, action: 'Rà soát năng lực xử lý và quy trình tiếp nhận của bộ phận.' });
  for (const b of breaches.filter((x) => x.stage === 'manager_review')) bottlenecks.push({ type: 'manager_slow', title: `Quản lý chậm tiếp nhận/chuyển báo cáo: ${b.from_name}`, detail: `${b.n} báo cáo quá SLA tiếp nhận`, action: 'Nhắc trách nhiệm tiếp nhận; cân nhắc người ủy quyền.' });
  for (const b of wrEsc) bottlenecks.push({ type: 'manager_slow', title: `Quản lý chậm xác nhận bản ghi công việc: ${b.from_name}`, detail: `${b.n} bản ghi quá hạn phản hồi`, action: 'Nhắc nghĩa vụ phản hồi trong SLA.' });
  const recurring = Object.entries(countBy(reports.filter((r) => r.asset), 'asset')).filter(([, n]) => (n as number) >= 2);
  for (const [asset, n] of recurring) bottlenecks.push({ type: 'recurring', title: `Vấn đề tái diễn: ${asset}`, detail: `${n} báo cáo trong kỳ`, action: 'Điều tra nguyên nhân gốc, thay thế/nâng cấp thiết bị.' });
  const violations = await q(
    `SELECT u.name, count(*)::int AS n FROM permits p JOIN company_members cm ON cm.id=p.requested_by JOIN users u ON u.id=cm.user_id
      WHERE p.company_id=$1 AND p.review_status='violation' AND p.reviewed_at >= $2 AND p.reviewed_at < $3 GROUP BY u.name`, P);
  for (const v of violations) bottlenecks.push({ type: 'permit_violation', title: `Vi phạm quy trình giấy phép: ${v.name}`, detail: `${v.n} giấy phép bị hậu kiểm là sai quy trình`, action: 'Nhắc lại quy trình cấp phép; hạn chế quyền khai báo tự động nếu tái diễn.' });
  const cross = await q1(
    `SELECT count(*) FILTER (WHERE ut.cause='support_other_dept' OR ut.category='external_support')::int AS cross, count(*)::int AS total
       FROM tasks t LEFT JOIN unexpected_tasks ut ON ut.task_id=t.id WHERE t.company_id=$1 AND t.created_at >= $2 AND t.created_at < $3`, P);
  const procReports = reports.filter((r) => r.category === 'process' && r.affected_task_id).length;
  if (cross.total > 0 && (cross.cross + procReports) / cross.total >= 0.15) {
    bottlenecks.push({ type: 'cross_department', title: 'Tỷ lệ nhiệm vụ bị ảnh hưởng bởi phối hợp liên phòng ban cao', detail: `${r2((100 * (cross.cross + procReports)) / cross.total)}% nhiệm vụ`, action: 'Làm rõ đầu mối/quy trình phối hợp giữa các bộ phận.' });
  }

  const es = memberList.map((m) => m.E).filter((x) => x !== null) as number[];
  const summary = {
    tasks: tsum, avg_E: es.length ? r2(es.reduce((a, b) => a + b, 0) / es.length) : null,
    unexpected: {
      common: { count: unexpectedAgg.common.count, P: r2(unexpectedAgg.common.sumW ? unexpectedAgg.common.sumC / unexpectedAgg.common.sumW : null) },
      diverse: { count: unexpectedAgg.diverse.count, P: r2(unexpectedAgg.diverse.sumW ? unexpectedAgg.diverse.sumC / unexpectedAgg.diverse.sumW : null) },
    },
    work_records: wrStats(wrRows), overtime_minutes: overtime.total_minutes, workplace_reports: reports.length,
  };

  let comparison: any = null;
  if (!opts.light) {
    const prev = await buildReport(companyId, previousPeriod(period, company.timezone), scope, { light: true });
    const pairs: [string, number | null, number | null][] = [
      ['Nhiệm vụ hoàn thành', summary.tasks.completed, prev.summary.tasks.completed],
      ['Nhiệm vụ quá hạn', summary.tasks.overdue, prev.summary.tasks.overdue],
      ['Điểm hiệu suất TB', summary.avg_E, prev.summary.avg_E],
      ['Giờ tăng ca', r2(summary.overtime_minutes / 60), r2(prev.summary.overtime_minutes / 60)],
      ['Báo cáo trở ngại', summary.workplace_reports, prev.summary.workplace_reports],
      ['Bản ghi tự khai báo', summary.work_records.submitted, prev.summary.work_records.submitted],
    ];
    comparison = {
      previous_period: prev.meta.period,
      items: pairs.map(([label, cur, pv]) => {
        const delta = cur !== null && pv !== null ? r2(cur - pv) : null;
        const pct = cur !== null && pv ? r2((100 * (cur - pv)) / pv) : null;
        return { label, current: cur, previous: pv, delta, pct, significant: pct !== null && Math.abs(pct) >= 20 };
      }),
    };
    comparison.notes = comparison.items.filter((i: any) => i.significant).map((i: any) =>
      `${i.label} ${i.delta > 0 ? 'tăng' : 'giảm'} ${Math.abs(i.pct)}% so với kỳ trước (${i.previous} → ${i.current}).`);
  }

  return {
    meta: {
      period: { type: period.type, key: period.key, label: period.label, start: period.startDate, end: period.endDate },
      scope, company: company.name, timezone: company.timezone, formula_version: version, config, generated_at: new Date().toISOString(),
      notes: [
        'Điểm tự động chỉ mang tính tham khảo; không dùng làm quyết định duy nhất cho thưởng, kỷ luật, thăng chức hoặc chấm dứt hợp đồng (D10).',
        'Giờ tăng ca không được cộng vào điểm hiệu suất.',
        'Bản ghi đang tranh chấp/khiếu nại hiển thị riêng, chưa tính như kết quả đã xác nhận.',
        'Nhiệm vụ trễ hạn có trở ngại khách quan đã xác nhận không bị trừ điểm tiến độ; nhiệm vụ hủy không tính là thất bại.',
      ],
    },
    summary, members: memberList, groups, overtime, workplace, bottlenecks, comparison,
  };
}

async function buildCohortMax(companyId: string, period: Period, cfg: PerformanceConfig) {
  const members = await q(`SELECT id AS member_id, role FROM company_members WHERE company_id=$1 AND status='active'`, [companyId]);
  const rows: TaskRow[] = await q(
    `SELECT t.id AS task_id, ta.company_member_id AS member_id, ta.assignment_type,
            (SELECT count(*) FROM task_assignees x WHERE x.task_id=t.id AND x.active AND x.assignment_type='collaborator')::int AS n_collab,
            t.complexity, t.requirement_level, t.is_unexpected, NULL AS requirement_structure, t.status, t.due_at, t.first_submitted_at, t.completed_at,
            t.revision_count, false AS impediment_confirmed, ev.total_score, ev.scores
       FROM tasks t JOIN task_assignees ta ON ta.task_id=t.id AND ta.active
       LEFT JOIN LATERAL (SELECT total_score, scores FROM task_evaluations e WHERE e.task_id=t.id AND e.decision='approved' ORDER BY created_at DESC LIMIT 1) ev ON true
      WHERE t.company_id=$1 AND t.status='completed' AND t.completed_at >= $2 AND t.completed_at < $3`, [companyId, period.start, period.end]);
  return scoreMembers(rows, members, cfg).maxByRole;
}
