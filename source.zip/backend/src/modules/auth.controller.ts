import { Body, Controller, Get, Post } from '@nestjs/common';
import * as bcrypt from 'bcryptjs';
import * as jwt from 'jsonwebtoken';
import { createHash, randomBytes } from 'crypto';
import { q, q1, tx } from '../db/db';
import { Public, jwtSecret } from '../common/auth.guard';
import { CurrentCtx, Ctx } from '../common/context';
import { AppError, Errors } from '../common/errors';
import { parse, z } from '../common/validate';
import { DEFAULT_PERFORMANCE, DEFAULT_SETTINGS, DEFAULT_SLA, DEFAULT_TASK_TYPES } from '../common/defaults';
import { audit } from '../common/audit';

const ACCESS_TTL = '30m';
const REFRESH_DAYS = 30;
const MAX_FAILED = 10;

const sha = (s: string) => createHash('sha256').update(s).digest('hex');

export async function issueTokens(userId: string, memberId: string) {
  const access_token = jwt.sign({ sub: userId, mid: memberId }, jwtSecret(), { expiresIn: ACCESS_TTL });
  const refresh = randomBytes(32).toString('hex');
  await q(`INSERT INTO refresh_tokens(user_id, token_hash, expires_at) VALUES ($1,$2, now() + interval '${REFRESH_DAYS} days')`, [userId, sha(refresh)]);
  return { access_token, refresh_token: refresh };
}

async function memberships(userId: string) {
  return q(
    `SELECT cm.id AS member_id, cm.company_id, c.name AS company_name, cm.role
       FROM company_members cm JOIN companies c ON c.id=cm.company_id
      WHERE cm.user_id=$1 AND cm.status='active' ORDER BY cm.joined_at`, [userId]);
}

/** Khởi tạo công ty mới với cấu hình mặc định (dùng cho Owner đăng ký và cho seed). */
export async function createCompanyWithOwner(input: { companyName: string; name: string; email: string; password: string; timezone?: string }) {
  return tx(async (c) => {
    const exists = await q1(`SELECT id FROM users WHERE lower(email)=lower($1)`, [input.email], c);
    if (exists) throw new AppError('EMAIL_TAKEN', 'Email đã được sử dụng', 409);
    const company = await q1(`INSERT INTO companies(name, timezone, settings) VALUES ($1,$2,$3) RETURNING *`,
      [input.companyName, input.timezone || 'Asia/Ho_Chi_Minh', JSON.stringify(DEFAULT_SETTINGS)], c);
    const user = await q1(`INSERT INTO users(name, email, password_hash) VALUES ($1,lower($2),$3) RETURNING id`,
      [input.name, input.email, await bcrypt.hash(input.password, 10)], c);
    const member = await q1(`INSERT INTO company_members(company_id, user_id, role, title) VALUES ($1,$2,'owner','Chủ doanh nghiệp') RETURNING id`,
      [company.id, user.id], c);
    for (const s of DEFAULT_SLA) {
      await q(`INSERT INTO sla_configs(company_id, severity, manager_review_minutes, acknowledge_minutes, resolve_minutes) VALUES ($1,$2,$3,$4,$5)`,
        [company.id, s.severity, s.manager_review_minutes, s.acknowledge_minutes, s.resolve_minutes], c);
    }
    for (const t of DEFAULT_TASK_TYPES) await q(`INSERT INTO task_types(company_id, name) VALUES ($1,$2)`, [company.id, t], c);
    await q(`INSERT INTO performance_configs(company_id, version, config, created_by) VALUES ($1,1,$2,$3)`,
      [company.id, JSON.stringify(DEFAULT_PERFORMANCE), member.id], c);
    await audit(c, { companyId: company.id, memberId: member.id }, 'company', company.id, 'company.created');
    return { companyId: company.id, userId: user.id, memberId: member.id };
  });
}

@Controller('auth')
export class AuthController {
  @Public()
  @Post('register-company')
  async register(@Body() body: any) {
    const b = parse(z.object({
      companyName: z.string().trim().min(2), name: z.string().trim().min(2),
      email: z.string().email(), password: z.string().min(8, 'Mật khẩu tối thiểu 8 ký tự'),
      timezone: z.string().optional(),
    }), body);
    const r = await createCompanyWithOwner(b);
    return { ...(await issueTokens(r.userId, r.memberId)), memberships: await memberships(r.userId) };
  }

  @Public()
  @Post('login')
  async login(@Body() body: any) {
    const b = parse(z.object({ email: z.string().email(), password: z.string().min(1), companyId: z.string().uuid().optional() }), body);
    const u = await q1(`SELECT * FROM users WHERE lower(email)=lower($1)`, [b.email]);
    if (!u) throw new AppError('INVALID_CREDENTIALS', 'Email hoặc mật khẩu không đúng', 401);
    if (u.status === 'locked') throw new AppError('ACCOUNT_LOCKED', 'Tài khoản đã bị khóa. Liên hệ quản trị viên.', 423);
    if (!(await bcrypt.compare(b.password, u.password_hash))) {
      await q(`UPDATE users SET failed_logins=failed_logins+1, status=CASE WHEN failed_logins+1>=$2 THEN 'locked' ELSE status END WHERE id=$1`, [u.id, MAX_FAILED]);
      throw new AppError('INVALID_CREDENTIALS', 'Email hoặc mật khẩu không đúng', 401);
    }
    await q(`UPDATE users SET failed_logins=0 WHERE id=$1`, [u.id]);
    const ms = await memberships(u.id);
    if (!ms.length) throw new AppError('NO_COMPANY', 'Tài khoản chưa thuộc công ty nào', 403);
    const m = (b.companyId && ms.find((x) => x.company_id === b.companyId)) || ms[0];
    return { ...(await issueTokens(u.id, m.member_id)), memberships: ms, member_id: m.member_id };
  }

  @Public()
  @Post('refresh')
  async refresh(@Body() body: any) {
    const b = parse(z.object({ refresh_token: z.string().min(10), memberId: z.string().uuid().optional() }), body);
    const t = await q1(`SELECT * FROM refresh_tokens WHERE token_hash=$1 AND revoked_at IS NULL AND expires_at > now()`, [sha(b.refresh_token)]);
    if (!t) throw Errors.unauthorized('Phiên đăng nhập đã hết hạn');
    await q(`UPDATE refresh_tokens SET revoked_at=now() WHERE id=$1`, [t.id]); // rotation
    const ms = await memberships(t.user_id);
    const m = (b.memberId && ms.find((x) => x.member_id === b.memberId)) || ms[0];
    if (!m) throw Errors.unauthorized();
    return { ...(await issueTokens(t.user_id, m.member_id)), memberships: ms, member_id: m.member_id };
  }

  @Post('logout')
  async logout(@Body() body: any, @CurrentCtx() ctx: Ctx) {
    if (body?.all) await q(`UPDATE refresh_tokens SET revoked_at=now() WHERE user_id=$1 AND revoked_at IS NULL`, [ctx.userId]);
    else if (body?.refresh_token) await q(`UPDATE refresh_tokens SET revoked_at=now() WHERE token_hash=$1 AND user_id=$2`, [sha(body.refresh_token), ctx.userId]);
    return { ok: true };
  }

  @Post('switch-company')
  async switchCompany(@Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({ companyId: z.string().uuid() }), body);
    const ms = await memberships(ctx.userId);
    const m = ms.find((x) => x.company_id === b.companyId);
    if (!m) throw Errors.forbidden('Bạn không thuộc công ty này');
    return { ...(await issueTokens(ctx.userId, m.member_id)), memberships: ms, member_id: m.member_id };
  }

  @Post('change-password')
  async changePassword(@Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({ oldPassword: z.string(), newPassword: z.string().min(8) }), body);
    const u = await q1(`SELECT password_hash FROM users WHERE id=$1`, [ctx.userId]);
    if (!(await bcrypt.compare(b.oldPassword, u.password_hash))) throw new AppError('INVALID_CREDENTIALS', 'Mật khẩu hiện tại không đúng', 422);
    await q(`UPDATE users SET password_hash=$2 WHERE id=$1`, [ctx.userId, await bcrypt.hash(b.newPassword, 10)]);
    await q(`UPDATE refresh_tokens SET revoked_at=now() WHERE user_id=$1 AND revoked_at IS NULL`, [ctx.userId]);
    return { ok: true };
  }

  @Get('me')
  async me(@CurrentCtx() ctx: Ctx) {
    const m = await q1(
      `SELECT cm.id AS member_id, cm.role, cm.title, cm.company_id, cm.department_id, cm.supervisor_member_id,
              u.id AS user_id, u.name, u.email, u.phone, c.name AS company_name, c.timezone
         FROM company_members cm JOIN users u ON u.id=cm.user_id JOIN companies c ON c.id=cm.company_id WHERE cm.id=$1`, [ctx.memberId]);
    const managed = await q(`SELECT id, name FROM groups WHERE manager_member_id=$1 AND deleted_at IS NULL`, [ctx.memberId]);
    const dept = await q(`SELECT id, name FROM departments WHERE head_member_id=$1`, [ctx.memberId]);
    return { ...m, managed_groups: managed, headed_departments: dept, memberships: await memberships(ctx.userId) };
  }
}
