import { Body, Controller, Get, Post } from '@nestjs/common';
import { PoolClient } from 'pg';
import * as bcrypt from 'bcryptjs';
import * as jwt from 'jsonwebtoken';
import { createHash, randomBytes } from 'crypto';
import { q, q1, tx } from '../db/db';
import { AllowNoCompany, Public, jwtSecret } from '../common/auth.guard';
import { CurrentCtx, Ctx } from '../common/context';
import { AppError, Errors } from '../common/errors';
import { parse, z } from '../common/validate';
import { DEFAULT_PERFORMANCE, DEFAULT_SETTINGS, DEFAULT_SLA, DEFAULT_TASK_TYPES } from '../common/defaults';
import { audit } from '../common/audit';
import { isPhoneLike, normalizePhone } from '../common/phone';
import { PLANS } from './plans';
import { ensureCompanyLibrary } from './library';

const ACCESS_TTL = '30m';
const REFRESH_DAYS = 30;
const MAX_FAILED = 10;

const sha = (s: string) => createHash('sha256').update(s).digest('hex');

export async function issueTokens(userId: string, memberId: string | null) {
  const access_token = jwt.sign({ sub: userId, mid: memberId }, jwtSecret(), { expiresIn: ACCESS_TTL });
  const refresh = randomBytes(32).toString('hex');
  await q(`INSERT INTO refresh_tokens(user_id, token_hash, expires_at) VALUES ($1,$2, now() + interval '${REFRESH_DAYS} days')`, [userId, sha(refresh)]);
  return { access_token, refresh_token: refresh };
}

export async function memberships(userId: string) {
  return q(
    `SELECT cm.id AS member_id, cm.company_id, c.name AS company_name, cm.role
       FROM company_members cm JOIN companies c ON c.id=cm.company_id
      WHERE cm.user_id=$1 AND cm.status='active' ORDER BY cm.joined_at`, [userId]);
}

async function session(userId: string, preferCompany?: string | null, preferMember?: string | null) {
  const ms = await memberships(userId);
  const m = (preferMember && ms.find((x) => x.member_id === preferMember)) || (preferCompany && ms.find((x) => x.company_id === preferCompany)) || ms[0] || null;
  return { ...(await issueTokens(userId, m?.member_id ?? null)), memberships: ms, member_id: m?.member_id ?? null };
}

/** Tạo doanh nghiệp cho một người dùng (người đó là Owner) với cấu hình mặc định. */
export async function createCompanyForUser(c: PoolClient, userId: string, o: { companyName: string; contactEmail?: string | null; plan?: string | null; timezone?: string }) {
  const plan = o.plan ? PLANS[o.plan] : null;
  const company = await q1(
    `INSERT INTO companies(name, timezone, settings, plan, member_limit, contact_email, plan_expires_at)
     VALUES ($1,$2,$3,$4,$5,$6, CASE WHEN $4::text IS NULL THEN NULL ELSE now() + interval '12 months' END) RETURNING *`,
    [o.companyName, o.timezone || 'Asia/Ho_Chi_Minh', JSON.stringify(DEFAULT_SETTINGS), o.plan ?? null, plan?.member_limit ?? null, o.contactEmail ?? null], c);
  const member = await q1(`INSERT INTO company_members(company_id, user_id, role, title) VALUES ($1,$2,'owner','Chủ doanh nghiệp') RETURNING id`, [company.id, userId], c);
  for (const s of DEFAULT_SLA) {
    await q(`INSERT INTO sla_configs(company_id, severity, manager_review_minutes, acknowledge_minutes, resolve_minutes) VALUES ($1,$2,$3,$4,$5)`,
      [company.id, s.severity, s.manager_review_minutes, s.acknowledge_minutes, s.resolve_minutes], c);
  }
  for (const t of DEFAULT_TASK_TYPES) await q(`INSERT INTO task_types(company_id, name) VALUES ($1,$2)`, [company.id, t], c);
  await ensureCompanyLibrary(c, company.id);
  await q(`INSERT INTO performance_configs(company_id, version, config, created_by) VALUES ($1,1,$2,$3)`, [company.id, JSON.stringify(DEFAULT_PERFORMANCE), member.id], c);
  await audit(c, { companyId: company.id, memberId: member.id }, 'company', company.id, 'company.created', null, { plan: o.plan });
  return { companyId: company.id as string, memberId: member.id as string };
}

/** Tạo người dùng mới + doanh nghiệp (dùng cho seed/kiểm thử). */
export async function createCompanyWithOwner(input: { companyName: string; name: string; email?: string; phone?: string; password: string; timezone?: string; plan?: string }) {
  return tx(async (c) => {
    if (input.email && await q1(`SELECT id FROM users WHERE lower(email)=lower($1)`, [input.email], c)) throw new AppError('EMAIL_TAKEN', 'Email đã được sử dụng', 409);
    const phone = input.phone ? normalizePhone(input.phone) : null;
    if (phone && await q1(`SELECT id FROM users WHERE phone=$1`, [phone], c)) throw new AppError('PHONE_TAKEN', 'Số điện thoại đã được đăng ký', 409);
    const user = await q1(`INSERT INTO users(name, email, phone, password_hash) VALUES ($1,lower($2),$3,$4) RETURNING id`,
      [input.name, input.email ?? null, phone, await bcrypt.hash(input.password, 10)], c);
    const r = await createCompanyForUser(c, user.id, { companyName: input.companyName, plan: input.plan ?? 'medium', contactEmail: input.email, timezone: input.timezone });
    return { ...r, userId: user.id as string };
  });
}

@Controller('auth')
export class AuthController {
  /** Đăng ký tài khoản cá nhân bằng SĐT. Nếu SĐT đã được doanh nghiệp thêm trước (tài khoản "invited") thì kích hoạt tài khoản đó. */
  @Public()
  @Post('register')
  async register(@Body() body: any) {
    const b = parse(z.object({
      phone: z.string().min(9), name: z.string().trim().min(4, 'Nhập họ và tên đầy đủ'),
      password: z.string().min(8, 'Mật khẩu tối thiểu 8 ký tự'), email: z.string().email().optional().or(z.literal('')),
    }), body);
    const phone = normalizePhone(b.phone);
    const userId = await tx(async (c) => {
      const ex = await q1(`SELECT * FROM users WHERE phone=$1`, [phone], c);
      if (ex && ex.status !== 'invited') throw new AppError('PHONE_TAKEN', 'Số điện thoại đã được đăng ký. Vui lòng đăng nhập.', 409);
      if (b.email && await q1(`SELECT id FROM users WHERE lower(email)=lower($1) AND id IS DISTINCT FROM $2`, [b.email, ex?.id ?? null], c)) {
        throw new AppError('EMAIL_TAKEN', 'Email đã được sử dụng', 409);
      }
      const hash = await bcrypt.hash(b.password, 10);
      if (ex) {
        await q(`UPDATE users SET name=$2, password_hash=$3, status='active', email=COALESCE(NULLIF(lower($4),''), email) WHERE id=$1`, [ex.id, b.name, hash, b.email || null], c);
        return ex.id;
      }
      const u = await q1(`INSERT INTO users(name, phone, email, password_hash) VALUES ($1,$2,NULLIF(lower($3),''),$4) RETURNING id`, [b.name, phone, b.email || null, hash], c);
      return u.id;
    });
    return session(userId);
  }

  @Public()
  @Post('login')
  async login(@Body() body: any) {
    const b = parse(z.object({
      phone: z.string().optional(), email: z.string().optional(), identifier: z.string().optional(),
      password: z.string().min(1), companyId: z.string().uuid().optional(),
    }), body);
    const id = (b.identifier || b.phone || b.email || '').trim();
    if (!id) throw Errors.validation('Nhập số điện thoại');
    const u = id.includes('@')
      ? await q1(`SELECT * FROM users WHERE lower(email)=lower($1)`, [id])
      : isPhoneLike(id) ? await q1(`SELECT * FROM users WHERE phone=$1`, [normalizePhone(id)]) : null;
    if (!u || !u.password_hash) throw new AppError('INVALID_CREDENTIALS', u?.status === 'invited' ? 'Số điện thoại đã được doanh nghiệp thêm nhưng chưa kích hoạt. Hãy chọn "Đăng ký" để đặt mật khẩu.' : 'Số điện thoại hoặc mật khẩu không đúng', 401);
    if (u.status === 'locked') throw new AppError('ACCOUNT_LOCKED', 'Tài khoản đã bị khóa. Liên hệ quản trị viên.', 423);
    if (!(await bcrypt.compare(b.password, u.password_hash))) {
      await q(`UPDATE users SET failed_logins=failed_logins+1, status=CASE WHEN failed_logins+1>=$2 THEN 'locked' ELSE status END WHERE id=$1`, [u.id, MAX_FAILED]);
      throw new AppError('INVALID_CREDENTIALS', 'Số điện thoại hoặc mật khẩu không đúng', 401);
    }
    await q(`UPDATE users SET failed_logins=0 WHERE id=$1`, [u.id]);
    return session(u.id, b.companyId);
  }

  @Public()
  @Post('refresh')
  async refresh(@Body() body: any) {
    const b = parse(z.object({ refresh_token: z.string().min(10), memberId: z.string().uuid().optional() }), body);
    const t = await q1(`SELECT * FROM refresh_tokens WHERE token_hash=$1 AND revoked_at IS NULL AND expires_at > now()`, [sha(b.refresh_token)]);
    if (!t) throw Errors.unauthorized('Phiên đăng nhập đã hết hạn');
    const u = await q1(`SELECT status FROM users WHERE id=$1`, [t.user_id]);
    if (u?.status !== 'active') throw Errors.unauthorized('Tài khoản đã bị khóa');
    await q(`UPDATE refresh_tokens SET revoked_at=now() WHERE id=$1`, [t.id]); // rotation
    return session(t.user_id, null, b.memberId);
  }

  @AllowNoCompany()
  @Post('logout')
  async logout(@Body() body: any, @CurrentCtx() ctx: Ctx) {
    if (body?.all) await q(`UPDATE refresh_tokens SET revoked_at=now() WHERE user_id=$1 AND revoked_at IS NULL`, [ctx.userId]);
    else if (body?.refresh_token) await q(`UPDATE refresh_tokens SET revoked_at=now() WHERE token_hash=$1 AND user_id=$2`, [sha(body.refresh_token), ctx.userId]);
    return { ok: true };
  }

  @AllowNoCompany()
  @Post('switch-company')
  async switchCompany(@Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({ companyId: z.string().uuid() }), body);
    const ms = await memberships(ctx.userId);
    if (!ms.find((x) => x.company_id === b.companyId)) throw Errors.forbidden('Bạn không thuộc công ty này');
    return session(ctx.userId, b.companyId);
  }

  @AllowNoCompany()
  @Post('change-password')
  async changePassword(@Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({ oldPassword: z.string(), newPassword: z.string().min(8) }), body);
    const u = await q1(`SELECT password_hash FROM users WHERE id=$1`, [ctx.userId]);
    if (!(await bcrypt.compare(b.oldPassword, u.password_hash))) throw new AppError('INVALID_CREDENTIALS', 'Mật khẩu hiện tại không đúng', 422);
    await q(`UPDATE users SET password_hash=$2 WHERE id=$1`, [ctx.userId, await bcrypt.hash(b.newPassword, 10)]);
    await q(`UPDATE refresh_tokens SET revoked_at=now() WHERE user_id=$1 AND revoked_at IS NULL`, [ctx.userId]);
    return { ok: true };
  }

  @AllowNoCompany()
  @Get('me')
  async me(@CurrentCtx() ctx: Ctx) {
    const u = await q1(
      `SELECT u.id AS user_id, u.name, u.email, u.phone, u.is_platform_admin, EXISTS (SELECT 1 FROM user_avatars a WHERE a.user_id=u.id) AS has_avatar
         FROM users u WHERE u.id=$1`, [ctx.userId]);
    const pending = await q(`SELECT cm.id, c.name AS company_name, cm.status FROM company_members cm JOIN companies c ON c.id=cm.company_id
                              WHERE cm.user_id=$1 AND cm.status='pending_hr'`, [ctx.userId]);
    const subs = await q(`SELECT id, plan, company_name, status, created_at FROM subscriptions WHERE user_id=$1 ORDER BY created_at DESC LIMIT 5`, [ctx.userId]);
    const base = { ...u, memberships: await memberships(ctx.userId), pending_memberships: pending, subscriptions: subs };
    if (!ctx.memberId) return { ...base, member_id: null, role: null, company_id: null, managed_groups: [], headed_departments: [] };
    const m = await q1(
      `SELECT cm.id AS member_id, cm.role, cm.title, cm.company_id, cm.department_id, cm.supervisor_member_id,
              c.name AS company_name, c.timezone, c.plan, c.member_limit
         FROM company_members cm JOIN companies c ON c.id=cm.company_id WHERE cm.id=$1`, [ctx.memberId]);
    const managed = await q(`SELECT id, name FROM groups WHERE manager_member_id=$1 AND deleted_at IS NULL`, [ctx.memberId]);
    const dept = await q(`SELECT id, name FROM departments WHERE head_member_id=$1`, [ctx.memberId]);
    return { ...base, ...m, managed_groups: managed, headed_departments: dept };
  }
}
