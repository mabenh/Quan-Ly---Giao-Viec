/**
 * Thư viện mặc định cho mỗi doanh nghiệp: mẫu giao việc, loại giấy phép, quy trình & thủ tục.
 * Hàm ensureCompanyLibrary chạy idempotent (khi tạo công ty và khi migrate) — chỉ thêm mục còn thiếu, không ghi đè bản công ty đã sửa.
 */
import { q, q1, Queryable } from '../db/db';

type F = { key: string; label: string; type?: 'text' | 'textarea' | 'number' | 'date' | 'datetime'; required?: boolean };
const f = (key: string, label: string, type: F['type'] = 'text', required = false): F => ({ key, label, type, required });

export const EXTRA_TASK_TYPES = ['Kho vận', 'Bảo vệ - An ninh', 'Chất lượng', 'Sản xuất'];

export const DEFAULT_TEMPLATES = [
  { key: 'nhap_kho', name: 'Nhập kho hàng hóa', icon: 'package-plus', category: 'Kho vận', type: 'Kho vận', complexity: 'medium', hours: 4,
    description: 'Tiếp nhận, kiểm đếm và nhập kho hàng hóa theo phiếu nhập.',
    fields: [f('so_phieu', 'Số phiếu nhập', 'text', true), f('nha_cung_cap', 'Nhà cung cấp'), f('hang_hoa', 'Mặt hàng & số lượng', 'textarea', true), f('vi_tri', 'Vị trí lưu kho')],
    criteria: ['Kiểm đếm đủ số lượng, đúng chủng loại, chất lượng theo phiếu', 'Phiếu nhập có chữ ký giao – nhận', 'Hàng xếp đúng vị trí và đã cập nhật số liệu tồn kho'], permits: ['equipment_use'] },
  { key: 'xuat_kho', name: 'Xuất kho', icon: 'package-minus', category: 'Kho vận', type: 'Kho vận', complexity: 'simple', hours: 3,
    description: 'Soạn hàng và xuất kho theo phiếu xuất/đơn hàng.',
    fields: [f('so_phieu', 'Số phiếu xuất', 'text', true), f('nguoi_nhan', 'Người/bộ phận nhận'), f('hang_hoa', 'Mặt hàng & số lượng', 'textarea', true)],
    criteria: ['Xuất đúng mặt hàng, số lượng theo phiếu', 'Có chữ ký người nhận', 'Cập nhật tồn kho ngay sau khi xuất'], permits: ['goods_out', 'equipment_use'] },
  { key: 'xu_ly_nguyen_lieu', name: 'Xử lý nguyên liệu', icon: 'flask', category: 'Sản xuất', type: 'Sản xuất', complexity: 'medium', hours: 6,
    description: 'Sơ chế/xử lý nguyên liệu theo công đoạn và tiêu chuẩn kỹ thuật.',
    fields: [f('nguyen_lieu', 'Loại nguyên liệu', 'text', true), f('khoi_luong', 'Khối lượng/số lượng', 'text', true), f('cong_doan', 'Công đoạn xử lý'), f('tieu_chuan', 'Tiêu chuẩn cần đạt', 'textarea')],
    criteria: ['Nguyên liệu sau xử lý đạt tiêu chuẩn đã nêu', 'Ghi nhật ký công đoạn (thời gian, khối lượng hao hụt)', 'Vệ sinh khu vực và thiết bị sau khi làm'], permits: ['equipment_use'] },
  { key: 'giao_hang', name: 'Giao hàng cho khách', icon: 'truck', category: 'Giao nhận', type: 'Vận hành', complexity: 'simple', hours: 4,
    description: 'Giao hàng đến khách hàng đúng hẹn, thu chứng từ/tiền (nếu có).',
    fields: [f('ma_don', 'Mã đơn hàng', 'text', true), f('khach_hang', 'Khách hàng', 'text', true), f('dia_chi', 'Địa chỉ giao', 'text', true), f('sdt_nhan', 'SĐT người nhận'), f('gio_hen', 'Thời gian hẹn giao', 'datetime'), f('cod', 'Số tiền thu hộ (nếu có)', 'number')],
    criteria: ['Giao đúng địa chỉ, đúng hẹn', 'Có biên bản/ảnh xác nhận người nhận', 'Tiền thu hộ (nếu có) nộp đủ trong ngày'], permits: ['gate_pass', 'vehicle_use', 'goods_out'] },
  { key: 'hang_ton', name: 'Giải quyết hàng tồn', icon: 'boxes', category: 'Kho vận', type: 'Kho vận', complexity: 'complex', hours: 16,
    description: 'Rà soát hàng tồn lâu ngày/cận date, đề xuất và triển khai phương án giải phóng tồn.',
    fields: [f('ma_hang', 'Mã hàng/lô', 'text', true), f('so_luong', 'Số lượng tồn', 'number'), f('han_dung', 'Hạn sử dụng', 'date'), f('phuong_an', 'Phương án đề xuất', 'textarea')],
    criteria: ['Danh sách tồn được phân loại (bán được/khuyến mãi/thanh lý/hủy)', 'Phương án được quản lý duyệt', 'Số lượng tồn giảm theo mục tiêu đã thống nhất'], permits: [] },
  { key: 'bao_ve_ca', name: 'Bảo vệ ca trực', icon: 'shield', category: 'An ninh', type: 'Bảo vệ - An ninh', complexity: 'simple', hours: 8,
    description: 'Trực bảo vệ theo ca, tuần tra và kiểm soát ra vào.',
    fields: [f('ca', 'Ca trực (vd 06:00–14:00)', 'text', true), f('chot', 'Vị trí/chốt trực', 'text', true), f('so_nguoi', 'Số người trong ca', 'number')],
    criteria: ['Sổ giao ca ghi đủ tình hình đầu/cuối ca', 'Tuần tra theo lịch, ghi giờ từng lượt', 'Kiểm soát ra vào đúng giấy phép; sự cố báo ngay trên app'], permits: [] },
  { key: 'khieu_nai', name: 'Giải quyết khiếu nại khách hàng', icon: 'message-alert', category: 'Khách hàng', type: 'Hỗ trợ khách hàng', complexity: 'medium', hours: 8,
    description: 'Tiếp nhận, xác minh và giải quyết khiếu nại của khách hàng.',
    fields: [f('ma_khieu_nai', 'Mã khiếu nại/đơn hàng'), f('khach_hang', 'Khách hàng', 'text', true), f('sdt', 'SĐT khách'), f('noi_dung', 'Nội dung khiếu nại', 'textarea', true), f('han_phan_hoi', 'Hạn phản hồi khách', 'datetime')],
    criteria: ['Liên hệ khách trong 24 giờ kể từ khi nhận', 'Xác minh rõ nguyên nhân, có bằng chứng', 'Phương án được khách chấp nhận và hồ sơ được đóng'], permits: [] },
  { key: 'hang_loi', name: 'Thụ lý hàng lỗi', icon: 'package-x', category: 'Chất lượng', type: 'Chất lượng', complexity: 'medium', hours: 6,
    description: 'Tiếp nhận, cách ly, lập biên bản và xử lý hàng lỗi.',
    fields: [f('ma_hang', 'Mã hàng', 'text', true), f('so_luong', 'Số lượng lỗi', 'number', true), f('mo_ta_loi', 'Mô tả lỗi', 'textarea', true), f('nguon', 'Nguồn (khách trả/nội bộ/NCC)')],
    criteria: ['Hàng lỗi được cách ly, dán nhãn', 'Có biên bản kèm ảnh', 'Đã phân loại xử lý: sửa / hủy / trả nhà cung cấp'], permits: ['goods_out'] },
  { key: 'kiem_ke', name: 'Kiểm kê kho', icon: 'clipboard-check', category: 'Kho vận', type: 'Kho vận', complexity: 'complex', hours: 16,
    description: 'Kiểm kê định kỳ, đối chiếu số liệu thực tế với sổ sách.',
    fields: [f('khu_vuc', 'Khu vực kiểm kê', 'text', true), f('ngay_chot', 'Ngày chốt số liệu', 'date', true)],
    criteria: ['Kiểm đếm 100% vị trí trong khu vực', 'Biên bản kiểm kê có chữ ký', 'Chênh lệch được giải trình'], permits: ['restricted_area'] },
  { key: 'dong_goi', name: 'Đóng gói hàng', icon: 'package', category: 'Kho vận', type: 'Kho vận', complexity: 'simple', hours: 3,
    description: 'Đóng gói hàng theo quy cách cho đơn hàng.',
    fields: [f('ma_don', 'Mã đơn', 'text', true), f('so_kien', 'Số kiện', 'number'), f('quy_cach', 'Quy cách đóng gói')],
    criteria: ['Đúng quy cách, chắc chắn, có tem nhãn', 'Kèm chứng từ trong kiện', 'Ảnh kiện hàng trước khi bàn giao'], permits: [] },
  { key: 'bao_tri', name: 'Bảo trì / sửa chữa thiết bị', icon: 'wrench', category: 'Kỹ thuật', type: 'Kỹ thuật', complexity: 'medium', hours: 6,
    description: 'Kiểm tra, bảo trì hoặc sửa chữa thiết bị.',
    fields: [f('ma_thiet_bi', 'Mã thiết bị/tài sản', 'text', true), f('hien_tuong', 'Hiện tượng/hạng mục bảo trì', 'textarea', true), f('dung_may', 'Thời gian dừng máy cho phép')],
    criteria: ['Thiết bị vận hành bình thường sau xử lý', 'Biên bản bàn giao lại cho bộ phận sử dụng', 'Ghi sổ lý lịch thiết bị'], permits: ['restricted_area'] },
  { key: 've_sinh', name: 'Vệ sinh khu vực (5S)', icon: 'sparkles', category: 'Vận hành', type: 'Vận hành', complexity: 'simple', hours: 2,
    description: 'Vệ sinh, sắp xếp khu vực làm việc theo tiêu chuẩn 5S.',
    fields: [f('khu_vuc', 'Khu vực', 'text', true), f('tieu_chuan', 'Tiêu chuẩn cần đạt')],
    criteria: ['Khu vực sạch, gọn theo 5S', 'Ảnh trước/sau'], permits: [] },
  { key: 'mua_hang', name: 'Mua vật tư / hàng hóa', icon: 'cart', category: 'Hành chính', type: 'Hành chính', complexity: 'simple', hours: 4,
    description: 'Mua vật tư/hàng hóa theo đề xuất đã duyệt.',
    fields: [f('mat_hang', 'Mặt hàng & số lượng', 'textarea', true), f('ngan_sach', 'Ngân sách tối đa', 'number'), f('ncc', 'Nhà cung cấp đề xuất')],
    criteria: ['Mua đúng chủng loại, số lượng, trong ngân sách', 'Có hóa đơn/chứng từ hợp lệ', 'Bàn giao vật tư cho bộ phận sử dụng'], permits: ['gate_pass', 'vehicle_use'] },
  { key: 'tiep_khach', name: 'Tiếp đón khách / đối tác', icon: 'handshake', category: 'Kinh doanh', type: 'Kinh doanh', complexity: 'simple', hours: 2,
    description: 'Đón tiếp và làm việc với khách/đối tác.',
    fields: [f('khach', 'Khách/đối tác', 'text', true), f('thoi_gian', 'Thời gian', 'datetime', true), f('noi_dung', 'Nội dung làm việc', 'textarea')],
    criteria: ['Chuẩn bị phòng họp, tài liệu trước giờ hẹn', 'Biên bản/ghi chú cuộc làm việc gửi quản lý'], permits: ['gate_pass'] },
  { key: 'bao_cao', name: 'Báo cáo định kỳ', icon: 'chart', category: 'Hành chính', type: 'Hành chính', complexity: 'simple', hours: 3,
    description: 'Lập báo cáo định kỳ theo mẫu.',
    fields: [f('ky', 'Kỳ báo cáo', 'text', true), f('noi_dung', 'Nội dung chính cần có', 'textarea')],
    criteria: ['Đúng mẫu, đủ số liệu', 'Gửi đúng hạn'], permits: [] },
];

export const DEFAULT_PERMIT_TYPES = [
  { key: 'gate_pass', name: 'Giấy ra vào cổng', icon: 'door', tracks: 'gate', dept: ['bảo vệ', 'an ninh'],
    description: 'Cho phép người (và phương tiện) ra/vào cổng trong khung giờ ghi trên giấy.',
    fields: [f('muc_dich', 'Mục đích ra/vào', 'text', true), f('bien_so', 'Biển số xe (nếu có)'), f('nguoi_di_cung', 'Người đi cùng')] },
  { key: 'goods_out', name: 'Phiếu mang hàng / vật tư ra cổng', icon: 'package-check', tracks: 'gate', dept: ['bảo vệ', 'an ninh', 'kho'],
    description: 'Xác nhận hàng/vật tư được phép mang ra khỏi công ty.',
    fields: [f('hang_hoa', 'Danh sách hàng & số lượng', 'textarea', true), f('chung_tu', 'Số chứng từ kèm theo'), f('noi_nhan', 'Nơi nhận')] },
  { key: 'vehicle_use', name: 'Giấy sử dụng xe công ty', icon: 'car', tracks: 'equipment', dept: ['hành chính', 'đội xe'],
    description: 'Cấp xe công ty cho người thực hiện nhiệm vụ; ghi nhận nhận – trả xe.',
    fields: [f('xe', 'Loại xe / biển số', 'text', true), f('km_nhan', 'Số km lúc nhận', 'number'), f('lo_trinh', 'Lộ trình')] },
  { key: 'equipment_use', name: 'Giấy cấp sử dụng thiết bị (xe nâng, máy móc)', icon: 'forklift', tracks: 'equipment', dept: ['kho', 'kỹ thuật'],
    description: 'Cấp quyền sử dụng thiết bị trong kho/xưởng; ghi nhận nhận – trả và tình trạng thiết bị.',
    fields: [f('thiet_bi', 'Thiết bị / mã tài sản', 'text', true), f('vi_tri', 'Vị trí sử dụng'), f('tinh_trang', 'Tình trạng khi nhận')] },
  { key: 'restricted_area', name: 'Giấy vào khu vực hạn chế (kho, phòng máy)', icon: 'key', tracks: 'gate', dept: ['kho', 'kỹ thuật', 'bảo vệ'],
    description: 'Cho phép vào khu vực hạn chế trong thời gian thực hiện công việc.',
    fields: [f('khu_vuc', 'Khu vực', 'text', true), f('ly_do', 'Lý do', 'text', true)] },
];

type Proc = { key: string; title: string; category: string; audience: 'all' | 'managers' | 'department'; dept?: string[]; reminder: 'daily' | 'weekly' | 'monthly' | 'none'; summary: string; reference?: string; steps: { title: string; detail: string; role?: string }[] };
export const DEFAULT_PROCEDURES: Proc[] = [
  { key: 'giao_viec_chuan', title: 'Quy trình giao việc (bản chuẩn hóa cho công ty)', category: 'Giao việc', audience: 'managers', reminder: 'weekly',
    summary: 'Quy trình 8 bước áp dụng khi giao mọi công việc trên Việc Đến. Người giao chịu trách nhiệm chuẩn bị đủ thông tin, nguồn lực và thủ tục trước khi giao.',
    steps: [
      { title: 'Xác định việc theo 5W2H', detail: 'Làm gì, vì sao, ở đâu, khi nào, ai làm, làm thế nào, bao nhiêu. Chọn mẫu giao việc phù hợp để điền nhanh.', role: 'Người giao' },
      { title: 'Đặt tiêu chí đầu ra rõ ràng (SMART)', detail: 'Tiêu chí cụ thể, đo được, có hạn. Tiêu chí được lưu phiên bản — không đánh giá theo yêu cầu thêm sau mà không ghi nhận.', role: 'Người giao' },
      { title: 'Chọn người phù hợp', detail: 'Xem tình trạng nhân sự: nghỉ phép, số việc đang làm, đang bàn giao. Mỗi việc chỉ một người chịu trách nhiệm chính.', role: 'Người giao' },
      { title: 'Chuẩn bị giấy phép & nguồn lực trước', detail: 'Lập sẵn giấy ra vào cổng, giấy sử dụng thiết bị/xe… đính kèm việc. Không để người nhận việc tự đi xin thủ tục.', role: 'Người giao' },
      { title: 'Giao việc trên app', detail: 'Giao trực tiếp trên app. Nếu đã giao qua điện thoại/tin nhắn thì khai việc nhanh trong ngày để người nhận xác nhận.', role: 'Người giao' },
      { title: 'Theo dõi & gỡ vướng', detail: 'Theo dõi tiến độ, xử lý báo cáo trở ngại đúng SLA, điều chỉnh deadline có ghi lý do.', role: 'Người giao' },
      { title: 'Nghiệm thu đúng hạn', detail: 'Nghiệm thu theo tiêu chí đã thống nhất trong 1 ngày làm việc; yêu cầu sửa phải nêu cụ thể.', role: 'Người giao' },
      { title: 'Đánh giá & ghi nhận', detail: 'Chấm điểm công bằng theo trọng số; không trừ điểm vì trở ngại khách quan đã xác nhận.', role: 'Người giao' },
    ] },
  { key: 'giao_viec_tham_khao', title: 'Tham khảo: thực hành giao việc phổ biến tại doanh nghiệp lớn', category: 'Giao việc', audience: 'managers', reminder: 'monthly',
    summary: 'Các nguyên tắc giao việc được nhiều doanh nghiệp hàng đầu áp dụng rộng rãi. Bản chuẩn hóa của công ty ở trên đã cụ thể hóa các nguyên tắc này.',
    reference: 'Tổng hợp từ các phương pháp quản trị phổ biến: SMART (G. T. Doran, 1981), ma trận RACI, chu trình PDCA (W. E. Deming), 5W2H, nguyên tắc một người chịu trách nhiệm trực tiếp (DRI), họp 1-1 định kỳ.',
    steps: [
      { title: 'Mục tiêu SMART', detail: 'Specific – Measurable – Achievable – Relevant – Time-bound.' },
      { title: 'Phân vai RACI', detail: 'Ai thực hiện (R), ai chịu trách nhiệm cuối (A), ai cần hỏi ý kiến (C), ai cần được báo (I).' },
      { title: 'Một người chịu trách nhiệm (DRI)', detail: 'Mỗi đầu việc có đúng một người chịu trách nhiệm chính; cộng tác viên được ghi nhận riêng.' },
      { title: 'Trao quyền đi kèm nguồn lực', detail: 'Giao việc phải kèm quyền hạn, thiết bị, ngân sách và thủ tục cần thiết.' },
      { title: 'Chu trình PDCA', detail: 'Lập kế hoạch – Thực hiện – Kiểm tra – Điều chỉnh; rút kinh nghiệm sau mỗi việc lớn.' },
      { title: 'Check-in 1-1 ngắn, định kỳ', detail: 'Trao đổi ngắn về tiến độ, vướng mắc; ghi nhận kết quả thay vì chỉ đếm giờ làm.' },
    ] },
  { key: 'ban_giao', title: 'Quy trình bàn giao khi điều chuyển, thăng chức, thôi việc', category: 'Nhân sự', audience: 'all', reminder: 'monthly',
    summary: 'Nhân sự có quyết định phải bàn giao toàn bộ việc đang làm trước hạn. Chỉ khi quản lý xác nhận bàn giao, quyết định mới có hiệu lực và nhân sự mới nhận việc mới.',
    steps: [
      { title: 'Nhận quyết định trên app', detail: 'Xem quyết định, ngày hiệu lực và hạn bàn giao ở Trang chủ.', role: 'Nhân viên' },
      { title: 'Lập kế hoạch bàn giao', detail: 'Chọn người nhận cho từng việc đang làm, ghi chú tình trạng, tài liệu, mật khẩu/tài sản cần trả.', role: 'Nhân viên' },
      { title: 'Gửi bàn giao', detail: 'Gửi trước hạn bàn giao. Trong thời gian bàn giao không nhận việc mới.', role: 'Nhân viên' },
      { title: 'Quản lý xác nhận', detail: 'Kiểm tra, trả lại nếu thiếu; xác nhận để hệ thống chuyển việc cho người nhận và áp dụng quyết định.', role: 'Quản lý' },
    ] },
  { key: 'cap_phep_cong', title: 'Quy trình cấp & kiểm soát giấy ra vào cổng', category: 'Thủ tục', audience: 'department', dept: ['bảo vệ', 'an ninh'], reminder: 'weekly',
    summary: 'Bảo vệ kiểm tra giấy phép trên app trước khi cho người/hàng ra vào, ghi nhận giờ ra – vào.',
    steps: [
      { title: 'Kiểm tra giấy phép', detail: 'Mở mã giấy phép (GP-…) trên app: đúng người, đúng khung giờ, trạng thái "Đã cấp" hoặc "Cấp tự động".' },
      { title: 'Ghi nhận ra', detail: 'Bấm "Ghi nhận ra" khi người/hàng/xe ra cổng.' },
      { title: 'Ghi nhận vào', detail: 'Bấm "Ghi nhận vào" khi quay lại; quá giờ thì ghi chú lý do.' },
      { title: 'Hậu kiểm đơn khai báo', detail: 'Với giấy cấp tự động, rà soát trong ngày: hợp lệ hoặc vi phạm (người giao việc chịu trách nhiệm).' },
    ] },
  { key: 'cap_phep_thiet_bi', title: 'Quy trình cấp – nhận – trả thiết bị, xe', category: 'Thủ tục', audience: 'department', dept: ['kho', 'kỹ thuật', 'hành chính'], reminder: 'weekly',
    summary: 'Thiết bị/xe chỉ được giao khi có giấy phép đính kèm công việc; ghi nhận tình trạng lúc nhận và trả.',
    steps: [
      { title: 'Đối chiếu giấy phép', detail: 'Đúng thiết bị, đúng người, còn hiệu lực.' },
      { title: 'Ghi nhận nhận thiết bị', detail: 'Bấm "Ghi nhận giao thiết bị", ghi tình trạng/số km.' },
      { title: 'Ghi nhận trả thiết bị', detail: 'Kiểm tra tình trạng khi trả; hư hỏng thì báo cáo trở ngại.' },
      { title: 'Hậu kiểm', detail: 'Rà soát giấy cấp tự động; quy trình sai thì đánh dấu vi phạm.' },
    ] },
  { key: 'khai_bao_tu_dong', title: 'Cấp phép tự động bằng đơn khai báo & hậu kiểm', category: 'Thủ tục', audience: 'managers', reminder: 'monthly',
    summary: 'Để rút ngắn thủ tục, người giao việc có thể khai báo để giấy phép có hiệu lực ngay. Bộ phận phụ trách hậu kiểm; quy trình sai thì người giao việc chịu trách nhiệm.',
    steps: [
      { title: 'Chỉ khai báo khi đủ điều kiện', detail: 'Thông tin đúng, đủ; việc có thật và cần ngay.' },
      { title: 'Giấy phép có hiệu lực ngay', detail: 'Bộ phận phụ trách nhận thông báo để theo dõi.' },
      { title: 'Hậu kiểm', detail: 'Bộ phận phụ trách đối chiếu nhận – trả, ra – vào và đánh dấu hợp lệ/vi phạm.' },
      { title: 'Trách nhiệm', detail: 'Vi phạm được ghi nhận cho người giao việc và báo cấp trên.' },
    ] },
  { key: 'nghi_phep', title: 'Quy trình xin nghỉ phép', category: 'Nhân sự', audience: 'all', reminder: 'monthly',
    summary: 'Xin nghỉ trên app, báo trước theo quy định; quản lý duyệt, đơn PDF tự gửi nhân sự.',
    steps: [
      { title: 'Báo trước', detail: 'Theo giờ ≥ 4 giờ, theo ca ≥ 12 giờ, theo ngày ≥ 24 giờ (đột xuất không áp dụng).' },
      { title: 'Ghi rõ bàn giao', detail: 'Ai xử lý thay, việc nào cần lưu ý.' },
      { title: 'Quản lý duyệt', detail: 'Duyệt hoặc từ chối có lý do; đơn được xuất PDF gửi nhân sự.' },
    ] },
  { key: 'tro_ngai', title: 'Quy trình báo cáo trở ngại', category: 'Vận hành', audience: 'all', reminder: 'monthly',
    summary: 'Gặp trở ngại về thiết bị, phần mềm, vật tư, quy trình… báo ngay trên app, gắn việc bị ảnh hưởng.',
    steps: [
      { title: 'Báo ngay', detail: 'Chọn danh mục, mức độ; nguy cơ an toàn thì kích hoạt quy trình an toàn ngoài app.' },
      { title: 'Theo dõi SLA', detail: 'Quá hạn sẽ tự chuyển cấp.' },
      { title: 'Xác nhận khắc phục', detail: 'Đóng hoặc mở lại nếu chưa giải quyết.' },
    ] },
  { key: 'khai_viec_nhanh', title: 'Giao việc qua điện thoại / tin nhắn', category: 'Giao việc', audience: 'all', reminder: 'weekly',
    summary: 'Việc giao ngoài app phải được khai việc nhanh trong ngày; ai khai trước thì người kia xác nhận.',
    steps: [
      { title: 'Gọi/nhắn từ app', detail: 'App sẽ gợi ý khai việc khi bạn quay lại.' },
      { title: 'Khai việc nhanh', detail: 'Ghi nội dung, hạn, đính kèm ghi âm nếu có.' },
      { title: 'Xác nhận', detail: 'Người còn lại xác nhận để thành nhiệm vụ chính thức.' },
    ] },
  { key: 'nghiem_thu', title: 'Nghiệm thu & đánh giá công bằng', category: 'Giao việc', audience: 'managers', reminder: 'monthly',
    summary: 'Nghiệm thu theo tiêu chí đã giao, đúng hạn, có lý do khi yêu cầu sửa.',
    steps: [
      { title: 'Đúng tiêu chí', detail: 'Chỉ đánh giá theo tiêu chí đã thống nhất (phiên bản hiện hành).' },
      { title: 'Đúng hạn', detail: 'Phản hồi bàn giao trong 1 ngày làm việc.' },
      { title: 'Công bằng', detail: 'Tính độ khó; không trừ điểm vì trở ngại khách quan đã xác nhận; tăng ca không phải điểm thưởng.' },
    ] },
];

/** Tìm bộ phận theo từ khóa, ưu tiên theo thứ tự từ khóa. */
const findDept = (depts: { id: string; name: string }[], kws?: string[]) => {
  for (const k of kws || []) { const d = depts.find((x) => x.name.toLowerCase().includes(k)); if (d) return d.id; }
  return null;
};

export async function ensureCompanyLibrary(db: Queryable, companyId: string) {
  for (const t of EXTRA_TASK_TYPES) {
    await q(`INSERT INTO task_types(company_id, name) SELECT $1,$2 WHERE NOT EXISTS (SELECT 1 FROM task_types WHERE company_id=$1 AND name=$2)`, [companyId, t], db);
  }
  const types = await q(`SELECT id, name FROM task_types WHERE company_id=$1`, [companyId], db);
  const depts = await q(`SELECT id, name FROM departments WHERE company_id=$1`, [companyId], db);
  let i = 0;
  for (const t of DEFAULT_TEMPLATES) {
    const tt = types.find((x) => x.name === t.type) || types[0];
    await q(
      `INSERT INTO task_templates(company_id, name, task_type_id, description, complexity, requirement_level, estimated_hours, criteria, icon, category, fields, permit_keys, system_key, sort)
       VALUES ($1,$2,$3,$4,$5,'normal',$6,$7,$8,$9,$10,$11,$12,$13) ON CONFLICT (company_id, system_key) WHERE system_key IS NOT NULL DO NOTHING`,
      [companyId, t.name, tt?.id ?? null, t.description, t.complexity, t.hours,
       JSON.stringify([{ direction: 'input', criterion: 'Thông tin trong mẫu được điền đầy đủ' }, ...t.criteria.map((c) => ({ direction: 'output', criterion: c }))]),
       t.icon, t.category, JSON.stringify(t.fields), JSON.stringify(t.permits), t.key, i++], db);
  }
  for (const p of DEFAULT_PERMIT_TYPES) {
    await q(`INSERT INTO permit_types(company_id, key, name, icon, description, department_id, fields, tracks) VALUES ($1,$2,$3,$4,$5,$6,$7,$8)
             ON CONFLICT (company_id, key) DO NOTHING`,
      [companyId, p.key, p.name, p.icon, p.description, findDept(depts, p.dept), JSON.stringify(p.fields), p.tracks], db);
  }
  for (const p of DEFAULT_PROCEDURES) {
    const deptId = p.audience === 'department' ? findDept(depts, p.dept) : null;
    await q(`INSERT INTO procedures(company_id, department_id, audience, system_key, title, category, summary, steps, reference, reminder)
             VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) ON CONFLICT (company_id, system_key) WHERE system_key IS NOT NULL DO NOTHING`,
      [companyId, deptId, deptId ? 'department' : p.audience === 'department' ? 'managers' : p.audience, p.key, p.title, p.category, p.summary, JSON.stringify(p.steps), p.reference ?? null, p.reminder], db);
  }
}

export async function ensureAllLibraries(db: Queryable) {
  const cs = await q(`SELECT id FROM companies`, [], db);
  for (const c of cs) await ensureCompanyLibrary(db, c.id);
}

export async function relinkLibraryDepartments(db: Queryable, companyId: string) {
  const depts = await q(`SELECT id, name FROM departments WHERE company_id=$1`, [companyId], db);
  for (const p of DEFAULT_PERMIT_TYPES) {
    const d = findDept(depts, p.dept);
    if (d) await q(`UPDATE permit_types SET department_id=$3 WHERE company_id=$1 AND key=$2 AND department_id IS NULL`, [companyId, p.key, d], db);
  }
  for (const p of DEFAULT_PROCEDURES.filter((x) => x.audience === 'department')) {
    const d = findDept(depts, p.dept);
    if (d) await q(`UPDATE procedures SET department_id=$3, audience='department' WHERE company_id=$1 AND system_key=$2 AND department_id IS NULL`, [companyId, p.key, d], db);
  }
  return q1(`SELECT count(*)::int AS n FROM permit_types WHERE company_id=$1 AND department_id IS NOT NULL`, [companyId], db);
}
