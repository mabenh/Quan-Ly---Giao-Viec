import { Body, Controller, Get, Param, Post, Query } from '@nestjs/common';
import { PoolClient } from 'pg';
import { q, q1, tx } from '../db/db';
import { AllowNoCompany, Public } from '../common/auth.guard';
import { CurrentCtx, Ctx } from '../common/context';
import { AppError, Errors } from '../common/errors';
import { parse, z } from '../common/validate';
import { audit } from '../common/audit';
import { notify } from '../common/notify';
import { ADDONS, PLANS, activationMode, limitFor, maxPacks, periodPrice } from './plans';
import { createCompanyForUser } from './auth.controller';

/**
 * Gói doanh nghiệp (v12): mua mới (gói cơ bản → gói cộng thêm), gia hạn, chuyển gói, mua thêm gói cộng thêm, hủy gói.
 * Hoàn tiền tương ứng: giá trị còn lại của kỳ hiện tại = (gói cơ bản + gói cộng thêm) × số ngày còn lại / số ngày của kỳ.
 *  - Chuyển gói: giá trị còn lại được trừ vào gói mới (nếu lớn hơn thì hoàn phần dư).
 *  - Mua thêm gói cộng thêm giữa kỳ: chỉ trả theo số ngày còn lại.
 *  - Hủy gói: hoàn giá trị còn lại, gói ngừng hiệu lực ngay.
 *  - Gia hạn: tính theo tổng gói cơ bản + gói cộng thêm hiện có.
 */
const DAY = 86400000;
const PERIOD_DAYS = (months: number) => Math.round(months * 365 / 12);
const round1000 = (n: number) => Math.round(n / 1000) * 1000;

async function ownerCompany(ctx: Ctx, companyId: string) {
  const own = await q1(`SELECT 1 FROM company_members WHERE company_id=$1 AND user_id=$2 AND role='owner' AND status='active'`, [companyId, ctx.userId]);
  if (!own) throw Errors.forbidden('Chỉ chủ doanh nghiệp (Owner) được quản lý gói');
  const c = await q1(`SELECT * FROM companies WHERE id=$1`, [companyId]);
  if (!c) throw Errors.notFound('Công ty');
  return c;
}
/** Giá trị còn lại của kỳ hiện tại (để hoàn/khấu trừ). */
function remainingValue(c: any, now = new Date()) {
  if (!c.plan || !c.plan_expires_at || !PLANS[c.plan]) return { days_left: 0, period_days: 365, value: 0 };
  const left = Math.max(0, (new Date(c.plan_expires_at).getTime() - now.getTime()) / DAY);
  const period = PERIOD_DAYS(PLANS[c.plan].months);
  const value = round1000(periodPrice(c.plan, c.addon_packs || 0) * Math.min(left, period) / period);
  return { days_left: Math.floor(left), period_days: period, value };
}
async function membersUsed(companyId: string, db?: any) {
  return (await q1(`SELECT count(*)::int AS n FROM company_members WHERE company_id=$1 AND status IN ('active','pending_hr')`, [companyId], db)).n;
}

/** Báo giá cho từng thao tác — giao diện hiển thị trước khi xác nhận. */
export async function quote(c: any | null, action: string, plan?: string, packs = 0, now = new Date()) {
  const used = c ? await membersUsed(c.id) : 0;
  if (action === 'new') {
    if (!plan || !PLANS[plan]) throw Errors.validation('Chọn gói');
    if (packs > maxPacks(plan)) throw Errors.validation(`Gói ${PLANS[plan].name} chỉ cộng thêm tối đa ${maxPacks(plan)} gói (tổng ${ADDONS[plan].max_total} thành viên)`);
    const base = PLANS[plan].price_vnd, add = packs * ADDONS[plan].price_vnd;
    return { action, plan, addon_packs: packs, member_limit: limitFor(plan, packs), base_price_vnd: base, addon_price_vnd: add, credit_vnd: 0, amount_vnd: base + add, refund_vnd: 0, months: PLANS[plan].months };
  }
  if (!c?.plan) throw Errors.invalidState('Công ty chưa có gói — hãy mua gói mới');
  const rem = remainingValue(c, now);
  if (action === 'renew') {
    const base = PLANS[c.plan].price_vnd, add = (c.addon_packs || 0) * ADDONS[c.plan].price_vnd;
    return { action, plan: c.plan, addon_packs: c.addon_packs, member_limit: c.member_limit, base_price_vnd: base, addon_price_vnd: add, credit_vnd: 0, amount_vnd: base + add, refund_vnd: 0, months: PLANS[c.plan].months,
      new_expires_at: new Date(Math.max(new Date(c.plan_expires_at || now).getTime(), now.getTime()) + PERIOD_DAYS(PLANS[c.plan].months) * DAY) };
  }
  if (action === 'addon') {
    if (packs < 1) throw Errors.validation('Chọn số gói cộng thêm');
    const total = (c.addon_packs || 0) + packs;
    if (total > maxPacks(c.plan)) throw Errors.validation(`Gói ${PLANS[c.plan].name} chỉ cộng thêm tối đa ${maxPacks(c.plan)} gói (tổng ${ADDONS[c.plan].max_total} thành viên) — hãy chuyển sang gói lớn hơn`);
    const add = round1000(packs * ADDONS[c.plan].price_vnd * Math.min(rem.days_left, rem.period_days) / rem.period_days);
    return { action, plan: c.plan, addon_packs: packs, total_packs: total, member_limit: limitFor(c.plan, total), base_price_vnd: 0, addon_price_vnd: add, credit_vnd: 0, amount_vnd: add, refund_vnd: 0,
      months: 0, prorated_days: rem.days_left, note: `Tính theo ${rem.days_left}/${rem.period_days} ngày còn lại của kỳ` };
  }
  if (action === 'change') {
    if (!plan || !PLANS[plan]) throw Errors.validation('Chọn gói mới');
    if (plan === c.plan && packs === c.addon_packs) throw Errors.validation('Gói mới trùng gói hiện tại');
    if (packs > maxPacks(plan)) throw Errors.validation(`Gói ${PLANS[plan].name} chỉ cộng thêm tối đa ${maxPacks(plan)} gói`);
    const limit = limitFor(plan, packs);
    if (used > limit) throw new AppError('PLAN_TOO_SMALL', `Công ty đang có ${used} thành viên, vượt hạn mức gói mới (${limit}) — cần thêm gói cộng thêm hoặc chọn gói lớn hơn`, 409);
    const base = PLANS[plan].price_vnd, add = packs * ADDONS[plan].price_vnd;
    const net = base + add - rem.value;
    return { action, plan, addon_packs: packs, member_limit: limit, base_price_vnd: base, addon_price_vnd: add, credit_vnd: rem.value, amount_vnd: Math.max(0, net), refund_vnd: Math.max(0, -net),
      months: PLANS[plan].months, note: `Khấu trừ giá trị còn lại ${rem.days_left}/${rem.period_days} ngày của gói hiện tại; kỳ mới tính từ hôm nay` };
  }
  if (action === 'cancel') {
    return { action, plan: c.plan, addon_packs: c.addon_packs, member_limit: c.member_limit, base_price_vnd: 0, addon_price_vnd: 0, credit_vnd: 0, amount_vnd: 0, refund_vnd: rem.value, months: 0,
      note: `Hoàn giá trị còn lại ${rem.days_left}/${rem.period_days} ngày (gói cơ bản + gói cộng thêm)` };
  }
  throw Errors.validation('Thao tác không hợp lệ');
}

async function activate(c: PoolClient, subId: string, byUserId: string | null, paymentRef?: string) {
  const s = await q1(`SELECT * FROM subscriptions WHERE id=$1 FOR UPDATE`, [subId], c);
  if (!s) throw Errors.notFound('Yêu cầu');
  if (s.status !== 'pending_payment') throw Errors.invalidState('Yêu cầu đã được xử lý');
  let companyId = s.company_id;
  const days = PERIOD_DAYS(s.months || 12);
  if (s.kind === 'new' || !s.kind) {
    if (companyId) {
      const used = await membersUsed(companyId, c);
      if (used > s.member_limit) throw new AppError('PLAN_TOO_SMALL', `Công ty đang có ${used} thành viên, vượt hạn mức gói (${s.member_limit})`, 409);
      await q(`UPDATE companies SET plan=$2, member_limit=$3, contact_email=$4, name=$5, addon_packs=$6, plan_started_at=now(),
                 plan_expires_at=GREATEST(COALESCE(plan_expires_at, now()), now()) + make_interval(days => $7) WHERE id=$1`,
        [companyId, s.plan, s.member_limit, s.contact_email, s.company_name, s.addon_packs, days], c);
    } else {
      companyId = (await createCompanyForUser(c, s.user_id, { companyName: s.company_name, contactEmail: s.contact_email, plan: s.plan })).companyId;
      await q(`UPDATE companies SET member_limit=$2, addon_packs=$3, plan_started_at=now(), plan_expires_at=now() + make_interval(days => $4) WHERE id=$1`, [companyId, s.member_limit, s.addon_packs, days], c);
    }
  } else if (s.kind === 'renew') {
    await q(`UPDATE companies SET plan_expires_at=GREATEST(COALESCE(plan_expires_at, now()), now()) + make_interval(days => $2) WHERE id=$1`, [companyId, days], c);
  } else if (s.kind === 'change') {
    const used = await membersUsed(companyId, c);
    if (used > s.member_limit) throw new AppError('PLAN_TOO_SMALL', `Công ty đang có ${used} thành viên, vượt hạn mức gói mới (${s.member_limit})`, 409);
    await q(`UPDATE companies SET plan=$2, member_limit=$3, addon_packs=$4, plan_started_at=now(), plan_expires_at=now() + make_interval(days => $5) WHERE id=$1`, [companyId, s.plan, s.member_limit, s.addon_packs, days], c);
  } else if (s.kind === 'addon') {
    await q(`UPDATE companies SET addon_packs=addon_packs+$2, member_limit=$3 WHERE id=$1`, [companyId, s.addon_packs, s.member_limit], c);
  }
  // Chuyển gói có phần dư được hoàn -> chờ nền tảng hoàn tiền
  const status = s.kind === 'change' && Number(s.refund_vnd) > 0 ? 'refund_pending' : 'active';
  await q(`UPDATE subscriptions SET status=$5, company_id=$2, activated_by=$3, activated_at=now(), payment_ref=COALESCE($4, payment_ref) WHERE id=$1`,
    [subId, companyId, byUserId, paymentRef ?? null, status], c);
  return companyId;
}

@Controller()
export class SubscriptionsController {
  @Public()
  @Get('plans')
  plans() {
    return { plans: Object.values(PLANS).map((p) => ({ ...p, addon: { ...ADDONS[p.plan], max_packs: maxPacks(p.plan) } })),
      activation: activationMode(), payment_instructions: process.env.PAYMENT_INSTRUCTIONS || null };
  }

  /** Mua gói mới: gói cơ bản + số gói cộng thêm. Nâng cấp công ty hiện có (chưa có gói) nếu truyền companyId. */
  @AllowNoCompany()
  @Post('subscriptions')
  async create(@Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({
      plan: z.enum(['small', 'medium', 'large']), companyName: z.string().trim().min(2, 'Nhập tên công ty'), addonPacks: z.number().int().min(0).max(50).default(0),
      contactEmail: z.string().email('Email liên hệ không hợp lệ'), companyId: z.string().uuid().optional(),
    }), body);
    let company: any = null;
    if (b.companyId) {
      company = await ownerCompany(ctx, b.companyId);
      if (company.plan && company.plan_expires_at && new Date(company.plan_expires_at) > new Date()) throw new AppError('PLAN_ACTIVE', 'Công ty đang có gói hiệu lực — dùng Gia hạn, Chuyển gói hoặc Mua thêm gói cộng thêm', 409);
    }
    const qt = await quote(null, 'new', b.plan, b.addonPacks);
    return this.record(ctx, { kind: 'new', companyId: b.companyId ?? null, companyName: b.companyName, contactEmail: b.contactEmail, qt });
  }

  @AllowNoCompany()
  @Get('subscriptions/quote')
  async getQuote(@CurrentCtx() ctx: Ctx, @Query() qs: any) {
    const b = parse(z.object({ action: z.enum(['new', 'renew', 'change', 'addon', 'cancel']), companyId: z.string().uuid().optional(), plan: z.enum(['small', 'medium', 'large']).optional(),
      packs: z.coerce.number().int().min(0).max(50).default(0) }), qs);
    const c = b.companyId ? await ownerCompany(ctx, b.companyId) : null;
    return quote(c, b.action, b.plan, b.packs);
  }

  /** Trạng thái gói hiện tại của công ty + lịch sử giao dịch. */
  @AllowNoCompany()
  @Get('subscriptions/current')
  async current(@CurrentCtx() ctx: Ctx, @Query('companyId') companyId: string) {
    const c = await ownerCompany(ctx, companyId);
    const used = await membersUsed(c.id);
    const rem = remainingValue(c);
    const history = await q(`SELECT * FROM subscriptions WHERE company_id=$1 ORDER BY created_at DESC LIMIT 50`, [c.id]);
    return { company: { id: c.id, name: c.name, plan: c.plan, plan_name: c.plan ? PLANS[c.plan]?.name : null, member_limit: c.member_limit, addon_packs: c.addon_packs, plan_expires_at: c.plan_expires_at,
      plan_started_at: c.plan_started_at, members_used: used, remaining_value_vnd: rem.value, days_left: rem.days_left,
      period_price_vnd: c.plan ? periodPrice(c.plan, c.addon_packs || 0) : 0, max_packs: c.plan ? maxPacks(c.plan) : 0, addon: c.plan ? ADDONS[c.plan] : null }, history };
  }

  @AllowNoCompany()
  @Post('subscriptions/renew')
  async renew(@Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({ companyId: z.string().uuid() }), body);
    const c = await ownerCompany(ctx, b.companyId);
    return this.record(ctx, { kind: 'renew', companyId: c.id, companyName: c.name, contactEmail: c.contact_email, qt: await quote(c, 'renew') });
  }
  @AllowNoCompany()
  @Post('subscriptions/change')
  async change(@Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({ companyId: z.string().uuid(), plan: z.enum(['small', 'medium', 'large']), addonPacks: z.number().int().min(0).max(50).default(0) }), body);
    const c = await ownerCompany(ctx, b.companyId);
    return this.record(ctx, { kind: 'change', companyId: c.id, companyName: c.name, contactEmail: c.contact_email, qt: await quote(c, 'change', b.plan, b.addonPacks) });
  }
  @AllowNoCompany()
  @Post('subscriptions/addons')
  async addons(@Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({ companyId: z.string().uuid(), packs: z.number().int().min(1).max(50) }), body);
    const c = await ownerCompany(ctx, b.companyId);
    return this.record(ctx, { kind: 'addon', companyId: c.id, companyName: c.name, contactEmail: c.contact_email, qt: await quote(c, 'addon', undefined, b.packs) });
  }
  /** Hủy gói: hoàn giá trị còn lại, gói ngừng hiệu lực ngay. */
  @AllowNoCompany()
  @Post('subscriptions/cancel-plan')
  async cancelPlan(@Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({ companyId: z.string().uuid(), reason: z.string().trim().min(3, 'Nêu lý do hủy gói'), confirm: z.literal(true, { message: 'Xác nhận hủy gói' }) }), body);
    const c = await ownerCompany(ctx, b.companyId);
    const qt = await quote(c, 'cancel');
    return tx(async (cx) => {
      const s = await q1(`INSERT INTO subscriptions(user_id, company_id, plan, company_name, contact_email, member_limit, price_vnd, months, kind, addon_packs, refund_vnd, amount_vnd, note, status, activated_at)
                          VALUES ($1,$2,$3,$4,$5,$6,0,0,'cancel',$7,$8,0,$9,$10, now()) RETURNING *`,
        [ctx.userId, c.id, c.plan, c.name, c.contact_email || 'n/a@viecden.vn', c.member_limit, c.addon_packs, qt.refund_vnd, b.reason, qt.refund_vnd > 0 ? 'refund_pending' : 'active'], cx);
      await q(`UPDATE companies SET plan=NULL, plan_expires_at=now(), addon_packs=0 WHERE id=$1`, [c.id], cx);
      await audit(cx, { companyId: c.id, memberId: null }, 'company', c.id, 'subscription.cancelled', { plan: c.plan, packs: c.addon_packs }, { refund_vnd: qt.refund_vnd }, b.reason);
      return { subscription: s, quote: qt };
    });
  }

  private async record(ctx: Ctx, o: { kind: string; companyId: string | null; companyName: string; contactEmail: string; qt: any }) {
    return tx(async (c) => {
      const pend = await q1(`SELECT id FROM subscriptions WHERE user_id=$1 AND status='pending_payment'`, [ctx.userId], c);
      if (pend) throw new AppError('SUBSCRIPTION_PENDING', 'Bạn đang có một yêu cầu chờ thanh toán — hủy hoặc hoàn tất trước', 409, { id: pend.id });
      const qt = o.qt;
      const s = await q1(
        `INSERT INTO subscriptions(user_id, company_id, plan, company_name, contact_email, member_limit, price_vnd, months, kind, addon_packs, base_price_vnd, addon_price_vnd, credit_vnd, refund_vnd, amount_vnd, note)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16) RETURNING *`,
        [ctx.userId, o.companyId, qt.plan, o.companyName, o.contactEmail || 'n/a@viecden.vn', qt.member_limit, qt.amount_vnd, qt.months || 12, o.kind, qt.addon_packs || 0,
         qt.base_price_vnd, qt.addon_price_vnd, qt.credit_vnd, qt.refund_vnd, qt.amount_vnd, qt.note ?? null], c);
      let companyId: string | null = null;
      // Không phải trả thêm (vd chuyển gói nhỏ hơn) hoặc chế độ dùng thử -> kích hoạt ngay
      if (activationMode() === 'auto' || (o.kind !== 'new' && Number(qt.amount_vnd) === 0)) companyId = await activate(c, s.id, null, activationMode() === 'auto' ? 'TRIAL-AUTO' : 'NO-PAYMENT');
      const out = await q1(`SELECT * FROM subscriptions WHERE id=$1`, [s.id], c);
      return { subscription: out, company_id: companyId, activation: activationMode(), quote: qt };
    });
  }

  @AllowNoCompany()
  @Get('subscriptions/mine')
  async mine(@CurrentCtx() ctx: Ctx) {
    return q(`SELECT * FROM subscriptions WHERE user_id=$1 ORDER BY created_at DESC`, [ctx.userId]);
  }

  @AllowNoCompany()
  @Post('subscriptions/:id/cancel')
  async cancel(@Param('id') id: string, @CurrentCtx() ctx: Ctx) {
    const r = await q1(`UPDATE subscriptions SET status='cancelled' WHERE id=$1 AND user_id=$2 AND status='pending_payment' RETURNING id`, [id, ctx.userId]);
    if (!r) throw Errors.invalidState('Không thể hủy yêu cầu này');
    return { ok: true };
  }

  // ---------- Quản trị nền tảng (xác nhận thanh toán / hoàn tiền) ----------
  private assertPlatform(ctx: Ctx) { if (!ctx.isPlatformAdmin) throw Errors.forbidden('Chỉ quản trị nền tảng Việc Đến'); }

  @AllowNoCompany()
  @Get('platform/subscriptions')
  async list(@CurrentCtx() ctx: Ctx, @Query('status') status?: string) {
    this.assertPlatform(ctx);
    return q(`SELECT s.*, u.name AS user_name, u.phone FROM subscriptions s JOIN users u ON u.id=s.user_id
               WHERE ($1::text IS NULL OR s.status=$1) ORDER BY s.created_at DESC LIMIT 300`, [status || null]);
  }

  @AllowNoCompany()
  @Post('platform/subscriptions/:id/activate')
  async activateSub(@Param('id') id: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    this.assertPlatform(ctx);
    const b = parse(z.object({ paymentRef: z.string().trim().min(2, 'Nhập mã giao dịch thanh toán') }), body);
    const companyId = await tx(async (c) => {
      const cid = await activate(c, id, ctx.userId, b.paymentRef);
      const s = await q1(`SELECT user_id FROM subscriptions WHERE id=$1`, [id], c);
      const owner = await q1(`SELECT id FROM company_members WHERE company_id=$1 AND user_id=$2`, [cid, s.user_id], c);
      if (owner) await notify(c, { companyId: cid, memberIds: [owner.id], type: 'subscription.active', title: 'Gói doanh nghiệp đã được kích hoạt' });
      await audit(c, { companyId: cid, memberId: null }, 'company', cid, 'subscription.activated', null, { subscription: id, payment_ref: b.paymentRef });
      return cid;
    });
    return { ok: true, company_id: companyId };
  }

  @AllowNoCompany()
  @Post('platform/subscriptions/:id/refunded')
  async refunded(@Param('id') id: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    this.assertPlatform(ctx);
    const b = parse(z.object({ refundRef: z.string().trim().min(2, 'Nhập mã giao dịch hoàn tiền') }), body);
    const r = await q1(`UPDATE subscriptions SET status='refunded', refund_ref=$2, refunded_at=now() WHERE id=$1 AND status='refund_pending' RETURNING id, company_id`, [id, b.refundRef]);
    if (!r) throw Errors.invalidState('Không có khoản hoàn tiền chờ xử lý');
    return { ok: true };
  }

  @AllowNoCompany()
  @Post('platform/subscriptions/:id/reject')
  async reject(@Param('id') id: string, @CurrentCtx() ctx: Ctx) {
    this.assertPlatform(ctx);
    const r = await q1(`UPDATE subscriptions SET status='rejected' WHERE id=$1 AND status='pending_payment' RETURNING id`, [id]);
    if (!r) throw Errors.invalidState('Không thể từ chối yêu cầu này');
    return { ok: true };
  }
}
