import { Body, Controller, Get, Post, Query } from '@nestjs/common';
import { randomInt } from 'crypto';
import { q, q1, tx } from '../db/db';
import { AllowNoCompany } from '../common/auth.guard';
import { CurrentCtx, Ctx, isAdmin, isHR } from '../common/context';
import { AppError, Errors } from '../common/errors';
import { parse, z } from '../common/validate';
import { notify } from '../common/notify';
import { audit } from '../common/audit';
import { slowRequests } from '../common/security.middleware';

/**
 * Nhiều doanh nghiệp cho một tài khoản (v13):
 * - Mỗi công ty có "mã gia nhập" (8 ký tự). Nhân viên đã có tài khoản nhập mã để xin gia nhập công ty thứ 2 → chờ Nhân sự duyệt.
 * - Chủ doanh nghiệp mở doanh nghiệp thứ 2 qua POST /subscriptions (không truyền companyId).
 * - Nhật ký lỗi kết nối phía ứng dụng để chẩn đoán "lỗi kết nối" (lưu 7 ngày).
 */
const ALPHA = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const genCode = () => Array.from({ length: 8 }, () => ALPHA[randomInt(ALPHA.length)]).join('');

export async function ensureJoinCode(companyId: string, rotate = false): Promise<string> {
  const c = await q1(`SELECT join_code FROM companies WHERE id=$1`, [companyId]);
  if (c?.join_code && !rotate) return c.join_code;
  for (let i = 0; i < 8; i++) {
    const code = genCode();
    try { await q(`UPDATE companies SET join_code=$2 WHERE id=$1`, [companyId, code]); return code; } catch { /* trùng mã → thử lại */ }
  }
  throw new AppError('INTERNAL', 'Không tạo được mã gia nhập', 500);
}

@Controller()
export class JoinController {
  @Get('company/join-code')
  async code(@CurrentCtx() ctx: Ctx) {
    if (!isHR(ctx)) throw Errors.forbidden('Chỉ Ban quản trị / Nhân sự xem mã gia nhập');
    return { code: await ensureJoinCode(ctx.companyId!) };
  }
  @Post('company/join-code/rotate')
  async rotate(@CurrentCtx() ctx: Ctx) {
    if (!isAdmin(ctx)) throw Errors.forbidden('Chỉ chủ doanh nghiệp / quản trị đổi mã');
    return { code: await ensureJoinCode(ctx.companyId!, true) };
  }

  /** Xem trước công ty theo mã (không lộ thông tin khác ngoài tên). */
  @AllowNoCompany()
  @Get('companies/lookup')
  async lookup(@Query('code') code: string) {
    const c = await q1(`SELECT id, name FROM companies WHERE join_code=$1`, [String(code || '').trim().toUpperCase()]);
    if (!c) throw Errors.notFound('Công ty với mã này');
    return { name: c.name };
  }

  /** Xin gia nhập công ty bằng mã → chờ Nhân sự duyệt. */
  @AllowNoCompany()
  @Post('companies/join')
  async join(@Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({ code: z.string().trim().min(6).max(12), note: z.string().trim().max(300).optional() }), body);
    const c = await q1(`SELECT id, name, plan, member_limit FROM companies WHERE join_code=$1`, [b.code.toUpperCase()]);
    if (!c) throw Errors.notFound('Công ty với mã này');
    return tx(async (db) => {
      await db.query(`SELECT 1 FROM companies WHERE id=$1 FOR UPDATE`, [c.id]);
      const dup = await q1(`SELECT id, status FROM company_members WHERE company_id=$1 AND user_id=$2`, [c.id, ctx.userId], db);
      if (dup && dup.status === 'active') throw new AppError('ALREADY_MEMBER', `Bạn đã là thành viên ${c.name}`, 409);
      if (dup && dup.status === 'pending_hr') throw new AppError('ALREADY_MEMBER', `Bạn đã gửi yêu cầu gia nhập ${c.name}, đang chờ nhân sự duyệt`, 409);
      if (c.member_limit) {
        const used = (await q1(`SELECT count(*)::int AS n FROM company_members WHERE company_id=$1 AND status IN ('active','pending_hr')`, [c.id], db)).n;
        if (used >= c.member_limit) throw new AppError('PLAN_LIMIT', `${c.name} đã đủ số thành viên của gói — liên hệ chủ doanh nghiệp`, 402);
      }
      let id: string;
      if (dup) {
        await q(`UPDATE company_members SET status='pending_hr', role='employee', left_at=NULL, hr_reviewed_by=NULL, hr_reviewed_at=NULL, hr_note=$2, added_by=NULL WHERE id=$1`, [dup.id, b.note ?? 'Tự xin gia nhập bằng mã'], db);
        id = dup.id;
      } else {
        id = (await q1(`INSERT INTO company_members(company_id, user_id, role, status, hr_note) VALUES ($1,$2,'employee','pending_hr',$3) RETURNING id`, [c.id, ctx.userId, b.note ?? 'Tự xin gia nhập bằng mã'], db)).id;
      }
      const u = await q1(`SELECT name, phone FROM users WHERE id=$1`, [ctx.userId], db);
      const hrs = await q(`SELECT id FROM company_members WHERE company_id=$1 AND status='active' AND role IN ('hr','admin','owner')`, [c.id], db);
      await notify(db, { companyId: c.id, memberIds: hrs.map((h) => h.id), type: 'member.pending_hr', title: `${u.name} xin gia nhập công ty bằng mã`, body: 'Cần nhân sự kiểm duyệt và xếp chức vụ, phòng ban', refType: 'member', refId: id });
      await audit(db, { userId: ctx.userId, memberId: id, companyId: c.id, role: 'employee', name: u.name } as any, 'member', id, 'member.join_request', null, { code: true });
      return { id, status: 'pending_hr', company_name: c.name, message: `Đã gửi yêu cầu gia nhập ${c.name}. Khi nhân sự duyệt, bạn đổi công ty ở nút tên công ty trên cùng.` };
    });
  }

  /** Hủy yêu cầu gia nhập đang chờ. */
  @AllowNoCompany()
  @Post('companies/join/cancel')
  async cancelJoin(@Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({ memberId: z.string().uuid() }), body);
    const r = await q1(`UPDATE company_members SET status='rejected', hr_note='Người xin đã hủy' WHERE id=$1 AND user_id=$2 AND status='pending_hr' RETURNING id`, [b.memberId, ctx.userId]);
    if (!r) throw Errors.notFound('Yêu cầu gia nhập');
    return { ok: true };
  }

  // ---------- Chẩn đoán lỗi kết nối ----------
  @AllowNoCompany()
  @Post('diag/client-errors')
  async clientErrors(@Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({ items: z.array(z.object({ code: z.string().max(40), status: z.number().int().optional(), path: z.string().max(200).optional(), message: z.string().max(300).optional(),
      online: z.boolean().optional(), at: z.string().optional() })).max(30), app: z.string().max(40).optional(), ua: z.string().max(200).optional() }), body);
    for (const it of b.items) {
      await q(`INSERT INTO client_error_logs(user_id, company_id, code, status, path, message, online, app, ua, created_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9, COALESCE($10::timestamptz, now()))`,
        [ctx.userId, ctx.companyId ?? null, it.code, it.status ?? null, it.path ?? null, it.message ?? null, it.online ?? null, b.app ?? null, b.ua ?? null,
          it.at && !isNaN(Date.parse(it.at)) && Math.abs(Date.now() - Date.parse(it.at)) < 86400000 ? it.at : null]);
    }
    return { ok: true, saved: b.items.length };
  }
  @AllowNoCompany()
  @Get('platform/client-errors')
  async listClientErrors(@CurrentCtx() ctx: Ctx, @Query('hours') hours?: string) {
    if (!ctx.isPlatformAdmin && !isAdmin(ctx)) throw Errors.forbidden('Chỉ quản trị');
    const h = Math.min(168, Math.max(1, Number(hours) || 24));
    const scope = ctx.isPlatformAdmin ? null : ctx.companyId;
    const summary = await q(`SELECT code, status, path, count(*)::int AS n, count(DISTINCT user_id)::int AS users, max(created_at) AS last_at FROM client_error_logs
                              WHERE created_at > now() - make_interval(hours => $1) AND ($2::uuid IS NULL OR company_id=$2) GROUP BY code, status, path ORDER BY n DESC LIMIT 50`, [h, scope]);
    const recent = await q(`SELECT l.created_at, l.code, l.status, l.path, l.message, l.online, l.app, u.name FROM client_error_logs l LEFT JOIN users u ON u.id=l.user_id
                             WHERE l.created_at > now() - make_interval(hours => $1) AND ($2::uuid IS NULL OR l.company_id=$2) ORDER BY l.created_at DESC LIMIT 100`, [h, scope]);
    return { hours: h, summary, recent, slow_requests: ctx.isPlatformAdmin ? slowRequests().slice(0, 60) : [] };
  }
}

/** v14: nhật ký mã OTP cho Quản trị nền tảng — khi chưa cấu hình SMS hoặc SMS lỗi, đọc mã hỗ trợ khách (đã xác minh danh tính qua điện thoại). */
@Controller()
export class OtpAdminController {
  @AllowNoCompany()
  @Get('platform/otp-log')
  async otpLog(@CurrentCtx() ctx: Ctx, @Query('phone') phone?: string) {
    if (!ctx.isPlatformAdmin) throw Errors.forbidden('Chỉ quản trị nền tảng Việc Đến');
    const rows = await q(`SELECT id, phone, purpose, channel, delivery, attempts, created_at, expires_at, consumed_at,
                                 CASE WHEN consumed_at IS NULL AND expires_at > now() THEN manual_code END AS manual_code
                            FROM otp_codes WHERE ($1::text IS NULL OR phone LIKE '%' || $1 || '%') ORDER BY created_at DESC LIMIT 100`, [phone || null]);
    return { items: rows, provider: process.env.SMS_PROVIDER || null };
  }
}

export async function runDiagRetention() {
  const r = await q(`DELETE FROM client_error_logs WHERE created_at < now() - interval '7 days' RETURNING id`);
  return { client_errors: r.length };
}
