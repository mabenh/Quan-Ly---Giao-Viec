/** Gói doanh nghiệp. Hạn mức & giá có thể cấu hình qua biến môi trường (giá mặc định chỉ là giá minh họa). */
const num = (k: string, d: number) => (process.env[k] ? Number(process.env[k]) : d);

export const PLANS: Record<string, { plan: string; name: string; member_limit: number; price_vnd: number; months: number }> = {
  small: { plan: 'small', name: 'Doanh nghiệp nhỏ', member_limit: num('PLAN_SMALL_LIMIT', 20), price_vnd: num('PLAN_SMALL_PRICE', 1_200_000), months: 12 },
  medium: { plan: 'medium', name: 'Doanh nghiệp vừa', member_limit: num('PLAN_MEDIUM_LIMIT', 100), price_vnd: num('PLAN_MEDIUM_PRICE', 4_800_000), months: 12 },
  large: { plan: 'large', name: 'Doanh nghiệp lớn', member_limit: num('PLAN_LARGE_LIMIT', 500), price_vnd: num('PLAN_LARGE_PRICE', 12_000_000), months: 12 },
};

/** 'auto' = kích hoạt ngay (dùng thử); 'manual' = chờ quản trị nền tảng xác nhận thanh toán. */
export const activationMode = () => (process.env.PLAN_ACTIVATION === 'manual' ? 'manual' : 'auto');

/** Gói cộng thêm thành viên (v12): mỗi gói có kích thước, giá (12 tháng) và tổng thành viên tối đa. */
export const ADDONS: Record<string, { size: number; price_vnd: number; max_total: number | null }> = {
  small: { size: 10, price_vnd: num('ADDON_SMALL_PRICE', 500_000), max_total: 90 },
  medium: { size: 50, price_vnd: num('ADDON_MEDIUM_PRICE', 2_000_000), max_total: 450 },
  large: { size: 100, price_vnd: num('ADDON_LARGE_PRICE', 3_500_000), max_total: null },
};
export const maxPacks = (plan: string) => { const a = ADDONS[plan]; return a.max_total ? Math.floor((a.max_total - PLANS[plan].member_limit) / a.size) : 50; };
export const limitFor = (plan: string, packs: number) => PLANS[plan].member_limit + packs * ADDONS[plan].size;
/** Tổng giá trị một kỳ (gói cơ bản + gói cộng thêm). */
export const periodPrice = (plan: string, packs: number) => PLANS[plan].price_vnd + packs * ADDONS[plan].price_vnd;
