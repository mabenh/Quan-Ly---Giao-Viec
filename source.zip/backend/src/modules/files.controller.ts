import { Controller, Get, Param, Post, Query, Res, UploadedFile, UseInterceptors } from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { Response } from 'express';
import { mkdirSync, writeFileSync, createReadStream, existsSync } from 'fs';
import { join, extname } from 'path';
import { randomUUID } from 'crypto';
import { q1 } from '../db/db';
import { CurrentCtx, Ctx } from '../common/context';
import { AppError, Errors } from '../common/errors';
import { audit } from '../common/audit';
import { getPool } from '../db/db';
import { TasksController } from './tasks.controller';
import { WorkRecordsController } from './work-records.controller';
import { WorkplaceReportsController } from './workplace-reports.controller';
import { OvertimeController } from './overtime.controller';
import { QuickClaimsController } from './quick-claims.controller';
import { LeavesController } from './leaves.controller';
import { accessLog, hasConsent } from '../common/privacy';
import { assertEvidenceAccess } from './conduct.controller';
import { OperationsController } from './operations.controller';

const MAX_SIZE = 20 * 1024 * 1024;
const ALLOWED = /^(image\/(png|jpe?g|gif|webp|heic)|video\/(mp4|quicktime|webm|3gpp)|application\/pdf|text\/plain|application\/(msword|vnd\.openxmlformats-officedocument\.[a-z.]+|vnd\.ms-excel)|audio\/(mpeg|mp4|x-m4a|m4a|aac|amr|3gpp|wav|x-wav|webm|ogg))$/;
const PARENTS = ['task', 'work_record', 'workplace_report', 'overtime', 'quick_claim', 'leave', 'conduct_case', 'handover'] as const;

/**
 * Lưu trữ tệp: driver local (UPLOAD_DIR). Có thể thay bằng S3-compatible bằng cách hiện thực lại put/get;
 * DB chỉ lưu metadata, quyền truy cập kiểm tra theo đối tượng cha.
 */
export const storage = {
  dir: () => process.env.UPLOAD_DIR || join(process.cwd(), 'uploads'),
  put(key: string, buf: Buffer) { const p = join(this.dir(), key); mkdirSync(join(p, '..'), { recursive: true }); writeFileSync(p, buf); },
  path(key: string) { return join(this.dir(), key); },
};

async function assertParentAccess(ctx: Ctx, type: string, id: string, mode: 'upload' | 'read' = 'read', uploadedBy?: string | null) {
  switch (type) {
    case 'task': return new TasksController().detail(id, ctx);
    case 'work_record': return new WorkRecordsController().detail(id, ctx);
    case 'workplace_report': return new WorkplaceReportsController().detail(id, ctx);
    case 'overtime': return new OvertimeController().get(id, ctx);
    case 'quick_claim': return new QuickClaimsController().detail(id, ctx);
    case 'leave': return new LeavesController().detail(id, ctx);
    case 'conduct_case': return assertEvidenceAccess(ctx, id, mode, uploadedBy);
    case 'handover': return new OperationsController().handover(id, ctx);
    default: throw Errors.validation('Loại đối tượng không hợp lệ');
  }
}

/** Lưu tệp do hệ thống tạo (vd đơn nghỉ PDF). */
export async function saveGeneratedFile(db: any, companyId: string, parentType: string, parentId: string, filename: string, mime: string, buf: Buffer, uploadedBy: string) {
  const key = `${companyId}/${parentType}/${randomUUID()}${extname(filename)}`;
  storage.put(key, buf);
  return q1(`INSERT INTO files(company_id, parent_type, parent_id, filename, mime, size, storage_key, uploaded_by) VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING id`,
    [companyId, parentType, parentId, filename, mime, buf.length, key, uploadedBy], db);
}

@Controller('files')
export class FilesController {
  @Post()
  @UseInterceptors(FileInterceptor('file', { limits: { fileSize: MAX_SIZE } }))
  async upload(@UploadedFile() file: Express.Multer.File, @Query('parentType') parentType: string, @Query('parentId') parentId: string, @CurrentCtx() ctx: Ctx) {
    if (!file) throw Errors.validation('Thiếu tệp (field "file")');
    if (!PARENTS.includes(parentType as any) || !parentId) throw Errors.validation('parentType/parentId không hợp lệ');
    if (!ALLOWED.test(file.mimetype)) throw new AppError('FILE_TYPE_NOT_ALLOWED', `Loại tệp ${file.mimetype} không được phép`, 415);
    await assertParentAccess(ctx, parentType, parentId, 'upload');
    // Ghi âm cuộc gọi là dữ liệu dựa trên đồng ý: người tải lên phải đồng ý mục đích "ghi âm cuộc gọi khai việc"
    if (parentType === 'quick_claim' && file.mimetype.startsWith('audio/') && !(await hasConsent(ctx.userId, 'call_recording'))) {
      throw new AppError('CONSENT_REQUIRED', 'Cần bạn đồng ý mục đích "Ghi âm cuộc gọi khai việc" trước khi đính kèm ghi âm (Cá nhân → Quyền riêng tư).', 428, { purpose: 'call_recording' });
    }
    const key = `${ctx.companyId}/${parentType}/${randomUUID()}${extname(file.originalname).slice(0, 10)}`;
    storage.put(key, file.buffer);
    const r = await q1(
      `INSERT INTO files(company_id, parent_type, parent_id, filename, mime, size, storage_key, uploaded_by) VALUES ($1,$2,$3,$4,$5,$6,$7,$8)
       RETURNING id, filename, mime, size, created_at`,
      [ctx.companyId, parentType, parentId, Buffer.from(file.originalname, 'latin1').toString('utf8'), file.mimetype, file.size, key, ctx.memberId]);
    await audit(getPool(), ctx, parentType, parentId, 'file.uploaded', null, { file: r.id, name: r.filename });
    return r;
  }

  @Get(':id')
  async download(@Param('id') id: string, @CurrentCtx() ctx: Ctx, @Res() res: Response) {
    const f = await q1(`SELECT * FROM files WHERE id=$1 AND company_id=$2`, [id, ctx.companyId]);
    if (!f) throw Errors.notFound('Tệp');
    try { await assertParentAccess(ctx, f.parent_type, f.parent_id, 'read', f.uploaded_by); } catch (e) {
      await accessLog({ companyId: ctx.companyId, actorUserId: ctx.userId, actorMemberId: ctx.memberId, action: 'file.download', objectType: 'file', objectId: id, result: 'denied' });
      throw e;
    }
    const p = storage.path(f.storage_key);
    await accessLog({ companyId: ctx.companyId, actorUserId: ctx.userId, actorMemberId: ctx.memberId, action: 'file.download', objectType: 'file', objectId: id, meta: { parent: f.parent_type } });
    if (!existsSync(p)) throw Errors.notFound('Tệp');
    res.setHeader('Content-Type', f.mime);
    res.setHeader('Cache-Control', 'private, no-store');
    res.setHeader('Content-Disposition', `inline; filename*=UTF-8''${encodeURIComponent(f.filename)}`);
    createReadStream(p).pipe(res);
  }
}
