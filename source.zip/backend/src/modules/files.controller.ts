import { Controller, Get, Param, Post, Query, Res, UploadedFile, UseInterceptors } from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { Response } from 'express';
import { mkdirSync, writeFileSync, createReadStream, existsSync } from 'fs';
import { join, extname } from 'path';
import { randomUUID } from 'crypto';
import { q1 } from '../db/db';
import { CurrentCtx, Ctx } from '../common/context';
import { AppError, Errors } from '../common/errors';
import { audit } from '../common/audit';
import { getPool } from '../db/db';
import { TasksController } from './tasks.controller';
import { WorkRecordsController } from './work-records.controller';
import { WorkplaceReportsController } from './workplace-reports.controller';
import { OvertimeController } from './overtime.controller';

const MAX_SIZE = 20 * 1024 * 1024;
const ALLOWED = /^(image\/(png|jpe?g|gif|webp|heic)|video\/(mp4|quicktime|webm)|application\/pdf|text\/plain|application\/(msword|vnd\.openxmlformats-officedocument\.[a-z.]+|vnd\.ms-excel)|audio\/(mpeg|mp4|webm|ogg))$/;
const PARENTS = ['task', 'work_record', 'workplace_report', 'overtime'] as const;

/**
 * Lưu trữ tệp: driver local (UPLOAD_DIR). Có thể thay bằng S3-compatible bằng cách hiện thực lại put/get;
 * DB chỉ lưu metadata, quyền truy cập kiểm tra theo đối tượng cha.
 */
const storage = {
  dir: () => process.env.UPLOAD_DIR || join(process.cwd(), 'uploads'),
  put(key: string, buf: Buffer) { const p = join(this.dir(), key); mkdirSync(join(p, '..'), { recursive: true }); writeFileSync(p, buf); },
  path(key: string) { return join(this.dir(), key); },
};

async function assertParentAccess(ctx: Ctx, type: string, id: string) {
  switch (type) {
    case 'task': return new TasksController().detail(id, ctx);
    case 'work_record': return new WorkRecordsController().detail(id, ctx);
    case 'workplace_report': return new WorkplaceReportsController().detail(id, ctx);
    case 'overtime': return new OvertimeController().get(id, ctx);
    default: throw Errors.validation('Loại đối tượng không hợp lệ');
  }
}

@Controller('files')
export class FilesController {
  @Post()
  @UseInterceptors(FileInterceptor('file', { limits: { fileSize: MAX_SIZE } }))
  async upload(@UploadedFile() file: Express.Multer.File, @Query('parentType') parentType: string, @Query('parentId') parentId: string, @CurrentCtx() ctx: Ctx) {
    if (!file) throw Errors.validation('Thiếu tệp (field "file")');
    if (!PARENTS.includes(parentType as any) || !parentId) throw Errors.validation('parentType/parentId không hợp lệ');
    if (!ALLOWED.test(file.mimetype)) throw new AppError('FILE_TYPE_NOT_ALLOWED', `Loại tệp ${file.mimetype} không được phép`, 415);
    await assertParentAccess(ctx, parentType, parentId);
    const key = `${ctx.companyId}/${parentType}/${randomUUID()}${extname(file.originalname).slice(0, 10)}`;
    storage.put(key, file.buffer);
    const r = await q1(
      `INSERT INTO files(company_id, parent_type, parent_id, filename, mime, size, storage_key, uploaded_by) VALUES ($1,$2,$3,$4,$5,$6,$7,$8)
       RETURNING id, filename, mime, size, created_at`,
      [ctx.companyId, parentType, parentId, Buffer.from(file.originalname, 'latin1').toString('utf8'), file.mimetype, file.size, key, ctx.memberId]);
    await audit(getPool(), ctx, parentType, parentId, 'file.uploaded', null, { file: r.id, name: r.filename });
    return r;
  }

  @Get(':id')
  async download(@Param('id') id: string, @CurrentCtx() ctx: Ctx, @Res() res: Response) {
    const f = await q1(`SELECT * FROM files WHERE id=$1 AND company_id=$2`, [id, ctx.companyId]);
    if (!f) throw Errors.notFound('Tệp');
    await assertParentAccess(ctx, f.parent_type, f.parent_id);
    const p = storage.path(f.storage_key);
    if (!existsSync(p)) throw Errors.notFound('Tệp');
    res.setHeader('Content-Type', f.mime);
    res.setHeader('Content-Disposition', `inline; filename*=UTF-8''${encodeURIComponent(f.filename)}`);
    createReadStream(p).pipe(res);
  }
}
