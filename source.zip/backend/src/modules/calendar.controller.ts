import { Controller, Get, Query } from '@nestjs/common';
import { DateTime } from 'luxon';
import { q } from '../db/db';
import { CurrentCtx, Ctx, isAdmin, isHR } from '../common/context';
import { Errors } from '../common/errors';
import { parse, z } from '../common/validate';
import { getCompany, getGroup } from '../common/access';
import { OPEN_STATUSES } from './tasks.controller';

const DAY = /^\d{4}-\d\d-\d\d$/;
/** Múi giờ được nội suy vào SQL nên phải là tên IANA hợp lệ. */
const safeTz = (tz: string) => (/^[A-Za-z0-9_+\-\/]{1,64}$/.test(tz) ? tz : 'Asia/Ho_Chi_Minh');

/** Danh sách thành viên mà người xem được xem tình trạng (quản lý nhóm, Admin/HR). */
export async function teamMemberIds(ctx: Ctx, groupId?: string): Promise<string[]> {
  if (groupId) {
    const g = await getGroup(ctx, groupId);
    if (!isHR(ctx) && g.manager_member_id !== ctx.memberId) throw Errors.forbidden('Bạn không quản lý nhóm này');
    const rows = await q(`SELECT company_member_id AS id FROM group_members gm JOIN company_members cm ON cm.id=gm.company_member_id
                           WHERE gm.group_id=$1 AND cm.status='active'`, [groupId]);
    return [...new Set([g.manager_member_id, ...rows.map((r) => r.id)])];
  }
  if (isHR(ctx)) {
    return (await q(`SELECT id FROM company_members WHERE company_id=$1 AND status='active'`, [ctx.companyId])).map((r) => r.id);
  }
  const rows = await q(
    `SELECT DISTINCT gm.company_member_id AS id FROM groups g JOIN group_members gm ON gm.group_id=g.id JOIN company_members cm ON cm.id=gm.company_member_id
      WHERE g.manager_member_id=$1 AND g.deleted_at IS NULL AND cm.status='active'
     UNION SELECT id FROM company_members WHERE supervisor_member_id=$1 AND status='active'`, [ctx.memberId]);
  return rows.map((r) => r.id);
}

@Controller()
export class CalendarController {
  /** Lịch tuần/tháng: số việc theo ngày thực hiện, deadline, nghỉ phép. */
  @Get('calendar')
  async calendar(@CurrentCtx() ctx: Ctx, @Query() qs: any) {
    const f = parse(z.object({ from: z.string().regex(DAY), to: z.string().regex(DAY), scope: z.enum(['mine', 'team']).default('mine') }), qs);
    const c = await getCompany(ctx.companyId);
    const tz = safeTz(c.timezone);
    const ids = f.scope === 'mine' ? [ctx.memberId] : await teamMemberIds(ctx);
    const taskFilter = f.scope === 'team' && isAdmin(ctx)
      ? `t.company_id=$1`
      : `t.company_id=$1 AND EXISTS (SELECT 1 FROM task_assignees ta WHERE ta.task_id=t.id AND ta.active AND ta.company_member_id = ANY($4::uuid[]))`;
    const params = [ctx.companyId, f.from, f.to, ids];
    const planned = await q(
      `SELECT to_char(t.plan_date,'YYYY-MM-DD') AS d, count(*)::int AS n,
              count(*) FILTER (WHERE t.status IN ${OPEN_STATUSES})::int AS open,
              count(*) FILTER (WHERE t.pinned AND t.status IN ${OPEN_STATUSES})::int AS pinned,
              count(*) FILTER (WHERE t.carry_count > 0 AND t.status IN ${OPEN_STATUSES})::int AS carried
         FROM tasks t WHERE ${taskFilter} AND t.plan_date BETWEEN $2::date AND $3::date GROUP BY 1`, params);
    const due = await q(
      `SELECT to_char((t.due_at AT TIME ZONE '${tz}')::date,'YYYY-MM-DD') AS d, count(*)::int AS n,
              count(*) FILTER (WHERE t.status IN ${OPEN_STATUSES})::int AS open
         FROM tasks t WHERE ${taskFilter} AND (t.due_at AT TIME ZONE '${tz}')::date BETWEEN $2::date AND $3::date AND t.status<>'cancelled' GROUP BY 1`, params);
    const leaves = await q(
      `SELECT to_char(g.d,'YYYY-MM-DD') AS d, l.id, l.leave_type, l.status, u.name, l.member_id
         FROM generate_series($2::date, $3::date, interval '1 day') g(d)
         JOIN leave_requests l ON l.company_id=$1 AND l.member_id = ANY($4::uuid[]) AND l.status IN ('approved','pending')
              AND (l.start_at AT TIME ZONE '${tz}')::date <= g.d AND (l.end_at AT TIME ZONE '${tz}')::date >= g.d
         JOIN company_members cm ON cm.id=l.member_id JOIN users u ON u.id=cm.user_id`, params);
    const days: any[] = [];
    for (let d = DateTime.fromISO(f.from); d <= DateTime.fromISO(f.to); d = d.plus({ days: 1 })) {
      const k = d.toISODate()!;
      const p = planned.find((x) => x.d === k); const du = due.find((x) => x.d === k);
      days.push({ date: k, planned: p?.n || 0, planned_open: p?.open || 0, pinned: p?.pinned || 0, carried: p?.carried || 0,
        due: du?.n || 0, due_open: du?.open || 0, leaves: leaves.filter((l) => l.d === k).map(({ d: _d, ...l }) => l) });
    }
    return { today: DateTime.now().setZone(tz).toISODate(), days };
  }

  /** Tình trạng nhân viên (nghỉ phép, khối lượng việc) để quản lý cân nhắc trước khi giao việc. */
  @Get('team/availability')
  async availability(@CurrentCtx() ctx: Ctx, @Query() qs: any) {
    const f = parse(z.object({ from: z.string().regex(DAY), to: z.string().regex(DAY), groupId: z.string().uuid().optional() }), qs);
    if (!['owner', 'admin', 'hr', 'manager', 'reviewer'].includes(ctx.role)) throw Errors.forbidden();
    const c = await getCompany(ctx.companyId);
    const tz = safeTz(c.timezone);
    const ids = await teamMemberIds(ctx, f.groupId);
    if (!ids.length) return { from: f.from, to: f.to, members: [] };
    const members = await q(
      `SELECT cm.id AS member_id, cm.user_id, u.name, cm.role, cm.title, EXISTS (SELECT 1 FROM user_avatars a WHERE a.user_id=u.id) AS has_avatar
         FROM company_members cm JOIN users u ON u.id=cm.user_id WHERE cm.id = ANY($1::uuid[]) ORDER BY u.name`, [ids]);
    const load = await q(
      `SELECT ta.company_member_id AS member_id,
              count(*) FILTER (WHERE t.status IN ${OPEN_STATUSES})::int AS open_tasks,
              COALESCE(sum(t.estimated_hours) FILTER (WHERE t.status IN ${OPEN_STATUSES} AND ta.assignment_type='owner'),0)::numeric AS open_hours,
              count(*) FILTER (WHERE t.status IN ${OPEN_STATUSES} AND t.due_at < now())::int AS overdue,
              count(*) FILTER (WHERE t.status IN ${OPEN_STATUSES} AND t.pinned)::int AS pinned,
              count(*) FILTER (WHERE t.status IN ${OPEN_STATUSES} AND (t.due_at AT TIME ZONE '${tz}')::date BETWEEN $2::date AND $3::date)::int AS due_in_range
         FROM task_assignees ta JOIN tasks t ON t.id=ta.task_id WHERE ta.active AND ta.company_member_id = ANY($1::uuid[]) GROUP BY 1`, [ids, f.from, f.to]);
    const planned = await q(
      `SELECT ta.company_member_id AS member_id, to_char(t.plan_date,'YYYY-MM-DD') AS d, count(*)::int AS n
         FROM task_assignees ta JOIN tasks t ON t.id=ta.task_id
        WHERE ta.active AND ta.company_member_id = ANY($1::uuid[]) AND t.status IN ${OPEN_STATUSES} AND t.plan_date BETWEEN $2::date AND $3::date GROUP BY 1,2`, [ids, f.from, f.to]);
    const leaves = await q(
      `SELECT id, member_id, leave_type, status, start_at, end_at, shift, minutes, reason FROM leave_requests
        WHERE member_id = ANY($1::uuid[]) AND status IN ('approved','pending')
          AND (start_at AT TIME ZONE '${tz}')::date <= $3::date AND (end_at AT TIME ZONE '${tz}')::date >= $2::date ORDER BY start_at`, [ids, f.from, f.to]);
    const handover = await q(`SELECT member_id, code, decision_type, handover_deadline FROM personnel_decisions WHERE member_id = ANY($1::uuid[]) AND status IN ('handover','pending_confirm')`, [ids]);
    return {
      from: f.from, to: f.to,
      members: members.map((m) => {
        const ho = handover.find((x) => x.member_id === m.member_id) || null;
        const l = load.find((x) => x.member_id === m.member_id) || { open_tasks: 0, open_hours: 0, overdue: 0, pinned: 0, due_in_range: 0 };
        const lv = leaves.filter((x) => x.member_id === m.member_id);
        const planned_by_day = Object.fromEntries(planned.filter((x) => x.member_id === m.member_id).map((x) => [x.d, x.n]));
        const onLeave = lv.some((x) => x.status === 'approved');
        const status = ho ? 'handover' : onLeave ? 'on_leave' : lv.length ? 'leave_pending' : Number(l.open_hours) >= 40 || l.open_tasks >= 8 ? 'busy' : l.overdue > 0 ? 'has_overdue' : 'available';
        return { ...m, ...l, open_hours: Number(l.open_hours), leaves: lv, planned_by_day, status, handover: ho };
      }),
    };
  }
}
