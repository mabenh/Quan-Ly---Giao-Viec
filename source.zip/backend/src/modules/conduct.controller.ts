/**
 * Báo cáo hành vi cần xem xét (UX-ABUSE-01): quấy rối/đe dọa, quyền riêng tư/dữ liệu, lạm dụng quyền/trả đũa.
 * Nguyên tắc: không tự động kết luận; tách tín hiệu khỏi kết luận; bảo mật hai chiều; không trả đũa; tối thiểu hóa dữ liệu.
 * Phân quyền xem theo vai trò trong hồ sơ:
 *  - Người báo cáo: mã, trạng thái, nội dung mình gửi, các cập nhật dành cho họ. Không thấy tên người xử lý.
 *  - Đầu mối xử lý (được phân công): toàn bộ hồ sơ; không thấy danh tính người báo cáo nếu họ chọn ẩn danh với đơn vị xử lý.
 *  - Người được báo cáo: chỉ khi được mời giải trình — thấy tóm tắt do người xử lý viết, không thấy danh tính người báo cáo/bằng chứng.
 *  - Chủ DN/Quản trị: sổ theo dõi (mã, trạng thái, mức ưu tiên, người xử lý) để giám sát tiến độ, không thấy nội dung; có thể phân công lại.
 */
import { Body, Controller, Get, Param, Post, Query } from '@nestjs/common';
import { getPool, q, q1, tx } from '../db/db';
import { CurrentCtx, Ctx, isAdmin } from '../common/context';
import { AppError, Errors } from '../common/errors';
import { parse, z } from '../common/validate';
import { notify } from '../common/notify';
import { getCompany } from '../common/access';
import { accessLog, rateLimit } from '../common/privacy';

export const CONDUCT_STATUS_MSG: Record<string, string> = {
  received: 'Chúng tôi đã nhận báo cáo. Việc gửi báo cáo chưa phải kết luận về bất kỳ cá nhân nào.',
  screening: 'Báo cáo đang được kiểm tra để xác định bước xử lý phù hợp.',
  needs_info: 'Bạn có thể bổ sung thông tin nếu thấy an toàn và thuận tiện. Không bắt buộc cung cấp dữ liệu không liên quan.',
  investigating: 'Hồ sơ đang được xác minh. Nội dung chỉ được chia sẻ với người có nhiệm vụ xử lý.',
  resolved: 'Quy trình xem xét đã hoàn tất. Vì lý do bảo mật, một số chi tiết xử lý có thể không được chia sẻ.',
  insufficient: 'Thông tin hiện có chưa đủ để xác định sự việc. Bạn có thể bổ sung thông tin mới nếu có; việc chưa đủ bằng chứng không đồng nghĩa báo cáo của bạn là cố ý sai.',
  referred: 'Báo cáo đã được chuyển tới đầu mối có thẩm quyền. Phạm vi thông tin được chia sẻ sẽ được giới hạn.',
  closed: 'Hồ sơ đã đóng. Bạn có thể yêu cầu xem xét lại nếu có thông tin mới hoặc chưa đồng ý với kết quả.',
  review_requested: 'Yêu cầu xem xét lại đã được ghi nhận và chuyển tới người xử lý khác.',
};
const OPEN = ['received', 'screening', 'needs_info', 'investigating', 'review_requested'];
const SELECT = `SELECT c.*, ru.name AS reporter_name, pu.name AS reported_name, hu.name AS handler_name
  FROM conduct_cases c
  JOIN company_members r ON r.id=c.reporter_member_id JOIN users ru ON ru.id=r.user_id
  LEFT JOIN company_members p ON p.id=c.reported_member_id LEFT JOIN users pu ON pu.id=p.user_id
  LEFT JOIN company_members h ON h.id=c.handler_member_id LEFT JOIN users hu ON hu.id=h.user_id`;

/** Chọn đầu mối xử lý không có xung đột lợi ích: không là người báo cáo/được báo cáo/người xử lý trước. Ưu tiên người ít hồ sơ đang mở. */
export async function pickHandler(db: any, companyId: string, exclude: (string | null | undefined)[]): Promise<string | null> {
  const ex = exclude.filter(Boolean) as string[];
  const s = (await getCompany(companyId, db)).settings.privacy;
  const tiers: string[][] = [];
  if (s.conductHandlerIds?.length) tiers.push(s.conductHandlerIds);
  for (const role of ['hr', 'owner', 'admin']) {
    tiers.push((await q(`SELECT id FROM company_members WHERE company_id=$1 AND role=$2 AND status='active'`, [companyId, role], db)).map((r) => r.id));
  }
  for (const tier of tiers) {
    const cands = tier.filter((id) => !ex.includes(id));
    if (!cands.length) continue;
    const r = await q1(
      `SELECT cm.id FROM company_members cm WHERE cm.id = ANY($1::uuid[]) AND cm.status='active'
        ORDER BY (SELECT count(*) FROM conduct_cases c WHERE c.handler_member_id=cm.id AND c.status = ANY($2::text[])), cm.joined_at LIMIT 1`, [cands, OPEN], db);
    if (r) return r.id;
  }
  return null;
}

async function loadCase(ctx: Ctx, id: string, db: any = getPool()) {
  const c = await q1(`${SELECT} WHERE c.id=$1 AND c.company_id=$2`, [id, ctx.companyId], db);
  let role: 'reporter' | 'handler' | 'reported' | 'oversight' | null = null;
  if (c) {
    if (c.handler_member_id === ctx.memberId) role = 'handler';
    else if (c.reporter_member_id === ctx.memberId) role = 'reporter';
    else if (c.reported_member_id === ctx.memberId && c.explanation_requested_at) role = 'reported';
    else if (isAdmin(ctx) && c.reported_member_id !== ctx.memberId) role = 'oversight';
  }
  if (!c || !role) {
    await accessLog({ companyId: ctx.companyId, actorUserId: ctx.userId, actorMemberId: ctx.memberId, action: 'conduct.view', objectType: 'conduct_case', objectId: id, result: 'denied' }, db);
    throw Errors.notFound('Hồ sơ');
  }
  return { c, role };
}

/** Quyền với tệp bằng chứng: người xử lý xem tất cả; người báo cáo/người được báo cáo chỉ thấy tệp chính mình tải lên. */
export async function assertEvidenceAccess(ctx: Ctx, caseId: string, mode: 'upload' | 'read', uploadedBy?: string | null) {
  const { c, role } = await loadCase(ctx, caseId);
  if (role === 'handler') return c;
  if (role === 'oversight') throw Errors.notFound('Tệp');
  if (mode === 'upload') {
    if (['closed'].includes(c.status)) throw Errors.invalidState('Hồ sơ đã đóng');
    return c;
  }
  if (uploadedBy && uploadedBy === ctx.memberId) return c;
  throw Errors.notFound('Tệp');
}

const event = (db: any, caseId: string, actor: string | null, kind: string, visibility: string, body?: string | null, data?: any) =>
  q(`INSERT INTO conduct_case_events(case_id, actor_member_id, kind, visibility, body, data) VALUES ($1,$2,$3,$4,$5,$6)`,
    [caseId, actor, kind, visibility, body ?? null, data ? JSON.stringify(data) : null], db);
const touch = (db: any, id: string, set: string, params: any[] = []) => q(`UPDATE conduct_cases SET ${set}, updated_at=now() WHERE id=$1`, [id, ...params], db);
/** Thông báo tối thiểu — không nội dung, không danh tính (UX-ABUSE-01 mục 7). */
const ping = (db: any, companyId: string, memberIds: (string | null)[], code: string, id: string, title?: string) =>
  notify(db, { companyId, memberIds, type: 'conduct.update', title: title || `Hồ sơ ${code} có cập nhật. Đăng nhập để xem.`, refType: 'conduct_case', refId: id });

@Controller('conduct-cases')
export class ConductController {
  @Post()
  async create(@Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({
      category: z.enum(['harassment', 'privacy_data', 'power_abuse', 'other', 'not_sure']),
      subcode: z.string().regex(/^(HAR|POW|DAT)-0\d$/).optional().nullable(),
      description: z.string().trim().min(10, 'Mô tả ngắn điều đã xảy ra (tối thiểu 10 ký tự)').max(4000),
      occurredAt: z.coerce.date().optional().nullable(),
      objectType: z.enum(['task', 'comment', 'file', 'profile', 'access_log', 'work_record', 'evaluation', 'other']).optional().nullable(),
      objectId: z.string().uuid().optional().nullable(), objectLabel: z.string().max(200).optional().nullable(),
      reportedMemberId: z.string().uuid().optional().nullable(),
      currentRisk: z.enum(['none', 'safety', 'retaliation']).default('none'),
      safeContact: z.string().max(300).optional().nullable(),
      anonymity: z.enum(['to_reported', 'to_handler']).default('to_reported'),
    }), body);
    // Chống spam nhưng không trừng phạt người báo cáo thiện chí: chỉ giới hạn tốc độ
    rateLimit(`conduct:${ctx.memberId}`, 10, 86400000, 'Bạn đã gửi nhiều báo cáo trong hôm nay. Bạn có thể bổ sung thông tin vào hồ sơ đã gửi.');
    const company = await getCompany(ctx.companyId);
    if (b.anonymity === 'to_handler' && !company.settings.privacy.allowAnonymousToHandler) b.anonymity = 'to_reported';
    if (b.reportedMemberId) {
      const m = await q1(`SELECT id FROM company_members WHERE id=$1 AND company_id=$2`, [b.reportedMemberId, ctx.companyId]);
      if (!m) throw Errors.notFound('Người được báo cáo');
      if (b.reportedMemberId === ctx.memberId) throw Errors.validation('Không thể báo cáo chính mình');
    }
    const r = await tx(async (c) => {
      const n = await q1(`SELECT count(*)::int + 1 AS n FROM conduct_cases WHERE company_id=$1`, [ctx.companyId], c);
      const code = `HV-${String(n.n).padStart(6, '0')}`;
      const handler = await pickHandler(c, ctx.companyId, [ctx.memberId, b.reportedMemberId]);
      if (!handler) throw new AppError('NO_HANDLER', 'Chưa có đầu mối tiếp nhận phù hợp. Vui lòng liên hệ bộ phận nhân sự.', 409);
      const severity = b.currentRisk === 'safety' ? 'S3' : null;
      const row = await q1(
        `INSERT INTO conduct_cases(company_id, code, reporter_member_id, category, subcode, description, occurred_at, object_type, object_id, object_label,
           reported_member_id, current_risk, safe_contact, anonymity, handler_member_id, severity, retaliation_flag)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17) RETURNING id, code, status`,
        [ctx.companyId, code, ctx.memberId, b.category, b.subcode ?? null, b.description, b.occurredAt ?? null, b.objectType ?? null, b.objectId ?? null,
         b.objectLabel ?? null, b.reportedMemberId ?? null, b.currentRisk, b.safeContact ?? null, b.anonymity, handler, severity, b.currentRisk === 'retaliation'], c);
      await event(c, row.id, ctx.memberId, 'status', 'parties', CONDUCT_STATUS_MSG.received, { status: 'received' });
      await notify(c, { companyId: ctx.companyId, memberIds: [handler], type: 'conduct.new',
        title: b.currentRisk === 'safety' ? `Hồ sơ ${code} cần ưu tiên an toàn — vui lòng xem ngay` : `Có hồ sơ báo cáo hành vi mới cần xem xét (${code})`, refType: 'conduct_case', refId: row.id });
      await accessLog({ companyId: ctx.companyId, actorUserId: ctx.userId, actorMemberId: ctx.memberId, action: 'conduct.create', objectType: 'conduct_case', objectId: row.id }, c);
      return row;
    });
    return {
      ...r, message: `Chúng tôi đã nhận báo cáo. Mã hồ sơ: ${r.code}. Việc gửi báo cáo chưa phải kết luận về bất kỳ cá nhân nào.`,
      safety: b.currentRisk === 'safety' ? company.settings.privacy.safetyContact : null,
    };
  }

  @Get()
  async list(@CurrentCtx() ctx: Ctx, @Query('scope') scope = 'mine') {
    if (scope === 'handling') {
      return q(`SELECT c.id, c.code, c.category, c.subcode, c.status, c.severity, c.current_risk, c.retaliation_flag, c.created_at, c.updated_at,
                       (c.anonymity='to_handler') AS anonymous, pu.name AS reported_name
                  FROM conduct_cases c LEFT JOIN company_members p ON p.id=c.reported_member_id LEFT JOIN users pu ON pu.id=p.user_id
                 WHERE c.company_id=$1 AND c.handler_member_id=$2
                 ORDER BY (c.status = ANY($3::text[])) DESC, array_position(ARRAY['S4','S3','S2','S1','S0'], c.severity) NULLS LAST, c.created_at`, [ctx.companyId, ctx.memberId, OPEN]);
    }
    if (scope === 'explain') {
      return q(`SELECT id, code, status, explanation_requested_at, updated_at FROM conduct_cases WHERE company_id=$1 AND reported_member_id=$2 AND explanation_requested_at IS NOT NULL ORDER BY updated_at DESC`, [ctx.companyId, ctx.memberId]);
    }
    if (scope === 'oversight') {
      if (!isAdmin(ctx)) throw Errors.forbidden();
      // Sổ theo dõi: không có nội dung, không danh tính người báo cáo/được báo cáo
      return q(`SELECT c.id, c.code, c.category, c.status, c.severity, c.created_at, c.updated_at, hu.name AS handler_name,
                       (c.status = ANY($3::text[]) AND c.created_at < now() - interval '7 days') AS stale
                  FROM conduct_cases c LEFT JOIN company_members h ON h.id=c.handler_member_id LEFT JOIN users hu ON hu.id=h.user_id
                 WHERE c.company_id=$1 AND (c.reported_member_id IS DISTINCT FROM $2) ORDER BY c.created_at DESC LIMIT 300`, [ctx.companyId, ctx.memberId, OPEN]);
    }
    return q(`SELECT id, code, category, status, created_at, updated_at FROM conduct_cases WHERE company_id=$1 AND reporter_member_id=$2 ORDER BY created_at DESC`, [ctx.companyId, ctx.memberId]);
  }

  @Get(':id')
  async detail(@Param('id') id: string, @CurrentCtx() ctx: Ctx) {
    const { c, role } = await loadCase(ctx, id);
    await accessLog({ companyId: ctx.companyId, actorUserId: ctx.userId, actorMemberId: ctx.memberId, action: 'conduct.view', objectType: 'conduct_case', objectId: id, meta: { role } });
    const base = { id: c.id, code: c.code, status: c.status, status_message: CONDUCT_STATUS_MSG[c.status], created_at: c.created_at, updated_at: c.updated_at, my_role: role };
    if (role === 'oversight') {
      return { ...base, category: c.category, severity: c.severity, handler_member_id: c.handler_member_id, handler_name: c.handler_name,
        note: 'Bạn đang xem ở chế độ giám sát: không hiển thị nội dung và danh tính để bảo vệ người liên quan.' };
    }
    const files = await q(`SELECT id, filename, mime, size, created_at, uploaded_by FROM files WHERE parent_type='conduct_case' AND parent_id=$1 ORDER BY created_at`, [id]);
    if (role === 'reported') {
      const ev = await q(`SELECT kind, body, created_at, (actor_member_id=$2) AS mine FROM conduct_case_events WHERE case_id=$1 AND visibility IN ('reported','parties') ORDER BY created_at`, [id, ctx.memberId]);
      return { ...base, explanation_summary: c.explanation_summary, outcome: ['resolved', 'insufficient', 'closed'].includes(c.status) ? c.outcome : null,
        events: ev, files: files.filter((f) => f.uploaded_by === ctx.memberId),
        can_explain: !['closed'].includes(c.status), can_request_review: ['resolved', 'insufficient', 'closed'].includes(c.status),
        note: 'Bạn được mời giải trình. Danh tính người báo cáo và bằng chứng không được chia sẻ. Vui lòng không liên hệ để gây áp lực với người liên quan.' };
    }
    if (role === 'reporter') {
      const ev = await q(`SELECT kind, body, created_at, (actor_member_id=$2) AS mine FROM conduct_case_events WHERE case_id=$1 AND visibility IN ('reporter','parties') ORDER BY created_at`, [id, ctx.memberId]);
      return { ...base, category: c.category, subcode: c.subcode, description: c.description, occurred_at: c.occurred_at, object_type: c.object_type, object_label: c.object_label,
        reported_name: c.reported_name, current_risk: c.current_risk, anonymity: c.anonymity, retaliation_flag: c.retaliation_flag,
        outcome: ['resolved', 'insufficient', 'closed'].includes(c.status) ? c.outcome : null, handler_label: 'Đầu mối xử lý được phân công',
        events: ev, files: files.filter((f) => f.uploaded_by === ctx.memberId),
        can_add_info: c.status !== 'closed', can_request_review: ['resolved', 'insufficient', 'closed'].includes(c.status) };
    }
    // handler
    const ev = await q(`SELECT e.kind, e.visibility, e.body, e.data, e.created_at, CASE WHEN e.actor_member_id=$2 THEN 'Bạn' WHEN e.actor_member_id=$3 THEN $4 WHEN e.actor_member_id=$5 THEN 'Người được báo cáo' ELSE 'Người xử lý khác' END AS actor
                          FROM conduct_case_events e WHERE e.case_id=$1 ORDER BY e.created_at`,
      [id, ctx.memberId, c.reporter_member_id, c.anonymity === 'to_handler' ? 'Người báo cáo (ẩn danh)' : 'Người báo cáo', c.reported_member_id]);
    const related = c.reported_member_id ? await relatedChanges(c) : [];
    return { ...base, category: c.category, subcode: c.subcode, description: c.description, occurred_at: c.occurred_at,
      object_type: c.object_type, object_id: c.object_id, object_label: c.object_label,
      reporter_name: c.anonymity === 'to_handler' ? null : c.reporter_name, anonymous: c.anonymity === 'to_handler',
      reported_member_id: c.reported_member_id, reported_name: c.reported_name, current_risk: c.current_risk, safe_contact: c.safe_contact,
      severity: c.severity, retaliation_flag: c.retaliation_flag, explanation_requested_at: c.explanation_requested_at, explanation_summary: c.explanation_summary,
      outcome: c.outcome, outcome_reason: c.outcome_reason, events: ev, files, related_changes: related,
      note: 'Mức ưu tiên là thứ tự xử lý, không phải kết luận vi phạm. Không dùng điểm tự động để quyết định kỷ luật.' };
  }

  /** Người báo cáo bổ sung thông tin. */
  @Post(':id/info')
  async addInfo(@Param('id') id: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({ body: z.string().trim().min(3).max(4000) }), body);
    const { c, role } = await loadCase(ctx, id);
    if (role !== 'reporter' || c.status === 'closed') throw Errors.forbidden();
    await tx(async (db) => {
      await event(db, id, ctx.memberId, 'info_added', 'reporter', b.body);
      if (c.status === 'needs_info') { await touch(db, id, `status='screening'`); await event(db, id, null, 'status', 'parties', CONDUCT_STATUS_MSG.screening, { status: 'screening' }); }
      else await touch(db, id, `status=status`);
      await ping(db, ctx.companyId, [c.handler_member_id], c.code, id);
    });
    return this.detail(id, ctx);
  }

  /** "Tôi lo ngại bị trả đũa": đánh dấu để xem xét riêng; nếu người xử lý có liên quan thì chuyển người khác. */
  @Post(':id/retaliation')
  async retaliation(@Param('id') id: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({ body: z.string().trim().max(2000).optional() }), body);
    const { c, role } = await loadCase(ctx, id);
    if (role !== 'reporter') throw Errors.forbidden();
    await tx(async (db) => {
      await touch(db, id, `retaliation_flag=true, current_risk=CASE WHEN current_risk='safety' THEN current_risk ELSE 'retaliation' END, severity=CASE WHEN severity IS NULL OR severity < 'S2' THEN 'S2' ELSE severity END`);
      await event(db, id, ctx.memberId, 'retaliation_flag', 'reporter', b.body || 'Người báo cáo lo ngại bị gây áp lực hoặc bất lợi vì đã báo cáo.');
      await ping(db, ctx.companyId, [c.handler_member_id], c.code, id, `Hồ sơ ${c.code}: người báo cáo lo ngại bị trả đũa — cần xem xét riêng`);
    });
    return this.detail(id, ctx);
  }

  /** Người xử lý: cập nhật trạng thái / mức ưu tiên / yêu cầu bổ sung / mời giải trình / ghi chú nội bộ. */
  @Post(':id/handle')
  async handle(@Param('id') id: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({
      action: z.enum(['screening', 'investigating', 'request_info', 'request_explanation', 'severity', 'note', 'link_retaliation']),
      message: z.string().trim().max(4000).optional(), severity: z.enum(['S0', 'S1', 'S2', 'S3', 'S4']).optional(),
    }), body);
    const { c, role } = await loadCase(ctx, id);
    if (role !== 'handler') throw Errors.forbidden('Chỉ đầu mối được phân công xử lý hồ sơ này');
    if (c.status === 'closed') throw Errors.invalidState('Hồ sơ đã đóng');
    await tx(async (db) => {
      switch (b.action) {
        case 'screening': case 'investigating':
          await touch(db, id, `status=$2`, [b.action]);
          await event(db, id, ctx.memberId, 'status', 'parties', CONDUCT_STATUS_MSG[b.action], { status: b.action });
          await ping(db, ctx.companyId, [c.reporter_member_id], c.code, id);
          break;
        case 'request_info':
          if (!b.message || b.message.length < 5) throw Errors.validation('Nêu thông tin cần bổ sung');
          await touch(db, id, `status='needs_info'`);
          await event(db, id, ctx.memberId, 'request_info', 'reporter', `${b.message}\n\n${CONDUCT_STATUS_MSG.needs_info}`, { status: 'needs_info' });
          await ping(db, ctx.companyId, [c.reporter_member_id], c.code, id);
          break;
        case 'request_explanation':
          if (!c.reported_member_id) throw Errors.invalidState('Hồ sơ không có người được báo cáo cụ thể');
          if (!b.message || b.message.length < 10) throw Errors.validation('Viết tóm tắt nội dung cần giải trình (không nêu danh tính người báo cáo)');
          await touch(db, id, `explanation_requested_at=now(), explanation_summary=$2, status='investigating'`, [b.message]);
          await event(db, id, ctx.memberId, 'request_explanation', 'reported', b.message);
          await ping(db, ctx.companyId, [c.reported_member_id], c.code, id, `Bạn được mời gửi giải trình cho hồ sơ ${c.code}. Đăng nhập để xem.`);
          break;
        case 'severity':
          if (!b.severity) throw Errors.validation('Chọn mức ưu tiên');
          await touch(db, id, `severity=$2`, [b.severity]);
          await event(db, id, ctx.memberId, 'severity', 'handler', b.message || null, { severity: b.severity });
          break;
        case 'note': case 'link_retaliation':
          if (!b.message) throw Errors.validation('Nhập ghi chú');
          if (b.action === 'link_retaliation') await touch(db, id, `retaliation_flag=true`);
          await event(db, id, ctx.memberId, b.action === 'note' ? 'note_internal' : 'retaliation_review', 'handler', b.message);
          break;
      }
    });
    return this.detail(id, ctx);
  }

  /** Người được báo cáo gửi giải trình (không sửa/xóa được bằng chứng gốc). */
  @Post(':id/explanation')
  async explanation(@Param('id') id: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({ body: z.string().trim().min(10, 'Nội dung giải trình tối thiểu 10 ký tự').max(6000) }), body);
    const { c, role } = await loadCase(ctx, id);
    if (role !== 'reported' || c.status === 'closed') throw Errors.forbidden();
    await tx(async (db) => {
      await event(db, id, ctx.memberId, 'explanation', 'reported', b.body);
      await touch(db, id, `status=status`);
      await ping(db, ctx.companyId, [c.handler_member_id], c.code, id);
    });
    return this.detail(id, ctx);
  }

  /** Kết quả: đã có kết quả / không đủ cơ sở / chuyển đơn vị phù hợp / đóng. */
  @Post(':id/outcome')
  async outcome(@Param('id') id: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({
      status: z.enum(['resolved', 'insufficient', 'referred', 'closed']),
      outcome: z.string().trim().min(5, 'Nêu kết quả ở mức có thể chia sẻ').max(2000),
      reason: z.string().trim().max(4000).optional(),
      referToMemberId: z.string().uuid().optional(),
    }), body);
    const { c, role } = await loadCase(ctx, id);
    if (role !== 'handler') throw Errors.forbidden('Chỉ đầu mối được phân công xử lý hồ sơ này');
    await tx(async (db) => {
      if (b.status === 'referred') {
        const to = b.referToMemberId;
        if (!to) throw Errors.validation('Chọn đầu mối có thẩm quyền để chuyển');
        if ([c.reporter_member_id, c.reported_member_id].includes(to)) throw new AppError('CONFLICT_OF_INTEREST', 'Không thể chuyển cho người báo cáo hoặc người được báo cáo', 422);
        const m = await q1(`SELECT id FROM company_members WHERE id=$1 AND company_id=$2 AND status='active'`, [to, ctx.companyId], db);
        if (!m) throw Errors.notFound('Thành viên');
        await touch(db, id, `status='referred', handler_member_id=$2`, [to]);
        await event(db, id, ctx.memberId, 'status', 'parties', CONDUCT_STATUS_MSG.referred, { status: 'referred' });
        await event(db, id, ctx.memberId, 'handler', 'handler', b.reason || b.outcome);
        await notify(db, { companyId: ctx.companyId, memberIds: [to], type: 'conduct.new', title: `Hồ sơ ${c.code} được chuyển tới bạn để xem xét`, refType: 'conduct_case', refId: id });
        await ping(db, ctx.companyId, [c.reporter_member_id], c.code, id);
        return;
      }
      await touch(db, id, `status=$2, outcome=$3, outcome_reason=$4, closed_at=CASE WHEN $2 IN ('closed','resolved','insufficient') THEN now() ELSE closed_at END`, [b.status, b.outcome, b.reason ?? null]);
      await event(db, id, ctx.memberId, 'outcome', 'parties', `${CONDUCT_STATUS_MSG[b.status]}\n${b.outcome}`, { status: b.status });
      if (b.reason) await event(db, id, ctx.memberId, 'note_internal', 'handler', b.reason);
      await ping(db, ctx.companyId, [c.reporter_member_id, c.explanation_requested_at ? c.reported_member_id : null], c.code, id);
    });
    return this.detail(id, ctx);
  }

  /** Người xử lý khai báo xung đột lợi ích -> hệ thống chuyển người khác. */
  @Post(':id/conflict')
  async conflict(@Param('id') id: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({ reason: z.string().trim().min(5).max(1000) }), body);
    const { c, role } = await loadCase(ctx, id);
    if (role !== 'handler') throw Errors.forbidden();
    const prev = (await q(`SELECT DISTINCT actor_member_id FROM conduct_case_events WHERE case_id=$1 AND kind IN ('conflict')`, [id])).map((r) => r.actor_member_id);
    const next = await pickHandler(getPool(), ctx.companyId, [c.reporter_member_id, c.reported_member_id, ctx.memberId, ...prev]);
    if (!next) throw new AppError('NO_HANDLER', 'Không còn đầu mối độc lập để chuyển. Liên hệ Chủ doanh nghiệp để chỉ định.', 409);
    await tx(async (db) => {
      await touch(db, id, `handler_member_id=$2`, [next]);
      await event(db, id, ctx.memberId, 'conflict', 'handler', b.reason);
      await notify(db, { companyId: ctx.companyId, memberIds: [next], type: 'conduct.new', title: `Hồ sơ ${c.code} được chuyển tới bạn (người xử lý trước có xung đột lợi ích)`, refType: 'conduct_case', refId: id });
    });
    return { ok: true, message: 'Đã chuyển hồ sơ cho đầu mối khác. Bạn không còn quyền xem hồ sơ này.' };
  }

  /** Yêu cầu xem xét lại (người báo cáo hoặc người được báo cáo) -> người xử lý độc lập khác. */
  @Post(':id/review-request')
  async reviewRequest(@Param('id') id: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({ reason: z.string().trim().min(10, 'Nêu lý do yêu cầu xem xét lại').max(3000) }), body);
    const { c, role } = await loadCase(ctx, id);
    if (role !== 'reporter' && role !== 'reported') throw Errors.forbidden();
    if (!['resolved', 'insufficient', 'closed'].includes(c.status)) throw Errors.invalidState('Chỉ yêu cầu xem xét lại khi hồ sơ đã có kết quả');
    const next = await pickHandler(getPool(), ctx.companyId, [c.reporter_member_id, c.reported_member_id, c.handler_member_id]);
    if (!next) throw new AppError('NO_HANDLER', 'Chưa có người xem xét độc lập. Liên hệ bộ phận nhân sự.', 409);
    await tx(async (db) => {
      await touch(db, id, `status='review_requested', handler_member_id=$2, review_requested_by=$3, closed_at=NULL`, [next, ctx.memberId]);
      await event(db, id, ctx.memberId, 'review_request', role, b.reason);
      await event(db, id, null, 'status', 'parties', CONDUCT_STATUS_MSG.review_requested, { status: 'review_requested' });
      await notify(db, { companyId: ctx.companyId, memberIds: [next], type: 'conduct.new', title: `Hồ sơ ${c.code}: có yêu cầu xem xét lại`, refType: 'conduct_case', refId: id });
    });
    return this.detail(id, ctx);
  }

  /** Chủ DN/Quản trị phân công lại người xử lý (giám sát, không thấy nội dung). */
  @Post(':id/reassign')
  async reassign(@Param('id') id: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({ memberId: z.string().uuid(), reason: z.string().trim().min(5) }), body);
    const { c, role } = await loadCase(ctx, id);
    if (role !== 'oversight') throw Errors.forbidden();
    if ([c.reporter_member_id, c.reported_member_id].includes(b.memberId)) throw new AppError('CONFLICT_OF_INTEREST', 'Người xử lý không được là người báo cáo hoặc người được báo cáo', 422);
    const m = await q1(`SELECT id FROM company_members WHERE id=$1 AND company_id=$2 AND status='active'`, [b.memberId, ctx.companyId]);
    if (!m) throw Errors.notFound('Thành viên');
    await tx(async (db) => {
      await touch(db, id, `handler_member_id=$2`, [b.memberId]);
      await event(db, id, ctx.memberId, 'handler', 'handler', `Phân công lại: ${b.reason}`);
      await notify(db, { companyId: ctx.companyId, memberIds: [b.memberId], type: 'conduct.new', title: `Hồ sơ ${c.code} được phân công cho bạn`, refType: 'conduct_case', refId: id });
    });
    return this.detail(id, ctx);
  }
}

/**
 * Theo dõi dấu hiệu trả đũa: các thay đổi do người được báo cáo thực hiện sau thời điểm báo cáo, liên quan tới người báo cáo
 * (nhiệm vụ, bản ghi tự khai, đơn nghỉ, tăng ca, đánh giá). Chỉ để rà soát — không tự động đảo ngược quyết định quản lý.
 */
async function relatedChanges(c: any) {
  return q(
    `SELECT a.entity_type, a.entity_id, a.action, a.reason, a.created_at,
            COALESCE(t.title, wr.title) AS title
       FROM audit_logs a
       LEFT JOIN tasks t ON a.entity_type='task' AND t.id=a.entity_id
       LEFT JOIN employee_work_records wr ON a.entity_type='work_record' AND wr.id=a.entity_id
      WHERE a.company_id=$1 AND a.actor_id=$2 AND a.created_at > $3
        AND ( (a.entity_type='task' AND EXISTS (SELECT 1 FROM task_assignees ta WHERE ta.task_id=a.entity_id AND ta.company_member_id=$4))
           OR (a.entity_type='work_record' AND wr.employee_id=$4)
           OR (a.entity_type='leave' AND EXISTS (SELECT 1 FROM leave_requests l WHERE l.id=a.entity_id AND l.member_id=$4))
           OR (a.entity_type='overtime' AND EXISTS (SELECT 1 FROM overtime_records o WHERE o.id=a.entity_id AND o.member_id=$4))
           OR (a.entity_type IN ('member','decision') AND a.entity_id=$4) )
      ORDER BY a.created_at DESC LIMIT 50`, [c.company_id, c.reported_member_id, c.created_at, c.reporter_member_id]);
}
