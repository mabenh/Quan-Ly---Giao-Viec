/**
 * Trung tâm quyền riêng tư (SEC-01 mục 6, 12, 13, 16) + cảnh báo bảo mật + truy cập đặc quyền của hỗ trợ nền tảng.
 */
import { Body, Controller, Delete, Get, Param, Post, Patch, Query, Res } from '@nestjs/common';
import { Response } from 'express';
import * as bcrypt from 'bcryptjs';
import { randomUUID } from 'crypto';
import { existsSync, createReadStream, unlinkSync } from 'fs';
import { getPool, q, q1, tx } from '../db/db';
import { AllowNoCompany } from '../common/auth.guard';
import { CurrentCtx, Ctx, isAdmin, isHR } from '../common/context';
import { AppError, Errors } from '../common/errors';
import { parse, z } from '../common/validate';
import { notify } from '../common/notify';
import { getCompany, getMember } from '../common/access';
import { DEFAULT_SETTINGS } from '../common/defaults';
import { ALERT_LABEL, FIELD_DEFAULTS, FIELD_LABEL, accessLog, rateLimit, visibilityOf, hit, securityAlert } from '../common/privacy';
import { storage } from './files.controller';
import { autoHistory } from './profile.controller';

export const CONSENT_PURPOSES: Record<string, { label: string; detail: string }> = {
  face_capture: { label: 'Chụp ảnh gương mặt làm ảnh đại diện', detail: 'Dùng camera trước để chụp ảnh đại diện. Ảnh chỉ dùng hiển thị trong công ty, không dùng nhận diện khuôn mặt. Bạn có thể chọn ảnh có sẵn hoặc không dùng ảnh.' },
  call_recording: { label: 'Ghi âm cuộc gọi khai việc', detail: 'Cho phép đính kèm ghi âm cuộc gọi khi khai việc nhanh. Chỉ người liên quan đến khai việc và quản lý xác nhận được nghe; tự xóa theo thời hạn lưu của công ty.' },
  share_cv_other_companies: { label: 'Chia sẻ lịch sử làm việc tự động với doanh nghiệp khác', detail: 'Khi bạn tham gia doanh nghiệp mới, quản lý ở đó xem được quá trình làm việc của bạn trên Việc Đến ở doanh nghiệp trước.' },
};
const DSR_TYPES = ['access', 'export', 'correction', 'deletion', 'restriction', 'consent_withdrawal'] as const;
const DELETION_SCOPES = ['avatar', 'cv_profile', 'self_history', 'notifications'] as const;

async function pickPrivacyHandler(db: any, companyId: string, exclude: string | null) {
  const r = await q1(`SELECT id FROM company_members WHERE company_id=$1 AND status='active' AND role IN ('hr','owner','admin') AND id IS DISTINCT FROM $2
                       ORDER BY array_position(ARRAY['hr','owner','admin'], role), joined_at LIMIT 1`, [companyId, exclude], db);
  return r?.id ?? null;
}
async function stepUp(userId: string, password?: string) {
  if (!password) throw new AppError('STEP_UP_REQUIRED', 'Nhập lại mật khẩu để xác nhận thao tác này', 401);
  const u = await q1(`SELECT password_hash FROM users WHERE id=$1`, [userId]);
  if (!u?.password_hash || !(await bcrypt.compare(password, u.password_hash))) throw new AppError('STEP_UP_FAILED', 'Mật khẩu không đúng', 422);
}

@Controller()
export class PrivacyController {
  // ---------------- Thiết lập hiển thị ----------------
  @AllowNoCompany()
  @Get('me/privacy')
  async getPrivacy(@CurrentCtx() ctx: Ctx) {
    const vis = (await visibilityOf([ctx.userId])).get(ctx.userId)!;
    const consents: Record<string, any> = {};
    for (const k of Object.keys(CONSENT_PURPOSES)) {
      const r = await q1(`SELECT status, captured_at, withdrawn_at, policy_version FROM consent_records WHERE user_id=$1 AND purpose=$2 ORDER BY captured_at DESC LIMIT 1`, [ctx.userId, k]);
      consents[k] = { ...CONSENT_PURPOSES[k], status: r?.status || 'not_set', at: r?.captured_at || null };
    }
    const restricted = (await q1(`SELECT restricted FROM user_profiles WHERE user_id=$1`, [ctx.userId]))?.restricted ?? false;
    return {
      fields: Object.keys(FIELD_DEFAULTS).map((k) => ({ key: k, label: FIELD_LABEL[k], visibility: vis[k], default: FIELD_DEFAULTS[k] })),
      consents, restricted,
      notes: [
        'Số điện thoại vẫn hiện cho người đang cùng xử lý một việc/đơn cụ thể với bạn (người duyệt đơn, người cùng khai việc) và cho bộ phận Nhân sự để quản trị tài khoản.',
        'Chức danh, bộ phận, ảnh đại diện hiển thị trong công ty theo nhu cầu công việc.',
      ],
    };
  }

  @AllowNoCompany()
  @Patch('me/privacy')
  async setPrivacy(@Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({
      fields: z.partialRecord(z.enum(['phone', 'email', 'dob', 'address', 'contact_email', 'work_history']), z.enum(['only_me', 'related', 'company'])).optional(),
      consents: z.partialRecord(z.enum(['face_capture', 'call_recording', 'share_cv_other_companies']), z.boolean()).optional(),
    }), body);
    await tx(async (c) => {
      for (const [k, v] of Object.entries(b.fields || {})) {
        await q(`INSERT INTO field_visibility_settings(user_id, field_key, visibility) VALUES ($1,$2,$3)
                 ON CONFLICT (user_id, field_key) DO UPDATE SET visibility=$3, updated_at=now()`, [ctx.userId, k, v], c);
      }
      for (const [k, v] of Object.entries(b.consents || {})) {
        const cur = await q1(`SELECT status FROM consent_records WHERE user_id=$1 AND purpose=$2 ORDER BY captured_at DESC LIMIT 1`, [ctx.userId, k], c);
        if ((cur?.status === 'granted') === v) continue;
        if (v) await q(`INSERT INTO consent_records(user_id, purpose, status) VALUES ($1,$2,'granted')`, [ctx.userId, k], c);
        else await q(`INSERT INTO consent_records(user_id, purpose, status, withdrawn_at) VALUES ($1,$2,'withdrawn', now())`, [ctx.userId, k], c);
        // Mục đích dựa trên đồng ý: rút lại thì dừng xử lý trong phạm vi áp dụng (không tự xóa dữ liệu đã có)
        if (k === 'share_cv_other_companies') await q(`INSERT INTO user_profiles(user_id, share_auto_history) VALUES ($1,$2) ON CONFLICT (user_id) DO UPDATE SET share_auto_history=$2`, [ctx.userId, v], c);
      }
      await accessLog({ companyId: ctx.companyId, actorUserId: ctx.userId, actorMemberId: ctx.memberId, action: 'privacy.updated', objectType: 'privacy', objectId: ctx.userId, subjectUserId: ctx.userId, meta: { fields: Object.keys(b.fields || {}), consents: b.consents || {} } }, c);
    });
    return this.getPrivacy(ctx);
  }

  // ---------------- Danh mục dữ liệu ----------------
  @AllowNoCompany()
  @Get('me/data')
  async catalog(@CurrentCtx() ctx: Ctx) {
    const r = ctx.companyId ? (await getCompany(ctx.companyId)).settings.privacy.retention : DEFAULT_SETTINGS.privacy.retention;
    const cnt = async (sql: string) => (await q1(sql, [ctx.userId]))?.n ?? 0;
    return [
      { key: 'account', label: 'Tài khoản', items: 'Họ tên, số điện thoại, email, mật khẩu (đã băm)', purpose: 'Đăng nhập, liên hệ công việc', retention: 'Đến khi xóa tài khoản', recipients: 'Doanh nghiệp bạn tham gia (tên, SĐT theo mức hiển thị)' },
      { key: 'profile', label: 'Hồ sơ CV', items: 'Học vấn, kỹ năng, kinh nghiệm, ngày sinh/địa chỉ (nếu bạn nhập)', purpose: 'Giới thiệu năng lực khi tham gia doanh nghiệp', retention: 'Đến khi bạn xóa', recipients: 'Nhân sự và quản lý trong phạm vi quản lý; trường riêng theo mức hiển thị' },
      { key: 'avatar', label: 'Ảnh đại diện', items: 'Ảnh do bạn chụp/chọn', purpose: 'Nhận diện trong công việc', retention: 'Đến khi bạn xóa', recipients: 'Thành viên công ty' },
      { key: 'work', label: 'Dữ liệu công việc', items: `Nhiệm vụ, bàn giao, bình luận, tệp, khai báo công việc (${await cnt(`SELECT count(*)::int AS n FROM task_assignees ta JOIN company_members cm ON cm.id=ta.company_member_id WHERE cm.user_id=$1`)} nhiệm vụ)`, purpose: 'Giao việc, nghiệm thu, đánh giá hiệu suất', retention: 'Theo chính sách lưu trữ của doanh nghiệp', recipients: 'Người liên quan đến nhiệm vụ, quản lý phụ trách' },
      { key: 'performance', label: 'Đánh giá hiệu suất (bảo mật cao)', items: 'Điểm nghiệm thu, điểm hiệu suất, nhận xét', purpose: 'Tham khảo cho quản lý; không dùng làm căn cứ duy nhất cho quyết định nhân sự', retention: 'Theo chính sách của doanh nghiệp', recipients: 'Bạn, quản lý được giao, Nhân sự được phân quyền' },
      { key: 'hr', label: 'Nghỉ phép, tăng ca, quyết định nhân sự', items: 'Đơn nghỉ, giờ tăng ca, điều chuyển/thôi việc', purpose: 'Quản lý nhân sự', retention: 'Theo nghĩa vụ lưu trữ lao động', recipients: 'Người duyệt, Nhân sự' },
      { key: 'recordings', label: 'Ghi âm cuộc gọi khai việc', items: 'Tệp ghi âm (nếu bạn đồng ý và đính kèm)', purpose: 'Làm bằng chứng giao việc qua điện thoại', retention: `${r.recordingsDays} ngày`, recipients: 'Người cùng khai việc, quản lý xác nhận' },
      { key: 'notifications', label: 'Thông báo', items: 'Thông báo trong ứng dụng', purpose: 'Nhắc việc', retention: `${r.notificationsDays} ngày`, recipients: 'Chỉ bạn' },
      { key: 'logs', label: 'Nhật ký truy cập & kiểm toán', items: 'Đăng nhập, xem hồ sơ, tải/xuất dữ liệu, thay đổi', purpose: 'Bảo mật, truy vết, xử lý khiếu nại', retention: `${r.accessLogsDays} ngày (nhật ký thay đổi nghiệp vụ lưu theo dữ liệu gốc)`, recipients: 'Quản trị được phân quyền; bạn xem lịch sử truy cập vào dữ liệu của mình' },
      { key: 'conduct', label: 'Báo cáo hành vi', items: 'Hồ sơ bạn gửi hoặc liên quan', purpose: 'Bảo vệ an toàn nơi làm việc', retention: `${r.closedConductCaseDays} ngày sau khi đóng`, recipients: 'Chỉ đầu mối xử lý được phân công' },
      { key: 'third_parties', label: 'Bên thứ ba', items: 'Không dùng SDK quảng cáo/theo dõi; không bán dữ liệu; không gửi dữ liệu nhân sự cho dịch vụ AI bên ngoài', purpose: '—', retention: '—', recipients: 'Nhà cung cấp hạ tầng máy chủ (lưu trữ theo hợp đồng)' },
    ];
  }

  // ---------------- Tải dữ liệu của tôi ----------------
  @AllowNoCompany()
  @Post('me/data-export')
  async export(@Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({ password: z.string().optional() }), body);
    await stepUp(ctx.userId, b.password);
    rateLimit(`export-self:${ctx.userId}`, 3, 86400000, 'Mỗi ngày chỉ tạo được 3 bản dữ liệu. Vui lòng thử lại vào ngày mai.');
    const uid = ctx.userId;
    const mids = (await q(`SELECT id FROM company_members WHERE user_id=$1`, [uid])).map((r) => r.id);
    const data = {
      generated_at: new Date().toISOString(),
      note: 'Dữ liệu cá nhân của bạn trên Việc Đến. Không gồm dữ liệu cá nhân của người khác (bình luận, đánh giá của người khác về họ...).',
      account: await q1(`SELECT id, name, phone, email, created_at FROM users WHERE id=$1`, [uid]),
      profile: await q1(`SELECT * FROM user_profiles WHERE user_id=$1`, [uid]),
      work_history_declared: await q(`SELECT company_name, position, start_date, end_date, description FROM user_work_history WHERE user_id=$1`, [uid]),
      visibility: await q(`SELECT field_key, visibility FROM field_visibility_settings WHERE user_id=$1`, [uid]),
      consents: await q(`SELECT purpose, status, captured_at, withdrawn_at, policy_version FROM consent_records WHERE user_id=$1 ORDER BY captured_at`, [uid]),
      memberships: await q(`SELECT c.name AS company, cm.role, cm.title, cm.status, cm.joined_at, cm.left_at FROM company_members cm JOIN companies c ON c.id=cm.company_id WHERE cm.user_id=$1`, [uid]),
      auto_history: await autoHistory(uid),
      tasks: await q(`SELECT t.code, t.title, t.status, ta.assignment_type, t.due_at, t.completed_at,
                             (SELECT total_score FROM task_evaluations e WHERE e.task_id=t.id AND e.decision='approved' ORDER BY created_at DESC LIMIT 1) AS score
                        FROM task_assignees ta JOIN tasks t ON t.id=ta.task_id WHERE ta.company_member_id = ANY($1::uuid[]) ORDER BY t.created_at`, [mids]),
      work_records: await q(`SELECT title, record_type, start_at, end_at, claimed_minutes, status, final_decision FROM employee_work_records WHERE employee_id = ANY($1::uuid[])`, [mids]),
      leaves: await q(`SELECT code, leave_type, start_at, end_at, minutes, reason, status FROM leave_requests WHERE member_id = ANY($1::uuid[])`, [mids]),
      overtime: await q(`SELECT start_at, end_at, minutes, ot_type, cause, approval_status FROM overtime_records WHERE member_id = ANY($1::uuid[])`, [mids]),
      workplace_reports: await q(`SELECT code, category, severity, description, status, created_at FROM workplace_reports WHERE reporter_id = ANY($1::uuid[])`, [mids]),
      conduct_reports_submitted: await q(`SELECT code, category, description, status, created_at FROM conduct_cases WHERE reporter_member_id = ANY($1::uuid[])`, [mids]),
      data_requests: await q(`SELECT code, request_type, status, created_at, resolution FROM data_subject_requests WHERE user_id=$1`, [uid]),
      access_log_about_me: await q(`SELECT action, object_type, result, created_at FROM data_access_logs WHERE subject_user_id=$1 ORDER BY created_at DESC LIMIT 500`, [uid]),
    };
    const hours = ctx.companyId ? (await getCompany(ctx.companyId)).settings.privacy.retention.exportFileHours : 24;
    const key = `exports/${uid}/${randomUUID()}.json`;
    storage.put(key, Buffer.from(JSON.stringify(data, null, 2), 'utf8'));
    const code = `DL-${Date.now().toString(36).toUpperCase()}`;
    const r = await q1(`INSERT INTO data_subject_requests(code, user_id, company_id, request_type, status, resolution, resolved_at, file_key, file_expires_at)
                        VALUES ($1,$2,$3,'export','completed','Tệp dữ liệu đã được tạo', now(), $4, now() + ($5 || ' hours')::interval) RETURNING id, code, file_expires_at`,
      [code, uid, ctx.companyId ?? null, key, String(hours)]);
    await accessLog({ companyId: ctx.companyId, actorUserId: uid, actorMemberId: ctx.memberId, action: 'data.export_self', objectType: 'user', objectId: uid, subjectUserId: uid });
    return { id: r.id, code: r.code, expires_at: r.file_expires_at, message: `Tệp dữ liệu sẵn sàng tải trong ${hours} giờ, sau đó tự xóa.` };
  }

  @AllowNoCompany()
  @Get('me/data-export/:id')
  async exportDownload(@Param('id') id: string, @CurrentCtx() ctx: Ctx, @Res() res: Response) {
    const r = await q1(`SELECT * FROM data_subject_requests WHERE id=$1 AND user_id=$2 AND request_type='export'`, [id, ctx.userId]);
    if (!r || !r.file_key || !r.file_expires_at || new Date(r.file_expires_at) < new Date() || !existsSync(storage.path(r.file_key))) throw Errors.notFound('Tệp dữ liệu (đã hết hạn?)');
    await accessLog({ companyId: ctx.companyId, actorUserId: ctx.userId, actorMemberId: ctx.memberId, action: 'data.export_download', objectType: 'data_export', objectId: id, subjectUserId: ctx.userId });
    res.setHeader('Content-Type', 'application/json; charset=utf-8');
    res.setHeader('Cache-Control', 'no-store');
    res.setHeader('Content-Disposition', `attachment; filename="du-lieu-cua-toi-${r.code}.json"`);
    createReadStream(storage.path(r.file_key)).pipe(res);
  }

  // ---------------- Yêu cầu của chủ thể dữ liệu ----------------
  @AllowNoCompany()
  @Post('me/data-requests')
  async createRequest(@Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({
      type: z.enum(['correction', 'deletion', 'restriction', 'access']),
      fieldKey: z.string().max(60).optional(), proposedValue: z.string().max(500).optional(),
      details: z.string().trim().min(5, 'Mô tả ngắn yêu cầu của bạn').max(3000),
      scope: z.array(z.enum(DELETION_SCOPES)).optional(),
    }), body);
    rateLimit(`dsr:${ctx.userId}`, 10, 86400000);
    if (!ctx.companyId) {
      // Tài khoản cá nhân: xử lý tự phục vụ (xóa CV/ảnh tự làm được); các yêu cầu khác gửi bộ phận hỗ trợ nền tảng
      if (b.type !== 'access') throw Errors.validation('Tài khoản cá nhân có thể tự sửa/xóa hồ sơ và ảnh trong mục Hồ sơ. Yêu cầu khác vui lòng liên hệ hỗ trợ.');
    }
    const due = new Date(Date.now() + (ctx.companyId ? (await getCompany(ctx.companyId)).settings.privacy.requestDueDays : 15) * 86400000);
    const r = await tx(async (c) => {
      const assignee = ctx.companyId ? await pickPrivacyHandler(c, ctx.companyId, ctx.memberId) : null;
      const code = `YC-${Date.now().toString(36).toUpperCase()}`;
      const row = await q1(`INSERT INTO data_subject_requests(code, user_id, company_id, request_type, field_key, proposed_value, details, scope, assigned_to, due_at)
                            VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) RETURNING *`,
        [code, ctx.userId, ctx.companyId ?? null, b.type, b.fieldKey ?? null, b.proposedValue ?? null, b.details, b.scope ? JSON.stringify(b.scope) : null, assignee, due], c);
      if (assignee) await notify(c, { companyId: ctx.companyId, memberIds: [assignee], type: 'privacy.request', title: `Có yêu cầu về dữ liệu cá nhân cần xử lý (${code})`, refType: 'privacy_request', refId: row.id });
      await accessLog({ companyId: ctx.companyId, actorUserId: ctx.userId, actorMemberId: ctx.memberId, action: 'dsr.create', objectType: 'data_request', objectId: row.id, subjectUserId: ctx.userId, meta: { type: b.type } }, c);
      return row;
    });
    return r;
  }

  @AllowNoCompany()
  @Get('me/data-requests')
  async myRequests(@CurrentCtx() ctx: Ctx) {
    return q(`SELECT r.id, r.code, r.request_type, r.field_key, r.proposed_value, r.details, r.status, r.due_at, r.resolution, r.retained_note, r.resolved_at, r.created_at,
                     (r.file_key IS NOT NULL AND r.file_expires_at > now()) AS downloadable, r.file_expires_at
                FROM data_subject_requests r WHERE r.user_id=$1 ORDER BY r.created_at DESC LIMIT 100`, [ctx.userId]);
  }

  @AllowNoCompany()
  @Post('me/data-requests/:id/cancel')
  async cancelRequest(@Param('id') id: string, @CurrentCtx() ctx: Ctx) {
    const r = await q1(`UPDATE data_subject_requests SET status='cancelled' WHERE id=$1 AND user_id=$2 AND status IN ('submitted','in_review') RETURNING id`, [id, ctx.userId]);
    if (!r) throw Errors.notFound('Yêu cầu');
    return this.myRequests(ctx);
  }

  /** Nhân sự xử lý yêu cầu của chủ thể dữ liệu trong công ty. */
  @Get('privacy/requests')
  async hrRequests(@CurrentCtx() ctx: Ctx, @Query('status') status?: string) {
    if (!isHR(ctx)) throw Errors.forbidden();
    return q(`SELECT r.id, r.code, r.request_type, r.field_key, r.proposed_value, r.details, r.scope, r.status, r.due_at, r.resolution, r.retained_note, r.created_at,
                     u.name AS user_name, au.name AS assigned_name, (r.due_at < now() AND r.status IN ('submitted','in_review')) AS overdue, (r.user_id=$2) AS is_mine
                FROM data_subject_requests r JOIN users u ON u.id=r.user_id
                LEFT JOIN company_members a ON a.id=r.assigned_to LEFT JOIN users au ON au.id=a.user_id
               WHERE r.company_id=$1 AND r.request_type <> 'export' AND ($3::text IS NULL OR r.status = ANY(string_to_array($3, ',')))
               ORDER BY (r.status IN ('submitted','in_review')) DESC, r.due_at`, [ctx.companyId, ctx.userId, status || null]);
  }

  @Post('privacy/requests/:id/resolve')
  async resolve(@Param('id') id: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    if (!isHR(ctx)) throw Errors.forbidden();
    const b = parse(z.object({
      status: z.enum(['in_review', 'completed', 'partially_completed', 'rejected']),
      resolution: z.string().trim().min(5, 'Nêu kết quả/lý do').max(3000),
      retainedNote: z.string().trim().max(2000).optional(),
      apply: z.boolean().default(false),
    }), body);
    const r = await q1(`SELECT * FROM data_subject_requests WHERE id=$1 AND company_id=$2`, [id, ctx.companyId]);
    if (!r) throw Errors.notFound('Yêu cầu');
    // Tách nhiệm vụ: người yêu cầu không tự xử lý yêu cầu của mình
    if (r.user_id === ctx.userId) throw new AppError('CONFLICT_OF_INTEREST', 'Bạn không thể tự xử lý yêu cầu của chính mình', 403);
    if (['completed', 'partially_completed', 'rejected', 'cancelled'].includes(r.status)) throw Errors.invalidState('Yêu cầu đã đóng');
    if (b.status === 'rejected' || b.status === 'partially_completed') {
      if (!b.retainedNote && r.request_type === 'deletion') throw Errors.validation('Nêu phần dữ liệu tiếp tục lưu và căn cứ/thời hạn');
    }
    await tx(async (c) => {
      const applied: string[] = [];
      if (b.apply && b.status !== 'rejected' && b.status !== 'in_review') {
        if (r.request_type === 'correction') {
          const m = await q1(`SELECT id FROM company_members WHERE user_id=$1 AND company_id=$2`, [r.user_id, ctx.companyId], c);
          if (r.field_key === 'name' && r.proposed_value) { await q(`UPDATE users SET name=$2 WHERE id=$1`, [r.user_id, r.proposed_value], c); applied.push('name'); }
          else if (r.field_key === 'title' && r.proposed_value && m) { await q(`UPDATE company_members SET title=$2 WHERE id=$1`, [m.id, r.proposed_value], c); applied.push('title'); }
        }
        if (r.request_type === 'restriction') { await q(`INSERT INTO user_profiles(user_id, restricted) VALUES ($1,true) ON CONFLICT (user_id) DO UPDATE SET restricted=true`, [r.user_id], c); applied.push('restricted'); }
        if (r.request_type === 'deletion') {
          const scope: string[] = r.scope || [];
          if (scope.includes('avatar')) { await q(`DELETE FROM user_avatars WHERE user_id=$1`, [r.user_id], c); applied.push('avatar'); }
          if (scope.includes('cv_profile')) {
            await q(`UPDATE user_profiles SET dob=NULL, address=NULL, contact_email=NULL, education=NULL, desired_position=NULL, summary=NULL, years_experience=NULL, field=NULL, skills=NULL, certificates=NULL WHERE user_id=$1`, [r.user_id], c);
            applied.push('cv_profile');
          }
          if (scope.includes('self_history')) { await q(`DELETE FROM user_work_history WHERE user_id=$1`, [r.user_id], c); applied.push('self_history'); }
          if (scope.includes('notifications')) {
            const n = await q(`DELETE FROM notifications WHERE member_id IN (SELECT id FROM company_members WHERE user_id=$1) RETURNING id`, [r.user_id], c);
            applied.push(`notifications:${n.length}`);
          }
          await q(`INSERT INTO data_deletion_jobs(company_id, scope, affected, note, completed_at) VALUES ($1,$2,$3,$4, now())`,
            [ctx.companyId, `dsr:${r.code}`, applied.length, applied.join(', ')], c);
        }
      }
      await q(`UPDATE data_subject_requests SET status=$2, resolution=$3, retained_note=$4, resolved_by=$5, resolved_at=CASE WHEN $2='in_review' THEN NULL ELSE now() END WHERE id=$1`,
        [id, b.status, b.resolution + (applied.length ? `\n(Đã áp dụng: ${applied.join(', ')})` : ''), b.retainedNote ?? null, ctx.memberId], c);
      const m = await q1(`SELECT id FROM company_members WHERE user_id=$1 AND company_id=$2`, [r.user_id, ctx.companyId], c);
      if (m) await notify(c, { companyId: ctx.companyId, memberIds: [m.id], type: 'privacy.request_update', title: `Yêu cầu ${r.code} đã được cập nhật`, refType: 'privacy_request', refId: id });
      await accessLog({ companyId: ctx.companyId, actorUserId: ctx.userId, actorMemberId: ctx.memberId, action: 'dsr.resolve', objectType: 'data_request', objectId: id, subjectUserId: r.user_id, meta: { status: b.status, applied } }, c);
    });
    return this.hrRequests(ctx);
  }

  // ---------------- Lịch sử truy cập vào dữ liệu của tôi ----------------
  @AllowNoCompany()
  @Get('me/privacy-access-log')
  async myAccessLog(@CurrentCtx() ctx: Ctx) {
    // Chỉ các lần truy cập vào dữ liệu của chính mình; không lộ dữ liệu của bên thứ ba (chỉ tên & vai trò người xem)
    return q(`SELECT l.id, l.action, l.object_type, l.result, l.reason, l.created_at,
                     CASE WHEN l.actor_user_id=$1 THEN 'Bạn' ELSE COALESCE(u.name, 'Hệ thống') END AS actor_name, cm.role AS actor_role, cm.id AS actor_member_id
                FROM data_access_logs l LEFT JOIN users u ON u.id=l.actor_user_id LEFT JOIN company_members cm ON cm.id=l.actor_member_id
               WHERE l.subject_user_id=$1 ORDER BY l.created_at DESC LIMIT 200`, [ctx.userId]);
  }

  // ---------------- Giới hạn liên hệ phi công việc ----------------
  @Get('me/contact-blocks')
  async blocks(@CurrentCtx() ctx: Ctx) {
    return q(`SELECT b.blocked_member_id AS member_id, u.name, b.created_at FROM contact_blocks b JOIN company_members cm ON cm.id=b.blocked_member_id JOIN users u ON u.id=cm.user_id
               WHERE b.blocker_member_id=$1 ORDER BY b.created_at DESC`, [ctx.memberId]);
  }
  @Post('me/contact-blocks')
  async addBlock(@Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({ memberId: z.string().uuid() }), body);
    if (b.memberId === ctx.memberId) throw Errors.validation('Không thể chọn chính mình');
    await getMember(ctx, b.memberId);
    await q(`INSERT INTO contact_blocks(company_id, blocker_member_id, blocked_member_id) VALUES ($1,$2,$3) ON CONFLICT DO NOTHING`, [ctx.companyId, ctx.memberId, b.memberId]);
    await accessLog({ companyId: ctx.companyId, actorUserId: ctx.userId, actorMemberId: ctx.memberId, action: 'contact.block', objectType: 'member', objectId: b.memberId });
    return this.blocks(ctx);
  }
  @Delete('me/contact-blocks/:memberId')
  async removeBlock(@Param('memberId') memberId: string, @CurrentCtx() ctx: Ctx) {
    await q(`DELETE FROM contact_blocks WHERE blocker_member_id=$1 AND blocked_member_id=$2`, [ctx.memberId, memberId]);
    return this.blocks(ctx);
  }

  // ---------------- Cảnh báo bảo mật (tín hiệu, không phải kết luận) ----------------
  @AllowNoCompany()
  @Get('security/alerts')
  async alerts(@CurrentCtx() ctx: Ctx, @Query('status') status = 'open') {
    if (ctx.isPlatformAdmin && !ctx.companyId) {
      return q(`SELECT a.*, u.name AS user_name FROM security_alerts a LEFT JOIN users u ON u.id=a.user_id WHERE a.company_id IS NULL AND ($1='all' OR a.status=$1) ORDER BY a.created_at DESC LIMIT 200`, [status]);
    }
    if (!isAdmin(ctx)) throw Errors.forbidden();
    return q(`SELECT a.*, u.name AS user_name FROM security_alerts a LEFT JOIN users u ON u.id=a.user_id
               WHERE (a.company_id=$1 OR (a.company_id IS NULL AND a.user_id IN (SELECT user_id FROM company_members WHERE company_id=$1)))
                 AND ($2='all' OR a.status=$2) ORDER BY a.created_at DESC LIMIT 200`, [ctx.companyId, status]);
  }
  @Post('security/alerts/:id/review')
  async reviewAlert(@Param('id') id: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    if (!isAdmin(ctx)) throw Errors.forbidden();
    const b = parse(z.object({ status: z.enum(['reviewed', 'dismissed']), note: z.string().trim().min(3).max(1000) }), body);
    const a = await q1(`SELECT * FROM security_alerts WHERE id=$1 AND (company_id=$2 OR (company_id IS NULL AND user_id IN (SELECT user_id FROM company_members WHERE company_id=$2)))`, [id, ctx.companyId]);
    if (!a) throw Errors.notFound('Cảnh báo');
    if (a.user_id === ctx.userId) throw new AppError('CONFLICT_OF_INTEREST', 'Cảnh báo liên quan đến chính bạn cần người khác rà soát', 403);
    await q(`UPDATE security_alerts SET status=$2, review_note=$3, reviewed_by=$4, reviewed_at=now() WHERE id=$1`, [id, b.status, b.note, ctx.memberId]);
    return this.alerts(ctx, 'open');
  }

  // ---------------- Truy cập đặc quyền của hỗ trợ nền tảng ----------------
  @AllowNoCompany()
  @Post('support/access-requests')
  async requestAccess(@Body() body: any, @CurrentCtx() ctx: Ctx) {
    if (!ctx.isPlatformAdmin) throw Errors.forbidden();
    const b = parse(z.object({
      companyId: z.string().uuid(), scope: z.enum(['company_settings', 'members_basic', 'audit_logs']),
      reason: z.string().trim().min(10, 'Nêu mục đích cụ thể'), ticket: z.string().max(100).optional(),
      hours: z.number().int().min(1).max(24).default(4), emergency: z.boolean().default(false),
    }), body);
    const c = await q1(`SELECT id, name FROM companies WHERE id=$1`, [b.companyId]);
    if (!c) throw Errors.notFound('Doanh nghiệp');
    const r = await tx(async (db) => {
      // Khẩn cấp: hiệu lực ngay tối đa 1 giờ, bắt buộc hậu kiểm bởi doanh nghiệp
      const row = await q1(`INSERT INTO privileged_access_requests(company_id, requester_user_id, scope, reason, ticket, hours, emergency, status, decided_at, expires_at)
                            VALUES ($1,$2,$3,$4,$5,$6,$7,$8, CASE WHEN $7 THEN now() END, CASE WHEN $7 THEN now() + interval '1 hour' END) RETURNING *`,
        [b.companyId, ctx.userId, b.scope, b.reason, b.ticket ?? null, b.emergency ? 1 : b.hours, b.emergency, b.emergency ? 'approved' : 'pending'], db);
      const admins = (await q(`SELECT id FROM company_members WHERE company_id=$1 AND status='active' AND role IN ('owner','admin')`, [b.companyId], db)).map((x) => x.id);
      await notify(db, { companyId: b.companyId, memberIds: admins, type: 'support.access',
        title: b.emergency ? 'Hỗ trợ nền tảng đã dùng quyền truy cập khẩn cấp — cần hậu kiểm' : 'Hỗ trợ nền tảng xin quyền truy cập tạm thời — cần duyệt', refType: 'support_access', refId: row.id });
      await accessLog({ companyId: b.companyId, actorUserId: ctx.userId, action: 'support.access_request', objectType: 'privileged_access', objectId: row.id, reason: b.reason, meta: { scope: b.scope, emergency: b.emergency } }, db);
      return row;
    });
    return r;
  }

  @AllowNoCompany()
  @Get('support/access-requests')
  async accessRequests(@CurrentCtx() ctx: Ctx) {
    await q(`UPDATE privileged_access_requests SET status='expired' WHERE status='approved' AND expires_at < now()`);
    if (ctx.isPlatformAdmin && !ctx.companyId) {
      return q(`SELECT p.*, c.name AS company_name FROM privileged_access_requests p JOIN companies c ON c.id=p.company_id WHERE p.requester_user_id=$1 ORDER BY p.created_at DESC LIMIT 100`, [ctx.userId]);
    }
    if (!isAdmin(ctx)) throw Errors.forbidden();
    return q(`SELECT p.*, u.name AS requester_name FROM privileged_access_requests p JOIN users u ON u.id=p.requester_user_id WHERE p.company_id=$1 ORDER BY p.created_at DESC LIMIT 100`, [ctx.companyId]);
  }

  @Post('support/access-requests/:id/decide')
  async decideAccess(@Param('id') id: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    if (!isAdmin(ctx)) throw Errors.forbidden();
    const b = parse(z.object({ decision: z.enum(['approve', 'reject', 'revoke']), note: z.string().trim().max(1000).optional() }), body);
    const p = await q1(`SELECT * FROM privileged_access_requests WHERE id=$1 AND company_id=$2`, [id, ctx.companyId]);
    if (!p) throw Errors.notFound('Yêu cầu');
    if (p.requester_user_id === ctx.userId) throw new AppError('CONFLICT_OF_INTEREST', 'Người yêu cầu không được tự phê duyệt', 403);
    if (b.decision === 'revoke') {
      await q(`UPDATE privileged_access_requests SET status='revoked', decision_note=$2, approver_member_id=$3 WHERE id=$1`, [id, b.note ?? null, ctx.memberId]);
    } else {
      if (p.status !== 'pending') throw Errors.invalidState('Yêu cầu đã được xử lý');
      await q(`UPDATE privileged_access_requests SET status=$2, approver_member_id=$3, decided_at=now(), decision_note=$4,
                 expires_at=CASE WHEN $2='approved' THEN now() + (hours || ' hours')::interval END WHERE id=$1`,
        [id, b.decision === 'approve' ? 'approved' : 'rejected', ctx.memberId, b.note ?? null]);
    }
    await accessLog({ companyId: ctx.companyId, actorUserId: ctx.userId, actorMemberId: ctx.memberId, action: `support.access_${b.decision}`, objectType: 'privileged_access', objectId: id });
    return this.accessRequests(ctx);
  }

  /** Hỗ trợ nền tảng xem dữ liệu trong phạm vi quyền tạm thời đã được duyệt. Mọi lần xem đều được ghi nhật ký. */
  @AllowNoCompany()
  @Get('support/companies/:companyId/view')
  async supportView(@Param('companyId') companyId: string, @Query('scope') scope: string, @CurrentCtx() ctx: Ctx) {
    if (!ctx.isPlatformAdmin) throw Errors.forbidden();
    const g = await q1(`SELECT * FROM privileged_access_requests WHERE company_id=$1 AND requester_user_id=$2 AND scope=$3 AND status='approved' AND expires_at > now() ORDER BY expires_at DESC LIMIT 1`, [companyId, ctx.userId, scope]);
    if (!g) {
      await accessLog({ companyId, actorUserId: ctx.userId, action: 'support.view', objectType: 'company', objectId: companyId, result: 'denied', meta: { scope } });
      throw Errors.forbidden('Không có quyền truy cập tạm thời còn hiệu lực cho phạm vi này');
    }
    await accessLog({ companyId, actorUserId: ctx.userId, action: 'support.view', objectType: 'company', objectId: companyId, reason: g.reason, meta: { scope, grant: g.id } });
    if (scope === 'company_settings') return { expires_at: g.expires_at, data: await q1(`SELECT id, name, timezone, settings, created_at FROM companies WHERE id=$1`, [companyId]) };
    if (scope === 'members_basic') return { expires_at: g.expires_at, data: await q(`SELECT cm.id, u.name, cm.role, cm.status, cm.title FROM company_members cm JOIN users u ON u.id=cm.user_id WHERE cm.company_id=$1 ORDER BY u.name`, [companyId]) };
    return { expires_at: g.expires_at, data: await q(`SELECT entity_type, action, created_at FROM audit_logs WHERE company_id=$1 ORDER BY created_at DESC LIMIT 200`, [companyId]) };
  }
}

/** Dọn dữ liệu theo chính sách lưu trữ (chạy trong scheduler, mỗi giờ). */
export async function runRetention(now = new Date()) {
  const out: Record<string, number> = {};
  // Tệp xuất dữ liệu hết hạn: xóa tệp thật, giữ bản ghi yêu cầu
  for (const r of await q(`SELECT id, file_key FROM data_subject_requests WHERE file_key IS NOT NULL AND file_expires_at < $1`, [now])) {
    try { if (existsSync(storage.path(r.file_key))) unlinkSync(storage.path(r.file_key)); } catch { /* bỏ qua */ }
    await q(`UPDATE data_subject_requests SET file_key=NULL WHERE id=$1`, [r.id]);
    out.exports = (out.exports || 0) + 1;
  }
  await q(`UPDATE privileged_access_requests SET status='expired' WHERE status='approved' AND expires_at < $1`, [now]);
  for (const { id: companyId } of await q(`SELECT id FROM companies`)) {
    const r = (await getCompany(companyId)).settings.privacy.retention;
    const notif = await q(`DELETE FROM notifications WHERE company_id=$1 AND created_at < $2::timestamptz - ($3 || ' days')::interval RETURNING id`, [companyId, now, String(r.notificationsDays)]);
    const recs = await q(`SELECT id, storage_key FROM files WHERE company_id=$1 AND parent_type='quick_claim' AND mime LIKE 'audio/%' AND created_at < $2::timestamptz - ($3 || ' days')::interval`, [companyId, now, String(r.recordingsDays)]);
    for (const f of recs) { try { if (existsSync(storage.path(f.storage_key))) unlinkSync(storage.path(f.storage_key)); } catch { /* bỏ qua */ } await q(`DELETE FROM files WHERE id=$1`, [f.id]); }
    let logs = 0;
    await tx(async (c) => {
      await c.query(`SET LOCAL app.retention_purge = 'on'`);
      logs = (await q(`DELETE FROM data_access_logs WHERE company_id=$1 AND created_at < $2::timestamptz - ($3 || ' days')::interval RETURNING id`, [companyId, now, String(r.accessLogsDays)], c)).length;
    });
    const total = notif.length + recs.length + logs;
    if (total) {
      await q(`INSERT INTO data_deletion_jobs(company_id, scope, affected, note, completed_at) VALUES ($1,'retention',$2,$3, now())`,
        [companyId, total, `notifications:${notif.length}, recordings:${recs.length}, access_logs:${logs}`]);
    }
    out.notifications = (out.notifications || 0) + notif.length; out.recordings = (out.recordings || 0) + recs.length; out.access_logs = (out.access_logs || 0) + logs;
  }
  return out;
}
export { ALERT_LABEL, hit, securityAlert };
