import { Body, Controller, Get, Param, Post, Query } from '@nestjs/common';
import { createHash } from 'crypto';
import { getPool, q, q1, tx } from '../db/db';
import { CurrentCtx, Ctx, isAdmin } from '../common/context';
import { AppError, Errors } from '../common/errors';
import { parse, z } from '../common/validate';
import { notify } from '../common/notify';
import { audit } from '../common/audit';
import { authority } from '../common/authority';
import { companyAdmins } from '../common/access';

/**
 * Báo cáo / phản ánh nhiệm vụ trong nhóm, phòng ban (v11).
 * - Công khai tên hoặc ẨN DANH. Ẩn danh: KHÔNG lưu danh tính người báo (chỉ lưu băm một chiều để chống báo trùng) — quản lý không thể biết ai báo.
 * - Nhiều người cùng báo một việc + cùng lý do được gộp vào một hồ sơ: hiển thị tên công việc, người phụ trách, lý do và số người báo cáo.
 * - Gửi người phụ trách tầng 5 (trưởng phòng của nhóm/công việc); nằm ở Công việc › Cần xử lý › Báo cáo.
 * - Kết luận có ảnh hưởng tiến độ/chất lượng -> đưa vào dòng thời gian (thống kê) của nhiệm vụ.
 */
export const MR_CATEGORY: Record<string, string> = {
  falsified_result: 'Gian dối về kết quả', left_post: 'Tự ý rời vị trí công việc', attire: 'Không đúng tác phong – trang phục',
  food_in_production: 'Mang đồ ăn – thức uống vào khu vực sản xuất', support_unrecorded: 'Hỗ trợ không được ghi nhận', safety: 'Vi phạm an toàn', other: 'Khác',
};
const reporterHash = (companyId: string, memberId: string, caseId: string) =>
  createHash('sha256').update(`${process.env.FIELD_ENCRYPTION_KEY || process.env.JWT_SECRET || 'dev'}|mr|${companyId}|${memberId}|${caseId}`).digest('hex');

const CASE = `SELECT c.*, t.code AS task_code, t.title AS task_title, g.name AS group_name, d.name AS department_name, hu.name AS handler_name, ru.name AS resolved_by_name,
    (SELECT count(*)::int FROM member_reports r WHERE r.case_id=c.id) AS reporter_count,
    (SELECT count(*)::int FROM member_reports r WHERE r.case_id=c.id AND r.anonymous) AS anonymous_count,
    (SELECT max(created_at) FROM member_reports r WHERE r.case_id=c.id) AS last_reported_at,
    (SELECT ou.name FROM task_assignees o JOIN company_members ocm ON ocm.id=o.company_member_id JOIN users ou ON ou.id=ocm.user_id WHERE o.task_id=c.task_id AND o.assignment_type='owner' AND o.active LIMIT 1) AS task_owner_name
  FROM member_report_cases c LEFT JOIN tasks t ON t.id=c.task_id LEFT JOIN groups g ON g.id=c.group_id LEFT JOIN departments d ON d.id=c.department_id
  LEFT JOIN company_members hcm ON hcm.id=c.handler_id LEFT JOIN users hu ON hu.id=hcm.user_id
  LEFT JOIN company_members rcm ON rcm.id=c.resolved_by LEFT JOIN users ru ON ru.id=rcm.user_id`;

@Controller('member-reports')
export class MemberReportsController {
  @Post()
  async create(@Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({
      taskId: z.string().uuid().optional().nullable(), groupId: z.string().uuid().optional().nullable(),
      category: z.enum(['falsified_result', 'left_post', 'attire', 'food_in_production', 'support_unrecorded', 'safety', 'other']),
      description: z.string().trim().min(10, 'Mô tả nội dung phản ánh (tối thiểu 10 ký tự)').max(2000), anonymous: z.boolean().default(false), occurredAt: z.coerce.date().optional(),
    }), body);
    let groupId = b.groupId ?? null;
    if (b.taskId) {
      const t = await q1(`SELECT id, group_id FROM tasks WHERE id=$1 AND company_id=$2`, [b.taskId, ctx.companyId]);
      if (!t) throw Errors.notFound('Nhiệm vụ');
      groupId = t.group_id;
    }
    if (!groupId && !b.taskId) {
      groupId = (await q1(`SELECT g.id FROM groups g LEFT JOIN group_members gm ON gm.group_id=g.id AND gm.company_member_id=$1 WHERE g.deleted_at IS NULL AND (gm.id IS NOT NULL OR g.manager_member_id=$1) LIMIT 1`, [ctx.memberId]))?.id ?? null;
    }
    const g = groupId ? await q1(`SELECT id, department_id, manager_member_id FROM groups WHERE id=$1 AND company_id=$2`, [groupId, ctx.companyId]) : null;
    const deptId = g?.department_id || (await q1(`SELECT department_id FROM company_members WHERE id=$1`, [ctx.memberId]))?.department_id || null;
    // Người phụ trách tầng 5: trưởng phòng -> quản lý nhóm -> Ban quản trị
    let handler = deptId ? (await q1(`SELECT head_member_id FROM departments WHERE id=$1`, [deptId]))?.head_member_id : null;
    if (!handler) handler = g?.manager_member_id || (await companyAdmins(ctx.companyId))[0] || null;
    if (b.category === 'support_unrecorded' && !b.taskId) throw Errors.validation('Chọn nhiệm vụ bạn đã hỗ trợ nhưng không được ghi nhận');
    const res = await tx(async (c) => {
      // Gộp: cùng nhiệm vụ (hoặc cùng nhóm khi không có nhiệm vụ) + cùng lý do + hồ sơ đang mở
      let kase = await q1(`SELECT * FROM member_report_cases WHERE company_id=$1 AND category=$2 AND status='open' AND task_id IS NOT DISTINCT FROM $3 AND ($3::uuid IS NOT NULL OR group_id IS NOT DISTINCT FROM $4) FOR UPDATE`,
        [ctx.companyId, b.category, b.taskId ?? null, groupId], c);
      let fresh = false;
      if (!kase) {
        const n = (await q1(`SELECT count(*)::int + 1 AS n FROM member_report_cases WHERE company_id=$1`, [ctx.companyId], c)).n;
        kase = await q1(`INSERT INTO member_report_cases(company_id, code, task_id, group_id, department_id, category, handler_id) VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING *`,
          [ctx.companyId, `PA-${String(n).padStart(5, '0')}`, b.taskId ?? null, groupId, deptId, b.category, handler], c);
        fresh = true;
      }
      const hash = reporterHash(ctx.companyId, ctx.memberId, kase.id);
      const dup = await q1(`SELECT 1 FROM member_reports WHERE case_id=$1 AND reporter_hash=$2`, [kase.id, hash], c);
      if (dup) throw new AppError('ALREADY_REPORTED', 'Bạn đã báo cáo nội dung này rồi — hồ sơ đang được người phụ trách xử lý', 409);
      await q(`INSERT INTO member_reports(case_id, company_id, anonymous, reporter_id, reporter_hash, description, occurred_at) VALUES ($1,$2,$3,$4,$5,$6,$7)`,
        [kase.id, ctx.companyId, b.anonymous, b.anonymous ? null : ctx.memberId, hash, b.description, b.occurredAt ?? new Date()], c);
      const count = (await q1(`SELECT count(*)::int AS n FROM member_reports WHERE case_id=$1`, [kase.id], c)).n;
      // Không ghi audit có danh tính khi ẩn danh
      if (!b.anonymous) await audit(c, ctx, 'member_report', kase.id, 'member_report.submitted', null, { category: b.category, task: b.taskId });
      await notify(c, { companyId: ctx.companyId, memberIds: [kase.handler_id], excludeMemberId: b.anonymous ? undefined : ctx.memberId, type: 'member_report.new',
        title: `${fresh ? 'Phản ánh mới' : `Thêm người phản ánh (${count})`}: ${MR_CATEGORY[b.category]}`, body: b.anonymous ? 'Người báo cáo ẩn danh' : `Từ ${ctx.name}`, refType: 'member_report', refId: kase.id,
        dedupeKey: `mr:${kase.id}:${count}` });
      return { id: kase.id, code: kase.code, count };
    });
    return { ...res, anonymous: b.anonymous, message: b.anonymous ? `Đã gửi phản ánh ẩn danh (mã ${res.code}). Người phụ trách không biết danh tính của bạn.` : `Đã gửi phản ánh (mã ${res.code}).` };
  }

  /** handling: hồ sơ tôi phụ trách (tầng 5); mine: phản ánh công khai tên của tôi; all: Ban điều hành. */
  @Get()
  async list(@CurrentCtx() ctx: Ctx, @Query('scope') scope = 'handling', @Query('status') status?: string) {
    const au = await authority(ctx);
    const where = scope === 'mine' ? `EXISTS (SELECT 1 FROM member_reports r WHERE r.case_id=c.id AND r.reporter_id=$2)`
      : scope === 'all' && (isAdmin(ctx) || au.tier <= 4) ? 'TRUE'
      : `(c.handler_id=$2 OR (c.department_id IS NOT NULL AND c.department_id=$3::uuid AND ${au.tier <= 5}))`;
    return q(`${CASE} WHERE c.company_id=$1 AND ${where} AND ($4::text IS NULL OR c.status=$4) AND ($3::uuid IS NULL OR TRUE) ORDER BY (c.status='open') DESC, c.created_at DESC LIMIT 200`,
      [ctx.companyId, ctx.memberId, au.departmentId, status || null]).then((r) => r.map((x) => ({ ...x, category_label: MR_CATEGORY[x.category] })));
  }

  @Get(':id')
  async detail(@Param('id') id: string, @CurrentCtx() ctx: Ctx) {
    const c = await q1(`${CASE} WHERE c.id=$1 AND c.company_id=$2`, [id, ctx.companyId]);
    if (!c) throw Errors.notFound('Hồ sơ phản ánh');
    const au = await authority(ctx);
    const handler = c.handler_id === ctx.memberId || isAdmin(ctx) || au.tier <= 4 || (au.tier === 5 && au.departmentId && au.departmentId === c.department_id);
    const mine = await q1(`SELECT 1 FROM member_reports WHERE case_id=$1 AND reporter_id=$2`, [id, ctx.memberId]);
    if (!handler && !mine) throw Errors.notFound('Hồ sơ phản ánh');
    // Ẩn danh: không có reporter_id trong DB -> không ai (kể cả quản lý) thấy tên
    const reports = await q(`SELECT r.id, r.anonymous, r.description, r.occurred_at, r.created_at, CASE WHEN r.anonymous THEN NULL ELSE u.name END AS reporter_name
                               FROM member_reports r LEFT JOIN company_members cm ON cm.id=r.reporter_id LEFT JOIN users u ON u.id=cm.user_id WHERE r.case_id=$1 ORDER BY r.created_at`, [id]);
    return { ...c, category_label: MR_CATEGORY[c.category], reports: handler ? reports : reports.filter((r: any) => r.reporter_name && mine),
      permissions: { can_resolve: handler && c.status === 'open' && c.handler_id !== null } };
  }

  /** Người phụ trách kết luận: có/không ảnh hưởng tiến độ, chất lượng; cách xử lý. */
  @Post(':id/resolve')
  async resolve(@Param('id') id: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({ decision: z.enum(['resolved', 'dismissed']), conclusion: z.string().trim().min(5, 'Nêu kết luận (≥5 ký tự)'), actionTaken: z.string().trim().max(1000).optional(),
      affectsProgress: z.boolean().default(false), affectsQuality: z.boolean().default(false) }), body);
    const c = await this.detail(id, ctx);
    if (!c.permissions.can_resolve) throw Errors.forbidden('Chỉ người phụ trách mới kết luận hồ sơ phản ánh');
    await tx(async (cx) => {
      await q(`UPDATE member_report_cases SET status=$2, conclusion=$3, action_taken=$4, affects_progress=$5, affects_quality=$6, resolved_by=$7, resolved_at=now() WHERE id=$1`,
        [id, b.decision, b.conclusion, b.actionTaken ?? null, b.decision === 'resolved' && b.affectsProgress, b.decision === 'resolved' && b.affectsQuality, ctx.memberId], cx);
      await audit(cx, ctx, 'member_report', id, 'member_report.' + b.decision, null, { affects_progress: b.affectsProgress, affects_quality: b.affectsQuality }, b.conclusion);
      const named = await q(`SELECT DISTINCT reporter_id FROM member_reports WHERE case_id=$1 AND reporter_id IS NOT NULL`, [id], cx);
      await notify(cx, { companyId: ctx.companyId, memberIds: named.map((x: any) => x.reporter_id), type: 'member_report.resolved', title: `Phản ánh ${c.code} đã được ${b.decision === 'resolved' ? 'xử lý' : 'xem xét (không xác nhận)'}`, body: b.conclusion, refType: 'member_report', refId: id });
    });
    return this.detail(id, ctx);
  }
}
void getPool;
