import { Body, Controller, Get, Param, Patch, Post, Query, Req } from '@nestjs/common';
import { createCipheriv, createHash, randomBytes } from 'crypto';
import { getPool, q, q1, tx, Queryable } from '../db/db';
import { CurrentCtx, Ctx, isAdmin } from '../common/context';
import { AppError, Errors } from '../common/errors';
import { parse, z } from '../common/validate';
import { notify } from '../common/notify';
import { audit } from '../common/audit';
import { authority } from '../common/authority';
import { Public } from '../common/auth.guard';
import { hit } from '../common/privacy';
import { onTaskCompleted } from './task-flow';

/** Mã hóa thông tin liên hệ người nhận (AES-256-GCM) — không lưu PII dạng rõ. */
export function encryptField(v: string) {
  const key = createHash('sha256').update(process.env.FIELD_ENCRYPTION_KEY || process.env.JWT_SECRET || 'dev-secret').digest();
  const iv = randomBytes(12); const c = createCipheriv('aes-256-gcm', key, iv);
  const enc = Buffer.concat([c.update(v, 'utf8'), c.final()]);
  return `v1:${iv.toString('base64')}:${c.getAuthTag().toString('base64')}:${enc.toString('base64')}`;
}

/**
 * Hai luồng QR độc lập (Đặc tả bổ sung v2.1):
 *  A. QR kết nối khu vực làm việc → phiên khu vực (work_area_sessions), KHÔNG phải chấm công, không tự hoàn thành nhiệm vụ.
 *  B. QR bàn giao nhiệm vụ bên ngoài → người nhận xác nhận trên trang web công khai; nhánh ngoại lệ bắt buộc giải trình và người giao duyệt.
 * Dùng chung thư viện token (ngẫu nhiên 192 bit, DB chỉ lưu SHA-256) nhưng tách bảng, vòng đời và quyền.
 */
export const newToken = () => randomBytes(24).toString('base64url');
export const hashToken = (t: string) => createHash('sha256').update(String(t || '')).digest('hex');
const publicBase = () => (process.env.PUBLIC_URL || '').replace(/\/$/, '');
const AREA_SESSION_HOURS = () => Number(process.env.AREA_SESSION_HOURS || 12);
const HANDOVER_QR_DAYS = () => Number(process.env.HANDOVER_QR_DAYS || 7);

async function areaEvent(db: Queryable, companyId: string, type: string, actor: string | null, source: string, p: { session?: string | null; area?: string | null; payload?: any }) {
  await q(`INSERT INTO work_area_events(company_id, session_id, work_area_id, event_type, actor_id, source, payload) VALUES ($1,$2,$3,$4,$5,$6,$7)`,
    [companyId, p.session ?? null, p.area ?? null, type, actor, source, p.payload ? JSON.stringify(p.payload) : null], db);
}
async function hoEvent(db: Queryable, companyId: string, taskId: string, type: string, actorType: string, actor: string | null, payload?: any) {
  await q(`INSERT INTO task_handover_events(company_id, task_id, event_type, actor_type, actor_id, payload) VALUES ($1,$2,$3,$4,$5,$6)`,
    [companyId, taskId, type, actorType, actor, payload ? JSON.stringify(payload) : null], db);
}
/** Quản lý khu vực: Ban quản trị, tầng 3–5 (quản lý phòng ban). */
async function canManageAreas(ctx: Ctx) { return isAdmin(ctx) || (await authority(ctx)).tier <= 5; }

const AREA = `SELECT a.*, s.name AS site_name, l.name AS location_name, g.name AS group_name, mu.name AS manager_name,
    (SELECT count(*)::int FROM work_area_sessions x WHERE x.work_area_id=a.id AND x.status='ACTIVE') AS active_sessions,
    (SELECT count(*)::int FROM area_qr_codes qc WHERE qc.work_area_id=a.id AND qc.status='active') AS active_qr
  FROM work_areas a JOIN work_sites s ON s.id=a.site_id LEFT JOIN work_locations l ON l.id=a.work_location_id LEFT JOIN groups g ON g.id=a.group_id
  LEFT JOIN company_members mm ON mm.id=a.manager_member_id LEFT JOIN users mu ON mu.id=mm.user_id`;

const SESSION = `SELECT x.*, a.name AS area_name, s.name AS site_name, w.name AS workstation_name, a.work_location_id, l.name AS location_name, u.name AS employee_name
  FROM work_area_sessions x JOIN work_areas a ON a.id=x.work_area_id JOIN work_sites s ON s.id=a.site_id LEFT JOIN workstations w ON w.id=x.workstation_id
  LEFT JOIN work_locations l ON l.id=a.work_location_id JOIN company_members cm ON cm.id=x.employee_id JOIN users u ON u.id=cm.user_id`;

@Controller()
export class QrController {
  // =================== LUỒNG A: QR KHU VỰC ===================
  @Get('work-sites')
  async sites(@CurrentCtx() ctx: Ctx) {
    return q(`SELECT s.*, (SELECT count(*)::int FROM work_areas a WHERE a.site_id=s.id AND a.status<>'archived') AS area_count FROM work_sites s WHERE s.company_id=$1 AND s.status<>'archived' ORDER BY s.name`, [ctx.companyId]);
  }
  @Post('work-sites')
  async addSite(@Body() body: any, @CurrentCtx() ctx: Ctx) {
    if (!(await canManageAreas(ctx))) throw Errors.forbidden('Chỉ quản lý được cấu hình cơ sở/khu vực');
    const b = parse(z.object({ name: z.string().trim().min(2), address: z.string().trim().max(300).optional() }), body);
    const r = await q1(`INSERT INTO work_sites(company_id, name, address) VALUES ($1,$2,$3) RETURNING *`, [ctx.companyId, b.name, b.address ?? null]);
    await audit(getPool(), ctx, 'work_site', r.id, 'work_site.created', null, b);
    return r;
  }
  @Get('work-areas')
  async areas(@CurrentCtx() ctx: Ctx) {
    return q(`${AREA} WHERE a.company_id=$1 AND a.status<>'archived' ORDER BY s.name, a.name`, [ctx.companyId]);
  }
  @Post('work-areas')
  async addArea(@Body() body: any, @CurrentCtx() ctx: Ctx) {
    if (!(await canManageAreas(ctx))) throw Errors.forbidden('Chỉ quản lý được cấu hình khu vực');
    const b = parse(z.object({ siteId: z.string().uuid(), name: z.string().trim().min(2), parentAreaId: z.string().uuid().nullable().optional(), areaType: z.string().max(40).default('area'),
      workLocationId: z.string().uuid().nullable().optional(), groupId: z.string().uuid().nullable().optional(), managerMemberId: z.string().uuid().nullable().optional() }), body);
    if (!(await q1(`SELECT 1 FROM work_sites WHERE id=$1 AND company_id=$2`, [b.siteId, ctx.companyId]))) throw Errors.notFound('Cơ sở');
    if (b.parentAreaId && !(await q1(`SELECT 1 FROM work_areas WHERE id=$1 AND company_id=$2`, [b.parentAreaId, ctx.companyId]))) throw Errors.notFound('Khu vực cha');
    if (b.workLocationId && !(await q1(`SELECT 1 FROM work_locations WHERE id=$1 AND company_id=$2`, [b.workLocationId, ctx.companyId]))) throw Errors.notFound('Vị trí');
    if (b.groupId && !(await q1(`SELECT 1 FROM groups WHERE id=$1 AND company_id=$2`, [b.groupId, ctx.companyId]))) throw Errors.notFound('Nhóm');
    const r = await q1(`INSERT INTO work_areas(company_id, site_id, parent_area_id, name, area_type, work_location_id, group_id, manager_member_id) VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING id`,
      [ctx.companyId, b.siteId, b.parentAreaId ?? null, b.name, b.areaType, b.workLocationId ?? null, b.groupId ?? null, b.managerMemberId ?? null]);
    await audit(getPool(), ctx, 'work_area', r.id, 'work_area.created', null, b);
    return this.area(r.id, ctx);
  }
  @Patch('work-areas/:id')
  async editArea(@Param('id') id: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    if (!(await canManageAreas(ctx))) throw Errors.forbidden('Chỉ quản lý được cấu hình khu vực');
    const b = parse(z.object({ name: z.string().trim().min(2).optional(), status: z.enum(['active', 'locked', 'archived']).optional(), workLocationId: z.string().uuid().nullable().optional(),
      groupId: z.string().uuid().nullable().optional() }), body);
    const old = await q1(`SELECT * FROM work_areas WHERE id=$1 AND company_id=$2`, [id, ctx.companyId]);
    if (!old) throw Errors.notFound('Khu vực');
    await q(`UPDATE work_areas SET name=COALESCE($2,name), status=COALESCE($3,status), work_location_id=CASE WHEN $4 THEN $5::uuid ELSE work_location_id END,
               group_id=CASE WHEN $6 THEN $7::uuid ELSE group_id END WHERE id=$1`,
      [id, b.name ?? null, b.status ?? null, 'workLocationId' in b, b.workLocationId ?? null, 'groupId' in b, b.groupId ?? null]);
    await audit(getPool(), ctx, 'work_area', id, 'work_area.updated', { name: old.name, status: old.status }, b);
    return this.area(id, ctx);
  }
  @Post('work-areas/:id/workstations')
  async addStation(@Param('id') id: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    if (!(await canManageAreas(ctx))) throw Errors.forbidden('Chỉ quản lý được cấu hình trạm');
    const b = parse(z.object({ code: z.string().trim().min(1).max(30), name: z.string().trim().min(2) }), body);
    if (!(await q1(`SELECT 1 FROM work_areas WHERE id=$1 AND company_id=$2`, [id, ctx.companyId]))) throw Errors.notFound('Khu vực');
    return q1(`INSERT INTO workstations(company_id, area_id, code, name) VALUES ($1,$2,$3,$4) RETURNING *`, [ctx.companyId, id, b.code, b.name]);
  }
  @Get('work-areas/:id')
  async area(@Param('id') id: string, @CurrentCtx() ctx: Ctx) {
    const a = await q1(`${AREA} WHERE a.id=$1 AND a.company_id=$2`, [id, ctx.companyId]);
    if (!a) throw Errors.notFound('Khu vực');
    const manage = await canManageAreas(ctx);
    const [stations, qrs, sessions, tasks] = await Promise.all([
      q(`SELECT * FROM workstations WHERE area_id=$1 AND status<>'archived' ORDER BY code`, [id]),
      manage ? q(`SELECT qc.id, qc.workstation_id, qc.status, qc.issued_at, qc.expires_at, qc.revoked_at, qc.revoke_reason, w.name AS workstation_name, u.name AS created_by_name
                    FROM area_qr_codes qc LEFT JOIN workstations w ON w.id=qc.workstation_id JOIN company_members cm ON cm.id=qc.created_by JOIN users u ON u.id=cm.user_id
                   WHERE qc.work_area_id=$1 ORDER BY qc.issued_at DESC LIMIT 30`, [id]) : Promise.resolve([]),
      q(`${SESSION} WHERE x.work_area_id=$1 AND (x.status='ACTIVE' OR x.started_at > now() - interval '24 hours') ORDER BY x.started_at DESC LIMIT 50`, [id]),
      q(`SELECT t.id, t.code, t.title, t.status FROM work_area_task_links k JOIN tasks t ON t.id=k.task_id WHERE k.work_area_id=$1
         UNION SELECT t.id, t.code, t.title, t.status FROM tasks t WHERE t.company_id=$2 AND $3::uuid IS NOT NULL AND t.work_location_id=$3 AND t.status NOT IN ('completed','cancelled') LIMIT 30`,
        [id, ctx.companyId, a.work_location_id]),
    ]);
    return { ...a, workstations: stations, qr_codes: qrs, sessions, tasks, can_manage: manage };
  }
  @Get('work-areas/:id/history')
  async areaHistory(@Param('id') id: string, @CurrentCtx() ctx: Ctx) {
    if (!(await canManageAreas(ctx))) throw Errors.forbidden('Không có quyền xem lịch sử khu vực');
    return q(`SELECT e.*, u.name AS actor_name FROM work_area_events e LEFT JOIN company_members cm ON cm.id=e.actor_id LEFT JOIN users u ON u.id=cm.user_id
               WHERE e.company_id=$1 AND e.work_area_id=$2 ORDER BY e.occurred_at DESC LIMIT 200`, [ctx.companyId, id]);
  }

  /** Phát hành QR cho khu vực/trạm: token chỉ trả về một lần; mã cũ cùng vị trí bị thay thế. */
  @Post('work-areas/:id/qr-codes')
  async issueAreaQr(@Param('id') id: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    if (!(await canManageAreas(ctx))) throw Errors.forbidden('Chỉ quản lý được phát hành QR');
    const b = parse(z.object({ workstationId: z.string().uuid().nullable().optional(), expiresAt: z.coerce.date().optional() }), body || {});
    const a = await q1(`SELECT * FROM work_areas WHERE id=$1 AND company_id=$2`, [id, ctx.companyId]);
    if (!a) throw Errors.notFound('Khu vực');
    if (b.workstationId && !(await q1(`SELECT 1 FROM workstations WHERE id=$1 AND area_id=$2`, [b.workstationId, id]))) throw Errors.notFound('Trạm');
    const token = newToken();
    const r = await tx(async (c) => {
      const prev = await q1(`UPDATE area_qr_codes SET status='revoked', revoked_at=now(), revoke_reason='Cấp lại mã mới' WHERE work_area_id=$1 AND workstation_id IS NOT DISTINCT FROM $2 AND status='active' RETURNING id`,
        [id, b.workstationId ?? null], c);
      const row = await q1(`INSERT INTO area_qr_codes(company_id, work_area_id, workstation_id, token_hash, expires_at, replaces_id, created_by) VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING id, issued_at, expires_at`,
        [ctx.companyId, id, b.workstationId ?? null, hashToken(token), b.expiresAt ?? null, prev?.id ?? null, ctx.memberId], c);
      await areaEvent(c, ctx.companyId, 'qr.issued', ctx.memberId, 'manager', { area: id, payload: { qr: row.id, replaces: prev?.id ?? null } });
      await audit(c, ctx, 'work_area', id, 'area_qr.issued', null, { qr: row.id });
      return row;
    });
    return { ...r, token, path: `/qr/a/${token}`, url: `${publicBase()}/qr/a/${token}` };
  }
  @Post('area-qr/:id/revoke')
  async revokeAreaQr(@Param('id') id: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    if (!(await canManageAreas(ctx))) throw Errors.forbidden('Chỉ quản lý được thu hồi QR');
    const b = parse(z.object({ reason: z.string().trim().min(3, 'Nêu lý do thu hồi'), lock: z.boolean().default(false) }), body);
    const r = await q1(`UPDATE area_qr_codes SET status=$3, revoked_at=now(), revoke_reason=$4 WHERE id=$1 AND company_id=$2 AND status='active' RETURNING work_area_id`,
      [id, ctx.companyId, b.lock ? 'locked' : 'revoked', b.reason]);
    if (!r) throw Errors.notFound('Mã QR đang hiệu lực');
    await areaEvent(getPool(), ctx.companyId, b.lock ? 'qr.locked' : 'qr.revoked', ctx.memberId, 'manager', { area: r.work_area_id, payload: { qr: id, reason: b.reason } });
    return { ok: true };
  }

  private async resolveAreaToken(ctx: Ctx, token: string) {
    const k = await q1(`SELECT qc.*, a.name AS area_name, a.status AS area_status, a.work_location_id, a.group_id, s.name AS site_name, s.status AS site_status, w.name AS workstation_name, l.name AS location_name
                          FROM area_qr_codes qc JOIN work_areas a ON a.id=qc.work_area_id JOIN work_sites s ON s.id=a.site_id
                          LEFT JOIN workstations w ON w.id=qc.workstation_id LEFT JOIN work_locations l ON l.id=a.work_location_id WHERE qc.token_hash=$1`, [hashToken(token)]);
    // QR sai hoặc thuộc công ty khác: lỗi chung, không tiết lộ
    if (!k || k.company_id !== ctx.companyId) throw new AppError('QR_INVALID', 'Mã QR không hợp lệ', 404);
    if (k.status !== 'active' || (k.expires_at && new Date(k.expires_at) < new Date())) throw new AppError('QR_INACTIVE', 'Mã QR đã bị khóa, thu hồi hoặc hết hạn — báo quản lý khu vực cấp mã mới', 410);
    if (k.area_status !== 'active' || k.site_status !== 'active') throw new AppError('AREA_LOCKED', 'Khu vực đang tạm khóa', 409);
    return k;
  }

  /** Kiểm tra mã — chưa tạo phiên; hiển thị khu vực để nhân viên xác nhận. */
  @Post('area-qr/validate')
  async validate(@Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({ token: z.string().min(10).max(100) }), body);
    if (hit('aqr:' + ctx.userId, 60000) > 30) throw new AppError('RATE_LIMITED', 'Quét quá nhiều lần, thử lại sau 1 phút', 429);
    const k = await this.resolveAreaToken(ctx, b.token);
    const cur = await q1(`${SESSION} WHERE x.employee_id=$1 AND x.status='ACTIVE'`, [ctx.memberId]);
    return { area: { id: k.work_area_id, name: k.area_name, site_name: k.site_name, workstation_id: k.workstation_id, workstation_name: k.workstation_name, location_id: k.work_location_id, location_name: k.location_name },
      current: cur, same: !!cur && cur.work_area_id === k.work_area_id && cur.workstation_id === k.workstation_id };
  }

  /** Kết nối khu vực: idempotent khi quét lại cùng mã; quét mã khác cần xác nhận chuyển (đóng phiên cũ trước). */
  @Post('work-area-sessions/connect')
  async connect(@Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({ token: z.string().min(10).max(100), confirmTransfer: z.boolean().default(false), transferReason: z.string().trim().max(300).optional() }), body);
    const k = await this.resolveAreaToken(ctx, b.token);
    const id = await tx(async (c) => {
      await c.query(`SELECT pg_advisory_xact_lock(hashtext($1))`, ['was:' + ctx.memberId]);
      const cur = await q1(`SELECT * FROM work_area_sessions WHERE employee_id=$1 AND status='ACTIVE' FOR UPDATE`, [ctx.memberId], c);
      if (cur && cur.work_area_id === k.work_area_id && cur.workstation_id === k.workstation_id) return cur.id;
      if (cur && !b.confirmTransfer) {
        const name = (await q1(`SELECT name FROM work_areas WHERE id=$1`, [cur.work_area_id], c)).name;
        throw new AppError('TRANSFER_REQUIRED', `Bạn đang kết nối "${name}". Xác nhận chuyển sang "${k.area_name}"?`, 409, { current_area: name });
      }
      if (cur) {
        await q(`UPDATE work_area_sessions SET status='TRANSFERRED', ended_at=now(), ended_reason=$2 WHERE id=$1`, [cur.id, b.transferReason || `Chuyển sang ${k.area_name}`], c);
        await areaEvent(c, ctx.companyId, 'session.transferred', ctx.memberId, 'employee_scan', { session: cur.id, area: cur.work_area_id, payload: { to_area: k.work_area_id } });
      }
      const s = await q1(`INSERT INTO work_area_sessions(company_id, employee_id, work_area_id, workstation_id, qr_code_id, group_id, verification_source, created_by)
                          VALUES ($1,$2,$3,$4,$5,$6,'employee_scan',$2) RETURNING id`, [ctx.companyId, ctx.memberId, k.work_area_id, k.workstation_id, k.id, k.group_id], c);
      await areaEvent(c, ctx.companyId, 'session.connected', ctx.memberId, 'employee_scan', { session: s.id, area: k.work_area_id, payload: { qr: k.id, from_session: cur?.id ?? null } });
      return s.id;
    });
    return this.mine(ctx, id);
  }

  @Post('work-area-sessions/:id/disconnect')
  async disconnect(@Param('id') id: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({ reason: z.string().trim().max(300).optional() }), body || {});
    const s = await q1(`SELECT * FROM work_area_sessions WHERE id=$1 AND company_id=$2`, [id, ctx.companyId]);
    if (!s) throw Errors.notFound('Phiên khu vực');
    if (s.employee_id !== ctx.memberId && !(await canManageAreas(ctx))) throw Errors.forbidden('Không thể ngắt phiên của người khác');
    if (s.status !== 'ACTIVE') return this.mine(ctx);
    await q(`UPDATE work_area_sessions SET status='ENDED', ended_at=now(), ended_reason=$2 WHERE id=$1`, [id, b.reason || 'Kết thúc chủ động']);
    await areaEvent(getPool(), ctx.companyId, 'session.ended', ctx.memberId, s.employee_id === ctx.memberId ? 'employee_scan' : 'manager_entered', { session: id, area: s.work_area_id, payload: { reason: b.reason } });
    return this.mine(ctx);
  }

  /** Quản lý ghi nhận hộ (nhân viên không quét được): có quyền, lý do, nguồn manager_entered. */
  @Post('work-area-sessions/manager-entry')
  async managerEntry(@Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({ employeeId: z.string().uuid(), areaId: z.string().uuid(), reason: z.string().trim().min(5, 'Nêu lý do ghi nhận hộ') }), body);
    const au = await authority(ctx);
    const emp = await q1(`SELECT id FROM company_members WHERE id=$1 AND company_id=$2 AND status='active'`, [b.employeeId, ctx.companyId]);
    if (!emp) throw Errors.notFound('Nhân viên');
    const leads = await q1(`SELECT 1 FROM groups g JOIN group_members gm ON gm.group_id=g.id WHERE gm.company_member_id=$1 AND (g.leader_member_id=$2 OR g.manager_member_id=$2) LIMIT 1`, [b.employeeId, ctx.memberId]);
    if (!isAdmin(ctx) && au.tier > 5 && !leads) throw Errors.forbidden('Chỉ trưởng nhóm/quản lý của nhân viên mới ghi nhận hộ');
    const a = await q1(`SELECT * FROM work_areas WHERE id=$1 AND company_id=$2 AND status='active'`, [b.areaId, ctx.companyId]);
    if (!a) throw Errors.notFound('Khu vực');
    await tx(async (c) => {
      const cur = await q1(`UPDATE work_area_sessions SET status='TRANSFERRED', ended_at=now(), ended_reason='Quản lý ghi nhận chuyển khu vực' WHERE employee_id=$1 AND status='ACTIVE' RETURNING id, work_area_id`, [b.employeeId], c);
      const s = await q1(`INSERT INTO work_area_sessions(company_id, employee_id, work_area_id, group_id, verification_source, created_by, reason) VALUES ($1,$2,$3,$4,'manager_entered',$5,$6) RETURNING id`,
        [ctx.companyId, b.employeeId, b.areaId, a.group_id, ctx.memberId, b.reason], c);
      await areaEvent(c, ctx.companyId, 'session.manager_entered', ctx.memberId, 'manager_entered', { session: s.id, area: b.areaId, payload: { employee: b.employeeId, reason: b.reason, from_session: cur?.id ?? null } });
      await notify(c, { companyId: ctx.companyId, memberIds: [b.employeeId], type: 'area.manager_entered', title: `${ctx.name} đã ghi nhận bạn đang ở khu vực ${a.name}`, body: b.reason });
    });
    return { ok: true };
  }

  /** Phiên khu vực của tôi: phiên đang kết nối + lịch sử các khu vực trong ngày và thời gian ở lại. */
  @Get('work-area-sessions/me')
  async mine(@CurrentCtx() ctx: Ctx, _id?: string) {
    const active = await q1(`${SESSION} WHERE x.employee_id=$1 AND x.status='ACTIVE'`, [ctx.memberId]);
    const today = await q(`${SESSION} WHERE x.employee_id=$1 AND (x.started_at >= date_trunc('day', now()) OR x.status='ACTIVE' OR x.ended_at >= date_trunc('day', now()))
                            ORDER BY x.started_at`, [ctx.memberId]);
    const items = today.map((s: any) => ({ id: s.id, area_name: s.area_name, site_name: s.site_name, workstation_name: s.workstation_name, location_id: s.work_location_id, location_name: s.location_name,
      started_at: s.started_at, ended_at: s.ended_at, status: s.status, source: s.verification_source,
      minutes: Math.max(0, Math.round(((s.ended_at ? new Date(s.ended_at).getTime() : Date.now()) - Math.max(new Date(s.started_at).getTime(), new Date(new Date().setHours(0, 0, 0, 0)).getTime())) / 60000)) }));
    const byArea: Record<string, { area_name: string; minutes: number; visits: number }> = {};
    for (const i of items) { const k = i.area_name; byArea[k] = byArea[k] || { area_name: k, minutes: 0, visits: 0 }; byArea[k].minutes += i.minutes; byArea[k].visits++; }
    return { active, today: items, totals: Object.values(byArea).sort((a, b) => b.minutes - a.minutes),
      note: 'Phiên khu vực chỉ là ngữ cảnh vận hành — không phải chấm công, không dùng đánh giá năng suất.' };
  }

  // =================== LUỒNG B: QR BÀN GIAO BÊN NGOÀI ===================
  private async task(ctx: Ctx, id: string) {
    const t = await q1(`SELECT t.*, o.company_member_id AS owner_id FROM tasks t LEFT JOIN task_assignees o ON o.task_id=t.id AND o.assignment_type='owner' AND o.active WHERE t.id=$1 AND t.company_id=$2`, [id, ctx.companyId]);
    if (!t) throw Errors.notFound('Nhiệm vụ');
    return t;
  }
  /** Người giao (hoặc người được ủy quyền: quản lý nhóm, Ban quản trị) — không phải người thực hiện. */
  private async isAssigner(ctx: Ctx, t: any) {
    if (t.owner_id === ctx.memberId) return false;
    if (t.created_by === ctx.memberId || isAdmin(ctx)) return true;
    return !!(await q1(`SELECT 1 FROM groups WHERE id=$1 AND manager_member_id=$2`, [t.group_id, ctx.memberId]));
  }

  /** Tạo/cập nhật thông tin bàn giao → nhiệm vụ trở thành loại "Giao tiếp – chuyển giao bên ngoài". */
  @Post('tasks/:id/handover-details')
  async details(@Param('id') id: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({
      recipientName: z.string().trim().min(2, 'Nhập tên người nhận'), recipientContact: z.string().trim().max(120).optional(), contactType: z.enum(['phone', 'email', 'other']).optional(),
      description: z.string().trim().min(3, 'Nội dung bàn giao là bắt buộc'), locationText: z.string().trim().max(300).optional(), expectedAt: z.coerce.date().optional(),
      allowReject: z.boolean().default(true), requiresReview: z.boolean().default(false),
    }), body);
    const t = await this.task(ctx, id);
    if (t.created_by !== ctx.memberId && !isAdmin(ctx) && !(await this.isAssigner(ctx, t))) throw Errors.forbidden('Chỉ người giao việc mới khai báo thông tin bàn giao');
    if (['completed', 'cancelled'].includes(t.status)) throw Errors.invalidState('Nhiệm vụ đã kết thúc');
    await tx(async (c) => {
      await q(`INSERT INTO task_handover_details(company_id, task_id, recipient_name, recipient_contact_encrypted, contact_type, description, location_text, expected_at, allow_reject)
               VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)
               ON CONFLICT (task_id) DO UPDATE SET recipient_name=EXCLUDED.recipient_name, recipient_contact_encrypted=EXCLUDED.recipient_contact_encrypted, contact_type=EXCLUDED.contact_type,
                 description=EXCLUDED.description, location_text=EXCLUDED.location_text, expected_at=EXCLUDED.expected_at, allow_reject=EXCLUDED.allow_reject, updated_at=now()`,
        [ctx.companyId, id, b.recipientName, b.recipientContact ? encryptField(b.recipientContact) : null, b.contactType ?? null, b.description, b.locationText ?? null, b.expectedAt ?? null, b.allowReject], c);
      await q(`UPDATE tasks SET external_handover=true, handover_status=COALESCE(handover_status,'PENDING'), handover_requires_review=$2 WHERE id=$1`, [id, b.requiresReview], c);
      await hoEvent(c, ctx.companyId, id, 'handover.details_saved', 'member', ctx.memberId, { recipient: b.recipientName });
    });
    return this.history(id, ctx);
  }

  /** Người thực hiện "Đề nghị bàn giao": phát hành QR/link cho đợt bàn giao (mã cũ bị thu hồi). */
  @Post('tasks/:id/handover-qr')
  async issueHandoverQr(@Param('id') id: string, @CurrentCtx() ctx: Ctx) {
    const t = await this.task(ctx, id);
    if (!t.external_handover) throw Errors.invalidState('Nhiệm vụ không thuộc loại bàn giao bên ngoài');
    if (t.owner_id !== ctx.memberId && !(await this.isAssigner(ctx, t))) throw Errors.forbidden('Chỉ người thực hiện chính mới đề nghị bàn giao');
    if (!['not_started', 'in_progress', 'revision_requested', 'awaiting_handover'].includes(t.status)) throw Errors.invalidState('Nhiệm vụ không ở trạng thái có thể bàn giao');
    const d = await q1(`SELECT * FROM task_handover_details WHERE task_id=$1`, [id]);
    const token = newToken();
    const days = HANDOVER_QR_DAYS();
    const r = await tx(async (c) => {
      await q(`UPDATE task_handover_qr_codes SET status='revoked', revoked_at=now() WHERE task_id=$1 AND status='active'`, [id], c);
      const batch = (await q1(`SELECT count(*)::int + 1 AS n FROM task_handover_qr_codes WHERE task_id=$1`, [id], c)).n;
      const row = await q1(`INSERT INTO task_handover_qr_codes(company_id, task_id, handover_detail_id, batch_no, token_hash, expires_at, created_by)
                            VALUES ($1,$2,$3,$4,$5, now() + ($6 || ' days')::interval, $7) RETURNING id, batch_no, issued_at, expires_at`, [ctx.companyId, id, d.id, batch, hashToken(token), String(days), ctx.memberId], c);
      await q(`UPDATE tasks SET status='awaiting_handover', handover_status='AWAITING_RECIPIENT', started_at=COALESCE(started_at, now()), updated_at=now() WHERE id=$1`, [id], c);
      await q(`UPDATE task_handover_details SET status='AWAITING_RECIPIENT' WHERE id=$1`, [d.id], c);
      await hoEvent(c, ctx.companyId, id, 'handover.qr_issued', 'member', ctx.memberId, { qr: row.id, batch });
      await audit(c, ctx, 'task', id, 'task.status', { status: t.status }, { status: 'awaiting_handover' });
      return row;
    });
    return { ...r, token, path: `/h/${token}`, url: `${publicBase()}/h/${token}` };
  }
  @Post('tasks/:id/handover-qr/revoke')
  async revokeHandoverQr(@Param('id') id: string, @CurrentCtx() ctx: Ctx) {
    const t = await this.task(ctx, id);
    if (t.owner_id !== ctx.memberId && !(await this.isAssigner(ctx, t))) throw Errors.forbidden('Không có quyền thu hồi');
    await tx(async (c) => {
      const r = await q(`UPDATE task_handover_qr_codes SET status='revoked', revoked_at=now() WHERE task_id=$1 AND status='active' RETURNING id`, [id], c);
      if (r.length && t.status === 'awaiting_handover') await q(`UPDATE tasks SET status='in_progress', handover_status='PENDING' WHERE id=$1`, [id], c);
      await hoEvent(c, ctx.companyId, id, 'handover.qr_revoked', 'member', ctx.memberId, { count: r.length });
    });
    return this.history(id, ctx);
  }

  /** Lịch sử bàn giao: thông tin, các đợt QR (không có token), xác nhận, giải trình, duyệt, sự kiện. */
  @Get('tasks/:id/handover-history')
  async history(@Param('id') id: string, @CurrentCtx() ctx: Ctx) {
    const t = await this.task(ctx, id);
    const involved = t.owner_id === ctx.memberId || (await this.isAssigner(ctx, t)) || !!(await q1(`SELECT 1 FROM task_assignees WHERE task_id=$1 AND company_member_id=$2 AND active`, [id, ctx.memberId]));
    if (!involved && !(await authority(ctx)).caps.has('view_company')) throw Errors.notFound('Nhiệm vụ');
    const d = await q1(`SELECT id, recipient_name, contact_type, description, location_text, expected_at, verification_method, allow_reject, status, (recipient_contact_encrypted IS NOT NULL) AS has_contact
                          FROM task_handover_details WHERE task_id=$1`, [id]);
    const [qrs, confs, exs, events] = await Promise.all([
      q(`SELECT id, batch_no, status, issued_at, expires_at, revoked_at FROM task_handover_qr_codes WHERE task_id=$1 ORDER BY issued_at DESC`, [id]),
      q(`SELECT id, recipient_display_name, confirmation_method, confirmation_status, reason, confirmed_at FROM task_handover_confirmations WHERE task_id=$1 ORDER BY confirmed_at`, [id]),
      q(`SELECT e.*, u.name AS submitted_by_name, r.decision, r.review_reason, r.reviewed_at, ru.name AS reviewed_by_name,
                (SELECT COALESCE(json_agg(json_build_object('id', f.id, 'filename', f.filename, 'mime', f.mime)), '[]') FROM files f WHERE f.parent_type='handover_exception' AND f.parent_id=e.id) AS files
           FROM task_handover_exceptions e JOIN company_members cm ON cm.id=e.submitted_by JOIN users u ON u.id=cm.user_id
           LEFT JOIN task_handover_reviews r ON r.exception_id=e.id LEFT JOIN company_members rcm ON rcm.id=r.reviewed_by LEFT JOIN users ru ON ru.id=rcm.user_id
          WHERE e.task_id=$1 ORDER BY e.submitted_at`, [id]),
      q(`SELECT ev.event_type, ev.actor_type, ev.occurred_at, ev.payload, u.name AS actor_name FROM task_handover_events ev LEFT JOIN company_members cm ON cm.id=ev.actor_id LEFT JOIN users u ON u.id=cm.user_id
          WHERE ev.task_id=$1 ORDER BY ev.occurred_at`, [id]),
    ]);
    const performer = t.owner_id === ctx.memberId;
    const assigner = await this.isAssigner(ctx, t);
    const pending = exs.find((e: any) => e.status === 'PENDING');
    return {
      task: { id: t.id, code: t.code, title: t.title, status: t.status, handover_status: t.handover_status, external_handover: t.external_handover, requires_review: t.handover_requires_review },
      details: d, qr_codes: qrs, confirmations: confs, exceptions: exs, events,
      permissions: {
        can_edit_details: (t.created_by === ctx.memberId || assigner) && !['completed', 'cancelled'].includes(t.status),
        can_issue_qr: t.external_handover && !!d && (performer || assigner) && ['not_started', 'in_progress', 'revision_requested', 'awaiting_handover'].includes(t.status),
        can_submit_exception: t.external_handover && performer && ['in_progress', 'awaiting_handover', 'revision_requested', 'not_started'].includes(t.status) && !pending,
        can_review_exception: !!pending && assigner && pending.submitted_by !== ctx.memberId,
      },
    };
  }

  /** Nhân viên bỏ qua QR: bắt buộc giải trình → nhiệm vụ TREO chờ người giao duyệt, chưa tính hoàn thành. */
  @Post('tasks/:id/handover-exceptions')
  async submitException(@Param('id') id: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({ reason: z.string().trim().min(10, 'Giải trình bắt buộc (tối thiểu 10 ký tự)'),
      cause: z.enum(['recipient_absent', 'no_device', 'network', 'qr_error', 'recipient_refused_scan', 'remote_handover', 'other']).default('other') }), body);
    const t = await this.task(ctx, id);
    if (!t.external_handover) throw Errors.invalidState('Nhiệm vụ không thuộc loại bàn giao bên ngoài');
    if (t.owner_id !== ctx.memberId) throw Errors.forbidden('Chỉ người thực hiện chính mới gửi giải trình');
    if (!['in_progress', 'awaiting_handover', 'revision_requested', 'not_started'].includes(t.status)) throw Errors.invalidState('Nhiệm vụ không ở trạng thái có thể gửi giải trình');
    const e = await tx(async (c) => {
      const row = await q1(`INSERT INTO task_handover_exceptions(company_id, task_id, submitted_by, reason, cause) VALUES ($1,$2,$3,$4,$5) RETURNING id`, [ctx.companyId, id, ctx.memberId, b.reason, b.cause], c);
      await q(`UPDATE task_handover_qr_codes SET status='revoked', revoked_at=now() WHERE task_id=$1 AND status='active'`, [id], c);
      await q(`UPDATE tasks SET status='pending_exception_review', handover_status='EXCEPTION_PENDING', updated_at=now() WHERE id=$1`, [id], c);
      await hoEvent(c, ctx.companyId, id, 'handover.exception_submitted', 'member', ctx.memberId, { exception: row.id, cause: b.cause });
      await audit(c, ctx, 'task', id, 'task.status', { status: t.status }, { status: 'pending_exception_review' }, b.reason);
      const reviewers = [t.created_by, (await q1(`SELECT manager_member_id FROM groups WHERE id=$1`, [t.group_id], c))?.manager_member_id].filter((x) => x && x !== ctx.memberId);
      await notify(c, { companyId: ctx.companyId, memberIds: reviewers, type: 'handover.exception', title: `${ctx.name} không bàn giao được bằng QR — cần bạn duyệt giải trình`, body: t.title, refType: 'task', refId: id });
      return row;
    });
    return { id: e.id, ...(await this.history(id, ctx)) };
  }

  @Get('handover-exceptions')
  async exceptions(@CurrentCtx() ctx: Ctx, @Query('status') status = 'PENDING') {
    const all = isAdmin(ctx);
    return q(`SELECT e.*, t.code AS task_code, t.title AS task_title, t.priority, g.name AS group_name, u.name AS submitted_by_name, d.recipient_name,
                     EXTRACT(EPOCH FROM (now() - e.submitted_at))/3600 AS waiting_hours
                FROM task_handover_exceptions e JOIN tasks t ON t.id=e.task_id LEFT JOIN groups g ON g.id=t.group_id
                JOIN company_members cm ON cm.id=e.submitted_by JOIN users u ON u.id=cm.user_id LEFT JOIN task_handover_details d ON d.task_id=t.id
               WHERE e.company_id=$1 AND e.status=$2 AND e.submitted_by<>$3 AND ($4::boolean OR t.created_by=$3 OR g.manager_member_id=$3)
               ORDER BY e.submitted_at LIMIT 200`, [ctx.companyId, status, ctx.memberId, all]);
  }

  /** Người giao/ủy quyền duyệt giải trình: chấp nhận → hoàn thành theo ngoại lệ; từ chối (bắt buộc lý do) → trả về xử lý. */
  @Post('handover-exceptions/:id/review')
  async review(@Param('id') id: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({ decision: z.enum(['APPROVED', 'REJECTED']), reason: z.string().trim().max(1000).optional() }), body);
    if (b.decision === 'REJECTED' && (!b.reason || b.reason.length < 5)) throw Errors.validation('Từ chối giải trình phải có lý do (tối thiểu 5 ký tự)');
    const e = await q1(`SELECT * FROM task_handover_exceptions WHERE id=$1 AND company_id=$2`, [id, ctx.companyId]);
    if (!e) throw Errors.notFound('Giải trình');
    const t = await this.task(ctx, e.task_id);
    if (e.submitted_by === ctx.memberId || !(await this.isAssigner(ctx, t))) throw Errors.forbidden('Chỉ người giao việc hoặc người được ủy quyền mới duyệt giải trình; nhân viên không tự duyệt');
    await tx(async (c) => {
      const locked = await q1(`SELECT status FROM task_handover_exceptions WHERE id=$1 FOR UPDATE`, [id], c);
      if (locked.status !== 'PENDING') throw Errors.invalidState('Giải trình đã được xử lý');
      const cur = await q1(`SELECT status FROM tasks WHERE id=$1 FOR UPDATE`, [t.id], c);
      if (cur.status !== 'pending_exception_review') throw Errors.invalidState('Nhiệm vụ không còn chờ duyệt ngoại lệ');
      await q(`INSERT INTO task_handover_reviews(company_id, exception_id, reviewed_by, decision, review_reason) VALUES ($1,$2,$3,$4,$5)`, [ctx.companyId, id, ctx.memberId, b.decision, b.reason ?? null], c);
      await q(`UPDATE task_handover_exceptions SET status=$2 WHERE id=$1`, [id, b.decision], c);
      if (b.decision === 'APPROVED') {
        const next = t.handover_requires_review ? 'pending_review' : 'completed';
        await q(`UPDATE tasks SET status=$2, handover_status='EXCEPTION_APPROVED', completed_at=CASE WHEN $2='completed' THEN now() END, updated_at=now() WHERE id=$1`, [t.id, next], c);
        await audit(c, ctx, 'task', t.id, 'task.status', { status: 'pending_exception_review' }, { status: next, via: 'handover_exception_approved' }, b.reason ?? null);
        if (next === 'completed') await onTaskCompleted(c, ctx.companyId, t.id);
      } else {
        await q(`UPDATE tasks SET status='in_progress', handover_status='EXCEPTION_REJECTED', updated_at=now() WHERE id=$1`, [t.id], c);
        await audit(c, ctx, 'task', t.id, 'task.status', { status: 'pending_exception_review' }, { status: 'in_progress', via: 'handover_exception_rejected' }, b.reason ?? null);
      }
      await hoEvent(c, ctx.companyId, t.id, 'handover.exception_reviewed', 'member', ctx.memberId, { exception: id, decision: b.decision });
      await notify(c, { companyId: ctx.companyId, memberIds: [e.submitted_by], type: 'handover.exception_reviewed',
        title: b.decision === 'APPROVED' ? `Giải trình bàn giao "${t.title}" được chấp nhận` : `Giải trình bàn giao "${t.title}" bị từ chối: ${b.reason}`, refType: 'task', refId: t.id });
    });
    return this.history(t.id, ctx);
  }

  // ---------- Trang xác nhận công khai cho người nhận (không cần tài khoản) ----------
  private async resolveHandover(token: string, ip: string, kind: string) {
    if (hit('hoip:' + ip, 60000) > 30) throw new AppError('RATE_LIMITED', 'Quá nhiều yêu cầu, vui lòng thử lại sau', 429);
    const k = await q1(`SELECT qc.*, t.status AS task_status, t.code AS task_code, t.title, t.handover_requires_review, t.created_by, c.name AS company_name,
                               d.recipient_name, d.description, d.location_text, d.expected_at, d.allow_reject, o.company_member_id AS owner_id, ou.name AS performer_name
                          FROM task_handover_qr_codes qc JOIN tasks t ON t.id=qc.task_id JOIN companies c ON c.id=qc.company_id JOIN task_handover_details d ON d.id=qc.handover_detail_id
                          LEFT JOIN task_assignees o ON o.task_id=t.id AND o.assignment_type='owner' AND o.active LEFT JOIN company_members ocm ON ocm.id=o.company_member_id LEFT JOIN users ou ON ou.id=ocm.user_id
                         WHERE qc.token_hash=$1`, [hashToken(token)]);
    const fp = createHash('sha256').update(ip).digest('hex').slice(0, 16);
    if (!k) { await q(`INSERT INTO task_handover_attempts(result, request_fingerprint, failure_reason) VALUES ('invalid',$1,$2)`, [fp, kind]); throw new AppError('LINK_INVALID', 'Liên kết xác nhận không hợp lệ', 404); }
    return { k, fp };
  }
  private publicView(k: any, conf?: any) {
    const masked = k.recipient_name ? k.recipient_name.replace(/^(\S+)(.*)$/, (_m: string, a: string, b: string) => a + b.replace(/\S/g, (ch: string, i: number) => (i % 3 === 1 ? ch : '•'))) : null;
    return { company: k.company_name, reference: k.task_code, title: k.title, content: k.description, location: k.location_text, expected_at: k.expected_at,
      recipient_hint: masked, performer: k.performer_name ? k.performer_name.split(' ').slice(-1)[0] : null, allow_reject: k.allow_reject,
      state: conf ? (conf.confirmation_status === 'CONFIRMED' ? 'confirmed' : 'rejected') : k.task_status === 'cancelled' ? 'task_cancelled' : k.status === 'revoked' ? 'revoked'
        : k.status === 'used' ? 'used' : k.expires_at && new Date(k.expires_at) < new Date() ? 'expired' : k.task_status !== 'awaiting_handover' ? 'not_ready' : 'ready',
      confirmed_at: conf?.confirmed_at ?? null };
  }
  @Public()
  @Post('external-handover/validate')
  async extValidate(@Body() body: any, @Req() req: any) {
    const b = parse(z.object({ token: z.string().min(10).max(100) }), body);
    const { k, fp } = await this.resolveHandover(b.token, req.ip || 'x', 'validate');
    const conf = await q1(`SELECT * FROM task_handover_confirmations WHERE qr_code_id=$1`, [k.id]);
    await q(`INSERT INTO task_handover_attempts(company_id, qr_code_id, result, request_fingerprint) VALUES ($1,$2,'viewed',$3)`, [k.company_id, k.id, fp]);
    return this.publicView(k, conf);
  }
  @Public()
  @Post('external-handover/confirm')
  async extConfirm(@Body() body: any, @Req() req: any) {
    const b = parse(z.object({ token: z.string().min(10).max(100), displayName: z.string().trim().min(2, 'Nhập tên người nhận').max(80) }), body);
    return this.extDecide(b.token, 'CONFIRMED', b.displayName, null, req.ip || 'x');
  }
  @Public()
  @Post('external-handover/reject')
  async extReject(@Body() body: any, @Req() req: any) {
    const b = parse(z.object({ token: z.string().min(10).max(100), displayName: z.string().trim().min(2).max(80), reason: z.string().trim().min(5, 'Nêu lý do không tiếp nhận').max(500) }), body);
    return this.extDecide(b.token, 'REJECTED', b.displayName, b.reason, req.ip || 'x');
  }
  private async extDecide(token: string, decision: 'CONFIRMED' | 'REJECTED', name: string, reason: string | null, ip: string) {
    const { k, fp } = await this.resolveHandover(token, ip, decision);
    const result = await tx(async (c) => {
      const qr = await q1(`SELECT * FROM task_handover_qr_codes WHERE id=$1 FOR UPDATE`, [k.id], c);
      const existing = await q1(`SELECT * FROM task_handover_confirmations WHERE qr_code_id=$1`, [k.id], c);
      if (existing) return { conf: existing, repeat: true };   // idempotent: bấm lặp không tạo bản ghi thứ hai
      const t = await q1(`SELECT * FROM tasks WHERE id=$1 FOR UPDATE`, [k.task_id], c);
      if (qr.status !== 'active' || (qr.expires_at && new Date(qr.expires_at) < new Date())) throw new AppError('LINK_INACTIVE', 'Liên kết đã hết hạn hoặc bị thu hồi. Vui lòng liên hệ người bàn giao để nhận liên kết mới.', 410);
      if (t.status !== 'awaiting_handover') throw new AppError('TASK_NOT_READY', t.status === 'cancelled' ? 'Nhiệm vụ đã hủy, không thể xác nhận' : 'Nhiệm vụ không còn chờ xác nhận bàn giao', 409);
      if (decision === 'REJECTED' && !k.allow_reject) throw Errors.forbidden('Không áp dụng từ chối cho bàn giao này');
      const conf = await q1(`INSERT INTO task_handover_confirmations(company_id, task_id, handover_detail_id, qr_code_id, recipient_display_name, confirmation_status, reason)
                             VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING *`, [k.company_id, k.task_id, k.handover_detail_id, k.id, name, decision, reason], c);
      await q(`UPDATE task_handover_qr_codes SET status='used' WHERE id=$1`, [k.id], c);
      if (decision === 'CONFIRMED') {
        const next = t.handover_requires_review ? 'pending_review' : 'completed';
        await q(`UPDATE tasks SET status=$2, handover_status='CONFIRMED', completed_at=CASE WHEN $2='completed' THEN now() END, updated_at=now() WHERE id=$1`, [t.id, next], c);
        await q(`UPDATE task_handover_details SET status='CONFIRMED' WHERE id=$1`, [k.handover_detail_id], c);
        if (next === 'completed') await onTaskCompleted(c, k.company_id, t.id);
      } else {
        await q(`UPDATE tasks SET status='in_progress', handover_status='RECIPIENT_REJECTED', updated_at=now() WHERE id=$1`, [t.id], c);
        await q(`UPDATE task_handover_details SET status='RECIPIENT_REJECTED' WHERE id=$1`, [k.handover_detail_id], c);
      }
      await hoEvent(c, k.company_id, t.id, decision === 'CONFIRMED' ? 'handover.confirmed' : 'handover.recipient_rejected', 'external_recipient', null, { qr: k.id, name, reason });
      await q(`INSERT INTO audit_logs(company_id, actor_id, entity_type, entity_id, action, old_value, new_value, reason) VALUES ($1,NULL,'task',$2,'task.status',$3,$4,$5)`,
        [k.company_id, t.id, JSON.stringify({ status: 'awaiting_handover' }), JSON.stringify({ status: decision === 'CONFIRMED' ? (t.handover_requires_review ? 'pending_review' : 'completed') : 'in_progress', via: 'external_recipient', recipient: name }), reason], c);
      await notify(c, { companyId: k.company_id, memberIds: [k.owner_id, k.created_by], type: decision === 'CONFIRMED' ? 'handover.confirmed' : 'handover.rejected',
        title: decision === 'CONFIRMED' ? `Người nhận đã xác nhận bàn giao: ${t.title}` : `Người nhận KHÔNG tiếp nhận bàn giao: ${t.title}`, body: reason ?? undefined, refType: 'task', refId: t.id });
      return { conf, repeat: false };
    });
    await q(`INSERT INTO task_handover_attempts(company_id, qr_code_id, result, request_fingerprint) VALUES ($1,$2,$3,$4)`, [k.company_id, k.id, result.repeat ? 'repeat' : decision.toLowerCase(), fp]);
    return this.publicView({ ...k, status: 'used' }, result.conf);
  }
}

/** Phiên khu vực quá hạn → EXPIRED (không đồng nghĩa vắng mặt); QR bàn giao quá hạn → expired. */
export async function runQrHousekeeping() {
  const exp = await q(`UPDATE work_area_sessions SET status='EXPIRED', ended_at=now(), ended_reason='Hết hạn theo cấu hình' WHERE status='ACTIVE' AND started_at < now() - ($1 || ' hours')::interval RETURNING id, company_id, work_area_id`, [String(AREA_SESSION_HOURS())]);
  for (const s of exp) await areaEvent(getPool(), s.company_id, 'session.expired', null, 'system', { session: s.id, area: s.work_area_id });
  const qr = await q(`UPDATE task_handover_qr_codes SET status='expired' WHERE status='active' AND expires_at < now() RETURNING id`);
  return { area_sessions_expired: exp.length, handover_qr_expired: qr.length };
}
