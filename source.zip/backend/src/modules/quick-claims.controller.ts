import { Body, Controller, Get, Param, Post, Query } from '@nestjs/common';
import { PoolClient } from 'pg';
import { getPool, q, q1, tx } from '../db/db';
import { CurrentCtx, Ctx, isAdmin } from '../common/context';
import { AppError, Errors } from '../common/errors';
import { parse, z } from '../common/validate';
import { getCompany, getMember } from '../common/access';
import { audit } from '../common/audit';
import { notify } from '../common/notify';
import { addWorkingMinutes } from '../common/calendar';
import { localToday } from './tasks.controller';
import { WorkRecordsController } from './work-records.controller';
import { assertAssignable } from './decisions.controller';

export const CHANNEL: Record<string, string> = { call: 'cuộc gọi', sms: 'tin nhắn SMS', chat: 'tin nhắn', zalo: 'Zalo', direct: 'trao đổi trực tiếp' };
const DEDUPE_HOURS = 2; // cùng cặp quản lý–nhân viên, thời điểm trao đổi gần nhau => coi là cùng một việc

/** Xác định ai là người giao (quản lý) và ai là người nhận việc giữa hai thành viên. */
async function resolvePair(ctx: Ctx, a: string, b: string, db: any) {
  const manages = async (mgr: string, emp: string) => {
    const m = await q1(`SELECT role, status FROM company_members WHERE id=$1`, [mgr], db);
    if (!m || m.status !== 'active') return null;
    const sup = await q1(`SELECT 1 FROM company_members WHERE id=$1 AND supervisor_member_id=$2`, [emp, mgr], db);
    const g = await q1(`SELECT g.id FROM groups g LEFT JOIN group_members gm ON gm.group_id=g.id AND gm.company_member_id=$2
                         WHERE g.manager_member_id=$1 AND g.deleted_at IS NULL AND gm.id IS NOT NULL ORDER BY g.created_at LIMIT 1`, [mgr, emp], db);
    if (g) return { groupId: g.id as string };
    if (sup || ['owner', 'admin'].includes(m.role)) {
      const any = await q1(`SELECT g.id FROM groups g JOIN group_members gm ON gm.group_id=g.id WHERE gm.company_member_id=$1 AND g.deleted_at IS NULL LIMIT 1`, [emp], db);
      return { groupId: (any?.id as string) ?? null };
    }
    return null;
  };
  const ab = await manages(a, b);
  if (ab) return { manager: a, assignee: b, groupId: ab.groupId };
  const ba = await manages(b, a);
  if (ba) return { manager: b, assignee: a, groupId: ba.groupId };
  throw new AppError('NOT_MANAGER_PAIR', 'Khai việc nhanh chỉ dùng giữa quản lý và nhân viên mình quản lý', 422);
}

const SELECT = `
  SELECT qc.*, cu.name AS creator_name, pu.name AS counterpart_name, mu.name AS manager_name, au.name AS assignee_name, g.name AS group_name,
         pu.phone AS counterpart_phone, cu.phone AS creator_phone
    FROM quick_claims qc
    JOIN company_members c1 ON c1.id=qc.creator_id JOIN users cu ON cu.id=c1.user_id
    JOIN company_members c2 ON c2.id=qc.counterpart_id JOIN users pu ON pu.id=c2.user_id
    JOIN company_members c3 ON c3.id=qc.manager_id JOIN users mu ON mu.id=c3.user_id
    JOIN company_members c4 ON c4.id=qc.assignee_id JOIN users au ON au.id=c4.user_id
    LEFT JOIN groups g ON g.id=qc.group_id`;

@Controller('quick-claims')
export class QuickClaimsController {
  private async load(ctx: Ctx, id: string, db: any = getPool()) {
    const r = await q1(`${SELECT} WHERE qc.id=$1 AND qc.company_id=$2`, [id, ctx.companyId], db);
    if (!r || (r.creator_id !== ctx.memberId && r.counterpart_id !== ctx.memberId && !isAdmin(ctx))) throw Errors.notFound('Khai việc');
    return r;
  }

  @Get()
  async list(@CurrentCtx() ctx: Ctx, @Query('status') status?: string) {
    return q(`${SELECT} WHERE qc.company_id=$1 AND (qc.creator_id=$2 OR qc.counterpart_id=$2) AND ($3::text IS NULL OR qc.status=$3)
              ORDER BY (qc.status='pending' AND qc.counterpart_id=$2) DESC, qc.created_at DESC LIMIT 200`, [ctx.companyId, ctx.memberId, status || null]);
  }

  /** Kiểm tra trước khi khai: đã có khai việc chờ xác nhận giữa hai người quanh thời điểm này chưa. */
  @Get('check')
  async check(@CurrentCtx() ctx: Ctx, @Query('counterpartId') counterpartId: string, @Query('occurredAt') occurredAt?: string) {
    const at = occurredAt ? new Date(occurredAt) : new Date();
    const r = await q1(
      `SELECT id, creator_id, title, occurred_at FROM quick_claims WHERE company_id=$1 AND status='pending'
         AND ((creator_id=$2 AND counterpart_id=$3) OR (creator_id=$3 AND counterpart_id=$2))
         AND abs(extract(epoch FROM occurred_at - $4::timestamptz)) <= $5 * 3600 ORDER BY created_at LIMIT 1`,
      [ctx.companyId, ctx.memberId, counterpartId, at, DEDUPE_HOURS]);
    return { existing: r ? { ...r, mine: r.creator_id === ctx.memberId } : null };
  }

  @Post()
  async create(@Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({
      counterpartId: z.string().uuid(), channel: z.enum(['call', 'sms', 'chat', 'zalo', 'direct']), occurredAt: z.coerce.date(),
      title: z.string().trim().min(3, 'Nhập nội dung công việc'), description: z.string().trim().optional(),
      dueAt: z.coerce.date().optional(), estimatedHours: z.number().positive().optional(), alreadyDone: z.boolean().default(false),
      groupId: z.string().uuid().optional(), notDuplicateOf: z.string().uuid().optional(),
    }), body);
    if (b.counterpartId === ctx.memberId) throw Errors.validation('Chọn người đã trao đổi với bạn');
    await getMember(ctx, b.counterpartId);
    const id = await tx(async (c) => {
      const pair = await resolvePair(ctx, ctx.memberId, b.counterpartId, c);
      await assertAssignable(c, [pair.assignee]);
      const dup = await q1(
        `SELECT id, creator_id FROM quick_claims WHERE company_id=$1 AND status='pending' AND manager_id=$2 AND assignee_id=$3
           AND abs(extract(epoch FROM occurred_at - $4::timestamptz)) <= $5 * 3600 LIMIT 1 FOR UPDATE`,
        [ctx.companyId, pair.manager, pair.assignee, b.occurredAt, DEDUPE_HOURS], c);
      if (dup && dup.id !== b.notDuplicateOf) {
        throw new AppError('CLAIM_EXISTS', dup.creator_id === ctx.memberId
          ? 'Bạn đã khai việc này rồi, đang chờ người kia xác nhận'
          : 'Người kia đã khai việc này trước — bạn chỉ cần xác nhận, không cần khai thêm', 409, { id: dup.id });
      }
      const groupId = b.groupId || pair.groupId;
      if (!groupId) throw new AppError('NO_GROUP', 'Nhân viên chưa thuộc nhóm nào của quản lý — hãy thêm vào nhóm trước', 422);
      const r = await q1(
        `INSERT INTO quick_claims(company_id, group_id, creator_id, counterpart_id, manager_id, assignee_id, channel, occurred_at, title, description,
                                  due_at, estimated_hours, already_done)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13) RETURNING id`,
        [ctx.companyId, groupId, ctx.memberId, b.counterpartId, pair.manager, pair.assignee, b.channel, b.occurredAt, b.title, b.description ?? null,
         b.dueAt ?? null, b.estimatedHours ?? null, b.alreadyDone], c);
      await audit(c, ctx, 'quick_claim', r.id, 'quick_claim.created', null, { channel: b.channel, counterpart: b.counterpartId });
      await notify(c, { companyId: ctx.companyId, memberIds: [b.counterpartId], type: 'quick_claim.pending',
        title: `${ctx.name} đã khai việc qua ${CHANNEL[b.channel]} — cần bạn xác nhận`, body: b.title, refType: 'quick_claim', refId: r.id });
      return r.id;
    });
    return this.detail(id, ctx);
  }

  @Get(':id')
  async detail(@Param('id') id: string, @CurrentCtx() ctx: Ctx) {
    const r = await this.load(ctx, id);
    const files = await q(`SELECT id, filename, mime, size, created_at FROM files WHERE parent_type='quick_claim' AND parent_id=$1 ORDER BY created_at`, [id]);
    return {
      ...r, files, channel_label: CHANNEL[r.channel],
      permissions: {
        can_confirm: r.status === 'pending' && r.counterpart_id === ctx.memberId,
        can_cancel: r.status === 'pending' && r.creator_id === ctx.memberId,
        can_convert: r.status === 'rejected' && r.assignee_id === ctx.memberId && !r.work_record_id,
      },
    };
  }

  /** Người kia xác nhận -> tạo nhiệm vụ chính thức (không cần khai thêm). */
  @Post(':id/confirm')
  async confirm(@Param('id') id: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({ dueAt: z.coerce.date().optional(), note: z.string().optional() }), body);
    await tx(async (c) => {
      await c.query(`SELECT 1 FROM quick_claims WHERE id=$1 FOR UPDATE`, [id]);
      const r = await this.load(ctx, id, c);
      if (r.counterpart_id !== ctx.memberId) throw Errors.forbidden('Chỉ người được khai cùng mới xác nhận');
      if (r.status !== 'pending') throw Errors.invalidState('Khai việc đã được xử lý');
      const taskId = await createTaskFromClaim(c, ctx.companyId, r, b.dueAt);
      await q(`UPDATE quick_claims SET status='confirmed', task_id=$2, responded_at=now(), response_reason=$3 WHERE id=$1`, [id, taskId, b.note ?? null], c);
      await audit(c, ctx, 'quick_claim', id, 'quick_claim.confirmed', null, { task: taskId });
      await notify(c, { companyId: ctx.companyId, memberIds: [r.creator_id], type: 'quick_claim.confirmed',
        title: `${ctx.name} đã xác nhận khai việc: ${r.title}`, body: 'Đã tạo nhiệm vụ chính thức', refType: 'task', refId: taskId });
    });
    return this.detail(id, ctx);
  }

  @Post(':id/reject')
  async reject(@Param('id') id: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({ reason: z.string().trim().min(10, 'Nêu lý do cụ thể (≥10 ký tự)') }), body);
    await tx(async (c) => {
      await c.query(`SELECT 1 FROM quick_claims WHERE id=$1 FOR UPDATE`, [id]);
      const r = await this.load(ctx, id, c);
      if (r.counterpart_id !== ctx.memberId) throw Errors.forbidden();
      if (r.status !== 'pending') throw Errors.invalidState('Khai việc đã được xử lý');
      await q(`UPDATE quick_claims SET status='rejected', response_reason=$2, responded_at=now() WHERE id=$1`, [id, b.reason], c);
      await audit(c, ctx, 'quick_claim', id, 'quick_claim.rejected', null, null, b.reason);
      await notify(c, { companyId: ctx.companyId, memberIds: [r.creator_id], type: 'quick_claim.rejected',
        title: `${ctx.name} không xác nhận khai việc: ${r.title}`, body: b.reason, refType: 'quick_claim', refId: id });
    });
    return this.detail(id, ctx);
  }

  @Post(':id/cancel')
  async cancel(@Param('id') id: string, @CurrentCtx() ctx: Ctx) {
    const r = await this.load(ctx, id);
    if (r.creator_id !== ctx.memberId || r.status !== 'pending') throw Errors.invalidState('Không thể hủy');
    await q(`UPDATE quick_claims SET status='cancelled', responded_at=now() WHERE id=$1`, [id]);
    return this.detail(id, ctx);
  }

  /** Khai việc của nhân viên bị quản lý từ chối -> chuyển thành bản ghi tự khai báo (có quy trình tranh chấp/khiếu nại). */
  @Post(':id/to-work-record')
  async toWorkRecord(@Param('id') id: string, @CurrentCtx() ctx: Ctx) {
    const r = await this.load(ctx, id);
    if (r.status !== 'rejected' || r.assignee_id !== ctx.memberId || r.work_record_id) throw Errors.invalidState('Không thể chuyển khai việc này');
    const start = new Date(r.occurred_at);
    const wr = await new WorkRecordsController().create({
      title: r.title, description: r.description || undefined, groupId: r.group_id, requesterMemberId: r.manager_id,
      startAt: start.toISOString(), endAt: new Date(start.getTime() + Math.round((r.estimated_hours || 1) * 3600000)).toISOString(),
      isEstimated: true, recordType: 'assigned_outside', result: r.description || r.title,
      reasonNotInSystem: `Giao qua ${CHANNEL[r.channel]} lúc ${start.toLocaleString('vi-VN')}; khai việc nhanh bị từ chối: ${r.response_reason}`,
    }, ctx);
    await q(`UPDATE quick_claims SET work_record_id=$2 WHERE id=$1`, [id, wr.id]);
    return { work_record_id: wr.id };
  }
}

export async function createTaskFromClaim(c: PoolClient, companyId: string, r: any, dueOverride?: Date) {
  const company = await getCompany(companyId, c);
  const type = await q1(`SELECT id FROM task_types WHERE company_id=$1 AND active ORDER BY name LIMIT 1`, [companyId], c);
  const hours = Number(r.estimated_hours) || 2;
  const due = dueOverride || (r.due_at ? new Date(r.due_at) : addWorkingMinutes(new Date(), Math.max(hours * 60, 240), company.settings.calendar, company.timezone));
  const seq = await q1(`SELECT count(*)::int + 1 AS n FROM tasks WHERE company_id=$1`, [companyId], c);
  const today = await localToday(companyId, c);
  const desc = `${r.description || r.title}\n\n— Nguồn: khai việc nhanh qua ${CHANNEL[r.channel]} lúc ${new Date(r.occurred_at).toLocaleString('vi-VN', { timeZone: company.timezone })}, ${r.creator_name} khai, ${r.counterpart_name} xác nhận.`;
  const t = await q1(
    `INSERT INTO tasks(company_id, group_id, code, title, description, task_type_id, complexity, requirement_level, estimated_hours, due_at, priority,
                       created_by, plan_date, original_plan_date, source_claim_id, status, started_at, first_submitted_at, submitted_at)
     VALUES ($1,$2,$3,$4,$5,$6,'simple','normal',$7,$8,'normal',$9,$10,$10,$11,
             CASE WHEN $12 THEN 'pending_review' ELSE 'not_started' END, CASE WHEN $12 THEN $13::timestamptz END,
             CASE WHEN $12 THEN now() END, CASE WHEN $12 THEN now() END) RETURNING id`,
    [companyId, r.group_id, `NV-${String(seq.n).padStart(5, '0')}`, r.title, desc, type.id, hours, due, r.manager_id, today, r.id, r.already_done, r.occurred_at], c);
  await q(`INSERT INTO task_assignees(task_id, company_member_id, assignment_type) VALUES ($1,$2,'owner')`, [t.id, r.assignee_id], c);
  await q(`INSERT INTO task_criteria(task_id, version, direction, criterion, created_by) VALUES ($1,1,'output',$2,$3)`,
    [t.id, 'Hoàn thành đúng nội dung đã trao đổi qua ' + CHANNEL[r.channel], r.manager_id], c);
  if (r.already_done) {
    await q(`INSERT INTO task_submissions(task_id, submitted_by, output_description, completion_percent) VALUES ($1,$2,$3,100)`,
      [t.id, r.assignee_id, r.description || 'Đã hoàn thành theo trao đổi'], c);
  }
  // chuyển tệp ghi âm/bằng chứng sang nhiệm vụ
  await q(`INSERT INTO files(company_id, parent_type, parent_id, filename, mime, size, storage_key, uploaded_by)
           SELECT company_id, 'task', $2, filename, mime, size, storage_key, uploaded_by FROM files WHERE parent_type='quick_claim' AND parent_id=$1`, [r.id, t.id], c);
  await audit(c, { companyId, memberId: r.manager_id }, 'task', t.id, 'task.created', null, { source: 'quick_claim', claim: r.id, title: r.title });
  return t.id as string;
}
