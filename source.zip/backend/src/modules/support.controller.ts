import { Body, Controller, Get, Param, Patch, Post, Query } from '@nestjs/common';
import { getPool, q, q1, tx } from '../db/db';
import { CurrentCtx, Ctx, isAdmin } from '../common/context';
import { Errors } from '../common/errors';
import { parse, z } from '../common/validate';
import { notify } from '../common/notify';
import { audit } from '../common/audit';
import { authority } from '../common/authority';
import { getCompany } from '../common/access';
import { DateTime } from 'luxon';

/** Nhóm của một thành viên (thành viên, quản lý hoặc trưởng nhóm). */
async function myGroups(memberId: string) {
  return (await q(`SELECT DISTINCT g.id FROM groups g LEFT JOIN group_members gm ON gm.group_id=g.id AND gm.company_member_id=$1
                    WHERE g.deleted_at IS NULL AND (gm.id IS NOT NULL OR g.manager_member_id=$1 OR g.leader_member_id=$1)`, [memberId])).map((r) => r.id as string);
}
async function groupPeople(groupId: string) {
  return (await q(`SELECT company_member_id AS id FROM group_members WHERE group_id=$1
                   UNION SELECT manager_member_id FROM groups WHERE id=$1 UNION SELECT leader_member_id FROM groups WHERE id=$1 AND leader_member_id IS NOT NULL`, [groupId])).map((r) => r.id as string);
}
/** Phòng ban của thành viên: phòng được gán, hoặc phòng của nhóm đầu tiên. */
async function myDepartment(ctx: Ctx) {
  const m = await q1(`SELECT department_id FROM company_members WHERE id=$1`, [ctx.memberId]);
  if (m?.department_id) return m.department_id as string;
  const g = await q1(`SELECT g.department_id FROM groups g LEFT JOIN group_members gm ON gm.group_id=g.id AND gm.company_member_id=$1
                      WHERE g.deleted_at IS NULL AND g.department_id IS NOT NULL AND (gm.id IS NOT NULL OR g.leader_member_id=$1 OR g.manager_member_id=$1) LIMIT 1`, [ctx.memberId]);
  return (g?.department_id as string) || null;
}

const SR = `SELECT r.*, u.name AS requester_name, g.name AS group_name, t.code AS task_code, t.title AS task_title,
   (SELECT COALESCE(json_agg(json_build_object('id', x.id, 'helper_id', x.helper_id, 'helper_name', hu.name, 'status', x.status, 'accepted_at', x.accepted_at,
        'done_at', x.done_at, 'minutes', x.minutes, 'note', x.note, 'decided_at', x.decided_at, 'decision_note', x.decision_note) ORDER BY x.accepted_at), '[]')
      FROM support_responses x JOIN company_members hcm ON hcm.id=x.helper_id JOIN users hu ON hu.id=hcm.user_id WHERE x.request_id=r.id) AS responses
  FROM support_requests r JOIN company_members cm ON cm.id=r.requester_id JOIN users u ON u.id=cm.user_id
  LEFT JOIN groups g ON g.id=r.group_id LEFT JOIN tasks t ON t.id=r.task_id`;

@Controller()
export class SupportController {
  /** Gửi yêu cầu hỗ trợ: đẩy thông báo tới các thành viên khác trong nhóm. */
  @Post('support-requests')
  async create(@Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({
      title: z.string().trim().min(3, 'Nêu ngắn gọn cần hỗ trợ việc gì'), description: z.string().trim().max(2000).optional(),
      taskId: z.string().uuid().optional().nullable(), groupId: z.string().uuid().optional().nullable(), neededPeople: z.number().int().min(1).max(20).default(1),
    }), body);
    let groupId = b.groupId ?? null;
    if (b.taskId) {
      const t = await q1(`SELECT id, group_id FROM tasks WHERE id=$1 AND company_id=$2`, [b.taskId, ctx.companyId]);
      if (!t) throw Errors.notFound('Nhiệm vụ');
      const involved = await q1(`SELECT 1 FROM task_assignees WHERE task_id=$1 AND company_member_id=$2 AND active`, [t.id, ctx.memberId]);
      if (!involved && !isAdmin(ctx)) throw Errors.forbidden('Chỉ người thực hiện nhiệm vụ mới yêu cầu hỗ trợ cho nhiệm vụ này');
      groupId = groupId || t.group_id;
    }
    const mine = await myGroups(ctx.memberId);
    if (!groupId) groupId = mine[0] || null;
    if (!groupId) throw Errors.validation('Bạn chưa thuộc nhóm nào để gửi yêu cầu hỗ trợ');
    if (!mine.includes(groupId) && !b.taskId) throw Errors.forbidden('Chỉ gửi yêu cầu hỗ trợ trong nhóm của bạn');
    const r = await tx(async (c) => {
      const n = (await q1(`SELECT count(*)::int + 1 AS n FROM support_requests WHERE company_id=$1`, [ctx.companyId], c)).n;
      const row = await q1(`INSERT INTO support_requests(company_id, code, requester_id, group_id, task_id, title, description, needed_people) VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *`,
        [ctx.companyId, `HT-${String(n).padStart(5, '0')}`, ctx.memberId, groupId, b.taskId ?? null, b.title, b.description ?? null, b.neededPeople], c);
      await notify(c, { companyId: ctx.companyId, memberIds: await groupPeople(groupId!), excludeMemberId: ctx.memberId, type: 'support.requested',
        title: `${ctx.name} cần hỗ trợ: ${b.title}`, body: b.description, refType: 'support_request', refId: row.id });
      await audit(c, ctx, 'support_request', row.id, 'support.requested', null, { group: groupId, task: b.taskId });
      return row;
    });
    return this.detail(r.id, ctx);
  }

  @Get('support-requests')
  async list(@CurrentCtx() ctx: Ctx, @Query('scope') scope = 'open') {
    const groups = await myGroups(ctx.memberId);
    const where = scope === 'mine' ? `r.requester_id=$2`
      : scope === 'helping' ? `EXISTS (SELECT 1 FROM support_responses x WHERE x.request_id=r.id AND x.helper_id=$2)`
      : `r.status IN ('open','accepted') AND (r.group_id = ANY($3::uuid[]) OR r.requester_id=$2)`;
    return q(`${SR} WHERE r.company_id=$1 AND ${where} ORDER BY r.created_at DESC LIMIT 100`, [ctx.companyId, ctx.memberId, groups]);
  }

  @Get('support-requests/:id')
  async detail(@Param('id') id: string, @CurrentCtx() ctx: Ctx) {
    const r = await q1(`${SR} WHERE r.id=$1 AND r.company_id=$2`, [id, ctx.companyId]);
    if (!r) throw Errors.notFound('Yêu cầu hỗ trợ');
    const inGroup = r.group_id ? (await myGroups(ctx.memberId)).includes(r.group_id) : false;
    const mineResp = r.responses.find((x: any) => x.helper_id === ctx.memberId);
    return { ...r, permissions: {
      can_accept: r.status !== 'closed' && r.status !== 'cancelled' && r.requester_id !== ctx.memberId && inGroup && !mineResp,
      can_done: !!mineResp && mineResp.status === 'accepted',
      can_confirm: r.requester_id === ctx.memberId,
      can_close: r.requester_id === ctx.memberId && ['open', 'accepted'].includes(r.status),
    } };
  }

  /** Thành viên khác trong nhóm tiếp nhận hỗ trợ. */
  @Post('support-requests/:id/accept')
  async accept(@Param('id') id: string, @CurrentCtx() ctx: Ctx) {
    const r = await this.detail(id, ctx);
    if (!r.permissions.can_accept) throw Errors.forbidden(r.requester_id === ctx.memberId ? 'Không thể tự tiếp nhận yêu cầu của mình' : 'Chỉ thành viên cùng nhóm mới tiếp nhận được yêu cầu đang mở');
    await tx(async (c) => {
      await q(`INSERT INTO support_responses(request_id, helper_id) VALUES ($1,$2) ON CONFLICT DO NOTHING`, [id, ctx.memberId], c);
      const n = (await q1(`SELECT count(*)::int AS n FROM support_responses WHERE request_id=$1 AND status IN ('accepted','done','confirmed')`, [id], c)).n;
      if (n >= r.needed_people) await q(`UPDATE support_requests SET status='accepted' WHERE id=$1 AND status='open'`, [id], c);
      await notify(c, { companyId: ctx.companyId, memberIds: [r.requester_id], type: 'support.accepted', title: `${ctx.name} đã tiếp nhận hỗ trợ: ${r.title}`, refType: 'support_request', refId: id });
    });
    return this.detail(id, ctx);
  }

  /** Người hỗ trợ báo đã xong, khai thời gian — chưa được ghi nhận cho tới khi người yêu cầu xác nhận. */
  @Post('support-requests/:id/done')
  async done(@Param('id') id: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({ minutes: z.number().int().min(1).max(720), note: z.string().trim().max(1000).optional() }), body);
    const r = await this.detail(id, ctx);
    if (!r.permissions.can_done) throw Errors.forbidden('Bạn chưa tiếp nhận yêu cầu này');
    await q(`UPDATE support_responses SET status='done', done_at=now(), minutes=$3, note=$4 WHERE request_id=$1 AND helper_id=$2`, [id, ctx.memberId, b.minutes, b.note ?? null]);
    await notify(getPool(), { companyId: ctx.companyId, memberIds: [r.requester_id], type: 'support.done', title: `${ctx.name} đã hỗ trợ xong — cần bạn xác nhận`, body: r.title, refType: 'support_request', refId: id });
    return this.detail(id, ctx);
  }

  /** Người yêu cầu xác nhận/từ chối phần hỗ trợ. Xác nhận mới ghi nhận công việc cho người hỗ trợ (bản ghi hỗ trợ đã chấp nhận). */
  @Post('support-requests/:id/responses/:rid/decide')
  async decide(@Param('id') id: string, @Param('rid') rid: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({ decision: z.enum(['confirm', 'reject']), minutes: z.number().int().min(1).max(720).optional(), note: z.string().trim().max(1000).optional() }), body);
    const r = await this.detail(id, ctx);
    if (r.requester_id !== ctx.memberId) throw Errors.forbidden('Chỉ người yêu cầu hỗ trợ mới xác nhận');
    const x = await q1(`SELECT * FROM support_responses WHERE id=$1 AND request_id=$2`, [rid, id]);
    if (!x || !['accepted', 'done'].includes(x.status)) throw Errors.invalidState('Phần hỗ trợ không ở trạng thái chờ xác nhận');
    if (b.decision === 'reject' && (!b.note || b.note.length < 5)) throw Errors.validation('Nêu lý do không xác nhận (tối thiểu 5 ký tự)');
    const minutes = b.minutes ?? x.minutes;
    if (b.decision === 'confirm' && !minutes) throw Errors.validation('Nhập số phút hỗ trợ được xác nhận');
    await tx(async (c) => {
      await q(`UPDATE support_responses SET status=$2, decided_at=now(), decision_note=$3, minutes=COALESCE($4, minutes) WHERE id=$1`, [rid, b.decision === 'confirm' ? 'confirmed' : 'rejected', b.note ?? null, minutes ?? null], c);
      if (b.decision === 'confirm') {
        const company = await getCompany(ctx.companyId, c);
        const start = new Date(x.accepted_at); const end = new Date(start.getTime() + minutes * 60000);
        const wr = await q1(`INSERT INTO employee_work_records(company_id, employee_id, group_id, title, description, requester_member_id, work_date, start_at, end_at, claimed_minutes,
               record_type, result, completion_status, reason_not_in_system, related_task_id, reviewer_member_id, status, accepted_minutes, final_decision, in_role)
             VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,'support',$11,'done',$12,$13,$6,'accepted',$10,'accepted',true) RETURNING id`,
          [ctx.companyId, x.helper_id, r.group_id, `Hỗ trợ ${r.requester_name}: ${r.title}`, x.note, ctx.memberId, DateTime.fromJSDate(start, { zone: company.timezone }).toISODate(), start, end, minutes,
           x.note || r.title, `Yêu cầu hỗ trợ ${r.code}`, r.task_id], c);
        await q(`INSERT INTO work_record_reviews(work_record_id, reviewer_id, decision, reason, accepted_minutes, chain_no) VALUES ($1,$2,'accept',$3,$4,1)`, [wr.id, ctx.memberId, b.note || 'Người yêu cầu xác nhận hỗ trợ', minutes], c);
        if (r.task_id) {
          await q(`INSERT INTO task_assignees(task_id, company_member_id, assignment_type) SELECT $1,$2,'collaborator'
                   WHERE NOT EXISTS (SELECT 1 FROM task_assignees WHERE task_id=$1 AND company_member_id=$2 AND active)`, [r.task_id, x.helper_id], c);
        }
      }
      await notify(c, { companyId: ctx.companyId, memberIds: [x.helper_id], type: 'support.decided',
        title: b.decision === 'confirm' ? `${ctx.name} đã xác nhận phần hỗ trợ của bạn (${minutes} phút)` : `${ctx.name} không xác nhận phần hỗ trợ: ${b.note}`, refType: 'support_request', refId: id });
      await audit(c, ctx, 'support_request', id, `support.${b.decision}`, null, { helper: x.helper_id, minutes });
    });
    return this.detail(id, ctx);
  }

  @Post('support-requests/:id/close')
  async close(@Param('id') id: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({ cancel: z.boolean().default(false) }), body || {});
    const r = await this.detail(id, ctx);
    if (!r.permissions.can_close) throw Errors.forbidden('Chỉ người yêu cầu mới đóng yêu cầu');
    await q(`UPDATE support_requests SET status=$2, closed_at=now() WHERE id=$1`, [id, b.cancel ? 'cancelled' : 'closed']);
    return this.detail(id, ctx);
  }

  // ---------- Tin chính / thông báo phòng ban ----------
  @Post('department-posts')
  async post(@Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({ title: z.string().trim().min(3), body: z.string().trim().max(4000).optional(), departmentId: z.string().uuid().nullable().optional(), pinned: z.boolean().default(false) }), body);
    const au = await authority(ctx);
    const deptId = b.departmentId === undefined ? au.departmentId : b.departmentId;
    const top = isAdmin(ctx) || au.tier <= 4;
    const head = deptId ? await q1(`SELECT 1 FROM departments WHERE id=$1 AND company_id=$2 AND head_member_id=$3`, [deptId, ctx.companyId, ctx.memberId]) : null;
    if (!top && !(deptId && (head || (au.departmentId === deptId && au.tier <= 5)))) throw Errors.forbidden('Chỉ quản lý phòng ban (hoặc Ban điều hành) mới đăng tin của phòng');
    const p = await q1(`INSERT INTO department_posts(company_id, department_id, author_id, title, body, pinned) VALUES ($1,$2,$3,$4,$5,$6) RETURNING *`,
      [ctx.companyId, deptId ?? null, ctx.memberId, b.title, b.body ?? null, b.pinned]);
    const members = deptId
      ? await q(`SELECT id FROM company_members WHERE company_id=$1 AND status='active' AND department_id=$2
                 UNION SELECT gm.company_member_id FROM group_members gm JOIN groups g ON g.id=gm.group_id WHERE g.department_id=$2`, [ctx.companyId, deptId])
      : await q(`SELECT id FROM company_members WHERE company_id=$1 AND status='active'`, [ctx.companyId]);
    await notify(getPool(), { companyId: ctx.companyId, memberIds: members.map((m) => m.id), excludeMemberId: ctx.memberId, type: 'department.post', title: `Tin phòng: ${b.title}`, refType: 'department_post', refId: p.id });
    return p;
  }
  @Patch('department-posts/:id')
  async editPost(@Param('id') id: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({ pinned: z.boolean().optional(), archived: z.boolean().optional() }), body);
    const p = await q1(`SELECT * FROM department_posts WHERE id=$1 AND company_id=$2`, [id, ctx.companyId]);
    if (!p) throw Errors.notFound('Tin');
    if (p.author_id !== ctx.memberId && !isAdmin(ctx)) throw Errors.forbidden('Chỉ người đăng mới sửa tin');
    if (b.archived) { await q(`DELETE FROM department_posts WHERE id=$1`, [id]); return { ok: true }; }
    return q1(`UPDATE department_posts SET pinned=COALESCE($2,pinned) WHERE id=$1 RETURNING *`, [id, b.pinned ?? null]);
  }

  /**
   * Trang chính phần Công việc: mô tả công việc của vai trò được giao, phòng ban đang ở, tin chính của phòng,
   * và bảng tin thông báo (trở ngại được báo, nhiệm vụ cần hỗ trợ) trong nhóm/phòng ban.
   */
  @Get('work/overview')
  async overview(@CurrentCtx() ctx: Ctx) {
    const au = await authority(ctx);
    const deptId = await myDepartment(ctx);
    const me = await q1(`SELECT cm.title, cm.role, jr.name AS job_role_name, jr.description AS job_role_description, jr.duties AS job_role_duties, p.name AS position_name, cm.job_grade
                           FROM company_members cm LEFT JOIN job_roles jr ON jr.id=cm.job_role_id LEFT JOIN positions p ON p.id=cm.position_id WHERE cm.id=$1`, [ctx.memberId]);
    const dept = deptId ? await q1(`SELECT d.id, d.name, d.function, u.name AS head_name, d.head_member_id,
                            (SELECT count(*)::int FROM company_members m WHERE m.department_id=d.id AND m.status='active') AS member_count
                          FROM departments d LEFT JOIN company_members h ON h.id=d.head_member_id LEFT JOIN users u ON u.id=h.user_id WHERE d.id=$1`, [deptId]) : null;
    const groups = await q(`SELECT g.id, g.name, lu.name AS leader_name FROM groups g LEFT JOIN company_members l ON l.id=COALESCE(g.leader_member_id, g.manager_member_id) LEFT JOIN users lu ON lu.id=l.user_id
                             WHERE g.id = ANY($1::uuid[]) ORDER BY g.name`, [await myGroups(ctx.memberId)]);
    const groupIds = groups.map((g: any) => g.id);
    const posts = await q(`SELECT p.*, u.name AS author_name FROM department_posts p JOIN company_members cm ON cm.id=p.author_id JOIN users u ON u.id=cm.user_id
                            WHERE p.company_id=$1 AND (p.department_id IS NULL OR p.department_id=$2) ORDER BY p.pinned DESC, p.created_at DESC LIMIT 10`, [ctx.companyId, deptId]);
    const deptGroupIds = deptId ? (await q(`SELECT id FROM groups WHERE department_id=$1 AND deleted_at IS NULL`, [deptId])).map((r) => r.id) : [];
    const scopeGroups = [...new Set([...groupIds, ...(au.caps.has('view_dept') || au.caps.has('assign_dept') ? deptGroupIds : [])])];
    const reports = await q(`SELECT w.id, w.code, w.description, w.severity, w.status, w.created_at, u.name AS reporter_name, g.name AS group_name
                              FROM workplace_reports w JOIN company_members cm ON cm.id=w.reporter_id JOIN users u ON u.id=cm.user_id LEFT JOIN groups g ON g.id=w.group_id
                             WHERE w.company_id=$1 AND NOT w.independent_channel AND w.group_id = ANY($2::uuid[]) AND w.created_at > now() - interval '14 days'
                             ORDER BY w.created_at DESC LIMIT 15`, [ctx.companyId, scopeGroups]);
    const support = await q(`${SR} WHERE r.company_id=$1 AND r.status IN ('open','accepted') AND (r.group_id = ANY($2::uuid[]) OR r.requester_id=$3) ORDER BY r.created_at DESC LIMIT 15`,
      [ctx.companyId, scopeGroups, ctx.memberId]);
    const feed = [
      ...reports.map((w: any) => ({ kind: 'report', id: w.id, at: w.created_at, title: `${w.code} · ${w.description.split(/[.\n]/)[0].slice(0, 90)}`, who: w.reporter_name, group: w.group_name, status: w.status, severity: w.severity })),
      ...support.map((r: any) => ({ kind: 'support', id: r.id, at: r.created_at, title: `${r.code} · ${r.title}`, who: r.requester_name, group: r.group_name, status: r.status,
        task: r.task_code ? `${r.task_code} - ${r.task_title}` : null, helpers: r.responses.length, needed: r.needed_people, mine: r.requester_id === ctx.memberId })),
    ].sort((a, b) => +new Date(b.at) - +new Date(a.at));
    const t = await q1(`SELECT count(*) FILTER (WHERE t.status IN ('not_started','in_progress','revision_requested','awaiting_handover'))::int AS open,
                               count(*) FILTER (WHERE t.status IN ('not_started','in_progress','revision_requested','awaiting_handover') AND t.due_at < now())::int AS overdue,
                               count(*) FILTER (WHERE t.status='pending_exception_review')::int AS on_hold
                          FROM task_assignees a JOIN tasks t ON t.id=a.task_id WHERE a.company_member_id=$1 AND a.active`, [ctx.memberId]);
    return {
      me: { ...me, tier: au.tier, position: au.positionName, caps: [...au.caps] },
      department: dept, groups, posts, feed, tasks: t,
      can_post: isAdmin(ctx) || au.tier <= 4 || (!!dept && (dept.head_member_id === ctx.memberId || (au.tier <= 5 && au.departmentId === dept.id))),
    };
  }
}
