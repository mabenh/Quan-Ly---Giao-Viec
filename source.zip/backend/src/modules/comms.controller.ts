import { Body, Controller, Get, Param, Post, Put, Query, Res, UploadedFile, UseInterceptors } from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { randomBytes, randomUUID } from 'crypto';
import { existsSync, unlinkSync } from 'fs';
import { extname } from 'path';
import { getPool, q, q1, tx } from '../db/db';
import { CurrentCtx, Ctx } from '../common/context';
import { AppError, Errors } from '../common/errors';
import { parse, z } from '../common/validate';
import { notify } from '../common/notify';
import { audit } from '../common/audit';
import { hasConsent } from '../common/privacy';
import { Public } from '../common/auth.guard';
import { storage } from './files.controller';

/**
 * Liên lạc trong app (v9): gọi thoại WebRTC (không qua nhà mạng, không lộ số), nhắn tin trực tiếp, Zalo chuyển hướng không hiện số.
 * - Báo hiệu WebRTC qua HTTP polling (offer/answer/ICE) — không cần WebSocket, chạy được sau nginx.
 * - Giới hạn cuộc gọi 3 phút (cấu hình CALL_LIMIT_SECONDS), máy chủ tự kết thúc khi quá hạn.
 * - Ghi âm (cần đồng ý mục đích "call_recording") lưu kèm nhật ký; khai báo công việc từ cuộc gọi sẽ sao bản ghi âm sang bản khai.
 * - Nhật ký cuộc gọi, tin nhắn, ghi âm tự xóa sau 30 ngày (COMMS_RETENTION_DAYS).
 */
export const CALL_LIMIT = () => Number(process.env.CALL_LIMIT_SECONDS || 180);
export const COMMS_DAYS = () => Number(process.env.COMMS_RETENTION_DAYS || 30);
const RING_SECONDS = 45;

export const DEFAULT_PREFS = {
  ringtone: true, ringVolume: 80, vibrate: true, messageSound: true, notificationSound: true,
  quietHours: { enabled: false, start: '22:00', end: '06:00' },
  mute: { tasks: false, reports: false, support: false, messages: false, calls: false, department: false },
};

// Liên kết Zalo dùng một lần: app không bao giờ nhận số điện thoại
const zaloLinks = new Map<string, { phone: string; exp: number }>();

const PARTY = `SELECT c.*, cu.name AS caller_name, eu.name AS callee_name, ccm.user_id AS caller_user_id, ecm.user_id AS callee_user_id
  FROM call_logs c JOIN company_members ccm ON ccm.id=c.caller_id JOIN users cu ON cu.id=ccm.user_id
  JOIN company_members ecm ON ecm.id=c.callee_id JOIN users eu ON eu.id=ecm.user_id`;

async function loadCall(ctx: Ctx, id: string) {
  const c = await q1(`${PARTY} WHERE c.id=$1 AND c.company_id=$2`, [id, ctx.companyId]);
  if (!c || (c.caller_id !== ctx.memberId && c.callee_id !== ctx.memberId)) throw Errors.notFound('Cuộc gọi');
  return c;
}
const other = (c: any, me: string) => (c.caller_id === me ? c.callee_id : c.caller_id);

/** Đóng cuộc gọi (idempotent); tính thời lượng tối đa bằng giới hạn. */
async function finish(callId: string, by: string | null, reason: string) {
  return tx(async (c) => {
    const k = await q1(`SELECT * FROM call_logs WHERE id=$1 FOR UPDATE`, [callId], c);
    if (!k || ['ended', 'missed', 'declined', 'cancelled', 'failed'].includes(k.status)) return k;
    const status = k.status === 'active' ? 'ended' : reason === 'declined' ? 'declined' : reason === 'timeout' ? 'missed' : 'cancelled';
    const dur = k.answered_at ? Math.min(k.limit_seconds, Math.max(0, Math.round((Date.now() - new Date(k.answered_at).getTime()) / 1000))) : 0;
    const r = await q1(`UPDATE call_logs SET status=$2, ended_at=now(), duration_seconds=$3, end_reason=$4, ended_by=$5 WHERE id=$1 RETURNING *`, [callId, status, dur, reason, by], c);
    for (const to of [k.caller_id, k.callee_id].filter((x) => x !== by)) {
      await q(`INSERT INTO call_signals(call_id, from_member_id, to_member_id, type, payload) VALUES ($1,$2,$3,'hangup',$4)`, [callId, by || to, to, JSON.stringify({ reason })], c);
    }
    if (status === 'missed') await notify(c, { companyId: k.company_id, memberIds: [k.callee_id], type: 'call.missed', title: 'Cuộc gọi nhỡ trong app', refType: 'call', refId: callId });
    return r;
  });
}

@Controller()
export class CommsController {
  /** Danh bạ nội bộ: chỉ tên, chức danh, nhóm — không có số điện thoại. */
  @Get('contacts')
  async contacts(@CurrentCtx() ctx: Ctx, @Query('q') search?: string) {
    return q(`SELECT cm.id, cm.user_id, u.name, cm.title, cm.role, EXISTS (SELECT 1 FROM user_avatars a WHERE a.user_id=u.id) AS has_avatar,
                     (SELECT string_agg(g.name, ', ') FROM groups g LEFT JOIN group_members gm ON gm.group_id=g.id AND gm.company_member_id=cm.id
                       WHERE g.deleted_at IS NULL AND (gm.id IS NOT NULL OR g.manager_member_id=cm.id OR g.leader_member_id=cm.id)) AS groups,
                     (u.phone IS NOT NULL) AS has_zalo
                FROM company_members cm JOIN users u ON u.id=cm.user_id
               WHERE cm.company_id=$1 AND cm.status='active' AND cm.id<>$2 AND ($3::text IS NULL OR u.name ILIKE '%'||$3||'%')
               ORDER BY u.name LIMIT 300`, [ctx.companyId, ctx.memberId, search || null]);
  }

  /** Zalo: trả về liên kết một lần (hết hạn 60 giây) — máy chủ chuyển hướng, app không thấy số. */
  @Post('contacts/:id/zalo')
  async zalo(@Param('id') id: string, @CurrentCtx() ctx: Ctx) {
    const m = await q1(`SELECT u.phone FROM company_members cm JOIN users u ON u.id=cm.user_id WHERE cm.id=$1 AND cm.company_id=$2 AND cm.status='active'`, [id, ctx.companyId]);
    if (!m?.phone) throw Errors.notFound('Liên hệ Zalo');
    const token = randomBytes(18).toString('base64url');
    zaloLinks.set(token, { phone: m.phone.replace(/^\+84/, '0'), exp: Date.now() + 60000 });
    await audit(getPool(), ctx, 'member', id, 'contact.zalo_link', null, null);
    return { url: `/api/v1/contacts/go/${token}` };
  }
  @Public()
  @Get('contacts/go/:token')
  go(@Param('token') token: string, @Res() res: any) {
    const l = zaloLinks.get(token);
    zaloLinks.delete(token);
    if (!l || l.exp < Date.now()) return res.status(410).send('Liên kết đã hết hạn. Mở lại từ ứng dụng Việc Đến.');
    return res.redirect(302, `https://zalo.me/${l.phone}`);
  }

  // ---------- Cài đặt âm thanh & thông báo ----------
  @Get('me/prefs')
  async prefs(@CurrentCtx() ctx: Ctx) {
    const u = await q1(`SELECT prefs FROM users WHERE id=$1`, [ctx.userId]);
    return { ...DEFAULT_PREFS, ...(u?.prefs || {}), mute: { ...DEFAULT_PREFS.mute, ...(u?.prefs?.mute || {}) }, quietHours: { ...DEFAULT_PREFS.quietHours, ...(u?.prefs?.quietHours || {}) },
      call_limit_seconds: CALL_LIMIT(), retention_days: COMMS_DAYS() };
  }
  @Put('me/prefs')
  async setPrefs(@Body() body: any, @CurrentCtx() ctx: Ctx) {
    const hhmm = z.string().regex(/^\d{2}:\d{2}$/);
    const b = parse(z.object({
      ringtone: z.boolean().optional(), ringVolume: z.number().int().min(0).max(100).optional(), vibrate: z.boolean().optional(),
      messageSound: z.boolean().optional(), notificationSound: z.boolean().optional(),
      quietHours: z.object({ enabled: z.boolean(), start: hhmm, end: hhmm }).optional(),
      mute: z.partialRecord(z.enum(['tasks', 'reports', 'support', 'messages', 'calls', 'department']), z.boolean()).optional(),
    }), body);
    const cur = await this.prefs(ctx);
    const next = { ringtone: cur.ringtone, ringVolume: cur.ringVolume, vibrate: cur.vibrate, messageSound: cur.messageSound, notificationSound: cur.notificationSound,
      quietHours: cur.quietHours, mute: { ...cur.mute, ...(b.mute || {}) }, ...b, ...(b.mute ? { mute: { ...cur.mute, ...b.mute } } : {}) };
    await q(`UPDATE users SET prefs=$2 WHERE id=$1`, [ctx.userId, JSON.stringify(next)]);
    return this.prefs(ctx);
  }

  // ---------- Gọi thoại ----------
  @Post('calls')
  async start(@Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({ calleeId: z.string().uuid() }), body);
    if (b.calleeId === ctx.memberId) throw Errors.validation('Không thể tự gọi cho mình');
    const callee = await q1(`SELECT cm.id, u.name FROM company_members cm JOIN users u ON u.id=cm.user_id WHERE cm.id=$1 AND cm.company_id=$2 AND cm.status='active'`, [b.calleeId, ctx.companyId]);
    if (!callee) throw Errors.notFound('Người nhận');
    const busy = await q1(`SELECT id FROM call_logs WHERE status IN ('ringing','active') AND (caller_id=$1 OR callee_id=$1) AND created_at > now() - interval '10 minutes'`, [b.calleeId]);
    if (busy) throw new AppError('CALLEE_BUSY', `${callee.name} đang trong cuộc gọi khác`, 409);
    // Người dùng đóng app giữa chừng: dọn cuộc gọi treo của chính mình
    for (const s of await q(`SELECT id FROM call_logs WHERE status IN ('ringing','active') AND (caller_id=$1 OR callee_id=$1)`, [ctx.memberId])) await finish(s.id, ctx.memberId, 'replaced');
    const c = await q1(`INSERT INTO call_logs(company_id, caller_id, callee_id, limit_seconds) VALUES ($1,$2,$3,$4) RETURNING id`, [ctx.companyId, ctx.memberId, b.calleeId, CALL_LIMIT()]);
    await notify(getPool(), { companyId: ctx.companyId, memberIds: [b.calleeId], type: 'call.incoming', title: `${ctx.name} đang gọi cho bạn qua Việc Đến`, refType: 'call', refId: c.id });
    return this.get(c.id, ctx);
  }

  @Get('calls/:id')
  async get(@Param('id') id: string, @CurrentCtx() ctx: Ctx) {
    const c = await loadCall(ctx, id);
    const remaining = c.answered_at && c.status === 'active' ? Math.max(0, c.limit_seconds - Math.round((Date.now() - new Date(c.answered_at).getTime()) / 1000)) : c.limit_seconds;
    const rec = c.recording_file_id ? await q1(`SELECT id, filename, mime, size FROM files WHERE id=$1`, [c.recording_file_id]) : null;
    return { ...c, direction: c.caller_id === ctx.memberId ? 'out' : 'in', other_name: c.caller_id === ctx.memberId ? c.callee_name : c.caller_name,
      other_id: other(c, ctx.memberId), other_user_id: c.caller_id === ctx.memberId ? c.callee_user_id : c.caller_user_id, remaining_seconds: remaining, recording: rec,
      ice_servers: iceServers() };
  }

  /** Thăm dò: cuộc gọi đến đang đổ chuông, tín hiệu WebRTC mới, tin nhắn chưa đọc. Đồng thời tự kết thúc cuộc gọi quá hạn. */
  @Get('calls-poll')
  async poll(@CurrentCtx() ctx: Ctx, @Query('since') since?: string) {
    const mine = await q(`SELECT id, status, created_at, answered_at, limit_seconds FROM call_logs WHERE status IN ('ringing','active') AND (caller_id=$1 OR callee_id=$1)`, [ctx.memberId]);
    for (const k of mine) {
      if (k.status === 'ringing' && Date.now() - new Date(k.created_at).getTime() > RING_SECONDS * 1000) await finish(k.id, null, 'timeout');
      if (k.status === 'active' && Date.now() - new Date(k.answered_at).getTime() > k.limit_seconds * 1000) await finish(k.id, null, 'limit');
    }
    const incoming = await q(`${PARTY} WHERE c.callee_id=$1 AND c.status='ringing' AND c.created_at > now() - interval '${RING_SECONDS} seconds' ORDER BY c.created_at DESC LIMIT 1`, [ctx.memberId]);
    const signals = await q(`SELECT id::text, call_id, type, payload, from_member_id FROM call_signals WHERE to_member_id=$1 AND id > $2::bigint ORDER BY id LIMIT 200`, [ctx.memberId, since || '0']);
    const unread = await q1(`SELECT count(*)::int AS n FROM direct_messages WHERE recipient_id=$1 AND read_at IS NULL`, [ctx.memberId]);
    const last = signals.length ? signals[signals.length - 1].id : since || (await q1(`SELECT COALESCE(max(id),0)::text AS id FROM call_signals WHERE to_member_id=$1`, [ctx.memberId])).id;
    return { incoming: incoming[0] ? { id: incoming[0].id, caller_name: incoming[0].caller_name, caller_user_id: incoming[0].caller_user_id, caller_id: incoming[0].caller_id } : null,
      signals, since: last, unread_messages: unread.n };
  }

  @Post('calls/:id/signal')
  async signal(@Param('id') id: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({ type: z.enum(['offer', 'answer', 'ice', 'recording']), payload: z.any() }), body);
    const c = await loadCall(ctx, id);
    if (!['ringing', 'active'].includes(c.status)) throw Errors.invalidState('Cuộc gọi đã kết thúc');
    const size = JSON.stringify(b.payload ?? null).length;
    if (size > 20000) throw Errors.validation('Tín hiệu quá lớn');
    await q(`INSERT INTO call_signals(call_id, from_member_id, to_member_id, type, payload) VALUES ($1,$2,$3,$4,$5)`, [id, ctx.memberId, other(c, ctx.memberId), b.type, JSON.stringify(b.payload ?? null)]);
    return { ok: true };
  }

  @Post('calls/:id/answer')
  async answer(@Param('id') id: string, @CurrentCtx() ctx: Ctx) {
    const c = await loadCall(ctx, id);
    if (c.callee_id !== ctx.memberId) throw Errors.forbidden('Chỉ người được gọi mới nhận cuộc gọi');
    const r = await q1(`UPDATE call_logs SET status='active', answered_at=now() WHERE id=$1 AND status='ringing' RETURNING id`, [id]);
    if (!r) throw Errors.invalidState('Cuộc gọi không còn đổ chuông');
    return this.get(id, ctx);
  }

  @Post('calls/:id/decline')
  async decline(@Param('id') id: string, @CurrentCtx() ctx: Ctx) {
    await loadCall(ctx, id);
    await finish(id, ctx.memberId, 'declined');
    return this.get(id, ctx);
  }

  @Post('calls/:id/end')
  async end(@Param('id') id: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({ reason: z.enum(['hangup', 'limit', 'error', 'cancelled']).default('hangup') }), body || {});
    await loadCall(ctx, id);
    await finish(id, ctx.memberId, b.reason);
    return this.get(id, ctx);
  }

  /** Tải ghi âm cuộc gọi (người ghi phải đồng ý mục đích ghi âm; bên kia được báo trong lúc gọi). */
  @Post('calls/:id/recording')
  @UseInterceptors(FileInterceptor('file', { limits: { fileSize: 15 * 1024 * 1024 } }))
  async recording(@Param('id') id: string, @UploadedFile() file: Express.Multer.File, @CurrentCtx() ctx: Ctx) {
    if (!file) throw Errors.validation('Thiếu tệp ghi âm');
    if (!/^audio\//.test(file.mimetype) && file.mimetype !== 'video/webm') throw new AppError('FILE_TYPE_NOT_ALLOWED', 'Chỉ nhận tệp âm thanh', 415);
    const c = await loadCall(ctx, id);
    if (!(await hasConsent(ctx.userId, 'call_recording'))) throw new AppError('CONSENT_REQUIRED', 'Cần đồng ý mục đích "Ghi âm cuộc gọi khai việc" (Cá nhân → Quyền riêng tư) trước khi lưu ghi âm.', 428, { purpose: 'call_recording' });
    if (c.recording_file_id) throw Errors.invalidState('Cuộc gọi đã có ghi âm');
    const key = `${ctx.companyId}/call/${randomUUID()}${extname(file.originalname || '.webm').slice(0, 10) || '.webm'}`;
    storage.put(key, file.buffer);
    const f = await q1(`INSERT INTO files(company_id, parent_type, parent_id, filename, mime, size, storage_key, uploaded_by) VALUES ($1,'call',$2,$3,$4,$5,$6,$7) RETURNING id`,
      [ctx.companyId, id, `ghi-am-cuoc-goi-${new Date().toISOString().slice(0, 16).replace(/[:T]/g, '')}.webm`, file.mimetype.replace('video/webm', 'audio/webm'), file.size, key, ctx.memberId]);
    await q(`UPDATE call_logs SET recording_file_id=$2 WHERE id=$1`, [id, f.id]);
    await q(`INSERT INTO call_signals(call_id, from_member_id, to_member_id, type, payload) VALUES ($1,$2,$3,'recording',$4)`, [id, ctx.memberId, other(c, ctx.memberId), JSON.stringify({ by: ctx.name })]);
    await audit(getPool(), ctx, 'call', id, 'call.recorded', null, { file: f.id });
    return this.get(id, ctx);
  }

  /** Nhật ký liên lạc: cuộc gọi trong app (30 ngày gần nhất). */
  @Get('calls')
  async log(@CurrentCtx() ctx: Ctx) {
    const rows = await q(`${PARTY} WHERE c.company_id=$1 AND (c.caller_id=$2 OR c.callee_id=$2) AND c.created_at > now() - ($3 || ' days')::interval ORDER BY c.created_at DESC LIMIT 300`,
      [ctx.companyId, ctx.memberId, String(COMMS_DAYS())]);
    return rows.map((c) => ({ id: c.id, status: c.status, direction: c.caller_id === ctx.memberId ? 'out' : 'in', other_id: other(c, ctx.memberId),
      other_name: c.caller_id === ctx.memberId ? c.callee_name : c.caller_name, other_user_id: c.caller_id === ctx.memberId ? c.callee_user_id : c.caller_user_id,
      created_at: c.created_at, answered_at: c.answered_at, duration_seconds: c.duration_seconds, end_reason: c.end_reason, has_recording: !!c.recording_file_id,
      recording_file_id: c.recording_file_id, work_record_id: c.work_record_id,
      expires_at: new Date(new Date(c.created_at).getTime() + COMMS_DAYS() * 86400000).toISOString() }));
  }

  // ---------- Nhắn tin ----------
  @Get('messages/threads')
  async threads(@CurrentCtx() ctx: Ctx) {
    return q(`WITH m AS (SELECT *, CASE WHEN sender_id=$2 THEN recipient_id ELSE sender_id END AS other_id FROM direct_messages
                          WHERE company_id=$1 AND (sender_id=$2 OR recipient_id=$2))
              SELECT DISTINCT ON (m.other_id) m.other_id, u.name AS other_name, cm.user_id AS other_user_id, m.body AS last_body, m.created_at AS last_at, m.sender_id=$2 AS last_mine,
                     (SELECT count(*)::int FROM direct_messages x WHERE x.sender_id=m.other_id AND x.recipient_id=$2 AND x.read_at IS NULL) AS unread
                FROM m JOIN company_members cm ON cm.id=m.other_id JOIN users u ON u.id=cm.user_id
               ORDER BY m.other_id, m.created_at DESC`, [ctx.companyId, ctx.memberId])
      .then((r) => r.sort((a: any, b: any) => +new Date(b.last_at) - +new Date(a.last_at)));
  }
  @Get('messages/with/:memberId')
  async thread(@Param('memberId') memberId: string, @CurrentCtx() ctx: Ctx) {
    const o = await q1(`SELECT cm.id, cm.user_id, u.name, cm.title FROM company_members cm JOIN users u ON u.id=cm.user_id WHERE cm.id=$1 AND cm.company_id=$2`, [memberId, ctx.companyId]);
    if (!o) throw Errors.notFound('Người nhận');
    await q(`UPDATE direct_messages SET read_at=now() WHERE sender_id=$1 AND recipient_id=$2 AND read_at IS NULL`, [memberId, ctx.memberId]);
    const items = await q(`SELECT id, sender_id, body, created_at, read_at FROM direct_messages WHERE company_id=$1 AND ((sender_id=$2 AND recipient_id=$3) OR (sender_id=$3 AND recipient_id=$2))
                            ORDER BY created_at DESC LIMIT 200`, [ctx.companyId, ctx.memberId, memberId]);
    return { other: o, items: items.reverse(), retention_days: COMMS_DAYS() };
  }
  @Post('messages')
  async send(@Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({ to: z.string().uuid(), body: z.string().trim().min(1).max(2000) }), body);
    if (b.to === ctx.memberId) throw Errors.validation('Không thể nhắn cho chính mình');
    const o = await q1(`SELECT id FROM company_members WHERE id=$1 AND company_id=$2 AND status='active'`, [b.to, ctx.companyId]);
    if (!o) throw Errors.notFound('Người nhận');
    const m = await q1(`INSERT INTO direct_messages(company_id, sender_id, recipient_id, body) VALUES ($1,$2,$3,$4) RETURNING id, sender_id, body, created_at`, [ctx.companyId, ctx.memberId, b.to, b.body]);
    await notify(getPool(), { companyId: ctx.companyId, memberIds: [b.to], type: 'message.new', title: `Tin nhắn từ ${ctx.name}`, refType: 'member', refId: ctx.memberId,
      dedupeKey: `dm:${ctx.memberId}:${new Date().toISOString().slice(0, 13)}` });
    return m;
  }
}

export function iceServers() {
  const list: any[] = [{ urls: (process.env.STUN_URLS || 'stun:stun.l.google.com:19302').split(',') }];
  if (process.env.TURN_URL) list.push({ urls: process.env.TURN_URL.split(','), username: process.env.TURN_USER, credential: process.env.TURN_PASS });
  return list;
}

/** Dọn dữ liệu liên lạc: tín hiệu > 1 giờ; cuộc gọi, tin nhắn, ghi âm > 30 ngày. Tệp ghi âm đã sao sang bản khai công việc được giữ lại. */
export async function runCommsRetention(now = new Date()) {
  await q(`DELETE FROM call_signals WHERE created_at < $1::timestamptz - interval '1 hour'`, [now]);
  for (const k of await q(`SELECT id FROM call_logs WHERE status IN ('ringing','active') AND created_at < $1::timestamptz - interval '15 minutes'`, [now])) await finish(k.id, null, 'timeout');
  const days = String(COMMS_DAYS());
  const old = await q(`SELECT id FROM call_logs WHERE created_at < $1::timestamptz - ($2 || ' days')::interval`, [now, days]);
  let files = 0;
  if (old.length) {
    const ids = old.map((r) => r.id);
    for (const f of await q(`SELECT id, storage_key FROM files WHERE parent_type='call' AND parent_id = ANY($1::uuid[])`, [ids])) {
      const shared = await q1(`SELECT 1 FROM files WHERE storage_key=$1 AND id<>$2 LIMIT 1`, [f.storage_key, f.id]);
      if (!shared) { try { if (existsSync(storage.path(f.storage_key))) unlinkSync(storage.path(f.storage_key)); } catch { /* bỏ qua */ } }
      await q(`DELETE FROM files WHERE id=$1`, [f.id]); files++;
    }
    await q(`DELETE FROM call_logs WHERE id = ANY($1::uuid[])`, [ids]);
  }
  const msgs = await q(`DELETE FROM direct_messages WHERE created_at < $1::timestamptz - ($2 || ' days')::interval RETURNING id`, [now, days]);
  return { calls: old.length, recordings: files, messages: msgs.length };
}
