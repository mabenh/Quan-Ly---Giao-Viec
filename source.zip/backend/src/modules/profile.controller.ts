import { Body, Controller, Delete, Get, Param, Patch, Post, Put, Query, Res } from '@nestjs/common';
import { Response } from 'express';
import { q, q1 } from '../db/db';
import { AllowNoCompany } from '../common/auth.guard';
import { CurrentCtx, Ctx, isHR } from '../common/context';
import { accessLog, canSeeField, hasConsent, hit, securityAlert } from '../common/privacy';
import { AppError, Errors } from '../common/errors';
import { parse, z } from '../common/validate';

const PROFILE = z.object({
  name: z.string().trim().min(4, 'Nhập họ và tên đầy đủ').optional(),
  email: z.string().email().optional().or(z.literal('')),
  dob: z.string().regex(/^\d{4}-\d\d-\d\d$/).optional().nullable().or(z.literal('')),
  address: z.string().max(300).optional().nullable(),
  contact_email: z.string().max(200).optional().nullable(),
  education: z.string().optional().nullable(), desired_position: z.string().optional().nullable(),
  summary: z.string().optional().nullable(), years_experience: z.coerce.number().min(0).max(80).optional().nullable(),
  field: z.string().optional().nullable(), skills: z.string().optional().nullable(), certificates: z.string().optional().nullable(),
  share_auto_history: z.boolean().optional(),
});
const HISTORY = z.object({
  company_name: z.string().trim().min(2), position: z.string().optional().nullable(),
  start_date: z.string().regex(/^\d{4}-\d\d(-\d\d)?$/).optional().nullable().or(z.literal('')),
  end_date: z.string().regex(/^\d{4}-\d\d(-\d\d)?$/).optional().nullable().or(z.literal('')),
  description: z.string().optional().nullable(),
});
const d = (s?: string | null) => (!s ? null : s.length === 7 ? s + '-01' : s);

/**
 * Phần hồ sơ do app tự cập nhật: quá trình làm việc trong Việc Đến ở từng doanh nghiệp
 * (vai trò, thời gian, số việc hoàn thành, đúng hạn, điểm nghiệm thu, điểm hiệu suất đã chốt...).
 */
export async function autoHistory(userId: string, onlyCompanyIds?: string[] | null) {
  const ms = await q(
    `SELECT cm.id, cm.company_id, c.name AS company_name, cm.role, cm.title, cm.status, cm.joined_at, cm.left_at, d.name AS department
       FROM company_members cm JOIN companies c ON c.id=cm.company_id LEFT JOIN departments d ON d.id=cm.department_id
      WHERE cm.user_id=$1 AND cm.status IN ('active','inactive') ORDER BY cm.joined_at DESC`, [userId]);
  const out: any[] = [];
  for (const m of ms) {
    if (onlyCompanyIds && !onlyCompanyIds.includes(m.company_id)) continue;
    const t = await q1(
      `SELECT count(*) FILTER (WHERE t.status='completed')::int AS completed,
              count(*) FILTER (WHERE t.status='completed' AND t.first_submitted_at <= t.due_at)::int AS on_time,
              count(*) FILTER (WHERE t.status='completed' AND t.is_unexpected)::int AS unexpected,
              count(*) FILTER (WHERE t.status='completed' AND t.complexity IN ('complex','very_complex'))::int AS complex,
              round(avg(ev.total_score)::numeric, 1) AS avg_score
         FROM tasks t JOIN task_assignees ta ON ta.task_id=t.id AND ta.active AND ta.assignment_type='owner' AND ta.company_member_id=$1
         LEFT JOIN LATERAL (SELECT total_score FROM task_evaluations e WHERE e.task_id=t.id AND e.decision='approved' ORDER BY created_at DESC LIMIT 1) ev ON true`, [m.id]);
    const groups = await q(`SELECT g.name FROM group_members gm JOIN groups g ON g.id=gm.group_id WHERE gm.company_member_id=$1`, [m.id]);
    const ot = await q1(`SELECT COALESCE(sum(minutes),0)::int AS m FROM overtime_records WHERE member_id=$1 AND approval_status='confirmed'`, [m.id]);
    const wr = await q1(`SELECT count(*)::int AS n, COALESCE(sum(accepted_minutes),0)::int AS m FROM employee_work_records WHERE employee_id=$1 AND final_decision IN ('accepted','partially_accepted')`, [m.id]);
    const lv = await q1(`SELECT COALESCE(sum(minutes),0)::int AS m, count(*) FILTER (WHERE leave_type='sudden')::int AS sudden FROM leave_requests WHERE member_id=$1 AND status='approved'`, [m.id]);
    const scores = await q(
      `SELECT p.period_type, p.snapshot->'meta'->'period'->>'label' AS label, (e->>'E')::numeric AS e, p.created_at
         FROM performance_reports p, jsonb_array_elements(p.snapshot->'members') e
        WHERE p.company_id=$1 AND e->>'member_id'=$2::text ORDER BY p.created_at DESC LIMIT 12`, [m.company_id, m.id]);
    out.push({
      company_name: m.company_name, role: m.role, title: m.title, department: m.department, status: m.status,
      joined_at: m.joined_at, left_at: m.left_at, groups: groups.map((g) => g.name),
      tasks_completed: t.completed, on_time_rate: t.completed ? Math.round((100 * t.on_time) / t.completed) : null,
      unexpected_completed: t.unexpected, complex_completed: t.complex, avg_task_score: t.avg_score,
      confirmed_overtime_hours: Math.round(ot.m / 6) / 10, accepted_self_reports: wr.n, accepted_self_report_hours: Math.round(wr.m / 6) / 10,
      approved_leave_hours: Math.round(lv.m / 6) / 10, sudden_leaves: lv.sudden,
      finalized_scores: scores.filter((s) => s.e !== null).map((s) => ({ period: s.label, E: Number(s.e) })),
    });
  }
  return out;
}

async function loadProfile(userId: string) {
  const u = await q1(`SELECT id, name, phone, email, created_at, EXISTS (SELECT 1 FROM user_avatars a WHERE a.user_id=users.id) AS has_avatar FROM users WHERE id=$1`, [userId]);
  if (!u) throw Errors.notFound('Người dùng');
  const p = (await q1(`SELECT * FROM user_profiles WHERE user_id=$1`, [userId])) || { share_auto_history: false };
  const history = await q(`SELECT * FROM user_work_history WHERE user_id=$1 ORDER BY start_date DESC NULLS LAST, created_at DESC`, [userId]);
  const av = await q1(`SELECT captured_live, face_detected, updated_at FROM user_avatars WHERE user_id=$1`, [userId]);
  return { user: u, profile: p, work_history: history, avatar: av };
}

@Controller()
export class ProfileController {
  @AllowNoCompany()
  @Get('profile/me')
  async me(@CurrentCtx() ctx: Ctx) {
    return { ...(await loadProfile(ctx.userId)), auto_history: await autoHistory(ctx.userId) };
  }

  @AllowNoCompany()
  @Put('profile/me')
  async update(@Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(PROFILE, body);
    if (b.name) await q(`UPDATE users SET name=$2 WHERE id=$1`, [ctx.userId, b.name]);
    if (b.email !== undefined) {
      if (b.email && await q1(`SELECT 1 FROM users WHERE lower(email)=lower($1) AND id<>$2`, [b.email, ctx.userId])) throw new AppError('EMAIL_TAKEN', 'Email đã được sử dụng', 409);
      await q(`UPDATE users SET email=NULLIF(lower($2),'') WHERE id=$1`, [ctx.userId, b.email]);
    }
    const f = ['dob', 'address', 'contact_email', 'education', 'desired_position', 'summary', 'years_experience', 'field', 'skills', 'certificates', 'share_auto_history'] as const;
    const cur = (await q1(`SELECT * FROM user_profiles WHERE user_id=$1`, [ctx.userId])) || {};
    const vals = f.map((k) => (b[k] !== undefined ? (b[k] === '' ? null : b[k]) : cur[k] ?? (k === 'share_auto_history' ? false : null)));
    await q(
      `INSERT INTO user_profiles(user_id, ${f.join(',')}, updated_at) VALUES ($1, ${f.map((_, i) => `$${i + 2}`).join(',')}, now())
       ON CONFLICT (user_id) DO UPDATE SET ${f.map((k, i) => `${k}=$${i + 2}`).join(', ')}, updated_at=now()`, [ctx.userId, ...vals]);
    return this.me(ctx);
  }

  @AllowNoCompany()
  @Post('profile/me/history')
  async addHistory(@Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(HISTORY, body);
    await q(`INSERT INTO user_work_history(user_id, company_name, position, start_date, end_date, description) VALUES ($1,$2,$3,$4,$5,$6)`,
      [ctx.userId, b.company_name, b.position ?? null, d(b.start_date), d(b.end_date), b.description ?? null]);
    return this.me(ctx);
  }

  @AllowNoCompany()
  @Patch('profile/me/history/:id')
  async updHistory(@Param('id') id: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(HISTORY, body);
    const r = await q1(`UPDATE user_work_history SET company_name=$3, position=$4, start_date=$5, end_date=$6, description=$7 WHERE id=$1 AND user_id=$2 RETURNING id`,
      [id, ctx.userId, b.company_name, b.position ?? null, d(b.start_date), d(b.end_date), b.description ?? null]);
    if (!r) throw Errors.notFound('Mục lịch sử làm việc');
    return this.me(ctx);
  }

  @AllowNoCompany()
  @Delete('profile/me/history/:id')
  async delHistory(@Param('id') id: string, @CurrentCtx() ctx: Ctx) {
    await q(`DELETE FROM user_work_history WHERE id=$1 AND user_id=$2`, [id, ctx.userId]);
    return this.me(ctx);
  }

  /** Ảnh đại diện chụp trực tiếp từ camera trước (quét gương mặt), đã thu nhỏ ở client. */
  @AllowNoCompany()
  @Put('profile/me/avatar')
  async avatar(@Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({ dataUrl: z.string().max(600_000), capturedLive: z.boolean().default(false), faceDetected: z.boolean().nullable().optional() }), body);
    const m = /^data:(image\/(jpeg|png|webp));base64,(.+)$/.exec(b.dataUrl);
    if (!m) throw Errors.validation('Ảnh không hợp lệ');
    if (b.capturedLive && !(await hasConsent(ctx.userId, 'face_capture'))) {
      throw new AppError('CONSENT_REQUIRED', 'Cần bạn đồng ý cho mục đích "Chụp ảnh gương mặt làm ảnh đại diện" trước khi dùng camera. Bạn cũng có thể chọn ảnh có sẵn.', 428, { purpose: 'face_capture' });
    }
    const buf = Buffer.from(m[3], 'base64');
    if (buf.length > 400_000) throw new AppError('FILE_TOO_LARGE', 'Ảnh quá lớn', 413);
    await q(`INSERT INTO user_avatars(user_id, mime, data, captured_live, face_detected, updated_at) VALUES ($1,$2,$3,$4,$5,now())
             ON CONFLICT (user_id) DO UPDATE SET mime=$2, data=$3, captured_live=$4, face_detected=$5, updated_at=now()`,
      [ctx.userId, m[1], buf, b.capturedLive, b.faceDetected ?? null]);
    return { ok: true };
  }

  /** Xóa ảnh đại diện (không bắt buộc dùng ảnh thật). */
  @AllowNoCompany()
  @Delete('profile/me/avatar')
  async deleteAvatar(@CurrentCtx() ctx: Ctx) {
    await q(`DELETE FROM user_avatars WHERE user_id=$1`, [ctx.userId]);
    await accessLog({ companyId: ctx.companyId, actorUserId: ctx.userId, actorMemberId: ctx.memberId, action: 'avatar.deleted', objectType: 'avatar', objectId: ctx.userId, subjectUserId: ctx.userId });
    return { ok: true };
  }

  @AllowNoCompany()
  @Get('users/:userId/avatar')
  async getAvatar(@Param('userId') userId: string, @CurrentCtx() ctx: Ctx, @Res() res: Response) {
    if (userId !== ctx.userId) {
      const shared = await q1(`SELECT 1 FROM company_members a JOIN company_members b ON a.company_id=b.company_id
                                WHERE a.user_id=$1 AND b.user_id=$2 AND a.status='active' LIMIT 1`, [ctx.userId, userId]);
      if (!shared) throw Errors.notFound('Ảnh');
    }
    const a = await q1(`SELECT mime, data, updated_at FROM user_avatars WHERE user_id=$1`, [userId]);
    if (!a) throw Errors.notFound('Ảnh');
    res.setHeader('Content-Type', a.mime);
    res.setHeader('Cache-Control', 'private, max-age=300');
    res.end(a.data);
  }

  /**
   * Hồ sơ của một người (cho quản lý/nhân sự rà soát). Quyền: bản thân; Owner/Admin/HR/Quản lý của doanh nghiệp
   * mà người đó là thành viên (kể cả đang chờ duyệt). Lịch sử tự động ở doanh nghiệp khác chỉ hiện khi người đó đồng ý chia sẻ.
   */
  @Get('profiles/:userId')
  async view(@Param('userId') userId: string, @CurrentCtx() ctx: Ctx, @Query('purpose') purpose?: string) {
    const self = userId === ctx.userId;
    let target: any = null;
    if (!self) {
      target = await q1(`SELECT id, status, added_by, supervisor_member_id FROM company_members WHERE company_id=$1 AND user_id=$2 AND status IN ('active','pending_hr','inactive')`, [ctx.companyId, userId]);
      const deny = async (why: string) => {
        await accessLog({ companyId: ctx.companyId, actorUserId: ctx.userId, actorMemberId: ctx.memberId, action: 'profile.view', objectType: 'profile', objectId: userId, subjectUserId: target ? userId : null, result: 'denied', reason: why });
        throw Errors.notFound('Hồ sơ');
      };
      if (!target) await deny('not_in_company');
      const hr = isHR(ctx);
      const restricted = (await q1(`SELECT restricted FROM user_profiles WHERE user_id=$1`, [userId]))?.restricted;
      if (restricted && !hr) await deny('restricted');
      if (!hr) {
        // Quản lý chỉ xem hồ sơ người trong phạm vi quản lý: cùng nhóm mình quản lý, cấp dưới (trực tiếp/gián tiếp), hoặc người mình đề nghị thêm
        if (ctx.role !== 'manager' && ctx.role !== 'reviewer') await deny('role');
        const inScope = target.added_by === ctx.memberId || !!(await q1(
          `WITH RECURSIVE sub AS (SELECT id FROM company_members WHERE supervisor_member_id=$1 UNION SELECT cm.id FROM company_members cm JOIN sub ON cm.supervisor_member_id=sub.id)
           SELECT 1 WHERE $2 IN (SELECT id FROM sub)
              OR EXISTS (SELECT 1 FROM groups g JOIN group_members gm ON gm.group_id=g.id WHERE g.manager_member_id=$1 AND gm.company_member_id=$2 AND g.deleted_at IS NULL)`,
          [ctx.memberId, target.id]));
        if (!inScope) await deny('out_of_scope');
      }
      // Cảnh báo khi một tài khoản xem nhiều hồ sơ trong thời gian ngắn (tín hiệu, không kết luận)
      if (hit('pv:' + ctx.userId, 3600000) === 30) await securityAlert({ companyId: ctx.companyId, userId: ctx.userId, memberId: ctx.memberId, kind: 'profile_views', detail: 'Xem 30 hồ sơ cá nhân trong 1 giờ' });
      await accessLog({ companyId: ctx.companyId, actorUserId: ctx.userId, actorMemberId: ctx.memberId, action: 'profile.view', objectType: 'profile', objectId: userId, subjectUserId: userId, reason: purpose?.slice(0, 200) || null });
    }
    const p = await loadProfile(userId);
    const share = !!p.profile.share_auto_history || self;
    const hist = await autoHistory(userId, share ? null : [ctx.companyId]);
    if (self) return { ...p, auto_history: hist, other_companies_hidden: false };
    // Trả trường theo mức hiển thị chủ thể đã chọn (Nhân sự vẫn thấy SĐT để quản trị tài khoản)
    const viewer = { userId: ctx.userId, memberId: ctx.memberId };
    const profile: any = { ...p.profile };
    const user: any = { ...p.user };
    for (const k of ['dob', 'address', 'contact_email']) if (!(await canSeeField(userId, target.id, viewer, k))) profile[k] = null;
    if (!(await canSeeField(userId, target.id, viewer, 'email'))) user.email = null;
    // v9: số điện thoại không hiển thị cho đồng nghiệp — liên lạc qua cuộc gọi/tin nhắn trong app (nhân sự vẫn xem được trong hồ sơ quản trị)
    if (!isHR(ctx) && userId !== ctx.userId) user.phone = null;
    const showHistory = isHR(ctx) || (await canSeeField(userId, target.id, viewer, 'work_history'));
    delete profile.restricted;
    return { ...p, user, profile, work_history: showHistory ? p.work_history : [], work_history_hidden: !showHistory, auto_history: hist, other_companies_hidden: !share,
      privacy_note: 'Một số trường được ẩn theo lựa chọn của người dùng. Lần xem hồ sơ này được ghi nhận trong lịch sử truy cập của họ.' };
  }
}
