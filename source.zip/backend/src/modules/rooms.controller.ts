import { Body, Controller, Delete, Get, Param, Patch, Post, Query } from '@nestjs/common';
import { getPool, q, q1, tx } from '../db/db';
import { CurrentCtx, Ctx, isAdmin } from '../common/context';
import { AppError, Errors } from '../common/errors';
import { parse, z } from '../common/validate';
import { notify } from '../common/notify';
import { audit } from '../common/audit';
import { authority } from '../common/authority';
import { iceServers, COMMS_DAYS } from './comms.controller';

/**
 * Nhóm liên lạc (v13): nhắn tin nhóm + gọi nhóm (WebRTC mesh, tối đa 8 người, không qua nhà mạng).
 * - Trưởng nhóm (tầng 6) lập nhóm với thành viên các nhóm mình phụ trách; trưởng phòng (tầng 5) với thành viên phòng ban; tầng 3–4: toàn công ty.
 * - Quyền hạn nhóm: ai được nhắn tin, ai được bắt đầu cuộc gọi, ai được thêm thành viên, thời lượng tối đa mỗi cuộc gọi.
 * - Tin nhắn nhóm tự xóa sau 30 ngày như tin nhắn riêng.
 */
export const DEFAULT_ROOM_SETTINGS = { who_can_post: 'all', who_can_call: 'all', who_can_add: 'admins', call_limit_minutes: 10 };
const MAX_CALL = 8;
type Settings = typeof DEFAULT_ROOM_SETTINGS;

/** Thành viên trong phạm vi phụ trách của người lập nhóm (null = toàn công ty). */
export async function scopeMembers(ctx: Ctx): Promise<string[] | null> {
  const au = await authority(ctx);
  if (isAdmin(ctx) || au.tier <= 4) return null;
  if (au.tier === 5 && au.departmentId) {
    return (await q(`SELECT id FROM company_members WHERE company_id=$1 AND status='active' AND department_id=$2
                     UNION SELECT gm.company_member_id FROM group_members gm JOIN groups g ON g.id=gm.group_id WHERE g.department_id=$2 AND g.deleted_at IS NULL`, [ctx.companyId, au.departmentId])).map((r) => r.id);
  }
  return (await q(`SELECT gm.company_member_id AS id FROM group_members gm JOIN groups g ON g.id=gm.group_id
                    WHERE g.company_id=$1 AND g.deleted_at IS NULL AND (g.leader_member_id=$2 OR g.manager_member_id=$2)`, [ctx.companyId, ctx.memberId])).map((r) => r.id);
}
async function canCreateRoom(ctx: Ctx) { const au = await authority(ctx); return isAdmin(ctx) || au.tier <= 6; }

async function loadRoom(ctx: Ctx, id: string) {
  const r = await q1(`SELECT r.*, m.role AS my_role FROM chat_rooms r LEFT JOIN chat_room_members m ON m.room_id=r.id AND m.member_id=$3 WHERE r.id=$1 AND r.company_id=$2`, [id, ctx.companyId, ctx.memberId]);
  if (!r || !r.my_role) throw Errors.notFound('Nhóm liên lạc');
  const settings: Settings = { ...DEFAULT_ROOM_SETTINGS, ...(r.settings || {}) };
  const admin = ['owner', 'admin'].includes(r.my_role);
  return { ...r, settings, perms: {
    is_admin: admin, can_post: settings.who_can_post === 'all' || admin, can_call: settings.who_can_call === 'all' || admin,
    can_add: settings.who_can_add === 'all' || admin, can_manage: admin } };
}
async function people(roomId: string) {
  return (await q(`SELECT member_id FROM chat_room_members WHERE room_id=$1`, [roomId])).map((r) => r.member_id as string);
}

@Controller()
export class RoomsController {
  @Get('rooms')
  async list(@CurrentCtx() ctx: Ctx) {
    const rows = await q(`SELECT r.id, r.name, r.settings, m.role AS my_role,
                                 (SELECT count(*)::int FROM chat_room_members x WHERE x.room_id=r.id) AS member_count,
                                 (SELECT count(*)::int FROM room_messages rm WHERE rm.room_id=r.id AND rm.created_at > m.last_read_at AND rm.sender_id<>$2) AS unread,
                                 (SELECT json_build_object('body', rm.body, 'at', rm.created_at, 'name', u.name) FROM room_messages rm JOIN company_members cm ON cm.id=rm.sender_id JOIN users u ON u.id=cm.user_id
                                   WHERE rm.room_id=r.id ORDER BY rm.created_at DESC LIMIT 1) AS last,
                                 (SELECT json_build_object('id', c.id, 'started_at', c.started_at, 'count', (SELECT count(*)::int FROM room_call_participants p WHERE p.call_id=c.id AND p.left_at IS NULL))
                                    FROM room_calls c WHERE c.room_id=r.id AND c.status='active') AS active_call
                            FROM chat_rooms r JOIN chat_room_members m ON m.room_id=r.id AND m.member_id=$2
                           WHERE r.company_id=$1 AND NOT r.archived ORDER BY COALESCE((SELECT max(created_at) FROM room_messages rm WHERE rm.room_id=r.id), r.created_at) DESC`, [ctx.companyId, ctx.memberId]);
    return { rooms: rows, can_create: await canCreateRoom(ctx) };
  }

  /** Danh sách người có thể thêm vào nhóm (theo phạm vi phụ trách). */
  @Get('rooms-eligible')
  async eligible(@CurrentCtx() ctx: Ctx) {
    const scope = await scopeMembers(ctx);
    const rows = await q(`SELECT cm.id, u.name, cm.user_id, cm.title, d.name AS department FROM company_members cm JOIN users u ON u.id=cm.user_id LEFT JOIN departments d ON d.id=cm.department_id
                           WHERE cm.company_id=$1 AND cm.status='active' AND cm.id<>$2 AND ($3::uuid[] IS NULL OR cm.id = ANY($3::uuid[])) ORDER BY d.name NULLS LAST, u.name`,
      [ctx.companyId, ctx.memberId, scope]);
    return { members: rows, scope: scope ? 'limited' : 'company', can_create: await canCreateRoom(ctx) };
  }

  /** Lập nhóm: thành viên phải nằm trong phạm vi phụ trách của người lập. */
  @Post('rooms')
  async create(@Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({ name: z.string().trim().min(2, 'Đặt tên nhóm').max(80), memberIds: z.array(z.string().uuid()).max(200).default([]),
      settings: z.object({ who_can_post: z.enum(['all', 'admins']), who_can_call: z.enum(['all', 'admins']), who_can_add: z.enum(['all', 'admins']), call_limit_minutes: z.number().int().min(3).max(30) }).partial().optional() }), body);
    if (!(await canCreateRoom(ctx))) throw Errors.forbidden('Chỉ trưởng nhóm, trưởng phòng hoặc Ban điều hành được lập nhóm liên lạc');
    const scope = await scopeMembers(ctx);
    const ids = [...new Set(b.memberIds.filter((x) => x !== ctx.memberId))];
    for (const m of ids) {
      if (!(await q1(`SELECT 1 FROM company_members WHERE id=$1 AND company_id=$2 AND status='active'`, [m, ctx.companyId]))) throw Errors.notFound('Thành viên');
      if (scope && !scope.includes(m)) throw Errors.forbidden('Chỉ thêm thành viên trong phạm vi bạn phụ trách');
    }
    const r = await tx(async (c) => {
      const room = await q1(`INSERT INTO chat_rooms(company_id, name, created_by, settings) VALUES ($1,$2,$3,$4) RETURNING *`, [ctx.companyId, b.name, ctx.memberId, JSON.stringify({ ...DEFAULT_ROOM_SETTINGS, ...(b.settings || {}) })], c);
      await q(`INSERT INTO chat_room_members(room_id, member_id, role) VALUES ($1,$2,'owner')`, [room.id, ctx.memberId], c);
      for (const m of ids) await q(`INSERT INTO chat_room_members(room_id, member_id) VALUES ($1,$2)`, [room.id, m], c);
      await notify(c, { companyId: ctx.companyId, memberIds: ids, type: 'room.added', title: `${ctx.name} đã thêm bạn vào nhóm liên lạc "${b.name}"`, refType: 'room', refId: room.id });
      await audit(c, ctx, 'room', room.id, 'room.created', null, { name: b.name, members: ids.length });
      return room;
    });
    return this.detail(r.id, ctx);
  }

  @Get('rooms/:id')
  async detail(@Param('id') id: string, @CurrentCtx() ctx: Ctx) {
    const r = await loadRoom(ctx, id);
    const members = await q(`SELECT m.member_id, m.role, u.name, cm.user_id, cm.title FROM chat_room_members m JOIN company_members cm ON cm.id=m.member_id JOIN users u ON u.id=cm.user_id
                              WHERE m.room_id=$1 ORDER BY (m.role='owner') DESC, (m.role='admin') DESC, u.name`, [id]);
    const call = await q1(`SELECT c.*, (SELECT count(*)::int FROM room_call_participants p WHERE p.call_id=c.id AND p.left_at IS NULL) AS count FROM room_calls c WHERE c.room_id=$1 AND c.status='active'`, [id]);
    return { id: r.id, name: r.name, settings: r.settings, my_role: r.my_role, permissions: r.perms, members, active_call: call || null, retention_days: COMMS_DAYS() };
  }

  /** Thiết lập quyền hạn nhóm (chủ nhóm / quản trị nhóm). */
  @Patch('rooms/:id')
  async update(@Param('id') id: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({ name: z.string().trim().min(2).max(80).optional(), archived: z.boolean().optional(),
      settings: z.object({ who_can_post: z.enum(['all', 'admins']), who_can_call: z.enum(['all', 'admins']), who_can_add: z.enum(['all', 'admins']), call_limit_minutes: z.number().int().min(3).max(30) }).partial().optional() }), body);
    const r = await loadRoom(ctx, id);
    if (!r.perms.can_manage) throw Errors.forbidden('Chỉ chủ nhóm / quản trị nhóm được thiết lập');
    await q(`UPDATE chat_rooms SET name=COALESCE($2,name), settings=$3, archived=COALESCE($4,archived) WHERE id=$1`, [id, b.name ?? null, JSON.stringify({ ...r.settings, ...(b.settings || {}) }), b.archived ?? null]);
    await audit(getPool(), ctx, 'room', id, 'room.updated', { settings: r.settings }, b);
    return this.detail(id, ctx);
  }

  @Post('rooms/:id/members')
  async addMembers(@Param('id') id: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({ memberIds: z.array(z.string().uuid()).min(1).max(200) }), body);
    const r = await loadRoom(ctx, id);
    if (!r.perms.can_add) throw Errors.forbidden('Theo thiết lập nhóm, bạn không được thêm thành viên');
    const scope = await scopeMembers(ctx);
    for (const m of b.memberIds) {
      if (!(await q1(`SELECT 1 FROM company_members WHERE id=$1 AND company_id=$2 AND status='active'`, [m, ctx.companyId]))) throw Errors.notFound('Thành viên');
      if (scope && !scope.includes(m)) throw Errors.forbidden('Chỉ thêm thành viên trong phạm vi bạn phụ trách');
    }
    await tx(async (c) => {
      for (const m of b.memberIds) await q(`INSERT INTO chat_room_members(room_id, member_id) VALUES ($1,$2) ON CONFLICT DO NOTHING`, [id, m], c);
      await notify(c, { companyId: ctx.companyId, memberIds: b.memberIds, excludeMemberId: ctx.memberId, type: 'room.added', title: `${ctx.name} đã thêm bạn vào nhóm liên lạc "${r.name}"`, refType: 'room', refId: id });
    });
    return this.detail(id, ctx);
  }
  @Patch('rooms/:id/members/:mid')
  async setRole(@Param('id') id: string, @Param('mid') mid: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({ role: z.enum(['admin', 'member']) }), body);
    const r = await loadRoom(ctx, id);
    if (r.my_role !== 'owner') throw Errors.forbidden('Chỉ chủ nhóm được phân quyền quản trị nhóm');
    await q(`UPDATE chat_room_members SET role=$3 WHERE room_id=$1 AND member_id=$2 AND role<>'owner'`, [id, mid, b.role]);
    return this.detail(id, ctx);
  }
  @Delete('rooms/:id/members/:mid')
  async removeMember(@Param('id') id: string, @Param('mid') mid: string, @CurrentCtx() ctx: Ctx) {
    const r = await loadRoom(ctx, id);
    if (mid !== ctx.memberId && !r.perms.can_manage) throw Errors.forbidden('Chỉ quản trị nhóm được xóa thành viên');
    const t = await q1(`SELECT role FROM chat_room_members WHERE room_id=$1 AND member_id=$2`, [id, mid]);
    if (t?.role === 'owner') throw Errors.invalidState('Không thể xóa chủ nhóm');
    await q(`DELETE FROM chat_room_members WHERE room_id=$1 AND member_id=$2`, [id, mid]);
    return mid === ctx.memberId ? { ok: true } : this.detail(id, ctx);
  }

  // ---------- Nhắn tin nhóm ----------
  @Get('rooms/:id/messages')
  async messages(@Param('id') id: string, @CurrentCtx() ctx: Ctx, @Query('after') after?: string) {
    await loadRoom(ctx, id);
    const items = await q(`SELECT rm.id, rm.sender_id, rm.body, rm.created_at, u.name AS sender_name FROM room_messages rm JOIN company_members cm ON cm.id=rm.sender_id JOIN users u ON u.id=cm.user_id
                            WHERE rm.room_id=$1 AND ($2::timestamptz IS NULL OR rm.created_at > $2::timestamptz) ORDER BY rm.created_at DESC LIMIT 200`, [id, after || null]);
    await q(`UPDATE chat_room_members SET last_read_at=now() WHERE room_id=$1 AND member_id=$2`, [id, ctx.memberId]);
    return { items: items.reverse() };
  }
  @Post('rooms/:id/messages')
  async send(@Param('id') id: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({ body: z.string().trim().min(1).max(2000) }), body);
    const r = await loadRoom(ctx, id);
    if (!r.perms.can_post) throw Errors.forbidden('Theo thiết lập nhóm, chỉ quản trị nhóm được nhắn tin');
    const m = await q1(`INSERT INTO room_messages(room_id, sender_id, body) VALUES ($1,$2,$3) RETURNING id, sender_id, body, created_at`, [id, ctx.memberId, b.body]);
    await q(`UPDATE chat_room_members SET last_read_at=now() WHERE room_id=$1 AND member_id=$2`, [id, ctx.memberId]);
    await notify(getPool(), { companyId: ctx.companyId, memberIds: await people(id), excludeMemberId: ctx.memberId, type: 'room.message', title: `[${r.name}] ${ctx.name}: ${b.body.slice(0, 80)}`,
      refType: 'room', refId: id, dedupeKey: `room:${id}:${new Date().toISOString().slice(0, 13)}` });
    return { ...m, sender_name: ctx.name };
  }

  // ---------- Gọi nhóm (mesh) ----------
  /** Bắt đầu hoặc tham gia cuộc gọi nhóm đang diễn ra. */
  @Post('rooms/:id/calls')
  async joinCall(@Param('id') id: string, @CurrentCtx() ctx: Ctx) {
    const r = await loadRoom(ctx, id);
    const call = await tx(async (c) => {
      await c.query(`SELECT pg_advisory_xact_lock(hashtext($1))`, ['room-call:' + id]);
      let k = await q1(`SELECT * FROM room_calls WHERE room_id=$1 AND status='active'`, [id], c);
      if (k && Date.now() - new Date(k.started_at).getTime() > k.limit_seconds * 1000) { await q(`UPDATE room_calls SET status='ended', ended_at=now() WHERE id=$1`, [k.id], c); k = null; }
      if (!k) {
        if (!r.perms.can_call) throw Errors.forbidden('Theo thiết lập nhóm, chỉ quản trị nhóm được bắt đầu cuộc gọi');
        k = await q1(`INSERT INTO room_calls(company_id, room_id, started_by, limit_seconds) VALUES ($1,$2,$3,$4) RETURNING *`, [ctx.companyId, id, ctx.memberId, r.settings.call_limit_minutes * 60], c);
        await notify(c, { companyId: ctx.companyId, memberIds: await people(id), excludeMemberId: ctx.memberId, type: 'room.call', title: `📞 ${ctx.name} đang gọi nhóm "${r.name}" — bấm để tham gia`, refType: 'room', refId: id });
      }
      const n = (await q1(`SELECT count(*)::int AS n FROM room_call_participants WHERE call_id=$1 AND left_at IS NULL AND member_id<>$2`, [k.id, ctx.memberId], c)).n;
      if (n >= MAX_CALL) throw new AppError('CALL_FULL', `Cuộc gọi nhóm đã đủ ${MAX_CALL} người`, 409);
      await q(`INSERT INTO room_call_participants(call_id, member_id) VALUES ($1,$2) ON CONFLICT (call_id, member_id) DO UPDATE SET left_at=NULL, joined_at=now(), last_seen_at=now()`, [k.id, ctx.memberId], c);
      return k;
    });
    return this.callState(call.id, ctx, '0');
  }

  private async callState(callId: string, ctx: Ctx, since: string) {
    const k = await q1(`SELECT c.*, r.name AS room_name FROM room_calls c JOIN chat_rooms r ON r.id=c.room_id WHERE c.id=$1 AND c.company_id=$2`, [callId, ctx.companyId]);
    if (!k) throw Errors.notFound('Cuộc gọi nhóm');
    // Người rớt mạng quá 20 giây coi như đã rời
    await q(`UPDATE room_call_participants SET left_at=now() WHERE call_id=$1 AND left_at IS NULL AND last_seen_at < now() - interval '20 seconds'`, [callId]);
    const parts = await q(`SELECT p.member_id, p.joined_at, u.name, cm.user_id FROM room_call_participants p JOIN company_members cm ON cm.id=p.member_id JOIN users u ON u.id=cm.user_id
                            WHERE p.call_id=$1 AND p.left_at IS NULL ORDER BY p.joined_at`, [callId]);
    const remaining = Math.max(0, k.limit_seconds - Math.round((Date.now() - new Date(k.started_at).getTime()) / 1000));
    if (k.status === 'active' && (remaining <= 0 || parts.length === 0)) { await q(`UPDATE room_calls SET status='ended', ended_at=now() WHERE id=$1 AND status='active'`, [callId]); k.status = 'ended'; }
    const signals = await q(`SELECT id::text, from_member_id, type, payload FROM room_call_signals WHERE call_id=$1 AND to_member_id=$2 AND id > $3::bigint ORDER BY id LIMIT 300`, [callId, ctx.memberId, since || '0']);
    return { id: k.id, room_id: k.room_id, room_name: k.room_name, status: k.status, started_at: k.started_at, limit_seconds: k.limit_seconds, remaining_seconds: remaining,
      participants: parts, signals, since: signals.length ? signals[signals.length - 1].id : since, me: ctx.memberId, ice_servers: iceServers() };
  }

  @Get('room-calls/:id/poll')
  async poll(@Param('id') id: string, @CurrentCtx() ctx: Ctx, @Query('since') since?: string) {
    const p = await q1(`UPDATE room_call_participants SET last_seen_at=now() WHERE call_id=$1 AND member_id=$2 AND left_at IS NULL RETURNING 1`, [id, ctx.memberId]);
    if (!p) throw Errors.invalidState('Bạn đã rời cuộc gọi nhóm');
    return this.callState(id, ctx, since || '0');
  }
  @Post('room-calls/:id/signal')
  async signal(@Param('id') id: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({ to: z.string().uuid(), type: z.enum(['offer', 'answer', 'ice']), payload: z.any() }), body);
    const ok = await q1(`SELECT 1 FROM room_call_participants a JOIN room_call_participants b ON b.call_id=a.call_id WHERE a.call_id=$1 AND a.member_id=$2 AND b.member_id=$3 AND a.left_at IS NULL`, [id, ctx.memberId, b.to]);
    if (!ok) throw Errors.invalidState('Người nhận không còn trong cuộc gọi');
    if (JSON.stringify(b.payload ?? null).length > 20000) throw Errors.validation('Tín hiệu quá lớn');
    await q(`INSERT INTO room_call_signals(call_id, from_member_id, to_member_id, type, payload) VALUES ($1,$2,$3,$4,$5)`, [id, ctx.memberId, b.to, b.type, JSON.stringify(b.payload ?? null)]);
    return { ok: true };
  }
  @Post('room-calls/:id/leave')
  async leave(@Param('id') id: string, @CurrentCtx() ctx: Ctx) {
    await q(`UPDATE room_call_participants SET left_at=now() WHERE call_id=$1 AND member_id=$2`, [id, ctx.memberId]);
    const left = (await q1(`SELECT count(*)::int AS n FROM room_call_participants WHERE call_id=$1 AND left_at IS NULL`, [id])).n;
    if (!left) await q(`UPDATE room_calls SET status='ended', ended_at=now() WHERE id=$1 AND status='active'`, [id]);
    return { ok: true };
  }
}

/** Dọn dữ liệu nhóm: tin nhắn > 30 ngày, tín hiệu gọi nhóm > 1 giờ, cuộc gọi treo. */
export async function runRoomsRetention() {
  const m = await q(`DELETE FROM room_messages WHERE created_at < now() - ($1 || ' days')::interval RETURNING id`, [String(COMMS_DAYS())]);
  await q(`DELETE FROM room_call_signals WHERE created_at < now() - interval '1 hour'`);
  await q(`UPDATE room_calls SET status='ended', ended_at=now() WHERE status='active' AND started_at + make_interval(secs => limit_seconds) < now()`);
  return { room_messages: m.length };
}
