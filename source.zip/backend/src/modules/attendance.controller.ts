import { Body, Controller, Get, Param, Post, Query } from '@nestjs/common';
import { getPool, q, q1, tx, Queryable } from '../db/db';
import { CurrentCtx, Ctx, isAdmin } from '../common/context';
import { AppError, Errors } from '../common/errors';
import { parse, z } from '../common/validate';
import { notify } from '../common/notify';
import { audit } from '../common/audit';
import { getMember } from '../common/access';
import { authority } from '../common/authority';
import { isHigherThan } from './overtime.controller';

/**
 * Ghi nhận chấm công (v10) — thay "Ghi nhận giờ làm ngoài máy chấm công".
 *  - Quản lý: "Ghi nhận chấm công" cho nhân viên (máy chấm công hỏng, làm ngoài xưởng…) → có hiệu lực ngay.
 *  - Nhân viên: "Tự khai báo chấm công" cho chính mình → quản lý trực tiếp xác nhận.
 * Chỉ ghi nhận thời gian làm việc (bắt đầu – kết thúc), KHÔNG tự tính tăng ca.
 * Đối chiếu trùng: cùng người được ghi nhận + (trùng thời gian hoặc cùng nhiệm vụ trong ngày) → không chấp nhận;
 * không cho phép quản lý và nhân viên cùng khai một công việc (kể cả bản tự khai báo công việc).
 */
export const ATT_KIND: Record<string, string> = { timeclock_down: 'Máy chấm công không hoạt động', offsite: 'Làm việc ngoài công ty/xưởng', field: 'Công tác hiện trường', forgot: 'Quên chấm công', other: 'Khác' };

const SELECT = `SELECT a.*, u.name AS member_name, ru.name AS recorded_by_name, vu.name AS reviewer_name, t.code AS task_code, t.title AS task_title, g.name AS group_name
  FROM attendance_records a JOIN company_members cm ON cm.id=a.member_id JOIN users u ON u.id=cm.user_id
  JOIN company_members rcm ON rcm.id=a.recorded_by JOIN users ru ON ru.id=rcm.user_id
  LEFT JOIN company_members vcm ON vcm.id=a.reviewer_id LEFT JOIN users vu ON vu.id=vcm.user_id
  LEFT JOIN tasks t ON t.id=a.task_id LEFT JOIN groups g ON g.id=a.group_id`;

const fmt = (d: Date) => new Date(d).toLocaleString('vi-VN', { timeZone: 'Asia/Ho_Chi_Minh', hour: '2-digit', minute: '2-digit', day: '2-digit', month: '2-digit' });

/** Tìm bản ghi trùng (chấm công hoặc tự khai báo công việc) của cùng người được ghi nhận. */
export async function findAttendanceConflict(db: Queryable, memberId: string, start: Date, end: Date, taskId: string | null, excludeId?: string) {
  const a = await q1(`SELECT a.id, a.source, a.start_at, a.end_at, u.name AS recorder, t.title AS task_title FROM attendance_records a
                        JOIN company_members cm ON cm.id=a.recorded_by JOIN users u ON u.id=cm.user_id LEFT JOIN tasks t ON t.id=a.task_id
                       WHERE a.member_id=$1 AND a.status<>'rejected' AND ($5::uuid IS NULL OR a.id<>$5)
                         AND (tstzrange(a.start_at, a.end_at) && tstzrange($2, $3)
                              OR ($4::uuid IS NOT NULL AND a.task_id=$4 AND a.start_at::date = $2::timestamptz::date))
                       LIMIT 1`, [memberId, start, end, taskId, excludeId ?? null], db);
  if (a) return { kind: 'attendance', ...a };
  const w = await q1(`SELECT r.id, r.title, r.start_at, r.end_at FROM employee_work_records r
                       WHERE r.employee_id=$1 AND NOT (r.status='resolved' AND r.final_decision='rejected') AND r.status<>'rejected'
                         AND tstzrange(r.start_at, r.end_at) && tstzrange($2, $3)
                         AND ($4::uuid IS NULL OR r.related_task_id IS NULL OR r.related_task_id=$4) LIMIT 1`, [memberId, start, end, taskId], db);
  if (w) return { kind: 'work_record', ...w };
  return null;
}
export function conflictError(c: any) {
  if (c.kind === 'attendance') {
    return new AppError('ALREADY_RECORDED', `Công việc/thời gian này đã được ghi nhận${c.source === 'manager' ? ` bởi quản lý ${c.recorder}` : ' do nhân viên tự khai báo'} (${fmt(c.start_at)} – ${fmt(c.end_at)}${c.task_title ? `, ${c.task_title}` : ''}). Không ghi nhận trùng.`, 409, { record_id: c.id });
  }
  return new AppError('ALREADY_RECORDED', `Thời gian này đã có bản tự khai báo công việc "${c.title}" (${fmt(c.start_at)} – ${fmt(c.end_at)}). Không ghi nhận trùng.`, 409, { work_record_id: c.id });
}

async function reviewerFor(db: Queryable, memberId: string, groupId: string | null) {
  const m = await q1(`SELECT supervisor_member_id FROM company_members WHERE id=$1`, [memberId], db);
  if (m?.supervisor_member_id) return m.supervisor_member_id as string;
  const g = await q1(`SELECT COALESCE(g.leader_member_id, g.manager_member_id) AS id FROM groups g LEFT JOIN group_members gm ON gm.group_id=g.id AND gm.company_member_id=$1
                      WHERE g.deleted_at IS NULL AND (($2::uuid IS NOT NULL AND g.id=$2) OR gm.id IS NOT NULL) AND COALESCE(g.leader_member_id, g.manager_member_id)<>$1 LIMIT 1`, [memberId, groupId], db);
  return (g?.id as string) || null;
}

@Controller('attendance-records')
export class AttendanceController {
  @Get()
  async list(@CurrentCtx() ctx: Ctx, @Query('scope') scope = 'mine') {
    const where = scope === 'mine' ? 'a.member_id=$2' : scope === 'review' ? `a.status='submitted' AND a.reviewer_id=$2`
      : scope === 'recorded' ? 'a.recorded_by=$2 AND a.member_id<>$2'
      : isAdmin(ctx) ? 'TRUE' : '(a.member_id=$2 OR a.recorded_by=$2 OR a.reviewer_id=$2)';
    return q(`${SELECT} WHERE a.company_id=$1 AND ${where} ORDER BY a.start_at DESC LIMIT 200`, [ctx.companyId, ctx.memberId]);
  }

  /**
   * Quản lý ghi nhận cho nhân viên (memberIds) hoặc nhân viên tự khai báo (không truyền memberIds).
   * Trả về thông báo "đã được ghi nhận"; trùng thì từ chối kèm lý do.
   */
  @Post()
  async create(@Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({
      memberIds: z.array(z.string().uuid()).max(50).optional(),
      kind: z.enum(['timeclock_down', 'offsite', 'field', 'forgot', 'other']).default('timeclock_down'), place: z.string().trim().max(200).optional(),
      startAt: z.coerce.date(), endAt: z.coerce.date(), taskId: z.string().uuid().optional().nullable(),
      note: z.string().trim().min(5, 'Nêu nội dung công việc / lý do (≥5 ký tự)'),
    }), body);
    if (b.endAt <= b.startAt) throw Errors.validation('Giờ kết thúc phải sau giờ bắt đầu');
    const minutes = Math.round((b.endAt.getTime() - b.startAt.getTime()) / 60000);
    if (minutes > 16 * 60) throw Errors.validation('Một lần ghi nhận không vượt quá 16 giờ');
    if (b.endAt.getTime() > Date.now() + 5 * 60000) throw Errors.validation('Không ghi nhận thời gian trong tương lai');
    if ((b.kind === 'offsite' || b.kind === 'field') && !b.place) throw Errors.validation('Nhập nơi làm việc');
    const self = !b.memberIds || b.memberIds.length === 0 || (b.memberIds.length === 1 && b.memberIds[0] === ctx.memberId);
    const targets = self ? [ctx.memberId] : b.memberIds!;
    let task: any = null;
    if (b.taskId) {
      task = await q1(`SELECT t.id, t.group_id, t.created_by, t.title FROM tasks t WHERE t.id=$1 AND t.company_id=$2`, [b.taskId, ctx.companyId]);
      if (!task) throw Errors.notFound('Nhiệm vụ');
    }
    if (!self) {
      const au = await authority(ctx);
      if (au.tier >= 7 && !isAdmin(ctx)) throw Errors.forbidden('Nhân viên chỉ tự khai báo chấm công cho chính mình');
      for (const m of targets) {
        if (m === ctx.memberId) throw Errors.validation('Quản lý không tự ghi nhận chấm công cho chính mình — dùng Tự khai báo');
        await getMember(ctx, m);
        if (!(await isHigherThan(ctx, m))) throw Errors.forbidden('Người ghi nhận phải là cấp quản lý của nhân viên được ghi nhận');
      }
    } else if (task) {
      // Người giao việc trùng với người khai báo: chính người giao không tự khai chấm công cho việc mình giao
      const assignee = await q1(`SELECT 1 FROM task_assignees WHERE task_id=$1 AND company_member_id=$2 AND active`, [task.id, ctx.memberId]);
      if (task.created_by === ctx.memberId && !assignee) throw new AppError('SAME_PERSON', 'Bạn là người giao nhiệm vụ này — không tự khai chấm công cho việc mình giao', 409);
    }
    const out = await tx(async (c) => {
      const ids: string[] = [];
      for (const m of targets) {
        await c.query(`SELECT pg_advisory_xact_lock(hashtext($1))`, ['att:' + m]);
        const conflict = await findAttendanceConflict(c, m, b.startAt, b.endAt, b.taskId ?? null);
        if (conflict) throw conflictError(conflict);
        const reviewer = self ? await reviewerFor(c, m, task?.group_id ?? null) : ctx.memberId;
        const n = (await q1(`SELECT count(*)::int + 1 AS n FROM attendance_records WHERE company_id=$1`, [ctx.companyId], c)).n;
        const r = await q1(`INSERT INTO attendance_records(company_id, code, member_id, task_id, group_id, source, recorded_by, kind, place, start_at, end_at, minutes, note, status, reviewer_id, reviewed_at)
                            VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16) RETURNING id`,
          [ctx.companyId, `CC-${String(n).padStart(5, '0')}`, m, b.taskId ?? null, task?.group_id ?? null, self ? 'self' : 'manager', ctx.memberId, b.kind, b.place ?? null,
           b.startAt, b.endAt, minutes, b.note, self ? 'submitted' : 'confirmed', reviewer, self ? null : new Date()], c);
        await audit(c, ctx, 'attendance', r.id, self ? 'attendance.self_declared' : 'attendance.recorded', null, { member: m, minutes, kind: b.kind, task: b.taskId });
        if (self) {
          await notify(c, { companyId: ctx.companyId, memberIds: [reviewer], type: 'attendance.submitted', title: `${ctx.name} tự khai báo chấm công ${Math.round(minutes / 6) / 10} giờ — cần bạn xác nhận`, body: b.note, refType: 'attendance', refId: r.id });
        } else {
          await notify(c, { companyId: ctx.companyId, memberIds: [m], type: 'attendance.recorded', title: `Thời gian làm việc của bạn đã được ghi nhận (${Math.round(minutes / 6) / 10} giờ)`, body: `${ctx.name}: ${b.note}`, refType: 'attendance', refId: r.id });
        }
        ids.push(r.id);
      }
      return ids;
    });
    return { ids: out, minutes, status: self ? 'submitted' : 'confirmed',
      message: self ? 'Đã gửi tự khai báo chấm công — chờ quản lý trực tiếp xác nhận.' : `Công việc đã được ghi nhận cho ${targets.length} người.` };
  }

  @Get(':id')
  async get(@Param('id') id: string, @CurrentCtx() ctx: Ctx) {
    const a = await q1(`${SELECT} WHERE a.id=$1 AND a.company_id=$2`, [id, ctx.companyId]);
    if (!a || (![a.member_id, a.recorded_by, a.reviewer_id].includes(ctx.memberId) && !isAdmin(ctx))) throw Errors.notFound('Bản ghi chấm công');
    return { ...a, can_review: a.status === 'submitted' && a.reviewer_id === ctx.memberId };
  }

  /** Quản lý xác nhận/từ chối bản tự khai báo chấm công. */
  @Post(':id/review')
  async review(@Param('id') id: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({ decision: z.enum(['confirm', 'reject']), note: z.string().trim().optional() }), body);
    const a = await this.get(id, ctx);
    if (!a.can_review) throw Errors.forbidden('Bạn không phải người xác nhận bản ghi này');
    if (b.decision === 'reject' && (!b.note || b.note.length < 5)) throw Errors.reasonRequired('Từ chối phải nêu lý do');
    const st = b.decision === 'confirm' ? 'confirmed' : 'rejected';
    await tx(async (c) => {
      await q(`UPDATE attendance_records SET status=$2, reviewed_at=now(), review_note=$3 WHERE id=$1`, [id, st, b.note ?? null], c);
      await audit(c, ctx, 'attendance', id, 'attendance.' + st, { status: 'submitted' }, { status: st }, b.note ?? null);
      await notify(c, { companyId: ctx.companyId, memberIds: [a.member_id], type: 'attendance.' + st,
        title: st === 'confirmed' ? 'Tự khai báo chấm công đã được xác nhận — công việc đã được ghi nhận' : 'Tự khai báo chấm công bị từ chối', body: b.note, refType: 'attendance', refId: id });
    });
    return this.get(id, ctx);
  }
}
void getPool;
