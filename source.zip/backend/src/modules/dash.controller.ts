/**
 * Dashboard theo vai trò (Đặc tả v2.0 mục 8, 9): mỗi vai trò có trang riêng, dùng chung nguồn dữ liệu nhưng khác mục đích và phạm vi.
 * Phạm vi tính ở server; mọi đường drill-down mở trang chi tiết vẫn kiểm tra quyền ở từng đối tượng.
 * Chỉ số có công thức rõ ràng (trả kèm `formulas`); không xếp hạng công khai; không quy lỗi khi hoãn khách quan.
 */
import { Controller, Get, Query } from '@nestjs/common';
import { DateTime } from 'luxon';
import { q, q1 } from '../db/db';
import { CurrentCtx, Ctx } from '../common/context';
import { Errors } from '../common/errors';
import { getCompany } from '../common/access';
import { isBoard, managedGroupIds } from '../common/scope';
import { accessLog } from '../common/privacy';
import { restBalance, SessionsController, timeSummary } from './sessions.controller';
import { OperationsController } from './operations.controller';

const OPEN = `('not_started','in_progress','revision_requested','waiting','pending_approval')`;
export const FORMULAS = {
  efficiency: 'Hiệu suất thực hiện = Σ thời gian chuẩn quy đổi từ sản lượng đạt chuẩn ÷ Σ thời gian thực hiện (phiên); không gồm thời gian chờ/hoãn khách quan',
  utilization: 'Hiệu quả sử dụng quỹ thời gian = thời gian thực hiện ÷ (thực hiện + chuẩn bị + chuyển đổi + chờ việc + hoãn chủ quan + chưa xác định); hoãn khách quan và nghỉ được phép không tính vào mẫu số',
  quality: 'Tỷ lệ đạt chuẩn = sản lượng đạt chuẩn ÷ sản lượng thực tế; tỷ lệ lỗi = (lỗi + làm lại) ÷ thực tế',
  on_time: 'Đúng hạn = việc hoàn thành có lần bàn giao đầu ≤ hạn (việc có trở ngại khách quan đã xác nhận được tính đúng hạn) ÷ việc hoàn thành',
};

function period(p: string | undefined, tz: string) {
  const now = DateTime.now().setZone(tz);
  const unit = p === 'day' ? 'day' : p === 'month' ? 'month' : 'week';
  const from = now.startOf(unit as any);
  const len = now.diff(from);
  return { unit, from: from.toJSDate(), to: now.toJSDate(), prevFrom: from.minus(len.toMillis() > 0 ? { [unit + 's']: 1 } as any : { days: 1 }).toJSDate(), prevTo: from.toJSDate() };
}

/** Chỉ số nhóm trong khoảng thời gian. */
async function groupMetrics(companyId: string, groupIds: string[], from: Date, to: Date) {
  if (!groupIds.length) return [];
  const rows = await q(
    `SELECT g.id, g.name,
        (SELECT count(*) FROM tasks t WHERE t.group_id=g.id AND t.status='completed' AND t.completed_at >= $2 AND t.completed_at < $3 AND NOT EXISTS (SELECT 1 FROM tasks k WHERE k.parent_id=t.id))::int AS completed,
        (SELECT count(*) FROM tasks t WHERE t.group_id=g.id AND t.status='completed' AND t.completed_at >= $2 AND t.completed_at < $3 AND (t.first_submitted_at <= t.due_at OR EXISTS (SELECT 1 FROM workplace_reports wr WHERE wr.affected_task_id=t.id AND wr.impact_confirmed)) AND NOT EXISTS (SELECT 1 FROM tasks k WHERE k.parent_id=t.id))::int AS on_time,
        (SELECT count(*) FROM tasks t WHERE t.group_id=g.id AND NOT t.is_standing AND t.status IN ${OPEN} AND NOT EXISTS (SELECT 1 FROM tasks k WHERE k.parent_id=t.id))::int AS backlog,
        (SELECT count(*) FROM tasks t WHERE t.group_id=g.id AND NOT t.is_standing AND t.status IN ${OPEN} AND t.due_at < now())::int AS overdue,
        (SELECT count(*) FROM tasks t WHERE t.group_id=g.id AND t.status IN ${OPEN} AND t.risk_level='at_risk')::int AS at_risk,
        (SELECT count(DISTINCT r.task_id) FROM work_time_records r JOIN tasks t ON t.id=r.task_id WHERE t.group_id=g.id AND r.ended_at IS NULL AND r.category IN ('objective_pause','subjective_pause'))::int AS paused,
        (SELECT COALESCE(sum(p.actual_qty),0) FROM production_records p WHERE p.group_id=g.id AND p.status='confirmed' AND p.created_at >= $2 AND p.created_at < $3) AS actual_qty,
        (SELECT COALESCE(sum(p.accepted_qty),0) FROM production_records p WHERE p.group_id=g.id AND p.status='confirmed' AND p.created_at >= $2 AND p.created_at < $3) AS accepted_qty,
        (SELECT COALESCE(sum(p.rejected_qty + p.rework_qty),0) FROM production_records p WHERE p.group_id=g.id AND p.status='confirmed' AND p.created_at >= $2 AND p.created_at < $3) AS defect_qty,
        (SELECT COALESCE(sum(p.accepted_qty / s.quantity * s.minutes),0) FROM production_records p JOIN production_standards s ON s.id=p.standard_id WHERE p.group_id=g.id AND p.status='confirmed' AND p.created_at >= $2 AND p.created_at < $3) AS std_minutes,
        (SELECT COALESCE(sum(p.execution_minutes),0) FROM production_records p WHERE p.group_id=g.id AND p.status='confirmed' AND p.standard_id IS NOT NULL AND p.created_at >= $2 AND p.created_at < $3) AS prod_exec_minutes,
        (SELECT COALESCE(sum(EXTRACT(EPOCH FROM (LEAST(COALESCE(s.ended_at, now()), $3) - GREATEST(s.started_at, $2))) / 60),0) FROM work_sessions s JOIN tasks t ON t.id=s.task_id WHERE t.group_id=g.id AND s.started_at < $3 AND COALESCE(s.ended_at, now()) > $2) AS exec_minutes,
        (SELECT COALESCE(sum(EXTRACT(EPOCH FROM (LEAST(COALESCE(r.ended_at, now()), $3) - GREATEST(r.started_at, $2))) / 60),0) FROM work_time_records r JOIN tasks t ON t.id=r.task_id WHERE t.group_id=g.id AND r.category='waiting' AND r.started_at < $3 AND COALESCE(r.ended_at, now()) > $2) AS waiting_minutes,
        (SELECT COALESCE(sum(EXTRACT(EPOCH FROM (LEAST(COALESCE(r.ended_at, now()), $3) - GREATEST(r.started_at, $2))) / 60),0) FROM work_time_records r JOIN tasks t ON t.id=r.task_id WHERE t.group_id=g.id AND r.category='objective_pause' AND r.started_at < $3 AND COALESCE(r.ended_at, now()) > $2) AS objective_pause_minutes,
        (SELECT count(*) FROM handover_contexts h WHERE h.from_group_id=g.id AND h.submitted_at >= $2 AND h.submitted_at < $3)::int AS handovers,
        (SELECT count(*) FROM handover_contexts h WHERE h.from_group_id=g.id AND h.reject_count > 0 AND h.submitted_at >= $2 AND h.submitted_at < $3)::int AS handovers_rejected,
        (SELECT count(*) FROM (SELECT company_member_id FROM group_members WHERE group_id=g.id) m)::int AS members
       FROM groups g WHERE g.company_id=$1 AND g.id = ANY($4::uuid[]) AND g.deleted_at IS NULL ORDER BY g.name`, [companyId, from, to, groupIds]);
  return rows.map((r) => {
    const n = (x: any) => Number(x) || 0;
    return {
      ...r, actual_qty: n(r.actual_qty), accepted_qty: n(r.accepted_qty), defect_qty: n(r.defect_qty), exec_minutes: Math.round(n(r.exec_minutes)), waiting_minutes: Math.round(n(r.waiting_minutes)),
      objective_pause_minutes: Math.round(n(r.objective_pause_minutes)),
      on_time_rate: r.completed ? Math.round((100 * r.on_time) / r.completed) : null,
      completion_rate: r.completed + r.backlog ? Math.round((100 * r.completed) / (r.completed + r.backlog)) : null,
      quality_rate: n(r.actual_qty) ? Math.round((100 * n(r.accepted_qty)) / n(r.actual_qty)) : null,
      defect_rate: n(r.actual_qty) ? Math.round((1000 * n(r.defect_qty)) / n(r.actual_qty)) / 10 : null,
      efficiency: n(r.prod_exec_minutes) ? Math.round((100 * n(r.std_minutes)) / n(r.prod_exec_minutes)) : null,
      handover_pass_rate: r.handovers ? Math.round((100 * (r.handovers - r.handovers_rejected)) / r.handovers) : null,
    };
  });
}

async function taskTotals(companyId: string, groupIds: string[] | null, from: Date, to: Date) {
  const g = groupIds ? `AND t.group_id = ANY($4::uuid[])` : `AND $4::uuid[] IS NULL`;
  const leaf = `AND NOT EXISTS (SELECT 1 FROM tasks k WHERE k.parent_id=t.id)`;
  return q1(`SELECT
      count(*) FILTER (WHERE t.created_at >= $2 AND t.created_at < $3)::int AS new,
      count(*) FILTER (WHERE t.status='in_progress')::int AS in_progress,
      count(*) FILTER (WHERE t.status IN ${OPEN} AND EXISTS (SELECT 1 FROM work_time_records r WHERE r.task_id=t.id AND r.ended_at IS NULL AND r.category IN ('objective_pause','subjective_pause')))::int AS paused,
      count(*) FILTER (WHERE t.status IN ${OPEN} AND t.due_at < now())::int AS overdue,
      count(*) FILTER (WHERE t.status='completed' AND t.completed_at >= $2 AND t.completed_at < $3)::int AS completed,
      count(*) FILTER (WHERE t.status IN ${OPEN})::int AS open
    FROM tasks t WHERE t.company_id=$1 AND NOT t.is_standing ${g} ${leaf}`, [companyId, from, to, groupIds]);
}

async function trend(companyId: string, groupIds: string[] | null, tz: string, days = 14) {
  const g = groupIds ? `AND t.group_id = ANY($3::uuid[])` : `AND $3::uuid[] IS NULL`;
  return q(`SELECT d::date AS day,
      (SELECT count(*) FROM tasks t WHERE t.company_id=$1 ${g} AND (t.created_at AT TIME ZONE $4)::date = d::date)::int AS created,
      (SELECT count(*) FROM tasks t WHERE t.company_id=$1 ${g} AND t.status='completed' AND (t.completed_at AT TIME ZONE $4)::date = d::date)::int AS completed
    FROM generate_series((now() AT TIME ZONE $4)::date - ($2::int - 1), (now() AT TIME ZONE $4)::date, interval '1 day') d`, [companyId, days, groupIds, tz]);
}

async function workforce(companyId: string, groupIds: string[] | null) {
  const g = groupIds ? `AND EXISTS (SELECT 1 FROM group_members gm WHERE gm.company_member_id=cm.id AND gm.group_id = ANY($2::uuid[]))` : `AND $2::uuid[] IS NULL`;
  const rows = await q(`SELECT cm.id, u.name,
      (SELECT count(*) FROM task_assignees a JOIN tasks t ON t.id=a.task_id WHERE a.company_member_id=cm.id AND a.active AND t.status IN ('not_started','in_progress','revision_requested'))::int AS open_tasks,
      (SELECT COALESCE(sum(t.estimated_hours),0) FROM task_assignees a JOIN tasks t ON t.id=a.task_id WHERE a.company_member_id=cm.id AND a.active AND a.assignment_type='owner' AND t.status IN ('not_started','in_progress','revision_requested'))::numeric AS open_hours,
      (SELECT count(*) FROM group_members gm WHERE gm.company_member_id=cm.id)::int AS groups,
      EXISTS (SELECT 1 FROM work_sessions s WHERE s.member_id=cm.id AND s.ended_at IS NULL) AS working,
      (SELECT category FROM work_time_records r WHERE r.member_id=cm.id AND r.ended_at IS NULL) AS open_category
    FROM company_members cm JOIN users u ON u.id=cm.user_id WHERE cm.company_id=$1 AND cm.status='active' AND cm.role IN ('employee','manager','handler') ${g}`, [companyId, groupIds]);
  return {
    total: rows.length,
    working_now: rows.filter((r) => r.working).length,
    waiting_now: rows.filter((r) => ['waiting', 'objective_pause'].includes(r.open_category)).length,
    overloaded: rows.filter((r) => Number(r.open_hours) > 40 || r.open_tasks >= 8).map((r) => ({ id: r.id, name: r.name, open_tasks: r.open_tasks, open_hours: Number(r.open_hours) })),
    idle: rows.filter((r) => r.open_tasks === 0 && !r.working).map((r) => ({ id: r.id, name: r.name })),
    multi_group: rows.filter((r) => r.groups > 1).map((r) => ({ id: r.id, name: r.name, groups: r.groups })),
  };
}

async function risks(ctx: Ctx, groupIds: string[] | null) {
  const g = groupIds ? `AND t.group_id = ANY($2::uuid[])` : `AND $2::uuid[] IS NULL`;
  const tasks = await q(`SELECT t.id, t.code, t.title, t.due_at, t.risk_level, gr.name AS group_name, r.chain_code
                           FROM tasks t JOIN groups gr ON gr.id=t.group_id LEFT JOIN tasks r ON r.id=t.root_id
                          WHERE t.company_id=$1 AND NOT t.is_standing ${g} AND t.status IN ${OPEN} AND (t.due_at < now() OR t.risk_level='at_risk')
                          ORDER BY t.due_at LIMIT 15`, [ctx.companyId, groupIds]);
  const hand = await q(`SELECT h.id, h.from_task_id, h.to_task_id, ft.title AS from_title, tt.title AS to_title, h.rejection_reason, h.status, h.submitted_at,
                               EXTRACT(EPOCH FROM (now() - h.submitted_at))/3600 AS hours_waiting
                          FROM handover_contexts h JOIN tasks ft ON ft.id=h.from_task_id LEFT JOIN tasks tt ON tt.id=h.to_task_id
                         WHERE h.company_id=$1 AND h.status IN ('submitted','rejected') AND (h.status='rejected' OR h.submitted_at < now() - interval '4 hours')
                           AND ($2::uuid[] IS NULL OR h.to_group_id = ANY($2::uuid[]) OR h.from_group_id = ANY($2::uuid[])) ORDER BY h.submitted_at LIMIT 15`, [ctx.companyId, groupIds]);
  const reports = await q1(`SELECT count(*)::int AS open, count(*) FILTER (WHERE w.stage_due_at < now())::int AS overdue FROM workplace_reports w
                             WHERE w.company_id=$1 AND w.stage<>'closed' AND ($2::uuid[] IS NULL OR w.group_id = ANY($2::uuid[]))`, [ctx.companyId, groupIds]);
  return { tasks, handovers: hand, workplace_reports: reports };
}

async function scopedChains(ctx: Ctx, groupIds: string[] | null) {
  const all = await new OperationsController().chains(ctx);
  if (!groupIds) return all;
  const ids = new Set((await q(`SELECT DISTINCT root_id FROM tasks WHERE root_id IS NOT NULL AND group_id = ANY($1::uuid[])`, [groupIds])).map((r) => r.root_id));
  return all.filter((c) => ids.has(c.id));
}

const delta = (cur: number | null, prev: number | null) => (cur === null || prev === null ? null : Math.round((cur - prev) * 10) / 10);

@Controller('dash')
export class DashController {
  /** Ban quản trị: sức khỏe vận hành toàn công ty (tổng hợp; chi tiết cá nhân truy xuất theo quyền). */
  @Get('board')
  async board(@CurrentCtx() ctx: Ctx, @Query('period') p?: string) {
    if (!isBoard(ctx)) throw Errors.forbidden('Trang tổng quan công ty dành cho Ban quản trị');
    return this.build(ctx, null, p, 'board');
  }

  /** Quản lý: phạm vi các nhóm được giao. */
  @Get('manager')
  async manager(@CurrentCtx() ctx: Ctx, @Query('period') p?: string) {
    const groups = await managedGroupIds(ctx);
    if (!groups.length) throw Errors.forbidden('Bạn chưa được giao quản lý nhóm nào');
    const base = await this.build(ctx, groups, p, 'manager');
    const company = await getCompany(ctx.companyId);
    const pr = period(p, company.timezone);
    // Hiệu suất cá nhân trong phạm vi: căn cứ cụ thể (việc, đúng hạn, thời gian, sản lượng); không xếp hạng công khai
    const members = await q(`SELECT DISTINCT cm.id, u.name FROM group_members gm JOIN company_members cm ON cm.id=gm.company_member_id JOIN users u ON u.id=cm.user_id
                              WHERE gm.group_id = ANY($1::uuid[]) AND cm.status='active' ORDER BY u.name`, [groups]);
    const ids = members.map((m) => m.id);
    const time = await timeSummary(ids, pr.from, pr.to);
    const stats = ids.length ? await q(`SELECT a.company_member_id AS id,
        count(*) FILTER (WHERE t.status IN ('not_started','in_progress','revision_requested'))::int AS open,
        count(*) FILTER (WHERE t.status IN ('not_started','in_progress','revision_requested') AND t.due_at < now())::int AS overdue,
        count(*) FILTER (WHERE t.status='completed' AND t.completed_at >= $2)::int AS completed,
        count(*) FILTER (WHERE t.status='completed' AND t.completed_at >= $2 AND (t.first_submitted_at <= t.due_at OR EXISTS (SELECT 1 FROM workplace_reports wr WHERE wr.affected_task_id=t.id AND wr.impact_confirmed)))::int AS on_time
      FROM task_assignees a JOIN tasks t ON t.id=a.task_id WHERE a.company_member_id = ANY($1::uuid[]) AND a.active AND a.assignment_type='owner' GROUP BY 1`, [ids, pr.from]) : [];
    const sm = Object.fromEntries(stats.map((s) => [s.id, s]));
    const pending = { handovers: (await new OperationsController().handovers(ctx, 'incoming')).filter((h: any) => h.status === 'submitted').length,
      rest: (await new SessionsController().restRequests(ctx)).length,
      feedback: (await q1(`SELECT count(*)::int AS n FROM data_feedback WHERE assigned_to=$1 AND status='open'`, [ctx.memberId])).n };
    await accessLog({ companyId: ctx.companyId, actorUserId: ctx.userId, actorMemberId: ctx.memberId, action: 'dashboard.manager', objectType: 'groups', objectId: groups.join(',').slice(0, 200) });
    return { ...base, pending, members: members.map((m) => {
      const s = sm[m.id] || { open: 0, overdue: 0, completed: 0, on_time: 0 }; const t = time[m.id];
      return { member_id: m.id, name: m.name, ...s, on_time_rate: s.completed ? Math.round((100 * s.on_time) / s.completed) : null,
        execution: t.execution, waiting: t.waiting, objective_pause: t.objective_pause, overtime: t.overtime };
    }) };
  }

  /** Trưởng nhóm: thành viên đang làm gì, sản lượng & bàn giao, hoãn/chờ/nghỉ. */
  @Get('leader')
  async leader(@CurrentCtx() ctx: Ctx, @Query('groupId') groupId?: string) {
    const groups = await managedGroupIds(ctx);
    if (!groups.length) throw Errors.forbidden('Trang trưởng nhóm dành cho người phụ trách nhóm');
    const gids = groupId && groups.includes(groupId) ? [groupId] : groups.slice(0, isBoard(ctx) ? 50 : 10);
    const company = await getCompany(ctx.companyId);
    const today = DateTime.now().setZone(company.timezone).startOf('day').toJSDate();
    const live = await new SessionsController().team(ctx, groupId);
    const tasks = await q(`SELECT t.id, t.code, t.title, t.status, t.due_at, t.risk_level, u.name AS owner_name,
                                  (SELECT r.category FROM work_time_records r WHERE r.task_id=t.id AND r.ended_at IS NULL LIMIT 1) AS open_pause,
                                  (SELECT r.reason FROM work_time_records r WHERE r.task_id=t.id AND r.ended_at IS NULL LIMIT 1) AS pause_reason
                             FROM tasks t LEFT JOIN task_assignees o ON o.task_id=t.id AND o.assignment_type='owner' AND o.active LEFT JOIN company_members cm ON cm.id=o.company_member_id LEFT JOIN users u ON u.id=cm.user_id
                            WHERE t.group_id = ANY($1::uuid[]) AND NOT t.is_standing AND t.status IN ${OPEN} AND NOT EXISTS (SELECT 1 FROM tasks k WHERE k.parent_id=t.id) ORDER BY t.due_at LIMIT 60`, [gids]);
    const production = await new OperationsController().listProduction(ctx, { from: today.toISOString() } as any);
    const handovers = (await new OperationsController().handovers(ctx, 'incoming')).filter((h: any) => ['submitted', 'rejected'].includes(h.status));
    const outgoing = (await new OperationsController().handovers(ctx, 'outgoing')).filter((h: any) => h.status === 'rejected');
    const pauses = await q(`SELECT r.id, r.category, r.reason, r.started_at, r.confirmed_by, u.name, t.title AS task_title, t.id AS task_id FROM work_time_records r
                              JOIN company_members cm ON cm.id=r.member_id JOIN users u ON u.id=cm.user_id LEFT JOIN tasks t ON t.id=r.task_id
                             WHERE r.company_id=$1 AND r.started_at >= $2 AND r.category IN ('objective_pause','subjective_pause','waiting','rest_internal','unknown')
                               AND EXISTS (SELECT 1 FROM group_members gm WHERE gm.company_member_id=r.member_id AND gm.group_id = ANY($3::uuid[])) ORDER BY r.started_at DESC LIMIT 40`, [ctx.companyId, today, gids]);
    const rest = await new SessionsController().restRequests(ctx);
    const prodHistory = await q(`SELECT p.id, p.version, p.change_reason, p.created_at, p.status, t.title AS task_title, u.name AS recorded_by_name FROM production_records p JOIN tasks t ON t.id=p.task_id
                                   JOIN company_members cm ON cm.id=p.recorded_by JOIN users u ON u.id=cm.user_id WHERE p.group_id = ANY($1::uuid[]) AND p.version > 1 ORDER BY p.created_at DESC LIMIT 10`, [gids]);
    const groupsInfo = await q(`SELECT id, name FROM groups WHERE id = ANY($1::uuid[]) ORDER BY name`, [gids]);
    return {
      groups: groupsInfo, live, tasks, production, handovers_incoming: handovers, handovers_rejected_outgoing: outgoing, pauses, rest_requests: rest, adjustments: prodHistory,
      totals: {
        working: live.filter((m: any) => m.session_id).length, paused: live.filter((m: any) => ['objective_pause', 'subjective_pause', 'waiting'].includes(m.record_category)).length,
        resting: live.filter((m: any) => m.record_category === 'rest_internal').length, idle: live.filter((m: any) => !m.session_id && !m.record_id).length,
        accepted_today: production.reduce((a: number, p: any) => a + Number(p.accepted_qty), 0), defects_today: production.reduce((a: number, p: any) => a + Number(p.rejected_qty) + Number(p.rework_qty), 0),
      },
    };
  }

  /** Nhân viên: việc của tôi, thời gian & nghỉ, kết quả của tôi, phản hồi dữ liệu. */
  @Get('me')
  async me(@CurrentCtx() ctx: Ctx, @Query('period') p?: string) {
    const company = await getCompany(ctx.companyId);
    const pr = period(p || 'week', company.timezone);
    const monthFrom = DateTime.now().setZone(company.timezone).startOf('month').toJSDate();
    const time = (await timeSummary([ctx.memberId], pr.from, pr.to))[ctx.memberId];
    const results = await q1(`SELECT count(*) FILTER (WHERE t.status='completed' AND t.completed_at >= $2)::int AS completed,
        count(*) FILTER (WHERE t.status='completed' AND t.completed_at >= $2 AND (t.first_submitted_at <= t.due_at OR EXISTS (SELECT 1 FROM workplace_reports wr WHERE wr.affected_task_id=t.id AND wr.impact_confirmed)))::int AS on_time,
        count(*) FILTER (WHERE t.status IN ('not_started','in_progress','revision_requested'))::int AS open,
        count(*) FILTER (WHERE t.status IN ('not_started','in_progress','revision_requested') AND t.due_at < now())::int AS overdue,
        round(avg((SELECT total_score FROM task_evaluations e WHERE e.task_id=t.id AND e.decision='approved' ORDER BY e.created_at DESC LIMIT 1)) FILTER (WHERE t.status='completed' AND t.completed_at >= $2), 1) AS avg_score
      FROM task_assignees a JOIN tasks t ON t.id=a.task_id WHERE a.company_member_id=$1 AND a.active AND a.assignment_type='owner'`, [ctx.memberId, monthFrom]);
    const prod = await q1(`SELECT COALESCE(sum(p.accepted_qty / s.quantity * s.minutes / GREATEST(array_length(p.participants,1),1)),0) AS std, COALESCE(sum(p.execution_minutes / GREATEST(array_length(p.participants,1),1)),0) AS exec,
                                  COALESCE(sum(p.accepted_qty),0) AS accepted, COALESCE(sum(p.actual_qty),0) AS actual
                             FROM production_records p JOIN production_standards s ON s.id=p.standard_id WHERE $1 = ANY(p.participants) AND p.status='confirmed' AND p.created_at >= $2`, [ctx.memberId, monthFrom]);
    const evals = await q(`SELECT e.id, e.total_score, e.decision, e.comment, e.created_at, t.title, t.id AS task_id FROM task_evaluations e JOIN tasks t ON t.id=e.task_id
                            JOIN task_assignees a ON a.task_id=t.id AND a.company_member_id=$1 AND a.active AND a.assignment_type='owner' ORDER BY e.created_at DESC LIMIT 10`, [ctx.memberId]);
    const history = await q(`SELECT s.id, s.started_at, s.ended_at, s.end_reason, t.title, t.id AS task_id, l.name AS location_name FROM work_sessions s JOIN tasks t ON t.id=s.task_id
                              LEFT JOIN work_locations l ON l.id=s.work_location_id WHERE s.member_id=$1 ORDER BY s.started_at DESC LIMIT 30`, [ctx.memberId]);
    const records = await q(`SELECT r.id, r.category, r.reason, r.started_at, r.ended_at, r.confirmed_by IS NOT NULL AS confirmed, t.title FROM work_time_records r LEFT JOIN tasks t ON t.id=r.task_id
                              WHERE r.member_id=$1 ORDER BY r.started_at DESC LIMIT 30`, [ctx.memberId]);
    const feedback = await q(`SELECT * FROM data_feedback WHERE member_id=$1 ORDER BY created_at DESC LIMIT 20`, [ctx.memberId]);
    const myProd = await q(`SELECT p.id, p.accepted_qty, p.actual_qty, p.rejected_qty, p.rework_qty, p.unit, p.created_at, p.version, t.title, t.id AS task_id FROM production_records p JOIN tasks t ON t.id=p.task_id
                             WHERE $1 = ANY(p.participants) AND p.status='confirmed' ORDER BY p.created_at DESC LIMIT 20`, [ctx.memberId]);
    const denom = time.execution + time.preparation + time.changeover + time.waiting + time.subjective_pause + time.unknown;
    return {
      period: pr, time, rest_balance: await restBalance(undefined, ctx.memberId), rest_enabled: company.settings.workTime.rest.enabled,
      results: { ...results, on_time_rate: results.completed ? Math.round((100 * results.on_time) / results.completed) : null,
        efficiency: Number(prod.exec) > 0 ? Math.round((100 * Number(prod.std)) / Number(prod.exec)) : null,
        quality_rate: Number(prod.actual) > 0 ? Math.round((100 * Number(prod.accepted)) / Number(prod.actual)) : null,
        utilization: denom > 0 ? Math.round((100 * time.execution) / denom) : null },
      evaluations: evals, sessions: history, time_records: records, production: myProd, feedback, formulas: FORMULAS,
      note: 'Hoãn do nguyên nhân khách quan và nghỉ được phép không làm giảm hiệu suất của bạn. Nếu thấy dữ liệu chưa đúng, hãy gửi phản hồi.',
    };
  }

  private async build(ctx: Ctx, groupIds: string[] | null, p: string | undefined, view: string) {
    const company = await getCompany(ctx.companyId);
    const pr = period(p, company.timezone);
    const allGroups = groupIds || (await q(`SELECT id FROM groups WHERE company_id=$1 AND deleted_at IS NULL`, [ctx.companyId])).map((r) => r.id);
    const [totals, prevTotals, groups, prevGroups, tr, wf, rk, chains] = await Promise.all([
      taskTotals(ctx.companyId, groupIds, pr.from, pr.to), taskTotals(ctx.companyId, groupIds, pr.prevFrom, pr.prevTo),
      groupMetrics(ctx.companyId, allGroups, pr.from, pr.to), groupMetrics(ctx.companyId, allGroups, pr.prevFrom, pr.prevTo),
      trend(ctx.companyId, groupIds, company.timezone), workforce(ctx.companyId, groupIds), risks(ctx, groupIds), scopedChains(ctx, groupIds),
    ]);
    const sum = (arr: any[], k: string) => arr.reduce((a, x) => a + (Number(x[k]) || 0), 0);
    const agg = (gs: any[]) => {
      const actual = sum(gs, 'actual_qty'); const std = sum(gs, 'std_minutes'); const pe = sum(gs, 'prod_exec_minutes'); const comp = sum(gs, 'completed'); const ot = sum(gs, 'on_time');
      return { accepted_qty: sum(gs, 'accepted_qty'), defect_rate: actual ? Math.round((1000 * sum(gs, 'defect_qty')) / actual) / 10 : null, efficiency: pe ? Math.round((100 * std) / pe) : null,
        on_time_rate: comp ? Math.round((100 * ot) / comp) : null, waiting_minutes: sum(gs, 'waiting_minutes'), exec_minutes: sum(gs, 'exec_minutes') };
    };
    const cur = agg(groups); const prev = agg(prevGroups);
    const qualityByStage = await q(`SELECT t.title, g.name AS group_name, sum(p.rejected_qty) AS rejected, sum(p.rework_qty) AS rework, sum(p.actual_qty) AS actual
                                      FROM production_records p JOIN tasks t ON t.id=p.task_id JOIN groups g ON g.id=p.group_id
                                     WHERE p.company_id=$1 AND p.status='confirmed' AND p.created_at >= $2 AND p.group_id = ANY($3::uuid[]) GROUP BY 1,2 HAVING sum(p.rejected_qty + p.rework_qty) > 0
                                     ORDER BY sum(p.rejected_qty + p.rework_qty) DESC LIMIT 10`, [ctx.companyId, pr.from, allGroups]);
    await accessLog({ companyId: ctx.companyId, actorUserId: ctx.userId, actorMemberId: ctx.memberId, action: `dashboard.${view}`, objectType: 'dashboard', objectId: view });
    return {
      view, period: pr, totals, compare: {
        completed: { cur: totals.completed, prev: prevTotals.completed, delta: delta(totals.completed, prevTotals.completed) },
        overdue: { cur: totals.overdue, prev: prevTotals.overdue },
        accepted_qty: { cur: cur.accepted_qty, prev: prev.accepted_qty, delta: delta(cur.accepted_qty, prev.accepted_qty) },
        defect_rate: { cur: cur.defect_rate, prev: prev.defect_rate, delta: delta(cur.defect_rate, prev.defect_rate) },
        efficiency: { cur: cur.efficiency, prev: prev.efficiency, delta: delta(cur.efficiency, prev.efficiency) },
        on_time_rate: { cur: cur.on_time_rate, prev: prev.on_time_rate, delta: delta(cur.on_time_rate, prev.on_time_rate) },
      },
      groups, trend: tr, workforce: wf, risks: rk, quality_by_stage: qualityByStage,
      chains: { total: chains.length, at_risk: chains.filter((c: any) => c.risk === 'at_risk').length, overdue: chains.filter((c: any) => c.risk === 'overdue').length,
        items: chains.filter((c: any) => c.risk !== 'done').slice(0, 20) },
      formulas: FORMULAS,
    };
  }
}
