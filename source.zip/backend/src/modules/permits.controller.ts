import { Body, Controller, Get, Param, Patch, Post, Query } from '@nestjs/common';
import { getPool, q, q1, tx } from '../db/db';
import { Roles } from '../common/auth.guard';
import { CurrentCtx, Ctx, isAdmin } from '../common/context';
import { AppError, Errors } from '../common/errors';
import { parse, z } from '../common/validate';
import { canManageGroup, companyAdmins, getMember } from '../common/access';
import { audit } from '../common/audit';
import { notify } from '../common/notify';

export const PERMIT_STATUS: Record<string, string> = { pending: 'Chờ cấp phép', approved: 'Đã cấp', rejected: 'Từ chối', auto_issued: 'Cấp tự động (khai báo)', cancelled: 'Đã hủy', closed: 'Đã đóng' };

const SELECT = `
  SELECT p.*, pt.key AS type_key, pt.name AS type_name, pt.icon AS type_icon, pt.tracks, pt.department_id, pt.fields AS type_fields, d.name AS department_name,
         ru.name AS requester_name, hu.name AS holder_name, hu.phone AS holder_phone, hcm.user_id AS holder_user_id,
         EXISTS (SELECT 1 FROM user_avatars a WHERE a.user_id=hcm.user_id) AS holder_has_avatar,
         du.name AS decision_by_name, vu.name AS reviewed_by_name, ou.name AS out_by_name, iu.name AS in_by_name,
         t.code AS task_code, t.title AS task_title, t.status AS task_status, t.due_at AS task_due_at, t.description AS task_description, g.name AS task_group_name
    FROM permits p JOIN permit_types pt ON pt.id=p.type_id LEFT JOIN departments d ON d.id=pt.department_id
    JOIN company_members rcm ON rcm.id=p.requested_by JOIN users ru ON ru.id=rcm.user_id
    JOIN company_members hcm ON hcm.id=p.holder_id JOIN users hu ON hu.id=hcm.user_id
    LEFT JOIN company_members dcm ON dcm.id=p.decision_by LEFT JOIN users du ON du.id=dcm.user_id
    LEFT JOIN company_members vcm ON vcm.id=p.reviewed_by LEFT JOIN users vu ON vu.id=vcm.user_id
    LEFT JOIN company_members ocm ON ocm.id=p.out_by LEFT JOIN users ou ON ou.id=ocm.user_id
    LEFT JOIN company_members icm ON icm.id=p.in_by LEFT JOIN users iu ON iu.id=icm.user_id
    LEFT JOIN tasks t ON t.id=p.task_id LEFT JOIN groups g ON g.id=t.group_id`;

/** Thành viên bộ phận phụ trách loại giấy phép (trưởng bộ phận + thành viên bộ phận); chưa gán bộ phận -> Admin/Owner. */
async function handlers(db: any, companyId: string, departmentId: string | null): Promise<string[]> {
  if (!departmentId) return companyAdmins(companyId, db);
  const rows = await q(`SELECT id FROM company_members WHERE company_id=$1 AND status='active' AND department_id=$2
                        UNION SELECT head_member_id FROM departments WHERE id=$2 AND head_member_id IS NOT NULL`, [companyId, departmentId], db);
  return rows.length ? rows.map((r) => r.id) : companyAdmins(companyId, db);
}

async function isHandler(ctx: Ctx, departmentId: string | null, db: any) {
  if (isAdmin(ctx)) return true;
  if (!departmentId) return false;
  const r = await q1(`SELECT 1 FROM company_members WHERE id=$1 AND department_id=$2 UNION SELECT 1 FROM departments WHERE id=$2 AND head_member_id=$1`, [ctx.memberId, departmentId], db);
  return !!r;
}

@Controller()
export class PermitsController {
  @Get('permit-types')
  async types(@CurrentCtx() ctx: Ctx) {
    return q(`SELECT pt.*, d.name AS department_name FROM permit_types pt LEFT JOIN departments d ON d.id=pt.department_id
               WHERE pt.company_id=$1 ORDER BY pt.active DESC, pt.name`, [ctx.companyId]);
  }

  @Patch('permit-types/:id')
  @Roles('owner', 'admin', 'hr')
  async updType(@Param('id') id: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({ departmentId: z.string().uuid().nullable().optional(), allowDeclaration: z.boolean().optional(), active: z.boolean().optional(), name: z.string().trim().min(3).optional() }), body);
    if (b.departmentId) { const d = await q1(`SELECT 1 FROM departments WHERE id=$1 AND company_id=$2`, [b.departmentId, ctx.companyId]); if (!d) throw Errors.notFound('Bộ phận'); }
    const r = await q1(`UPDATE permit_types SET department_id=CASE WHEN $3::boolean THEN $4::uuid ELSE department_id END, allow_declaration=COALESCE($5, allow_declaration),
                          active=COALESCE($6, active), name=COALESCE($7, name) WHERE id=$1 AND company_id=$2 RETURNING *`,
      [id, ctx.companyId, 'departmentId' in b, b.departmentId ?? null, b.allowDeclaration ?? null, b.active ?? null, b.name ?? null]);
    if (!r) throw Errors.notFound('Loại giấy phép');
    return r;
  }

  @Get('permits')
  async list(@CurrentCtx() ctx: Ctx, @Query() qs: any) {
    const f = parse(z.object({ scope: z.enum(['mine', 'requested', 'handling', 'all']).default('mine'), status: z.string().optional(), review: z.enum(['pending']).optional(), taskId: z.string().uuid().optional() }), qs);
    const params: any[] = [ctx.companyId, ctx.memberId];
    const where = ['p.company_id=$1', '$2::uuid IS NOT NULL'];
    const handling = `(pt.department_id IN (SELECT department_id FROM company_members WHERE id=$2 AND department_id IS NOT NULL UNION SELECT id FROM departments WHERE head_member_id=$2)
                       OR (pt.department_id IS NULL AND ${isAdmin(ctx)}))`;
    if (f.scope === 'mine') where.push('p.holder_id=$2');
    else if (f.scope === 'requested') where.push('p.requested_by=$2');
    else if (f.scope === 'handling') where.push(handling);
    else if (!isAdmin(ctx)) where.push(`(p.holder_id=$2 OR p.requested_by=$2 OR ${handling})`);
    if (f.status) { params.push(f.status.split(',')); where.push(`p.status = ANY($${params.length}::text[])`); }
    if (f.review) where.push(`p.mode='declaration' AND p.review_status IS NULL AND p.status='auto_issued'`);
    if (f.taskId) { params.push(f.taskId); where.push(`p.task_id=$${params.length}`); }
    return q(`${SELECT} WHERE ${where.join(' AND ')} ORDER BY (p.status='pending') DESC, p.valid_from DESC LIMIT 300`, params);
  }

  /** Người giao việc chuẩn bị giấy phép (đính kèm công việc). Khai báo = cấp tự động, bộ phận hậu kiểm sau. */
  @Post('permits')
  async create(@Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({
      typeKey: z.string().optional(), typeId: z.string().uuid().optional(), taskId: z.string().uuid().optional().nullable(),
      holderId: z.string().uuid(), data: z.record(z.string(), z.any()).default({}),
      validFrom: z.coerce.date(), validTo: z.coerce.date(), mode: z.enum(['approval', 'declaration']).default('approval'),
    }), body);
    if (!['owner', 'admin', 'manager', 'hr'].includes(ctx.role)) throw Errors.forbidden('Giấy phép do người giao việc (quản lý) chuẩn bị — nhân viên không tự xin');
    if (b.validTo <= b.validFrom) throw Errors.validation('Thời gian hết hiệu lực phải sau thời gian bắt đầu');
    const pt = await q1(`SELECT * FROM permit_types WHERE company_id=$1 AND active AND (id=$2 OR key=$3)`, [ctx.companyId, b.typeId ?? null, b.typeKey ?? null]);
    if (!pt) throw Errors.notFound('Loại giấy phép');
    if (b.mode === 'declaration' && !pt.allow_declaration) throw new AppError('DECLARATION_NOT_ALLOWED', 'Loại giấy phép này bắt buộc chờ bộ phận phụ trách duyệt', 422);
    for (const fl of pt.fields || []) if (fl.required && !String(b.data[fl.key] ?? '').trim()) throw Errors.validation(`Thiếu thông tin "${fl.label}"`);
    await getMember(ctx, b.holderId);
    if (b.taskId) {
      const t = await q1(`SELECT id, group_id, title FROM tasks WHERE id=$1 AND company_id=$2`, [b.taskId, ctx.companyId]);
      if (!t) throw Errors.notFound('Nhiệm vụ');
      if (!(await canManageGroup(ctx, t.group_id))) throw Errors.forbidden('Chỉ người quản lý nhóm của việc này được lập giấy phép');
      const a = await q1(`SELECT 1 FROM task_assignees WHERE task_id=$1 AND company_member_id=$2 AND active`, [b.taskId, b.holderId]);
      if (!a) throw Errors.validation('Người được cấp phép phải là người thực hiện việc này');
    }
    const id = await tx(async (c) => {
      const seq = await q1(`UPDATE companies SET permit_seq=permit_seq+1 WHERE id=$1 RETURNING permit_seq`, [ctx.companyId], c);
      const status = b.mode === 'declaration' ? 'auto_issued' : 'pending';
      const r = await q1(
        `INSERT INTO permits(company_id, code, type_id, task_id, requested_by, holder_id, data, valid_from, valid_to, mode, status)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11) RETURNING id`,
        [ctx.companyId, `GP-${String(seq.permit_seq).padStart(5, '0')}`, pt.id, b.taskId ?? null, ctx.memberId, b.holderId, JSON.stringify(b.data), b.validFrom, b.validTo, b.mode, status], c);
      await audit(c, ctx, 'permit', r.id, 'permit.created', null, { type: pt.key, mode: b.mode, task: b.taskId });
      const hs = await handlers(c, ctx.companyId, pt.department_id);
      await notify(c, { companyId: ctx.companyId, memberIds: hs, excludeMemberId: ctx.memberId, type: b.mode === 'declaration' ? 'permit.declared' : 'permit.pending',
        title: b.mode === 'declaration' ? `🛂 ${pt.name} cấp tự động (khai báo) — cần hậu kiểm` : `🛂 ${pt.name} chờ bộ phận cấp phép`,
        body: `${ctx.name} lập cho công việc${b.taskId ? '' : ' (không gắn việc)'}`, refType: 'permit', refId: r.id });
      await notify(c, { companyId: ctx.companyId, memberIds: [b.holderId], excludeMemberId: ctx.memberId, type: 'permit.holder',
        title: b.mode === 'declaration' ? `Bạn đã được cấp ${pt.name.toLowerCase()} (có hiệu lực ngay)` : `${pt.name} của bạn đang chờ cấp`, refType: 'permit', refId: r.id });
      return r.id;
    });
    return this.detail(id, ctx);
  }

  @Get('permits/:id')
  async detail(@Param('id') id: string, @CurrentCtx() ctx: Ctx) {
    const p = await q1(`${SELECT} WHERE p.id=$1 AND p.company_id=$2`, [id, ctx.companyId]);
    if (!p) throw Errors.notFound('Giấy phép');
    const handler = await isHandler(ctx, p.department_id, getPool());
    if (p.holder_id !== ctx.memberId && p.requested_by !== ctx.memberId && !handler) throw Errors.notFound('Giấy phép');
    const now = new Date();
    const valid = ['approved', 'auto_issued'].includes(p.status) && now >= new Date(p.valid_from) && now <= new Date(p.valid_to);
    return {
      ...p, status_label: PERMIT_STATUS[p.status], is_valid_now: valid, expired: new Date(p.valid_to) < now,
      permissions: {
        can_decide: handler && p.status === 'pending',
        can_track: handler && ['approved', 'auto_issued'].includes(p.status) && p.tracks !== 'none',
        can_review: handler && p.status !== 'pending' && p.status !== 'cancelled' && !p.review_status,
        can_cancel: p.requested_by === ctx.memberId && ['pending', 'approved', 'auto_issued'].includes(p.status) && !p.out_at,
        is_handler: handler,
      },
    };
  }

  @Post('permits/:id/decide')
  async decide(@Param('id') id: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({ decision: z.enum(['approve', 'reject']), note: z.string().trim().optional() }), body);
    const p = await this.detail(id, ctx);
    if (!p.permissions.can_decide) throw Errors.forbidden('Chỉ bộ phận phụ trách được cấp phép');
    if (b.decision === 'reject' && (!b.note || b.note.length < 5)) throw Errors.reasonRequired('Từ chối cấp phép phải nêu lý do');
    const st = b.decision === 'approve' ? 'approved' : 'rejected';
    await tx(async (c) => {
      await q(`UPDATE permits SET status=$2, decision_by=$3, decision_at=now(), decision_note=$4 WHERE id=$1`, [id, st, ctx.memberId, b.note ?? null], c);
      await audit(c, ctx, 'permit', id, 'permit.' + st, null, null, b.note ?? null);
      await notify(c, { companyId: ctx.companyId, memberIds: [p.requested_by, p.holder_id], excludeMemberId: ctx.memberId, type: 'permit.' + st,
        title: st === 'approved' ? `✅ ${p.type_name} ${p.code} đã được cấp` : `${p.type_name} ${p.code} bị từ chối`, body: b.note, refType: 'permit', refId: id });
    });
    return this.detail(id, ctx);
  }

  /** Bộ phận ghi nhận ra/vào cổng hoặc giao/nhận lại thiết bị. */
  @Post('permits/:id/track')
  async track(@Param('id') id: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({ event: z.enum(['out', 'in']), note: z.string().trim().optional() }), body);
    const p = await this.detail(id, ctx);
    if (!p.permissions.can_track) throw Errors.forbidden('Chỉ bộ phận phụ trách ghi nhận');
    if (b.event === 'out' && p.out_at) throw Errors.invalidState('Đã ghi nhận lượt ra/giao thiết bị');
    if (b.event === 'in' && !p.out_at) throw Errors.invalidState('Chưa ghi nhận lượt ra/giao thiết bị');
    if (b.event === 'in' && p.in_at) throw Errors.invalidState('Đã ghi nhận lượt vào/trả thiết bị');
    const late = new Date() > new Date(p.valid_to);
    if (b.event === 'out' && !p.is_valid_now) throw new AppError('PERMIT_NOT_VALID', 'Giấy phép chưa đến giờ hoặc đã hết hiệu lực — không cho ra/giao thiết bị', 409);
    await tx(async (c) => {
      if (b.event === 'out') await q(`UPDATE permits SET out_at=now(), out_by=$2 WHERE id=$1`, [id, ctx.memberId], c);
      else await q(`UPDATE permits SET in_at=now(), in_by=$2, status='closed' WHERE id=$1`, [id, ctx.memberId], c);
      await audit(c, ctx, 'permit', id, 'permit.' + b.event, null, { late }, b.note ?? null);
      if (late && b.event === 'in') {
        await notify(c, { companyId: ctx.companyId, memberIds: [p.requested_by], type: 'permit.late', title: `${p.code}: trả/quay lại muộn so với giấy phép`, refType: 'permit', refId: id });
      }
    });
    return this.detail(id, ctx);
  }

  /** Hậu kiểm: quy trình đúng hay sai. Sai -> người giao việc (người lập giấy) chịu trách nhiệm. */
  @Post('permits/:id/review')
  async review(@Param('id') id: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({ result: z.enum(['ok', 'violation']), note: z.string().trim().optional() }), body);
    const p = await this.detail(id, ctx);
    if (!p.permissions.can_review) throw Errors.forbidden('Chỉ bộ phận phụ trách hậu kiểm');
    if (b.result === 'violation' && (!b.note || b.note.length < 10)) throw Errors.reasonRequired('Ghi rõ sai phạm trong quy trình (≥10 ký tự)');
    await tx(async (c) => {
      await q(`UPDATE permits SET review_status=$2, reviewed_by=$3, reviewed_at=now(), review_note=$4 WHERE id=$1`, [id, b.result, ctx.memberId, b.note ?? null], c);
      await audit(c, ctx, 'permit', id, 'permit.review_' + b.result, null, { responsible: p.requested_by }, b.note ?? null);
      if (b.result === 'violation') {
        const sup = await q1(`SELECT supervisor_member_id FROM company_members WHERE id=$1`, [p.requested_by], c);
        await notify(c, { companyId: ctx.companyId, memberIds: [p.requested_by], type: 'permit.violation',
          title: `⚠ Giấy phép ${p.code}: quy trình sai — bạn là người chịu trách nhiệm`, body: b.note, refType: 'permit', refId: id });
        await notify(c, { companyId: ctx.companyId, memberIds: [sup?.supervisor_member_id], excludeMemberId: ctx.memberId, type: 'permit.violation_notice',
          title: `Vi phạm quy trình giấy phép ${p.code} của ${p.requester_name}`, body: b.note, refType: 'permit', refId: id });
      }
    });
    return this.detail(id, ctx);
  }

  @Post('permits/:id/cancel')
  async cancel(@Param('id') id: string, @CurrentCtx() ctx: Ctx) {
    const p = await this.detail(id, ctx);
    if (!p.permissions.can_cancel) throw Errors.forbidden();
    await q(`UPDATE permits SET status='cancelled' WHERE id=$1`, [id]);
    await audit(getPool(), ctx, 'permit', id, 'permit.cancelled');
    return this.detail(id, ctx);
  }
}
