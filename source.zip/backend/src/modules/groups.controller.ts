import { Query, Body, Controller, Delete, Get, Param, Patch, Post } from '@nestjs/common';
import { getPool, q, q1, tx } from '../db/db';
import { Roles } from '../common/auth.guard';
import { CurrentCtx, Ctx, isAdmin } from '../common/context';
import { AppError, Errors } from '../common/errors';
import { maskContacts } from '../common/privacy';
import { parse, z } from '../common/validate';
import { canManageGroup, getCompany, getGroup, getMember } from '../common/access';
import { audit } from '../common/audit';
import { notify } from '../common/notify';

@Controller('groups')
export class GroupsController {
  @Get()
  async list(@CurrentCtx() ctx: Ctx, @Query('scope') scope?: string) {
    return q(
      `SELECT g.id, g.name, g.description, g.manager_member_id, u.name AS manager_name, g.created_at,
              (SELECT count(*) FROM group_members gm WHERE gm.group_id=g.id)::int AS member_count,
              (SELECT count(*) FROM tasks t WHERE t.group_id=g.id AND t.status NOT IN ('completed','cancelled'))::int AS open_tasks,
              (SELECT count(*) FROM tasks t WHERE t.group_id=g.id AND t.status NOT IN ('completed','cancelled') AND t.due_at < now())::int AS overdue_tasks,
              (g.manager_member_id=$2) AS is_manager
         FROM groups g JOIN company_members cm ON cm.id=g.manager_member_id JOIN users u ON u.id=cm.user_id
        WHERE g.company_id=$1 AND g.deleted_at IS NULL
          AND ($3::boolean OR g.manager_member_id=$2 OR EXISTS (SELECT 1 FROM group_members gm WHERE gm.group_id=g.id AND gm.company_member_id=$2))
        ORDER BY g.name`, [ctx.companyId, ctx.memberId, isAdmin(ctx) || scope === 'all']);
  }

  @Post()
  @Roles('owner', 'admin', 'manager')
  async create(@Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({
      name: z.string().trim().min(2), description: z.string().optional(),
      managerMemberId: z.string().uuid().optional(), memberIds: z.array(z.string().uuid()).default([]),
    }), body);
    let managerId = ctx.memberId;
    if (b.managerMemberId && b.managerMemberId !== ctx.memberId) {
      if (!isAdmin(ctx)) throw Errors.forbidden('Chỉ Admin/Owner được chỉ định quản lý khác');
      managerId = b.managerMemberId;
    }
    const mgr = await getMember(ctx, managerId);
    if (!['manager', 'admin', 'owner'].includes(mgr.role)) throw Errors.validation('Quản lý chính của nhóm phải có vai trò Manager/Admin/Owner');
    const g = await tx(async (c) => {
      const g = await q1(`INSERT INTO groups(company_id,name,description,manager_member_id,created_by) VALUES ($1,$2,$3,$4,$5) RETURNING *`,
        [ctx.companyId, b.name, b.description ?? null, managerId, ctx.memberId], c);
      await audit(c, ctx, 'group', g.id, 'group.created', null, { name: b.name, manager: managerId });
      return g;
    });
    if (b.memberIds.length) await this.addMembers(g.id, { memberIds: b.memberIds }, ctx);
    return this.detail(g.id, ctx);
  }

  @Get(':id')
  async detail(@Param('id') id: string, @CurrentCtx() ctx: Ctx) {
    const g = await getGroup(ctx, id);
    const members = await q(
      `SELECT x.member_id, u.name, u.phone, cm.user_id, cm.role, cm.title, x.joined_at,
              EXISTS (SELECT 1 FROM user_avatars a WHERE a.user_id=cm.user_id) AS has_avatar,
              (SELECT count(*) FROM task_assignees ta JOIN tasks t ON t.id=ta.task_id WHERE ta.company_member_id=x.member_id AND ta.active AND ta.assignment_type='owner'
                 AND t.status IN ('not_started','in_progress','revision_requested','waiting'))::int AS doing,
              (SELECT count(*) FROM task_assignees ta JOIN tasks t ON t.id=ta.task_id WHERE ta.company_member_id=x.member_id AND ta.active AND ta.assignment_type='owner'
                 AND t.status='pending_review')::int AS reviewing,
              (SELECT count(*) FROM task_assignees ta JOIN tasks t ON t.id=ta.task_id WHERE ta.company_member_id=x.member_id AND ta.active AND ta.assignment_type='owner'
                 AND t.status='completed' AND t.completed_at >= date_trunc('month', now()))::int AS done_month,
              (SELECT count(*) FROM task_assignees ta JOIN tasks t ON t.id=ta.task_id WHERE ta.company_member_id=x.member_id AND ta.active AND ta.assignment_type='owner'
                 AND t.status IN ('not_started','in_progress','revision_requested') AND t.due_at < now())::int AS overdue
         FROM (SELECT company_member_id AS member_id, joined_at FROM group_members WHERE group_id=$1
               UNION SELECT manager_member_id, created_at FROM groups WHERE id=$1) x
         JOIN company_members cm ON cm.id=x.member_id JOIN users u ON u.id=cm.user_id
        ORDER BY (x.member_id=(SELECT manager_member_id FROM groups WHERE id=$1)) DESC, u.name`, [id]);
    const isMember = members.some((m) => m.member_id === ctx.memberId);
    if (!isAdmin(ctx) && g.manager_member_id !== ctx.memberId && !isMember) throw Errors.notFound('Nhóm');
    const mgr = await getMember(ctx, g.manager_member_id);
    await maskContacts(members, ctx, { fields: { phone: 'phone' } });
    return { ...g, manager_name: mgr.name, members, can_manage: await canManageGroup(ctx, id) };
  }

  @Patch(':id')
  async update(@Param('id') id: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({ name: z.string().trim().min(2).optional(), description: z.string().optional().nullable(), managerMemberId: z.string().uuid().optional(),
      leaderMemberId: z.string().uuid().optional().nullable() }), body);
    const g = await getGroup(ctx, id);
    if (!(await canManageGroup(ctx, id))) throw Errors.forbidden();
    if (b.managerMemberId && b.managerMemberId !== g.manager_member_id) {
      if (!isAdmin(ctx)) throw Errors.forbidden('Chỉ Admin/Owner được đổi quản lý chính');
      const m = await getMember(ctx, b.managerMemberId);
      if (!['manager', 'admin', 'owner'].includes(m.role)) throw Errors.validation('Quản lý chính phải có vai trò Manager/Admin/Owner');
    }
    if (b.leaderMemberId) {
      // Trưởng nhóm phải là thành viên nhóm; phụ cấp trưởng nhóm là chính sách nhân sự riêng, không gắn vào điểm chuyên môn
      const inG = await q1(`SELECT 1 FROM group_members WHERE group_id=$1 AND company_member_id=$2`, [id, b.leaderMemberId]);
      if (!inG && b.leaderMemberId !== g.manager_member_id) throw Errors.validation('Trưởng nhóm phải là thành viên của nhóm');
    }
    await tx(async (c) => {
      if ('leaderMemberId' in b) await q(`UPDATE groups SET leader_member_id=$2 WHERE id=$1`, [id, b.leaderMemberId ?? null], c);
      await q(`UPDATE groups SET name=COALESCE($2,name), description=CASE WHEN $3::boolean THEN $4 ELSE description END,
                 manager_member_id=COALESCE($5,manager_member_id) WHERE id=$1`,
        [id, b.name ?? null, 'description' in b, b.description ?? null, b.managerMemberId ?? null], c);
      await audit(c, ctx, 'group', id, 'group.updated', { name: g.name, manager: g.manager_member_id }, b);
    });
    return this.detail(id, ctx);
  }

  @Delete(':id')
  async remove(@Param('id') id: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    await getGroup(ctx, id);
    if (!(await canManageGroup(ctx, id))) throw Errors.forbidden();
    const open = await q1(`SELECT count(*)::int AS n FROM tasks WHERE group_id=$1 AND status NOT IN ('completed','cancelled')`, [id]);
    if (open.n > 0) throw Errors.invalidState(`Nhóm còn ${open.n} nhiệm vụ đang mở; hãy hoàn thành/hủy/giao lại trước khi xóa`);
    await q(`UPDATE groups SET deleted_at=now() WHERE id=$1`, [id]);
    await audit(getPool(), ctx, 'group', id, 'group.deleted', null, null, body?.reason ?? null);
    return { ok: true };
  }

  @Post(':id/members')
  async addMembers(@Param('id') id: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({ memberIds: z.array(z.string().uuid()).min(1) }), body);
    const g = await getGroup(ctx, id);
    if (!(await canManageGroup(ctx, id))) throw Errors.forbidden('Chỉ quản lý nhóm hoặc Admin được thêm thành viên');
    const company = await getCompany(ctx.companyId);
    const added: string[] = [];
    await tx(async (c) => {
      for (const mid of b.memberIds) {
        const m = await getMember(ctx, mid, c);
        if (m.status !== 'active') throw Errors.validation(`${m.name} không còn hoạt động`);
        if (!company.settings.policies.multiGroup && m.role === 'employee') {
          const other = await q1(`SELECT g.name FROM group_members gm JOIN groups g ON g.id=gm.group_id
                                   WHERE gm.company_member_id=$1 AND g.id<>$2 AND g.deleted_at IS NULL LIMIT 1`, [mid, id], c);
          if (other) throw new AppError('MULTI_GROUP_DISABLED', `${m.name} đã thuộc nhóm "${other.name}"; công ty không cho phép tham gia nhiều nhóm`, 409);
        }
        const r = await q(`INSERT INTO group_members(group_id, company_member_id) VALUES ($1,$2) ON CONFLICT DO NOTHING RETURNING id`, [id, mid], c);
        if (r.length) {
          added.push(mid);
          await audit(c, ctx, 'group', id, 'group.member_added', null, { member: mid });
        }
      }
      await notify(c, { companyId: ctx.companyId, memberIds: added, type: 'group.added', title: `Bạn được thêm vào nhóm ${g.name}`, refType: 'group', refId: id });
    });
    return this.detail(id, ctx);
  }

  @Delete(':id/members/:memberId')
  async removeMember(@Param('id') id: string, @Param('memberId') memberId: string, @CurrentCtx() ctx: Ctx) {
    const g = await getGroup(ctx, id);
    if (!(await canManageGroup(ctx, id))) throw Errors.forbidden();
    if (memberId === g.manager_member_id) throw Errors.invalidState('Không thể xóa quản lý chính khỏi nhóm; hãy đổi quản lý trước');
    await tx(async (c) => {
      await q(`DELETE FROM group_members WHERE group_id=$1 AND company_member_id=$2`, [id, memberId], c);
      await audit(c, ctx, 'group', id, 'group.member_removed', { member: memberId }, null);
    });
    return this.detail(id, ctx);
  }
}
