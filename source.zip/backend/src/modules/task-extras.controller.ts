import { Body, Controller, Get, Param, Patch, Post, Query } from '@nestjs/common';
import { getPool, q, q1, tx } from '../db/db';
import { CurrentCtx, Ctx } from '../common/context';
import { Errors } from '../common/errors';
import { parse, z } from '../common/validate';
import { audit } from '../common/audit';
import { notify } from '../common/notify';
import { TasksController } from './tasks.controller';
import { MR_CATEGORY } from './member-reports.controller';

const mins = (a: any, b: any) => Math.max(0, Math.round(((b ? new Date(b).getTime() : Date.now()) - new Date(a).getTime()) / 60000));
const PAUSE: Record<string, string> = { waiting: 'Chờ việc / chờ vật tư', objective_pause: 'Hoãn khách quan', subjective_pause: 'Hoãn chủ quan', changeover: 'Chuyển đổi', preparation: 'Chuẩn bị', handover: 'Bàn giao', unknown: 'Chưa xác định', rest_internal: 'Nghỉ' };
const ACTION: Record<string, string> = {
  'task.created': 'Tạo nhiệm vụ', 'task.status': 'Đổi trạng thái', 'task.submitted': 'Gửi bàn giao chờ nghiệm thu', 'task.approved': 'Nghiệm thu đạt', 'task.revision_requested': 'Yêu cầu chỉnh sửa',
  'task.deadline_changed': 'Đổi deadline', 'task.updated': 'Điều chỉnh nhiệm vụ', 'task.cancelled': 'Hủy nhiệm vụ', 'session.switched': 'Chuyển sang việc khác',
  'order.review': 'Xem xét đơn hàng', 'order.approve': 'Duyệt đơn hàng', 'order.reject': 'Trả lại đơn hàng', 'order.resubmit': 'Gửi lại đơn hàng',
  'task.paused': 'Tạm dừng / hoãn', 'task.early_start': 'Cho phép bắt đầu sớm', 'task.auto_started': 'Tự động bắt đầu', 'task.pinned': 'Ghim việc gấp', 'task.unpinned': 'Gỡ ghim',
  'task.priority_changed': 'Đổi ưu tiên', 'task.plan_date': 'Đổi ngày làm', 'task.scope_changed': 'Đổi phạm vi', 'task.subitem_added': 'Thêm yêu cầu thành phần', 'task.subitem_updated': 'Cập nhật yêu cầu thành phần',
  'task.marked_unexpected': 'Đánh dấu việc phát sinh', 'task.approval_approve': 'Duyệt giao việc', 'task.approval_reject': 'Không duyệt giao việc',
  'handover.accepted': 'Tiếp nhận bàn giao', 'handover.rejected': 'Trả lại bàn giao', 'handover.submitted': 'Gửi bàn giao công đoạn', 'handover.decided': 'Quyết định bàn giao',
  'production.recorded': 'Ghi nhận sản lượng', 'production.adjusted': 'Điều chỉnh sản lượng',
  'equipment.declared': 'Khai báo thiết bị', 'equipment.daily_check': 'Kiểm kê thiết bị cuối ngày', 'equipment.completion_check': 'Kiểm kê thiết bị khi hoàn thành',
  'file.uploaded': 'Tải tệp lên', 'permit.created': 'Lập giấy phép',
};
const STATUS: Record<string, string> = { not_started: 'chưa bắt đầu', in_progress: 'đang thực hiện', pending_review: 'chờ nghiệm thu', completed: 'hoàn thành', revision_requested: 'yêu cầu chỉnh sửa',
  cancelled: 'hủy', waiting: 'chờ giai đoạn trước', pending_approval: 'chờ duyệt giao', awaiting_handover: 'chờ người nhận xác nhận', pending_exception_review: 'treo chờ duyệt giải trình' };

@Controller()
export class TaskExtrasController {
  /**
   * v11: Dòng thời gian chi tiết của nhiệm vụ / đơn hàng — từ lúc bắt đầu tới hiện tại:
   * sự kiện, phiên làm việc, đoạn bị vướng (chờ/hoãn, trở ngại, chờ bàn giao, hỗ trợ) kèm thời lượng và cách giải quyết,
   * và báo cáo phản ánh được kết luận có ảnh hưởng tiến độ/chất lượng.
   */
  @Get('tasks/:id/timeline')
  async timeline(@Param('id') id: string, @CurrentCtx() ctx: Ctx) {
    const t = await new TasksController().loadTask(ctx, id);
    const kids = await q(`SELECT id, code, title, stage_no, status, started_at, completed_at, created_at, group_id, (SELECT name FROM groups WHERE id=tasks.group_id) AS group_name
                            FROM tasks WHERE parent_id=$1 AND status<>'cancelled' ORDER BY stage_no NULLS LAST, created_at`, [id]);
    const ids = [id, ...kids.map((k: any) => k.id)];
    const label = (tid: string) => (tid === id ? '' : (() => { const k = kids.find((x: any) => x.id === tid); return k ? `${k.code} ${k.title}` : ''; })());
    const [aud, sess, pauses, reps, hos, sups, cases, subs] = await Promise.all([
      q(`SELECT a.entity_id, a.action, a.old_value, a.new_value, a.reason, a.created_at, u.name AS actor_name FROM audit_logs a LEFT JOIN company_members cm ON cm.id=a.actor_id LEFT JOIN users u ON u.id=cm.user_id
          WHERE a.company_id=$1 AND a.entity_type='task' AND a.entity_id = ANY($2::uuid[]) ORDER BY a.created_at`, [ctx.companyId, ids]),
      q(`SELECT s.task_id, s.started_at, s.ended_at, s.end_reason, u.name AS member_name FROM work_sessions s JOIN company_members cm ON cm.id=s.member_id JOIN users u ON u.id=cm.user_id
          WHERE s.task_id = ANY($1::uuid[]) ORDER BY s.started_at`, [ids]),
      q(`SELECT w.task_id, w.category, w.reason, w.related_party, w.started_at, w.ended_at, w.confirmed_at, u.name AS member_name, cu.name AS confirmed_by_name
           FROM work_time_records w JOIN company_members cm ON cm.id=w.member_id JOIN users u ON u.id=cm.user_id LEFT JOIN company_members ccm ON ccm.id=w.confirmed_by LEFT JOIN users cu ON cu.id=ccm.user_id
          WHERE w.task_id = ANY($1::uuid[]) AND w.category IN ('waiting','objective_pause','subjective_pause','unknown','changeover') ORDER BY w.started_at`, [ids]),
      q(`SELECT w.id, w.code, w.description, w.status, w.created_at, w.closed_at, w.affected_task_id, u.name AS reporter_name, rt.code AS resolution_code, rt.title AS resolution_title,
                (SELECT string_agg(ru.comment, ' → ' ORDER BY ru.created_at) FROM report_updates ru WHERE ru.report_id=w.id AND ru.comment IS NOT NULL) AS steps
           FROM workplace_reports w JOIN company_members cm ON cm.id=w.reporter_id JOIN users u ON u.id=cm.user_id LEFT JOIN tasks rt ON rt.id=w.resolution_task_id
          WHERE w.affected_task_id = ANY($1::uuid[]) ORDER BY w.created_at`, [ids]),
      q(`SELECT h.to_task_id, h.from_task_id, h.status, h.submitted_at, h.accepted_at, h.content, h.rejection_reason FROM handover_contexts h WHERE h.to_task_id = ANY($1::uuid[]) ORDER BY h.submitted_at`, [ids]),
      q(`SELECT r.id, r.code, r.title, r.task_id, r.status, r.created_at, r.closed_at, r.broadcast, u.name AS requester_name,
                (SELECT string_agg(hu.name || COALESCE(' (' || x.minutes || 'p)', ''), ', ') FROM support_responses x JOIN company_members hcm ON hcm.id=x.helper_id JOIN users hu ON hu.id=hcm.user_id
                  WHERE x.request_id=r.id AND x.status IN ('accepted','done','confirmed')) AS helpers
           FROM support_requests r JOIN company_members cm ON cm.id=r.requester_id JOIN users u ON u.id=cm.user_id WHERE r.task_id = ANY($1::uuid[]) ORDER BY r.created_at`, [ids]),
      q(`SELECT c.*, (SELECT count(*)::int FROM member_reports m WHERE m.case_id=c.id) AS reporter_count FROM member_report_cases c
          WHERE c.task_id = ANY($1::uuid[]) AND c.status='resolved' AND (c.affects_progress OR c.affects_quality) ORDER BY c.created_at`, [ids]),
      q(`SELECT s.task_id, s.created_at, s.output_description, s.supporter_ids FROM task_submissions s WHERE s.task_id = ANY($1::uuid[]) ORDER BY s.created_at`, [ids]),
    ]);
    const events: any[] = [];
    for (const a of aud) {
      const st = a.new_value?.status ? ` → ${STATUS[a.new_value.status] || a.new_value.status}` : '';
      events.push({ at: a.created_at, kind: 'event', title: `${ACTION[a.action] || ACTION[a.action.replace(/_[a-z]+$/, '')] || a.action.replace(/[._]/g, ' ')}${st}`, who: a.actor_name || 'Hệ thống', detail: a.reason || null, task: label(a.entity_id) });
    }
    for (const s of sess) events.push({ at: s.started_at, kind: 'session', title: 'Phiên làm việc', who: s.member_name, minutes: mins(s.started_at, s.ended_at), until: s.ended_at, task: label(s.task_id), open: !s.ended_at });
    const blockers: any[] = [];
    for (const p of pauses) {
      const b = { at: p.started_at, until: p.ended_at, kind: 'blocker', source: 'pause', title: PAUSE[p.category] || p.category, who: p.member_name, minutes: mins(p.started_at, p.ended_at),
        cause: p.reason, resolution: p.ended_at ? (p.confirmed_by_name ? `Đã tiếp tục · ${p.confirmed_by_name} xác nhận` : 'Đã tiếp tục làm việc') : 'Đang vướng', related: p.related_party, task: label(p.task_id), open: !p.ended_at };
      blockers.push(b); events.push(b);
    }
    for (const r of reps) {
      const b = { at: r.created_at, until: r.closed_at, kind: 'blocker', source: 'report', title: `Trở ngại ${r.code}`, who: r.reporter_name, minutes: mins(r.created_at, r.closed_at), cause: r.description,
        resolution: r.closed_at ? (r.steps || (r.resolution_title ? `Giao việc xử lý ${r.resolution_code} - ${r.resolution_title}` : 'Đã đóng')) : `Đang xử lý${r.steps ? ': ' + r.steps : ''}`, task: label(r.affected_task_id), open: !r.closed_at, ref: { type: 'report', id: r.id } };
      blockers.push(b); events.push(b);
    }
    for (const h of hos) {
      const b = { at: h.submitted_at, until: h.accepted_at, kind: 'blocker', source: 'handover', title: 'Chờ tiếp nhận bàn giao công đoạn trước', minutes: mins(h.submitted_at, h.accepted_at), cause: h.content,
        resolution: h.status === 'accepted' ? 'Đã tiếp nhận bàn giao' : h.status === 'rejected' ? `Bị trả lại: ${h.rejection_reason || ''}` : 'Đang chờ tiếp nhận', task: label(h.to_task_id), open: h.status === 'submitted' };
      blockers.push(b); events.push(b);
    }
    for (const s of sups) events.push({ at: s.created_at, until: s.closed_at, kind: 'support', title: `${s.broadcast ? 'Kêu gọi hỗ trợ' : 'Yêu cầu hỗ trợ'} ${s.code}: ${s.title}`, who: s.requester_name, minutes: mins(s.created_at, s.closed_at), detail: s.helpers ? `Người hỗ trợ: ${s.helpers}` : 'Chưa có người hỗ trợ', task: label(s.task_id), ref: { type: 'support', id: s.id } });
    for (const c of cases) events.push({ at: c.created_at, until: c.resolved_at, kind: 'report_case', title: `Phản ánh ${c.code}: ${MR_CATEGORY[c.category]} (${c.reporter_count} người báo)`, minutes: mins(c.created_at, c.resolved_at),
      detail: `Kết luận: ${c.conclusion}${c.action_taken ? ` · Xử lý: ${c.action_taken}` : ''}`, impact: [c.affects_progress && 'tiến độ', c.affects_quality && 'chất lượng'].filter(Boolean).join(', '), task: label(c.task_id) });
    for (const s of subs) if ((s.supporter_ids || []).length) {
      const names = (await q(`SELECT u.name FROM company_members cm JOIN users u ON u.id=cm.user_id WHERE cm.id = ANY($1::uuid[])`, [s.supporter_ids])).map((x: any) => x.name);
      events.push({ at: s.created_at, kind: 'event', title: 'Người hỗ trợ ghi trong bàn giao', detail: names.join(', '), task: label(s.task_id) });
    }
    events.sort((a, b) => +new Date(a.at) - +new Date(b.at));
    const start = t.started_at || t.created_at; const end = t.completed_at || null;
    const blocked = blockers.reduce((a, b) => a + b.minutes, 0);
    const stages = kids.map((k: any) => ({ id: k.id, code: k.code, title: k.title, stage_no: k.stage_no, group_name: k.group_name, status: k.status, started_at: k.started_at, completed_at: k.completed_at,
      minutes: k.started_at ? mins(k.started_at, k.completed_at) : 0, blocked_minutes: blockers.filter((b) => b.task === `${k.code} ${k.title}`).reduce((a, b) => a + b.minutes, 0) }));
    return {
      task: { id: t.id, code: t.code, title: t.title, status: t.status, is_chain: t.is_chain, started_at: t.started_at, completed_at: t.completed_at, due_at: t.due_at },
      summary: { elapsed_minutes: mins(start, end), blocked_minutes: blocked, blocker_count: blockers.length, open_blockers: blockers.filter((b) => b.open).length,
        longest: [...blockers].sort((a, b) => b.minutes - a.minutes).slice(0, 3).map((b) => ({ title: b.title, minutes: b.minutes, task: b.task, resolution: b.resolution })) },
      stages, events,
    };
  }

  // ---------- Bình luận ----------
  /** Toàn bộ lịch sử bình luận (màn chi tiết chỉ hiện 3 tin mới nhất + "Xem thêm"). Đánh dấu đã đọc. */
  @Get('tasks/:id/comments')
  async comments(@Param('id') id: string, @CurrentCtx() ctx: Ctx, @Query('limit') limit?: string) {
    await new TasksController().loadTask(ctx, id);
    const n = Math.min(Number(limit) || 500, 500);
    const rows = await q(`SELECT c.id, c.content, c.created_at, c.member_id, c.reply_to_id, u.name, cm.user_id, rc.content AS reply_content, ru.name AS reply_name
                            FROM task_comments c JOIN company_members cm ON cm.id=c.member_id JOIN users u ON u.id=cm.user_id
                            LEFT JOIN task_comments rc ON rc.id=c.reply_to_id LEFT JOIN company_members rcm ON rcm.id=rc.member_id LEFT JOIN users ru ON ru.id=rcm.user_id
                           WHERE c.task_id=$1 ORDER BY c.created_at DESC LIMIT $2`, [id, n]);
    const total = (await q1(`SELECT count(*)::int AS n FROM task_comments WHERE task_id=$1`, [id])).n;
    await q(`INSERT INTO task_comment_reads(task_id, member_id, last_read_at) VALUES ($1,$2,now()) ON CONFLICT (task_id, member_id) DO UPDATE SET last_read_at=now()`, [id, ctx.memberId]);
    return { items: rows.reverse(), total };
  }

  // ---------- Thiết bị ----------
  private async canEditEquipment(ctx: Ctx, t: any) {
    const a = await q1(`SELECT 1 FROM task_assignees WHERE task_id=$1 AND company_member_id=$2 AND active`, [t.id, ctx.memberId]);
    return !!a || t.created_by === ctx.memberId;
  }
  @Get('tasks/:id/equipment')
  async equipment(@Param('id') id: string, @CurrentCtx() ctx: Ctx) {
    const t = await new TasksController().loadTask(ctx, id);
    const items = await q(`SELECT e.*, p.code AS permit_code, p.status AS permit_status, du.name AS declared_by_name,
                                  (SELECT json_agg(json_build_object('kind', k.kind, 'location', k.location, 'at', k.checked_at, 'by', ku.name) ORDER BY k.checked_at DESC)
                                     FROM task_equipment_checks k JOIN company_members kcm ON kcm.id=k.checked_by JOIN users ku ON ku.id=kcm.user_id WHERE k.equipment_id=e.id) AS checks
                             FROM task_equipment e LEFT JOIN permits p ON p.id=e.permit_id JOIN company_members dcm ON dcm.id=e.declared_by JOIN users du ON du.id=dcm.user_id
                            WHERE e.task_id=$1 ORDER BY e.created_at`, [id]);
    const permits = await q(`SELECT p.id, p.code, p.status, pt.name AS type_name FROM permits p JOIN permit_types pt ON pt.id=p.type_id WHERE p.task_id=$1 AND p.status IN ('approved','auto_issued')`, [id]);
    const today = new Date(); today.setHours(0, 0, 0, 0);
    return { items, permits, can_edit: await this.canEditEquipment(ctx, t) && !['completed', 'cancelled'].includes(t.status),
      missing_current: items.filter((e: any) => !e.current_location).length,
      checked_today: items.length > 0 && items.every((e: any) => (e.checks || []).some((k: any) => ['daily', 'completion'].includes(k.kind) && new Date(k.at) >= today)) };
  }
  /** Người nhận nhiệm vụ khai báo thiết bị: vị trí ban đầu (sửa/bổ sung được), mang ra khỏi khu vực thì phải có giấy phép. */
  @Post('tasks/:id/equipment')
  async addEquipment(@Param('id') id: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({ name: z.string().trim().min(2), code: z.string().trim().max(60).optional(), quantity: z.number().int().min(1).max(10000).default(1),
      originLocation: z.string().trim().max(200).optional(), movedOut: z.boolean().default(false), permitId: z.string().uuid().optional().nullable() }), body);
    const t = await new TasksController().loadTask(ctx, id);
    if (!(await this.canEditEquipment(ctx, t))) throw Errors.forbidden('Chỉ người nhận nhiệm vụ (hoặc người giao) khai báo thiết bị');
    await this.assertPermit(id, b.movedOut, b.permitId);
    const r = await q1(`INSERT INTO task_equipment(company_id, task_id, name, code, quantity, origin_location, moved_out, permit_id, declared_by) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING id`,
      [ctx.companyId, id, b.name, b.code ?? null, b.quantity, b.originLocation ?? null, b.movedOut, b.permitId ?? null, ctx.memberId]);
    await audit(getPool(), ctx, 'task', id, 'equipment.declared', null, { equipment: r.id, name: b.name, origin: b.originLocation, moved_out: b.movedOut });
    return this.equipment(id, ctx);
  }
  @Patch('tasks/:id/equipment/:eid')
  async editEquipment(@Param('id') id: string, @Param('eid') eid: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({ name: z.string().trim().min(2).optional(), code: z.string().trim().max(60).optional().nullable(), quantity: z.number().int().min(1).max(10000).optional(),
      originLocation: z.string().trim().max(200).optional().nullable(), currentLocation: z.string().trim().max(200).optional(), movedOut: z.boolean().optional(), permitId: z.string().uuid().optional().nullable() }), body);
    const t = await new TasksController().loadTask(ctx, id);
    if (!(await this.canEditEquipment(ctx, t))) throw Errors.forbidden('Chỉ người nhận nhiệm vụ (hoặc người giao) sửa khai báo thiết bị');
    const e = await q1(`SELECT * FROM task_equipment WHERE id=$1 AND task_id=$2`, [eid, id]);
    if (!e) throw Errors.notFound('Thiết bị');
    const movedOut = b.movedOut ?? e.moved_out; const permitId = b.permitId !== undefined ? b.permitId : e.permit_id;
    await this.assertPermit(id, movedOut, permitId);
    await tx(async (c) => {
      await q(`UPDATE task_equipment SET name=COALESCE($2,name), code=CASE WHEN $3::boolean THEN $4 ELSE code END, quantity=COALESCE($5,quantity),
                 origin_location=CASE WHEN $6::boolean THEN $7 ELSE origin_location END, current_location=COALESCE($8,current_location), moved_out=$9, permit_id=$10, updated_by=$11, updated_at=now() WHERE id=$1`,
        [eid, b.name ?? null, 'code' in b, b.code ?? null, b.quantity ?? null, 'originLocation' in b, b.originLocation ?? null, b.currentLocation ?? null, movedOut, permitId ?? null, ctx.memberId], c);
      if (b.currentLocation) await q(`INSERT INTO task_equipment_checks(equipment_id, kind, location, checked_by) VALUES ($1,'update',$2,$3)`, [eid, b.currentLocation, ctx.memberId], c);
    });
    return this.equipment(id, ctx);
  }
  /** Kiểm kê: cuối ngày hoặc khi hoàn thành nhiệm vụ (không bắt buộc khi đổi phiên/khu vực). */
  @Post('tasks/:id/equipment/check')
  async check(@Param('id') id: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({ kind: z.enum(['daily', 'completion']), items: z.array(z.object({ id: z.string().uuid(), location: z.string().trim().min(2, 'Nhập vị trí hiện tại của thiết bị') })).min(1) }), body);
    const t = await new TasksController().loadTask(ctx, id);
    if (!(await this.canEditEquipment(ctx, t))) throw Errors.forbidden('Chỉ người nhận nhiệm vụ kiểm kê thiết bị');
    await tx(async (c) => {
      for (const it of b.items) {
        const e = await q1(`SELECT id FROM task_equipment WHERE id=$1 AND task_id=$2`, [it.id, id], c);
        if (!e) throw Errors.notFound('Thiết bị');
        await q(`UPDATE task_equipment SET current_location=$2, updated_by=$3, updated_at=now() WHERE id=$1`, [it.id, it.location, ctx.memberId], c);
        await q(`INSERT INTO task_equipment_checks(equipment_id, kind, location, checked_by) VALUES ($1,$2,$3,$4)`, [it.id, b.kind, it.location, ctx.memberId], c);
      }
      await audit(c, ctx, 'task', id, b.kind === 'daily' ? 'equipment.daily_check' : 'equipment.completion_check', null, { items: b.items.length });
    });
    if (b.kind === 'daily' && t.created_by !== ctx.memberId) await notify(getPool(), { companyId: ctx.companyId, memberIds: [t.created_by], type: 'equipment.checked', title: `Đã kiểm kê thiết bị cuối ngày: ${t.title}`, refType: 'task', refId: id, dedupeKey: `eqd:${id}:${new Date().toISOString().slice(0, 10)}` });
    return this.equipment(id, ctx);
  }
  private async assertPermit(taskId: string, movedOut: boolean, permitId?: string | null) {
    if (!movedOut) return;
    if (!permitId) throw Errors.validation('Thiết bị mang ra – vào khỏi phòng ban/vị trí thực hiện phải có giấy phép — chọn giấy phép của nhiệm vụ');
    const p = await q1(`SELECT status FROM permits WHERE id=$1 AND task_id=$2`, [permitId, taskId]);
    if (!p || !['approved', 'auto_issued', 'closed'].includes(p.status)) throw Errors.validation('Giấy phép chưa được cấp hoặc không thuộc nhiệm vụ này');
  }
}

/** Kiểm tra trước khi hoàn thành nhiệm vụ: mọi thiết bị phải có vị trí hiện tại (kiểm kê khi hoàn thành). */
export async function equipmentCompletionIssue(taskId: string): Promise<string | null> {
  const r = await q1(`SELECT count(*) FILTER (WHERE current_location IS NULL OR current_location='')::int AS missing, count(*)::int AS total FROM task_equipment WHERE task_id=$1`, [taskId]);
  if (r.total > 0 && r.missing > 0) return `Còn ${r.missing}/${r.total} thiết bị chưa khai báo vị trí hiện tại — kiểm kê thiết bị trước khi hoàn thành`;
  return null;
}
