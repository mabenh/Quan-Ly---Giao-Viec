/**
 * Phân hệ giám sát công việc & phiên làm việc (Đặc tả v2.0 mục 4, 6):
 * - Bắt đầu / Hoãn / Chuyển việc / Tiếp tục / Kết thúc; mỗi nhân viên chỉ có 1 phiên đang chạy (ràng buộc DB + kiểm tra).
 * - Chuyển việc: phiên cũ được đóng và lưu lịch sử trước khi mở phiên mới.
 * - Thời gian phân loại riêng: thực hiện (phiên), chuẩn bị, chuyển đổi, chờ việc, hoãn khách quan/chủ quan, nghỉ bổ sung, bàn giao, chưa xác định; tăng ca ở phân hệ riêng.
 * - Hoãn khách quan không tự động bị coi là lỗi/hiệu suất thấp.
 * - Vị trí chỉ bắt buộc khi nhiệm vụ cấu hình location_required.
 * - Quỹ nghỉ bổ sung tích lũy: tách khỏi nghỉ theo luật và tăng ca, không tự quy đổi.
 */
import { Body, Controller, Delete, Get, Param, Patch, Post, Query } from '@nestjs/common';
import { DateTime } from 'luxon';
import { PoolClient } from 'pg';
import { getPool, q, q1, tx } from '../db/db';
import { CurrentCtx, Ctx, isAdmin, isHR } from '../common/context';
import { AppError, Errors } from '../common/errors';
import { parse, z } from '../common/validate';
import { notify } from '../common/notify';
import { audit } from '../common/audit';
import { getCompany } from '../common/access';
import { canLeadGroup, inScope, leaderOf, managedGroupIds, scopeMemberIds } from '../common/scope';

export const TIME_CATS = ['preparation', 'changeover', 'waiting', 'objective_pause', 'subjective_pause', 'rest_internal', 'handover', 'unknown'] as const;
const PAUSE_CATS = ['objective_pause', 'subjective_pause', 'waiting', 'preparation', 'changeover', 'handover'] as const;

function inNight(at: Date, tz: string, start: string, end: string) {
  const t = DateTime.fromJSDate(at, { zone: tz });
  const m = t.hour * 60 + t.minute;
  const [sh, sm] = start.split(':').map(Number); const [eh, em] = end.split(':').map(Number);
  const s = sh * 60 + sm, e = eh * 60 + em;
  return s > e ? m >= s || m < e : m >= s && m < e;
}

export async function restBalance(db: any, memberId: string): Promise<number> {
  return (await q1(`SELECT COALESCE(sum(minutes),0)::int AS b FROM rest_transactions WHERE member_id=$1 AND status='posted'`, [memberId], db)).b;
}

/**
 * Tích lũy quỹ nghỉ sau khi đóng phiên: mỗi khối `continuousMinutes` phút thực hiện trong ngày (tính trên các phiên liền nhau,
 * gián đoạn > 30 phút thì tính lại) được cộng dayAccrual/nightAccrual phút; không vượt trần. Thông số do doanh nghiệp chốt (D-01).
 */
export async function accrueRest(c: PoolClient, companyId: string, memberId: string, at: Date) {
  const company = await getCompany(companyId, c);
  const p = company.settings.workTime.rest;
  if (!p.enabled) return 0;
  const tz = company.timezone;
  const day = DateTime.fromJSDate(at, { zone: tz }).startOf('day');
  const sessions = await q(`SELECT started_at, ended_at, night FROM work_sessions WHERE member_id=$1 AND ended_at IS NOT NULL AND started_at >= $2 AND started_at < $3 ORDER BY started_at`,
    [memberId, day.toJSDate(), day.plus({ days: 1 }).toJSDate()], c);
  let entitled = 0; let run = 0; let runNight = false; let lastEnd: Date | null = null;
  const flush = () => { entitled += Math.floor(run / p.continuousMinutes) * (runNight ? p.nightAccrual : p.dayAccrual); run = 0; runNight = false; };
  for (const s of sessions) {
    if (lastEnd && (new Date(s.started_at).getTime() - lastEnd.getTime()) / 60000 > 30) flush();
    run += (new Date(s.ended_at).getTime() - new Date(s.started_at).getTime()) / 60000;
    runNight = runNight || s.night;
    lastEnd = new Date(s.ended_at);
  }
  flush();
  const done = await q1(`SELECT COALESCE(sum(minutes),0)::int AS m FROM rest_transactions WHERE member_id=$1 AND kind='accrual' AND work_date=$2`, [memberId, day.toISODate()], c);
  let add = entitled - done.m;
  if (add <= 0) return 0;
  const bal = await restBalance(c, memberId);
  add = Math.max(0, Math.min(add, p.capMinutes - bal));
  if (add <= 0) return 0;
  await q(`INSERT INTO rest_transactions(company_id, member_id, kind, minutes, work_date, status, reason) VALUES ($1,$2,'accrual',$3,$4,'posted',$5)`,
    [companyId, memberId, add, day.toISODate(), `Tích lũy theo chính sách: ${p.continuousMinutes} phút làm việc liên tục`], c);
  return add;
}

/** Đóng phiên đang chạy (nếu có). */
export async function closeActiveSession(c: PoolClient, companyId: string, memberId: string, reason: string) {
  const s = await q1(`UPDATE work_sessions SET ended_at=now(), end_reason=$2 WHERE member_id=$1 AND ended_at IS NULL RETURNING *`, [memberId, reason], c);
  if (s) await accrueRest(c, companyId, memberId, new Date(s.started_at));
  return s;
}

/** Đóng khoảng thời gian không thực hiện đang mở; nếu là nghỉ bổ sung thì trừ quỹ theo số phút thực tế. */
export async function closeOpenRecord(c: PoolClient, companyId: string, memberId: string) {
  const r = await q1(`UPDATE work_time_records SET ended_at=now() WHERE member_id=$1 AND ended_at IS NULL RETURNING *`, [memberId], c);
  if (r?.category === 'rest_internal') {
    const used = Math.max(1, Math.round((new Date(r.ended_at).getTime() - new Date(r.started_at).getTime()) / 60000));
    const bal = await restBalance(c, memberId);
    const take = Math.min(used, Math.max(0, bal));
    await q(`UPDATE rest_transactions SET status='posted', minutes=$2, reason=COALESCE(reason,'') || $3 WHERE time_record_id=$1 AND kind='use'`,
      [r.id, -take, used > take ? ` (nghỉ thực tế ${used} phút, vượt quỹ ${used - take} phút — cần trưởng nhóm xem xét)` : ''], c);
  }
  return r;
}

async function loadTaskForMember(db: any, ctx: Ctx, taskId: string) {
  const t = await q1(`SELECT t.*, o.company_member_id AS owner_id,
                             EXISTS (SELECT 1 FROM task_assignees a WHERE a.task_id=t.id AND a.company_member_id=$3 AND a.active) AS assigned
                        FROM tasks t LEFT JOIN task_assignees o ON o.task_id=t.id AND o.assignment_type='owner' AND o.active
                       WHERE t.id=$1 AND t.company_id=$2`, [taskId, ctx.companyId, ctx.memberId], db);
  if (!t || !t.assigned) throw Errors.notFound('Nhiệm vụ');
  return t;
}

@Controller()
export class SessionsController {
  /** Bắt đầu (hoặc chuyển sang) một nhiệm vụ: phiên cũ đóng & lưu trước khi mở phiên mới. */
  @Post('sessions/start')
  async start(@Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({
      taskId: z.string().uuid(), locationId: z.string().uuid().optional().nullable(),
      locationSource: z.enum(['declared', 'outside', 'unknown']).optional(),
    }), body);
    await tx(async (c) => {
      const t = await loadTaskForMember(c, ctx, b.taskId);
      if (Number((await q1(`SELECT count(*)::int AS n FROM tasks WHERE parent_id=$1 AND status<>'cancelled'`, [t.id], c)).n) > 0) {
        throw Errors.invalidState('Việc khung có phần việc con — hãy bắt đầu phiên ở phần việc của bạn');
      }
      if (['waiting', 'pending_approval'].includes(t.status)) throw new AppError('DEPENDENCY_NOT_MET', t.status === 'waiting' ? 'Công đoạn trước chưa hoàn thành. Cần người có quyền cho phép bắt đầu sớm.' : 'Việc đang chờ cấp trên duyệt giao', 409);
      if (['completed', 'cancelled', 'pending_review'].includes(t.status)) throw Errors.invalidState('Nhiệm vụ không ở trạng thái thực hiện');
      const pendingHo = await q1(`SELECT id, status FROM handover_contexts WHERE to_task_id=$1 AND status IN ('submitted','rejected') LIMIT 1`, [t.id], c);
      if (pendingHo && !t.early_start_reason) throw new AppError('HANDOVER_NOT_ACCEPTED', pendingHo.status === 'submitted' ? 'Cần tiếp nhận bàn giao của công đoạn trước trước khi bắt đầu' : 'Bàn giao của công đoạn trước đang chờ bổ sung', 409);
      let locId = b.locationId ?? null; let locSrc: string | null = b.locationSource ?? (locId ? 'declared' : null);
      if (t.location_required && !locId) {
        if (t.work_location_id) { locId = t.work_location_id; locSrc = 'task'; } else throw Errors.validation('Nhiệm vụ này yêu cầu khai báo vị trí làm việc');
      } else if (!locId && t.work_location_id) { locId = t.work_location_id; locSrc = 'task'; }
      if (locId && !(await q1(`SELECT 1 FROM work_locations WHERE id=$1 AND company_id=$2`, [locId, ctx.companyId], c))) throw Errors.notFound('Vị trí');
      await closeOpenRecord(c, ctx.companyId, ctx.memberId);
      const prev = await closeActiveSession(c, ctx.companyId, ctx.memberId, 'switch');
      const company = await getCompany(ctx.companyId, c);
      const night = inNight(new Date(), company.timezone, company.settings.workTime.rest.nightStart, company.settings.workTime.rest.nightEnd);
      await q(`INSERT INTO work_sessions(company_id, member_id, task_id, work_location_id, location_source, night) VALUES ($1,$2,$3,$4,$5,$6)`,
        [ctx.companyId, ctx.memberId, t.id, locId, locSrc, night], c);
      if (['not_started', 'revision_requested'].includes(t.status)) {
        await q(`UPDATE tasks SET status='in_progress', started_at=COALESCE(started_at, now()), updated_at=now() WHERE id=$1`, [t.id], c);
        await audit(c, ctx, 'task', t.id, 'task.status', { status: t.status }, { status: 'in_progress', via: 'session' });
      }
      if (prev && prev.task_id !== t.id) await audit(c, ctx, 'task', prev.task_id, 'session.switched', null, { to_task: t.id });
    });
    return this.me(ctx);
  }

  @Post('sessions/pause')
  async pause(@Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({ category: z.enum(PAUSE_CATS), reason: z.string().trim().max(500).optional(), relatedParty: z.string().max(200).optional() }), body);
    if (['objective_pause', 'waiting', 'subjective_pause'].includes(b.category) && (!b.reason || b.reason.length < 3)) throw Errors.reasonRequired('Nêu lý do hoãn/chờ');
    await tx(async (c) => {
      const s = await closeActiveSession(c, ctx.companyId, ctx.memberId, b.category === 'handover' ? 'handover' : 'pause');
      const open = await q1(`SELECT task_id FROM work_time_records WHERE member_id=$1 AND ended_at IS NULL`, [ctx.memberId], c);
      const taskId = s?.task_id || open?.task_id || null;
      await closeOpenRecord(c, ctx.companyId, ctx.memberId);
      await q(`INSERT INTO work_time_records(company_id, member_id, task_id, category, reason, related_party, created_by) VALUES ($1,$2,$3,$4,$5,$6,$2)`,
        [ctx.companyId, ctx.memberId, taskId, b.category, b.reason ?? null, b.relatedParty ?? null], c);
      if (b.category === 'objective_pause' && taskId) {
        const t = await q1(`SELECT title, group_id FROM tasks WHERE id=$1`, [taskId], c);
        await audit(c, ctx, 'task', taskId, 'task.paused', null, { category: b.category }, b.reason);
        await notify(c, { companyId: ctx.companyId, memberIds: [await leaderOf(t.group_id, c)], excludeMemberId: ctx.memberId, type: 'session.paused',
          title: `${ctx.name} hoãn "${t.title}" do nguyên nhân khách quan — cần xác nhận`, body: b.reason, refType: 'task', refId: taskId });
      }
    });
    return this.me(ctx);
  }

  @Post('sessions/resume')
  async resume(@CurrentCtx() ctx: Ctx) {
    const open = await q1(`SELECT task_id FROM work_time_records WHERE member_id=$1 AND ended_at IS NULL`, [ctx.memberId]);
    const last = open?.task_id || (await q1(`SELECT task_id FROM work_sessions WHERE member_id=$1 ORDER BY started_at DESC LIMIT 1`, [ctx.memberId]))?.task_id;
    if (!last) throw Errors.invalidState('Không có việc để tiếp tục — chọn một nhiệm vụ để bắt đầu');
    return this.start({ taskId: last }, ctx);
  }

  @Post('sessions/end')
  async end(@Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({ reason: z.enum(['end', 'complete', 'handover']).default('end') }), body || {});
    await tx(async (c) => {
      await closeActiveSession(c, ctx.companyId, ctx.memberId, b.reason);
      await closeOpenRecord(c, ctx.companyId, ctx.memberId);
    });
    return this.me(ctx);
  }

  @Get('sessions/me')
  async me(@CurrentCtx() ctx: Ctx) {
    const company = await getCompany(ctx.companyId);
    const tz = company.timezone;
    const day = DateTime.now().setZone(tz).startOf('day');
    const active = await q1(`SELECT s.*, t.title AS task_title, t.code AS task_code, l.name AS location_name FROM work_sessions s JOIN tasks t ON t.id=s.task_id
                               LEFT JOIN work_locations l ON l.id=s.work_location_id WHERE s.member_id=$1 AND s.ended_at IS NULL`, [ctx.memberId]);
    const open = await q1(`SELECT r.*, t.title AS task_title FROM work_time_records r LEFT JOIN tasks t ON t.id=r.task_id WHERE r.member_id=$1 AND r.ended_at IS NULL`, [ctx.memberId]);
    const today = await timeSummary([ctx.memberId], day.toJSDate(), day.plus({ days: 1 }).toJSDate());
    const timeline = await q(
      `SELECT 'session' AS kind, 'execution' AS category, s.started_at, s.ended_at, t.title AS task_title, s.end_reason AS note FROM work_sessions s JOIN tasks t ON t.id=s.task_id
        WHERE s.member_id=$1 AND s.started_at >= $2
       UNION ALL
       SELECT 'record', r.category, r.started_at, r.ended_at, t.title, r.reason FROM work_time_records r LEFT JOIN tasks t ON t.id=r.task_id WHERE r.member_id=$1 AND r.started_at >= $2
       ORDER BY 3 DESC LIMIT 60`, [ctx.memberId, day.toJSDate()]);
    const pendingRest = await q1(`SELECT id, created_at FROM rest_transactions WHERE member_id=$1 AND kind='use' AND status='pending'`, [ctx.memberId]);
    return {
      active, open, today: today[ctx.memberId], timeline,
      rest: { enabled: company.settings.workTime.rest.enabled, balance: await restBalance(getPool(), ctx.memberId), policy: company.settings.workTime.rest, pending: pendingRest },
    };
  }

  /** Trưởng nhóm/quản lý: ai đang làm gì (phiên, hoãn, nghỉ, thời điểm cần quay lại). */
  @Get('sessions/team')
  async team(@CurrentCtx() ctx: Ctx, @Query('groupId') groupId?: string) {
    const groups = await managedGroupIds(ctx);
    if (!groups.length) throw Errors.forbidden('Chỉ trưởng nhóm/quản lý xem được phiên làm việc của nhóm');
    const gids = groupId ? (groups.includes(groupId) ? [groupId] : []) : groups;
    if (!gids.length) throw Errors.notFound('Nhóm');
    return q(
      `SELECT DISTINCT ON (cm.id) cm.id AS member_id, u.name, cm.user_id, g.name AS group_name,
              s.id AS session_id, s.started_at AS session_started_at, st.title AS session_task, st.id AS session_task_id, sl.name AS location_name,
              r.id AS record_id, r.category AS record_category, r.started_at AS record_started_at, r.reason AS record_reason, r.confirmed_by AS record_confirmed_by, rt.title AS record_task,
              (SELECT count(*) FROM task_assignees a JOIN tasks t ON t.id=a.task_id WHERE a.company_member_id=cm.id AND a.active AND t.status IN ('not_started','in_progress','revision_requested'))::int AS open_tasks
         FROM groups g JOIN (SELECT group_id, company_member_id FROM group_members UNION SELECT id, manager_member_id FROM groups UNION SELECT id, leader_member_id FROM groups WHERE leader_member_id IS NOT NULL) gm ON gm.group_id=g.id
         JOIN company_members cm ON cm.id=gm.company_member_id AND cm.status='active' JOIN users u ON u.id=cm.user_id
         LEFT JOIN work_sessions s ON s.member_id=cm.id AND s.ended_at IS NULL LEFT JOIN tasks st ON st.id=s.task_id LEFT JOIN work_locations sl ON sl.id=s.work_location_id
         LEFT JOIN work_time_records r ON r.member_id=cm.id AND r.ended_at IS NULL LEFT JOIN tasks rt ON rt.id=r.task_id
        WHERE g.id = ANY($1::uuid[]) ORDER BY cm.id, u.name`, [gids]);
  }

  /** Trưởng nhóm xác nhận hoãn khách quan (hoặc chuyển thành hoãn chủ quan, có lý do). */
  @Post('time-records/:id/confirm')
  async confirm(@Param('id') id: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({ objective: z.boolean(), note: z.string().trim().max(500).optional() }), body);
    const r = await q1(`SELECT r.*, t.group_id FROM work_time_records r LEFT JOIN tasks t ON t.id=r.task_id WHERE r.id=$1 AND r.company_id=$2`, [id, ctx.companyId]);
    if (!r) throw Errors.notFound('Bản ghi thời gian');
    if (r.member_id === ctx.memberId) throw new AppError('CONFLICT_OF_INTEREST', 'Không tự xác nhận thời gian của mình', 403);
    if (!(await canLeadGroup(ctx, r.group_id)) && !(await inScope(ctx, r.member_id))) throw Errors.forbidden();
    if (!['objective_pause', 'subjective_pause'].includes(r.category)) throw Errors.invalidState('Chỉ xác nhận bản ghi hoãn');
    if (!b.objective && (!b.note || b.note.length < 5)) throw Errors.reasonRequired('Nêu lý do không xác nhận là hoãn khách quan');
    await tx(async (c) => {
      const cat = b.objective ? 'objective_pause' : 'subjective_pause';
      await q(`UPDATE work_time_records SET category=$2, confirmed_by=$3, confirmed_at=now(), reason=COALESCE(reason,'') || CASE WHEN $4::text IS NULL THEN '' ELSE ' · Xác nhận: ' || $4 END WHERE id=$1`, [id, cat, ctx.memberId, b.note ?? null], c);
      await audit(c, ctx, 'time_record', id, 'time.confirmed', { category: r.category }, { category: cat }, b.note ?? null);
      await notify(c, { companyId: ctx.companyId, memberIds: [r.member_id], type: 'session.confirmed', title: b.objective ? 'Hoãn khách quan đã được xác nhận' : 'Khoảng hoãn được ghi nhận là hoãn chủ quan', body: b.note, refType: 'task', refId: r.task_id });
    });
    return { ok: true };
  }

  // ---------------- Quỹ nghỉ bổ sung ----------------
  @Get('rest/ledger')
  async ledger(@CurrentCtx() ctx: Ctx, @Query('memberId') memberId?: string) {
    const mid = memberId || ctx.memberId;
    if (mid !== ctx.memberId && !(await inScope(ctx, mid)) && !isHR(ctx)) throw Errors.forbidden();
    const company = await getCompany(ctx.companyId);
    const items = await q(`SELECT r.*, au.name AS approved_by_name FROM rest_transactions r LEFT JOIN company_members a ON a.id=r.approved_by LEFT JOIN users au ON au.id=a.user_id
                            WHERE r.member_id=$1 AND r.company_id=$2 ORDER BY r.created_at DESC LIMIT 100`, [mid, ctx.companyId]);
    return { balance: await restBalance(getPool(), mid), policy: company.settings.workTime.rest, items,
      note: 'Quỹ nghỉ bổ sung do doanh nghiệp thiết kế thêm, tách biệt nghỉ giữa giờ theo luật và giờ làm thêm; không tự động quy đổi thành giờ làm thêm hay tiền lương.' };
  }

  /** Xin dùng quỹ nghỉ khi đang hoãn khách quan/chờ việc. */
  @Post('rest/request')
  async requestRest(@Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({ note: z.string().max(300).optional() }), body || {});
    const company = await getCompany(ctx.companyId);
    const p = company.settings.workTime.rest;
    if (!p.enabled) throw Errors.invalidState('Doanh nghiệp chưa áp dụng quỹ nghỉ bổ sung');
    const open = await q1(`SELECT r.*, t.group_id, t.title FROM work_time_records r LEFT JOIN tasks t ON t.id=r.task_id WHERE r.member_id=$1 AND r.ended_at IS NULL`, [ctx.memberId]);
    if (!open || !['objective_pause', 'waiting'].includes(open.category)) throw new AppError('REST_NOT_ALLOWED', 'Chỉ dùng quỹ nghỉ khi nhiệm vụ đang hoãn khách quan hoặc đang chờ việc và không có việc phù hợp', 409);
    const bal = await restBalance(getPool(), ctx.memberId);
    if (bal <= 0) throw new AppError('REST_NO_BALANCE', 'Quỹ nghỉ bổ sung của bạn đã hết', 409);
    if (await q1(`SELECT 1 FROM rest_transactions WHERE member_id=$1 AND kind='use' AND status IN ('pending','approved')`, [ctx.memberId])) throw Errors.invalidState('Bạn đã có yêu cầu nghỉ đang chờ/đang dùng');
    await tx(async (c) => {
      const t = await q1(`INSERT INTO rest_transactions(company_id, member_id, kind, minutes, status, reason, requested_by) VALUES ($1,$2,'use',0,'pending',$3,$2) RETURNING id`,
        [ctx.companyId, ctx.memberId, b.note ?? null], c);
      if (p.requireApproval) {
        await notify(c, { companyId: ctx.companyId, memberIds: [await leaderOf(open.group_id, c)], excludeMemberId: ctx.memberId, type: 'rest.request',
          title: `${ctx.name} xin dùng quỹ nghỉ (còn ${bal} phút) trong lúc hoãn "${open.title || 'việc'}"`, refType: 'rest', refId: t.id });
      } else await this.startRest(c, ctx.companyId, ctx.memberId, t.id, null);
    });
    return this.me(ctx);
  }

  private async startRest(c: PoolClient, companyId: string, memberId: string, txId: string, approver: string | null) {
    const open = await q1(`SELECT task_id FROM work_time_records WHERE member_id=$1 AND ended_at IS NULL`, [memberId], c);
    await closeOpenRecord(c, companyId, memberId);
    const r = await q1(`INSERT INTO work_time_records(company_id, member_id, task_id, category, reason, created_by, confirmed_by, confirmed_at) VALUES ($1,$2,$3,'rest_internal','Dùng quỹ nghỉ bổ sung',$2,$4, CASE WHEN $4::uuid IS NULL THEN NULL ELSE now() END) RETURNING id`,
      [companyId, memberId, open?.task_id ?? null, approver], c);
    await q(`UPDATE rest_transactions SET status='approved', approved_by=$2, approved_at=now(), time_record_id=$3 WHERE id=$1`, [txId, approver, r.id], c);
  }

  @Post('rest/:id/decide')
  async decideRest(@Param('id') id: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({ decision: z.enum(['approve', 'reject']), note: z.string().max(300).optional() }), body);
    const t = await q1(`SELECT * FROM rest_transactions WHERE id=$1 AND company_id=$2 AND kind='use' AND status='pending'`, [id, ctx.companyId]);
    if (!t) throw Errors.notFound('Yêu cầu nghỉ');
    if (t.member_id === ctx.memberId) throw new AppError('CONFLICT_OF_INTEREST', 'Không tự duyệt nghỉ của mình', 403);
    if (!(await inScope(ctx, t.member_id))) throw Errors.forbidden();
    await tx(async (c) => {
      if (b.decision === 'approve') await this.startRest(c, ctx.companyId, t.member_id, id, ctx.memberId);
      else await q(`UPDATE rest_transactions SET status='rejected', approved_by=$2, approved_at=now(), reason=$3 WHERE id=$1`, [id, ctx.memberId, b.note ?? 'Không duyệt'], c);
      await notify(c, { companyId: ctx.companyId, memberIds: [t.member_id], type: 'rest.decided', title: b.decision === 'approve' ? 'Được phép nghỉ — bấm "Tiếp tục" khi quay lại làm việc' : 'Yêu cầu nghỉ chưa được duyệt', body: b.note, refType: 'rest', refId: id });
    });
    return { ok: true };
  }

  @Get('rest/requests')
  async restRequests(@CurrentCtx() ctx: Ctx) {
    const scope = await scopeMemberIds(ctx);
    return q(`SELECT r.id, r.member_id, u.name, r.created_at, r.reason FROM rest_transactions r JOIN company_members cm ON cm.id=r.member_id JOIN users u ON u.id=cm.user_id
               WHERE r.company_id=$1 AND r.kind='use' AND r.status='pending' AND r.member_id<>$2 AND ($3::uuid[] IS NULL OR r.member_id = ANY($3::uuid[]))`, [ctx.companyId, ctx.memberId, scope]);
  }

  /** Điều chỉnh quỹ nghỉ (Nhân sự/Quản trị), bắt buộc lý do, lưu vết. */
  @Post('rest/adjust')
  async adjust(@Body() body: any, @CurrentCtx() ctx: Ctx) {
    if (!isHR(ctx)) throw Errors.forbidden();
    const b = parse(z.object({ memberId: z.string().uuid(), minutes: z.number().int().min(-600).max(600), reason: z.string().trim().min(5) }), body);
    if (b.memberId === ctx.memberId) throw new AppError('CONFLICT_OF_INTEREST', 'Không tự điều chỉnh quỹ nghỉ của mình', 403);
    await q(`INSERT INTO rest_transactions(company_id, member_id, kind, minutes, status, reason, requested_by, approved_by, approved_at) VALUES ($1,$2,'adjust',$3,'posted',$4,$5,$5,now())`,
      [ctx.companyId, b.memberId, b.minutes, b.reason, ctx.memberId]);
    await audit(getPool(), ctx, 'member', b.memberId, 'rest.adjusted', null, { minutes: b.minutes }, b.reason);
    return this.ledger(ctx, b.memberId);
  }

  // ---------------- Báo cáo thời gian ----------------
  @Get('time/summary')
  async summary(@CurrentCtx() ctx: Ctx, @Query() qs: any) {
    const f = parse(z.object({ memberId: z.string().uuid().optional(), groupId: z.string().uuid().optional(), from: z.coerce.date().optional(), to: z.coerce.date().optional() }), qs);
    const to = f.to || new Date(); const from = f.from || new Date(to.getTime() - 7 * 86400000);
    let ids: string[];
    if (f.memberId) { if (f.memberId !== ctx.memberId && !(await inScope(ctx, f.memberId))) throw Errors.forbidden(); ids = [f.memberId]; }
    else if (f.groupId) {
      if (!(await canLeadGroup(ctx, f.groupId))) throw Errors.forbidden();
      ids = (await q(`SELECT company_member_id AS id FROM group_members WHERE group_id=$1`, [f.groupId])).map((r) => r.id);
    } else ids = [ctx.memberId];
    const sum = await timeSummary(ids, from, to);
    const names = await q(`SELECT cm.id, u.name FROM company_members cm JOIN users u ON u.id=cm.user_id WHERE cm.id = ANY($1::uuid[])`, [ids]);
    return { from, to, members: names.map((n) => ({ member_id: n.id, name: n.name, ...sum[n.id] })) };
  }

  // ---------------- Vị trí làm việc ----------------
  @Get('company/locations')
  async locations(@CurrentCtx() ctx: Ctx) {
    return q(`SELECT * FROM work_locations WHERE company_id=$1 ORDER BY active DESC, name`, [ctx.companyId]);
  }
  @Post('company/locations')
  async addLocation(@Body() body: any, @CurrentCtx() ctx: Ctx) {
    if (!isAdmin(ctx) && !isHR(ctx) && ctx.role !== 'manager') throw Errors.forbidden();
    const b = parse(z.object({ name: z.string().trim().min(2), kind: z.enum(['department', 'machine_room', 'raw_store', 'cold_store', 'production_floor', 'packing', 'office', 'outside', 'area']).default('area') }), body);
    return q1(`INSERT INTO work_locations(company_id, name, kind) VALUES ($1,$2,$3) RETURNING *`, [ctx.companyId, b.name, b.kind]);
  }
  @Patch('company/locations/:id')
  async editLocation(@Param('id') id: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    if (!isAdmin(ctx) && !isHR(ctx) && ctx.role !== 'manager') throw Errors.forbidden();
    const b = parse(z.object({ name: z.string().trim().min(2).optional(), active: z.boolean().optional() }), body);
    const r = await q1(`UPDATE work_locations SET name=COALESCE($3,name), active=COALESCE($4,active) WHERE id=$1 AND company_id=$2 RETURNING *`, [id, ctx.companyId, b.name ?? null, b.active ?? null]);
    if (!r) throw Errors.notFound('Vị trí');
    return r;
  }
}

/** Tổng hợp thời gian theo loại (phút), cắt theo khoảng [from,to). Phiên đang chạy tính đến hiện tại. */
export async function timeSummary(memberIds: string[], from: Date, to: Date): Promise<Record<string, Record<string, number>>> {
  const out: Record<string, Record<string, number>> = {};
  for (const id of memberIds) out[id] = { execution: 0, preparation: 0, changeover: 0, waiting: 0, objective_pause: 0, subjective_pause: 0, rest_internal: 0, handover: 0, unknown: 0, overtime: 0 };
  if (!memberIds.length) return out;
  const clip = `GREATEST(0, EXTRACT(EPOCH FROM (LEAST(COALESCE(x.ended_at, now()), $3) - GREATEST(x.started_at, $2))) / 60)`;
  const ses = await q(`SELECT x.member_id, sum(${clip})::numeric AS m FROM work_sessions x WHERE x.member_id = ANY($1::uuid[]) AND x.started_at < $3 AND COALESCE(x.ended_at, now()) > $2 GROUP BY 1`, [memberIds, from, to]);
  for (const r of ses) out[r.member_id].execution = Math.round(Number(r.m));
  const rec = await q(`SELECT x.member_id, x.category, sum(${clip})::numeric AS m FROM work_time_records x WHERE x.member_id = ANY($1::uuid[]) AND x.started_at < $3 AND COALESCE(x.ended_at, now()) > $2 GROUP BY 1,2`, [memberIds, from, to]);
  for (const r of rec) out[r.member_id][r.category] = Math.round(Number(r.m));
  const ot = await q(`SELECT member_id, COALESCE(sum(minutes),0)::int AS m FROM overtime_records WHERE member_id = ANY($1::uuid[]) AND approval_status='confirmed' AND start_at < $3 AND end_at > $2 GROUP BY 1`, [memberIds, from, to]);
  for (const r of ot) out[r.member_id].overtime = r.m;
  return out;
}
