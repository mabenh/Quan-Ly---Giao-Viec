/**
 * Luồng công việc nhiều lớp / nhiều giai đoạn:
 * - Phần việc con có stage_no; các phần việc cùng giai đoạn chạy song song, giai đoạn sau chỉ bắt đầu khi giai đoạn trước hoàn thành.
 * - Việc có phần việc con (việc "khung") tự chuyển sang chờ nghiệm thu khi mọi phần con hoàn thành.
 * - Nghiệm thu không nhảy cấp: người nghiệm thu là quản lý trực tiếp của nhóm chứa việc
 *   (nếu người làm chính là quản lý nhóm đó thì người giao việc nghiệm thu; nếu trùng nữa thì cấp trên trực tiếp).
 */
import { PoolClient } from 'pg';
import { q, q1 } from '../db/db';
import { Ctx, isAdmin } from '../common/context';
import { notify } from '../common/notify';
import { audit } from '../common/audit';
import { createStageHandovers } from './operations.controller';

export async function reviewerOf(db: any, t: { group_id: string; owner_id: string | null; created_by: string }): Promise<string | null> {
  const g = await q1(`SELECT manager_member_id FROM groups WHERE id=$1`, [t.group_id], db);
  if (g && g.manager_member_id !== t.owner_id) return g.manager_member_id;
  if (t.created_by !== t.owner_id) return t.created_by;
  const s = await q1(`SELECT supervisor_member_id FROM company_members WHERE id=$1`, [t.owner_id], db);
  return s?.supervisor_member_id ?? null;
}

/** Quyền sửa: 'full' cho người giao việc (người tạo việc hoặc người tạo việc gốc) và Admin; 'assignees' cho quản lý lớp dưới. */
export async function editScope(db: any, ctx: Ctx, t: any): Promise<'full' | 'assignees' | null> {
  if (isAdmin(ctx) || t.created_by === ctx.memberId) return 'full';
  if (t.root_id) {
    const r = await q1(`SELECT created_by FROM tasks WHERE id=$1`, [t.root_id], db);
    if (r?.created_by === ctx.memberId) return 'full';
  }
  const g = await q1(`SELECT manager_member_id FROM groups WHERE id=$1`, [t.group_id], db);
  if (g?.manager_member_id === ctx.memberId) return 'assignees';
  if (t.parent_id) {
    const po = await q1(`SELECT 1 FROM task_assignees WHERE task_id=$1 AND company_member_id=$2 AND active AND assignment_type='owner'`, [t.parent_id, ctx.memberId], db);
    if (po) return 'assignees';
  }
  return null;
}

/** Giai đoạn đang chạy của một việc khung = giai đoạn nhỏ nhất còn phần việc chưa xong. */
export async function activeStage(db: any, parentId: string): Promise<number | null> {
  const r = await q1(`SELECT min(stage_no) AS s FROM tasks WHERE parent_id=$1 AND status NOT IN ('completed','cancelled')`, [parentId], db);
  return r?.s ?? null;
}

/** Gọi sau khi một phần việc con hoàn thành/hủy/được duyệt: mở giai đoạn tiếp theo hoặc chuyển việc khung sang chờ nghiệm thu. */
export async function advanceStages(c: PoolClient, companyId: string, parentId: string | null) {
  if (!parentId) return;
  const parent = await q1(`SELECT t.*, o.company_member_id AS owner_id FROM tasks t LEFT JOIN task_assignees o ON o.task_id=t.id AND o.assignment_type='owner' AND o.active WHERE t.id=$1`, [parentId], c);
  if (!parent || ['completed', 'cancelled'].includes(parent.status)) return;
  const kids = await q(`SELECT id, stage_no, status FROM tasks WHERE parent_id=$1 AND status<>'cancelled'`, [parentId], c);
  if (!kids.length) return;
  const open = kids.filter((k) => k.status !== 'completed');
  if (!open.length) {
    if (!['pending_review'].includes(parent.status)) {
      await q(`UPDATE tasks SET status='pending_review', submitted_at=now(), first_submitted_at=COALESCE(first_submitted_at, now()), started_at=COALESCE(started_at, now()), updated_at=now() WHERE id=$1`, [parentId], c);
      await q(`INSERT INTO task_submissions(task_id, submitted_by, output_description, completion_percent) VALUES ($1,$2,$3,100)`,
        [parentId, parent.owner_id || parent.created_by, `Tất cả ${kids.length} phần việc con đã hoàn thành.`], c);
      await audit(c, { companyId, memberId: null }, 'task', parentId, 'task.submitted', { status: parent.status }, { status: 'pending_review', auto: true });
      const rv = await reviewerOf(c, parent);
      await notify(c, { companyId, memberIds: [rv], type: 'task.pending_review', title: `Các phần việc của "${parent.title}" đã xong — chờ bạn nghiệm thu`, refType: 'task', refId: parentId });
    }
    return;
  }
  const stage = Math.min(...open.map((k) => k.stage_no));
  const toStart = await q(`UPDATE tasks SET status='not_started', updated_at=now() WHERE parent_id=$1 AND stage_no=$2 AND status='waiting' RETURNING id, title, group_id`, [parentId, stage], c);
  // Bàn giao liên bộ phận: kế thừa kết quả công đoạn trước, bên nhận tiếp nhận trước khi bắt đầu
  const fresh = await q(`SELECT id, title, group_id FROM tasks WHERE parent_id=$1 AND stage_no=$2 AND status IN ('not_started') AND NOT EXISTS (SELECT 1 FROM handover_contexts h WHERE h.to_task_id=tasks.id)`, [parentId, stage], c);
  if (stage > Math.min(...kids.map((k) => k.stage_no))) await createStageHandovers(c, companyId, parentId, stage, fresh);
  for (const t of toStart) {
    const own = await q1(`SELECT company_member_id FROM task_assignees WHERE task_id=$1 AND assignment_type='owner' AND active`, [t.id], c);
    const g = await q1(`SELECT manager_member_id FROM groups WHERE id=$1`, [t.group_id], c);
    await audit(c, { companyId, memberId: null }, 'task', t.id, 'task.status', { status: 'waiting' }, { status: 'not_started', stage });
    await notify(c, { companyId, memberIds: [own?.company_member_id, g?.manager_member_id], type: 'task.stage_started',
      title: `▶ Đến lượt bạn: ${t.title}`, body: `Giai đoạn ${stage} của "${parent.title}" bắt đầu`, refType: 'task', refId: t.id });
  }
  if (parent.status === 'not_started') await q(`UPDATE tasks SET status='in_progress', started_at=COALESCE(started_at, now()) WHERE id=$1`, [parentId], c);
}

/** Việc xử lý trở ngại đã hoàn thành -> báo cáo chuyển sang chờ người báo cáo xác nhận. */
export async function onTaskCompleted(c: PoolClient, companyId: string, taskId: string) {
  const t = await q1(`SELECT id, parent_id, source_report_id, title FROM tasks WHERE id=$1`, [taskId], c);
  if (t?.source_report_id) {
    const w = await q1(`SELECT id, code, reporter_id, stage FROM workplace_reports WHERE id=$1`, [t.source_report_id], c);
    if (w && w.stage !== 'closed') {
      await q(`UPDATE workplace_reports SET status='resolved_pending', stage='reporter_confirm', current_holder_id=reporter_id, stage_due_at=NULL WHERE id=$1`, [w.id], c);
      await q(`INSERT INTO report_updates(report_id, actor_id, status, comment) VALUES ($1,NULL,'resolved_pending',$2)`, [w.id, `Việc xử lý "${t.title}" đã được nghiệm thu`], c);
      await notify(c, { companyId, memberIds: [w.reporter_id], type: 'report.resolved', title: `[${w.code}] Đã xử lý — vui lòng xác nhận`, refType: 'workplace_report', refId: w.id });
    }
  }
  await advanceStages(c, companyId, t?.parent_id ?? null);
}

/** Gắn việc xử lý vào báo cáo trở ngại (quản lý tự giải quyết bằng cách giao việc). */
export async function linkReportTask(c: PoolClient, ctx: Ctx, reportId: string, taskId: string, ownerId: string, dueAt: Date) {
  const w = await q1(`SELECT * FROM workplace_reports WHERE id=$1 AND company_id=$2`, [reportId, ctx.companyId], c);
  if (!w) return;
  const task = await q1(`SELECT code, title FROM tasks WHERE id=$1`, [taskId], c);
  const owner = await q1(`SELECT u.name FROM company_members cm JOIN users u ON u.id=cm.user_id WHERE cm.id=$1`, [ownerId], c);
  await q(`UPDATE workplace_reports SET status='task_assigned', stage='resolution', impact_confirmed=true, resolution_task_id=$2, assignee_id=$3, current_holder_id=$3,
             stage_due_at=$4, decided_by=$5, sla_cycle=sla_cycle+1, escalation_level=0 WHERE id=$1`, [reportId, taskId, ownerId, dueAt, ctx.memberId], c);
  await q(`UPDATE escalations SET status='resolved', resolution='Đã giao việc xử lý', resolved_by=$2, resolved_at=now() WHERE parent_type='workplace_report' AND parent_id=$1 AND status='open'`, [reportId, ctx.memberId], c);
  await q(`INSERT INTO report_updates(report_id, actor_id, status, comment, new_due_at) VALUES ($1,$2,'task_assigned',$3,$4)`,
    [reportId, ctx.memberId, `${ctx.name} giao cho ${owner?.name} giải quyết (${task.code} · ${task.title})`, dueAt], c);
  await audit(c, ctx, 'workplace_report', reportId, 'report.task_assigned', { status: w.status }, { task: taskId, owner: ownerId });
  await notify(c, { companyId: ctx.companyId, memberIds: [w.reporter_id], type: 'report.status', title: `[${w.code}] ${ctx.name} đã giao ${owner?.name} xử lý`, refType: 'workplace_report', refId: reportId });
}
