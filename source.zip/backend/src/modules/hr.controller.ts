import { Body, Controller, Get, Param, Patch, Post } from '@nestjs/common';
import { DateTime } from 'luxon';
import { getPool, q, q1 } from '../db/db';
import { CurrentCtx, Ctx, isHR } from '../common/context';
import { Errors } from '../common/errors';
import { parse, z } from '../common/validate';
import { getCompany } from '../common/access';
import { audit } from '../common/audit';
import { notify } from '../common/notify';
import { OPEN_STATUSES } from './tasks.controller';

const STEPS = z.array(z.object({ title: z.string().trim().min(2), detail: z.string().trim().default(''), role: z.string().optional() })).min(1);
const MANAGERIAL = ['owner', 'admin', 'manager', 'hr', 'reviewer'];

/** Quy trình áp dụng cho một thành viên: toàn công ty, dành cho quản lý, hoặc riêng bộ phận của người đó. */
export async function proceduresFor(companyId: string, member: { id: string; role: string; department_id: string | null }, db: any = getPool()) {
  const heads = (await q(`SELECT id FROM departments WHERE head_member_id=$1`, [member.id], db)).map((r) => r.id);
  const depts = [member.department_id, ...heads].filter(Boolean);
  return q(
    `SELECT p.*, d.name AS department_name FROM procedures p LEFT JOIN departments d ON d.id=p.department_id
      WHERE p.company_id=$1 AND p.active AND (p.audience='all' OR (p.audience='managers' AND $2::boolean) OR (p.audience='department' AND p.department_id = ANY($3::uuid[])))
      ORDER BY p.category, p.title`, [companyId, MANAGERIAL.includes(member.role), depts], db);
}

/** Tin vắn quy trình theo chu kỳ: mỗi ngày làm việc (sau 8:30 giờ công ty) mỗi người nhận tối đa một tin. */
export async function sendProcedureTips(companyId: string, now: Date) {
  const c = await getCompany(companyId);
  const local = DateTime.fromJSDate(now, { zone: c.timezone });
  if (!c.settings.calendar.workdays.includes(local.weekday) || c.settings.calendar.holidays.includes(local.toISODate()!)) return 0;
  if (local.hour * 60 + local.minute < 8 * 60 + 30) return 0;
  const members = await q(`SELECT id, role, department_id FROM company_members WHERE company_id=$1 AND status='active'`, [companyId]);
  const dayNo = Math.floor(local.startOf('day').toSeconds() / 86400);
  let sent = 0;
  for (const m of members) {
    const due = (await proceduresFor(companyId, m)).filter((p) =>
      p.reminder === 'daily' || (p.reminder === 'weekly' && local.weekday === 1) || (p.reminder === 'monthly' && local.day <= 7 && local.weekday === 1));
    if (!due.length) continue;
    const p = due[dayNo % due.length];
    const steps = p.steps || [];
    const st = steps.length ? steps[Math.floor(dayNo / due.length) % steps.length] : null;
    sent += await notify(getPool(), {
      companyId, memberIds: [m.id], type: 'procedure.tip', refType: 'procedure', refId: p.id,
      title: `📘 ${p.title}`, body: st ? `${st.title}: ${st.detail}` : p.summary, dedupeKey: `tip-${local.toISODate()}`,
    });
  }
  return sent;
}

@Controller('hr')
export class HrController {
  /** Sơ đồ tổ chức (cây theo cấp trên trực tiếp) kèm bộ phận, nhóm, số việc, trạng thái nghỉ/bàn giao. */
  @Get('org-chart')
  async org(@CurrentCtx() ctx: Ctx) {
    const c = await getCompany(ctx.companyId);
    const members = await q(
      `SELECT cm.id, cm.user_id, u.name, u.phone, cm.role, cm.title, cm.supervisor_member_id, cm.department_id, d.name AS department_name,
              EXISTS (SELECT 1 FROM user_avatars a WHERE a.user_id=u.id) AS has_avatar,
              (SELECT string_agg(g.name, ', ') FROM group_members gm JOIN groups g ON g.id=gm.group_id WHERE gm.company_member_id=cm.id AND g.deleted_at IS NULL) AS groups,
              (SELECT count(*) FROM task_assignees ta JOIN tasks t ON t.id=ta.task_id WHERE ta.company_member_id=cm.id AND ta.active AND t.status IN ${OPEN_STATUSES})::int AS open_tasks,
              EXISTS (SELECT 1 FROM leave_requests l WHERE l.member_id=cm.id AND l.status='approved' AND now() BETWEEN l.start_at AND l.end_at) AS on_leave,
              (SELECT code FROM personnel_decisions x WHERE x.member_id=cm.id AND x.status IN ('handover','pending_confirm') LIMIT 1) AS handover_code
         FROM company_members cm JOIN users u ON u.id=cm.user_id LEFT JOIN departments d ON d.id=cm.department_id
        WHERE cm.company_id=$1 AND cm.status='active' ORDER BY array_position(ARRAY['owner','admin','hr','manager','reviewer','handler','employee'], cm.role), u.name`, [ctx.companyId]);
    const departments = await q(`SELECT d.id, d.name, d.head_member_id FROM departments d WHERE d.company_id=$1 ORDER BY d.name`, [ctx.companyId]);
    const groups = await q(`SELECT g.id, g.name, g.manager_member_id, (SELECT array_agg(company_member_id) FROM group_members WHERE group_id=g.id) AS member_ids
                             FROM groups g WHERE g.company_id=$1 AND g.deleted_at IS NULL ORDER BY g.name`, [ctx.companyId]);
    return { company: c.name, members, departments, groups };
  }

  @Get('procedures')
  async procedures(@CurrentCtx() ctx: Ctx) {
    const me = await q1(`SELECT id, role, department_id FROM company_members WHERE id=$1`, [ctx.memberId]);
    const mine = await proceduresFor(ctx.companyId, me);
    const all = isHR(ctx) || ['manager'].includes(ctx.role)
      ? await q(`SELECT p.*, d.name AS department_name FROM procedures p LEFT JOIN departments d ON d.id=p.department_id WHERE p.company_id=$1 ORDER BY p.active DESC, p.category, p.title`, [ctx.companyId])
      : mine;
    return { mine: mine.map((p: any) => p.id), items: all };
  }

  @Get('procedures/:id')
  async procedure(@Param('id') id: string, @CurrentCtx() ctx: Ctx) {
    const p = await q1(`SELECT p.*, d.name AS department_name, u.name AS updated_by_name FROM procedures p LEFT JOIN departments d ON d.id=p.department_id
                         LEFT JOIN company_members cm ON cm.id=p.updated_by LEFT JOIN users u ON u.id=cm.user_id WHERE p.id=$1 AND p.company_id=$2`, [id, ctx.companyId]);
    if (!p) throw Errors.notFound('Quy trình');
    return p;
  }

  @Post('procedures')
  async create(@Body() body: any, @CurrentCtx() ctx: Ctx) {
    if (!isHR(ctx)) throw Errors.forbidden();
    const b = parse(z.object({
      title: z.string().trim().min(5), category: z.string().trim().default('Khác'), summary: z.string().trim().optional(), steps: STEPS,
      audience: z.enum(['all', 'managers', 'department']).default('all'), departmentId: z.string().uuid().optional().nullable(),
      reminder: z.enum(['none', 'daily', 'weekly', 'monthly']).default('weekly'), reference: z.string().optional(),
    }), body);
    if (b.audience === 'department' && !b.departmentId) throw Errors.validation('Chọn bộ phận áp dụng');
    const r = await q1(`INSERT INTO procedures(company_id, department_id, audience, title, category, summary, steps, reference, reminder, updated_by)
                        VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) RETURNING id`,
      [ctx.companyId, b.audience === 'department' ? b.departmentId : null, b.audience, b.title, b.category, b.summary ?? null, JSON.stringify(b.steps), b.reference ?? null, b.reminder, ctx.memberId]);
    await audit(getPool(), ctx, 'procedure', r.id, 'procedure.created');
    return this.procedure(r.id, ctx);
  }

  @Patch('procedures/:id')
  async update(@Param('id') id: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    if (!isHR(ctx)) throw Errors.forbidden();
    const b = parse(z.object({
      title: z.string().trim().min(5).optional(), category: z.string().optional(), summary: z.string().optional().nullable(), steps: STEPS.optional(),
      audience: z.enum(['all', 'managers', 'department']).optional(), departmentId: z.string().uuid().optional().nullable(),
      reminder: z.enum(['none', 'daily', 'weekly', 'monthly']).optional(), active: z.boolean().optional(), notify: z.boolean().default(false),
    }), body);
    const old = await this.procedure(id, ctx);
    const audience = b.audience ?? old.audience;
    const dept = audience === 'department' ? (b.departmentId !== undefined ? b.departmentId : old.department_id) : null;
    if (audience === 'department' && !dept) throw Errors.validation('Chọn bộ phận áp dụng');
    await q(`UPDATE procedures SET title=COALESCE($2,title), category=COALESCE($3,category), summary=CASE WHEN $4::boolean THEN $5 ELSE summary END,
               steps=COALESCE($6, steps), audience=$7, department_id=$8, reminder=COALESCE($9,reminder), active=COALESCE($10,active),
               version=version+1, updated_by=$11, updated_at=now() WHERE id=$1`,
      [id, b.title ?? null, b.category ?? null, 'summary' in b, b.summary ?? null, b.steps ? JSON.stringify(b.steps) : null, audience, dept, b.reminder ?? null, b.active ?? null, ctx.memberId]);
    await audit(getPool(), ctx, 'procedure', id, 'procedure.updated', { version: old.version }, { version: old.version + 1 });
    if (b.notify) {
      const members = await q(`SELECT id, role, department_id FROM company_members WHERE company_id=$1 AND status='active'`, [ctx.companyId]);
      const targets: string[] = [];
      for (const m of members) if ((await proceduresFor(ctx.companyId, m)).some((p: any) => p.id === id)) targets.push(m.id);
      await notify(getPool(), { companyId: ctx.companyId, memberIds: targets, excludeMemberId: ctx.memberId, type: 'procedure.updated', title: `📘 Quy trình được cập nhật: ${b.title ?? old.title}`, refType: 'procedure', refId: id });
    }
    return this.procedure(id, ctx);
  }
}
