import { Body, Controller, Get, Param, Post, Query, Res } from '@nestjs/common';
import { Response } from 'express';
import { join } from 'path';
import { existsSync, createReadStream } from 'fs';
import { DateTime } from 'luxon';
import PDFDocument from 'pdfkit';
import { getPool, q, q1, tx } from '../db/db';
import { CurrentCtx, Ctx, isAdmin, isHR } from '../common/context';
import { AppError, Errors } from '../common/errors';
import { parse, z } from '../common/validate';
import { getCompany, getGroup, getMember } from '../common/access';
import { audit } from '../common/audit';
import { notify } from '../common/notify';
import { saveGeneratedFile, storage } from './files.controller';
import { OPEN_STATUSES } from './tasks.controller';

export const DECISION_TYPE: Record<string, string> = { transfer: 'Điều chuyển', promotion: 'Thăng chức / đổi vai trò', termination: 'Thôi việc' };
const ROLE_VI: Record<string, string> = { owner: 'Chủ doanh nghiệp', admin: 'Quản trị', manager: 'Quản lý', employee: 'Nhân viên', handler: 'Bộ phận xử lý', reviewer: 'Reviewer độc lập', hr: 'Quản lý nhân sự' };

/** Nhân sự đang trong quá trình bàn giao không nhận việc mới cho tới khi quản lý xác nhận bàn giao. */
export async function assertAssignable(db: any, memberIds: (string | null | undefined)[]) {
  const ids = [...new Set(memberIds.filter(Boolean))] as string[];
  if (!ids.length) return;
  const r = await q1(
    `SELECT u.name, d.code FROM personnel_decisions d JOIN company_members cm ON cm.id=d.member_id JOIN users u ON u.id=cm.user_id
      WHERE d.member_id = ANY($1::uuid[]) AND d.status IN ('handover','pending_confirm') LIMIT 1`, [ids], db);
  if (r) throw new AppError('MEMBER_IN_HANDOVER', `${r.name} đang bàn giao công việc theo quyết định ${r.code} — chưa thể nhận việc mới cho tới khi quản lý xác nhận bàn giao`, 409);
}

const SELECT = `
  SELECT d.*, u.name AS member_name, u.phone AS member_phone, cm.role AS current_role, cm.title AS current_title, cm.user_id,
         EXISTS (SELECT 1 FROM user_avatars a WHERE a.user_id=cm.user_id) AS has_avatar,
         cu.name AS confirmer_name, bu.name AS created_by_name, ru.name AS receiver_name, g.name AS new_group_name,
         dp.name AS new_department_name, su.name AS new_supervisor_name, cfu.name AS confirmed_by_name
    FROM personnel_decisions d
    JOIN company_members cm ON cm.id=d.member_id JOIN users u ON u.id=cm.user_id
    JOIN company_members ccm ON ccm.id=d.confirmer_id JOIN users cu ON cu.id=ccm.user_id
    JOIN company_members bcm ON bcm.id=d.created_by JOIN users bu ON bu.id=bcm.user_id
    LEFT JOIN company_members rcm ON rcm.id=d.handover_receiver_id LEFT JOIN users ru ON ru.id=rcm.user_id
    LEFT JOIN company_members scm ON scm.id=d.new_supervisor_id LEFT JOIN users su ON su.id=scm.user_id
    LEFT JOIN company_members fcm ON fcm.id=d.confirmed_by LEFT JOIN users cfu ON cfu.id=fcm.user_id
    LEFT JOIN groups g ON g.id=d.new_group_id LEFT JOIN departments dp ON dp.id=d.new_department_id`;

function decisionPdf(d: any, company: any): Promise<Buffer> {
  return new Promise((resolve) => {
    const doc = new PDFDocument({ size: 'A4', margin: 56 });
    const fonts = join(__dirname, '..', '..', 'assets', 'fonts');
    doc.registerFont('R', join(fonts, 'DejaVuSans.ttf')); doc.registerFont('B', join(fonts, 'DejaVuSans-Bold.ttf'));
    const chunks: Buffer[] = []; doc.on('data', (c) => chunks.push(c)); doc.on('end', () => resolve(Buffer.concat(chunks)));
    const tz = company.timezone;
    const day = (s: any) => DateTime.fromJSDate(new Date(s), { zone: tz }).toFormat('dd/MM/yyyy');
    const dt = (s: any) => DateTime.fromJSDate(new Date(s), { zone: tz }).toFormat('HH:mm dd/MM/yyyy');
    doc.font('B').fontSize(11).text(company.name.toUpperCase(), 56, 56, { width: 230 });
    doc.font('R').fontSize(10).text(`Số: ${d.code}/QĐ`, 56, doc.y + 2);
    doc.font('B').fontSize(11).text('CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM', 300, 56, { width: 240, align: 'center' });
    doc.font('B').fontSize(10).text('Độc lập - Tự do - Hạnh phúc', 300, doc.y, { width: 240, align: 'center' });
    doc.moveDown(3); doc.x = 56;
    doc.font('B').fontSize(16).text(`QUYẾT ĐỊNH`, { align: 'center' });
    doc.font('B').fontSize(12).text(`Về việc ${DECISION_TYPE[d.decision_type].toLowerCase()} nhân sự`, { align: 'center' }).moveDown(1.2);
    doc.font('R').fontSize(11).text(`Căn cứ nhu cầu công việc và quy chế của ${company.name};`).moveDown(0.8);
    doc.font('B').text('QUYẾT ĐỊNH:', { align: 'center' }).moveDown(0.5);
    const p = (k: string, v?: string | null) => { if (!v) return; doc.font('B').text(`${k} `, { continued: true }).font('R').text(v); doc.moveDown(0.3); };
    p('Điều 1.', `${DECISION_TYPE[d.decision_type]} đối với Ông/Bà ${d.member_name} (SĐT ${d.member_phone || '—'}), hiện là ${d.current_title || ROLE_VI[d.current_role]}.`);
    if (d.decision_type === 'termination') p('', 'Chấm dứt làm việc tại công ty kể từ ngày hiệu lực của quyết định này.');
    if (d.new_role) p('  • Vai trò mới:', ROLE_VI[d.new_role]);
    if (d.new_title) p('  • Chức danh mới:', d.new_title);
    if (d.new_group_name) p('  • Nhóm công tác mới:', d.new_group_name);
    if (d.new_department_name) p('  • Bộ phận mới:', d.new_department_name);
    if (d.new_supervisor_name) p('  • Cấp trên trực tiếp:', d.new_supervisor_name);
    p('Điều 2.', `Lý do: ${d.reason}`);
    p('Điều 3.', `Ông/Bà ${d.member_name} có trách nhiệm bàn giao toàn bộ công việc đang thực hiện trước ${dt(d.handover_deadline)}${d.receiver_name ? `, người nhận bàn giao mặc định: ${d.receiver_name}` : ''}. Việc bàn giao được ${d.confirmer_name} xác nhận trên ứng dụng Việc Đến. Trong thời gian bàn giao không nhận việc mới.`);
    p('Điều 4.', `Quyết định có hiệu lực kể từ ngày ${day(d.effective_date)}, sau khi việc bàn giao được xác nhận.`);
    doc.moveDown(1.5);
    doc.font('B').text('NGƯỜI RA QUYẾT ĐỊNH', 330, doc.y, { width: 210, align: 'center' });
    doc.font('R').text(d.created_by_name, 330, doc.y + 40, { width: 210, align: 'center' });
    doc.moveDown(2); doc.x = 56;
    doc.fontSize(9).fillColor('#555').text(`Lập điện tử trên ứng dụng Việc Đến lúc ${dt(d.created_at)}.`, 56);
    doc.end();
  });
}

@Controller('decisions')
export class DecisionsController {
  private async load(ctx: Ctx, id: string, db: any = getPool()) {
    const d = await q1(`${SELECT} WHERE d.id=$1 AND d.company_id=$2`, [id, ctx.companyId], db);
    if (!d) throw Errors.notFound('Quyết định');
    if (d.member_id !== ctx.memberId && d.confirmer_id !== ctx.memberId && d.created_by !== ctx.memberId && !isHR(ctx)) throw Errors.notFound('Quyết định');
    return d;
  }

  @Get()
  async list(@CurrentCtx() ctx: Ctx, @Query('scope') scope = 'mine', @Query('status') status?: string) {
    const where = scope === 'mine' ? 'd.member_id=$2' : isHR(ctx) ? 'TRUE' : '(d.confirmer_id=$2 OR d.created_by=$2)';
    return q(`${SELECT} WHERE d.company_id=$1 AND $2::uuid IS NOT NULL AND ${where} AND ($3::text IS NULL OR d.status = ANY(string_to_array($3, ',')))
              ORDER BY (d.status IN ('handover','pending_confirm')) DESC, d.created_at DESC LIMIT 300`, [ctx.companyId, ctx.memberId, status || null]);
  }

  /** Ra quyết định điều chuyển / thăng chức / thôi việc (Chủ DN, Quản trị, Quản lý nhân sự). */
  @Post()
  async create(@Body() body: any, @CurrentCtx() ctx: Ctx) {
    if (!isHR(ctx)) throw Errors.forbidden('Chỉ Chủ doanh nghiệp, Quản trị hoặc Quản lý nhân sự được ra quyết định nhân sự');
    const b = parse(z.object({
      memberId: z.string().uuid(), decisionType: z.enum(['transfer', 'promotion', 'termination']),
      effectiveDate: z.string().regex(/^\d{4}-\d\d-\d\d$/), handoverDeadline: z.coerce.date(),
      newRole: z.enum(['admin', 'manager', 'employee', 'handler', 'reviewer', 'hr']).optional(), newTitle: z.string().trim().optional(),
      newGroupId: z.string().uuid().optional(), removeFromGroups: z.boolean().default(false), newDepartmentId: z.string().uuid().optional(),
      newSupervisorId: z.string().uuid().optional(), handoverReceiverId: z.string().uuid().optional(), confirmerId: z.string().uuid().optional(),
      reason: z.string().trim().min(10, 'Nêu lý do/căn cứ (≥10 ký tự)'),
    }), body);
    const m = await getMember(ctx, b.memberId);
    if (m.status !== 'active') throw Errors.invalidState('Thành viên không còn hoạt động');
    if (m.role === 'owner') throw Errors.forbidden('Không ra quyết định đối với Chủ doanh nghiệp');
    if (b.memberId === ctx.memberId) throw Errors.forbidden('Không tự ra quyết định cho chính mình');
    if (b.newRole === 'admin' && ctx.role !== 'owner') throw Errors.forbidden('Chỉ Chủ doanh nghiệp được bổ nhiệm Quản trị');
    if (b.decisionType === 'promotion' && !b.newRole && !b.newTitle) throw Errors.validation('Thăng chức cần vai trò hoặc chức danh mới');
    if (b.decisionType === 'transfer' && !b.newGroupId && !b.newDepartmentId && !b.newSupervisorId) throw Errors.validation('Điều chuyển cần nhóm, bộ phận hoặc cấp trên mới');
    if (b.newGroupId) await getGroup(ctx, b.newGroupId);
    for (const x of [b.newSupervisorId, b.handoverReceiverId, b.confirmerId]) if (x) await getMember(ctx, x);
    if (b.handoverReceiverId === b.memberId || b.confirmerId === b.memberId || b.newSupervisorId === b.memberId) throw Errors.validation('Người nhận bàn giao/người xác nhận/cấp trên phải là người khác');
    if (b.handoverReceiverId) await assertAssignable(getPool(), [b.handoverReceiverId]);
    // Người xác nhận bàn giao mặc định: cấp trên trực tiếp -> quản lý nhóm -> người ra quyết định
    let confirmer = b.confirmerId || m.supervisor_member_id;
    if (!confirmer) confirmer = (await q1(`SELECT g.manager_member_id AS id FROM group_members gm JOIN groups g ON g.id=gm.group_id WHERE gm.company_member_id=$1 AND g.manager_member_id<>$1 AND g.deleted_at IS NULL LIMIT 1`, [b.memberId]))?.id;
    confirmer = confirmer || ctx.memberId;
    const id = await tx(async (c) => {
      const open = await q1(`SELECT code FROM personnel_decisions WHERE member_id=$1 AND status IN ('handover','pending_confirm')`, [b.memberId], c);
      if (open) throw new AppError('DECISION_OPEN', `Thành viên đang có quyết định ${open.code} chưa hoàn tất`, 409);
      const seq = await q1(`UPDATE companies SET decision_seq=decision_seq+1 WHERE id=$1 RETURNING decision_seq`, [ctx.companyId], c);
      const r = await q1(
        `INSERT INTO personnel_decisions(company_id, code, member_id, decision_type, effective_date, handover_deadline, new_role, new_title, new_group_id,
            remove_from_groups, new_department_id, new_supervisor_id, handover_receiver_id, confirmer_id, reason, created_by)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16) RETURNING id`,
        [ctx.companyId, `QD-${String(seq.decision_seq).padStart(4, '0')}`, b.memberId, b.decisionType, b.effectiveDate, b.handoverDeadline, b.newRole ?? null,
         b.newTitle ?? null, b.newGroupId ?? null, b.decisionType === 'termination' ? true : b.removeFromGroups, b.newDepartmentId ?? null,
         b.newSupervisorId ?? null, b.handoverReceiverId ?? null, confirmer, b.reason, ctx.memberId], c);
      const d = await q1(`${SELECT} WHERE d.id=$1`, [r.id], c);
      const company = await getCompany(ctx.companyId, c);
      const pdf = await decisionPdf(d, company);
      const file = await saveGeneratedFile(c, ctx.companyId, 'decision', r.id, `Quyet-dinh-${d.code}.pdf`, 'application/pdf', pdf, ctx.memberId);
      await q(`UPDATE personnel_decisions SET pdf_file_id=$2 WHERE id=$1`, [r.id, file.id], c);
      await audit(c, ctx, 'member', b.memberId, 'decision.created', null, { decision: r.id, type: b.decisionType });
      await notify(c, { companyId: ctx.companyId, memberIds: [b.memberId], type: 'decision.issued',
        title: `📜 Quyết định ${DECISION_TYPE[b.decisionType].toLowerCase()} ${d.code}`, body: `Hạn bàn giao công việc: ${DateTime.fromJSDate(b.handoverDeadline, { zone: company.timezone }).toFormat('HH:mm dd/MM/yyyy')}`,
        refType: 'decision', refId: r.id });
      await notify(c, { companyId: ctx.companyId, memberIds: [confirmer], excludeMemberId: ctx.memberId, type: 'decision.notice',
        title: `Quyết định ${d.code}: bạn là người xác nhận bàn giao của ${d.member_name}`, refType: 'decision', refId: r.id });
      if (b.handoverReceiverId) await notify(c, { companyId: ctx.companyId, memberIds: [b.handoverReceiverId], excludeMemberId: confirmer, type: 'decision.notice',
        title: `Quyết định ${d.code}: bạn là người nhận bàn giao mặc định từ ${d.member_name}`, refType: 'decision', refId: r.id });
      return r.id;
    });
    return this.detail(id, ctx);
  }

  @Get(':id')
  async detail(@Param('id') id: string, @CurrentCtx() ctx: Ctx) {
    const d = await this.load(ctx, id);
    const tasks = await q(
      `SELECT t.id, t.code, t.title, t.status, t.due_at, t.group_id, g.name AS group_name, ta.assignment_type, t.pinned
         FROM task_assignees ta JOIN tasks t ON t.id=ta.task_id JOIN groups g ON g.id=t.group_id
        WHERE ta.company_member_id=$1 AND ta.active AND t.status IN ${OPEN_STATUSES} ORDER BY t.due_at`, [d.member_id]);
    const candidates = await q(
      `SELECT DISTINCT cm.id, u.name, gm.group_id FROM group_members gm JOIN company_members cm ON cm.id=gm.company_member_id JOIN users u ON u.id=cm.user_id
        WHERE gm.group_id = ANY($1::uuid[]) AND cm.id<>$2 AND cm.status='active'
          AND NOT EXISTS (SELECT 1 FROM personnel_decisions x WHERE x.member_id=cm.id AND x.status IN ('handover','pending_confirm'))
       UNION SELECT g.manager_member_id, u.name, g.id FROM groups g JOIN company_members cm ON cm.id=g.manager_member_id JOIN users u ON u.id=cm.user_id
        WHERE g.id = ANY($1::uuid[]) AND g.manager_member_id<>$2`, [tasks.map((t) => t.group_id), d.member_id]);
    const isMember = d.member_id === ctx.memberId;
    return {
      ...d, type_label: DECISION_TYPE[d.decision_type], open_tasks: tasks, receiver_candidates: candidates,
      overdue_handover: ['handover', 'pending_confirm'].includes(d.status) && new Date(d.handover_deadline) < new Date(),
      permissions: {
        can_handover: isMember && d.status === 'handover',
        can_confirm: d.status === 'pending_confirm' && !isMember && (d.confirmer_id === ctx.memberId || isAdmin(ctx)),
        can_cancel: ['handover', 'pending_confirm'].includes(d.status) && (d.created_by === ctx.memberId || isHR(ctx)) && !isMember,
      },
    };
  }

  /** Nhân viên gửi bàn giao: người nhận cho từng việc đang làm + ghi chú tài sản/tài liệu. */
  @Post(':id/handover')
  async handover(@Param('id') id: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({
      note: z.string().trim().min(10, 'Ghi chú bàn giao (tài liệu, tài sản, tình trạng việc) tối thiểu 10 ký tự'),
      plan: z.array(z.object({ taskId: z.string().uuid(), receiverId: z.string().uuid().optional().nullable(), note: z.string().optional() })).default([]),
    }), body);
    const d = await this.detail(id, ctx);
    if (!d.permissions.can_handover) throw Errors.forbidden('Chỉ người nhận quyết định được gửi bàn giao');
    const plan: any[] = [];
    for (const t of d.open_tasks) {
      const p = b.plan.find((x) => x.taskId === t.id);
      if (t.assignment_type === 'collaborator') { plan.push({ taskId: t.id, receiverId: null, note: p?.note || 'Rút khỏi vai trò cộng tác viên' }); continue; }
      const receiver = p?.receiverId || d.handover_receiver_id;
      if (!receiver) throw Errors.validation(`Chọn người nhận cho việc ${t.code} "${t.title}"`);
      if (receiver === d.member_id) throw Errors.validation('Người nhận phải là người khác');
      if (!d.receiver_candidates.some((x: any) => x.id === receiver && x.group_id === t.group_id)) {
        throw Errors.validation(`Người nhận việc ${t.code} phải là thành viên/quản lý nhóm "${t.group_name}" và không đang bàn giao`);
      }
      plan.push({ taskId: t.id, receiverId: receiver, note: p?.note || null });
    }
    await assertAssignable(getPool(), plan.map((p) => p.receiverId));
    await tx(async (c) => {
      await q(`UPDATE personnel_decisions SET status='pending_confirm', handover_note=$2, handover_plan=$3, handover_submitted_at=now() WHERE id=$1`, [id, b.note, JSON.stringify(plan)], c);
      await audit(c, ctx, 'decision', id, 'decision.handover_submitted', null, { tasks: plan.length });
      await notify(c, { companyId: ctx.companyId, memberIds: [d.confirmer_id], type: 'decision.handover',
        title: `${d.member_name} đã gửi bàn giao (${d.code}) — cần bạn xác nhận`, body: `${plan.length} việc bàn giao`, refType: 'decision', refId: id });
    });
    return this.detail(id, ctx);
  }

  /** Quản lý xác nhận bàn giao -> chuyển việc cho người nhận và áp dụng quyết định; hoặc trả lại để bổ sung. */
  @Post(':id/confirm')
  async confirm(@Param('id') id: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({ decision: z.enum(['confirm', 'return']), note: z.string().trim().optional() }), body);
    const d = await this.detail(id, ctx);
    if (!d.permissions.can_confirm) throw Errors.forbidden('Bạn không phải người xác nhận bàn giao');
    if (b.decision === 'return') {
      if (!b.note || b.note.length < 5) throw Errors.reasonRequired('Trả lại bàn giao phải nêu nội dung cần bổ sung');
      await tx(async (c) => {
        await q(`UPDATE personnel_decisions SET status='handover', confirm_note=$2 WHERE id=$1`, [id, b.note], c);
        await notify(c, { companyId: ctx.companyId, memberIds: [d.member_id], type: 'decision.handover_returned', title: `Bàn giao ${d.code} cần bổ sung`, body: b.note, refType: 'decision', refId: id });
      });
      return this.detail(id, ctx);
    }
    await tx(async (c) => {
      for (const p of (d.handover_plan || []) as any[]) {
        const t = await q1(`SELECT id, title, status FROM tasks WHERE id=$1`, [p.taskId], c);
        if (!t || !OPEN_STATUSES.includes(t.status)) continue;
        await q(`UPDATE task_assignees SET active=false WHERE task_id=$1 AND company_member_id=$2 AND active`, [p.taskId, d.member_id], c);
        if (p.receiverId) {
          const has = await q1(`SELECT id, assignment_type FROM task_assignees WHERE task_id=$1 AND company_member_id=$2 AND active`, [p.taskId, p.receiverId], c);
          if (has) await q(`UPDATE task_assignees SET active=false WHERE id=$1`, [has.id], c);
          await q(`INSERT INTO task_assignees(task_id, company_member_id, assignment_type) VALUES ($1,$2,'owner')`, [p.taskId, p.receiverId], c);
          await audit(c, ctx, 'task', p.taskId, 'task.updated', { owner: d.member_id }, { owner: p.receiverId }, `Bàn giao theo quyết định ${d.code}${p.note ? ': ' + p.note : ''}`);
          await notify(c, { companyId: ctx.companyId, memberIds: [p.receiverId], type: 'task.assigned', title: `Bạn nhận bàn giao việc: ${t.title}`, body: `Từ ${d.member_name} (${d.code})${p.note ? ' — ' + p.note : ''}`, refType: 'task', refId: p.taskId });
        }
      }
      // Áp dụng quyết định
      if (d.decision_type === 'termination') {
        await q(`UPDATE company_members SET status='inactive', left_at=now() WHERE id=$1`, [d.member_id], c);
        await q(`DELETE FROM group_members WHERE company_member_id=$1`, [d.member_id], c);
      } else {
        await q(`UPDATE company_members SET role=COALESCE($2, role), title=COALESCE($3, title), department_id=COALESCE($4, department_id),
                   supervisor_member_id=COALESCE($5, supervisor_member_id) WHERE id=$1`,
          [d.member_id, d.new_role, d.new_title, d.new_department_id, d.new_supervisor_id], c);
        if (d.remove_from_groups) await q(`DELETE FROM group_members WHERE company_member_id=$1 AND ($2::uuid IS NULL OR group_id<>$2)`, [d.member_id, d.new_group_id], c);
        if (d.new_group_id) await q(`INSERT INTO group_members(group_id, company_member_id) VALUES ($1,$2) ON CONFLICT DO NOTHING`, [d.new_group_id, d.member_id], c);
      }
      await q(`UPDATE personnel_decisions SET status='completed', confirmed_by=$2, confirmed_at=now(), confirm_note=$3 WHERE id=$1`, [id, ctx.memberId, b.note ?? null], c);
      await audit(c, ctx, 'member', d.member_id, 'decision.completed', { role: d.current_role, title: d.current_title }, { decision: id, type: d.decision_type, new_role: d.new_role, new_title: d.new_title });
      await notify(c, { companyId: ctx.companyId, memberIds: [d.member_id, d.created_by], excludeMemberId: ctx.memberId, type: 'decision.completed',
        title: `Bàn giao ${d.code} đã được xác nhận — quyết định có hiệu lực`, refType: 'decision', refId: id });
    });
    return this.detail(id, ctx);
  }

  @Post(':id/cancel')
  async cancel(@Param('id') id: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    const d = await this.detail(id, ctx);
    if (!d.permissions.can_cancel) throw Errors.forbidden();
    await q(`UPDATE personnel_decisions SET status='cancelled', confirm_note=$2 WHERE id=$1`, [id, body?.reason ?? null]);
    await notify(getPool(), { companyId: ctx.companyId, memberIds: [d.member_id, d.confirmer_id], excludeMemberId: ctx.memberId, type: 'decision.cancelled', title: `Quyết định ${d.code} đã bị hủy`, refType: 'decision', refId: id });
    return this.detail(id, ctx);
  }

  @Get(':id/pdf')
  async pdf(@Param('id') id: string, @CurrentCtx() ctx: Ctx, @Res() res: Response) {
    const d = await this.load(ctx, id);
    const f = d.pdf_file_id ? await q1(`SELECT * FROM files WHERE id=$1`, [d.pdf_file_id]) : null;
    if (!f || !existsSync(storage.path(f.storage_key))) throw Errors.notFound('File quyết định');
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename="${f.filename}"`);
    createReadStream(storage.path(f.storage_key)).pipe(res);
  }
}
