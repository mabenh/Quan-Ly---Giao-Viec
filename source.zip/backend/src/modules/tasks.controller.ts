import { Body, Controller, Get, Param, Patch, Post, Query } from '@nestjs/common';
import { PoolClient } from 'pg';
import { getPool, q, q1, tx } from '../db/db';
import { Roles } from '../common/auth.guard';
import { CurrentCtx, Ctx, isAdmin } from '../common/context';
import { AppError, Errors } from '../common/errors';
import { parse, z, zReason } from '../common/validate';
import { canManageGroup, escalationChain, getCompany, getGroup, getMember } from '../common/access';
import { audit } from '../common/audit';
import { taskOps } from './operations.controller';
import { authority, orderAuthorities } from '../common/authority';
import { notify } from '../common/notify';
import { workingMinutesBetween } from '../common/calendar';
import { DateTime } from 'luxon';
import { assertAssignable } from './decisions.controller';
import { activeStage, advanceStages, editScope, linkReportTask, onTaskCompleted, reviewerOf } from './task-flow';
import { DEFAULT_PERFORMANCE } from '../common/defaults';

const COMPLEXITY = z.enum(['simple', 'medium', 'complex', 'very_complex']);
const REQ = z.enum(['normal', 'high', 'very_high']);
const CRITERIA = z.array(z.object({ direction: z.enum(['input', 'output']), criterion: z.string().trim().min(2), weight: z.number().optional() }));
const UNEXPECTED = z.object({
  category: z.enum(['ad_hoc', 'urgent', 'scope_addition', 'external_support']),
  requirementStructure: z.enum(['common', 'diverse']),
  cause: z.enum(['incident', 'superior_request', 'customer', 'resource_shortage', 'support_other_dept', 'other']),
  causeDetail: z.string().optional(),
  requesterMemberId: z.string().uuid().optional().nullable(),
  requestedAt: z.coerce.date().optional(),
  impact: z.string().optional(),
});

export const OPEN_STATUSES = `('not_started','in_progress','pending_review','revision_requested','awaiting_handover')`;

/** Điều kiện SQL giới hạn nhiệm vụ người dùng được xem (D02). Tham số $1=company, $2=member. */
/** Trường nhạy cảm của chuỗi đơn hàng (giá bán, lợi nhuận): chỉ Ban quản trị và người tạo chuỗi (Đặc tả v2.0 mục 7.5, D-06). */
export function sanitizeTask(ctx: Ctx, t: any) {
  if (t && !isAdmin(ctx) && t.created_by !== ctx.memberId) { delete t.order_value; delete t.margin_note; }
  return t;
}

export async function taskVisibilitySql(ctx: Ctx): Promise<string> {
  if (isAdmin(ctx)) return `t.company_id=$1 AND $2::uuid IS NOT NULL`;
  // Bộ phận xử lý giấy phép được xem thông tin công việc có giấy phép gửi tới bộ phận mình
  const permitDept = `EXISTS (SELECT 1 FROM permits p JOIN permit_types pt ON pt.id=p.type_id WHERE p.task_id=t.id AND pt.department_id IS NOT NULL
      AND (pt.department_id IN (SELECT department_id FROM company_members WHERE id=$2) OR pt.department_id IN (SELECT id FROM departments WHERE head_member_id=$2)))`;
  const assigned = `EXISTS (SELECT 1 FROM task_assignees ta WHERE ta.task_id=t.id AND ta.company_member_id=$2 AND ta.active)`;
  const managed = `EXISTS (SELECT 1 FROM groups g WHERE g.id=t.group_id AND (g.manager_member_id=$2 OR g.leader_member_id=$2))`;
  // Quản lý bộ phận liên quan xem được toàn bộ chuỗi đơn hàng có phần việc thuộc nhóm mình
  const chainMgr = `(t.root_id IS NOT NULL OR t.is_chain) AND EXISTS (SELECT 1 FROM tasks x JOIN groups gx ON gx.id=x.group_id WHERE x.root_id=COALESCE(t.root_id, t.id) AND (gx.manager_member_id=$2 OR gx.leader_member_id=$2))`;
  // Việc phân lớp: chỉ thấy phần việc của mình; người giao việc gốc thấy cả cây; người phụ trách việc cha thấy các phần con.
  const tree = `(t.created_by=$2 OR EXISTS (SELECT 1 FROM tasks r WHERE r.id=t.root_id AND r.created_by=$2)
      OR EXISTS (SELECT 1 FROM task_assignees pa WHERE pa.task_id=t.parent_id AND pa.company_member_id=$2 AND pa.active AND pa.assignment_type='owner'))`;
  const inGroupRoot = `(t.parent_id IS NULL AND EXISTS (SELECT 1 FROM group_members gm WHERE gm.group_id=t.group_id AND gm.company_member_id=$2))`;
  const base = `${assigned} OR ${managed} OR ${tree} OR ${permitDept} OR t.approver_id=$2`;
  const auth = await authority(ctx);
  // Quản lý phòng ban (tầng 5) xem việc của các nhóm thuộc phòng ban mình
  const deptView = auth.caps.has('assign_dept') && auth.departmentId ? ` OR EXISTS (SELECT 1 FROM groups gd WHERE gd.id=t.group_id AND gd.department_id='${auth.departmentId}')` : '';
  if (auth.hrScoped) return `t.company_id=$1 AND (${base} OR ${inGroupRoot}${deptView})`;
  if (ctx.role === 'manager' || ctx.role === 'reviewer' || ctx.role === 'hr') return `t.company_id=$1 AND (${base} OR ${inGroupRoot} OR (${chainMgr})${deptView})`;
  if (deptView) return `t.company_id=$1 AND (${base} OR ${inGroupRoot} OR (${chainMgr})${deptView})`;
  if (ctx.role === 'handler') return `t.company_id=$1 AND (${base})`;
  const c = await getCompany(ctx.companyId);
  if (c.settings.policies.employeeTaskVisibility === 'related') return `t.company_id=$1 AND (${base})`;
  return `t.company_id=$1 AND (${base} OR ${inGroupRoot})`;
}

/** Ngày hôm nay theo múi giờ công ty (YYYY-MM-DD). */
export async function localToday(companyId: string, db: any = getPool()): Promise<string> {
  const c = await getCompany(companyId, db);
  return DateTime.now().setZone(c.timezone).toISODate()!;
}

export async function perfConfig(companyId: string, db = getPool() as any) {
  const r = await q1(`SELECT version, config FROM performance_configs WHERE company_id=$1 ORDER BY version DESC LIMIT 1`, [companyId], db);
  return { version: r?.version ?? 0, config: { ...DEFAULT_PERFORMANCE, ...(r?.config || {}) } };
}

const TASK_SELECT = `
  SELECT t.*, g.name AS group_name, tt.name AS task_type_name,
         o.company_member_id AS owner_id, ou.name AS owner_name,
         (t.status IN ${OPEN_STATUSES} AND t.due_at < now()) AS is_overdue,
         (t.first_submitted_at IS NOT NULL AND t.first_submitted_at > t.due_at) AS submitted_late,
         EXISTS (SELECT 1 FROM workplace_reports wr WHERE wr.affected_task_id=t.id AND wr.impact_confirmed) AS impediment_confirmed,
         ut.category AS unexpected_category, ut.requirement_structure, rtc.chain_code AS root_chain_code,
         pt.title AS parent_title, pt.code AS parent_code,
         (SELECT count(*) FROM tasks ch WHERE ch.parent_id=t.id AND ch.status<>'cancelled')::int AS child_count,
         (SELECT count(*) FROM task_comments tc WHERE tc.task_id=t.id)::int AS comment_count,
         (SELECT count(*) FROM task_comments tc WHERE tc.task_id=t.id AND tc.member_id<>$2::uuid
             AND tc.created_at > COALESCE((SELECT r.last_read_at FROM task_comment_reads r WHERE r.task_id=t.id AND r.member_id=$2::uuid), 'epoch'::timestamptz))::int AS unread_comments
    FROM tasks t
    LEFT JOIN tasks pt ON pt.id=t.parent_id
    JOIN groups g ON g.id=t.group_id
    JOIN task_types tt ON tt.id=t.task_type_id
    LEFT JOIN task_assignees o ON o.task_id=t.id AND o.assignment_type='owner' AND o.active
    LEFT JOIN company_members ocm ON ocm.id=o.company_member_id LEFT JOIN users ou ON ou.id=ocm.user_id
    LEFT JOIN unexpected_tasks ut ON ut.task_id=t.id
    LEFT JOIN tasks rtc ON rtc.id=t.root_id`;

@Controller()
export class TasksController {
  // ---------------- Danh sách ----------------
  @Get('tasks')
  async list(@CurrentCtx() ctx: Ctx, @Query() qs: any) {
    const f = parse(z.object({
      status: z.string().optional(), groupId: z.string().uuid().optional(), mine: z.enum(['owner', 'any']).optional(),
      overdue: z.enum(['true', 'false']).optional(), search: z.string().optional(), taskTypeId: z.string().uuid().optional(),
      unexpected: z.enum(['true', 'false']).optional(), dueBefore: z.coerce.date().optional(),
      sort: z.enum(['due_at', 'created_at', 'updated_at']).default('due_at'), page: z.coerce.number().int().min(1).default(1),
      limit: z.coerce.number().int().min(1).max(200).default(30), memberId: z.string().uuid().optional(),
      planDate: z.string().regex(/^\d{4}-\d\d-\d\d$/).optional(), pinned: z.enum(['true']).optional(),
      standing: z.enum(['true', 'false', 'all']).default('false'),
    }), qs);
    const vis = await taskVisibilitySql(ctx);
    const params: any[] = [ctx.companyId, ctx.memberId];
    const where = [vis];
    if (f.standing !== 'all') where.push(f.standing === 'true' ? 't.is_standing' : 'NOT t.is_standing');
    const add = (sql: string, v: any) => { params.push(v); where.push(sql.replace('?', `$${params.length}`)); };
    if (f.status) add(`t.status = ANY(?::text[])`, f.status.split(','));
    if (f.groupId) add(`t.group_id = ?`, f.groupId);
    if (f.taskTypeId) add(`t.task_type_id = ?`, f.taskTypeId);
    if (f.search) { params.push(f.search); const i = params.length; where.push(`(t.title ILIKE '%'||$${i}||'%' OR t.code ILIKE '%'||$${i}||'%')`); }
    if (f.unexpected) where.push(`t.is_unexpected = ${f.unexpected === 'true'}`);
    if (f.overdue === 'true') where.push(`t.status IN ${OPEN_STATUSES} AND t.due_at < now()`);
    if (f.dueBefore) add(`t.due_at <= ?`, f.dueBefore);
    if (f.planDate) add(`t.plan_date = ?::date`, f.planDate);
    if (f.pinned) where.push(`t.pinned`);
    if (f.mine === 'owner') where.push(`o.company_member_id = $2`);
    if (f.mine === 'any') where.push(`EXISTS (SELECT 1 FROM task_assignees ta WHERE ta.task_id=t.id AND ta.company_member_id=$2 AND ta.active)`);
    if (f.memberId) add(`EXISTS (SELECT 1 FROM task_assignees ta WHERE ta.task_id=t.id AND ta.company_member_id=? AND ta.active)`, f.memberId);
    // v11: bình luận mới đẩy nhiệm vụ lên đầu danh sách (sau việc ghim/gấp)
    const order = `t.pinned DESC, t.urgent DESC, (t.last_comment_at > now() - interval '3 days') DESC NULLS LAST, t.last_comment_at DESC NULLS LAST, ` + (f.sort === 'due_at' ? `t.due_at ASC` : `t.${f.sort} DESC`);
    const total = await q1(`SELECT count(*)::int AS n FROM (${TASK_SELECT} WHERE ${where.join(' AND ')}) x`, params);
    params.push(f.limit, (f.page - 1) * f.limit);
    const items = await q(`${TASK_SELECT} WHERE ${where.join(' AND ')} ORDER BY ${order} LIMIT $${params.length - 1} OFFSET $${params.length}`, params);
    return { items: items.map((x) => sanitizeTask(ctx, x)), total: total.n, page: f.page, limit: f.limit };
  }

  // ---------------- Tạo nhiệm vụ (kể cả phần việc con / giai đoạn) ----------------
  @Post('tasks')
  async create(@Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({
      title: z.string().trim().min(3), description: z.string().trim().optional(),
      groupId: z.string().uuid(), ownerMemberId: z.string().uuid().optional(),
      collaboratorIds: z.array(z.string().uuid()).default([]), taskTypeId: z.string().uuid().optional(),
      complexity: COMPLEXITY.optional(), requirementLevel: REQ.optional(), estimatedHours: z.number().positive().optional(),
      dueAt: z.coerce.date().optional(), priority: z.enum(['low', 'normal', 'high', 'urgent']).default('normal'),
      resources: z.string().optional(), criteria: CRITERIA.optional(),
      subitems: z.array(z.object({ title: z.string().min(2), extraHours: z.number().min(0).default(0) })).default([]),
      unexpected: UNEXPECTED.optional(),
      planDate: z.string().regex(/^\d{4}-\d\d-\d\d$/).optional(), urgent: z.boolean().default(false), pinned: z.boolean().default(false),
      parentId: z.string().uuid().optional(), stageNo: z.number().int().min(1).max(20).default(1), sourceReportId: z.string().uuid().optional(),
      isChain: z.boolean().default(false), customerName: z.string().max(200).optional(), importance: z.enum(['normal', 'high', 'critical']).default('normal'),
      orderValue: z.number().min(0).optional(), marginNote: z.string().max(500).optional(),
      standardMinutes: z.number().int().min(1).max(100000).optional(), bufferMinutes: z.number().int().min(0).max(10000).default(0),
      workLocationId: z.string().uuid().optional().nullable(), locationRequired: z.boolean().default(false),
      handoverMode: z.enum(['single', 'stage']).default('single'), productionStandardId: z.string().uuid().optional().nullable(),
      isStanding: z.boolean().default(false), chainCode: z.string().trim().regex(/^[A-Za-z0-9._\-\/]{2,30}$/, 'Mã đơn hàng chỉ gồm chữ, số, - _ . /').optional(),
      autoStart: z.enum(['manual', 'on_handover', 'scheduled']).default('manual'), scheduledStartAt: z.coerce.date().optional().nullable(),
    }), body);
    // Nhiệm vụ thường trực: không có hạn, chỉ dùng để ghi nhận phiên làm việc (có thể chia công đoạn)
    if (b.isStanding && !b.parentId) {
      b.dueAt = b.dueAt || new Date(Date.now() + 3650 * 86400000);
      b.complexity = b.complexity || 'simple'; b.requirementLevel = b.requirementLevel || 'normal'; b.estimatedHours = b.estimatedHours || 1;
      b.criteria = b.criteria?.length ? b.criteria : [{ direction: 'output', criterion: 'Ghi nhận theo phiên làm việc' }];
    }
    if (b.autoStart === 'scheduled' && !b.scheduledStartAt) throw Errors.validation('Chọn thời điểm bắt đầu theo lịch');
    let parent: any = null;
    if (b.parentId) {
      parent = await this.loadTask(ctx, b.parentId);
      if (['completed', 'cancelled'].includes(parent.status)) throw Errors.invalidState('Việc cha đã đóng');
      // Không được chọn giai đoạn đã qua (các phần việc của giai đoạn đó đã xong) — chỉ giai đoạn đang chạy hoặc giai đoạn sau
      const st = await q1(`SELECT min(stage_no) FILTER (WHERE status NOT IN ('completed','cancelled')) AS open_min, max(stage_no) AS max_s FROM tasks WHERE parent_id=$1`, [parent.id]);
      const minAllowed = st.open_min ?? (st.max_s ? st.max_s + 1 : 1);
      if (b.stageNo < minAllowed) throw Errors.validation(`Giai đoạn ${b.stageNo} đã hoàn thành — chỉ chọn giai đoạn ${minAllowed} trở đi`);
      const sc = await editScope(getPool(), ctx, parent);
      const isParentOwner = parent.owner_id === ctx.memberId;
      // Thêm công đoạn (đơn hàng con) vào đơn hàng: chỉ người có quyền lập đơn hàng (Quản lý nhân sự không được)
      if (parent.is_chain && parent.created_by !== ctx.memberId) {
        const au = await authority(ctx);
        if (!au.caps.has('create_order')) throw Errors.forbidden('Chỉ người có quyền lập đơn hàng mới thêm công đoạn vào đơn hàng');
      }
      if (!sc && !isParentOwner) throw Errors.forbidden('Chỉ người giao việc hoặc người phụ trách việc này được chia phần việc con');
      b.description = b.description || parent.description;
      b.taskTypeId = b.taskTypeId || parent.task_type_id;
      b.complexity = b.complexity || 'simple';
      b.requirementLevel = b.requirementLevel || parent.requirement_level;
      b.estimatedHours = b.estimatedHours || 2;
      b.dueAt = b.dueAt || new Date(parent.due_at);
      b.criteria = b.criteria?.length ? b.criteria : [{ direction: 'output', criterion: `Hoàn thành phần việc: ${b.title}` }];
    }
    if (!b.description || b.description.length < 5) throw Errors.validation('Mô tả/phạm vi là bắt buộc');
    // v10: đơn hàng mới luôn thuộc loại "Chuỗi công việc sản xuất" (tính nguyên liệu → bao bì → mua NL → sản xuất → đóng gói → giao hàng)
    if (b.isChain && !b.parentId) {
      let ct = await q1(`SELECT id FROM task_types WHERE company_id=$1 AND name='Chuỗi công việc sản xuất'`, [ctx.companyId]);
      if (!ct) ct = await q1(`INSERT INTO task_types(company_id, name, category) VALUES ($1,'Chuỗi công việc sản xuất','Sản xuất') RETURNING id`, [ctx.companyId]);
      b.taskTypeId = ct.id;
    }
    if (!b.taskTypeId || !b.complexity || !b.requirementLevel || !b.estimatedHours || !b.dueAt || !b.criteria) throw Errors.validation('Thiếu loại việc, độ phức tạp, mức yêu cầu, thời lượng, deadline hoặc tiêu chí');
    if (!b.criteria.some((c) => c.direction === 'output')) throw Errors.validation('Cần ít nhất một tiêu chí đầu ra (điều kiện nghiệm thu)');
    const group = await getGroup(ctx, b.groupId);
    // Giao vào nhóm mình không quản lý (và không có quyền giao chéo) -> chờ cấp quản lý lớn hơn duyệt
    let approver: string | null = null;
    const au = await authority(ctx);
    if (b.isChain && !parent && !au.caps.has('create_order')) {
      throw Errors.forbidden('Chỉ Ban điều hành, quản lý cấp cao hoặc Trưởng/Phó phòng Kinh doanh – Kế hoạch – Sản xuất được lập đơn hàng');
    }
    if (au.hrScoped && au.visibleGroupIds && !au.visibleGroupIds.includes(b.groupId)) throw Errors.forbidden('Quản lý nhân sự chỉ giao việc cho nhóm thuộc phòng nhân sự');
    const inScope = au.assignableGroupIds === null || au.assignableGroupIds.includes(b.groupId);
    if (!parent && !inScope && au.tier >= 6) throw Errors.forbidden('Bạn chỉ giao việc trong nhóm mình phụ trách');
    const orderStage = !!parent && parent.is_chain && au.caps.has('create_order'); // công đoạn đơn hàng được kiểm soát bởi quy trình duyệt đơn
    if (!inScope && !orderStage && !(await canManageGroup(ctx, b.groupId))) {
      const me = await getMember(ctx, ctx.memberId);
      if (!me.can_cross_group_assign) {
        const chain = await escalationChain(ctx.companyId, ctx.memberId);
        approver = chain.find((x) => x !== group.manager_member_id) || chain[0] || null;
        if (!approver) throw Errors.forbidden('Không có cấp quản lý để duyệt việc giao sang nhóm khác');
      }
    }
    // Mặc định giao cho trưởng nhóm của nhóm nhận việc
    const ownerId = b.ownerMemberId || (approver || parent || b.isChain ? (group.leader_member_id || group.manager_member_id) : null);
    if (!ownerId) throw Errors.validation('Chọn người chịu trách nhiệm');
    const owner = await getMember(ctx, ownerId);
    if (owner.status !== 'active') throw Errors.validation('Người chịu trách nhiệm không còn hoạt động');
    await this.assertInGroup(b.groupId, [ownerId, ...b.collaboratorIds]);
    await assertAssignable(getPool(), [ownerId, ...b.collaboratorIds]);
    const tt = await q1(`SELECT id FROM task_types WHERE id=$1 AND company_id=$2 AND active`, [b.taskTypeId, ctx.companyId]);
    if (!tt) throw Errors.notFound('Loại công việc');
    if (b.unexpected?.requesterMemberId) await getMember(ctx, b.unexpected.requesterMemberId);
    if (b.sourceReportId) {
      const w = await q1(`SELECT id, manager_member_id, decided_by, stage FROM workplace_reports WHERE id=$1 AND company_id=$2`, [b.sourceReportId, ctx.companyId]);
      if (!w || w.stage === 'closed') throw Errors.notFound('Báo cáo trở ngại');
      const allowed = isAdmin(ctx) || w.manager_member_id === ctx.memberId || w.decided_by === ctx.memberId
        || !!(await q1(`SELECT 1 FROM escalations WHERE parent_type='workplace_report' AND parent_id=$1 AND to_member_id=$2 AND status='open'`, [w.id, ctx.memberId]))
        || !!(await q1(`WITH RECURSIVE sub AS (SELECT id FROM company_members WHERE supervisor_member_id=$1 UNION SELECT cm.id FROM company_members cm JOIN sub ON cm.supervisor_member_id=sub.id)
                        SELECT 1 FROM sub WHERE id=$2`, [ctx.memberId, w.decided_by || w.manager_member_id]));
      if (!allowed) throw Errors.forbidden('Bạn không phụ trách báo cáo trở ngại này');
    }

    const id = await tx(async (c) => {
      let status = 'not_started';
      const orderPending = !!parent && parent.is_chain && parent.order_status !== 'approved';
      if (approver) status = 'pending_approval';
      else if (orderPending) status = 'waiting';
      else if (parent) {
        const prev = await q1(`SELECT count(*)::int AS n FROM tasks WHERE parent_id=$1 AND stage_no < $2 AND status NOT IN ('completed','cancelled')`, [parent.id, b.stageNo], c);
        if (prev.n > 0) status = 'waiting';
      }
      // Mã: việc độc lập / công đoạn của đơn hàng -> NV-xxxxx; phần việc con của một nhiệm vụ -> mã cha + ".n" (vd NV-00043.1)
      let code: string;
      if (parent && !parent.is_chain) {
        const n = await q1(`SELECT count(*)::int + 1 AS n FROM tasks WHERE parent_id=$1`, [parent.id], c);
        code = `${parent.code}.${n.n}`;
      } else {
        const seq = await q1(`SELECT count(*)::int + 1 AS n FROM tasks WHERE company_id=$1 AND code NOT LIKE '%.%'`, [ctx.companyId], c);
        code = `NV-${String(seq.n).padStart(5, '0')}`;
      }
      const t = await q1(
        `INSERT INTO tasks(company_id, group_id, code, title, description, task_type_id, complexity, requirement_level, estimated_hours,
                           due_at, priority, resources, is_unexpected, created_by, plan_date, original_plan_date, urgent, pinned, pinned_at, pinned_by,
                           parent_id, root_id, stage_no, depth, status, approver_id, source_report_id)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14, COALESCE($15::date, $16::date), COALESCE($15::date, $16::date), $17, $18,
                 CASE WHEN $18 THEN now() END, CASE WHEN $18 THEN $14::uuid END, $19, $20, $21, $22, $23, $24, $25) RETURNING id`,
        [ctx.companyId, b.groupId, code, b.title, b.description, b.taskTypeId, b.complexity,
         b.requirementLevel, b.estimatedHours, b.dueAt, b.priority, b.resources ?? null, !!b.unexpected, ctx.memberId,
         b.planDate ?? null, await localToday(ctx.companyId, c), b.urgent || b.pinned, b.pinned,
         parent?.id ?? null, parent ? (parent.root_id || parent.id) : null, parent ? b.stageNo : 1, parent ? (parent.depth || 0) + 1 : 0,
         status, approver, b.sourceReportId ?? null], c);
      await q(`INSERT INTO task_assignees(task_id, company_member_id, assignment_type) VALUES ($1,$2,'owner')`, [t.id, ownerId], c);
      if (b.workLocationId && !(await q1(`SELECT 1 FROM work_locations WHERE id=$1 AND company_id=$2`, [b.workLocationId, ctx.companyId], c))) throw Errors.notFound('Vị trí');
      if (b.productionStandardId && !(await q1(`SELECT 1 FROM production_standards WHERE id=$1 AND company_id=$2`, [b.productionStandardId, ctx.companyId], c))) throw Errors.notFound('Định mức');
      const isChain = b.isChain && !parent;
      if (isChain && b.chainCode && await q1(`SELECT 1 FROM tasks WHERE company_id=$1 AND chain_code=$2`, [ctx.companyId, b.chainCode], c)) throw new AppError('CHAIN_CODE_TAKEN', `Mã đơn hàng ${b.chainCode} đã tồn tại — chọn đơn hàng đó để thêm nhiệm vụ con`, 409);
      const chainCode = isChain ? (b.chainCode || `DH-${String((await q1(`SELECT count(*)::int + 1 AS n FROM tasks WHERE company_id=$1 AND is_chain`, [ctx.companyId], c)).n).padStart(5, '0')}`) : null;
      const standing = b.isStanding || !!parent?.is_standing;
      if (isChain) {
        const orderStatus = au.caps.has('approve_order') ? 'approved' : 'pending_review';
        await q(`UPDATE tasks SET order_status=$2, order_approved_by=CASE WHEN $2='approved' THEN $3::uuid END, order_approved_at=CASE WHEN $2='approved' THEN now() END WHERE id=$1`, [t.id, orderStatus, ctx.memberId], c);
        // v10: nhóm/người phụ trách điều hành nhận thông báo khi đơn hàng được lập
        const coord = (await q(`SELECT company_member_id AS id FROM group_members WHERE group_id=$1 UNION SELECT manager_member_id FROM groups WHERE id=$1
                                UNION SELECT leader_member_id FROM groups WHERE id=$1 AND leader_member_id IS NOT NULL`, [b.groupId], c)).map((x: any) => x.id);
        await notify(c, { companyId: ctx.companyId, memberIds: [...coord, ownerId], excludeMemberId: ctx.memberId, type: 'order.created',
          title: `Đơn hàng ${chainCode} đã được lập — nhóm/người phụ trách điều hành: bạn`, body: b.title, refType: 'task', refId: t.id });
        if (orderStatus === 'pending_review') {
          const rv = await orderAuthorities(ctx.companyId, 'review_order', [ctx.memberId], c);
          await notify(c, { companyId: ctx.companyId, memberIds: rv.map((x) => x.id), type: 'order.review', title: `Đơn hàng ${chainCode} chờ xem xét: ${b.title}`, refType: 'task', refId: t.id });
        }
      }
      await q(`UPDATE tasks SET is_standing=$2, auto_start=$3, scheduled_start_at=$4, plan_date=CASE WHEN $2 THEN NULL ELSE plan_date END WHERE id=$1`,
        [t.id, standing, standing ? 'manual' : b.autoStart, b.autoStart === 'scheduled' ? b.scheduledStartAt : null], c);
      await q(`UPDATE tasks SET is_chain=$2, chain_code=$3, customer_name=$4, importance=$5, order_value=$6, margin_note=$7, standard_minutes=$8, buffer_minutes=$9,
                 work_location_id=$10, location_required=$11, handover_mode=$12, production_standard_id=$13 WHERE id=$1`,
        [t.id, isChain, chainCode, isChain ? b.customerName ?? null : null, parent ? parent.importance || 'normal' : b.importance, isChain ? b.orderValue ?? null : null, isChain ? b.marginNote ?? null : null,
         b.standardMinutes ?? null, b.bufferMinutes, b.workLocationId ?? (parent ? parent.work_location_id : null), b.locationRequired, b.handoverMode, b.productionStandardId ?? null], c);
      for (const cid of [...new Set(b.collaboratorIds)].filter((x) => x !== ownerId)) {
        await q(`INSERT INTO task_assignees(task_id, company_member_id, assignment_type) VALUES ($1,$2,'collaborator')`, [t.id, cid], c);
      }
      for (const cr of b.criteria!) {
        await q(`INSERT INTO task_criteria(task_id, version, direction, criterion, weight, created_by) VALUES ($1,1,$2,$3,$4,$5)`,
          [t.id, cr.direction, cr.criterion, cr.weight ?? null, ctx.memberId], c);
      }
      for (const s of b.subitems) {
        await q(`INSERT INTO task_subitems(task_id, title, extra_hours, scope_version, created_by, requested_by) VALUES ($1,$2,$3,1,$4,$4)`,
          [t.id, s.title, s.extraHours, ctx.memberId], c);
      }
      if (b.unexpected) await this.insertUnexpected(c, t.id, b.unexpected, ctx);
      if (parent && parent.status === 'not_started') await q(`UPDATE tasks SET status='in_progress', started_at=COALESCE(started_at, now()) WHERE id=$1`, [parent.id], c);
      await audit(c, ctx, 'task', t.id, 'task.created', null, { title: b.title, owner: ownerId, due_at: b.dueAt, parent: parent?.id, stage: b.stageNo, status });
      if (b.sourceReportId && status !== 'pending_approval') await linkReportTask(c, ctx, b.sourceReportId, t.id, ownerId, b.dueAt!);
      // v10: thành viên nhóm công đoạn nhận thông báo lần 1 khi đơn hàng đã được lập/duyệt (lần 2 khi công đoạn bắt đầu)
      if (parent?.is_chain && !orderPending) {
        const gm = (await q(`SELECT company_member_id AS id FROM group_members WHERE group_id=$1 UNION SELECT manager_member_id FROM groups WHERE id=$1`, [b.groupId], c)).map((x: any) => x.id);
        await notify(c, { companyId: ctx.companyId, memberIds: gm, excludeMemberId: ctx.memberId, type: 'order.stage_assigned', title: `Đơn hàng ${parent.chain_code}: nhóm bạn phụ trách công đoạn ${b.stageNo} — ${b.title}`,
          body: 'Bạn sẽ được báo lần nữa khi công đoạn bắt đầu', refType: 'task', refId: parent.id, dedupeKey: `order-stage:${parent.id}:${b.groupId}:${b.stageNo}` });
      }
      if (status === 'pending_approval') {
        await notify(c, { companyId: ctx.companyId, memberIds: [approver], type: 'task.approval', title: `Duyệt giao việc sang nhóm ${group.name}: ${b.title}`, body: `${ctx.name} đề nghị`, refType: 'task', refId: t.id });
      } else if (!orderPending) {
        await notify(c, {
          companyId: ctx.companyId, memberIds: [ownerId, ...b.collaboratorIds], excludeMemberId: ctx.memberId, type: 'task.assigned',
          title: status === 'waiting' ? `Bạn được giao phần việc (giai đoạn ${b.stageNo}): ${b.title}` : `Bạn được giao nhiệm vụ: ${b.title}`,
          body: status === 'waiting' ? 'Sẽ bắt đầu khi giai đoạn trước hoàn thành' : `Hạn: ${b.dueAt!.toISOString()}`, refType: 'task', refId: t.id,
        });
      }
      return t.id;
    });
    return this.detail(id, ctx);
  }

  /** Cấp quản lý duyệt việc giao sang nhóm mà người giao không quản lý. */
  @Post('tasks/:id/approve')
  async approve(@Param('id') id: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({ decision: z.enum(['approve', 'reject']), note: z.string().trim().optional() }), body);
    const t = await this.loadTask(ctx, id);
    if (t.status !== 'pending_approval') throw Errors.invalidState('Việc không ở trạng thái chờ duyệt');
    if (t.approver_id !== ctx.memberId && !isAdmin(ctx)) throw Errors.forbidden('Bạn không phải người duyệt');
    if (b.decision === 'reject' && (!b.note || b.note.length < 5)) throw Errors.reasonRequired('Từ chối phải nêu lý do');
    await tx(async (c) => {
      if (b.decision === 'approve') {
        let status = 'not_started';
        if (t.parent_id) {
          const prev = await q1(`SELECT count(*)::int AS n FROM tasks WHERE parent_id=$1 AND stage_no < $2 AND status NOT IN ('completed','cancelled','pending_approval')`, [t.parent_id, t.stage_no], c);
          if (prev.n > 0) status = 'waiting';
        }
        await q(`UPDATE tasks SET status=$2, approval_note=$3, updated_at=now() WHERE id=$1`, [id, status, b.note ?? null], c);
        if (t.source_report_id) await linkReportTask(c, { ...ctx, memberId: t.created_by } as Ctx, t.source_report_id, id, t.owner_id, new Date(t.due_at));
        const g = await q1(`SELECT manager_member_id FROM groups WHERE id=$1`, [t.group_id], c);
        await notify(c, { companyId: ctx.companyId, memberIds: [t.owner_id, g.manager_member_id, t.created_by], excludeMemberId: ctx.memberId, type: 'task.assigned',
          title: `Việc "${t.title}" đã được duyệt giao cho nhóm ${t.group_name}`, refType: 'task', refId: id });
      } else {
        await q(`UPDATE tasks SET status='cancelled', cancel_reason=$2, cancelled_by=$3, cancel_is_business_decision=true, approval_note=$2, updated_at=now() WHERE id=$1`, [id, b.note, ctx.memberId], c);
        await notify(c, { companyId: ctx.companyId, memberIds: [t.created_by], type: 'task.cancelled', title: `Không duyệt giao việc "${t.title}"`, body: b.note, refType: 'task', refId: id });
        await advanceStages(c, ctx.companyId, t.parent_id);
      }
      await audit(c, ctx, 'task', id, 'task.approval_' + b.decision, null, null, b.note ?? null);
    });
    return this.detail(id, ctx);
  }

  private async insertUnexpected(c: PoolClient, taskId: string, u: z.infer<typeof UNEXPECTED>, ctx: Ctx) {
    await q(`INSERT INTO unexpected_tasks(task_id, category, requirement_structure, cause, cause_detail, requester_member_id, requested_at, impact)
             VALUES ($1,$2,$3,$4,$5,$6,COALESCE($7, now()),$8)
             ON CONFLICT (task_id) DO UPDATE SET category=$2, requirement_structure=$3, cause=$4, cause_detail=$5, requester_member_id=$6, impact=$8`,
      [taskId, u.category, u.requirementStructure, u.cause, u.causeDetail ?? null, u.requesterMemberId ?? ctx.memberId, u.requestedAt ?? null, u.impact ?? null], c);
    await q(`UPDATE tasks SET is_unexpected=true WHERE id=$1`, [taskId], c);
  }

  /** Đánh dấu nhiệm vụ đã có là công việc đột xuất (POST /unexpected-tasks). */
  @Post('unexpected-tasks')
  @Roles('owner', 'admin', 'manager')
  async markUnexpected(@Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(UNEXPECTED.extend({ taskId: z.string().uuid(), actualHours: z.number().min(0).optional() }), body);
    const t = await this.loadTask(ctx, b.taskId);
    if (!(await canManageGroup(ctx, t.group_id))) throw Errors.forbidden();
    await tx(async (c) => {
      await this.insertUnexpected(c, t.id, b, ctx);
      if (b.actualHours !== undefined) await q(`UPDATE unexpected_tasks SET actual_hours=$2 WHERE task_id=$1`, [t.id, b.actualHours], c);
      await audit(c, ctx, 'task', t.id, 'task.marked_unexpected', null, b);
    });
    return this.detail(t.id, ctx);
  }

  private async assertCanAssignInGroup(ctx: Ctx, groupId: string) {
    if (await canManageGroup(ctx, groupId)) return;
    const me = await getMember(ctx, ctx.memberId);
    if (!me.can_cross_group_assign) throw Errors.forbidden('Bạn chỉ được giao việc trong nhóm mình quản lý (D03)');
  }

  private async assertInGroup(groupId: string, memberIds: string[]) {
    const ids = [...new Set(memberIds)];
    const rows = await q(
      `SELECT x.id FROM unnest($2::uuid[]) AS x(id)
        WHERE NOT EXISTS (SELECT 1 FROM group_members gm WHERE gm.group_id=$1 AND gm.company_member_id=x.id)
          AND NOT EXISTS (SELECT 1 FROM groups g WHERE g.id=$1 AND g.manager_member_id=x.id)`, [groupId, ids]);
    if (rows.length) throw Errors.validation('Người được giao phải là thành viên của nhóm', rows.map((r) => r.id));
  }

  async loadTask(ctx: Ctx, id: string, db: any = getPool()) {
    const vis = await taskVisibilitySql(ctx);
    const t = await q1(`${TASK_SELECT} WHERE t.id=$3 AND ${vis}`, [ctx.companyId, ctx.memberId, id], db);
    if (!t) throw Errors.notFound('Nhiệm vụ');
    return t;
  }

  // ---------------- Chi tiết ----------------
  @Get('tasks/:id')
  async detail(@Param('id') id: string, @CurrentCtx() ctx: Ctx) {
    const t = await this.loadTask(ctx, id);
    const permits = await q(`SELECT p.id, p.code, p.status, p.mode, p.valid_from, p.valid_to, p.review_status, p.holder_id, pt.name AS type_name, pt.icon AS type_icon, hu.name AS holder_name
         FROM permits p JOIN permit_types pt ON pt.id=p.type_id JOIN company_members hcm ON hcm.id=p.holder_id JOIN users hu ON hu.id=hcm.user_id
        WHERE p.task_id=$1 AND p.status<>'cancelled' ORDER BY p.created_at`, [id]);
    const [assignees, criteria, subitems, comments, submissions, evaluations, activities, files, reports, overtime, unexpected] = await Promise.all([
      q(`SELECT ta.company_member_id AS member_id, ta.assignment_type, ta.active, u.name FROM task_assignees ta
           JOIN company_members cm ON cm.id=ta.company_member_id JOIN users u ON u.id=cm.user_id WHERE ta.task_id=$1 ORDER BY ta.created_at`, [id]),
      q(`SELECT tc.*, u.name AS created_by_name FROM task_criteria tc JOIN company_members cm ON cm.id=tc.created_by JOIN users u ON u.id=cm.user_id
          WHERE tc.task_id=$1 ORDER BY tc.version DESC, tc.direction, tc.created_at`, [id]),
      q(`SELECT s.*, u.name AS requested_by_name FROM task_subitems s LEFT JOIN company_members cm ON cm.id=s.requested_by LEFT JOIN users u ON u.id=cm.user_id
          WHERE s.task_id=$1 ORDER BY s.created_at`, [id]),
      q(`SELECT c.*, u.name, rc.content AS reply_content, ru.name AS reply_name FROM task_comments c JOIN company_members cm ON cm.id=c.member_id JOIN users u ON u.id=cm.user_id
           LEFT JOIN task_comments rc ON rc.id=c.reply_to_id LEFT JOIN company_members rcm ON rcm.id=rc.member_id LEFT JOIN users ru ON ru.id=rcm.user_id
          WHERE c.task_id=$1 ORDER BY c.created_at`, [id]),
      q(`SELECT s.*, u.name FROM task_submissions s JOIN company_members cm ON cm.id=s.submitted_by JOIN users u ON u.id=cm.user_id WHERE s.task_id=$1 ORDER BY s.created_at DESC`, [id]),
      q(`SELECT e.*, u.name AS evaluator_name FROM task_evaluations e JOIN company_members cm ON cm.id=e.evaluator_id JOIN users u ON u.id=cm.user_id WHERE e.task_id=$1 ORDER BY e.created_at DESC`, [id]),
      q(`SELECT a.id, a.action, a.old_value, a.new_value, a.reason, a.created_at, u.name AS actor_name FROM audit_logs a
           LEFT JOIN company_members cm ON cm.id=a.actor_id LEFT JOIN users u ON u.id=cm.user_id
          WHERE a.entity_type='task' AND a.entity_id=$1 ORDER BY a.id DESC`, [id]),
      q(`SELECT id, filename, mime, size, created_at FROM files WHERE parent_type='task' AND parent_id=$1 ORDER BY created_at`, [id]),
      q(`SELECT id, code, category, severity, status, impact_confirmed, description FROM workplace_reports WHERE affected_task_id=$1 ORDER BY created_at DESC`, [id]),
      q(`SELECT o.id, o.start_at, o.end_at, o.minutes, o.approval_status, u.name FROM overtime_records o JOIN company_members cm ON cm.id=o.member_id
           JOIN users u ON u.id=cm.user_id WHERE o.task_id=$1 ORDER BY o.start_at DESC`, [id]),
      q1(`SELECT ut.*, u.name AS requester_name FROM unexpected_tasks ut LEFT JOIN company_members cm ON cm.id=ut.requester_member_id
            LEFT JOIN users u ON u.id=cm.user_id WHERE ut.task_id=$1`, [id]),
    ]);
    const currentVersion = criteria.reduce((m, c) => Math.max(m, c.version), 0);
    const vis = await taskVisibilitySql(ctx);
    const children = await q(`${TASK_SELECT} WHERE t.parent_id=$3 AND ${vis} ORDER BY t.stage_no, t.created_at`, [ctx.companyId, ctx.memberId, id]);
    const hiddenChildren = (await q1(`SELECT count(*)::int AS n FROM tasks WHERE parent_id=$1 AND status<>'cancelled'`, [id])).n - children.filter((x: any) => x.status !== 'cancelled').length;
    const stageNow = await activeStage(getPool(), id);
    const branchRecords = await q(`SELECT r.id, r.title, r.claimed_minutes, r.status, r.final_decision, u.name AS employee_name, r.created_at FROM employee_work_records r
       JOIN company_members cm ON cm.id=r.employee_id JOIN users u ON u.id=cm.user_id WHERE r.related_task_id=$1 ORDER BY r.created_at`, [id]);
    const scope = await editScope(getPool(), ctx, t);
    const reviewer = await reviewerOf(getPool(), t);
    const reviewerName = reviewer ? (await q1(`SELECT u.name FROM company_members cm JOIN users u ON u.id=cm.user_id WHERE cm.id=$1`, [reviewer]))?.name : null;
    const canManage = !!scope;
    const isOwner = t.owner_id === ctx.memberId;
    const company = await getCompany(ctx.companyId);
    let suggestedScheduleScore: number | null = null;
    if (t.first_submitted_at) {
      if (new Date(t.first_submitted_at) <= new Date(t.due_at) || t.impediment_confirmed) suggestedScheduleScore = 100;
      else {
        const lateMin = workingMinutesBetween(new Date(t.due_at), new Date(t.first_submitted_at), company.settings.calendar, company.timezone);
        suggestedScheduleScore = Math.max(0, 100 - Math.ceil(lateMin / 480) * 10);
      }
    }
    const ops = await taskOps(ctx, t);
    return {
      ...sanitizeTask(ctx, { ...t }), assignees, unexpected, ...ops,
      criteria: criteria.filter((c) => c.version === currentVersion), criteria_history: criteria, criteria_version: currentVersion,
      subitems, comments, submissions, evaluations, activities, files, reports, overtime, permits,
      children, hidden_children: Math.max(0, hiddenChildren), active_stage: stageNow, branch_records: branchRecords,
      reviewer_id: reviewer, reviewer_name: reviewerName, edit_scope: scope,
      approver_name: t.approver_id ? (await q1(`SELECT u.name FROM company_members cm JOIN users u ON u.id=cm.user_id WHERE cm.id=$1`, [t.approver_id]))?.name : null,
      suggested_schedule_score: suggestedScheduleScore,
      permissions: {
        can_manage: canManage,
        can_edit_full: scope === 'full' && !['completed', 'cancelled'].includes(t.status),
        can_edit_assignees: !!scope && !['completed', 'cancelled'].includes(t.status),
        can_start: isOwner && ['not_started', 'revision_requested'].includes(t.status) && t.child_count === 0,
        can_submit: isOwner && ['in_progress', 'revision_requested'].includes(t.status) && t.child_count === 0,
        can_review: reviewer === ctx.memberId && t.status === 'pending_review',
        can_cancel: scope === 'full' && !['completed', 'cancelled'].includes(t.status),
        can_add_children: (scope === 'full' || isOwner) && !['completed', 'cancelled', 'pending_review', 'pending_approval'].includes(t.status) && (scope === 'full' || ['manager', 'admin', 'owner', 'hr'].includes(ctx.role)),
        can_approve: t.status === 'pending_approval' && (t.approver_id === ctx.memberId || isAdmin(ctx)),
        can_comment: true,
      },
    };
  }

  // ---------------- Cập nhật (quản lý) ----------------
  @Patch('tasks/:id')
  async update(@Param('id') id: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({
      title: z.string().trim().min(3).optional(), description: z.string().trim().min(5).optional(),
      dueAt: z.coerce.date().optional(), estimatedHours: z.number().positive().optional(),
      complexity: COMPLEXITY.optional(), requirementLevel: REQ.optional(), resources: z.string().optional().nullable(),
      priority: z.enum(['low', 'normal', 'high', 'urgent']).optional(), taskTypeId: z.string().uuid().optional(),
      criteria: CRITERIA.optional(), ownerMemberId: z.string().uuid().optional(), collaboratorIds: z.array(z.string().uuid()).optional(),
      reason: z.string().trim().optional(),
    }), body);
    const t = await this.loadTask(ctx, id);
    const scope = await editScope(getPool(), ctx, t);
    if (!scope) throw Errors.forbidden('Chỉ người giao việc hoặc quản lý nhóm được sửa nhiệm vụ');
    if (scope === 'assignees' && Object.keys(b).some((k) => !['ownerMemberId', 'collaboratorIds', 'reason'].includes(k))) {
      throw Errors.forbidden('Quản lý lớp dưới chỉ được thêm/đổi người phụ trách; nội dung việc do người giao việc điều chỉnh');
    }
    if (['completed', 'cancelled'].includes(t.status)) throw Errors.invalidState('Nhiệm vụ đã nghiệm thu/đóng, không thể sửa');
    const started = t.status !== 'not_started';
    const scopeChange = b.criteria || b.description || b.dueAt || b.complexity || b.requirementLevel || b.estimatedHours;
    if ((started && scopeChange) || b.ownerMemberId) {
      if (!b.reason || b.reason.length < 5) throw Errors.reasonRequired('Thay đổi phạm vi/deadline/người phụ trách sau khi giao phải có lý do (lưu vết điều chỉnh)');
    }
    if (b.criteria && !b.criteria.some((c) => c.direction === 'output')) throw Errors.validation('Cần ít nhất một tiêu chí đầu ra');
    if (b.ownerMemberId || b.collaboratorIds) {
      await this.assertInGroup(t.group_id, [...(b.ownerMemberId ? [b.ownerMemberId] : []), ...(b.collaboratorIds || [])]);
      await assertAssignable(getPool(), [b.ownerMemberId && b.ownerMemberId !== t.owner_id ? b.ownerMemberId : null, ...(b.collaboratorIds || [])]);
    }

    await tx(async (c) => {
      const old: any = {}; const nw: any = {};
      const fields: [keyof typeof b, string][] = [['title', 'title'], ['description', 'description'], ['dueAt', 'due_at'], ['estimatedHours', 'estimated_hours'],
        ['complexity', 'complexity'], ['requirementLevel', 'requirement_level'], ['resources', 'resources'], ['priority', 'priority'], ['taskTypeId', 'task_type_id']];
      const sets: string[] = []; const params: any[] = [id];
      for (const [k, col] of fields) {
        if (b[k] === undefined) continue;
        params.push(b[k]); sets.push(`${col}=$${params.length}`);
        old[col] = t[col]; nw[col] = b[k];
      }
      let scopeBump = false;
      if (b.criteria) {
        const cur = await q1(`SELECT COALESCE(max(version),0) AS v FROM task_criteria WHERE task_id=$1`, [id], c);
        const v = cur.v + 1;
        for (const cr of b.criteria) {
          await q(`INSERT INTO task_criteria(task_id, version, direction, criterion, weight, created_by) VALUES ($1,$2,$3,$4,$5,$6)`,
            [id, v, cr.direction, cr.criterion, cr.weight ?? null, ctx.memberId], c);
        }
        old.criteria_version = cur.v; nw.criteria_version = v; scopeBump = true;
      }
      if (b.description || b.dueAt || b.estimatedHours) scopeBump = true;
      if (scopeBump) sets.push(`scope_version=scope_version+1`);
      sets.push(`updated_at=now()`);
      await q(`UPDATE tasks SET ${sets.join(', ')} WHERE id=$1`, params, c);

      if (b.ownerMemberId && b.ownerMemberId !== t.owner_id) {
        await q(`UPDATE task_assignees SET active=false WHERE task_id=$1 AND assignment_type='owner' AND active`, [id], c);
        await q(`UPDATE task_assignees SET active=false WHERE task_id=$1 AND company_member_id=$2 AND active`, [id, b.ownerMemberId], c);
        await q(`INSERT INTO task_assignees(task_id, company_member_id, assignment_type) VALUES ($1,$2,'owner')`, [id, b.ownerMemberId], c);
        old.owner = t.owner_id; nw.owner = b.ownerMemberId;
        await notify(c, { companyId: ctx.companyId, memberIds: [b.ownerMemberId], type: 'task.assigned', title: `Bạn được giao lại nhiệm vụ: ${t.title}`, refType: 'task', refId: id });
      }
      if (b.collaboratorIds) {
        const ownerNow = b.ownerMemberId || t.owner_id;
        await q(`UPDATE task_assignees SET active=false WHERE task_id=$1 AND assignment_type='collaborator' AND active`, [id], c);
        for (const cid of [...new Set(b.collaboratorIds)].filter((x) => x !== ownerNow)) {
          await q(`INSERT INTO task_assignees(task_id, company_member_id, assignment_type) VALUES ($1,$2,'collaborator')`, [id, cid], c);
        }
        nw.collaborators = b.collaboratorIds;
      }
      await audit(c, ctx, 'task', id, b.dueAt ? 'task.deadline_changed' : 'task.updated', old, nw, b.reason ?? null);
      const assignees = await q(`SELECT company_member_id FROM task_assignees WHERE task_id=$1 AND active`, [id], c);
      if (b.dueAt || b.criteria) {
        await notify(c, {
          companyId: ctx.companyId, memberIds: assignees.map((a) => a.company_member_id), excludeMemberId: ctx.memberId,
          type: b.dueAt ? 'task.deadline_changed' : 'task.scope_changed',
          title: b.dueAt ? `Deadline nhiệm vụ "${t.title}" đã thay đổi` : `Phạm vi/tiêu chí nhiệm vụ "${t.title}" đã thay đổi`,
          body: b.reason, refType: 'task', refId: id,
        });
      }
    });
    return this.detail(id, ctx);
  }

  // ---------------- Workflow ----------------
  @Post('tasks/:id/start')
  async start(@Param('id') id: string, @CurrentCtx() ctx: Ctx) {
    const t = await this.loadTask(ctx, id);
    if (t.owner_id !== ctx.memberId) throw Errors.forbidden('Chỉ người chịu trách nhiệm được bắt đầu nhiệm vụ');
    if (!['not_started', 'revision_requested'].includes(t.status)) throw Errors.invalidState('Nhiệm vụ không ở trạng thái có thể bắt đầu');
    await tx(async (c) => {
      await q(`UPDATE tasks SET status='in_progress', started_at=COALESCE(started_at, now()), updated_at=now() WHERE id=$1`, [id], c);
      await audit(c, ctx, 'task', id, 'task.status', { status: t.status }, { status: 'in_progress' });
    });
    return this.detail(id, ctx);
  }

  @Post('tasks/:id/submit')
  async submit(@Param('id') id: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({ outputDescription: z.string().trim().min(5, 'Mô tả kết quả bàn giao là bắt buộc'), completionPercent: z.number().int().min(0).max(100).default(100),
      links: z.array(z.string().trim().url('Đường link tài liệu không hợp lệ').max(500)).max(10).default([]),
      supporterIds: z.array(z.string().uuid()).max(30).default([]) }), body);
    const t = await this.loadTask(ctx, id);
    if (t.owner_id !== ctx.memberId) throw Errors.forbidden('Chỉ người chịu trách nhiệm được bàn giao');
    // v11: hoàn thành nhiệm vụ bắt buộc khai báo vị trí hiện tại của thiết bị
    { const { equipmentCompletionIssue } = await import('./task-extras.controller'); const issue = await equipmentCompletionIssue(id); if (issue) throw new AppError('EQUIPMENT_CHECK_REQUIRED', issue, 409); }
    for (const sid of b.supporterIds) if (!(await q1(`SELECT 1 FROM company_members WHERE id=$1 AND company_id=$2`, [sid, ctx.companyId]))) throw Errors.notFound('Người hỗ trợ');
    if (t.child_count > 0) throw Errors.invalidState('Việc có phần việc con sẽ tự chuyển nghiệm thu khi các phần con hoàn thành');
    // v9: nhiệm vụ bàn giao bên ngoài chỉ hoàn thành khi người nhận xác nhận QR hoặc giải trình được người giao duyệt
    if (t.external_handover) throw new AppError('HANDOVER_REQUIRED', 'Nhiệm vụ bàn giao bên ngoài: dùng "Đề nghị bàn giao" (QR/link cho người nhận) hoặc "Không thể bàn giao – gửi giải trình"', 409);
    if (!['in_progress', 'revision_requested'].includes(t.status)) throw Errors.invalidState('Chỉ bàn giao khi nhiệm vụ đang thực hiện');
    await tx(async (c) => {
      await q(`INSERT INTO task_submissions(task_id, submitted_by, output_description, completion_percent, links, supporter_ids) VALUES ($1,$2,$3,$4,$5,$6)`, [id, ctx.memberId, b.outputDescription, b.completionPercent, JSON.stringify(b.links), JSON.stringify(b.supporterIds.filter((x) => x !== ctx.memberId))], c);
      if (b.supporterIds.length) await notify(c, { companyId: ctx.companyId, memberIds: b.supporterIds, excludeMemberId: ctx.memberId, type: 'task.supporter_listed', title: `${ctx.name} ghi tên bạn là người hỗ trợ: ${t.title}`, refType: 'task', refId: id });
      // Bàn giao kết quả: phiên đang chạy trên việc này được đóng (lưu lịch sử)
      await q(`UPDATE work_sessions SET ended_at=now(), end_reason='complete' WHERE task_id=$1 AND ended_at IS NULL`, [id], c);
      await q(`UPDATE tasks SET status='pending_review', submitted_at=now(), first_submitted_at=COALESCE(first_submitted_at, now()),
                 started_at=COALESCE(started_at, now()), updated_at=now() WHERE id=$1`, [id], c);
      await audit(c, ctx, 'task', id, 'task.submitted', { status: t.status }, { status: 'pending_review', completion: b.completionPercent });
      const rv = await reviewerOf(c, t);
      await notify(c, { companyId: ctx.companyId, memberIds: [rv], excludeMemberId: ctx.memberId,
        type: 'task.pending_review', title: `Nhiệm vụ chờ nghiệm thu: ${t.title}`, refType: 'task', refId: id });
    });
    return this.detail(id, ctx);
  }

  @Post('tasks/:id/review')
  async review(@Param('id') id: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({
      decision: z.enum(['approve', 'revision']),
      scores: z.record(z.string(), z.number().min(0).max(100)).optional(),
      comment: z.string().trim().optional(),
    }), body);
    const t = await this.loadTask(ctx, id);
    const rv = await reviewerOf(getPool(), t);
    if (rv !== ctx.memberId) throw Errors.forbidden('Nghiệm thu do quản lý trực tiếp của nhóm thực hiện (không nhảy cấp)');
    if (t.owner_id === ctx.memberId) throw Errors.forbidden('Không được tự nghiệm thu nhiệm vụ của chính mình');
    if (t.status !== 'pending_review') throw Errors.invalidState('Nhiệm vụ không ở trạng thái chờ nghiệm thu');
    const { version, config } = await perfConfig(ctx.companyId);
    const kind = t.is_unexpected ? 'unexpected' : 'regular';
    let total: number | null = null; let scores: any = null;
    if (b.decision === 'approve') {
      const weights: Record<string, number> = kind === 'regular' ? config.regularWeights : config.unexpectedWeights;
      scores = {};
      for (const k of Object.keys(weights)) {
        const v = b.scores?.[k];
        if (v === undefined) throw Errors.validation(`Thiếu điểm tiêu chí "${k}" (thang 0-100)`);
        scores[k] = v;
      }
      total = Math.round(Object.entries(weights).reduce((s, [k, w]) => s + w * scores[k], 0) * 100) / 100;
    } else if (!b.comment || b.comment.length < 5) {
      throw Errors.reasonRequired('Yêu cầu chỉnh sửa phải nêu rõ nội dung cần sửa');
    }
    if (t.external_handover && b.decision === 'approve' && !['CONFIRMED', 'EXCEPTION_APPROVED'].includes(t.handover_status)) {
      throw new AppError('HANDOVER_REQUIRED', 'Chưa có xác nhận của người nhận hoặc giải trình được duyệt — không thể nghiệm thu hoàn thành', 409);
    }
    await tx(async (c) => {
      await q(`INSERT INTO task_evaluations(task_id, evaluator_id, decision, kind, scores, total_score, config_version, comment)
               VALUES ($1,$2,$3,$4,$5,$6,$7,$8)`,
        [id, ctx.memberId, b.decision === 'approve' ? 'approved' : 'revision_requested', kind, scores ? JSON.stringify(scores) : null, total, version, b.comment ?? null], c);
      if (b.decision === 'approve') {
        await q(`UPDATE tasks SET status='completed', completed_at=now(), updated_at=now() WHERE id=$1`, [id], c);
        await onTaskCompleted(c, ctx.companyId, id);
      } else {
        await q(`UPDATE tasks SET status='revision_requested', revision_count=revision_count+1, updated_at=now() WHERE id=$1`, [id], c);
      }
      await audit(c, ctx, 'task', id, b.decision === 'approve' ? 'task.approved' : 'task.revision_requested', { status: t.status },
        { status: b.decision === 'approve' ? 'completed' : 'revision_requested', total_score: total }, b.comment ?? null);
      const assignees = await q(`SELECT company_member_id FROM task_assignees WHERE task_id=$1 AND active`, [id], c);
      await notify(c, {
        companyId: ctx.companyId, memberIds: assignees.map((a) => a.company_member_id), excludeMemberId: ctx.memberId,
        type: b.decision === 'approve' ? 'task.completed' : 'task.revision_requested',
        title: b.decision === 'approve' ? `Nhiệm vụ "${t.title}" đã được nghiệm thu (${total} điểm)` : `Nhiệm vụ "${t.title}" cần chỉnh sửa`,
        body: b.comment, refType: 'task', refId: id,
      });
    });
    return this.detail(id, ctx);
  }

  @Post('tasks/:id/cancel')
  async cancel(@Param('id') id: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({ reason: zReason, businessDecision: z.boolean().default(true) }), body);
    const t = await this.loadTask(ctx, id);
    if ((await editScope(getPool(), ctx, t)) !== 'full') throw Errors.forbidden('Chỉ người giao việc được hủy nhiệm vụ');
    if (['completed', 'cancelled'].includes(t.status)) throw Errors.invalidState('Nhiệm vụ đã đóng');
    await tx(async (c) => {
      await q(`UPDATE tasks SET status='cancelled', cancel_reason=$2, cancelled_by=$3, cancel_is_business_decision=$4, updated_at=now() WHERE id=$1`,
        [id, b.reason, ctx.memberId, b.businessDecision], c);
      await audit(c, ctx, 'task', id, 'task.cancelled', { status: t.status }, { status: 'cancelled' }, b.reason);
      await q(`UPDATE tasks SET status='cancelled', cancel_reason=$2, cancelled_by=$3, updated_at=now() WHERE parent_id=$1 AND status NOT IN ('completed','cancelled')`, [id, 'Việc cha bị hủy: ' + b.reason, ctx.memberId], c);
      await advanceStages(c, ctx.companyId, t.parent_id);
      const assignees = await q(`SELECT company_member_id FROM task_assignees WHERE task_id=$1 AND active`, [id], c);
      await notify(c, { companyId: ctx.companyId, memberIds: assignees.map((a) => a.company_member_id), excludeMemberId: ctx.memberId,
        type: 'task.cancelled', title: `Nhiệm vụ "${t.title}" đã bị hủy`, body: b.reason, refType: 'task', refId: id });
    });
    return this.detail(id, ctx);
  }

  @Post('tasks/:id/comments')
  async comment(@Param('id') id: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({ content: z.string().trim().min(1).max(5000), replyToId: z.string().uuid().optional().nullable() }), body);
    const t = await this.loadTask(ctx, id);
    if (b.replyToId && !(await q1(`SELECT 1 FROM task_comments WHERE id=$1 AND task_id=$2`, [b.replyToId, id]))) throw Errors.notFound('Bình luận được trích dẫn');
    await tx(async (c) => {
      await q(`INSERT INTO task_comments(task_id, member_id, content, reply_to_id) VALUES ($1,$2,$3,$4)`, [id, ctx.memberId, b.content, b.replyToId ?? null], c);
      await q(`UPDATE tasks SET last_comment_at=now() WHERE id=$1`, [id], c);
      await q(`INSERT INTO task_comment_reads(task_id, member_id, last_read_at) VALUES ($1,$2,now()) ON CONFLICT (task_id, member_id) DO UPDATE SET last_read_at=now()`, [id, ctx.memberId], c);
      if (b.replyToId) {
        const orig = await q1(`SELECT member_id FROM task_comments WHERE id=$1`, [b.replyToId], c);
        await notify(c, { companyId: ctx.companyId, memberIds: [orig?.member_id], excludeMemberId: ctx.memberId, type: 'task.comment_reply', title: `${ctx.name} trả lời bình luận của bạn: ${t.title}`, body: b.content.slice(0, 140), refType: 'task', refId: id });
      }
      const assignees = await q(`SELECT company_member_id FROM task_assignees WHERE task_id=$1 AND active`, [id], c);
      const g = await q1(`SELECT manager_member_id FROM groups WHERE id=$1`, [t.group_id], c);
      await notify(c, { companyId: ctx.companyId, memberIds: [...assignees.map((a) => a.company_member_id), g.manager_member_id], excludeMemberId: ctx.memberId,
        type: 'task.comment', title: `${ctx.name} bình luận: ${t.title}`, body: b.content.slice(0, 140), refType: 'task', refId: id });
    });
    return this.detail(id, ctx);
  }

  // Yêu cầu thành phần (việc đa dạng) — lưu thời điểm thêm, người yêu cầu, ảnh hưởng thời lượng, phiên bản phạm vi
  @Post('tasks/:id/subitems')
  async addSubitem(@Param('id') id: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({ title: z.string().trim().min(2), extraHours: z.number().min(0).default(0), requestedBy: z.string().uuid().optional(), reason: z.string().optional() }), body);
    const t = await this.loadTask(ctx, id);
    if (!(await canManageGroup(ctx, t.group_id))) throw Errors.forbidden();
    if (['completed', 'cancelled'].includes(t.status)) throw Errors.invalidState('Nhiệm vụ đã đóng');
    if (b.requestedBy) await getMember(ctx, b.requestedBy);
    await tx(async (c) => {
      const nv = await q1(`UPDATE tasks SET scope_version=scope_version+1, estimated_hours=estimated_hours+$2, updated_at=now() WHERE id=$1 RETURNING scope_version`, [id, b.extraHours], c);
      await q(`INSERT INTO task_subitems(task_id, title, extra_hours, scope_version, created_by, requested_by) VALUES ($1,$2,$3,$4,$5,$6)`,
        [id, b.title, b.extraHours, nv.scope_version, ctx.memberId, b.requestedBy ?? ctx.memberId], c);
      await audit(c, ctx, 'task', id, 'task.subitem_added', { scope_version: t.scope_version }, { scope_version: nv.scope_version, title: b.title, extra_hours: b.extraHours }, b.reason ?? null);
      const assignees = await q(`SELECT company_member_id FROM task_assignees WHERE task_id=$1 AND active`, [id], c);
      await notify(c, { companyId: ctx.companyId, memberIds: assignees.map((a) => a.company_member_id), excludeMemberId: ctx.memberId,
        type: 'task.scope_changed', title: `Thêm yêu cầu mới vào "${t.title}"`, body: b.title, refType: 'task', refId: id });
    });
    return this.detail(id, ctx);
  }

  @Patch('tasks/:id/subitems/:sid')
  async toggleSubitem(@Param('id') id: string, @Param('sid') sid: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({ done: z.boolean() }), body);
    const t = await this.loadTask(ctx, id);
    const isAssignee = await q1(`SELECT 1 FROM task_assignees WHERE task_id=$1 AND company_member_id=$2 AND active`, [id, ctx.memberId]);
    if (!isAssignee && !(await canManageGroup(ctx, t.group_id))) throw Errors.forbidden();
    const r = await q1(`UPDATE task_subitems SET done=$3, updated_at=now() WHERE id=$1 AND task_id=$2 RETURNING id`, [sid, id, b.done]);
    if (!r) throw Errors.notFound('Yêu cầu thành phần');
    await audit(getPool(), ctx, 'task', id, 'task.subitem_updated', null, { subitem: sid, done: b.done });
    return this.detail(id, ctx);
  }

  // ---------------- Ghim việc gấp ----------------
  @Post('tasks/:id/pin')
  async pin(@Param('id') id: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({ pinned: z.boolean(), urgent: z.boolean().optional(), note: z.string().trim().optional() }), body);
    const t = await this.loadTask(ctx, id);
    if (!(await canManageGroup(ctx, t.group_id))) throw Errors.forbidden('Chỉ quản lý được ghim/gỡ ghim việc gấp');
    const urgent = b.urgent ?? b.pinned;
    await tx(async (c) => {
      await q(`UPDATE tasks SET pinned=$2, urgent=$3, pinned_at=CASE WHEN $2 THEN now() ELSE NULL END, pinned_by=CASE WHEN $2 THEN $4::uuid ELSE NULL END,
                 priority=CASE WHEN $3 THEN 'urgent' WHEN priority='urgent' THEN 'high' ELSE priority END, updated_at=now() WHERE id=$1`,
        [id, b.pinned, urgent, ctx.memberId], c);
      await audit(c, ctx, 'task', id, b.pinned ? 'task.pinned' : 'task.unpinned', { pinned: t.pinned, urgent: t.urgent }, { pinned: b.pinned, urgent }, b.note ?? null);
      const assignees = await q(`SELECT company_member_id FROM task_assignees WHERE task_id=$1 AND active`, [id], c);
      await notify(c, { companyId: ctx.companyId, memberIds: assignees.map((a) => a.company_member_id), excludeMemberId: ctx.memberId,
        type: b.pinned ? 'task.pinned' : 'task.unpinned',
        title: b.pinned ? `📌 Việc gấp được ghim: ${t.title}` : urgent ? `Việc "${t.title}" đã gỡ ghim (vẫn là việc gấp)` : `Việc "${t.title}" đã gỡ ghim, không còn là việc gấp`,
        body: b.note, refType: 'task', refId: id });
    });
    return this.detail(id, ctx);
  }

  /** Đổi ngày thực hiện trong lịch (người chịu trách nhiệm hoặc quản lý). */
  @Post('tasks/:id/plan')
  async plan(@Param('id') id: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({ planDate: z.string().regex(/^\d{4}-\d\d-\d\d$/) }), body);
    const t = await this.loadTask(ctx, id);
    if (t.owner_id !== ctx.memberId && !(await canManageGroup(ctx, t.group_id))) throw Errors.forbidden();
    await q(`UPDATE tasks SET plan_date=$2, original_plan_date=$2, carry_count=0, updated_at=now() WHERE id=$1`, [id, b.planDate]);
    await audit(getPool(), ctx, 'task', id, 'task.plan_date', { plan_date: t.plan_date }, { plan_date: b.planDate });
    return this.detail(id, ctx);
  }
}
