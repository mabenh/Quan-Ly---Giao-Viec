import { Body, Controller, Get, Param, Patch, Post, Query } from '@nestjs/common';
import { PoolClient } from 'pg';
import { getPool, q, q1, tx } from '../db/db';
import { Roles } from '../common/auth.guard';
import { CurrentCtx, Ctx, isAdmin } from '../common/context';
import { Errors } from '../common/errors';
import { parse, z, zReason } from '../common/validate';
import { canManageGroup, getCompany, getGroup, getMember } from '../common/access';
import { audit } from '../common/audit';
import { notify } from '../common/notify';
import { workingMinutesBetween } from '../common/calendar';
import { DEFAULT_PERFORMANCE } from '../common/defaults';

const COMPLEXITY = z.enum(['simple', 'medium', 'complex', 'very_complex']);
const REQ = z.enum(['normal', 'high', 'very_high']);
const CRITERIA = z.array(z.object({ direction: z.enum(['input', 'output']), criterion: z.string().trim().min(2), weight: z.number().optional() }));
const UNEXPECTED = z.object({
  category: z.enum(['ad_hoc', 'urgent', 'scope_addition', 'external_support']),
  requirementStructure: z.enum(['common', 'diverse']),
  cause: z.enum(['incident', 'superior_request', 'customer', 'resource_shortage', 'support_other_dept', 'other']),
  causeDetail: z.string().optional(),
  requesterMemberId: z.string().uuid().optional().nullable(),
  requestedAt: z.coerce.date().optional(),
  impact: z.string().optional(),
});

export const OPEN_STATUSES = `('not_started','in_progress','pending_review','revision_requested')`;

/** Điều kiện SQL giới hạn nhiệm vụ người dùng được xem (D02). Tham số $1=company, $2=member. */
export async function taskVisibilitySql(ctx: Ctx): Promise<string> {
  if (isAdmin(ctx)) return `t.company_id=$1 AND $2::uuid IS NOT NULL`;
  const assigned = `EXISTS (SELECT 1 FROM task_assignees ta WHERE ta.task_id=t.id AND ta.company_member_id=$2 AND ta.active)`;
  const managed = `EXISTS (SELECT 1 FROM groups g WHERE g.id=t.group_id AND g.manager_member_id=$2)`;
  const inGroup = `EXISTS (SELECT 1 FROM group_members gm WHERE gm.group_id=t.group_id AND gm.company_member_id=$2)`;
  if (ctx.role === 'manager' || ctx.role === 'reviewer') return `t.company_id=$1 AND (${assigned} OR ${managed} OR ${inGroup} OR t.created_by=$2)`;
  if (ctx.role === 'handler') return `t.company_id=$1 AND (${assigned})`;
  const c = await getCompany(ctx.companyId);
  if (c.settings.policies.employeeTaskVisibility === 'related') return `t.company_id=$1 AND ${assigned}`;
  return `t.company_id=$1 AND (${assigned} OR ${inGroup})`;
}

export async function perfConfig(companyId: string, db = getPool() as any) {
  const r = await q1(`SELECT version, config FROM performance_configs WHERE company_id=$1 ORDER BY version DESC LIMIT 1`, [companyId], db);
  return { version: r?.version ?? 0, config: { ...DEFAULT_PERFORMANCE, ...(r?.config || {}) } };
}

const TASK_SELECT = `
  SELECT t.*, g.name AS group_name, tt.name AS task_type_name,
         o.company_member_id AS owner_id, ou.name AS owner_name,
         (t.status IN ${OPEN_STATUSES} AND t.due_at < now()) AS is_overdue,
         (t.first_submitted_at IS NOT NULL AND t.first_submitted_at > t.due_at) AS submitted_late,
         EXISTS (SELECT 1 FROM workplace_reports wr WHERE wr.affected_task_id=t.id AND wr.impact_confirmed) AS impediment_confirmed,
         ut.category AS unexpected_category, ut.requirement_structure
    FROM tasks t
    JOIN groups g ON g.id=t.group_id
    JOIN task_types tt ON tt.id=t.task_type_id
    LEFT JOIN task_assignees o ON o.task_id=t.id AND o.assignment_type='owner' AND o.active
    LEFT JOIN company_members ocm ON ocm.id=o.company_member_id LEFT JOIN users ou ON ou.id=ocm.user_id
    LEFT JOIN unexpected_tasks ut ON ut.task_id=t.id`;

@Controller()
export class TasksController {
  // ---------------- Danh sách ----------------
  @Get('tasks')
  async list(@CurrentCtx() ctx: Ctx, @Query() qs: any) {
    const f = parse(z.object({
      status: z.string().optional(), groupId: z.string().uuid().optional(), mine: z.enum(['owner', 'any']).optional(),
      overdue: z.enum(['true', 'false']).optional(), search: z.string().optional(), taskTypeId: z.string().uuid().optional(),
      unexpected: z.enum(['true', 'false']).optional(), dueBefore: z.coerce.date().optional(),
      sort: z.enum(['due_at', 'created_at', 'updated_at']).default('due_at'), page: z.coerce.number().int().min(1).default(1),
      limit: z.coerce.number().int().min(1).max(100).default(30), memberId: z.string().uuid().optional(),
    }), qs);
    const vis = await taskVisibilitySql(ctx);
    const params: any[] = [ctx.companyId, ctx.memberId];
    const where = [vis];
    const add = (sql: string, v: any) => { params.push(v); where.push(sql.replace('?', `$${params.length}`)); };
    if (f.status) add(`t.status = ANY(?::text[])`, f.status.split(','));
    if (f.groupId) add(`t.group_id = ?`, f.groupId);
    if (f.taskTypeId) add(`t.task_type_id = ?`, f.taskTypeId);
    if (f.search) { params.push(f.search); const i = params.length; where.push(`(t.title ILIKE '%'||$${i}||'%' OR t.code ILIKE '%'||$${i}||'%')`); }
    if (f.unexpected) where.push(`t.is_unexpected = ${f.unexpected === 'true'}`);
    if (f.overdue === 'true') where.push(`t.status IN ${OPEN_STATUSES} AND t.due_at < now()`);
    if (f.dueBefore) add(`t.due_at <= ?`, f.dueBefore);
    if (f.mine === 'owner') where.push(`o.company_member_id = $2`);
    if (f.mine === 'any') where.push(`EXISTS (SELECT 1 FROM task_assignees ta WHERE ta.task_id=t.id AND ta.company_member_id=$2 AND ta.active)`);
    if (f.memberId) add(`EXISTS (SELECT 1 FROM task_assignees ta WHERE ta.task_id=t.id AND ta.company_member_id=? AND ta.active)`, f.memberId);
    const order = f.sort === 'due_at' ? `t.due_at ASC` : `t.${f.sort} DESC`;
    const total = await q1(`SELECT count(*)::int AS n FROM (${TASK_SELECT} WHERE ${where.join(' AND ')}) x`, params);
    params.push(f.limit, (f.page - 1) * f.limit);
    const items = await q(`${TASK_SELECT} WHERE ${where.join(' AND ')} ORDER BY ${order} LIMIT $${params.length - 1} OFFSET $${params.length}`, params);
    return { items, total: total.n, page: f.page, limit: f.limit };
  }

  // ---------------- Tạo nhiệm vụ ----------------
  @Post('tasks')
  @Roles('owner', 'admin', 'manager')
  async create(@Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({
      title: z.string().trim().min(3), description: z.string().trim().min(5, 'Mô tả/phạm vi là bắt buộc'),
      groupId: z.string().uuid(), ownerMemberId: z.string().uuid(),
      collaboratorIds: z.array(z.string().uuid()).default([]), taskTypeId: z.string().uuid(),
      complexity: COMPLEXITY, requirementLevel: REQ, estimatedHours: z.number().positive(),
      dueAt: z.coerce.date(), priority: z.enum(['low', 'normal', 'high', 'urgent']).default('normal'),
      resources: z.string().optional(), criteria: CRITERIA,
      subitems: z.array(z.object({ title: z.string().min(2), extraHours: z.number().min(0).default(0) })).default([]),
      unexpected: UNEXPECTED.optional(),
    }), body);
    if (!b.criteria.some((c) => c.direction === 'output')) throw Errors.validation('Cần ít nhất một tiêu chí đầu ra (điều kiện nghiệm thu)');
    await getGroup(ctx, b.groupId);
    await this.assertCanAssignInGroup(ctx, b.groupId);
    const owner = await getMember(ctx, b.ownerMemberId);
    if (owner.status !== 'active') throw Errors.validation('Người chịu trách nhiệm không còn hoạt động');
    await this.assertInGroup(b.groupId, [b.ownerMemberId, ...b.collaboratorIds]);
    const tt = await q1(`SELECT id FROM task_types WHERE id=$1 AND company_id=$2 AND active`, [b.taskTypeId, ctx.companyId]);
    if (!tt) throw Errors.notFound('Loại công việc');
    if (b.unexpected?.requesterMemberId) await getMember(ctx, b.unexpected.requesterMemberId);

    const id = await tx(async (c) => {
      const seq = await q1(`SELECT count(*)::int + 1 AS n FROM tasks WHERE company_id=$1`, [ctx.companyId], c);
      const t = await q1(
        `INSERT INTO tasks(company_id, group_id, code, title, description, task_type_id, complexity, requirement_level, estimated_hours,
                           due_at, priority, resources, is_unexpected, created_by)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14) RETURNING id`,
        [ctx.companyId, b.groupId, `NV-${String(seq.n).padStart(5, '0')}`, b.title, b.description, b.taskTypeId, b.complexity,
         b.requirementLevel, b.estimatedHours, b.dueAt, b.priority, b.resources ?? null, !!b.unexpected, ctx.memberId], c);
      await q(`INSERT INTO task_assignees(task_id, company_member_id, assignment_type) VALUES ($1,$2,'owner')`, [t.id, b.ownerMemberId], c);
      for (const cid of [...new Set(b.collaboratorIds)].filter((x) => x !== b.ownerMemberId)) {
        await q(`INSERT INTO task_assignees(task_id, company_member_id, assignment_type) VALUES ($1,$2,'collaborator')`, [t.id, cid], c);
      }
      for (const cr of b.criteria) {
        await q(`INSERT INTO task_criteria(task_id, version, direction, criterion, weight, created_by) VALUES ($1,1,$2,$3,$4,$5)`,
          [t.id, cr.direction, cr.criterion, cr.weight ?? null, ctx.memberId], c);
      }
      for (const s of b.subitems) {
        await q(`INSERT INTO task_subitems(task_id, title, extra_hours, scope_version, created_by, requested_by) VALUES ($1,$2,$3,1,$4,$4)`,
          [t.id, s.title, s.extraHours, ctx.memberId], c);
      }
      if (b.unexpected) await this.insertUnexpected(c, t.id, b.unexpected, ctx);
      await audit(c, ctx, 'task', t.id, 'task.created', null, { title: b.title, owner: b.ownerMemberId, due_at: b.dueAt, criteria_version: 1 });
      await notify(c, {
        companyId: ctx.companyId, memberIds: [b.ownerMemberId, ...b.collaboratorIds], excludeMemberId: ctx.memberId,
        type: 'task.assigned', title: `Bạn được giao nhiệm vụ: ${b.title}`, body: `Hạn: ${b.dueAt.toISOString()}`, refType: 'task', refId: t.id,
      });
      return t.id;
    });
    return this.detail(id, ctx);
  }

  private async insertUnexpected(c: PoolClient, taskId: string, u: z.infer<typeof UNEXPECTED>, ctx: Ctx) {
    await q(`INSERT INTO unexpected_tasks(task_id, category, requirement_structure, cause, cause_detail, requester_member_id, requested_at, impact)
             VALUES ($1,$2,$3,$4,$5,$6,COALESCE($7, now()),$8)
             ON CONFLICT (task_id) DO UPDATE SET category=$2, requirement_structure=$3, cause=$4, cause_detail=$5, requester_member_id=$6, impact=$8`,
      [taskId, u.category, u.requirementStructure, u.cause, u.causeDetail ?? null, u.requesterMemberId ?? ctx.memberId, u.requestedAt ?? null, u.impact ?? null], c);
    await q(`UPDATE tasks SET is_unexpected=true WHERE id=$1`, [taskId], c);
  }

  /** Đánh dấu nhiệm vụ đã có là công việc đột xuất (POST /unexpected-tasks). */
  @Post('unexpected-tasks')
  @Roles('owner', 'admin', 'manager')
  async markUnexpected(@Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(UNEXPECTED.extend({ taskId: z.string().uuid(), actualHours: z.number().min(0).optional() }), body);
    const t = await this.loadTask(ctx, b.taskId);
    if (!(await canManageGroup(ctx, t.group_id))) throw Errors.forbidden();
    await tx(async (c) => {
      await this.insertUnexpected(c, t.id, b, ctx);
      if (b.actualHours !== undefined) await q(`UPDATE unexpected_tasks SET actual_hours=$2 WHERE task_id=$1`, [t.id, b.actualHours], c);
      await audit(c, ctx, 'task', t.id, 'task.marked_unexpected', null, b);
    });
    return this.detail(t.id, ctx);
  }

  private async assertCanAssignInGroup(ctx: Ctx, groupId: string) {
    if (await canManageGroup(ctx, groupId)) return;
    const me = await getMember(ctx, ctx.memberId);
    if (!me.can_cross_group_assign) throw Errors.forbidden('Bạn chỉ được giao việc trong nhóm mình quản lý (D03)');
  }

  private async assertInGroup(groupId: string, memberIds: string[]) {
    const ids = [...new Set(memberIds)];
    const rows = await q(
      `SELECT x.id FROM unnest($2::uuid[]) AS x(id)
        WHERE NOT EXISTS (SELECT 1 FROM group_members gm WHERE gm.group_id=$1 AND gm.company_member_id=x.id)
          AND NOT EXISTS (SELECT 1 FROM groups g WHERE g.id=$1 AND g.manager_member_id=x.id)`, [groupId, ids]);
    if (rows.length) throw Errors.validation('Người được giao phải là thành viên của nhóm', rows.map((r) => r.id));
  }

  async loadTask(ctx: Ctx, id: string, db: any = getPool()) {
    const vis = await taskVisibilitySql(ctx);
    const t = await q1(`${TASK_SELECT} WHERE t.id=$3 AND ${vis}`, [ctx.companyId, ctx.memberId, id], db);
    if (!t) throw Errors.notFound('Nhiệm vụ');
    return t;
  }

  // ---------------- Chi tiết ----------------
  @Get('tasks/:id')
  async detail(@Param('id') id: string, @CurrentCtx() ctx: Ctx) {
    const t = await this.loadTask(ctx, id);
    const [assignees, criteria, subitems, comments, submissions, evaluations, activities, files, reports, overtime, unexpected] = await Promise.all([
      q(`SELECT ta.company_member_id AS member_id, ta.assignment_type, ta.active, u.name FROM task_assignees ta
           JOIN company_members cm ON cm.id=ta.company_member_id JOIN users u ON u.id=cm.user_id WHERE ta.task_id=$1 ORDER BY ta.created_at`, [id]),
      q(`SELECT tc.*, u.name AS created_by_name FROM task_criteria tc JOIN company_members cm ON cm.id=tc.created_by JOIN users u ON u.id=cm.user_id
          WHERE tc.task_id=$1 ORDER BY tc.version DESC, tc.direction, tc.created_at`, [id]),
      q(`SELECT s.*, u.name AS requested_by_name FROM task_subitems s LEFT JOIN company_members cm ON cm.id=s.requested_by LEFT JOIN users u ON u.id=cm.user_id
          WHERE s.task_id=$1 ORDER BY s.created_at`, [id]),
      q(`SELECT c.*, u.name FROM task_comments c JOIN company_members cm ON cm.id=c.member_id JOIN users u ON u.id=cm.user_id WHERE c.task_id=$1 ORDER BY c.created_at`, [id]),
      q(`SELECT s.*, u.name FROM task_submissions s JOIN company_members cm ON cm.id=s.submitted_by JOIN users u ON u.id=cm.user_id WHERE s.task_id=$1 ORDER BY s.created_at DESC`, [id]),
      q(`SELECT e.*, u.name AS evaluator_name FROM task_evaluations e JOIN company_members cm ON cm.id=e.evaluator_id JOIN users u ON u.id=cm.user_id WHERE e.task_id=$1 ORDER BY e.created_at DESC`, [id]),
      q(`SELECT a.id, a.action, a.old_value, a.new_value, a.reason, a.created_at, u.name AS actor_name FROM audit_logs a
           LEFT JOIN company_members cm ON cm.id=a.actor_id LEFT JOIN users u ON u.id=cm.user_id
          WHERE a.entity_type='task' AND a.entity_id=$1 ORDER BY a.id DESC`, [id]),
      q(`SELECT id, filename, mime, size, created_at FROM files WHERE parent_type='task' AND parent_id=$1 ORDER BY created_at`, [id]),
      q(`SELECT id, code, category, severity, status, impact_confirmed, description FROM workplace_reports WHERE affected_task_id=$1 ORDER BY created_at DESC`, [id]),
      q(`SELECT o.id, o.start_at, o.end_at, o.minutes, o.approval_status, u.name FROM overtime_records o JOIN company_members cm ON cm.id=o.member_id
           JOIN users u ON u.id=cm.user_id WHERE o.task_id=$1 ORDER BY o.start_at DESC`, [id]),
      q1(`SELECT ut.*, u.name AS requester_name FROM unexpected_tasks ut LEFT JOIN company_members cm ON cm.id=ut.requester_member_id
            LEFT JOIN users u ON u.id=cm.user_id WHERE ut.task_id=$1`, [id]),
    ]);
    const currentVersion = criteria.reduce((m, c) => Math.max(m, c.version), 0);
    const canManage = await canManageGroup(ctx, t.group_id);
    const isOwner = t.owner_id === ctx.memberId;
    const company = await getCompany(ctx.companyId);
    let suggestedScheduleScore: number | null = null;
    if (t.first_submitted_at) {
      if (new Date(t.first_submitted_at) <= new Date(t.due_at) || t.impediment_confirmed) suggestedScheduleScore = 100;
      else {
        const lateMin = workingMinutesBetween(new Date(t.due_at), new Date(t.first_submitted_at), company.settings.calendar, company.timezone);
        suggestedScheduleScore = Math.max(0, 100 - Math.ceil(lateMin / 480) * 10);
      }
    }
    return {
      ...t, assignees, unexpected,
      criteria: criteria.filter((c) => c.version === currentVersion), criteria_history: criteria, criteria_version: currentVersion,
      subitems, comments, submissions, evaluations, activities, files, reports, overtime,
      suggested_schedule_score: suggestedScheduleScore,
      permissions: {
        can_manage: canManage,
        can_start: isOwner && ['not_started', 'revision_requested'].includes(t.status),
        can_submit: isOwner && ['in_progress', 'revision_requested'].includes(t.status),
        can_review: canManage && t.status === 'pending_review',
        can_cancel: canManage && !['completed', 'cancelled'].includes(t.status),
        can_comment: true,
      },
    };
  }

  // ---------------- Cập nhật (quản lý) ----------------
  @Patch('tasks/:id')
  async update(@Param('id') id: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({
      title: z.string().trim().min(3).optional(), description: z.string().trim().min(5).optional(),
      dueAt: z.coerce.date().optional(), estimatedHours: z.number().positive().optional(),
      complexity: COMPLEXITY.optional(), requirementLevel: REQ.optional(), resources: z.string().optional().nullable(),
      priority: z.enum(['low', 'normal', 'high', 'urgent']).optional(), taskTypeId: z.string().uuid().optional(),
      criteria: CRITERIA.optional(), ownerMemberId: z.string().uuid().optional(), collaboratorIds: z.array(z.string().uuid()).optional(),
      reason: z.string().trim().optional(),
    }), body);
    const t = await this.loadTask(ctx, id);
    if (!(await canManageGroup(ctx, t.group_id))) throw Errors.forbidden('Chỉ quản lý nhóm được sửa nhiệm vụ');
    if (['completed', 'cancelled'].includes(t.status)) throw Errors.invalidState('Nhiệm vụ đã đóng, không thể sửa');
    const started = t.status !== 'not_started';
    const scopeChange = b.criteria || b.description || b.dueAt || b.complexity || b.requirementLevel || b.estimatedHours;
    if ((started && scopeChange) || b.ownerMemberId) {
      if (!b.reason || b.reason.length < 5) throw Errors.reasonRequired('Thay đổi phạm vi/deadline/người phụ trách sau khi giao phải có lý do (lưu vết điều chỉnh)');
    }
    if (b.criteria && !b.criteria.some((c) => c.direction === 'output')) throw Errors.validation('Cần ít nhất một tiêu chí đầu ra');
    if (b.ownerMemberId || b.collaboratorIds) await this.assertInGroup(t.group_id, [...(b.ownerMemberId ? [b.ownerMemberId] : []), ...(b.collaboratorIds || [])]);

    await tx(async (c) => {
      const old: any = {}; const nw: any = {};
      const fields: [keyof typeof b, string][] = [['title', 'title'], ['description', 'description'], ['dueAt', 'due_at'], ['estimatedHours', 'estimated_hours'],
        ['complexity', 'complexity'], ['requirementLevel', 'requirement_level'], ['resources', 'resources'], ['priority', 'priority'], ['taskTypeId', 'task_type_id']];
      const sets: string[] = []; const params: any[] = [id];
      for (const [k, col] of fields) {
        if (b[k] === undefined) continue;
        params.push(b[k]); sets.push(`${col}=$${params.length}`);
        old[col] = t[col]; nw[col] = b[k];
      }
      let scopeBump = false;
      if (b.criteria) {
        const cur = await q1(`SELECT COALESCE(max(version),0) AS v FROM task_criteria WHERE task_id=$1`, [id], c);
        const v = cur.v + 1;
        for (const cr of b.criteria) {
          await q(`INSERT INTO task_criteria(task_id, version, direction, criterion, weight, created_by) VALUES ($1,$2,$3,$4,$5,$6)`,
            [id, v, cr.direction, cr.criterion, cr.weight ?? null, ctx.memberId], c);
        }
        old.criteria_version = cur.v; nw.criteria_version = v; scopeBump = true;
      }
      if (b.description || b.dueAt || b.estimatedHours) scopeBump = true;
      if (scopeBump) sets.push(`scope_version=scope_version+1`);
      sets.push(`updated_at=now()`);
      await q(`UPDATE tasks SET ${sets.join(', ')} WHERE id=$1`, params, c);

      if (b.ownerMemberId && b.ownerMemberId !== t.owner_id) {
        await q(`UPDATE task_assignees SET active=false WHERE task_id=$1 AND assignment_type='owner' AND active`, [id], c);
        await q(`UPDATE task_assignees SET active=false WHERE task_id=$1 AND company_member_id=$2 AND active`, [id, b.ownerMemberId], c);
        await q(`INSERT INTO task_assignees(task_id, company_member_id, assignment_type) VALUES ($1,$2,'owner')`, [id, b.ownerMemberId], c);
        old.owner = t.owner_id; nw.owner = b.ownerMemberId;
        await notify(c, { companyId: ctx.companyId, memberIds: [b.ownerMemberId], type: 'task.assigned', title: `Bạn được giao lại nhiệm vụ: ${t.title}`, refType: 'task', refId: id });
      }
      if (b.collaboratorIds) {
        const ownerNow = b.ownerMemberId || t.owner_id;
        await q(`UPDATE task_assignees SET active=false WHERE task_id=$1 AND assignment_type='collaborator' AND active`, [id], c);
        for (const cid of [...new Set(b.collaboratorIds)].filter((x) => x !== ownerNow)) {
          await q(`INSERT INTO task_assignees(task_id, company_member_id, assignment_type) VALUES ($1,$2,'collaborator')`, [id, cid], c);
        }
        nw.collaborators = b.collaboratorIds;
      }
      await audit(c, ctx, 'task', id, b.dueAt ? 'task.deadline_changed' : 'task.updated', old, nw, b.reason ?? null);
      const assignees = await q(`SELECT company_member_id FROM task_assignees WHERE task_id=$1 AND active`, [id], c);
      if (b.dueAt || b.criteria) {
        await notify(c, {
          companyId: ctx.companyId, memberIds: assignees.map((a) => a.company_member_id), excludeMemberId: ctx.memberId,
          type: b.dueAt ? 'task.deadline_changed' : 'task.scope_changed',
          title: b.dueAt ? `Deadline nhiệm vụ "${t.title}" đã thay đổi` : `Phạm vi/tiêu chí nhiệm vụ "${t.title}" đã thay đổi`,
          body: b.reason, refType: 'task', refId: id,
        });
      }
    });
    return this.detail(id, ctx);
  }

  // ---------------- Workflow ----------------
  @Post('tasks/:id/start')
  async start(@Param('id') id: string, @CurrentCtx() ctx: Ctx) {
    const t = await this.loadTask(ctx, id);
    if (t.owner_id !== ctx.memberId) throw Errors.forbidden('Chỉ người chịu trách nhiệm được bắt đầu nhiệm vụ');
    if (!['not_started', 'revision_requested'].includes(t.status)) throw Errors.invalidState('Nhiệm vụ không ở trạng thái có thể bắt đầu');
    await tx(async (c) => {
      await q(`UPDATE tasks SET status='in_progress', started_at=COALESCE(started_at, now()), updated_at=now() WHERE id=$1`, [id], c);
      await audit(c, ctx, 'task', id, 'task.status', { status: t.status }, { status: 'in_progress' });
    });
    return this.detail(id, ctx);
  }

  @Post('tasks/:id/submit')
  async submit(@Param('id') id: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({ outputDescription: z.string().trim().min(5, 'Mô tả kết quả bàn giao là bắt buộc'), completionPercent: z.number().int().min(0).max(100).default(100) }), body);
    const t = await this.loadTask(ctx, id);
    if (t.owner_id !== ctx.memberId) throw Errors.forbidden('Chỉ người chịu trách nhiệm được bàn giao');
    if (!['in_progress', 'revision_requested'].includes(t.status)) throw Errors.invalidState('Chỉ bàn giao khi nhiệm vụ đang thực hiện');
    await tx(async (c) => {
      await q(`INSERT INTO task_submissions(task_id, submitted_by, output_description, completion_percent) VALUES ($1,$2,$3,$4)`, [id, ctx.memberId, b.outputDescription, b.completionPercent], c);
      await q(`UPDATE tasks SET status='pending_review', submitted_at=now(), first_submitted_at=COALESCE(first_submitted_at, now()),
                 started_at=COALESCE(started_at, now()), updated_at=now() WHERE id=$1`, [id], c);
      await audit(c, ctx, 'task', id, 'task.submitted', { status: t.status }, { status: 'pending_review', completion: b.completionPercent });
      const g = await q1(`SELECT manager_member_id FROM groups WHERE id=$1`, [t.group_id], c);
      await notify(c, { companyId: ctx.companyId, memberIds: [g.manager_member_id, t.created_by], excludeMemberId: ctx.memberId,
        type: 'task.pending_review', title: `Nhiệm vụ chờ nghiệm thu: ${t.title}`, refType: 'task', refId: id });
    });
    return this.detail(id, ctx);
  }

  @Post('tasks/:id/review')
  async review(@Param('id') id: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({
      decision: z.enum(['approve', 'revision']),
      scores: z.record(z.string(), z.number().min(0).max(100)).optional(),
      comment: z.string().trim().optional(),
    }), body);
    const t = await this.loadTask(ctx, id);
    if (!(await canManageGroup(ctx, t.group_id))) throw Errors.forbidden('Chỉ quản lý/người nghiệm thu được đánh giá');
    if (t.owner_id === ctx.memberId) throw Errors.forbidden('Không được tự nghiệm thu nhiệm vụ của chính mình');
    if (t.status !== 'pending_review') throw Errors.invalidState('Nhiệm vụ không ở trạng thái chờ nghiệm thu');
    const { version, config } = await perfConfig(ctx.companyId);
    const kind = t.is_unexpected ? 'unexpected' : 'regular';
    let total: number | null = null; let scores: any = null;
    if (b.decision === 'approve') {
      const weights: Record<string, number> = kind === 'regular' ? config.regularWeights : config.unexpectedWeights;
      scores = {};
      for (const k of Object.keys(weights)) {
        const v = b.scores?.[k];
        if (v === undefined) throw Errors.validation(`Thiếu điểm tiêu chí "${k}" (thang 0-100)`);
        scores[k] = v;
      }
      total = Math.round(Object.entries(weights).reduce((s, [k, w]) => s + w * scores[k], 0) * 100) / 100;
    } else if (!b.comment || b.comment.length < 5) {
      throw Errors.reasonRequired('Yêu cầu chỉnh sửa phải nêu rõ nội dung cần sửa');
    }
    await tx(async (c) => {
      await q(`INSERT INTO task_evaluations(task_id, evaluator_id, decision, kind, scores, total_score, config_version, comment)
               VALUES ($1,$2,$3,$4,$5,$6,$7,$8)`,
        [id, ctx.memberId, b.decision === 'approve' ? 'approved' : 'revision_requested', kind, scores ? JSON.stringify(scores) : null, total, version, b.comment ?? null], c);
      if (b.decision === 'approve') {
        await q(`UPDATE tasks SET status='completed', completed_at=now(), updated_at=now() WHERE id=$1`, [id], c);
      } else {
        await q(`UPDATE tasks SET status='revision_requested', revision_count=revision_count+1, updated_at=now() WHERE id=$1`, [id], c);
      }
      await audit(c, ctx, 'task', id, b.decision === 'approve' ? 'task.approved' : 'task.revision_requested', { status: t.status },
        { status: b.decision === 'approve' ? 'completed' : 'revision_requested', total_score: total }, b.comment ?? null);
      const assignees = await q(`SELECT company_member_id FROM task_assignees WHERE task_id=$1 AND active`, [id], c);
      await notify(c, {
        companyId: ctx.companyId, memberIds: assignees.map((a) => a.company_member_id), excludeMemberId: ctx.memberId,
        type: b.decision === 'approve' ? 'task.completed' : 'task.revision_requested',
        title: b.decision === 'approve' ? `Nhiệm vụ "${t.title}" đã được nghiệm thu (${total} điểm)` : `Nhiệm vụ "${t.title}" cần chỉnh sửa`,
        body: b.comment, refType: 'task', refId: id,
      });
    });
    return this.detail(id, ctx);
  }

  @Post('tasks/:id/cancel')
  async cancel(@Param('id') id: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({ reason: zReason, businessDecision: z.boolean().default(true) }), body);
    const t = await this.loadTask(ctx, id);
    if (!(await canManageGroup(ctx, t.group_id))) throw Errors.forbidden('Nhân viên không được tự xóa/hủy nhiệm vụ được giao');
    if (['completed', 'cancelled'].includes(t.status)) throw Errors.invalidState('Nhiệm vụ đã đóng');
    await tx(async (c) => {
      await q(`UPDATE tasks SET status='cancelled', cancel_reason=$2, cancelled_by=$3, cancel_is_business_decision=$4, updated_at=now() WHERE id=$1`,
        [id, b.reason, ctx.memberId, b.businessDecision], c);
      await audit(c, ctx, 'task', id, 'task.cancelled', { status: t.status }, { status: 'cancelled' }, b.reason);
      const assignees = await q(`SELECT company_member_id FROM task_assignees WHERE task_id=$1 AND active`, [id], c);
      await notify(c, { companyId: ctx.companyId, memberIds: assignees.map((a) => a.company_member_id), excludeMemberId: ctx.memberId,
        type: 'task.cancelled', title: `Nhiệm vụ "${t.title}" đã bị hủy`, body: b.reason, refType: 'task', refId: id });
    });
    return this.detail(id, ctx);
  }

  @Post('tasks/:id/comments')
  async comment(@Param('id') id: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({ content: z.string().trim().min(1).max(5000) }), body);
    const t = await this.loadTask(ctx, id);
    await tx(async (c) => {
      await q(`INSERT INTO task_comments(task_id, member_id, content) VALUES ($1,$2,$3)`, [id, ctx.memberId, b.content], c);
      const assignees = await q(`SELECT company_member_id FROM task_assignees WHERE task_id=$1 AND active`, [id], c);
      const g = await q1(`SELECT manager_member_id FROM groups WHERE id=$1`, [t.group_id], c);
      await notify(c, { companyId: ctx.companyId, memberIds: [...assignees.map((a) => a.company_member_id), g.manager_member_id], excludeMemberId: ctx.memberId,
        type: 'task.comment', title: `${ctx.name} bình luận: ${t.title}`, body: b.content.slice(0, 140), refType: 'task', refId: id });
    });
    return this.detail(id, ctx);
  }

  // Yêu cầu thành phần (việc đa dạng) — lưu thời điểm thêm, người yêu cầu, ảnh hưởng thời lượng, phiên bản phạm vi
  @Post('tasks/:id/subitems')
  async addSubitem(@Param('id') id: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({ title: z.string().trim().min(2), extraHours: z.number().min(0).default(0), requestedBy: z.string().uuid().optional(), reason: z.string().optional() }), body);
    const t = await this.loadTask(ctx, id);
    if (!(await canManageGroup(ctx, t.group_id))) throw Errors.forbidden();
    if (['completed', 'cancelled'].includes(t.status)) throw Errors.invalidState('Nhiệm vụ đã đóng');
    if (b.requestedBy) await getMember(ctx, b.requestedBy);
    await tx(async (c) => {
      const nv = await q1(`UPDATE tasks SET scope_version=scope_version+1, estimated_hours=estimated_hours+$2, updated_at=now() WHERE id=$1 RETURNING scope_version`, [id, b.extraHours], c);
      await q(`INSERT INTO task_subitems(task_id, title, extra_hours, scope_version, created_by, requested_by) VALUES ($1,$2,$3,$4,$5,$6)`,
        [id, b.title, b.extraHours, nv.scope_version, ctx.memberId, b.requestedBy ?? ctx.memberId], c);
      await audit(c, ctx, 'task', id, 'task.subitem_added', { scope_version: t.scope_version }, { scope_version: nv.scope_version, title: b.title, extra_hours: b.extraHours }, b.reason ?? null);
      const assignees = await q(`SELECT company_member_id FROM task_assignees WHERE task_id=$1 AND active`, [id], c);
      await notify(c, { companyId: ctx.companyId, memberIds: assignees.map((a) => a.company_member_id), excludeMemberId: ctx.memberId,
        type: 'task.scope_changed', title: `Thêm yêu cầu mới vào "${t.title}"`, body: b.title, refType: 'task', refId: id });
    });
    return this.detail(id, ctx);
  }

  @Patch('tasks/:id/subitems/:sid')
  async toggleSubitem(@Param('id') id: string, @Param('sid') sid: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({ done: z.boolean() }), body);
    const t = await this.loadTask(ctx, id);
    const isAssignee = await q1(`SELECT 1 FROM task_assignees WHERE task_id=$1 AND company_member_id=$2 AND active`, [id, ctx.memberId]);
    if (!isAssignee && !(await canManageGroup(ctx, t.group_id))) throw Errors.forbidden();
    const r = await q1(`UPDATE task_subitems SET done=$3, updated_at=now() WHERE id=$1 AND task_id=$2 RETURNING id`, [sid, id, b.done]);
    if (!r) throw Errors.notFound('Yêu cầu thành phần');
    await audit(getPool(), ctx, 'task', id, 'task.subitem_updated', null, { subitem: sid, done: b.done });
    return this.detail(id, ctx);
  }
}
