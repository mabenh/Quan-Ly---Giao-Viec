import { Controller, Get } from '@nestjs/common';
import { q, q1 } from '../db/db';
import { CurrentCtx, Ctx, isAdmin } from '../common/context';
import { taskVisibilitySql, OPEN_STATUSES } from './tasks.controller';

@Controller('dashboard')
export class DashboardController {
  @Get()
  async get(@CurrentCtx() ctx: Ctx) {
    const P = [ctx.companyId, ctx.memberId];
    const mine = `EXISTS (SELECT 1 FROM task_assignees ta WHERE ta.task_id=t.id AND ta.company_member_id=$2 AND ta.active)`;
    const my = await q1(
      `SELECT count(*) FILTER (WHERE t.status IN ${OPEN_STATUSES})::int AS open,
              count(*) FILTER (WHERE t.status IN ${OPEN_STATUSES} AND t.due_at < now())::int AS overdue,
              count(*) FILTER (WHERE t.status IN ${OPEN_STATUSES} AND t.due_at >= now() AND t.due_at < now() + interval '2 days')::int AS due_soon,
              count(*) FILTER (WHERE t.status IN ${OPEN_STATUSES} AND (t.due_at AT TIME ZONE c.timezone)::date = (now() AT TIME ZONE c.timezone)::date)::int AS due_today,
              count(*) FILTER (WHERE t.status='revision_requested')::int AS revision
         FROM tasks t JOIN companies c ON c.id=t.company_id WHERE t.company_id=$1 AND ${mine}`, P);
    const myTasks = await q(
      `SELECT t.id, t.code, t.title, t.status, t.due_at, (t.due_at < now()) AS is_overdue, g.name AS group_name FROM tasks t JOIN groups g ON g.id=t.group_id
        WHERE t.company_id=$1 AND ${mine} AND t.status IN ${OPEN_STATUSES} ORDER BY t.due_at LIMIT 8`, P);
    const myRecords = await q1(
      `SELECT count(*) FILTER (WHERE status IN ('rejected','partially_accepted','needs_information'))::int AS need_response,
              count(*) FILTER (WHERE status IN ('submitted','disputed'))::int AS waiting_manager,
              count(*) FILTER (WHERE status='appealed')::int AS appealed
         FROM employee_work_records WHERE company_id=$1 AND employee_id=$2`, P);
    const myReports = await q1(
      `SELECT count(*) FILTER (WHERE stage<>'closed')::int AS open, count(*) FILTER (WHERE stage='reporter_confirm')::int AS need_confirm
         FROM workplace_reports WHERE company_id=$1 AND reporter_id=$2`, P);

    // Quản lý
    const vis = await taskVisibilitySql(ctx);
    const review = await q1(
      `SELECT count(*)::int AS n FROM tasks t WHERE ${vis} AND t.status='pending_review'
          AND (EXISTS (SELECT 1 FROM groups g WHERE g.id=t.group_id AND g.manager_member_id=$2) OR $3::boolean)`, [...P, isAdmin(ctx)]);
    const team = await q1(
      `SELECT count(*) FILTER (WHERE t.status IN ${OPEN_STATUSES})::int AS open, count(*) FILTER (WHERE t.status IN ${OPEN_STATUSES} AND t.due_at < now())::int AS overdue
         FROM tasks t WHERE t.company_id=$1 AND EXISTS (SELECT 1 FROM groups g WHERE g.id=t.group_id AND g.manager_member_id=$2)`, P);
    const recordsToReview = await q1(
      `SELECT count(*)::int AS n, count(*) FILTER (WHERE r.overdue OR r.review_due_at < now())::int AS overdue FROM employee_work_records r
        WHERE r.company_id=$1 AND r.status IN ('submitted','disputed') AND r.employee_id<>$2 AND (r.reviewer_member_id=$2
          OR EXISTS (SELECT 1 FROM escalations e WHERE e.parent_type='work_record' AND e.parent_id=r.id AND e.to_member_id=$2 AND e.status='open'))`, P);
    const appeals = await q1(`SELECT count(*)::int AS n FROM work_record_appeals a JOIN employee_work_records r ON r.id=a.work_record_id
                               WHERE r.company_id=$1 AND a.reviewer_id=$2 AND a.status='open'`, P);
    const holding = await q1(
      `SELECT count(*)::int AS n,
              count(*) FILTER (WHERE w.stage_due_at < now())::int AS overdue,
              count(*) FILTER (WHERE w.stage_due_at >= now() AND w.stage_due_at < now() + interval '4 hours')::int AS near_due
         FROM workplace_reports w WHERE w.company_id=$1 AND w.stage IN ('manager_review','department_ack','resolution')
          AND (w.current_holder_id=$2 OR EXISTS (SELECT 1 FROM escalations e WHERE e.parent_type='workplace_report' AND e.parent_id=w.id AND e.to_member_id=$2 AND e.status='open')
               OR (w.stage='department_ack' AND EXISTS (SELECT 1 FROM company_members me WHERE me.id=$2 AND me.department_id=w.department_id)))`, P);
    const escalations = await q1(`SELECT count(*)::int AS n FROM escalations WHERE company_id=$1 AND to_member_id=$2 AND status='open'`, P);
    const overtimePending = await q1(
      `SELECT count(*)::int AS n FROM overtime_records o JOIN company_members cm ON cm.id=o.member_id
        WHERE o.company_id=$1 AND o.approval_status='pending' AND o.member_id<>$2 AND (cm.supervisor_member_id=$2 OR $3::boolean
          OR EXISTS (SELECT 1 FROM groups g WHERE g.manager_member_id=$2 AND (g.id=o.group_id OR EXISTS (SELECT 1 FROM group_members gm WHERE gm.group_id=g.id AND gm.company_member_id=o.member_id))))`,
      [...P, isAdmin(ctx)]);
    const unread = await q1(`SELECT count(*)::int AS n FROM notifications WHERE member_id=$1 AND read_at IS NULL`, [ctx.memberId]);
    return {
      role: ctx.role,
      me: { tasks: my, tasks_list: myTasks, work_records: myRecords, reports: myReports },
      manage: {
        tasks_pending_review: review.n, team_tasks: team, work_records_to_review: recordsToReview, appeals_to_resolve: appeals.n,
        reports_holding: holding, escalations_open: escalations.n, overtime_pending: overtimePending.n,
      },
      unread_notifications: unread.n,
    };
  }
}
