import { Module } from '@nestjs/common';
import { APP_FILTER, APP_GUARD, APP_INTERCEPTOR } from '@nestjs/core';
import { ScheduleModule } from '@nestjs/schedule';
import { AuthGuard } from './common/auth.guard';
import { IdempotencyInterceptor } from './common/idempotency.interceptor';
import { AllExceptionsFilter } from './common/exception.filter';
import { AuthController } from './modules/auth.controller';
import { CompanyController } from './modules/company.controller';
import { GroupsController } from './modules/groups.controller';
import { TasksController } from './modules/tasks.controller';
import { OvertimeController } from './modules/overtime.controller';
import { WorkRecordsController } from './modules/work-records.controller';
import { WorkplaceReportsController } from './modules/workplace-reports.controller';
import { EscalationsController } from './modules/escalations.controller';
import { PerformanceController } from './modules/performance.controller';
import { NotificationsController } from './modules/notifications.controller';
import { FilesController } from './modules/files.controller';
import { DashboardController } from './modules/dashboard.controller';
import { SchedulerService } from './modules/scheduler.service';
import { HealthController } from './modules/health.controller';
import { SubscriptionsController } from './modules/subscriptions.controller';
import { ProfileController } from './modules/profile.controller';
import { CalendarController } from './modules/calendar.controller';
import { QuickClaimsController } from './modules/quick-claims.controller';
import { LeavesController } from './modules/leaves.controller';
import { DecisionsController } from './modules/decisions.controller';
import { PermitsController } from './modules/permits.controller';
import { HrController } from './modules/hr.controller';

@Module({
  imports: [ScheduleModule.forRoot()],
  controllers: [
    HealthController, AuthController, CompanyController, GroupsController, TasksController, OvertimeController, WorkRecordsController,
    WorkplaceReportsController, EscalationsController, PerformanceController, NotificationsController, FilesController, DashboardController,
    SubscriptionsController, ProfileController, CalendarController, QuickClaimsController, LeavesController,
    DecisionsController, PermitsController, HrController,
  ],
  providers: [
    { provide: APP_GUARD, useClass: AuthGuard },
    { provide: APP_INTERCEPTOR, useClass: IdempotencyInterceptor },
    { provide: APP_FILTER, useClass: AllExceptionsFilter },
    SchedulerService,
  ],
})
export class AppModule {}
