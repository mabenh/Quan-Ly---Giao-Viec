/**
 * Bảo vệ dữ liệu cá nhân (SEC-01):
 * - Nhật ký truy cập dữ liệu (data_access_logs) — chỉ ghi thêm, không ghi giá trị nhạy cảm.
 * - Mức hiển thị theo trường (only_me | related | company) và giới hạn liên hệ (contact_blocks).
 * - Giới hạn tốc độ trong bộ nhớ + cảnh báo hành vi bất thường (security_alerts). Cảnh báo là tín hiệu, không phải kết luận.
 */
import { Queryable, getPool, q, q1 } from '../db/db';
import { AppError } from './errors';

export type Visibility = 'only_me' | 'related' | 'company';
export const FIELD_DEFAULTS: Record<string, Visibility> = {
  phone: 'related', // SĐT là kênh liên hệ công việc (gọi/nhắn/Zalo) — mặc định chỉ người cùng nhóm/quan hệ quản lý thấy
  email: 'only_me',
  dob: 'only_me',
  address: 'only_me',
  contact_email: 'only_me',
  work_history: 'related',
};
export const FIELD_LABEL: Record<string, string> = {
  phone: 'Số điện thoại', email: 'Email đăng nhập', dob: 'Ngày sinh', address: 'Địa chỉ', contact_email: 'Email liên hệ', work_history: 'Quá trình làm việc (CV)',
};

export interface AccessLogInput {
  companyId?: string | null; actorUserId?: string | null; actorMemberId?: string | null;
  action: string; objectType: string; objectId?: string | null; subjectUserId?: string | null;
  reason?: string | null; result?: 'allowed' | 'denied'; meta?: any;
}
export async function accessLog(e: AccessLogInput, db: Queryable = getPool()) {
  await q(
    `INSERT INTO data_access_logs(company_id, actor_user_id, actor_member_id, action, object_type, object_id, subject_user_id, reason, result, meta)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)`,
    [e.companyId ?? null, e.actorUserId ?? null, e.actorMemberId ?? null, e.action, e.objectType, e.objectId ?? null, e.subjectUserId ?? null,
     e.reason ?? null, e.result ?? 'allowed', e.meta ? JSON.stringify(e.meta) : null], db);
}

export async function visibilityOf(userIds: string[], db: Queryable = getPool()): Promise<Map<string, Record<string, Visibility>>> {
  const out = new Map<string, Record<string, Visibility>>();
  if (!userIds.length) return out;
  const rows = await q(`SELECT user_id, field_key, visibility FROM field_visibility_settings WHERE user_id = ANY($1::uuid[])`, [userIds], db);
  for (const id of userIds) out.set(id, { ...FIELD_DEFAULTS });
  for (const r of rows) out.get(r.user_id)![r.field_key] = r.visibility;
  return out;
}

/** Tập member có quan hệ công việc với viewer: cùng nhóm (thành viên/quản lý), cấp trên/cấp dưới trực tiếp. */
export async function relatedMemberIds(viewerMemberId: string, db: Queryable = getPool()): Promise<Set<string>> {
  const rows = await q(
    `WITH my_groups AS (
       SELECT g.id FROM groups g WHERE g.deleted_at IS NULL AND (g.manager_member_id=$1 OR EXISTS (SELECT 1 FROM group_members gm WHERE gm.group_id=g.id AND gm.company_member_id=$1)))
     SELECT gm.company_member_id AS id FROM group_members gm WHERE gm.group_id IN (SELECT id FROM my_groups)
     UNION SELECT g.manager_member_id FROM groups g WHERE g.id IN (SELECT id FROM my_groups)
     UNION SELECT supervisor_member_id FROM company_members WHERE id=$1 AND supervisor_member_id IS NOT NULL
     UNION SELECT id FROM company_members WHERE supervisor_member_id=$1`, [viewerMemberId], db);
  return new Set(rows.map((r) => r.id).filter(Boolean));
}

/**
 * Che trường liên hệ trong danh sách theo lựa chọn của chủ thể. `forceRelated` dùng khi ngữ cảnh đã là quan hệ công việc
 * cụ thể (người duyệt đơn, người cùng khai việc, người cấp giấy phép...). Người bị chủ thể giới hạn liên hệ không thấy SĐT.
 */
export async function maskContacts<T extends Record<string, any>>(
  rows: T[], viewer: { userId: string; memberId: string | null },
  opts: { userIdKey?: string; memberIdKey?: string; fields?: Record<string, string>; forceRelated?: boolean } = {},
  db: Queryable = getPool(),
): Promise<T[]> {
  const uk = opts.userIdKey || 'user_id';
  const mk = opts.memberIdKey || 'member_id';
  const fields = opts.fields || { phone: 'phone', email: 'email' };
  const userIds = [...new Set(rows.map((r) => r[uk]).filter(Boolean))];
  if (!userIds.length) return rows;
  const vis = await visibilityOf(userIds, db);
  const related = viewer.memberId && !opts.forceRelated ? await relatedMemberIds(viewer.memberId, db) : new Set<string>();
  const blocks = viewer.memberId
    ? new Set((await q(`SELECT blocker_member_id FROM contact_blocks WHERE blocked_member_id=$1`, [viewer.memberId], db)).map((r) => r.blocker_member_id))
    : new Set<string>();
  for (const r of rows) {
    if (r[uk] === viewer.userId) continue;
    const v = vis.get(r[uk]) || FIELD_DEFAULTS;
    const isRelated = opts.forceRelated || related.has(r[mk]);
    for (const [fieldKey, col] of Object.entries(fields)) {
      if (!(col in r)) continue;
      const level = v[fieldKey] || 'only_me';
      let show = level === 'company' || (level === 'related' && isRelated);
      if (fieldKey === 'phone' && blocks.has(r[mk])) show = false;
      if (!show) (r as any)[col] = null;
    }
  }
  return rows;
}

/** Có hiển thị trường `field` của `subjectUserId` cho viewer không (dùng cho hồ sơ đơn lẻ). */
export async function canSeeField(subjectUserId: string, subjectMemberId: string | null, viewer: { userId: string; memberId: string | null }, field: string, db: Queryable = getPool()) {
  if (subjectUserId === viewer.userId) return true;
  const v = (await visibilityOf([subjectUserId], db)).get(subjectUserId)!;
  const level = v[field] || 'only_me';
  if (level === 'company') return true;
  if (level === 'related' && viewer.memberId && subjectMemberId) return (await relatedMemberIds(viewer.memberId, db)).has(subjectMemberId);
  return false;
}

export async function hasConsent(userId: string, purpose: string, db: Queryable = getPool()) {
  const r = await q1(`SELECT status FROM consent_records WHERE user_id=$1 AND purpose=$2 ORDER BY captured_at DESC LIMIT 1`, [userId, purpose], db);
  return r?.status === 'granted';
}

// ---------------- Giới hạn tốc độ & cảnh báo bất thường ----------------
const buckets = new Map<string, number[]>();
/** Cửa sổ trượt trong bộ nhớ (một tiến trình). Trả về số lần trong cửa sổ sau khi ghi nhận. */
export function hit(key: string, windowMs: number): number {
  const now = Date.now();
  const arr = (buckets.get(key) || []).filter((t) => now - t < windowMs);
  arr.push(now);
  buckets.set(key, arr);
  if (buckets.size > 50000) for (const [k, v] of buckets) if (!v.length || now - v[v.length - 1] > 3600000) buckets.delete(k);
  return arr.length;
}
export function count(key: string, windowMs: number): number {
  const now = Date.now();
  return (buckets.get(key) || []).filter((t) => now - t < windowMs).length;
}
export function resetRateLimits() { buckets.clear(); }

export function rateLimit(key: string, max: number, windowMs: number, message = 'Bạn thao tác quá nhanh. Vui lòng thử lại sau ít phút.') {
  if (hit('rl:' + key, windowMs) > max) throw new AppError('RATE_LIMITED', message, 429);
}

const ALERT_LABEL: Record<string, string> = {
  id_scan: 'Nhiều yêu cầu bị từ chối/không tìm thấy trong thời gian ngắn (có thể dò ID)',
  profile_views: 'Xem nhiều hồ sơ cá nhân trong thời gian ngắn',
  export_volume: 'Xuất dữ liệu nhiều lần trong thời gian ngắn',
  out_of_scope: 'Cố truy cập dữ liệu ngoài phạm vi',
  login_failures: 'Đăng nhập sai nhiều lần',
  request_burst: 'Số lượng yêu cầu bất thường',
};
/** Ghi cảnh báo (gộp cùng loại trong 1 giờ). Không khóa tài khoản, không kết luận vi phạm. */
export async function securityAlert(a: { companyId?: string | null; userId?: string | null; memberId?: string | null; kind: string; detail?: string }) {
  try {
    const ex = await q1(`SELECT id FROM security_alerts WHERE kind=$1 AND COALESCE(user_id::text,'')=COALESCE($2::text,'') AND status='open' AND created_at > now() - interval '1 hour'`, [a.kind, a.userId ?? null]);
    if (ex) { await q(`UPDATE security_alerts SET count=count+1 WHERE id=$1`, [ex.id]); return; }
    await q(`INSERT INTO security_alerts(company_id, user_id, member_id, kind, detail) VALUES ($1,$2,$3,$4,$5)`,
      [a.companyId ?? null, a.userId ?? null, a.memberId ?? null, a.kind, a.detail || ALERT_LABEL[a.kind] || a.kind]);
  } catch { /* không để lỗi cảnh báo làm hỏng request */ }
}
export { ALERT_LABEL };
