/**
 * v14: Tên trọng điểm của công ty để hiển thị gọn trên thanh trên cùng.
 * "Công ty TNHH Demo Việt" → "Demo Việt"; "Cty TNHH MTV Nhà Văn Môn" → "Nhà Văn Môn" (giữ nguyên chữ hoa/thường gốc).
 * Quản trị có thể tự đặt tên rút gọn trong Cấu hình công ty.
 */
const PREFIXES = [
  'tổng công ty', 'công ty', 'cong ty', 'cty', 'tập đoàn', 'doanh nghiệp tư nhân', 'dntn', 'hợp tác xã', 'htx',
  'trách nhiệm hữu hạn một thành viên', 'trách nhiệm hữu hạn hai thành viên trở lên', 'trách nhiệm hữu hạn',
  'tnhh một thành viên', 'tnhh mtv', 'tnhh', 'một thành viên', 'mtv', 'cổ phần', 'cp',
];
const RES = PREFIXES.map((p) => new RegExp(`^${p}(?:\\s+|[.,\\-–]+\\s*|$)`, 'iu'));
export function shortCompanyName(name: string): string {
  const orig = (name || '').trim();
  let s = orig;
  for (let guard = 0; guard < 10; guard++) {
    const re = RES.find((r) => r.test(s));
    if (!re) break;
    s = s.replace(re, '').trim();
  }
  s = s.replace(/\s*[-–,]?\s*(?:co\.?,?\s*ltd\.?|jsc|llc)\.?$/iu, '').trim();
  return s || orig;
}
