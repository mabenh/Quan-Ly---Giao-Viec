import { createParamDecorator, ExecutionContext } from '@nestjs/common';

export type Role = 'owner' | 'admin' | 'manager' | 'employee' | 'handler' | 'reviewer';

export interface Ctx {
  userId: string;
  memberId: string;
  companyId: string;
  role: Role;
  name: string;
}

export const CurrentCtx = createParamDecorator((_d: unknown, ec: ExecutionContext): Ctx => {
  return ec.switchToHttp().getRequest().ctx;
});

export const isAdmin = (ctx: Ctx) => ctx.role === 'owner' || ctx.role === 'admin';
export const isManagerial = (ctx: Ctx) => isAdmin(ctx) || ctx.role === 'manager' || ctx.role === 'reviewer';
