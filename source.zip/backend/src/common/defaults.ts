/** Cấu hình khởi tạo minh họa (mục 4.3, 8.4, 9, 18). Doanh nghiệp điều chỉnh trong phần Cấu hình. */
export interface WorkCalendar {
  workdays: number[]; // 1=Thứ 2 ... 7=Chủ nhật (ISO)
  start: string; // HH:mm
  end: string;
  breakStart?: string;
  breakEnd?: string;
  holidays: string[]; // YYYY-MM-DD
}

export interface CompanyPolicies {
  multiGroup: boolean; // D01
  employeeTaskVisibility: 'group' | 'related'; // D02
  appealThreshold: number; // D04: lần từ chối thứ N (mặc định 4) mở quyền khiếu nại
  workRecordReviewMinutes: number; // D05: phút làm việc (480 = 1 ngày làm việc)
  overtimeReviewMinutes: number;
  taskDueSoonMinutes: number; // nhắc trước hạn (phút lịch)
  reminderRatio: number; // nhắc khi còn <= tỷ lệ này của thời hạn SLA
  resetChainOnAccept: boolean;
  lunchBreakLimitMinutes: number; // tham chiếu cho lý do từ chối (không tự khấu trừ)
}

export interface CompanySettings {
  calendar: WorkCalendar;
  policies: CompanyPolicies;
}

export const DEFAULT_SETTINGS: CompanySettings = {
  calendar: {
    workdays: [1, 2, 3, 4, 5],
    start: '08:00',
    end: '17:00',
    breakStart: '12:00',
    breakEnd: '13:00',
    holidays: ['2026-01-01', '2026-04-30', '2026-05-01', '2026-09-02'],
  },
  policies: {
    multiGroup: true,
    employeeTaskVisibility: 'group',
    appealThreshold: 4,
    workRecordReviewMinutes: 480,
    overtimeReviewMinutes: 960,
    taskDueSoonMinutes: 24 * 60,
    reminderRatio: 0.25,
    resetChainOnAccept: true,
    lunchBreakLimitMinutes: 30,
  },
};

export function mergeSettings(s: any): CompanySettings {
  return {
    calendar: { ...DEFAULT_SETTINGS.calendar, ...(s?.calendar || {}) },
    policies: { ...DEFAULT_SETTINGS.policies, ...(s?.policies || {}) },
  };
}

/** SLA khởi tạo (mục 8.4), đơn vị phút làm việc. Mức nghiêm trọng tính theo giờ lịch 24/7. */
export const DEFAULT_SLA = [
  { severity: 'low', manager_review_minutes: 480, acknowledge_minutes: 480, resolve_minutes: 2400 },
  { severity: 'medium', manager_review_minutes: 240, acknowledge_minutes: 240, resolve_minutes: 960 },
  { severity: 'high', manager_review_minutes: 60, acknowledge_minutes: 60, resolve_minutes: 480 },
  { severity: 'critical', manager_review_minutes: 15, acknowledge_minutes: 15, resolve_minutes: 240 },
];

export interface PerformanceConfig {
  regularWeights: { output: number; quality: number; schedule: number; process: number };
  unexpectedWeights: { requirement: number; response: number; handling: number; quality: number; coordination: number };
  complexityFactors: Record<string, number>;
  requirementFactors: Record<string, number>;
  employeeWeights: { V: number; T: number; Q: number; D: number; R: number };
  ownerShare: number; // phần ghi nhận cho người chịu trách nhiệm khi có cộng tác viên
  qualityMix: { score: number; firstPass: number };
}

export const DEFAULT_PERFORMANCE: PerformanceConfig = {
  regularWeights: { output: 0.4, quality: 0.3, schedule: 0.2, process: 0.1 },
  unexpectedWeights: { requirement: 0.35, response: 0.2, handling: 0.2, quality: 0.15, coordination: 0.1 },
  complexityFactors: { simple: 1.0, medium: 1.3, complex: 1.7, very_complex: 2.2 },
  requirementFactors: { normal: 1.0, high: 1.1, very_high: 1.25 },
  employeeWeights: { V: 0.25, T: 0.2, Q: 0.3, D: 0.15, R: 0.1 },
  ownerShare: 0.6,
  qualityMix: { score: 0.7, firstPass: 0.3 },
};

/** Khung thời lượng tham khảo (mục 4.3), giờ làm việc [min,max]. 1 ngày = 8 giờ. */
export const DURATION_GUIDE: Record<string, Record<string, [number, number]>> = {
  simple: { normal: [2, 4], high: [4, 8] },
  medium: { normal: [8, 16], high: [16, 24] },
  complex: { normal: [24, 40], high: [40, 64] },
  very_complex: { normal: [40, 80], high: [80, 160] },
};

export const DEFAULT_TASK_TYPES = ['Vận hành', 'Kỹ thuật', 'Hành chính', 'Kinh doanh', 'Hỗ trợ khách hàng'];
