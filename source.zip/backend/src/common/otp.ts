import { createHmac, randomInt, timingSafeEqual } from 'crypto';
import { Logger } from '@nestjs/common';
import { q, q1 } from '../db/db';
import { AppError } from './errors';
import { jwtSecret } from './auth.guard';

/**
 * Mã OTP gửi qua SMS (v14).
 * Nhà cung cấp SMS cấu hình bằng biến môi trường SMS_PROVIDER:
 *   esms      — eSMS.vn  (ESMS_API_KEY, ESMS_SECRET_KEY, ESMS_BRANDNAME; ESMS_SMS_TYPE mặc định 2 = brandname CSKH)
 *   speedsms  — SpeedSMS.vn (SPEEDSMS_TOKEN, SPEEDSMS_SENDER; SPEEDSMS_TYPE mặc định 5 = brandname)
 *   twilio    — Twilio (TWILIO_SID, TWILIO_TOKEN, TWILIO_FROM)
 *   webhook   — gọi URL tùy ý (SMS_WEBHOOK_URL, SMS_WEBHOOK_TOKEN) với JSON {phone, text}
 *   (trống)   — chưa có SMS: mã được lưu để Quản trị nền tảng đọc hỗ trợ khách (Quản trị nền tảng › OTP).
 * Mã 6 số, hết hạn sau 5 phút, sai tối đa 5 lần; mỗi số gửi lại sau 60 giây, tối đa 5 mã/giờ; mỗi IP tối đa 20 mã/giờ.
 */
export type OtpPurpose = 'register' | 'login' | 'reset' | 'change_password';
const log = new Logger('OTP');
const TTL_SEC = () => Number(process.env.OTP_TTL_SECONDS || 300);
const RESEND_SEC = () => Number(process.env.OTP_RESEND_SECONDS || 60);
export const smsProvider = () => (process.env.SMS_PROVIDER || '').toLowerCase();
/** Đăng ký có bắt buộc OTP: OTP_REQUIRED=true/false; mặc định bắt buộc khi đã cấu hình nhà cung cấp SMS. */
export const otpRequired = () => (process.env.OTP_REQUIRED ? process.env.OTP_REQUIRED === 'true' : !!smsProvider());

const hash = (phone: string, purpose: string, code: string) => createHmac('sha256', jwtSecret()).update(`${phone}:${purpose}:${code}`).digest('hex');
const toE164 = (p: string) => '+84' + p.slice(1);
const toIntl = (p: string) => '84' + p.slice(1);

async function sendSms(phone: string, text: string): Promise<string> {
  const pv = smsProvider();
  const post = async (url: string, body: any, headers: Record<string, string> = {}) => {
    const r = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json', ...headers }, body: typeof body === 'string' ? body : JSON.stringify(body), signal: AbortSignal.timeout(15000) });
    const t = await r.text();
    if (!r.ok) throw new Error(`HTTP ${r.status}: ${t.slice(0, 200)}`);
    return t;
  };
  if (pv === 'esms') {
    const t = await post('https://rest.esms.vn/MainService.svc/json/SendMultipleMessage_V4_post_json/', {
      ApiKey: process.env.ESMS_API_KEY, SecretKey: process.env.ESMS_SECRET_KEY, Phone: phone, Content: text, Brandname: process.env.ESMS_BRANDNAME,
      SmsType: process.env.ESMS_SMS_TYPE || '2', IsUnicode: '0' });
    const j = JSON.parse(t); if (String(j.CodeResult) !== '100') throw new Error(`eSMS ${j.CodeResult}: ${j.ErrorMessage || ''}`);
    return 'esms:' + (j.SMSID || 'ok');
  }
  if (pv === 'speedsms') {
    const auth = 'Basic ' + Buffer.from(`${process.env.SPEEDSMS_TOKEN}:x`).toString('base64');
    const t = await post('https://api.speedsms.vn/index.php/sms/send', { to: [toIntl(phone)], content: text, sms_type: Number(process.env.SPEEDSMS_TYPE || 5), sender: process.env.SPEEDSMS_SENDER || '' }, { Authorization: auth });
    const j = JSON.parse(t); if (j.status !== 'success') throw new Error(`SpeedSMS: ${j.message || t.slice(0, 120)}`);
    return 'speedsms:' + (j.data?.tranId || 'ok');
  }
  if (pv === 'twilio') {
    const sid = process.env.TWILIO_SID!;
    const r = await fetch(`https://api.twilio.com/2010-04-01/Accounts/${sid}/Messages.json`, {
      method: 'POST', signal: AbortSignal.timeout(15000),
      headers: { Authorization: 'Basic ' + Buffer.from(`${sid}:${process.env.TWILIO_TOKEN}`).toString('base64'), 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({ To: toE164(phone), From: process.env.TWILIO_FROM || '', Body: text }).toString() });
    if (!r.ok) throw new Error(`Twilio HTTP ${r.status}`);
    return 'twilio';
  }
  if (pv === 'webhook') {
    await post(process.env.SMS_WEBHOOK_URL!, { phone, text }, process.env.SMS_WEBHOOK_TOKEN ? { Authorization: `Bearer ${process.env.SMS_WEBHOOK_TOKEN}` } : {});
    return 'webhook';
  }
  return 'manual';
}

/** Tạo và gửi mã. Trả về thông tin hiển thị cho app (không bao giờ trả mã, trừ khi OTP_DEV_ECHO=true để kiểm thử). */
export async function issueOtp(phone: string, purpose: OtpPurpose, ip: string, opts: { silent?: boolean } = {}) {
  const last = await q1(`SELECT created_at FROM otp_codes WHERE phone=$1 AND purpose=$2 ORDER BY created_at DESC LIMIT 1`, [phone, purpose]);
  if (last) {
    const wait = RESEND_SEC() - Math.floor((Date.now() - new Date(last.created_at).getTime()) / 1000);
    if (wait > 0) throw new AppError('OTP_TOO_SOON', `Vui lòng đợi ${wait} giây rồi gửi lại mã`, 429, { retry_after: wait });
  }
  const hourPhone = (await q1(`SELECT count(*)::int AS n FROM otp_codes WHERE phone=$1 AND created_at > now() - interval '1 hour'`, [phone])).n;
  if (hourPhone >= Number(process.env.OTP_MAX_PER_HOUR || 5)) throw new AppError('OTP_LIMIT', 'Số điện thoại này đã yêu cầu quá nhiều mã trong 1 giờ. Vui lòng thử lại sau.', 429);
  const hourIp = (await q1(`SELECT count(*)::int AS n FROM otp_codes WHERE ip=$1 AND created_at > now() - interval '1 hour'`, [ip])).n;
  if (hourIp >= Number(process.env.OTP_MAX_PER_IP_HOUR || 20)) throw new AppError('OTP_LIMIT', 'Quá nhiều yêu cầu mã từ mạng này. Vui lòng thử lại sau.', 429);

  const code = String(randomInt(0, 1000000)).padStart(6, '0');
  const pv = smsProvider();
  const row = await q1(`INSERT INTO otp_codes(phone, purpose, code_hash, manual_code, expires_at, ip, channel) VALUES ($1,$2,$3,$4, now() + make_interval(secs => $5), $6, $7) RETURNING id`,
    [phone, purpose, hash(phone, purpose, code), pv ? null : code, TTL_SEC(), ip, pv || 'manual']);
  // Số chưa đăng ký khi quên mật khẩu: không gửi thật (tránh dò số), nhưng phản hồi giống hệt
  if (!opts.silent) {
    const text = `Ma xac thuc Viec Den cua ban la ${code}. Het han sau ${Math.round(TTL_SEC() / 60)} phut. Khong chia se ma nay cho bat ky ai.`;
    try { const d = await sendSms(phone, text); await q(`UPDATE otp_codes SET delivery=$2 WHERE id=$1`, [row.id, d]); }
    catch (e: any) {
      log.error(`Gửi SMS lỗi (${pv}): ${e?.message}`);
      await q(`UPDATE otp_codes SET delivery=$2, manual_code=$3 WHERE id=$1`, [row.id, 'error: ' + String(e?.message || e).slice(0, 200), code]);
    }
  } else {
    await q(`UPDATE otp_codes SET delivery='skipped', manual_code=NULL WHERE id=$1`, [row.id]);
  }
  return { sent: true, channel: pv ? 'sms' : 'manual', expires_in: TTL_SEC(), resend_after: RESEND_SEC(),
    ...(process.env.OTP_DEV_ECHO === 'true' ? { dev_code: code } : {}) };
}

/** Kiểm tra và dùng mã (mỗi mã dùng một lần). */
export async function consumeOtp(phone: string, purpose: OtpPurpose, code: string) {
  const c = (code || '').replace(/\D/g, '');
  const r = await q1(`SELECT * FROM otp_codes WHERE phone=$1 AND purpose=$2 AND consumed_at IS NULL ORDER BY created_at DESC LIMIT 1`, [phone, purpose]);
  if (!r) throw new AppError('OTP_INVALID', 'Chưa có mã xác thực — bấm "Gửi mã"', 422);
  if (new Date(r.expires_at) < new Date()) throw new AppError('OTP_EXPIRED', 'Mã xác thực đã hết hạn — bấm "Gửi lại mã"', 422);
  if (r.attempts >= 5) throw new AppError('OTP_LOCKED', 'Nhập sai quá 5 lần — bấm "Gửi lại mã" để nhận mã mới', 422);
  const ok = c.length === 6 && timingSafeEqual(Buffer.from(hash(phone, purpose, c)), Buffer.from(r.code_hash));
  if (!ok) {
    await q(`UPDATE otp_codes SET attempts=attempts+1 WHERE id=$1`, [r.id]);
    throw new AppError('OTP_INVALID', `Mã xác thực không đúng (còn ${Math.max(0, 4 - r.attempts)} lần thử)`, 422);
  }
  await q(`UPDATE otp_codes SET consumed_at=now(), manual_code=NULL WHERE id=$1`, [r.id]);
}

export async function runOtpRetention() {
  await q(`UPDATE otp_codes SET manual_code=NULL WHERE manual_code IS NOT NULL AND (expires_at < now() OR consumed_at IS NOT NULL)`);
  const r = await q(`DELETE FROM otp_codes WHERE created_at < now() - interval '7 days' RETURNING id`);
  return { otp: r.length };
}
