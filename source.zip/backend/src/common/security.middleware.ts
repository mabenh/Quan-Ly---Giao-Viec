/**
 * Lớp bảo vệ HTTP chung (SEC-01 mục 8, 9):
 * - Header bảo mật; HSTS khi chạy sau HTTPS.
 * - Giới hạn tốc độ theo IP cho toàn API và chặt hơn cho đăng nhập/đăng ký.
 * - Đếm phản hồi 403/404 theo người dùng để phát hiện dò ID (chỉ tạo cảnh báo, không tự khóa).
 */
import { hit, securityAlert } from './privacy';

const isTest = () => process.env.NODE_ENV === 'test' && process.env.RATE_LIMIT_IN_TEST !== 'true';
const n = (v: string | undefined, d: number) => (v && !isNaN(Number(v)) ? Number(v) : d);

export function securityMiddleware() {
  const perMin = n(process.env.RATE_LIMIT_IP_PER_MIN, 1200);
  const authPerMin = n(process.env.RATE_LIMIT_AUTH_PER_MIN, 30);
  return (req: any, res: any, next: any) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('X-Frame-Options', 'DENY');
    res.setHeader('Referrer-Policy', 'no-referrer');
    res.setHeader('Permissions-Policy', 'geolocation=(), payment=()');
    if (req.secure || req.headers['x-forwarded-proto'] === 'https') res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
    const url: string = req.originalUrl || req.url || '';
    if (!url.startsWith('/api/')) return next();
    res.setHeader('Cache-Control', 'no-store');
    const ip = (req.headers['x-forwarded-for'] as string)?.split(',')[0].trim() || req.socket?.remoteAddress || 'unknown';
    if (!isTest()) {
      if (hit('ip:' + ip, 60000) > perMin) {
        if (hit('ipalert:' + ip, 3600000) === 1) securityAlert({ kind: 'request_burst', detail: `IP ${ip} vượt ${perMin} yêu cầu/phút` });
        return res.status(429).json({ error: { code: 'RATE_LIMITED', message: 'Quá nhiều yêu cầu. Vui lòng thử lại sau.' } });
      }
      if (/\/auth\/(login|register|refresh|activate)/.test(url) && hit('auth:' + ip, 60000) > authPerMin) {
        return res.status(429).json({ error: { code: 'RATE_LIMITED', message: 'Bạn thử đăng nhập quá nhiều lần. Vui lòng đợi 1 phút.' } });
      }
    }
    res.on('finish', () => {
      const ctx = req.ctx;
      if (!ctx?.userId || (res.statusCode !== 403 && res.statusCode !== 404)) return;
      const c = hit('deny:' + ctx.userId, 10 * 60000);
      if (c === 20 || c === 60 || c === 150) {
        securityAlert({ companyId: ctx.companyId, userId: ctx.userId, memberId: ctx.memberId, kind: 'id_scan', detail: `${c} yêu cầu bị từ chối/không tìm thấy trong 10 phút` });
      }
    });
    next();
  };
}
