import { CanActivate, ExecutionContext, Injectable, SetMetadata } from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import * as jwt from 'jsonwebtoken';
import { q1 } from '../db/db';
import { Errors } from './errors';
import { Role } from './context';

export const PUBLIC = 'isPublic';
export const Public = () => SetMetadata(PUBLIC, true);
export const ROLES = 'roles';
export const Roles = (...roles: Role[]) => SetMetadata(ROLES, roles);

export const jwtSecret = () => process.env.JWT_SECRET || 'dev-secret-change-me';

@Injectable()
export class AuthGuard implements CanActivate {
  constructor(private reflector: Reflector) {}

  async canActivate(ec: ExecutionContext): Promise<boolean> {
    const isPublic = this.reflector.getAllAndOverride<boolean>(PUBLIC, [ec.getHandler(), ec.getClass()]);
    if (isPublic) return true;
    const req = ec.switchToHttp().getRequest();
    const h: string = req.headers.authorization || '';
    const token = h.startsWith('Bearer ') ? h.slice(7) : (req.query?.access_token as string);
    if (!token) throw Errors.unauthorized();
    let payload: any;
    try {
      payload = jwt.verify(token, jwtSecret());
    } catch {
      throw Errors.unauthorized();
    }
    // Kiểm tra lại membership mỗi request để khóa tài khoản/thu hồi quyền có hiệu lực ngay.
    const m = await q1(
      `SELECT cm.id, cm.company_id, cm.role, cm.status, u.status AS user_status, u.name
         FROM company_members cm JOIN users u ON u.id = cm.user_id
        WHERE cm.id = $1 AND cm.user_id = $2`,
      [payload.mid, payload.sub],
    );
    if (!m || m.status !== 'active' || m.user_status !== 'active') throw Errors.unauthorized('Tài khoản đã bị khóa hoặc không còn thuộc công ty');
    req.ctx = { userId: payload.sub, memberId: m.id, companyId: m.company_id, role: m.role, name: m.name };
    const roles = this.reflector.getAllAndOverride<Role[]>(ROLES, [ec.getHandler(), ec.getClass()]);
    if (roles && !roles.includes(m.role)) throw Errors.forbidden();
    return true;
  }
}
