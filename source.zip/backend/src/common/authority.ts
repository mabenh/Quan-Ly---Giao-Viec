/**
 * Phân cấp & quyền hạn (Hệ thống phân cấp doanh nghiệp tầng 3–7).
 * Tách độc lập: chức vụ (positions.tier), phòng ban & chức năng (departments.function), vai trò hệ thống (company_members.role),
 * quyền hạn (capabilities — mặc định theo tầng, có thể ghi đè theo chức vụ). Chức danh không quyết định toàn bộ quyền truy cập dữ liệu:
 * phạm vi xem còn phụ thuộc phòng ban, nhóm phụ trách, nhiệm vụ được giao.
 */
import { Queryable, getPool, q, q1 } from '../db/db';
import { Ctx } from './context';

export type Capability =
  | 'create_order' | 'review_order' | 'approve_order'   // lập / xem xét / duyệt đơn hàng sản xuất
  | 'assign_all' | 'assign_dept' | 'assign_group'       // phạm vi giao việc
  | 'manage_templates_all' | 'manage_templates_dept'    // tạo/sửa mẫu công việc
  | 'view_company' | 'view_dept' | 'view_group';         // phạm vi xem báo cáo

export const CAP_LABEL: Record<Capability, string> = {
  create_order: 'Lập đơn hàng sản xuất', review_order: 'Xem xét đơn hàng (kế hoạch/năng lực)', approve_order: 'Duyệt / phát hành đơn hàng',
  assign_all: 'Giao việc toàn công ty', assign_dept: 'Giao việc trong phòng ban', assign_group: 'Giao việc trong nhóm',
  manage_templates_all: 'Quản lý mẫu công việc mọi phòng ban', manage_templates_dept: 'Tạo/sửa mẫu công việc của phòng mình',
  view_company: 'Xem báo cáo toàn công ty', view_dept: 'Xem báo cáo phòng ban', view_group: 'Xem báo cáo nhóm',
};
export const TIER_LABEL: Record<number, string> = { 3: 'Tầng 3 — Điều hành', 4: 'Tầng 4 — Quản lý cấp cao', 5: 'Tầng 5 — Quản lý trung gian', 6: 'Tầng 6 — Quản lý trực tiếp', 7: 'Tầng 7 — Nhân sự thực thi' };
export const DEPT_FUNCTION: Record<string, string> = {
  production: 'Sản xuất / vận hành', planning: 'Kế hoạch sản xuất', sales: 'Kinh doanh', warehouse: 'Kho vận – chuỗi cung ứng', qa: 'Chất lượng QA/QC',
  hr: 'Nhân sự', admin: 'Hành chính', finance: 'Tài chính – kế toán', it: 'Công nghệ thông tin', marketing: 'Marketing', hse: 'An toàn – môi trường (HSE)',
  security: 'Bảo vệ – an ninh', cs: 'Chăm sóc khách hàng', other: 'Khác',
};
/** Phòng ban được lập đơn hàng (tầng 5) và xem xét đơn hàng. */
export const ORDER_CREATOR_FUNCS = ['sales', 'planning', 'production'];
export const ORDER_REVIEWER_FUNCS = ['planning', 'production'];

export function defaultCaps(tier: number, func: string | null): Set<Capability> {
  const s = new Set<Capability>();
  if (tier <= 3) ['create_order', 'review_order', 'approve_order', 'assign_all', 'manage_templates_all', 'view_company'].forEach((c) => s.add(c as Capability));
  else if (tier === 4) ['create_order', 'review_order', 'approve_order', 'assign_all', 'manage_templates_all', 'view_company'].forEach((c) => s.add(c as Capability));
  else if (tier === 5) {
    ['assign_dept', 'manage_templates_dept', 'view_dept'].forEach((c) => s.add(c as Capability));
    if (func && ORDER_CREATOR_FUNCS.includes(func)) s.add('create_order');
    if (func && ORDER_REVIEWER_FUNCS.includes(func)) s.add('review_order');
  } else if (tier === 6) ['assign_group', 'view_group'].forEach((c) => s.add(c as Capability));
  return s;
}
const ROLE_TIER: Record<string, number> = { owner: 3, admin: 4, manager: 5, hr: 5, reviewer: 5, handler: 6, employee: 7 };

export interface Authority {
  tier: number; positionId: string | null; positionName: string | null;
  departmentId: string | null; departmentName: string | null; deptFunction: string | null;
  hrScoped: boolean; caps: Set<Capability>;
  /** null = mọi nhóm */
  assignableGroupIds: string[] | null;
  visibleGroupIds: string[] | null;
}

export async function authority(ctx: Pick<Ctx, 'memberId' | 'companyId' | 'role'>, db: Queryable = getPool()): Promise<Authority> {
  const m = await q1(
    `SELECT cm.role, cm.department_id, d.name AS department_name, d.function AS dept_function, p.id AS position_id, p.name AS position_name, p.tier, p.capabilities
       FROM company_members cm LEFT JOIN positions p ON p.id=cm.position_id LEFT JOIN departments d ON d.id=cm.department_id WHERE cm.id=$1`, [ctx.memberId], db);
  const role = m?.role || ctx.role;
  const tier = m?.tier ?? ROLE_TIER[role] ?? 7;
  const func = m?.dept_function ?? (role === 'hr' ? 'hr' : null);
  const caps = defaultCaps(tier, func);
  for (const [k, v] of Object.entries(m?.capabilities || {})) { if (v) caps.add(k as Capability); else caps.delete(k as Capability); }
  const isAdminRole = role === 'owner' || role === 'admin';
  if (isAdminRole) ['create_order', 'review_order', 'approve_order', 'assign_all', 'manage_templates_all', 'view_company'].forEach((c) => caps.add(c as Capability));
  // Quản lý nhân sự: chỉ giao việc trong phòng nhân sự, không lập đơn hàng, không thấy nhóm ngoài phòng ban mình
  const hrScoped = !isAdminRole && (role === 'hr' || func === 'hr');
  if (hrScoped) { caps.delete('create_order'); caps.delete('review_order'); caps.delete('approve_order'); caps.delete('assign_all'); caps.delete('manage_templates_all'); caps.delete('view_company'); }

  const led = (await q(`SELECT id FROM groups WHERE company_id=$1 AND deleted_at IS NULL AND (manager_member_id=$2 OR leader_member_id=$2)`, [ctx.companyId, ctx.memberId], db)).map((r) => r.id);
  const member = (await q(`SELECT g.id FROM groups g JOIN group_members gm ON gm.group_id=g.id WHERE g.company_id=$1 AND g.deleted_at IS NULL AND gm.company_member_id=$2`, [ctx.companyId, ctx.memberId], db)).map((r) => r.id);
  const deptGroups = m?.department_id ? (await q(`SELECT id FROM groups WHERE company_id=$1 AND deleted_at IS NULL AND department_id=$2`, [ctx.companyId, m.department_id], db)).map((r) => r.id) : [];
  let assignable: string[] | null;
  if (caps.has('assign_all')) assignable = null;
  else if (caps.has('assign_dept')) assignable = [...new Set([...deptGroups, ...led])];
  else if (caps.has('assign_group') || led.length) assignable = led;
  else assignable = [];
  let visible: string[] | null = null;
  if (hrScoped) visible = [...new Set([...deptGroups, ...led, ...member])];
  return { tier, positionId: m?.position_id ?? null, positionName: m?.position_name ?? null, departmentId: m?.department_id ?? null, departmentName: m?.department_name ?? null,
    deptFunction: func, hrScoped, caps, assignableGroupIds: assignable, visibleGroupIds: visible };
}

/** Người có quyền xem xét / duyệt đơn hàng (trừ người lập). */
export async function orderAuthorities(companyId: string, cap: 'review_order' | 'approve_order', exclude: string[], db: Queryable = getPool()) {
  const rows = await q(`SELECT cm.id, cm.role, u.name FROM company_members cm JOIN users u ON u.id=cm.user_id WHERE cm.company_id=$1 AND cm.status='active'`, [companyId], db);
  const out: { id: string; name: string }[] = [];
  for (const r of rows) {
    if (exclude.includes(r.id)) continue;
    const a = await authority({ memberId: r.id, companyId, role: r.role }, db);
    if (a.caps.has(cap)) out.push({ id: r.id, name: r.name });
  }
  return out;
}

export const DEFAULT_POSITIONS: { key: string; name: string; tier: number; grp: string }[] = [
  { key: 'ceo', name: 'Tổng giám đốc', tier: 3, grp: 'leadership' }, { key: 'coo', name: 'Giám đốc điều hành / vận hành', tier: 3, grp: 'leadership' },
  { key: 'deputy_ceo', name: 'Phó tổng giám đốc', tier: 4, grp: 'senior' }, { key: 'division_director', name: 'Giám đốc khối', tier: 4, grp: 'senior' },
  { key: 'plant_director', name: 'Giám đốc nhà máy / chi nhánh', tier: 4, grp: 'senior' },
  { key: 'dept_director', name: 'Giám đốc phòng', tier: 5, grp: 'dept' }, { key: 'dept_head', name: 'Trưởng phòng', tier: 5, grp: 'dept' },
  { key: 'dept_deputy', name: 'Phó phòng', tier: 5, grp: 'dept' }, { key: 'unit_head', name: 'Trưởng bộ phận', tier: 5, grp: 'dept' },
  { key: 'team_leader', name: 'Trưởng nhóm', tier: 6, grp: 'team' }, { key: 'team_deputy', name: 'Phó nhóm', tier: 6, grp: 'team' },
  { key: 'supervisor', name: 'Giám sát', tier: 6, grp: 'team' }, { key: 'foreman', name: 'Tổ trưởng', tier: 6, grp: 'team' }, { key: 'shift_lead', name: 'Trưởng ca', tier: 6, grp: 'team' },
  { key: 'workshop_manager', name: 'Quản đốc phân xưởng', tier: 6, grp: 'team' },
  { key: 'specialist', name: 'Chuyên viên', tier: 7, grp: 'expert' }, { key: 'senior_specialist', name: 'Chuyên viên cao cấp', tier: 7, grp: 'expert' }, { key: 'expert', name: 'Chuyên gia', tier: 7, grp: 'expert' },
  { key: 'staff', name: 'Nhân viên', tier: 7, grp: 'execution' }, { key: 'technician', name: 'Kỹ thuật viên', tier: 7, grp: 'execution' }, { key: 'worker', name: 'Công nhân', tier: 7, grp: 'execution' },
  { key: 'collaborator', name: 'Cộng tác viên', tier: 7, grp: 'support' }, { key: 'intern', name: 'Thực tập sinh', tier: 7, grp: 'support' },
];
export const JOB_GRADES = ['Intern', 'Junior', 'Middle', 'Senior', 'Specialist', 'Expert', 'Principal', 'Manager', 'Senior Manager'];

export async function ensurePositions(db: Queryable, companyId: string) {
  let i = 0;
  for (const p of DEFAULT_POSITIONS) {
    await q(`INSERT INTO positions(company_id, name, tier, grp, system_key, sort) VALUES ($1,$2,$3,$4,$5,$6) ON CONFLICT (company_id, system_key) WHERE system_key IS NOT NULL DO NOTHING`,
      [companyId, p.name, p.tier, p.grp, p.key, i++], db);
  }
}
