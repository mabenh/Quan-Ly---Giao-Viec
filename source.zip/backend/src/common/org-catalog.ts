/**
 * Danh mục cơ cấu tổ chức chuẩn (v12): Khối → Phòng ban → Bộ phận → Nhóm.
 * Doanh nghiệp chọn các phòng ban cần dùng; hệ thống tạo phòng ban, bộ phận và nhóm tương ứng (có thể đổi tên, bổ sung, ngừng dùng).
 */
export interface CatalogUnit { name: string; groups: string[] }
export interface CatalogDept { key: string; block: string; name: string; function: string; description: string; units: CatalogUnit[] }

export const ORG_BLOCKS = [
  'Khối Quản trị & Hành chính (Back-office)',
  'Khối Kinh doanh & Phát triển thị trường (Front-office)',
  'Khối Sản xuất, Vận hành & Kỹ thuật (Operations & Tech)',
  'Khối Quản lý cấp cao & Dự án',
];
const [B1, B2, B3, B4] = ORG_BLOCKS;

export const ORG_CATALOG: CatalogDept[] = [
  { key: 'hr_admin', block: B1, name: 'Phòng Hành chính - Nhân sự', function: 'hr', description: 'Tuyển dụng, đào tạo, tính lương (C&B), quản lý văn phòng phẩm, tài sản và các thủ tục hành chính nội bộ.', units: [
    { name: 'Bộ phận Tuyển dụng (Talent Acquisition)', groups: ['Nhóm Tuyển dụng khối Văn phòng (Back-office)', 'Nhóm Tuyển dụng khối Kinh doanh / Kỹ thuật (Mass/Tech)', 'Nhóm Xây dựng thương hiệu tuyển dụng (Employer Branding)'] },
    { name: 'Bộ phận Tiền lương & Phúc lợi (C&B)', groups: ['Nhóm Chấm công & Tính lương (Payroll)', 'Nhóm Bảo hiểm, Thuế & Hợp đồng lao động'] },
    { name: 'Bộ phận Đào tạo & Phát triển (L&D)', groups: ['Nhóm Đào tạo hội nhập (Onboarding)', 'Nhóm Đào tạo kỹ năng & Phát triển nhân tài'] },
    { name: 'Bộ phận Hành chính (Admin)', groups: ['Nhóm Lễ tân & Văn thư lưu trữ', 'Nhóm Quản lý tài sản, Cơ sở vật chất & Tạp vụ'] },
  ] },
  { key: 'finance', block: B1, name: 'Phòng Tài chính - Kế toán', function: 'finance', description: 'Quản lý dòng tiền, lập báo cáo tài chính, kê khai thuế, thanh toán và kiểm soát ngân sách.', units: [
    { name: 'Bộ phận Kế toán tổng hợp', groups: ['Nhóm Kế toán thuế & Báo cáo tài chính', 'Nhóm Kiểm soát nội bộ & Ngân sách'] },
    { name: 'Bộ phận Kế toán thanh toán & Công nợ', groups: ['Nhóm Kế toán phải thu (AR)', 'Nhóm Kế toán phải trả (AP)', 'Nhóm Thủ quỹ & Giao dịch ngân hàng'] },
    { name: 'Bộ phận Kế toán kho & Giá thành', groups: ['Nhóm Kế toán hàng tồn kho', 'Nhóm Tính giá thành sản phẩm'] },
  ] },
  { key: 'legal', block: B1, name: 'Phòng Pháp chế', function: 'legal', description: 'Tư vấn luật, soạn thảo và rà soát hợp đồng, xử lý các vấn đề liên quan đến bản quyền và tuân thủ pháp luật.', units: [] },
  { key: 'audit', block: B1, name: 'Phòng Kiểm toán nội bộ', function: 'audit', description: 'Đánh giá hiệu quả kiểm soát nội bộ, quản trị rủi ro và phát hiện sai phạm tài chính/vận hành.', units: [] },
  { key: 'sales', block: B2, name: 'Phòng Kinh doanh', function: 'sales', description: 'Tìm kiếm khách hàng, tư vấn bán hàng, đàm phán hợp đồng và chịu trách nhiệm trực tiếp về doanh số.', units: [
    { name: 'Bộ phận Bán hàng trực tiếp (Direct / Field Sales)', groups: ['Nhóm Kinh doanh khách hàng cá nhân (B2C)', 'Nhóm Kinh doanh khách hàng doanh nghiệp (B2B)'] },
    { name: 'Bộ phận Tư vấn qua điện thoại / Trực tuyến (Telesales / Inside Sales)', groups: ['Nhóm Chốt đơn qua điện thoại', 'Nhóm Tư vấn qua kênh chat / Mạng xã hội'] },
    { name: 'Bộ phận Hỗ trợ kinh doanh (Sales Admin / Sales Ops)', groups: ['Nhóm Quản lý đơn hàng & Hợp đồng', 'Nhóm Theo dõi doanh số & Hoa hồng'] },
  ] },
  { key: 'marketing', block: B2, name: 'Phòng Marketing', function: 'marketing', description: 'Xây dựng thương hiệu, chạy quảng cáo, quản lý truyền thông, tổ chức sự kiện và nghiên cứu thị trường.', units: [
    { name: 'Bộ phận Tiếp thị số (Digital Marketing)', groups: ['Nhóm Chạy quảng cáo (Performance / Paid Ads)', 'Nhóm Tối ưu hóa công cụ tìm kiếm (SEO & Website)'] },
    { name: 'Bộ phận Sáng tạo nội dung (Content & Creative)', groups: ['Nhóm Biên tập nội dung (Content / Copywriter)', 'Nhóm Thiết kế đồ họa (Graphic Design)', 'Nhóm Sản xuất Video (Multimedia)'] },
    { name: 'Bộ phận Thương hiệu & Truyền thông (Brand & PR)', groups: ['Nhóm Quan hệ công chúng & Báo chí (PR)', 'Nhóm Tổ chức sự kiện & Tài trợ (Event & Activation)'] },
    { name: 'Bộ phận Nghiên cứu thị trường (Market Research)', groups: ['Nhóm Phân tích dữ liệu khách hàng (Data Analyst)', 'Nhóm Phát triển sản phẩm mới (Product Marketing)'] },
  ] },
  { key: 'cs', block: B2, name: 'Phòng Chăm sóc khách hàng', function: 'cs', description: 'Hỗ trợ giải đáp thắc mắc, xử lý khiếu nại và duy trì mối quan hệ sau bán hàng.', units: [
    { name: 'Bộ phận Tổng đài & Tiếp nhận thông tin (Call Center / Helpdesk)', groups: ['Nhóm Giải đáp thắc mắc đa kênh (Hotline, Email, Chat)'] },
    { name: 'Bộ phận Xử lý khiếu nại & Hậu mãi (After-sales)', groups: ['Nhóm Giải quyết sự cố & Đổi trả', 'Nhóm Khảo sát hài lòng & Giữ chân khách hàng (Retention)'] },
  ] },
  { key: 'bd', block: B2, name: 'Phòng Phát triển kinh doanh', function: 'bd', description: 'Mở rộng thị trường mới, tìm kiếm đối tác chiến lược và phát triển các kênh phân phối mới.', units: [] },
  { key: 'it', block: B3, name: 'Phòng Công nghệ thông tin', function: 'it', description: 'Quản trị hệ thống mạng, bảo mật dữ liệu, hỗ trợ kỹ thuật nội bộ hoặc phát triển phần mềm.', units: [
    { name: 'Bộ phận Hạ tầng & Hỗ trợ kỹ thuật (IT Helpdesk & Infra)', groups: ['Nhóm Quản trị mạng & Bảo mật (System/Network Admin)', 'Nhóm Hỗ trợ thiết bị văn phòng (IT Support)'] },
    { name: 'Bộ phận Phát triển phần mềm (Software Development)', groups: ['Nhóm Lập trình giao diện (Frontend)', 'Nhóm Lập trình hệ thống (Backend)', 'Nhóm Phát triển ứng dụng di động (Mobile App)'] },
    { name: 'Bộ phận Quản trị sản phẩm & Kiểm thử (Product & QA)', groups: ['Nhóm Phân tích nghiệp vụ (BA)', 'Nhóm Thiết kế trải nghiệm người dùng (UI/UX)', 'Nhóm Kiểm thử chất lượng phần mềm (Tester / QC)'] },
  ] },
  { key: 'rnd', block: B3, name: 'Phòng Nghiên cứu & Phát triển', function: 'rnd', description: 'Nghiên cứu, thiết kế và thử nghiệm sản phẩm/dịch vụ mới.', units: [] },
  { key: 'procurement', block: B3, name: 'Phòng Thu mua', function: 'procurement', description: 'Tìm kiếm nhà cung cấp, đàm phán giá cả và đặt mua nguyên vật liệu, trang thiết bị.', units: [] },
  { key: 'scm', block: B3, name: 'Phòng Chuỗi cung ứng & Kho vận', function: 'warehouse', description: 'Quản lý xuất nhập tồn kho, điều phối vận chuyển và giao nhận hàng hóa.', units: [
    { name: 'Bộ phận Thu mua (Purchasing)', groups: ['Nhóm Mua hàng trong nước', 'Nhóm Xuất nhập khẩu (Import/Export)'] },
    { name: 'Bộ phận Quản lý kho (Warehouse)', groups: ['Nhóm Nhập hàng & Kiểm đếm (Inbound)', 'Nhóm Đóng gói & Xuất hàng (Outbound)'] },
    { name: 'Bộ phận Điều vận (Logistics / Delivery)', groups: ['Nhóm Điều phối đơn vị vận chuyển ngoài', 'Nhóm Đội xe giao nhận nội bộ'] },
  ] },
  { key: 'qa', block: B3, name: 'Phòng Quản lý chất lượng (QA/QC)', function: 'qa', description: 'Kiểm tra, giám sát và đảm bảo chất lượng sản phẩm/dịch vụ đạt tiêu chuẩn trước khi ra thị trường.', units: [] },
  { key: 'production', block: B3, name: 'Phòng Sản xuất', function: 'production', description: 'Trực tiếp vận hành dây chuyền, gia công và chế tạo sản phẩm.', units: [] },
  { key: 'bod', block: B4, name: 'Ban Giám đốc', function: 'bod', description: 'Đưa ra chiến lược phát triển, điều hành tổng thể và chịu trách nhiệm cao nhất về hoạt động của công ty.', units: [] },
  { key: 'pmo', block: B4, name: 'Phòng Quản lý dự án (PMO)', function: 'pmo', description: 'Lập kế hoạch, điều phối nguồn lực và giám sát tiến độ các dự án trọng điểm.', units: [] },
  { key: 'secretary', block: B4, name: 'Ban Trợ lý / Thư ký', function: 'secretary', description: 'Hỗ trợ Ban Giám đốc sắp xếp lịch trình, tổng hợp báo cáo và điều phối thông tin giữa các phòng ban.', units: [] },
];
