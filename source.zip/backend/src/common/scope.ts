/**
 * Phạm vi quản lý (Đặc tả v2.0 mục 3, 10): quyền xem dữ liệu được tính ở server theo vai trò + nhóm + quan hệ quản lý.
 * - Ban quản trị (owner/admin): toàn công ty.
 * - Quản lý/Trưởng nhóm: các nhóm mình quản lý hoặc làm trưởng nhóm + cấp dưới (trực tiếp/gián tiếp).
 * - Nhân viên: chính mình.
 */
import { Queryable, getPool, q, q1 } from '../db/db';
import { Ctx, isAdmin } from './context';

export const isBoard = (ctx: Ctx) => isAdmin(ctx);

/** Trưởng nhóm của nhóm (mặc định = quản lý nhóm). */
export async function leaderOf(groupId: string | null | undefined, db: Queryable = getPool()): Promise<string | null> {
  if (!groupId) return null;
  const g = await q1(`SELECT COALESCE(leader_member_id, manager_member_id) AS id FROM groups WHERE id=$1`, [groupId], db);
  return g?.id ?? null;
}

/** Nhóm mà người này quản lý hoặc làm trưởng nhóm (Ban quản trị: mọi nhóm). */
export async function managedGroupIds(ctx: Ctx, db: Queryable = getPool()): Promise<string[]> {
  const rows = isBoard(ctx)
    ? await q(`SELECT id FROM groups WHERE company_id=$1 AND deleted_at IS NULL`, [ctx.companyId], db)
    : await q(`SELECT id FROM groups WHERE company_id=$1 AND deleted_at IS NULL AND (manager_member_id=$2 OR leader_member_id=$2)`, [ctx.companyId, ctx.memberId], db);
  return rows.map((r) => r.id);
}

/** Thành viên trong phạm vi (gồm chính mình). null = toàn công ty. */
export async function scopeMemberIds(ctx: Ctx, db: Queryable = getPool()): Promise<string[] | null> {
  if (isBoard(ctx)) return null;
  const rows = await q(
    `WITH RECURSIVE sub AS (SELECT id FROM company_members WHERE supervisor_member_id=$1 UNION SELECT cm.id FROM company_members cm JOIN sub ON cm.supervisor_member_id=sub.id)
     SELECT id FROM sub
     UNION SELECT gm.company_member_id FROM group_members gm JOIN groups g ON g.id=gm.group_id WHERE g.deleted_at IS NULL AND (g.manager_member_id=$1 OR g.leader_member_id=$1)
     UNION SELECT $1::uuid`, [ctx.memberId], db);
  return rows.map((r) => r.id);
}

export async function inScope(ctx: Ctx, memberId: string, db: Queryable = getPool()) {
  const s = await scopeMemberIds(ctx, db);
  return s === null ? !!(await q1(`SELECT 1 FROM company_members WHERE id=$1 AND company_id=$2`, [memberId, ctx.companyId], db)) : s.includes(memberId);
}

/** Có quyền điều phối/ghi nhận cho nhóm (trưởng nhóm, quản lý nhóm, Ban quản trị). */
export async function canLeadGroup(ctx: Ctx, groupId: string | null | undefined, db: Queryable = getPool()) {
  if (!groupId) return false;
  if (isBoard(ctx)) return true;
  return !!(await q1(`SELECT 1 FROM groups WHERE id=$1 AND company_id=$2 AND (manager_member_id=$3 OR leader_member_id=$3)`, [groupId, ctx.companyId, ctx.memberId], db));
}
