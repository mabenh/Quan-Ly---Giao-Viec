import { readFileSync } from 'fs';
import { join } from 'path';
import { getPool, closePool } from './db';

export async function migrate() {
  const sql = readFileSync(join(__dirname, 'schema.sql'), 'utf8');
  await getPool().query(sql);
  const { ensureAllLibraries } = await import('../modules/library');
  await ensureAllLibraries(getPool());
}

if (require.main === module) {
  migrate()
    .then(() => { console.log('Migration OK'); return closePool(); })
    .catch((e) => { console.error(e); process.exit(1); });
}
