import { readFileSync } from 'fs';
import { join } from 'path';
import { getPool, closePool } from './db';

export async function migrate() {
  const sql = readFileSync(join(__dirname, 'schema.sql'), 'utf8');
  // Di chuyển CSDL không bị giới hạn thời gian truy vấn (statement_timeout chỉ áp cho yêu cầu thường)
  const c = await getPool().connect();
  try { await c.query('SET statement_timeout = 0'); await c.query(sql); } finally { await c.query('RESET statement_timeout').catch(() => {}); c.release(); }
  const { ensureAllLibraries } = await import('../modules/library');
  await ensureAllLibraries(getPool());
}

if (require.main === module) {
  migrate()
    .then(() => { console.log('Migration OK'); return closePool(); })
    .catch((e) => { console.error(e); process.exit(1); });
}
