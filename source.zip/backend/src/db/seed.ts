/* Dữ liệu demo: chạy qua chính REST API để đảm bảo đúng nghiệp vụ. Mật khẩu chung: Demo@123 */
import 'reflect-metadata';
import * as bcrypt from 'bcryptjs';
import { q, q1, closePool, getPool } from './db';
import { migrate } from './migrate';
import { createApp } from '../main';
import { createCompanyWithOwner } from '../modules/auth.controller';
import { relinkLibraryDepartments } from '../modules/library';

const PW = 'Demo@123';

export async function resetDb() {
  await getPool().query(`DROP SCHEMA public CASCADE; CREATE SCHEMA public;`);
  await migrate();
}

export async function seed(baseUrl?: string) {
  const app = baseUrl ? null : await createApp();
  if (app) await app.listen(0);
  const url = baseUrl || `http://127.0.0.1:${(app!.getHttpServer().address() as any).port}/api/v1`;
  const tokens: Record<string, string> = {};
  const call = async (who: string, method: string, path: string, body?: any) => {
    const r = await fetch(url + path, {
      method, headers: { 'Content-Type': 'application/json', ...(tokens[who] ? { Authorization: `Bearer ${tokens[who]}` } : {}) },
      body: body ? JSON.stringify(body) : undefined,
    });
    const j: any = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(`${method} ${path} [${who}] -> ${r.status} ${JSON.stringify(j)}`);
    return j;
  };
  const login = async (who: string, email: string) => { tokens[who] = (await call(who, 'POST', '/auth/login', { email, password: PW })).access_token; };

  const { companyId, memberId: ownerId } = await createCompanyWithOwner({ companyName: 'Công ty TNHH Demo Việt', name: 'Nguyễn Văn An', email: 'owner@demo.vn', phone: '0901000001', password: PW, plan: 'medium' });
  await q(`INSERT INTO users(name, phone, password_hash, is_platform_admin) VALUES ('Quản trị Việc Đến', '0900000000', $1, true)`, [await bcrypt.hash(PW, 10)]);
  await login('owner', 'owner@demo.vn');

  const hash = await bcrypt.hash(PW, 10);
  const PHONES: Record<string, string> = {
    'admin@demo.vn': '0901000002', 'quanly1@demo.vn': '0901000003', 'quanly2@demo.vn': '0901000004', 'truongkt@demo.vn': '0901000005',
    'kythuat@demo.vn': '0901000006', 'nv1@demo.vn': '0901000007', 'nv2@demo.vn': '0901000008', 'nv3@demo.vn': '0901000009',
    'nv4@demo.vn': '0901000010', 'reviewer@demo.vn': '0901000011', 'nhansu@demo.vn': '0901000012', 'baove@demo.vn': '0901000013', 'kho@demo.vn': '0901000014',
  };
  const mk = async (name: string, email: string, role: string, title: string, supervisor: string | null, dept: string | null = null) => {
    const phone = PHONES[email];
    const u = await q1(`INSERT INTO users(name,email,phone,password_hash) VALUES ($1,$2,$3,$4) RETURNING id`, [name, email, phone, hash]);
    const m = await q1(`INSERT INTO company_members(company_id,user_id,role,title,supervisor_member_id,department_id) VALUES ($1,$2,$3,$4,$5,$6) RETURNING id`,
      [companyId, u.id, role, title, supervisor, dept]);
    return m.id as string;
  };
  const admin = await mk('Trần Thị Bình', 'admin@demo.vn', 'admin', 'Trưởng phòng Hành chính - Nhân sự', ownerId);
  const reviewer = await mk('Lý Thu Hà', 'reviewer@demo.vn', 'reviewer', 'Kiểm soát nội bộ (reviewer độc lập)', null);
  const hr = await mk('Mai Thị Nhân', 'nhansu@demo.vn', 'hr', 'Chuyên viên Nhân sự', admin);
  const m1 = await mk('Lê Văn Cường', 'quanly1@demo.vn', 'manager', 'Trưởng nhóm Vận hành', admin);
  const m2 = await mk('Phạm Thị Dung', 'quanly2@demo.vn', 'manager', 'Trưởng nhóm Kinh doanh', admin);
  const ktDept = await q1(`INSERT INTO departments(company_id,name) VALUES ($1,'Kỹ thuật - CNTT') RETURNING id`, [companyId]);
  const hcDept = await q1(`INSERT INTO departments(company_id,name,head_member_id) VALUES ($1,'Hành chính - Cơ sở vật chất',$2) RETURNING id`, [companyId, admin]);
  const kt1 = await mk('Hoàng Văn Em', 'truongkt@demo.vn', 'handler', 'Trưởng bộ phận Kỹ thuật', admin, ktDept.id);
  const kt2 = await mk('Đỗ Văn Phúc', 'kythuat@demo.vn', 'handler', 'Kỹ thuật viên', kt1, ktDept.id);
  await q(`UPDATE departments SET head_member_id=$2 WHERE id=$1`, [ktDept.id, kt1]);
  const e1 = await mk('Vũ Thị Giang', 'nv1@demo.vn', 'employee', 'Nhân viên vận hành', m1);
  const e2 = await mk('Bùi Văn Hùng', 'nv2@demo.vn', 'employee', 'Nhân viên vận hành', m1);
  const e3 = await mk('Ngô Thị Lan', 'nv3@demo.vn', 'employee', 'Nhân viên điều phối', m1);
  const e4 = await mk('Đặng Văn Minh', 'nv4@demo.vn', 'employee', 'Nhân viên kinh doanh', m2);
  const bvDept = await q1(`INSERT INTO departments(company_id,name) VALUES ($1,'Bảo vệ - An ninh') RETURNING id`, [companyId]);
  const khoDept = await q1(`INSERT INTO departments(company_id,name) VALUES ($1,'Kho vận') RETURNING id`, [companyId]);
  const bv = await mk('Trương Văn Bảo', 'baove@demo.vn', 'handler', 'Trưởng ca bảo vệ', admin, bvDept.id);
  const kho = await mk('Lương Thị Kho', 'kho@demo.vn', 'handler', 'Thủ kho', admin, khoDept.id);
  await q(`UPDATE departments SET head_member_id=$2 WHERE id=$1`, [bvDept.id, bv]);
  await q(`UPDATE departments SET head_member_id=$2 WHERE id=$1`, [khoDept.id, kho]);
  await relinkLibraryDepartments(getPool(), companyId);
  void reviewer; void kt2; void hcDept; void hr;

  for (const [k, e] of Object.entries({ admin: 'admin@demo.vn', m1: 'quanly1@demo.vn', m2: 'quanly2@demo.vn', kt1: 'truongkt@demo.vn', kt2: 'kythuat@demo.vn',
    e1: 'nv1@demo.vn', e2: 'nv2@demo.vn', e3: 'nv3@demo.vn', e4: 'nv4@demo.vn', hr: 'nhansu@demo.vn' })) await login(k, e);

  const types = await call('owner', 'GET', '/company/task-types');
  const tt = (n: string) => types.find((t: any) => t.name === n).id;
  await call('admin', 'POST', '/company/task-templates', {
    name: 'Báo cáo vận hành tuần', taskTypeId: tt('Vận hành'), description: 'Tổng hợp số liệu vận hành tuần, sự cố và đề xuất.',
    complexity: 'simple', requirementLevel: 'normal', estimatedHours: 4,
    criteria: [{ direction: 'input', criterion: 'Số liệu từ hệ thống vận hành' }, { direction: 'output', criterion: 'Báo cáo đúng mẫu, gửi trước 17h thứ Sáu' }],
  });

  const g1 = await call('m1', 'POST', '/groups', { name: 'Nhóm Vận hành', description: 'Vận hành kho và điều phối giao nhận', memberIds: [e1, e2, e3] });
  const g2 = await call('m2', 'POST', '/groups', { name: 'Nhóm Kinh doanh', description: 'Chăm sóc khách hàng doanh nghiệp', memberIds: [e3, e4] });

  const day = 86400000; const now = Date.now();
  const mkTask = (who: string, groupId: string, owner: string, title: string, o: any = {}) => call(who, 'POST', '/tasks', {
    title, description: o.description || `${title}: thực hiện theo phạm vi và tiêu chí đã thống nhất.`, groupId, ownerMemberId: owner,
    collaboratorIds: o.collab || [], taskTypeId: tt(o.type || 'Vận hành'), complexity: o.complexity || 'medium', requirementLevel: o.req || 'normal',
    estimatedHours: o.hours || 12, dueAt: new Date(now + (o.dueDays ?? 3) * day).toISOString(), priority: o.priority || 'normal',
    criteria: [{ direction: 'input', criterion: 'Yêu cầu và dữ liệu đầu vào đầy đủ' }, { direction: 'output', criterion: o.output || 'Kết quả đạt tiêu chí nghiệm thu, có bằng chứng' }],
    subitems: o.subitems, unexpected: o.unexpected,
  });
  const complete = async (id: string, owner: string, scores: any, o: { revision?: boolean; daysAgo?: number; late?: boolean } = {}) => {
    await call(owner, 'POST', `/tasks/${id}/start`);
    await call(owner, 'POST', `/tasks/${id}/submit`, { outputDescription: 'Đã hoàn thành và đính kèm kết quả.', completionPercent: 100 });
    if (o.revision) {
      await call('m1', 'POST', `/tasks/${id}/review`, { decision: 'revision', comment: 'Bổ sung bảng số liệu chi tiết theo khu vực.' });
      await call(owner, 'POST', `/tasks/${id}/start`);
      await call(owner, 'POST', `/tasks/${id}/submit`, { outputDescription: 'Đã bổ sung số liệu.', completionPercent: 100 });
    }
    const t = await call('owner', 'GET', `/tasks/${id}`);
    const reviewer = t.group_id === g1.id ? 'm1' : 'm2';
    await call(reviewer, 'POST', `/tasks/${id}/review`, { decision: 'approve', scores, comment: 'Đạt yêu cầu.' });
    // Đưa dữ liệu về các ngày trước trong tháng để báo cáo có xu hướng
    const back = (o.daysAgo ?? 2) * day;
    const sub = o.late ? `due_at + interval '1 day'` : `due_at - interval '4 hours'`;
    await q(`UPDATE tasks SET created_at=now() - $2::interval, due_at=now() - $3::interval, first_submitted_at=NULL WHERE id=$1`,
      [id, `${(o.daysAgo ?? 2) + 5} days`, `${o.daysAgo ?? 2} days`]);
    await q(`UPDATE tasks SET first_submitted_at=${sub}, submitted_at=${sub}, completed_at=${sub} + interval '2 hours' WHERE id=$1`, [id]);
    void back;
  };
  const R = (o: number, q: number, s: number, p: number) => ({ output: o, quality: q, schedule: s, process: p });

  const t1 = await mkTask('m1', g1.id, e1, 'Kiểm kê kho định kỳ tháng', { complexity: 'complex', req: 'high', hours: 32 });
  await complete(t1.id, 'e1', R(90, 88, 95, 90), { daysAgo: 6 });
  const t2 = await mkTask('m1', g1.id, e2, 'Cập nhật quy trình nhập hàng', { complexity: 'medium', collab: [e1] });
  await complete(t2.id, 'e2', R(80, 75, 70, 80), { daysAgo: 4, revision: true, late: true });
  const t3 = await mkTask('m1', g1.id, e3, 'Báo cáo vận hành tuần', { complexity: 'simple', hours: 4 });
  await complete(t3.id, 'e3', R(95, 92, 100, 90), { daysAgo: 3 });
  const t4 = await mkTask('m2', g2.id, e4, 'Đề xuất gói dịch vụ cho khách hàng ABC', { type: 'Kinh doanh', complexity: 'very_complex', req: 'very_high', hours: 80 });
  await complete(t4.id, 'e4', R(85, 90, 90, 85), { daysAgo: 1 });
  // Việc đột xuất - yêu cầu đa dạng
  const t5 = await mkTask('m1', g1.id, e1, 'Xử lý đơn hàng gấp cho khách hàng XYZ', {
    complexity: 'complex', req: 'high', hours: 16, dueDays: 1, priority: 'urgent',
    unexpected: { category: 'urgent', requirementStructure: 'diverse', cause: 'customer', causeDetail: 'Khách hàng tăng đơn đột xuất 40%', impact: 'Lùi kiểm kê khu B 1 ngày' },
    subitems: [{ title: 'Điều phối 2 xe bổ sung', extraHours: 0 }, { title: 'Đóng gói lại 120 kiện', extraHours: 0 }],
  });
  await call('m1', 'POST', `/tasks/${t5.id}/subitems`, { title: 'Khách hàng bổ sung yêu cầu dán nhãn song ngữ', extraHours: 3, reason: 'Khách yêu cầu qua điện thoại lúc 14h' });
  await call('e1', 'POST', `/tasks/${t5.id}/start`);
  await call('e1', 'POST', `/tasks/${t5.id}/submit`, { outputDescription: 'Đã giao đủ đơn, dán nhãn song ngữ.', completionPercent: 100 });
  await call('m1', 'POST', `/tasks/${t5.id}/review`, { decision: 'approve', scores: { requirement: 90, response: 95, handling: 88, quality: 85, coordination: 90 } });
  // Việc đang làm / quá hạn / chờ nghiệm thu
  const t6 = await mkTask('m1', g1.id, e2, 'Bảo trì xe nâng số 3', { complexity: 'medium', dueDays: -1 });
  await call('e2', 'POST', `/tasks/${t6.id}/start`);
  const t7 = await mkTask('m1', g1.id, e3, 'Sắp xếp lại khu vực hàng trả về', { complexity: 'simple', hours: 6, dueDays: 2 });
  await call('e3', 'POST', `/tasks/${t7.id}/start`);
  await call('e3', 'POST', `/tasks/${t7.id}/submit`, { outputDescription: 'Đã sắp xếp, có ảnh trước/sau.', completionPercent: 100 });
  await mkTask('m1', g1.id, e1, 'Đào tạo nhân viên mới về an toàn kho', { complexity: 'medium', dueDays: 5, collab: [e2] });
  await mkTask('m2', g2.id, e3, 'Khảo sát mức độ hài lòng khách hàng quý', { type: 'Kinh doanh', complexity: 'medium', dueDays: 7 });

  // Báo cáo trở ngại: liên kết nhiệm vụ quá hạn
  const r1 = await call('e2', 'POST', '/workplace-reports', {
    category: 'equipment', severity: 'high', description: 'Xe nâng số 3 hỏng bơm thủy lực, không nâng được pallet trên 500kg.',
    detectedAt: new Date(now - 2 * day).toISOString(), groupId: g1.id, affectedTaskId: t6.id, asset: 'XN-03', location: 'Kho A',
    tempMeasure: 'Dùng xe nâng tay cho pallet nhỏ',
  });
  await call('m1', 'POST', `/workplace-reports/${r1.id}/assign`, { departmentId: ktDept.id, impactConfirmed: true, comment: 'Ưu tiên trong ngày' });
  await call('kt1', 'POST', `/workplace-reports/${r1.id}/acknowledge`, { assigneeId: kt2, comment: 'Giao anh Phúc kiểm tra' });
  await call('kt2', 'POST', `/workplace-reports/${r1.id}/updates`, { status: 'waiting', comment: 'Chờ nhà cung cấp giao bơm thay thế', newDueAt: new Date(now + 2 * day).toISOString() });
  const r2 = await call('e3', 'POST', '/workplace-reports', {
    category: 'software', severity: 'medium', description: 'Phần mềm quản lý kho treo khi in phiếu xuất hàng loạt (>50 phiếu).',
    detectedAt: new Date(now - day).toISOString(), groupId: g1.id, asset: 'WMS',
  });
  await call('m1', 'POST', `/workplace-reports/${r2.id}/assign`, { departmentId: ktDept.id, impactConfirmed: true });
  await call('kt1', 'POST', `/workplace-reports/${r2.id}/acknowledge`, {});
  await call('kt1', 'POST', `/workplace-reports/${r2.id}/updates`, { status: 'resolved_pending', comment: 'Đã tăng timeout máy in và cập nhật driver.' });
  await call('e3', 'POST', `/workplace-reports/${r2.id}/confirm`, { decision: 'close', comment: 'Đã in thử 80 phiếu OK' });
  await call('e4', 'POST', '/workplace-reports', {
    category: 'facility', severity: 'low', description: 'Điều hòa phòng kinh doanh chảy nước, ảnh hưởng khu vực bàn làm việc.', detectedAt: new Date().toISOString(), groupId: g2.id,
  });

  // Tăng ca
  const ot = (who: string, daysAgo: number, hours: number, o: any) => call(who, 'POST', '/overtime-records', {
    startAt: new Date(now - daysAgo * day).toISOString(), endAt: new Date(now - daysAgo * day + hours * 3600000).toISOString(), ...o,
  });
  const o1 = await ot('e1', 3, 3, { otType: 'ad_hoc', cause: 'Xử lý đơn hàng gấp khách XYZ', taskId: t5.id, requestedByMemberId: m1, notifiedInAdvance: false });
  await call('m1', 'POST', `/overtime-records/${o1.id}/review`, { decision: 'confirm' });
  await ot('e2', 2, 2, { otType: 'incident', cause: 'Xe nâng hỏng, phải bốc xếp thủ công', reportId: r1.id, groupId: g1.id });
  await ot('e4', 5, 2.5, { otType: 'workload', cause: 'Hoàn thiện đề xuất ABC đúng hạn', taskId: t4.id });

  // Bản ghi công việc tự khai báo
  await call('e1', 'POST', '/work-records', { locationSource: 'unknown', 
    title: 'Hỗ trợ nhóm Kinh doanh đóng gói hàng mẫu', groupId: g1.id, requesterMemberId: m2,
    startAt: new Date(now - 2 * day).toISOString(), endAt: new Date(now - 2 * day + 2 * 3600000).toISOString(),
    recordType: 'support', result: 'Đóng gói 30 bộ hàng mẫu', reasonNotInSystem: 'Chị Dung nhờ trực tiếp, không tạo nhiệm vụ',
  });
  const wr2 = await call('e2', 'POST', '/work-records', { locationSource: 'unknown', 
    title: 'Trực kho ngoài giờ nhận hàng nhập khẩu', groupId: g1.id, requesterMemberId: m1,
    startAt: new Date(now - 4 * day + 10 * 3600000).toISOString(), endAt: new Date(now - 4 * day + 14 * 3600000).toISOString(),
    recordType: 'assigned_outside', result: 'Nhận đủ 2 container', reasonNotInSystem: 'Quản lý gọi điện giao việc buổi tối',
  });
  await call('m1', 'POST', `/work-records/${wr2.id}/reviews`, {
    decision: 'partial', reason: 'Thời gian khai báo trùng giờ nghỉ trưa vượt quy định 30 phút', basis: 'Nhật ký cổng kho 12:00-13:00',
    acceptedMinutes: 180, acceptedScope: 'Nhận hàng 13:00-16:00', rejectedScope: 'Khoảng 12:00-13:00 trùng giờ nghỉ',
  });
  await call('e2', 'POST', `/work-records/${wr2.id}/disputes`, { response: 'dispute', comment: 'Hôm đó container đến lúc 12h, tôi phải nhận hàng ngay, có ảnh chụp giờ.' });

  // Ghim việc gấp, khai việc nhanh, nghỉ phép
  await call('m1', 'POST', `/tasks/${t6.id}/pin`, { pinned: true, note: 'Xe nâng phục vụ đơn XYZ — ưu tiên' });
  await call('m1', 'POST', '/quick-claims', {
    counterpartId: e3, channel: 'call', occurredAt: new Date(now - 3600000).toISOString(),
    title: 'Gọi khách hàng ABC xác nhận lịch giao hàng tuần sau', description: 'Đã trao đổi qua điện thoại, cần gọi trước 16h', estimatedHours: 1,
  });
  const qc2 = await call('e2', 'POST', '/quick-claims', {
    counterpartId: m1, channel: 'zalo', occurredAt: new Date(now - 2 * 3600000).toISOString(),
    title: 'Kiểm đếm lại lô hàng trả về số 15', description: 'Anh Cường nhắn Zalo lúc 9h', estimatedHours: 2, alreadyDone: true,
  });
  await call('m1', 'POST', `/quick-claims/${qc2.id}/confirm`, {});
  const nextMon = new Date(now + ((8 - new Date(now).getDay()) % 7 || 7) * day).toISOString().slice(0, 10);
  const lv = await call('e1', 'POST', '/leaves', { leaveType: 'day', startDate: nextMon, endDate: nextMon, reason: 'Việc gia đình', handover: 'Bàn giao kiểm kê khu B cho Hùng' });
  await call('m1', 'POST', `/leaves/${lv.id}/decide`, { decision: 'approve', reason: 'Đồng ý' });
  await call('e3', 'POST', '/leaves', { leaveType: 'shift', date: nextMon, shift: 'afternoon', reason: 'Đi khám sức khỏe định kỳ' });

  // Giấy phép mẫu: giao hàng có giấy ra cổng (khai báo – cấp tự động) và giấy dùng xe (chờ duyệt)
  const tg = await call('m1', 'POST', '/tasks', {
    title: 'Giao hàng cho khách Hòa Bình', description: 'Giao 20 thùng hàng theo đơn DH-1024', groupId: g1.id, ownerMemberId: e2, taskTypeId: tt('Vận hành'),
    complexity: 'simple', requirementLevel: 'normal', estimatedHours: 4, dueAt: new Date(now + day).toISOString(),
    criteria: [{ direction: 'output', criterion: 'Giao đúng hẹn, có biên bản xác nhận' }],
  });
  const vf = new Date(now - 3600000).toISOString(); const vt = new Date(now + 8 * 3600000).toISOString();
  await call('m1', 'POST', '/permits', { typeKey: 'gate_pass', taskId: tg.id, holderId: e2, data: { muc_dich: 'Giao hàng cho khách Hòa Bình', bien_so: '29C-123.45' }, validFrom: vf, validTo: vt, mode: 'declaration' });
  await call('m1', 'POST', '/permits', { typeKey: 'vehicle_use', taskId: tg.id, holderId: e2, data: { xe: 'Xe tải 1,5 tấn 29C-123.45', lo_trinh: 'Kho A → Hòa Bình' }, validFrom: vf, validTo: vt, mode: 'approval' });
  // Quyết định điều chuyển đang chờ bàn giao
  await call('hr', 'POST', '/decisions', {
    memberId: e4, decisionType: 'transfer', effectiveDate: new Date(now + 7 * day).toISOString().slice(0, 10),
    handoverDeadline: new Date(now + 5 * day).toISOString(), newGroupId: g1.id, removeFromGroups: true, newSupervisorId: m1, handoverReceiverId: m2,
    reason: 'Tăng cường nhân sự cho nhóm Vận hành mùa cao điểm cuối năm',
  });

  // Mô tả vai trò
  const jr = async (key: string, ids: string[]) => { const r = await q1(`SELECT id FROM job_roles WHERE company_id=$1 AND system_key=$2`, [companyId, key]); await q(`UPDATE company_members SET job_role_id=$1 WHERE id = ANY($2::uuid[])`, [r.id, ids]); };
  await jr('nv_van_hanh', [e1, e2, e3]); await jr('nv_kinh_doanh', [e4]); await jr('ky_thuat', [kt1, kt2]); await jr('bao_ve', [bv]);
  await jr('nv_kho', [kho]); await jr('truong_nhom', [m1, m2]); await jr('nhan_su', [hr]);

  // Việc nhiều giai đoạn: Nhập lô hàng (đặt → nhận + kiểm song song → nhập kho)
  const root = await call('m1', 'POST', '/tasks', {
    title: 'Nhập lô hàng nước giải khát tháng 11', description: 'Nhập 500 thùng từ NCC Tân Hiệp, đi qua 3 giai đoạn', groupId: g1.id, ownerMemberId: m1,
    taskTypeId: tt('Kho vận'), complexity: 'complex', requirementLevel: 'normal', estimatedHours: 16, dueAt: new Date(now + 4 * day).toISOString(),
    criteria: [{ direction: 'output', criterion: 'Nhập đủ 500 thùng, chứng từ đầy đủ' }],
  });
  const child = (title: string, owner: string, stageNo: number, hours = 3) => call('m1', 'POST', '/tasks', { parentId: root.id, title, groupId: g1.id, ownerMemberId: owner, stageNo, estimatedHours: hours });
  const s1 = await child('Đặt hàng với NCC Tân Hiệp', e1, 1, 2);
  await child('Nhận hàng tại kho A', e2, 2); await child('Kiểm hàng (số lượng, hạn dùng)', e3, 2); await child('Nhập kho & cập nhật tồn', e1, 3);
  await call('e1', 'POST', `/tasks/${s1.id}/start`);
  await call('e1', 'POST', `/tasks/${s1.id}/submit`, { outputDescription: 'Đã chốt đơn, NCC giao ngày mai' });
  await call('m1', 'POST', `/tasks/${s1.id}/review`, { decision: 'approve', scores: { output: 90, quality: 90, schedule: 100, process: 85 } });

  // Trở ngại do quản lý tự giải quyết bằng cách giao việc
  const r3 = await call('e2', 'POST', '/workplace-reports', { category: 'facility', severity: 'medium', description: 'Kệ hàng số 4 khu B bị nghiêng, có nguy cơ đổ', detectedAt: new Date().toISOString(), groupId: g1.id });
  await call('m1', 'POST', '/tasks', { title: 'Gia cố kệ hàng số 4 khu B', description: 'Kệ hàng số 4 khu B bị nghiêng, có nguy cơ đổ', groupId: g1.id, ownerMemberId: e3,
    taskTypeId: tt('Vận hành'), complexity: 'simple', requirementLevel: 'normal', estimatedHours: 3, dueAt: new Date(now + day).toISOString(),
    criteria: [{ direction: 'output', criterion: 'Kệ được gia cố, chụp ảnh xác nhận' }], sourceReportId: r3.id });

  // Khai báo nhanh: việc thường ngày (tự chủ động) và việc ngoài vai trò
  await call('e1', 'POST', '/work-records', { locationSource: 'unknown',  recordType: 'routine', initiative: true, title: 'Sắp xếp lại khu vực đóng gói', groupId: g1.id,
    startAt: new Date(now - 3 * 3600000).toISOString(), endAt: new Date(now - 2 * 3600000).toISOString() });
  await call('e2', 'POST', '/work-records', { locationSource: 'unknown',  recordType: 'outside_role', title: 'Hỗ trợ nhóm Kinh doanh tiếp khách hội chợ', requesterMemberId: m2, groupId: g1.id,
    reasonNotInSystem: 'Nhóm Kinh doanh thiếu người trong ngày hội chợ', startAt: new Date(now - 26 * 3600000).toISOString(), endAt: new Date(now - 22 * 3600000).toISOString() });

  // ---- v6: vị trí, định mức, tổ đóng gói có trưởng nhóm, chuỗi đơn hàng liên bộ phận, phiên làm việc, sản lượng ----
  const loc = async (name: string, kind: string) => (await call('admin', 'POST', '/company/locations', { name, kind })).id;
  const lKho = await loc('Kho nguyên liệu', 'raw_store'); await loc('Kho lạnh', 'cold_store'); const lPack = await loc('Khu đóng gói', 'packing');
  await loc('Sàn sản xuất', 'production_floor'); await loc('Văn phòng', 'office');
  const stdPack = await call('admin', 'POST', '/company/production-standards', { name: 'Đóng túi 1kg', unit: 'túi', quantity: 100, minutes: 30 });
  await call('admin', 'POST', '/company/production-standards', { name: 'Dán nhãn thùng', unit: 'thùng', quantity: 60, minutes: 30 });
  const g3 = await call('m1', 'POST', '/groups', { name: 'Tổ Đóng gói', description: 'Đóng gói, dán nhãn thành phẩm', memberIds: [e3, e4] });
  await call('m1', 'PATCH', `/groups/${g3.id}`, { leaderMemberId: e3 });
  const ch = await call('m1', 'POST', '/tasks', {
    title: 'Đơn hàng Siêu thị Hòa Phát — 2.000 túi gạo 1kg', description: 'Đơn liên bộ phận: chuẩn bị nguyên liệu → đóng gói → giao hàng', groupId: g1.id, ownerMemberId: m1,
    taskTypeId: tt('Vận hành'), complexity: 'complex', requirementLevel: 'high', estimatedHours: 24, dueAt: new Date(now + 4 * day).toISOString(),
    criteria: [{ direction: 'output', criterion: 'Giao đủ 2.000 túi đạt chuẩn đúng hạn' }], isChain: true, customerName: 'Siêu thị Hòa Phát', importance: 'high', orderValue: 56000000, marginNote: 'Biên lợi nhuận dự kiến 12%',
  });
  const cc = (title: string, groupId: string, owner: string, stageNo: number, minutes: number, extra: any = {}) =>
    call('m1', 'POST', '/tasks', { parentId: ch.id, title, groupId, ownerMemberId: owner, stageNo, estimatedHours: minutes / 60, standardMinutes: minutes, ...extra });
  const cs1 = await cc('Chuẩn bị gạo nguyên liệu tại kho', g1.id, e1, 1, 120, { workLocationId: lKho });
  const cs2 = await cc('Đóng gói 2.000 túi 1kg', g3.id, e3, 2, 600, { workLocationId: lPack, locationRequired: true, productionStandardId: stdPack.id, handoverMode: 'stage' });
  await cc('Giao hàng cho siêu thị', g1.id, e2, 3, 180, { autoStart: 'on_handover' });
  await call('m1', 'POST', `/chains/${ch.id}/schedule`, { apply: true });
  // Giai đoạn 1: phiên làm việc + bàn giao kết quả -> nghiệm thu -> mở giai đoạn 2 kèm bàn giao chờ tiếp nhận
  await call('e1', 'POST', '/sessions/start', { taskId: cs1.id });
  await q(`UPDATE work_sessions SET started_at=now() - interval '95 minutes' WHERE task_id=$1 AND ended_at IS NULL`, [cs1.id]);
  await call('e1', 'POST', '/sessions/pause', { category: 'objective_pause', reason: 'Xe nâng kho nguyên liệu hỏng, chờ kỹ thuật' });
  await q(`UPDATE work_time_records SET started_at=now() - interval '20 minutes' WHERE member_id=$1 AND ended_at IS NULL`, [e1]);
  await call('e1', 'POST', '/sessions/resume', {});
  await q(`UPDATE work_sessions SET started_at=now() - interval '15 minutes' WHERE task_id=$1 AND ended_at IS NULL`, [cs1.id]);
  await call('e1', 'POST', `/tasks/${cs1.id}/submit`, { outputDescription: 'Đã xuất 2.000 kg gạo ra khu đóng gói, kèm phiếu xuất kho PX-118' });
  await call('m1', 'POST', `/tasks/${cs1.id}/review`, { decision: 'approve', scores: { output: 95, quality: 90, schedule: 100, process: 90 } });
  // Tổ đóng gói đã có một phần sản lượng từ ca trước (bản ghi của trưởng nhóm) — bàn giao chờ tiếp nhận
  await call('e3', 'POST', `/handovers/${(await q1(`SELECT id FROM handover_contexts WHERE to_task_id=$1`, [cs2.id])).id}/decide`, { decision: 'accept' });
  await call('e3', 'POST', '/sessions/start', { taskId: cs2.id });
  await q(`UPDATE work_sessions SET started_at=now() - interval '120 minutes' WHERE task_id=$1 AND ended_at IS NULL`, [cs2.id]);
  await call('e3', 'POST', '/production', { taskId: cs2.id, mode: 'stage', participants: [e3, e4], actualQty: 380, acceptedQty: 360, rejectedQty: 12, reworkQty: 8, backlogQty: 0,
    plannedQty: 400, executionMinutes: 120, note: 'Ca sáng — máy hàn túi số 2 chạy chậm' });
  // v7: nhiệm vụ thường trực (ghi nhận phiên), tăng ca ngoại lệ do cấp trên ghi nhận
  const std1 = await call('m1', 'POST', '/tasks', { title: 'Trực kho ca ngày', description: 'Nhiệm vụ thường trực của Nhóm Vận hành: nhận hàng lẻ, sắp xếp kệ, hỗ trợ xuất hàng', groupId: g1.id, ownerMemberId: m1,
    taskTypeId: tt('Kho vận'), isStanding: true });
  for (const [i, title] of ['Nhận hàng lẻ', 'Sắp xếp kệ & 5S', 'Hỗ trợ xuất hàng'].entries()) await call('m1', 'POST', '/tasks', { parentId: std1.id, title, groupId: g1.id, ownerMemberId: m1, stageNo: 1, estimatedHours: 1 + i * 0 });
  await call('m1', 'POST', '/tasks', { title: 'Vận hành dây chuyền đóng gói', description: 'Thường trực Tổ Đóng gói', groupId: g3.id, ownerMemberId: e3, taskTypeId: tt('Vận hành'), isStanding: true });
  await call('m1', 'POST', '/overtime-records/exception', { memberIds: [e2], kind: 'offsite', place: 'Xưởng đối tác Bình Dương', startAt: new Date(now - day - 3 * 3600000).toISOString(),
    endAt: new Date(now - day - 3600000).toISOString(), workMinutes: 480, cause: 'Lắp đặt kệ tại xưởng đối tác, máy chấm công không có tại chỗ' });
  await q(`UPDATE companies SET settings = jsonb_set(COALESCE(settings,'{}'::jsonb), '{workTime}', '{"rest":{"enabled":true}}'::jsonb, true)`);

  if (app) await app.close();
  return { companyId };
}

if (require.main === module) {
  (async () => {
    await resetDb();
    await seed();
    console.log('Seed OK. Đăng nhập bằng SĐT, mật khẩu Demo@123: 0901000001 Owner, 0901000002 Admin, 0901000003 Quản lý Vận hành, 0901000004 Quản lý KD, 0901000005 Trưởng KT, 0901000006 Kỹ thuật viên, 0901000007..10 Nhân viên 1-4, 0901000011 Reviewer, 0901000012 Nhân sự, 0901000013 Bảo vệ, 0901000014 Thủ kho, 0900000000 Quản trị nền tảng');
    await closePool();
    process.exit(0);
  })().catch(async (e) => { console.error(e); await closePool(); process.exit(1); });
}
