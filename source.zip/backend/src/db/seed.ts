/* Dữ liệu demo: chạy qua chính REST API để đảm bảo đúng nghiệp vụ. Mật khẩu chung: Demo@123 */
import 'reflect-metadata';
import * as bcrypt from 'bcryptjs';
import { q, q1, closePool, getPool } from './db';
import { migrate } from './migrate';
import { createApp } from '../main';
import { createCompanyWithOwner } from '../modules/auth.controller';

const PW = 'Demo@123';

export async function resetDb() {
  await getPool().query(`DROP SCHEMA public CASCADE; CREATE SCHEMA public;`);
  await migrate();
}

export async function seed(baseUrl?: string) {
  const app = baseUrl ? null : await createApp();
  if (app) await app.listen(0);
  const url = baseUrl || `http://127.0.0.1:${(app!.getHttpServer().address() as any).port}/api/v1`;
  const tokens: Record<string, string> = {};
  const call = async (who: string, method: string, path: string, body?: any) => {
    const r = await fetch(url + path, {
      method, headers: { 'Content-Type': 'application/json', ...(tokens[who] ? { Authorization: `Bearer ${tokens[who]}` } : {}) },
      body: body ? JSON.stringify(body) : undefined,
    });
    const j: any = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(`${method} ${path} [${who}] -> ${r.status} ${JSON.stringify(j)}`);
    return j;
  };
  const login = async (who: string, email: string) => { tokens[who] = (await call(who, 'POST', '/auth/login', { email, password: PW })).access_token; };

  const { companyId, memberId: ownerId } = await createCompanyWithOwner({ companyName: 'Công ty TNHH Demo Việt', name: 'Nguyễn Văn An', email: 'owner@demo.vn', password: PW });
  await login('owner', 'owner@demo.vn');

  const hash = await bcrypt.hash(PW, 10);
  const mk = async (name: string, email: string, role: string, title: string, supervisor: string | null, dept: string | null = null) => {
    const u = await q1(`INSERT INTO users(name,email,password_hash) VALUES ($1,$2,$3) RETURNING id`, [name, email, hash]);
    const m = await q1(`INSERT INTO company_members(company_id,user_id,role,title,supervisor_member_id,department_id) VALUES ($1,$2,$3,$4,$5,$6) RETURNING id`,
      [companyId, u.id, role, title, supervisor, dept]);
    return m.id as string;
  };
  const admin = await mk('Trần Thị Bình', 'admin@demo.vn', 'admin', 'Trưởng phòng Hành chính - Nhân sự', ownerId);
  const reviewer = await mk('Lý Thu Hà', 'reviewer@demo.vn', 'reviewer', 'Kiểm soát nội bộ (reviewer độc lập)', null);
  const m1 = await mk('Lê Văn Cường', 'quanly1@demo.vn', 'manager', 'Trưởng nhóm Vận hành', admin);
  const m2 = await mk('Phạm Thị Dung', 'quanly2@demo.vn', 'manager', 'Trưởng nhóm Kinh doanh', admin);
  const ktDept = await q1(`INSERT INTO departments(company_id,name) VALUES ($1,'Kỹ thuật - CNTT') RETURNING id`, [companyId]);
  const hcDept = await q1(`INSERT INTO departments(company_id,name,head_member_id) VALUES ($1,'Hành chính - Cơ sở vật chất',$2) RETURNING id`, [companyId, admin]);
  const kt1 = await mk('Hoàng Văn Em', 'truongkt@demo.vn', 'handler', 'Trưởng bộ phận Kỹ thuật', admin, ktDept.id);
  const kt2 = await mk('Đỗ Văn Phúc', 'kythuat@demo.vn', 'handler', 'Kỹ thuật viên', kt1, ktDept.id);
  await q(`UPDATE departments SET head_member_id=$2 WHERE id=$1`, [ktDept.id, kt1]);
  const e1 = await mk('Vũ Thị Giang', 'nv1@demo.vn', 'employee', 'Nhân viên vận hành', m1);
  const e2 = await mk('Bùi Văn Hùng', 'nv2@demo.vn', 'employee', 'Nhân viên vận hành', m1);
  const e3 = await mk('Ngô Thị Lan', 'nv3@demo.vn', 'employee', 'Nhân viên điều phối', m1);
  const e4 = await mk('Đặng Văn Minh', 'nv4@demo.vn', 'employee', 'Nhân viên kinh doanh', m2);
  void reviewer; void kt2; void hcDept;

  for (const [k, e] of Object.entries({ admin: 'admin@demo.vn', m1: 'quanly1@demo.vn', m2: 'quanly2@demo.vn', kt1: 'truongkt@demo.vn', kt2: 'kythuat@demo.vn',
    e1: 'nv1@demo.vn', e2: 'nv2@demo.vn', e3: 'nv3@demo.vn', e4: 'nv4@demo.vn' })) await login(k, e);

  const types = await call('owner', 'GET', '/company/task-types');
  const tt = (n: string) => types.find((t: any) => t.name === n).id;
  await call('admin', 'POST', '/company/task-templates', {
    name: 'Báo cáo vận hành tuần', taskTypeId: tt('Vận hành'), description: 'Tổng hợp số liệu vận hành tuần, sự cố và đề xuất.',
    complexity: 'simple', requirementLevel: 'normal', estimatedHours: 4,
    criteria: [{ direction: 'input', criterion: 'Số liệu từ hệ thống vận hành' }, { direction: 'output', criterion: 'Báo cáo đúng mẫu, gửi trước 17h thứ Sáu' }],
  });

  const g1 = await call('m1', 'POST', '/groups', { name: 'Nhóm Vận hành', description: 'Vận hành kho và điều phối giao nhận', memberIds: [e1, e2, e3] });
  const g2 = await call('m2', 'POST', '/groups', { name: 'Nhóm Kinh doanh', description: 'Chăm sóc khách hàng doanh nghiệp', memberIds: [e3, e4] });

  const day = 86400000; const now = Date.now();
  const mkTask = (who: string, groupId: string, owner: string, title: string, o: any = {}) => call(who, 'POST', '/tasks', {
    title, description: o.description || `${title}: thực hiện theo phạm vi và tiêu chí đã thống nhất.`, groupId, ownerMemberId: owner,
    collaboratorIds: o.collab || [], taskTypeId: tt(o.type || 'Vận hành'), complexity: o.complexity || 'medium', requirementLevel: o.req || 'normal',
    estimatedHours: o.hours || 12, dueAt: new Date(now + (o.dueDays ?? 3) * day).toISOString(), priority: o.priority || 'normal',
    criteria: [{ direction: 'input', criterion: 'Yêu cầu và dữ liệu đầu vào đầy đủ' }, { direction: 'output', criterion: o.output || 'Kết quả đạt tiêu chí nghiệm thu, có bằng chứng' }],
    subitems: o.subitems, unexpected: o.unexpected,
  });
  const complete = async (id: string, owner: string, scores: any, o: { revision?: boolean; daysAgo?: number; late?: boolean } = {}) => {
    await call(owner, 'POST', `/tasks/${id}/start`);
    await call(owner, 'POST', `/tasks/${id}/submit`, { outputDescription: 'Đã hoàn thành và đính kèm kết quả.', completionPercent: 100 });
    if (o.revision) {
      await call('m1', 'POST', `/tasks/${id}/review`, { decision: 'revision', comment: 'Bổ sung bảng số liệu chi tiết theo khu vực.' });
      await call(owner, 'POST', `/tasks/${id}/start`);
      await call(owner, 'POST', `/tasks/${id}/submit`, { outputDescription: 'Đã bổ sung số liệu.', completionPercent: 100 });
    }
    const t = await call('owner', 'GET', `/tasks/${id}`);
    const reviewer = t.group_id === g1.id ? 'm1' : 'm2';
    await call(reviewer, 'POST', `/tasks/${id}/review`, { decision: 'approve', scores, comment: 'Đạt yêu cầu.' });
    // Đưa dữ liệu về các ngày trước trong tháng để báo cáo có xu hướng
    const back = (o.daysAgo ?? 2) * day;
    const sub = o.late ? `due_at + interval '1 day'` : `due_at - interval '4 hours'`;
    await q(`UPDATE tasks SET created_at=now() - $2::interval, due_at=now() - $3::interval, first_submitted_at=NULL WHERE id=$1`,
      [id, `${(o.daysAgo ?? 2) + 5} days`, `${o.daysAgo ?? 2} days`]);
    await q(`UPDATE tasks SET first_submitted_at=${sub}, submitted_at=${sub}, completed_at=${sub} + interval '2 hours' WHERE id=$1`, [id]);
    void back;
  };
  const R = (o: number, q: number, s: number, p: number) => ({ output: o, quality: q, schedule: s, process: p });

  const t1 = await mkTask('m1', g1.id, e1, 'Kiểm kê kho định kỳ tháng', { complexity: 'complex', req: 'high', hours: 32 });
  await complete(t1.id, 'e1', R(90, 88, 95, 90), { daysAgo: 6 });
  const t2 = await mkTask('m1', g1.id, e2, 'Cập nhật quy trình nhập hàng', { complexity: 'medium', collab: [e1] });
  await complete(t2.id, 'e2', R(80, 75, 70, 80), { daysAgo: 4, revision: true, late: true });
  const t3 = await mkTask('m1', g1.id, e3, 'Báo cáo vận hành tuần', { complexity: 'simple', hours: 4 });
  await complete(t3.id, 'e3', R(95, 92, 100, 90), { daysAgo: 3 });
  const t4 = await mkTask('m2', g2.id, e4, 'Đề xuất gói dịch vụ cho khách hàng ABC', { type: 'Kinh doanh', complexity: 'very_complex', req: 'very_high', hours: 80 });
  await complete(t4.id, 'e4', R(85, 90, 90, 85), { daysAgo: 1 });
  // Việc đột xuất - yêu cầu đa dạng
  const t5 = await mkTask('m1', g1.id, e1, 'Xử lý đơn hàng gấp cho khách hàng XYZ', {
    complexity: 'complex', req: 'high', hours: 16, dueDays: 1, priority: 'urgent',
    unexpected: { category: 'urgent', requirementStructure: 'diverse', cause: 'customer', causeDetail: 'Khách hàng tăng đơn đột xuất 40%', impact: 'Lùi kiểm kê khu B 1 ngày' },
    subitems: [{ title: 'Điều phối 2 xe bổ sung', extraHours: 0 }, { title: 'Đóng gói lại 120 kiện', extraHours: 0 }],
  });
  await call('m1', 'POST', `/tasks/${t5.id}/subitems`, { title: 'Khách hàng bổ sung yêu cầu dán nhãn song ngữ', extraHours: 3, reason: 'Khách yêu cầu qua điện thoại lúc 14h' });
  await call('e1', 'POST', `/tasks/${t5.id}/start`);
  await call('e1', 'POST', `/tasks/${t5.id}/submit`, { outputDescription: 'Đã giao đủ đơn, dán nhãn song ngữ.', completionPercent: 100 });
  await call('m1', 'POST', `/tasks/${t5.id}/review`, { decision: 'approve', scores: { requirement: 90, response: 95, handling: 88, quality: 85, coordination: 90 } });
  // Việc đang làm / quá hạn / chờ nghiệm thu
  const t6 = await mkTask('m1', g1.id, e2, 'Bảo trì xe nâng số 3', { complexity: 'medium', dueDays: -1 });
  await call('e2', 'POST', `/tasks/${t6.id}/start`);
  const t7 = await mkTask('m1', g1.id, e3, 'Sắp xếp lại khu vực hàng trả về', { complexity: 'simple', hours: 6, dueDays: 2 });
  await call('e3', 'POST', `/tasks/${t7.id}/start`);
  await call('e3', 'POST', `/tasks/${t7.id}/submit`, { outputDescription: 'Đã sắp xếp, có ảnh trước/sau.', completionPercent: 100 });
  await mkTask('m1', g1.id, e1, 'Đào tạo nhân viên mới về an toàn kho', { complexity: 'medium', dueDays: 5, collab: [e2] });
  await mkTask('m2', g2.id, e3, 'Khảo sát mức độ hài lòng khách hàng quý', { type: 'Kinh doanh', complexity: 'medium', dueDays: 7 });

  // Báo cáo trở ngại: liên kết nhiệm vụ quá hạn
  const r1 = await call('e2', 'POST', '/workplace-reports', {
    category: 'equipment', severity: 'high', description: 'Xe nâng số 3 hỏng bơm thủy lực, không nâng được pallet trên 500kg.',
    detectedAt: new Date(now - 2 * day).toISOString(), groupId: g1.id, affectedTaskId: t6.id, asset: 'XN-03', location: 'Kho A',
    tempMeasure: 'Dùng xe nâng tay cho pallet nhỏ',
  });
  await call('m1', 'POST', `/workplace-reports/${r1.id}/assign`, { departmentId: ktDept.id, impactConfirmed: true, comment: 'Ưu tiên trong ngày' });
  await call('kt1', 'POST', `/workplace-reports/${r1.id}/acknowledge`, { assigneeId: kt2, comment: 'Giao anh Phúc kiểm tra' });
  await call('kt2', 'POST', `/workplace-reports/${r1.id}/updates`, { status: 'waiting', comment: 'Chờ nhà cung cấp giao bơm thay thế', newDueAt: new Date(now + 2 * day).toISOString() });
  const r2 = await call('e3', 'POST', '/workplace-reports', {
    category: 'software', severity: 'medium', description: 'Phần mềm quản lý kho treo khi in phiếu xuất hàng loạt (>50 phiếu).',
    detectedAt: new Date(now - day).toISOString(), groupId: g1.id, asset: 'WMS',
  });
  await call('m1', 'POST', `/workplace-reports/${r2.id}/assign`, { departmentId: ktDept.id, impactConfirmed: true });
  await call('kt1', 'POST', `/workplace-reports/${r2.id}/acknowledge`, {});
  await call('kt1', 'POST', `/workplace-reports/${r2.id}/updates`, { status: 'resolved_pending', comment: 'Đã tăng timeout máy in và cập nhật driver.' });
  await call('e3', 'POST', `/workplace-reports/${r2.id}/confirm`, { decision: 'close', comment: 'Đã in thử 80 phiếu OK' });
  await call('e4', 'POST', '/workplace-reports', {
    category: 'facility', severity: 'low', description: 'Điều hòa phòng kinh doanh chảy nước, ảnh hưởng khu vực bàn làm việc.', detectedAt: new Date().toISOString(), groupId: g2.id,
  });

  // Tăng ca
  const ot = (who: string, daysAgo: number, hours: number, o: any) => call(who, 'POST', '/overtime-records', {
    startAt: new Date(now - daysAgo * day).toISOString(), endAt: new Date(now - daysAgo * day + hours * 3600000).toISOString(), ...o,
  });
  const o1 = await ot('e1', 3, 3, { otType: 'ad_hoc', cause: 'Xử lý đơn hàng gấp khách XYZ', taskId: t5.id, requestedByMemberId: m1, notifiedInAdvance: false });
  await call('m1', 'POST', `/overtime-records/${o1.id}/review`, { decision: 'confirm' });
  await ot('e2', 2, 2, { otType: 'incident', cause: 'Xe nâng hỏng, phải bốc xếp thủ công', reportId: r1.id, groupId: g1.id });
  await ot('e4', 5, 2.5, { otType: 'workload', cause: 'Hoàn thiện đề xuất ABC đúng hạn', taskId: t4.id });

  // Bản ghi công việc tự khai báo
  await call('e1', 'POST', '/work-records', {
    title: 'Hỗ trợ nhóm Kinh doanh đóng gói hàng mẫu', groupId: g1.id, requesterMemberId: m2,
    startAt: new Date(now - 2 * day).toISOString(), endAt: new Date(now - 2 * day + 2 * 3600000).toISOString(),
    recordType: 'support', result: 'Đóng gói 30 bộ hàng mẫu', reasonNotInSystem: 'Chị Dung nhờ trực tiếp, không tạo nhiệm vụ',
  });
  const wr2 = await call('e2', 'POST', '/work-records', {
    title: 'Trực kho ngoài giờ nhận hàng nhập khẩu', groupId: g1.id, requesterMemberId: m1,
    startAt: new Date(now - 4 * day + 10 * 3600000).toISOString(), endAt: new Date(now - 4 * day + 14 * 3600000).toISOString(),
    recordType: 'assigned_outside', result: 'Nhận đủ 2 container', reasonNotInSystem: 'Quản lý gọi điện giao việc buổi tối',
  });
  await call('m1', 'POST', `/work-records/${wr2.id}/reviews`, {
    decision: 'partial', reason: 'Thời gian khai báo trùng giờ nghỉ trưa vượt quy định 30 phút', basis: 'Nhật ký cổng kho 12:00-13:00',
    acceptedMinutes: 180, acceptedScope: 'Nhận hàng 13:00-16:00', rejectedScope: 'Khoảng 12:00-13:00 trùng giờ nghỉ',
  });
  await call('e2', 'POST', `/work-records/${wr2.id}/disputes`, { response: 'dispute', comment: 'Hôm đó container đến lúc 12h, tôi phải nhận hàng ngay, có ảnh chụp giờ.' });

  if (app) await app.close();
  return { companyId };
}

if (require.main === module) {
  (async () => {
    await resetDb();
    await seed();
    console.log('Seed OK. Tài khoản demo (mật khẩu Demo@123): owner@demo.vn, admin@demo.vn, quanly1@demo.vn, quanly2@demo.vn, truongkt@demo.vn, kythuat@demo.vn, nv1..nv4@demo.vn, reviewer@demo.vn');
    await closePool();
    process.exit(0);
  })().catch(async (e) => { console.error(e); await closePool(); process.exit(1); });
}
