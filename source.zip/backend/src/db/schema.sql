-- Schema MVP: Ứng dụng quản lý nhóm, giao việc và đánh giá hiệu suất
-- Quy tắc: UUID khóa chính, mọi dữ liệu nghiệp vụ có company_id, thời gian lưu UTC (timestamptz).
CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE IF NOT EXISTS companies (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  timezone text NOT NULL DEFAULT 'Asia/Ho_Chi_Minh',
  settings jsonb NOT NULL DEFAULT '{}'::jsonb,
  report_seq int NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  email text NOT NULL UNIQUE,
  phone text,
  password_hash text NOT NULL,
  auth_provider text NOT NULL DEFAULT 'password',
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active','locked')),
  failed_logins int NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS refresh_tokens (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id),
  token_hash text NOT NULL UNIQUE,
  expires_at timestamptz NOT NULL,
  revoked_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS departments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id uuid NOT NULL REFERENCES companies(id),
  name text NOT NULL,
  head_member_id uuid,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS company_members (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id uuid NOT NULL REFERENCES companies(id),
  user_id uuid NOT NULL REFERENCES users(id),
  role text NOT NULL CHECK (role IN ('owner','admin','manager','employee','handler','reviewer')),
  title text,
  department_id uuid REFERENCES departments(id),
  supervisor_member_id uuid REFERENCES company_members(id),
  can_cross_group_assign boolean NOT NULL DEFAULT false,
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active','inactive')),
  joined_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (company_id, user_id)
);
ALTER TABLE departments DROP CONSTRAINT IF EXISTS departments_head_fk;
ALTER TABLE departments ADD CONSTRAINT departments_head_fk FOREIGN KEY (head_member_id) REFERENCES company_members(id);

CREATE TABLE IF NOT EXISTS groups (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id uuid NOT NULL REFERENCES companies(id),
  name text NOT NULL,
  description text,
  manager_member_id uuid NOT NULL REFERENCES company_members(id),
  created_by uuid NOT NULL REFERENCES company_members(id),
  created_at timestamptz NOT NULL DEFAULT now(),
  deleted_at timestamptz
);

CREATE TABLE IF NOT EXISTS group_members (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  group_id uuid NOT NULL REFERENCES groups(id),
  company_member_id uuid NOT NULL REFERENCES company_members(id),
  joined_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (group_id, company_member_id)
);

CREATE TABLE IF NOT EXISTS task_types (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id uuid NOT NULL REFERENCES companies(id),
  name text NOT NULL,
  category text,
  active boolean NOT NULL DEFAULT true
);

CREATE TABLE IF NOT EXISTS task_templates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id uuid NOT NULL REFERENCES companies(id),
  name text NOT NULL,
  task_type_id uuid REFERENCES task_types(id),
  description text,
  complexity text NOT NULL DEFAULT 'simple',
  requirement_level text NOT NULL DEFAULT 'normal',
  estimated_hours numeric NOT NULL DEFAULT 4,
  criteria jsonb NOT NULL DEFAULT '[]'::jsonb,
  active boolean NOT NULL DEFAULT true
);

CREATE TABLE IF NOT EXISTS tasks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id uuid NOT NULL REFERENCES companies(id),
  group_id uuid NOT NULL REFERENCES groups(id),
  code text,
  title text NOT NULL,
  description text NOT NULL,
  status text NOT NULL DEFAULT 'not_started'
    CHECK (status IN ('not_started','in_progress','pending_review','completed','revision_requested','cancelled')),
  priority text NOT NULL DEFAULT 'normal',
  task_type_id uuid NOT NULL REFERENCES task_types(id),
  complexity text NOT NULL CHECK (complexity IN ('simple','medium','complex','very_complex')),
  requirement_level text NOT NULL CHECK (requirement_level IN ('normal','high','very_high')),
  estimated_hours numeric NOT NULL CHECK (estimated_hours > 0),
  due_at timestamptz NOT NULL,
  resources text,
  is_unexpected boolean NOT NULL DEFAULT false,
  scope_version int NOT NULL DEFAULT 1,
  revision_count int NOT NULL DEFAULT 0,
  cancel_reason text,
  cancelled_by uuid REFERENCES company_members(id),
  cancel_is_business_decision boolean,
  started_at timestamptz,
  first_submitted_at timestamptz,
  submitted_at timestamptz,
  completed_at timestamptz,
  created_by uuid NOT NULL REFERENCES company_members(id),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS tasks_company_status ON tasks(company_id, status);
CREATE INDEX IF NOT EXISTS tasks_group ON tasks(group_id);

CREATE TABLE IF NOT EXISTS task_assignees (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  task_id uuid NOT NULL REFERENCES tasks(id),
  company_member_id uuid NOT NULL REFERENCES company_members(id),
  assignment_type text NOT NULL CHECK (assignment_type IN ('owner','collaborator')),
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS task_one_owner ON task_assignees(task_id) WHERE assignment_type = 'owner' AND active;

CREATE TABLE IF NOT EXISTS task_criteria (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  task_id uuid NOT NULL REFERENCES tasks(id),
  version int NOT NULL,
  direction text NOT NULL CHECK (direction IN ('input','output')),
  criterion text NOT NULL,
  weight numeric,
  created_by uuid NOT NULL REFERENCES company_members(id),
  created_at timestamptz NOT NULL DEFAULT now()
);

-- Đầu việc con / yêu cầu thành phần (yêu cầu đa dạng)
CREATE TABLE IF NOT EXISTS task_subitems (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  task_id uuid NOT NULL REFERENCES tasks(id),
  title text NOT NULL,
  requested_by uuid REFERENCES company_members(id),
  extra_hours numeric NOT NULL DEFAULT 0,
  scope_version int NOT NULL,
  done boolean NOT NULL DEFAULT false,
  created_by uuid NOT NULL REFERENCES company_members(id),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS task_comments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  task_id uuid NOT NULL REFERENCES tasks(id),
  member_id uuid NOT NULL REFERENCES company_members(id),
  content text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS task_submissions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  task_id uuid NOT NULL REFERENCES tasks(id),
  submitted_by uuid NOT NULL REFERENCES company_members(id),
  output_description text NOT NULL,
  completion_percent int NOT NULL DEFAULT 100,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS task_evaluations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  task_id uuid NOT NULL REFERENCES tasks(id),
  evaluator_id uuid NOT NULL REFERENCES company_members(id),
  decision text NOT NULL CHECK (decision IN ('approved','revision_requested')),
  kind text NOT NULL DEFAULT 'regular' CHECK (kind IN ('regular','unexpected')),
  scores jsonb,
  total_score numeric,
  config_version int,
  comment text,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS unexpected_tasks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  task_id uuid NOT NULL UNIQUE REFERENCES tasks(id),
  category text NOT NULL CHECK (category IN ('ad_hoc','urgent','scope_addition','external_support')),
  requirement_structure text NOT NULL CHECK (requirement_structure IN ('common','diverse')),
  cause text NOT NULL CHECK (cause IN ('incident','superior_request','customer','resource_shortage','support_other_dept','other')),
  cause_detail text,
  requester_member_id uuid REFERENCES company_members(id),
  requested_at timestamptz NOT NULL DEFAULT now(),
  actual_hours numeric,
  impact text
);

CREATE TABLE IF NOT EXISTS overtime_records (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id uuid NOT NULL REFERENCES companies(id),
  member_id uuid NOT NULL REFERENCES company_members(id),
  group_id uuid REFERENCES groups(id),
  task_id uuid REFERENCES tasks(id),
  report_id uuid,
  start_at timestamptz NOT NULL,
  end_at timestamptz NOT NULL,
  minutes int NOT NULL,
  ot_type text NOT NULL CHECK (ot_type IN ('planned','ad_hoc','incident','workload','support')),
  cause text NOT NULL,
  requested_by_member_id uuid REFERENCES company_members(id),
  notified_in_advance boolean NOT NULL DEFAULT false,
  impact text,
  approval_status text NOT NULL DEFAULT 'pending' CHECK (approval_status IN ('pending','confirmed','rejected')),
  reviewer_id uuid REFERENCES company_members(id),
  review_reason text,
  reviewed_at timestamptz,
  created_by uuid NOT NULL REFERENCES company_members(id),
  created_at timestamptz NOT NULL DEFAULT now(),
  CHECK (end_at > start_at)
);

CREATE TABLE IF NOT EXISTS employee_work_records (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id uuid NOT NULL REFERENCES companies(id),
  employee_id uuid NOT NULL REFERENCES company_members(id),
  group_id uuid REFERENCES groups(id),
  title text NOT NULL,
  description text,
  requester_member_id uuid REFERENCES company_members(id),
  requester_unknown_note text,
  work_date date NOT NULL,
  start_at timestamptz NOT NULL,
  end_at timestamptz NOT NULL,
  is_estimated boolean NOT NULL DEFAULT false,
  claimed_minutes int NOT NULL,
  record_type text NOT NULL CHECK (record_type IN ('assigned_outside','missing','after_hours','support','other')),
  result text NOT NULL,
  completion_status text NOT NULL DEFAULT 'done' CHECK (completion_status IN ('done','partial','in_progress')),
  reason_not_in_system text NOT NULL,
  related_task_id uuid REFERENCES tasks(id),
  reviewer_member_id uuid REFERENCES company_members(id),
  status text NOT NULL DEFAULT 'submitted' CHECK (status IN ('submitted','needs_information','accepted','partially_accepted','rejected','disputed','appealed','resolved')),
  review_due_at timestamptz,
  overdue boolean NOT NULL DEFAULT false,
  sla_cycle int NOT NULL DEFAULT 0,
  escalation_level int NOT NULL DEFAULT 0,
  chain_no int NOT NULL DEFAULT 1,
  consecutive_rejections int NOT NULL DEFAULT 0,
  accepted_minutes int,
  overlap_warning boolean NOT NULL DEFAULT false,
  final_decision text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CHECK (end_at > start_at)
);
CREATE INDEX IF NOT EXISTS ewr_company_status ON employee_work_records(company_id, status);

-- Bản ghi bất biến: không update/delete
CREATE TABLE IF NOT EXISTS work_record_reviews (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  work_record_id uuid NOT NULL REFERENCES employee_work_records(id),
  reviewer_id uuid NOT NULL REFERENCES company_members(id),
  decision text NOT NULL CHECK (decision IN ('accept','partial','reject','needs_info')),
  reason text,
  basis text,
  related_period text,
  accepted_minutes int,
  accepted_scope text,
  rejected_scope text,
  chain_no int NOT NULL,
  rejection_no int,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS work_record_disputes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  work_record_id uuid NOT NULL REFERENCES employee_work_records(id),
  employee_id uuid NOT NULL REFERENCES company_members(id),
  review_id uuid REFERENCES work_record_reviews(id),
  response text NOT NULL CHECK (response IN ('accept','dispute','supplement')),
  comment text,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS work_record_appeals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  work_record_id uuid NOT NULL REFERENCES employee_work_records(id),
  appellant_id uuid NOT NULL REFERENCES company_members(id),
  respondent_id uuid REFERENCES company_members(id),
  reviewer_id uuid NOT NULL REFERENCES company_members(id),
  reason text NOT NULL,
  early boolean NOT NULL DEFAULT false,
  early_reason text,
  decision text CHECK (decision IN ('accept','partial','reject')),
  decision_reason text,
  accepted_minutes int,
  status text NOT NULL DEFAULT 'open' CHECK (status IN ('open','resolved')),
  created_at timestamptz NOT NULL DEFAULT now(),
  resolved_at timestamptz
);

CREATE TABLE IF NOT EXISTS files (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id uuid NOT NULL REFERENCES companies(id),
  parent_type text NOT NULL,
  parent_id uuid NOT NULL,
  filename text NOT NULL,
  mime text NOT NULL,
  size int NOT NULL,
  storage_key text NOT NULL,
  uploaded_by uuid NOT NULL REFERENCES company_members(id),
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS files_parent ON files(parent_type, parent_id);

CREATE TABLE IF NOT EXISTS sla_configs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id uuid NOT NULL REFERENCES companies(id),
  severity text NOT NULL CHECK (severity IN ('low','medium','high','critical')),
  manager_review_minutes int NOT NULL,
  acknowledge_minutes int NOT NULL,
  resolve_minutes int NOT NULL,
  UNIQUE (company_id, severity)
);

CREATE TABLE IF NOT EXISTS workplace_reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id uuid NOT NULL REFERENCES companies(id),
  code text NOT NULL,
  reporter_id uuid NOT NULL REFERENCES company_members(id),
  group_id uuid REFERENCES groups(id),
  category text NOT NULL CHECK (category IN ('equipment','software','facility','supplies','process','other')),
  subcategory text,
  severity text NOT NULL CHECK (severity IN ('low','medium','high','critical')),
  description text NOT NULL,
  detected_at timestamptz NOT NULL,
  affected_task_id uuid REFERENCES tasks(id),
  asset text,
  location text,
  temp_measure text,
  safety_risk boolean NOT NULL DEFAULT false,
  independent_channel boolean NOT NULL DEFAULT false,
  status text NOT NULL DEFAULT 'submitted' CHECK (status IN ('submitted','manager_review','assigned','acknowledged','in_progress','waiting','resolved_pending','closed','reopened','escalated')),
  stage text NOT NULL DEFAULT 'manager_review' CHECK (stage IN ('manager_review','department_ack','resolution','reporter_confirm','closed')),
  impact_confirmed boolean NOT NULL DEFAULT false,
  manager_member_id uuid REFERENCES company_members(id),
  department_id uuid REFERENCES departments(id),
  assignee_id uuid REFERENCES company_members(id),
  current_holder_id uuid REFERENCES company_members(id),
  stage_due_at timestamptz,
  stage_window_minutes int,
  sla_cycle int NOT NULL DEFAULT 0,
  escalation_level int NOT NULL DEFAULT 0,
  reopen_count int NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  closed_at timestamptz,
  UNIQUE (company_id, code)
);

CREATE TABLE IF NOT EXISTS report_assignments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  report_id uuid NOT NULL REFERENCES workplace_reports(id),
  department_id uuid REFERENCES departments(id),
  assignee_id uuid REFERENCES company_members(id),
  assigned_by uuid NOT NULL REFERENCES company_members(id),
  assigned_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS report_updates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  report_id uuid NOT NULL REFERENCES workplace_reports(id),
  actor_id uuid REFERENCES company_members(id),
  status text NOT NULL,
  comment text,
  new_due_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- Chuyển cấp chung cho báo cáo trở ngại / bản ghi công việc
CREATE TABLE IF NOT EXISTS escalations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id uuid NOT NULL REFERENCES companies(id),
  parent_type text NOT NULL CHECK (parent_type IN ('workplace_report','work_record')),
  parent_id uuid NOT NULL,
  stage text NOT NULL,
  cycle int NOT NULL DEFAULT 0,
  level int NOT NULL,
  from_member_id uuid REFERENCES company_members(id),
  to_member_id uuid NOT NULL REFERENCES company_members(id),
  reason text NOT NULL,
  auto boolean NOT NULL DEFAULT true,
  new_due_at timestamptz,
  status text NOT NULL DEFAULT 'open' CHECK (status IN ('open','resolved')),
  resolution text,
  resolved_by uuid REFERENCES company_members(id),
  resolved_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (parent_type, parent_id, stage, cycle, level)
);

CREATE TABLE IF NOT EXISTS performance_configs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id uuid NOT NULL REFERENCES companies(id),
  version int NOT NULL,
  config jsonb NOT NULL,
  effective_from timestamptz NOT NULL DEFAULT now(),
  created_by uuid REFERENCES company_members(id),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (company_id, version)
);

CREATE TABLE IF NOT EXISTS performance_reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id uuid NOT NULL REFERENCES companies(id),
  period_type text NOT NULL CHECK (period_type IN ('month','quarter','year')),
  period_start date NOT NULL,
  period_end date NOT NULL,
  scope_type text NOT NULL CHECK (scope_type IN ('company','group','member')),
  scope_id uuid,
  formula_version int NOT NULL,
  snapshot jsonb NOT NULL,
  created_by uuid NOT NULL REFERENCES company_members(id),
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id uuid NOT NULL REFERENCES companies(id),
  member_id uuid NOT NULL REFERENCES company_members(id),
  type text NOT NULL,
  title text NOT NULL,
  body text,
  reference_type text,
  reference_id uuid,
  dedupe_key text,
  push_status text NOT NULL DEFAULT 'skipped',
  read_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS notifications_dedupe ON notifications(member_id, dedupe_key) WHERE dedupe_key IS NOT NULL;
CREATE INDEX IF NOT EXISTS notifications_member ON notifications(member_id, created_at DESC);

CREATE TABLE IF NOT EXISTS audit_logs (
  id bigserial PRIMARY KEY,
  company_id uuid NOT NULL REFERENCES companies(id),
  entity_type text NOT NULL,
  entity_id uuid NOT NULL,
  actor_id uuid REFERENCES company_members(id),
  action text NOT NULL,
  old_value jsonb,
  new_value jsonb,
  reason text,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS audit_entity ON audit_logs(entity_type, entity_id);

CREATE TABLE IF NOT EXISTS idempotency_keys (
  member_id uuid NOT NULL,
  key text NOT NULL,
  route text NOT NULL,
  status_code int,
  response jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (member_id, key, route)
);

-- Bảo vệ bất biến cho lịch sử quyết định / audit
CREATE OR REPLACE FUNCTION forbid_mutation() RETURNS trigger AS $$
BEGIN
  RAISE EXCEPTION 'IMMUTABLE_RECORD: % không được sửa/xóa', TG_TABLE_NAME;
END; $$ LANGUAGE plpgsql;

DO $$
DECLARE t text;
BEGIN
  FOREACH t IN ARRAY ARRAY['work_record_reviews','work_record_disputes','audit_logs','performance_reports','report_updates'] LOOP
    EXECUTE format('DROP TRIGGER IF EXISTS %I_immutable ON %I', t, t);
    EXECUTE format('CREATE TRIGGER %I_immutable BEFORE UPDATE OR DELETE ON %I FOR EACH ROW EXECUTE FUNCTION forbid_mutation()', t, t);
  END LOOP;
END $$;

-- =====================================================================
-- v2: Việc Đến — đăng nhập SĐT, hồ sơ, gói doanh nghiệp, lịch, ghim việc,
--     khai việc nhanh, nghỉ phép. Các lệnh idempotent để nâng cấp DB cũ.
-- =====================================================================
ALTER TABLE users ALTER COLUMN email DROP NOT NULL;
ALTER TABLE users ALTER COLUMN password_hash DROP NOT NULL;
ALTER TABLE users ADD COLUMN IF NOT EXISTS is_platform_admin boolean NOT NULL DEFAULT false;
ALTER TABLE users DROP CONSTRAINT IF EXISTS users_status_check;
ALTER TABLE users ADD CONSTRAINT users_status_check CHECK (status IN ('active','locked','invited'));
CREATE UNIQUE INDEX IF NOT EXISTS users_phone_unique ON users(phone) WHERE phone IS NOT NULL;

ALTER TABLE company_members DROP CONSTRAINT IF EXISTS company_members_role_check;
ALTER TABLE company_members ADD CONSTRAINT company_members_role_check CHECK (role IN ('owner','admin','manager','employee','handler','reviewer','hr'));
ALTER TABLE company_members DROP CONSTRAINT IF EXISTS company_members_status_check;
ALTER TABLE company_members ADD CONSTRAINT company_members_status_check CHECK (status IN ('active','inactive','pending_hr','rejected'));
ALTER TABLE company_members ADD COLUMN IF NOT EXISTS added_by uuid REFERENCES company_members(id);
ALTER TABLE company_members ADD COLUMN IF NOT EXISTS hr_reviewed_by uuid REFERENCES company_members(id);
ALTER TABLE company_members ADD COLUMN IF NOT EXISTS hr_reviewed_at timestamptz;
ALTER TABLE company_members ADD COLUMN IF NOT EXISTS hr_note text;
ALTER TABLE company_members ADD COLUMN IF NOT EXISTS left_at timestamptz;

ALTER TABLE companies ADD COLUMN IF NOT EXISTS plan text;
ALTER TABLE companies ADD COLUMN IF NOT EXISTS member_limit int;
ALTER TABLE companies ADD COLUMN IF NOT EXISTS contact_email text;
ALTER TABLE companies ADD COLUMN IF NOT EXISTS plan_expires_at timestamptz;

-- Ảnh đại diện (ảnh quét gương mặt), lưu nhỏ gọn trong DB
CREATE TABLE IF NOT EXISTS user_avatars (
  user_id uuid PRIMARY KEY REFERENCES users(id),
  mime text NOT NULL,
  data bytea NOT NULL,
  captured_live boolean NOT NULL DEFAULT false,
  face_detected boolean,
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- Hồ sơ xin việc
CREATE TABLE IF NOT EXISTS user_profiles (
  user_id uuid PRIMARY KEY REFERENCES users(id),
  dob date,
  gender text,
  address text,
  contact_email text,
  id_number text,
  education text,
  desired_position text,
  summary text,
  years_experience numeric,
  field text,
  skills text,
  certificates text,
  share_auto_history boolean NOT NULL DEFAULT false,
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS user_work_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id),
  company_name text NOT NULL,
  position text,
  start_date date,
  end_date date,
  description text,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- Gói doanh nghiệp
CREATE TABLE IF NOT EXISTS subscriptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id),
  company_id uuid REFERENCES companies(id),
  plan text NOT NULL CHECK (plan IN ('small','medium','large')),
  company_name text NOT NULL,
  contact_email text NOT NULL,
  member_limit int NOT NULL,
  price_vnd bigint NOT NULL,
  months int NOT NULL DEFAULT 12,
  status text NOT NULL DEFAULT 'pending_payment' CHECK (status IN ('pending_payment','active','rejected','cancelled')),
  payment_ref text,
  activated_by uuid REFERENCES users(id),
  activated_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- Lịch & ghim việc gấp
ALTER TABLE tasks ADD COLUMN IF NOT EXISTS plan_date date;
ALTER TABLE tasks ADD COLUMN IF NOT EXISTS original_plan_date date;
ALTER TABLE tasks ADD COLUMN IF NOT EXISTS carry_count int NOT NULL DEFAULT 0;
ALTER TABLE tasks ADD COLUMN IF NOT EXISTS pinned boolean NOT NULL DEFAULT false;
ALTER TABLE tasks ADD COLUMN IF NOT EXISTS pinned_at timestamptz;
ALTER TABLE tasks ADD COLUMN IF NOT EXISTS pinned_by uuid REFERENCES company_members(id);
ALTER TABLE tasks ADD COLUMN IF NOT EXISTS urgent boolean NOT NULL DEFAULT false;
ALTER TABLE tasks ADD COLUMN IF NOT EXISTS source_claim_id uuid;
UPDATE tasks SET plan_date = (created_at AT TIME ZONE 'Asia/Ho_Chi_Minh')::date WHERE plan_date IS NULL;
CREATE INDEX IF NOT EXISTS tasks_plan_date ON tasks(company_id, plan_date);

-- Khai việc nhanh qua gọi điện / tin nhắn
CREATE TABLE IF NOT EXISTS quick_claims (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id uuid NOT NULL REFERENCES companies(id),
  group_id uuid REFERENCES groups(id),
  creator_id uuid NOT NULL REFERENCES company_members(id),
  counterpart_id uuid NOT NULL REFERENCES company_members(id),
  manager_id uuid NOT NULL REFERENCES company_members(id),
  assignee_id uuid NOT NULL REFERENCES company_members(id),
  channel text NOT NULL CHECK (channel IN ('call','sms','chat','zalo','direct')),
  occurred_at timestamptz NOT NULL,
  title text NOT NULL,
  description text,
  due_at timestamptz,
  estimated_hours numeric,
  already_done boolean NOT NULL DEFAULT false,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','confirmed','rejected','cancelled')),
  response_reason text,
  responded_at timestamptz,
  task_id uuid REFERENCES tasks(id),
  work_record_id uuid REFERENCES employee_work_records(id),
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS quick_claims_pair ON quick_claims(company_id, manager_id, assignee_id, status);

-- Nghỉ phép
CREATE TABLE IF NOT EXISTS leave_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id uuid NOT NULL REFERENCES companies(id),
  code text NOT NULL,
  member_id uuid NOT NULL REFERENCES company_members(id),
  leave_type text NOT NULL CHECK (leave_type IN ('sudden','hourly','shift','day')),
  start_at timestamptz NOT NULL,
  end_at timestamptz NOT NULL,
  shift text,
  minutes int NOT NULL,
  reason text NOT NULL,
  handover text,
  notice_minutes int NOT NULL,
  late_notice boolean NOT NULL DEFAULT false,
  approver_id uuid REFERENCES company_members(id),
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','approved','rejected','cancelled')),
  decision_reason text,
  decided_by uuid REFERENCES company_members(id),
  decided_at timestamptz,
  pdf_file_id uuid REFERENCES files(id),
  hr_notified_at timestamptz,
  hr_email_status text,
  created_at timestamptz NOT NULL DEFAULT now(),
  CHECK (end_at > start_at)
);
CREATE INDEX IF NOT EXISTS leave_member_time ON leave_requests(member_id, start_at);
ALTER TABLE companies ADD COLUMN IF NOT EXISTS leave_seq int NOT NULL DEFAULT 0;

-- =====================================================================
-- v3: Quyết định nhân sự & bàn giao, mẫu việc mở rộng, giấy phép, quy trình
-- =====================================================================
CREATE TABLE IF NOT EXISTS personnel_decisions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id uuid NOT NULL REFERENCES companies(id),
  code text NOT NULL,
  member_id uuid NOT NULL REFERENCES company_members(id),
  decision_type text NOT NULL CHECK (decision_type IN ('transfer','promotion','termination')),
  effective_date date NOT NULL,
  handover_deadline timestamptz NOT NULL,
  new_role text,
  new_title text,
  new_group_id uuid REFERENCES groups(id),
  remove_from_groups boolean NOT NULL DEFAULT false,
  new_department_id uuid REFERENCES departments(id),
  new_supervisor_id uuid REFERENCES company_members(id),
  handover_receiver_id uuid REFERENCES company_members(id),
  confirmer_id uuid NOT NULL REFERENCES company_members(id),
  reason text NOT NULL,
  status text NOT NULL DEFAULT 'handover' CHECK (status IN ('handover','pending_confirm','completed','cancelled')),
  handover_note text,
  handover_plan jsonb,
  handover_submitted_at timestamptz,
  confirm_note text,
  confirmed_by uuid REFERENCES company_members(id),
  confirmed_at timestamptz,
  pdf_file_id uuid REFERENCES files(id),
  created_by uuid NOT NULL REFERENCES company_members(id),
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS decisions_member ON personnel_decisions(member_id, status);
ALTER TABLE companies ADD COLUMN IF NOT EXISTS decision_seq int NOT NULL DEFAULT 0;
ALTER TABLE companies ADD COLUMN IF NOT EXISTS permit_seq int NOT NULL DEFAULT 0;

-- Mẫu việc: biểu tượng, nhóm mẫu, trường khai báo nhanh, giấy phép gợi ý
ALTER TABLE task_templates ADD COLUMN IF NOT EXISTS icon text;
ALTER TABLE task_templates ADD COLUMN IF NOT EXISTS category text;
ALTER TABLE task_templates ADD COLUMN IF NOT EXISTS fields jsonb NOT NULL DEFAULT '[]'::jsonb;
ALTER TABLE task_templates ADD COLUMN IF NOT EXISTS permit_keys jsonb NOT NULL DEFAULT '[]'::jsonb;
ALTER TABLE task_templates ADD COLUMN IF NOT EXISTS system_key text;
ALTER TABLE task_templates ADD COLUMN IF NOT EXISTS sort int NOT NULL DEFAULT 100;
CREATE UNIQUE INDEX IF NOT EXISTS task_templates_system ON task_templates(company_id, system_key) WHERE system_key IS NOT NULL;

-- Giấy phép / thủ tục đơn giản
CREATE TABLE IF NOT EXISTS permit_types (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id uuid NOT NULL REFERENCES companies(id),
  key text NOT NULL,
  name text NOT NULL,
  icon text,
  description text,
  department_id uuid REFERENCES departments(id),
  fields jsonb NOT NULL DEFAULT '[]'::jsonb,
  allow_declaration boolean NOT NULL DEFAULT true,
  tracks text NOT NULL DEFAULT 'none' CHECK (tracks IN ('none','gate','equipment')),
  active boolean NOT NULL DEFAULT true,
  UNIQUE (company_id, key)
);
CREATE TABLE IF NOT EXISTS permits (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id uuid NOT NULL REFERENCES companies(id),
  code text NOT NULL,
  type_id uuid NOT NULL REFERENCES permit_types(id),
  task_id uuid REFERENCES tasks(id),
  requested_by uuid NOT NULL REFERENCES company_members(id),
  holder_id uuid NOT NULL REFERENCES company_members(id),
  data jsonb NOT NULL DEFAULT '{}'::jsonb,
  valid_from timestamptz NOT NULL,
  valid_to timestamptz NOT NULL,
  mode text NOT NULL CHECK (mode IN ('approval','declaration')),
  status text NOT NULL CHECK (status IN ('pending','approved','rejected','auto_issued','cancelled','closed')),
  decision_by uuid REFERENCES company_members(id),
  decision_at timestamptz,
  decision_note text,
  review_status text CHECK (review_status IN ('ok','violation')),
  reviewed_by uuid REFERENCES company_members(id),
  reviewed_at timestamptz,
  review_note text,
  out_at timestamptz, out_by uuid REFERENCES company_members(id),
  in_at timestamptz, in_by uuid REFERENCES company_members(id),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (company_id, code),
  CHECK (valid_to > valid_from)
);
CREATE INDEX IF NOT EXISTS permits_task ON permits(task_id);
CREATE INDEX IF NOT EXISTS permits_company_status ON permits(company_id, status);

-- Quy trình & thủ tục công ty
CREATE TABLE IF NOT EXISTS procedures (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id uuid NOT NULL REFERENCES companies(id),
  department_id uuid REFERENCES departments(id),
  audience text NOT NULL DEFAULT 'all' CHECK (audience IN ('all','managers','department')),
  system_key text,
  title text NOT NULL,
  category text,
  summary text,
  steps jsonb NOT NULL DEFAULT '[]'::jsonb,
  reference text,
  reminder text NOT NULL DEFAULT 'weekly' CHECK (reminder IN ('none','daily','weekly','monthly')),
  active boolean NOT NULL DEFAULT true,
  version int NOT NULL DEFAULT 1,
  updated_by uuid REFERENCES company_members(id),
  updated_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS procedures_system ON procedures(company_id, system_key) WHERE system_key IS NOT NULL;

-- =====================================================================
-- v4: công việc nhiều giai đoạn/phân lớp, trở ngại giao việc xử lý, mô tả vai trò, khai báo nhanh
-- =====================================================================
ALTER TABLE tasks DROP CONSTRAINT IF EXISTS tasks_status_check;
ALTER TABLE tasks ADD CONSTRAINT tasks_status_check CHECK (status IN ('not_started','in_progress','pending_review','completed','revision_requested','cancelled','waiting','pending_approval'));
ALTER TABLE tasks ADD COLUMN IF NOT EXISTS parent_id uuid REFERENCES tasks(id);
ALTER TABLE tasks ADD COLUMN IF NOT EXISTS root_id uuid REFERENCES tasks(id);
ALTER TABLE tasks ADD COLUMN IF NOT EXISTS stage_no int NOT NULL DEFAULT 1;
ALTER TABLE tasks ADD COLUMN IF NOT EXISTS depth int NOT NULL DEFAULT 0;
ALTER TABLE tasks ADD COLUMN IF NOT EXISTS approver_id uuid REFERENCES company_members(id);
ALTER TABLE tasks ADD COLUMN IF NOT EXISTS approval_note text;
ALTER TABLE tasks ADD COLUMN IF NOT EXISTS source_report_id uuid REFERENCES workplace_reports(id);
ALTER TABLE tasks ADD COLUMN IF NOT EXISTS auto_container boolean NOT NULL DEFAULT false;
CREATE INDEX IF NOT EXISTS tasks_parent ON tasks(parent_id, stage_no);

ALTER TABLE workplace_reports ADD COLUMN IF NOT EXISTS resolution_task_id uuid REFERENCES tasks(id);
ALTER TABLE workplace_reports ADD COLUMN IF NOT EXISTS decided_by uuid REFERENCES company_members(id);
ALTER TABLE workplace_reports ADD COLUMN IF NOT EXISTS overridden_by uuid REFERENCES company_members(id);
ALTER TABLE workplace_reports DROP CONSTRAINT IF EXISTS workplace_reports_status_check;
ALTER TABLE workplace_reports ADD CONSTRAINT workplace_reports_status_check CHECK (status IN ('submitted','manager_review','assigned','acknowledged','in_progress','waiting','resolved_pending','closed','reopened','escalated','task_assigned'));

-- Mô tả công việc/nhiệm vụ theo vai trò (chức danh)
CREATE TABLE IF NOT EXISTS job_roles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id uuid NOT NULL REFERENCES companies(id),
  system_key text,
  name text NOT NULL,
  description text,
  duties jsonb NOT NULL DEFAULT '[]'::jsonb,
  keywords jsonb NOT NULL DEFAULT '[]'::jsonb,
  active boolean NOT NULL DEFAULT true,
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS job_roles_system ON job_roles(company_id, system_key) WHERE system_key IS NOT NULL;
ALTER TABLE company_members ADD COLUMN IF NOT EXISTS job_role_id uuid REFERENCES job_roles(id);

-- Khai báo nhanh: việc thường ngày, việc ngoài vai trò, thêm vào nhánh việc hiện có
ALTER TABLE employee_work_records DROP CONSTRAINT IF EXISTS employee_work_records_record_type_check;
ALTER TABLE employee_work_records ADD CONSTRAINT employee_work_records_record_type_check CHECK (record_type IN ('assigned_outside','missing','after_hours','support','other','routine','outside_role','branch'));
ALTER TABLE employee_work_records ALTER COLUMN reason_not_in_system DROP NOT NULL;
ALTER TABLE employee_work_records ADD COLUMN IF NOT EXISTS initiative boolean NOT NULL DEFAULT false;
ALTER TABLE employee_work_records ADD COLUMN IF NOT EXISTS in_role boolean;
ALTER TABLE employee_work_records ADD COLUMN IF NOT EXISTS in_role_suggested boolean;

ALTER TABLE task_templates ADD COLUMN IF NOT EXISTS stages jsonb NOT NULL DEFAULT '[]'::jsonb;

-- =====================================================================
-- v5: Bảo mật & quyền riêng tư (SEC-01), hành vi an toàn & chống lạm dụng (UX-ABUSE-01)
-- =====================================================================
-- Tối thiểu hóa dữ liệu: bỏ số giấy tờ định danh và giới tính khỏi hồ sơ (không cần cho chức năng cốt lõi)
ALTER TABLE user_profiles DROP COLUMN IF EXISTS id_number;
ALTER TABLE user_profiles DROP COLUMN IF EXISTS gender;
ALTER TABLE user_profiles ADD COLUMN IF NOT EXISTS restricted boolean NOT NULL DEFAULT false;
-- Khóa tạm thời khi đăng nhập sai nhiều lần (giãn nhịp), thay cho khóa vĩnh viễn dễ bị lợi dụng
ALTER TABLE users ADD COLUMN IF NOT EXISTS locked_until timestamptz;

-- Mức hiển thị theo trường do người dùng chọn: only_me | related | company
CREATE TABLE IF NOT EXISTS field_visibility_settings (
  user_id uuid NOT NULL REFERENCES users(id),
  field_key text NOT NULL CHECK (field_key IN ('phone','email','dob','address','contact_email','work_history')),
  visibility text NOT NULL CHECK (visibility IN ('only_me','related','company')),
  updated_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (user_id, field_key)
);

-- Đồng ý theo từng mục đích (không dùng một checkbox chung)
CREATE TABLE IF NOT EXISTS consent_records (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id),
  purpose text NOT NULL CHECK (purpose IN ('face_capture','call_recording','share_cv_other_companies')),
  status text NOT NULL CHECK (status IN ('granted','withdrawn')),
  policy_version text NOT NULL DEFAULT '1.0',
  captured_at timestamptz NOT NULL DEFAULT now(),
  withdrawn_at timestamptz
);
CREATE INDEX IF NOT EXISTS consent_user ON consent_records(user_id, purpose, captured_at DESC);

-- Nhật ký truy cập dữ liệu (ai xem/tải/xuất gì, của ai, lý do, kết quả) — chỉ ghi thêm
CREATE TABLE IF NOT EXISTS data_access_logs (
  id bigserial PRIMARY KEY,
  company_id uuid REFERENCES companies(id),
  actor_user_id uuid REFERENCES users(id),
  actor_member_id uuid REFERENCES company_members(id),
  action text NOT NULL,
  object_type text NOT NULL,
  object_id text,
  subject_user_id uuid REFERENCES users(id),
  reason text,
  result text NOT NULL DEFAULT 'allowed' CHECK (result IN ('allowed','denied')),
  meta jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS dal_subject ON data_access_logs(subject_user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS dal_actor ON data_access_logs(actor_user_id, created_at DESC);
CREATE OR REPLACE FUNCTION dal_immutable() RETURNS trigger AS $$
BEGIN
  IF current_setting('app.retention_purge', true) = 'on' AND TG_OP = 'DELETE' THEN RETURN OLD; END IF;
  RAISE EXCEPTION 'data_access_logs is append-only';
END $$ LANGUAGE plpgsql;
DROP TRIGGER IF EXISTS dal_no_update ON data_access_logs;
CREATE TRIGGER dal_no_update BEFORE UPDATE OR DELETE ON data_access_logs FOR EACH ROW EXECUTE FUNCTION dal_immutable();

-- Yêu cầu của chủ thể dữ liệu
CREATE TABLE IF NOT EXISTS data_subject_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code text NOT NULL,
  user_id uuid NOT NULL REFERENCES users(id),
  company_id uuid REFERENCES companies(id),
  request_type text NOT NULL CHECK (request_type IN ('access','export','correction','deletion','restriction','consent_withdrawal')),
  field_key text, proposed_value text, details text,
  scope jsonb,
  status text NOT NULL DEFAULT 'submitted' CHECK (status IN ('submitted','in_review','completed','partially_completed','rejected','cancelled')),
  assigned_to uuid REFERENCES company_members(id),
  due_at timestamptz,
  resolution text, retained_note text,
  resolved_by uuid REFERENCES company_members(id), resolved_at timestamptz,
  file_key text, file_expires_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS dsr_user ON data_subject_requests(user_id, created_at DESC);

-- Giới hạn liên hệ phi công việc (không chặn thông báo nghiệp vụ)
CREATE TABLE IF NOT EXISTS contact_blocks (
  company_id uuid NOT NULL REFERENCES companies(id),
  blocker_member_id uuid NOT NULL REFERENCES company_members(id),
  blocked_member_id uuid NOT NULL REFERENCES company_members(id),
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (blocker_member_id, blocked_member_id)
);

-- Cảnh báo hành vi bất thường (tín hiệu, không phải kết luận)
CREATE TABLE IF NOT EXISTS security_alerts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id uuid REFERENCES companies(id),
  user_id uuid REFERENCES users(id),
  member_id uuid REFERENCES company_members(id),
  kind text NOT NULL,
  detail text,
  count int NOT NULL DEFAULT 1,
  status text NOT NULL DEFAULT 'open' CHECK (status IN ('open','reviewed','dismissed')),
  reviewed_by uuid REFERENCES company_members(id), review_note text, reviewed_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS sa_company ON security_alerts(company_id, status, created_at DESC);

-- Truy cập đặc quyền của bộ phận hỗ trợ nền tảng: tạm thời, có lý do, người duyệt độc lập
CREATE TABLE IF NOT EXISTS privileged_access_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id uuid NOT NULL REFERENCES companies(id),
  requester_user_id uuid NOT NULL REFERENCES users(id),
  approver_member_id uuid REFERENCES company_members(id),
  scope text NOT NULL CHECK (scope IN ('company_settings','members_basic','audit_logs')),
  reason text NOT NULL, ticket text, hours int NOT NULL DEFAULT 4,
  emergency boolean NOT NULL DEFAULT false,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','approved','rejected','expired','revoked')),
  decided_at timestamptz, expires_at timestamptz, decision_note text,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- Nhật ký các lần xóa/khử nhận dạng theo chính sách lưu trữ
CREATE TABLE IF NOT EXISTS data_deletion_jobs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id uuid REFERENCES companies(id),
  scope text NOT NULL, status text NOT NULL DEFAULT 'completed', affected int NOT NULL DEFAULT 0,
  note text, scheduled_at timestamptz NOT NULL DEFAULT now(), completed_at timestamptz
);

-- Báo cáo hành vi cần xem xét (quấy rối, quyền riêng tư/dữ liệu, lạm dụng quyền/trả đũa)
CREATE TABLE IF NOT EXISTS conduct_cases (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id uuid NOT NULL REFERENCES companies(id),
  code text NOT NULL,
  reporter_member_id uuid NOT NULL REFERENCES company_members(id),
  category text NOT NULL CHECK (category IN ('harassment','privacy_data','power_abuse','other','not_sure')),
  subcode text,
  description text NOT NULL,
  occurred_at timestamptz,
  object_type text, object_id uuid, object_label text,
  reported_member_id uuid REFERENCES company_members(id),
  current_risk text NOT NULL DEFAULT 'none' CHECK (current_risk IN ('none','safety','retaliation')),
  safe_contact text,
  anonymity text NOT NULL DEFAULT 'to_reported' CHECK (anonymity IN ('to_reported','to_handler')),
  status text NOT NULL DEFAULT 'received' CHECK (status IN ('received','screening','needs_info','investigating','resolved','insufficient','referred','closed','review_requested')),
  severity text CHECK (severity IN ('S0','S1','S2','S3','S4')),
  handler_member_id uuid REFERENCES company_members(id),
  retaliation_flag boolean NOT NULL DEFAULT false,
  explanation_requested_at timestamptz, explanation_summary text,
  outcome text, outcome_reason text,
  review_requested_by uuid REFERENCES company_members(id),
  closed_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS cc_company ON conduct_cases(company_id, status);
CREATE TABLE IF NOT EXISTS conduct_case_events (
  id bigserial PRIMARY KEY,
  case_id uuid NOT NULL REFERENCES conduct_cases(id),
  actor_member_id uuid REFERENCES company_members(id),
  kind text NOT NULL,
  visibility text NOT NULL CHECK (visibility IN ('handler','reporter','reported','parties')),
  body text,
  data jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS cce_case ON conduct_case_events(case_id, created_at);
DROP TRIGGER IF EXISTS cce_no_update ON conduct_case_events;
CREATE TRIGGER cce_no_update BEFORE UPDATE OR DELETE ON conduct_case_events FOR EACH ROW EXECUTE FUNCTION dal_immutable();

-- =====================================================================
-- v6: Giám sát, điều phối & báo cáo hiệu suất (Đặc tả nghiệp vụ v2.0)
-- phiên làm việc, phân loại thời gian, vị trí, sản lượng, bàn giao liên bộ phận,
-- chuỗi đơn hàng, deadline/cảnh báo, quỹ nghỉ tích lũy, phản hồi dữ liệu
-- =====================================================================
-- Trưởng nhóm (tổ chức thực hiện, xác nhận sản lượng); mặc định = quản lý nhóm
ALTER TABLE groups ADD COLUMN IF NOT EXISTS leader_member_id uuid REFERENCES company_members(id);

-- Danh mục vị trí làm việc (tham khảo; không GPS)
CREATE TABLE IF NOT EXISTS work_locations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id uuid NOT NULL REFERENCES companies(id),
  name text NOT NULL,
  kind text NOT NULL DEFAULT 'area' CHECK (kind IN ('department','machine_room','raw_store','cold_store','production_floor','packing','office','outside','area')),
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- Chuỗi đơn hàng = việc gốc có is_chain; nhiệm vụ con giữ mã riêng, cùng root_id
ALTER TABLE tasks ADD COLUMN IF NOT EXISTS is_chain boolean NOT NULL DEFAULT false;
ALTER TABLE tasks ADD COLUMN IF NOT EXISTS chain_code text;
ALTER TABLE tasks ADD COLUMN IF NOT EXISTS importance text NOT NULL DEFAULT 'normal';
ALTER TABLE tasks DROP CONSTRAINT IF EXISTS tasks_importance_check;
ALTER TABLE tasks ADD CONSTRAINT tasks_importance_check CHECK (importance IN ('normal','high','critical'));
ALTER TABLE tasks ADD COLUMN IF NOT EXISTS customer_name text;
ALTER TABLE tasks ADD COLUMN IF NOT EXISTS order_value numeric;      -- dữ liệu nhạy cảm (giá bán) — chỉ Ban quản trị/người tạo chuỗi
ALTER TABLE tasks ADD COLUMN IF NOT EXISTS margin_note text;          -- nhạy cảm (lợi nhuận)
ALTER TABLE tasks ADD COLUMN IF NOT EXISTS standard_minutes int;      -- thời lượng chuẩn công đoạn (dùng tính deadline ngược)
ALTER TABLE tasks ADD COLUMN IF NOT EXISTS buffer_minutes int NOT NULL DEFAULT 0;
ALTER TABLE tasks ADD COLUMN IF NOT EXISTS planned_start_at timestamptz;
ALTER TABLE tasks ADD COLUMN IF NOT EXISTS risk_level text NOT NULL DEFAULT 'normal';
ALTER TABLE tasks ADD COLUMN IF NOT EXISTS risk_notified text;
ALTER TABLE tasks ADD COLUMN IF NOT EXISTS early_start_reason text;
ALTER TABLE tasks ADD COLUMN IF NOT EXISTS work_location_id uuid REFERENCES work_locations(id);
ALTER TABLE tasks ADD COLUMN IF NOT EXISTS location_required boolean NOT NULL DEFAULT false;
ALTER TABLE tasks ADD COLUMN IF NOT EXISTS handover_mode text NOT NULL DEFAULT 'single';
ALTER TABLE tasks DROP CONSTRAINT IF EXISTS tasks_handover_mode_check;
ALTER TABLE tasks ADD CONSTRAINT tasks_handover_mode_check CHECK (handover_mode IN ('single','stage'));
CREATE UNIQUE INDEX IF NOT EXISTS tasks_chain_code ON tasks(company_id, chain_code) WHERE chain_code IS NOT NULL;

-- Phiên làm việc: mỗi nhân viên tối đa 1 phiên đang chạy
CREATE TABLE IF NOT EXISTS work_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id uuid NOT NULL REFERENCES companies(id),
  member_id uuid NOT NULL REFERENCES company_members(id),
  task_id uuid NOT NULL REFERENCES tasks(id),
  started_at timestamptz NOT NULL DEFAULT now(),
  ended_at timestamptz,
  end_reason text CHECK (end_reason IN ('switch','pause','handover','complete','end','auto')),
  source text NOT NULL DEFAULT 'app' CHECK (source IN ('app','leader','device','auto')),
  work_location_id uuid REFERENCES work_locations(id),
  location_source text CHECK (location_source IN ('task','declared','outside','unknown')),
  location_verified boolean NOT NULL DEFAULT false,
  location_verification_note text,
  night boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS ws_one_active ON work_sessions(member_id) WHERE ended_at IS NULL;
CREATE INDEX IF NOT EXISTS ws_task ON work_sessions(task_id);
CREATE INDEX IF NOT EXISTS ws_member_time ON work_sessions(member_id, started_at);

-- Thời gian không thực hiện: chuẩn bị, chuyển đổi, chờ việc, hoãn khách quan, nghỉ tích lũy, bàn giao, chưa xác định
CREATE TABLE IF NOT EXISTS work_time_records (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id uuid NOT NULL REFERENCES companies(id),
  member_id uuid NOT NULL REFERENCES company_members(id),
  task_id uuid REFERENCES tasks(id),
  category text NOT NULL CHECK (category IN ('preparation','changeover','waiting','objective_pause','subjective_pause','rest_internal','handover','unknown')),
  reason text, related_party text,
  started_at timestamptz NOT NULL DEFAULT now(),
  ended_at timestamptz,
  created_by uuid REFERENCES company_members(id),
  confirmed_by uuid REFERENCES company_members(id),   -- người có thẩm quyền xác nhận hoãn khách quan
  confirmed_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS wtr_one_open ON work_time_records(member_id) WHERE ended_at IS NULL;
CREATE INDEX IF NOT EXISTS wtr_member_time ON work_time_records(member_id, started_at);

-- Định mức sản lượng
CREATE TABLE IF NOT EXISTS production_standards (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id uuid NOT NULL REFERENCES companies(id),
  name text NOT NULL,
  task_type_id uuid REFERENCES task_types(id),
  unit text NOT NULL DEFAULT 'sản phẩm',
  quantity numeric NOT NULL CHECK (quantity > 0),
  minutes numeric NOT NULL CHECK (minutes > 0),
  note text,
  active boolean NOT NULL DEFAULT true,
  version int NOT NULL DEFAULT 1,
  created_by uuid REFERENCES company_members(id),
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE tasks ADD COLUMN IF NOT EXISTS production_standard_id uuid REFERENCES production_standards(id);

-- Sản lượng & chất lượng theo phiên/công đoạn do trưởng nhóm ghi nhận; không sửa đè — điều chỉnh tạo phiên bản mới
CREATE TABLE IF NOT EXISTS production_records (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id uuid NOT NULL REFERENCES companies(id),
  task_id uuid NOT NULL REFERENCES tasks(id),
  root_id uuid REFERENCES tasks(id),
  group_id uuid REFERENCES groups(id),
  session_id uuid REFERENCES work_sessions(id),
  mode text NOT NULL DEFAULT 'stage' CHECK (mode IN ('stage','single')),
  standard_id uuid REFERENCES production_standards(id),
  participants uuid[] NOT NULL DEFAULT '{}',
  unit text NOT NULL DEFAULT 'sản phẩm',
  input_qty numeric, planned_qty numeric,
  actual_qty numeric NOT NULL DEFAULT 0, accepted_qty numeric NOT NULL DEFAULT 0,
  rejected_qty numeric NOT NULL DEFAULT 0, rework_qty numeric NOT NULL DEFAULT 0, backlog_qty numeric NOT NULL DEFAULT 0,
  execution_minutes numeric,
  started_at timestamptz, ended_at timestamptz,
  source text NOT NULL DEFAULT 'leader' CHECK (source IN ('leader','device','scan','scale','batch')),
  note text, issues text,
  status text NOT NULL DEFAULT 'confirmed' CHECK (status IN ('confirmed','superseded')),
  version int NOT NULL DEFAULT 1,
  supersedes_id uuid REFERENCES production_records(id),
  recorded_by uuid NOT NULL REFERENCES company_members(id),
  confirmed_by uuid REFERENCES company_members(id), confirmed_at timestamptz,
  change_reason text,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS pr_task ON production_records(task_id, status);
CREATE INDEX IF NOT EXISTS pr_group_time ON production_records(group_id, created_at);
CREATE OR REPLACE FUNCTION pr_no_silent_edit() RETURNS trigger AS $$
BEGIN
  IF TG_OP = 'DELETE' THEN RAISE EXCEPTION 'production_records: không xóa bản ghi đã xác nhận'; END IF;
  -- chỉ cho phép chuyển confirmed -> superseded (khi có phiên bản điều chỉnh)
  IF NEW.status = 'superseded' AND OLD.status = 'confirmed' AND NEW.actual_qty = OLD.actual_qty AND NEW.accepted_qty = OLD.accepted_qty
     AND NEW.rejected_qty = OLD.rejected_qty AND NEW.rework_qty = OLD.rework_qty AND NEW.backlog_qty = OLD.backlog_qty THEN RETURN NEW; END IF;
  RAISE EXCEPTION 'production_records: không sửa trực tiếp; tạo bản ghi điều chỉnh có lý do';
END $$ LANGUAGE plpgsql;
DROP TRIGGER IF EXISTS pr_guard ON production_records;
CREATE TRIGGER pr_guard BEFORE UPDATE OR DELETE ON production_records FOR EACH ROW EXECUTE FUNCTION pr_no_silent_edit();

-- Bàn giao liên bộ phận (handover context)
CREATE TABLE IF NOT EXISTS handover_contexts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id uuid NOT NULL REFERENCES companies(id),
  root_id uuid REFERENCES tasks(id),
  from_task_id uuid REFERENCES tasks(id),
  to_task_id uuid REFERENCES tasks(id),
  from_group_id uuid REFERENCES groups(id),
  to_group_id uuid REFERENCES groups(id),
  content text NOT NULL,
  acceptance_criteria text,
  quantity numeric, unit text,
  due_at timestamptz,
  status text NOT NULL DEFAULT 'submitted' CHECK (status IN ('submitted','accepted','rejected','cancelled')),
  submitted_by uuid REFERENCES company_members(id), submitted_at timestamptz NOT NULL DEFAULT now(),
  accepted_by uuid REFERENCES company_members(id), accepted_at timestamptz,
  rejection_reason text, reject_count int NOT NULL DEFAULT 0,
  auto boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS hc_to ON handover_contexts(to_task_id, status);
CREATE INDEX IF NOT EXISTS hc_root ON handover_contexts(root_id);
CREATE TABLE IF NOT EXISTS handover_events (
  id bigserial PRIMARY KEY,
  handover_id uuid NOT NULL REFERENCES handover_contexts(id),
  actor_member_id uuid REFERENCES company_members(id),
  kind text NOT NULL CHECK (kind IN ('submitted','accepted','rejected','supplemented','cancelled')),
  note text,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- Quỹ nghỉ bổ sung tích lũy (tách khỏi nghỉ theo luật và tăng ca)
CREATE TABLE IF NOT EXISTS rest_transactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id uuid NOT NULL REFERENCES companies(id),
  member_id uuid NOT NULL REFERENCES company_members(id),
  kind text NOT NULL CHECK (kind IN ('accrual','use','adjust','expire')),
  minutes int NOT NULL,                       -- accrual/adjust(+/-) ; use/expire âm
  work_date date,
  status text NOT NULL DEFAULT 'posted' CHECK (status IN ('pending','approved','posted','rejected','cancelled')),
  time_record_id uuid REFERENCES work_time_records(id),
  reason text,
  requested_by uuid REFERENCES company_members(id),
  approved_by uuid REFERENCES company_members(id), approved_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS rt_member ON rest_transactions(member_id, created_at);

-- Phản hồi dữ liệu sai của nhân viên
CREATE TABLE IF NOT EXISTS data_feedback (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id uuid NOT NULL REFERENCES companies(id),
  member_id uuid NOT NULL REFERENCES company_members(id),
  target_type text NOT NULL CHECK (target_type IN ('session','time_record','production','task','evaluation','performance')),
  target_id uuid,
  content text NOT NULL,
  status text NOT NULL DEFAULT 'open' CHECK (status IN ('open','resolved','rejected')),
  assigned_to uuid REFERENCES company_members(id),
  resolution text, resolved_by uuid REFERENCES company_members(id), resolved_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- Tự khai công việc: vị trí (yêu cầu khai nếu xác định được; cho phép ngoài công ty/không xác định)
ALTER TABLE employee_work_records ADD COLUMN IF NOT EXISTS work_location_id uuid REFERENCES work_locations(id);
ALTER TABLE employee_work_records ADD COLUMN IF NOT EXISTS location_source text;

-- =====================================================================
-- v7: tăng ca ngoại lệ (máy chấm công hỏng / làm ngoài xưởng), tăng ca trong ghi nhận sản lượng,
-- nhiệm vụ thường trực, tự động bắt đầu (khi nhận bàn giao / theo lịch), mã nhiệm vụ con,
-- phương thức bàn giao + tài liệu/đường link
-- =====================================================================
ALTER TABLE overtime_records DROP CONSTRAINT IF EXISTS overtime_records_ot_type_check;
ALTER TABLE overtime_records ADD CONSTRAINT overtime_records_ot_type_check CHECK (ot_type IN ('planned','ad_hoc','incident','workload','support','timeclock_down','offsite','production'));
ALTER TABLE overtime_records ADD COLUMN IF NOT EXISTS source text NOT NULL DEFAULT 'manual';
ALTER TABLE overtime_records ADD COLUMN IF NOT EXISTS production_record_id uuid REFERENCES production_records(id);
ALTER TABLE overtime_records ADD COLUMN IF NOT EXISTS place text;
ALTER TABLE overtime_records ADD COLUMN IF NOT EXISTS work_minutes int;           -- giờ làm việc thường được ghi nhận kèm (ngoại lệ chấm công)
ALTER TABLE overtime_records DROP CONSTRAINT IF EXISTS overtime_records_approval_status_check;
ALTER TABLE overtime_records ADD CONSTRAINT overtime_records_approval_status_check CHECK (approval_status IN ('pending','confirmed','rejected','superseded'));

ALTER TABLE tasks ADD COLUMN IF NOT EXISTS is_standing boolean NOT NULL DEFAULT false;     -- nhiệm vụ thường trực (không có hạn, dùng để ghi nhận phiên)
ALTER TABLE tasks ADD COLUMN IF NOT EXISTS auto_start text NOT NULL DEFAULT 'manual';
ALTER TABLE tasks DROP CONSTRAINT IF EXISTS tasks_auto_start_check;
ALTER TABLE tasks ADD CONSTRAINT tasks_auto_start_check CHECK (auto_start IN ('manual','on_handover','scheduled'));
ALTER TABLE tasks ADD COLUMN IF NOT EXISTS scheduled_start_at timestamptz;
ALTER TABLE tasks ADD COLUMN IF NOT EXISTS auto_started_at timestamptz;
ALTER TABLE tasks ADD COLUMN IF NOT EXISTS schedule_notified boolean NOT NULL DEFAULT false;
DROP INDEX IF EXISTS tasks_code_unique;

ALTER TABLE task_submissions ADD COLUMN IF NOT EXISTS links jsonb NOT NULL DEFAULT '[]'::jsonb;

ALTER TABLE handover_contexts ADD COLUMN IF NOT EXISTS method text NOT NULL DEFAULT 'direct_inspection';
ALTER TABLE handover_contexts DROP CONSTRAINT IF EXISTS handover_contexts_method_check;
ALTER TABLE handover_contexts ADD CONSTRAINT handover_contexts_method_check CHECK (method IN ('direct_inspection','customer_confirmation','document_check','leader_confirmation','other'));
ALTER TABLE handover_contexts ADD COLUMN IF NOT EXISTS method_note text;
ALTER TABLE handover_contexts ADD COLUMN IF NOT EXISTS links jsonb NOT NULL DEFAULT '[]'::jsonb;

ALTER TABLE production_records ADD COLUMN IF NOT EXISTS participant_times jsonb NOT NULL DEFAULT '[]'::jsonb;  -- [{member_id, work_minutes, ot_minutes}]
ALTER TABLE production_records ADD COLUMN IF NOT EXISTS overtime_minutes numeric NOT NULL DEFAULT 0;

-- =====================================================================
-- v8: Phân cấp doanh nghiệp tầng 3–7 — chức vụ, cấp bậc, chức năng phòng ban, quyền hạn cấu hình riêng,
-- quy trình lập – xem xét – duyệt đơn hàng sản xuất, mẫu công việc theo phòng ban
-- =====================================================================
CREATE TABLE IF NOT EXISTS positions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id uuid NOT NULL REFERENCES companies(id),
  name text NOT NULL,
  tier int NOT NULL CHECK (tier BETWEEN 3 AND 7),
  grp text NOT NULL DEFAULT 'execution',         -- lãnh đạo / quản lý cấp cao / quản lý phòng ban / quản lý nhóm / chuyên môn / thực thi / hỗ trợ
  capabilities jsonb NOT NULL DEFAULT '{}'::jsonb, -- ghi đè quyền mặc định theo tầng: {"create_order": true, ...}
  system_key text,
  active boolean NOT NULL DEFAULT true,
  sort int NOT NULL DEFAULT 100,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS positions_sys ON positions(company_id, system_key) WHERE system_key IS NOT NULL;
ALTER TABLE company_members ADD COLUMN IF NOT EXISTS position_id uuid REFERENCES positions(id);
ALTER TABLE company_members ADD COLUMN IF NOT EXISTS job_grade text;

-- Chức năng phòng ban quyết định quyền nghiệp vụ (vd chỉ Kinh doanh/Kế hoạch/Sản xuất lập đơn hàng)
ALTER TABLE departments ADD COLUMN IF NOT EXISTS function text NOT NULL DEFAULT 'other';
ALTER TABLE departments DROP CONSTRAINT IF EXISTS departments_function_check;
ALTER TABLE departments ADD CONSTRAINT departments_function_check CHECK (function IN ('production','planning','sales','warehouse','qa','hr','admin','finance','it','marketing','hse','security','cs','other'));
ALTER TABLE groups ADD COLUMN IF NOT EXISTS department_id uuid REFERENCES departments(id);

-- Mẫu công việc theo phòng ban (null = mẫu dùng chung); quản lý phòng ban tự tạo/sửa mẫu của phòng mình
ALTER TABLE task_templates ADD COLUMN IF NOT EXISTS department_id uuid REFERENCES departments(id);
ALTER TABLE task_templates ADD COLUMN IF NOT EXISTS created_by uuid REFERENCES company_members(id);
ALTER TABLE task_templates ADD COLUMN IF NOT EXISTS updated_at timestamptz;

-- Đơn hàng sản xuất: lập -> xem xét -> duyệt -> phát hành (trưởng nhóm nhận việc lần lượt theo chuỗi)
ALTER TABLE tasks ADD COLUMN IF NOT EXISTS order_status text;
ALTER TABLE tasks DROP CONSTRAINT IF EXISTS tasks_order_status_check;
ALTER TABLE tasks ADD CONSTRAINT tasks_order_status_check CHECK (order_status IS NULL OR order_status IN ('pending_review','reviewed','approved','rejected'));
ALTER TABLE tasks ADD COLUMN IF NOT EXISTS order_reviewed_by uuid REFERENCES company_members(id);
ALTER TABLE tasks ADD COLUMN IF NOT EXISTS order_reviewed_at timestamptz;
ALTER TABLE tasks ADD COLUMN IF NOT EXISTS order_approved_by uuid REFERENCES company_members(id);
ALTER TABLE tasks ADD COLUMN IF NOT EXISTS order_approved_at timestamptz;
ALTER TABLE tasks ADD COLUMN IF NOT EXISTS order_note text;
