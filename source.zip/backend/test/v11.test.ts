/* Kiểm thử v11: kết nối (làm mới phiên), kêu gọi hỗ trợ, phản ánh ẩn danh, dòng thời gian nhiệm vụ, bình luận, thiết bị. */
process.env.DATABASE_URL = process.env.TEST_DATABASE_URL || 'postgresql://app:app@localhost:5432/teamapp_test';
process.env.DISABLE_SCHEDULER = 'true';
process.env.UPLOAD_DIR = '/tmp/teamapp-test-uploads';

import { INestApplication } from '@nestjs/common';
import { closePool, q, q1 } from '../src/db/db';
import { createApp } from '../src/main';
import { resetDb, seed } from '../src/db/seed';

let app: INestApplication;
let url = '';
const tok: Record<string, string> = {};
const refresh: Record<string, string> = {};
const ids: Record<string, string> = {};
async function call(who: string, method: string, path: string, body?: any) {
  const r = await fetch(url + path, { method, headers: { 'Content-Type': 'application/json', ...(tok[who] ? { Authorization: `Bearer ${tok[who]}` } : {}) }, body: body ? JSON.stringify(body) : undefined });
  return { status: r.status, body: (await r.json().catch(() => ({}))) as any };
}
async function ok(who: string, method: string, path: string, body?: any) {
  const r = await call(who, method, path, body);
  if (r.status >= 300) throw new Error(`${method} ${path} -> ${r.status} ${JSON.stringify(r.body)}`);
  return r.body;
}
const PH: Record<string, string> = { admin: '0901000002', m1: '0901000003', m2: '0901000004', e1: '0901000007', e2: '0901000008', e3: '0901000009' };

beforeAll(async () => {
  await resetDb();
  app = await createApp();
  await app.listen(0);
  url = `http://127.0.0.1:${(app.getHttpServer().address() as any).port}/api/v1`;
  await seed(url);
  for (const [k, p] of Object.entries(PH)) {
    const s = await ok('', 'POST', '/auth/login', { phone: p, password: 'Demo@123' });
    tok[k] = s.access_token; refresh[k] = s.refresh_token;
    ids[k] = (await q1(`SELECT cm.id FROM company_members cm JOIN users u ON u.id=cm.user_id WHERE u.phone=$1`, [p])).id;
  }
  ids.g1 = (await q1(`SELECT id FROM groups WHERE name='Nhóm Vận hành'`)).id;
  ids.sx = (await q1(`SELECT id FROM departments WHERE name='Sản xuất - Vận hành'`)).id;
});
afterAll(async () => { await app.close(); await closePool(); });

test('Làm mới phiên: dùng lại token vừa xoay vòng trong 60 giây không bị đăng xuất (mạng rớt / 2 tab)', async () => {
  const a = await ok('', 'POST', '/auth/refresh', { refresh_token: refresh.e2 });
  const b = await ok('', 'POST', '/auth/refresh', { refresh_token: refresh.e2 });   // phản hồi lần trước bị rơi
  expect(a.access_token).toBeTruthy(); expect(b.access_token).toBeTruthy();
  await q(`UPDATE refresh_tokens SET revoked_at=now() - interval '5 minutes' WHERE revoked_at IS NOT NULL`);
  expect((await call('', 'POST', '/auth/refresh', { refresh_token: refresh.e2 })).status).toBe(401);  // quá 60 giây: hết hiệu lực
});

test('Kêu gọi hỗ trợ: trưởng phòng gửi toàn phòng; đồng ý/từ chối; phiên hỗ trợ có thời gian; hủy báo người đã nhận; lịch sử hỗ trợ', async () => {
  expect((await call('e1', 'POST', '/support-requests', { title: 'Cần người bốc hàng', broadcast: 'department' })).status).toBe(403);
  const r = await ok('m1', 'POST', '/support-requests', { title: 'Cần 3 người dỡ container nguyên liệu', broadcast: 'department', neededPeople: 3 });
  expect(r.broadcast).toBe('department');
  expect(await q1(`SELECT 1 FROM notifications WHERE member_id=$1 AND type='support.call' AND reference_id=$2`, [ids.e1, r.id])).toBeTruthy();
  expect((await ok('m1', 'GET', '/support-requests?scope=mine_open')).some((x: any) => x.id === r.id)).toBe(true);   // việc của tôi
  expect((await call('m2', 'POST', `/support-requests/${r.id}/accept`)).status).toBe(403);                       // khác phòng
  await ok('e1', 'POST', `/support-requests/${r.id}/accept`);
  await ok('e2', 'POST', `/support-requests/${r.id}/decline`, { note: 'Đang chạy máy' });
  const d = await ok('m1', 'GET', `/support-requests/${r.id}`);
  expect(d.responses.find((x: any) => x.helper_id === ids.e1).status).toBe('accepted');
  expect(d.responses.find((x: any) => x.helper_id === ids.e2).status).toBe('declined');
  const s = await ok('e1', 'POST', `/support-requests/${r.id}/start`);
  expect(s.active.requester_name).toBeTruthy();
  await q(`UPDATE support_sessions SET started_at=now() - interval '25 minutes' WHERE helper_id=$1 AND ended_at IS NULL`, [ids.e1]);
  await ok('e1', 'POST', '/support-sessions/end', {});
  expect((await ok('m1', 'GET', `/support-requests/${r.id}`)).responses.find((x: any) => x.helper_id === ids.e1).minutes).toBeGreaterThanOrEqual(24);
  expect((await ok('m1', 'GET', '/support-requests?scope=to_confirm')).some((x: any) => x.id === r.id)).toBe(true);
  const h = await ok('e1', 'GET', '/support-history');
  expect(h.total_minutes).toBeGreaterThanOrEqual(24);
  expect((await ok('m1', 'GET', `/support-history?memberId=${ids.e1}`)).sessions).toBeGreaterThan(0);
  // Hủy: người đã đồng ý nhận tin báo
  const r2 = await ok('m1', 'POST', '/support-requests', { title: 'Dọn kho lạnh', broadcast: 'group', groupId: ids.g1 });
  await ok('e3', 'POST', `/support-requests/${r2.id}/accept`);
  await ok('m1', 'POST', `/support-requests/${r2.id}/close`, { cancel: true, reason: 'Xe chưa về' });
  expect(await q1(`SELECT 1 FROM notifications WHERE member_id=$1 AND type='support.cancelled' AND reference_id=$2`, [ids.e3, r2.id])).toBeTruthy();
});

test('Phản ánh: công khai/ẩn danh, gộp nhiều người, gửi tầng 5, ẩn danh không lộ tên kể cả với quản lý; kết luận ảnh hưởng vào dòng thời gian', async () => {
  const t = await q1(`SELECT t.id FROM tasks t WHERE t.group_id=$1 AND NOT t.is_chain AND t.status IN ('in_progress','not_started') LIMIT 1`, [ids.g1]);
  const a = await ok('e1', 'POST', '/member-reports', { taskId: t.id, category: 'left_post', description: 'Người làm ca bỏ vị trí 40 phút không báo', anonymous: true });
  expect(a.message).toMatch(/ẩn danh/);
  await ok('e2', 'POST', '/member-reports', { taskId: t.id, category: 'left_post', description: 'Xác nhận có rời vị trí lúc 10h', anonymous: false });
  expect((await call('e1', 'POST', '/member-reports', { taskId: t.id, category: 'left_post', description: 'Báo lại lần nữa cho chắc', anonymous: true })).status).toBe(409);
  const row = await q1(`SELECT reporter_id FROM member_reports WHERE case_id=$1 AND anonymous`, [a.id]);
  expect(row.reporter_id).toBeNull();                                         // không lưu danh tính
  const list = await ok('m1', 'GET', '/member-reports?scope=handling');
  const c = list.find((x: any) => x.id === a.id);
  expect(c.reporter_count).toBe(2); expect(c.task_title).toBeTruthy(); expect(c.handler_id).toBe(ids.m1);
  const det = await ok('m1', 'GET', `/member-reports/${a.id}`);
  expect(det.reports.filter((r: any) => r.reporter_name).map((r: any) => r.reporter_name)).toHaveLength(1);
  expect(JSON.stringify(det)).not.toContain(ids.e1);
  expect((await call('e3', 'GET', `/member-reports/${a.id}`)).status).toBe(404);
  await ok('m1', 'POST', `/member-reports/${a.id}/resolve`, { decision: 'resolved', conclusion: 'Xác minh qua camera: có rời vị trí 35 phút', actionTaken: 'Nhắc nhở, bố trí người thay ca', affectsProgress: true });
  const tl = await ok('m1', 'GET', `/tasks/${t.id}/timeline`);
  expect(tl.events.some((e: any) => e.kind === 'report_case' && e.impact.includes('tiến độ'))).toBe(true);
  expect(await q1(`SELECT 1 FROM notifications WHERE member_id=$1 AND type='member_report.resolved'`, [ids.e2])).toBeTruthy();
});

test('Dòng thời gian đơn hàng: công đoạn, đoạn vướng (chờ bàn giao/hoãn) có thời lượng và cách giải quyết', async () => {
  const chain = await q1(`SELECT id FROM tasks WHERE is_chain ORDER BY created_at LIMIT 1`);
  const tl = await ok('admin', 'GET', `/tasks/${chain.id}/timeline`);
  expect(tl.stages.length).toBeGreaterThan(0);
  expect(tl.summary).toHaveProperty('blocked_minutes');
  expect(tl.events.length).toBeGreaterThan(3);
  expect(tl.events.filter((e: any) => e.kind === 'blocker').every((b: any) => typeof b.minutes === 'number' && b.resolution)).toBe(true);
});

test('Bình luận: trích dẫn trả lời, đếm chưa đọc, đẩy nhiệm vụ lên đầu danh sách, xem toàn bộ lịch sử', async () => {
  const t = await q1(`SELECT t.id FROM tasks t JOIN task_assignees a ON a.task_id=t.id AND a.active WHERE a.company_member_id=$1 AND t.status IN ('in_progress','not_started') AND NOT t.pinned ORDER BY t.created_at LIMIT 1`, [ids.e1]);
  const d1 = await ok('m1', 'POST', `/tasks/${t.id}/comments`, { content: 'Lô này cần kiểm tra độ ẩm trước khi xuất' });
  const first = d1.comments.at(-1);
  await ok('e1', 'POST', `/tasks/${t.id}/comments`, { content: 'Em đo rồi, 12%', replyToId: first.id });
  const d2 = await ok('m1', 'GET', `/tasks/${t.id}`);
  expect(d2.comments.at(-1).reply_content).toContain('độ ẩm');
  for (const n of [1, 2, 3]) await ok('m1', 'POST', `/tasks/${t.id}/comments`, { content: `Ghi chú bổ sung ${n}` });
  const lst = await ok('e1', 'GET', '/tasks?mine=any&limit=50');
  const row = lst.items.find((x: any) => x.id === t.id);
  expect(row.unread_comments).toBe(3);
  expect(lst.items.filter((x: any) => !x.pinned && !x.urgent)[0].id).toBe(t.id);       // bình luận đẩy lên đầu
  const all = await ok('e1', 'GET', `/tasks/${t.id}/comments`);
  expect(all.total).toBe(5);
  expect((await ok('e1', 'GET', '/tasks?mine=any&limit=50')).items.find((x: any) => x.id === t.id).unread_comments).toBe(0);
});

test('Thiết bị: khai vị trí ban đầu, mang ra phải có giấy phép, hoàn thành bắt buộc vị trí hiện tại; kiểm kê cuối ngày; người hỗ trợ trong bàn giao', async () => {
  const typeId = (await q1(`SELECT id FROM task_types WHERE name='Hành chính'`)).id;
  const t = await ok('m1', 'POST', '/tasks', { title: 'Sửa băng tải số 3', description: 'Thay con lăn băng tải', groupId: ids.g1, ownerMemberId: ids.e1, taskTypeId: typeId, complexity: 'simple',
    requirementLevel: 'normal', estimatedHours: 2, dueAt: new Date(Date.now() + 86400000).toISOString(), criteria: [{ direction: 'output', criterion: 'Băng tải chạy ổn định' }] });
  await ok('e1', 'POST', `/tasks/${t.id}/start`);
  expect((await call('e1', 'POST', `/tasks/${t.id}/equipment`, { name: 'Máy khoan pin', movedOut: true })).status).toBe(422);   // mang ra không có giấy phép
  const eq = await ok('e1', 'POST', `/tasks/${t.id}/equipment`, { name: 'Máy khoan pin', code: 'MK-02', quantity: 1 });
  const item = eq.items[0];
  await ok('e1', 'PATCH', `/tasks/${t.id}/equipment/${item.id}`, { originLocation: 'Tủ dụng cụ xưởng 1' });                     // bổ sung vị trí ban đầu
  const r = await call('e1', 'POST', `/tasks/${t.id}/submit`, { outputDescription: 'Đã thay con lăn, chạy thử ổn', supporterIds: [ids.e2] });
  expect(r.status).toBe(409); expect(r.body.error.code).toBe('EQUIPMENT_CHECK_REQUIRED');
  const ck = await ok('e1', 'POST', `/tasks/${t.id}/equipment/check`, { kind: 'daily', items: [{ id: item.id, location: 'Tủ dụng cụ xưởng 1' }] });
  expect(ck.checked_today).toBe(true);
  await ok('e1', 'POST', `/tasks/${t.id}/submit`, { outputDescription: 'Đã thay con lăn, chạy thử ổn', supporterIds: [ids.e2] });
  const sub = await q1(`SELECT supporter_ids FROM task_submissions WHERE task_id=$1`, [t.id]);
  expect(sub.supporter_ids).toEqual([ids.e2]);
  expect(await q1(`SELECT 1 FROM notifications WHERE member_id=$1 AND type='task.supporter_listed'`, [ids.e2])).toBeTruthy();
  // Người hỗ trợ không có tên -> phản ánh "hỗ trợ không được ghi nhận"
  const pr = await ok('e3', 'POST', '/member-reports', { taskId: t.id, category: 'support_unrecorded', description: 'Tôi phụ khiêng con lăn 30 phút nhưng không có tên' });
  expect(pr.code).toMatch(/^PA-/);
});
