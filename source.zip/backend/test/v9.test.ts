/* Kiểm thử v9: liên lạc trong app (gọi 3 phút, ghi âm, nhật ký 30 ngày, che số), yêu cầu hỗ trợ, tổng quan công việc, QR khu vực & QR bàn giao bên ngoài (Đặc tả v2.1). */
process.env.DATABASE_URL = process.env.TEST_DATABASE_URL || 'postgresql://app:app@localhost:5432/teamapp_test';
process.env.DISABLE_SCHEDULER = 'true';
process.env.UPLOAD_DIR = '/tmp/teamapp-test-uploads';

import { INestApplication } from '@nestjs/common';
import { closePool, q, q1 } from '../src/db/db';
import { createApp } from '../src/main';
import { resetDb, seed } from '../src/db/seed';
import { runCommsRetention } from '../src/modules/comms.controller';

let app: INestApplication;
let url = '';
const tok: Record<string, string> = {};
const ids: Record<string, string> = {};
async function call(who: string, method: string, path: string, body?: any) {
  const r = await fetch(url + path, { method, headers: { 'Content-Type': 'application/json', ...(tok[who] ? { Authorization: `Bearer ${tok[who]}` } : {}) }, body: body ? JSON.stringify(body) : undefined });
  return { status: r.status, body: (await r.json().catch(() => ({}))) as any };
}
async function ok(who: string, method: string, path: string, body?: any) {
  const r = await call(who, method, path, body);
  if (r.status >= 300) throw new Error(`${method} ${path} -> ${r.status} ${JSON.stringify(r.body)}`);
  return r.body;
}
const PH: Record<string, string> = { owner: '0901000001', admin: '0901000002', m1: '0901000003', m2: '0901000004', e1: '0901000007', e2: '0901000008', e3: '0901000009', hr: '0901000012' };
let typeId = '';

beforeAll(async () => {
  await resetDb();
  app = await createApp();
  await app.listen(0);
  url = `http://127.0.0.1:${(app.getHttpServer().address() as any).port}/api/v1`;
  await seed(url);
  for (const [k, p] of Object.entries(PH)) {
    tok[k] = (await ok('', 'POST', '/auth/login', { phone: p, password: 'Demo@123' })).access_token;
    ids[k] = (await q1(`SELECT cm.id FROM company_members cm JOIN users u ON u.id=cm.user_id WHERE u.phone=$1`, [p])).id;
  }
  for (const [k, n] of Object.entries({ g1: 'Nhóm Vận hành', g2: 'Nhóm Kinh doanh' })) ids[k] = (await q1(`SELECT id FROM groups WHERE name=$1`, [n])).id;
  typeId = (await q1(`SELECT id FROM task_types WHERE name='Kinh doanh'`)).id;
});
afterAll(async () => { await app.close(); await closePool(); });

test('Che số điện thoại trong nhóm/sơ đồ tổ chức/danh bạ; Zalo qua liên kết một lần', async () => {
  const g = await ok('e1', 'GET', `/groups/${ids.g1}`);
  expect(g.members.every((m: any) => !m.phone)).toBe(true);
  const org = await ok('m1', 'GET', '/hr/org-chart');
  expect(org.members.every((m: any) => !m.phone)).toBe(true);
  const c = await ok('e1', 'GET', '/contacts');
  expect(c.length).toBeGreaterThan(3);
  expect(JSON.stringify(c)).not.toMatch(/090100/);
  const z = await ok('e1', 'POST', `/contacts/${ids.m1}/zalo`);
  expect(z.url).toMatch(/^\/api\/v1\/contacts\/go\//);
  const r = await fetch(url.replace('/api/v1', '') + z.url, { redirect: 'manual' });
  expect(r.status).toBe(302);
  expect((await fetch(url.replace('/api/v1', '') + z.url, { redirect: 'manual' })).status).toBe(410); // dùng một lần
});

test('Cuộc gọi trong app: báo hiệu WebRTC, giới hạn 3 phút, ghi âm cần đồng ý, khai báo công việc từ cuộc gọi, tự xóa sau 30 ngày', async () => {
  const c = await ok('e1', 'POST', '/calls', { calleeId: ids.e2 });
  expect(c.limit_seconds).toBe(180);
  const poll = await ok('e2', 'GET', '/calls-poll');
  expect(poll.incoming.id).toBe(c.id);
  await ok('e1', 'POST', `/calls/${c.id}/signal`, { type: 'offer', payload: { sdp: 'v=0' } });
  const p2 = await ok('e2', 'GET', `/calls-poll?since=0`);
  expect(p2.signals.some((s: any) => s.type === 'offer' && s.call_id === c.id)).toBe(true);
  expect((await call('e1', 'POST', `/calls/${c.id}/answer`)).status).toBe(403);
  await ok('e2', 'POST', `/calls/${c.id}/answer`);
  // Quá 3 phút: máy chủ tự kết thúc ở lượt thăm dò kế tiếp
  await q(`UPDATE call_logs SET answered_at=now() - interval '200 seconds' WHERE id=$1`, [c.id]);
  await ok('e1', 'GET', '/calls-poll');
  const ended = await ok('e1', 'GET', `/calls/${c.id}`);
  expect(ended.status).toBe('ended');
  expect(ended.end_reason).toBe('limit');
  expect(ended.duration_seconds).toBe(180);
  // Ghi âm: chưa đồng ý mục đích -> 428
  const fd = () => { const f = new FormData(); f.append('file', new Blob([Buffer.from('OggS-test-audio')], { type: 'audio/webm' }), 'rec.webm'); return f; };
  const up = (who: string) => fetch(`${url}/calls/${c.id}/recording`, { method: 'POST', headers: { Authorization: `Bearer ${tok[who]}` }, body: fd() });
  expect((await up('e1')).status).toBe(428);
  await ok('e1', 'PATCH', '/me/privacy', { consents: { call_recording: true } });
  expect((await up('e1')).status).toBeLessThan(300);
  const log = await ok('e1', 'GET', '/calls');
  expect(log.find((x: any) => x.id === c.id).has_recording).toBe(true);
  // Khai báo công việc từ cuộc gọi: ghi âm sao sang bản khai
  const wr = await ok('e1', 'POST', '/work-records', { title: 'Trao đổi điều phối xe giao hàng', recordType: 'support', reasonNotInSystem: 'Việc phát sinh qua cuộc gọi', locationSource: 'unknown',
    startAt: new Date(Date.now() - 3600000).toISOString(), endAt: new Date(Date.now() - 3000000).toISOString(), callId: c.id });
  expect(wr.requester_member_id).toBe(ids.e2);
  expect(wr.files.some((f: any) => f.mime.startsWith('audio/'))).toBe(true);
  expect((await call('e1', 'POST', '/work-records', { title: 'Khai lại', recordType: 'support', reasonNotInSystem: 'Lặp lại cuộc gọi', locationSource: 'unknown',
    startAt: new Date(Date.now() - 3600000).toISOString(), endAt: new Date(Date.now() - 3000000).toISOString(), callId: c.id })).status).toBe(409);
  // Nhật ký > 30 ngày tự xóa; tệp đã sao sang bản khai được giữ
  await q(`UPDATE call_logs SET created_at=now() - interval '31 days' WHERE id=$1`, [c.id]);
  await q(`INSERT INTO direct_messages(company_id, sender_id, recipient_id, body, created_at) SELECT company_id, $1, $2, 'cũ', now() - interval '40 days' FROM company_members WHERE id=$1`, [ids.e1, ids.e2]);
  const r = await runCommsRetention();
  expect(r.calls).toBeGreaterThanOrEqual(1);
  expect(r.messages).toBeGreaterThanOrEqual(1);
  expect(await q1(`SELECT 1 FROM call_logs WHERE id=$1`, [c.id])).toBeFalsy();
  expect((await ok('e1', 'GET', `/work-records/${wr.id}`)).files.length).toBeGreaterThan(0);
});

test('Nhắn tin & cài đặt âm thanh/thông báo', async () => {
  await ok('e2', 'POST', '/messages', { to: ids.e1, body: 'Anh ơi em tới kho rồi' });
  expect((await ok('e1', 'GET', '/calls-poll')).unread_messages).toBeGreaterThan(0);
  const th = await ok('e1', 'GET', `/messages/with/${ids.e2}`);
  expect(th.items.at(-1).body).toBe('Anh ơi em tới kho rồi');
  const p = await ok('e1', 'PUT', '/me/prefs', { ringtone: false, ringVolume: 40, mute: { department: true }, quietHours: { enabled: true, start: '22:00', end: '06:00' } });
  expect(p.ringtone).toBe(false);
  expect(p.mute.department).toBe(true);
  expect(p.mute.tasks).toBe(false);
  expect(p.call_limit_seconds).toBe(180);
});

test('Yêu cầu hỗ trợ: thông báo nhóm, thành viên khác tiếp nhận, chỉ ghi nhận khi người yêu cầu xác nhận', async () => {
  const r = await ok('e1', 'POST', '/support-requests', { title: 'Cần hỗ trợ kiểm đếm 200 thùng', groupId: ids.g1 });
  expect(await q1(`SELECT 1 FROM notifications WHERE member_id=$1 AND reference_id=$2 AND type='support.requested'`, [ids.e2, r.id])).toBeTruthy();
  expect((await call('e1', 'POST', `/support-requests/${r.id}/accept`)).status).toBe(403);      // không tự tiếp nhận
  expect((await call('m2', 'POST', `/support-requests/${r.id}/accept`)).status).toBe(403);      // khác nhóm
  await ok('e2', 'POST', `/support-requests/${r.id}/accept`);
  await ok('e2', 'POST', `/support-requests/${r.id}/done`, { minutes: 40, note: 'Đếm xong 200 thùng' });
  const resp = (await ok('e1', 'GET', `/support-requests/${r.id}`)).responses[0];
  expect(await q1(`SELECT 1 FROM employee_work_records WHERE employee_id=$1 AND reason_not_in_system=$2`, [ids.e2, `Yêu cầu hỗ trợ ${r.code}`])).toBeFalsy();
  expect((await call('e2', 'POST', `/support-requests/${r.id}/responses/${resp.id}/decide`, { decision: 'confirm' })).status).toBe(403);
  await ok('e1', 'POST', `/support-requests/${r.id}/responses/${resp.id}/decide`, { decision: 'confirm', minutes: 35 });
  const wr = await q1(`SELECT * FROM employee_work_records WHERE employee_id=$1 AND reason_not_in_system=$2`, [ids.e2, `Yêu cầu hỗ trợ ${r.code}`]);
  expect(wr.status).toBe('accepted');
  expect(wr.accepted_minutes).toBe(35);
  const ov = await ok('e2', 'GET', '/work/overview');
  expect(ov.feed.some((x: any) => x.kind === 'support')).toBe(true);
  expect(ov.posts.length).toBeGreaterThan(0);
  expect(ov.department).toBeTruthy();
});

test('QR khu vực: kiểm tra, kết nối idempotent, chuyển khu vực, thu hồi, tenant, ghi nhận hộ, không quyền phát hành', async () => {
  const areas = await ok('admin', 'GET', '/work-areas');
  const kho = areas.find((a: any) => a.name === 'Kho nguyên liệu'); const pack = areas.find((a: any) => a.name === 'Khu đóng gói');
  expect((await call('e1', 'POST', `/work-areas/${kho.id}/qr-codes`, {})).status).toBe(403);
  const q1t = (await ok('admin', 'POST', `/work-areas/${kho.id}/qr-codes`, {})).token;
  const q2t = (await ok('admin', 'POST', `/work-areas/${pack.id}/qr-codes`, {})).token;
  expect(await q1(`SELECT 1 FROM area_qr_codes WHERE token_hash=$1`, [q1t])).toBeFalsy(); // chỉ lưu hash
  const v = await ok('e1', 'POST', '/area-qr/validate', { token: q1t });
  expect(v.area.name).toBe('Kho nguyên liệu');
  expect(await q1(`SELECT 1 FROM work_area_sessions WHERE employee_id=$1 AND status='ACTIVE'`, [ids.e1])).toBeFalsy(); // validate không tạo phiên
  const s1 = await ok('e1', 'POST', '/work-area-sessions/connect', { token: q1t });
  const again = await ok('e1', 'POST', '/work-area-sessions/connect', { token: q1t });
  expect(again.active.id).toBe(s1.active.id);
  const [a, b] = await Promise.all([call('e2', 'POST', '/work-area-sessions/connect', { token: q1t }), call('e2', 'POST', '/work-area-sessions/connect', { token: q1t })]);
  expect(a.status).toBeLessThan(300); expect(b.status).toBeLessThan(300);
  expect((await q1(`SELECT count(*)::int AS n FROM work_area_sessions WHERE employee_id=$1 AND work_area_id=$2`, [ids.e2, kho.id])).n).toBe(1);
  const tr = await call('e1', 'POST', '/work-area-sessions/connect', { token: q2t });
  expect(tr.status).toBe(409); expect(tr.body.error.code).toBe('TRANSFER_REQUIRED');
  const s2 = await ok('e1', 'POST', '/work-area-sessions/connect', { token: q2t, confirmTransfer: true });
  expect(s2.active.area_name).toBe('Khu đóng gói');
  expect(s2.today.length).toBeGreaterThanOrEqual(2);
  expect((await q1(`SELECT status FROM work_area_sessions WHERE id=$1`, [s1.active.id])).status).toBe('TRANSFERRED');
  // Bắt đầu phiên làm việc từ QR: vị trí điền sẵn theo khu vực
  const task = await q1(`SELECT t.id FROM tasks t JOIN task_assignees a ON a.task_id=t.id AND a.active WHERE a.company_member_id=$1 AND t.status IN ('not_started','in_progress') AND NOT t.is_standing AND NOT t.is_chain
                          AND NOT EXISTS (SELECT 1 FROM tasks c WHERE c.parent_id=t.id) AND NOT EXISTS (SELECT 1 FROM handover_contexts h WHERE h.to_task_id=t.id) LIMIT 1`, [ids.e1]);
  if (task) {
    await ok('e1', 'POST', '/sessions/start', { taskId: task.id, locationSource: 'qr', workAreaSessionId: s2.active.id });
    const ws = await q1(`SELECT location_source, work_location_id, work_area_session_id FROM work_sessions WHERE member_id=$1 AND ended_at IS NULL`, [ids.e1]);
    expect(ws.work_area_session_id).toBe(s2.active.id);
    expect(ws.location_source).toBe('qr');
  }
  // Thu hồi -> không tạo phiên
  const qrRow = (await ok('admin', 'GET', `/work-areas/${kho.id}`)).qr_codes.find((x: any) => x.status === 'active');
  await ok('admin', 'POST', `/area-qr/${qrRow.id}/revoke`, { reason: 'Tem bị rách' });
  expect((await call('e3', 'POST', '/work-area-sessions/connect', { token: q1t })).status).toBe(410);
  expect((await call('e3', 'POST', '/work-area-sessions/connect', { token: 'khong-ton-tai-123456789' })).status).toBe(404);
  // Ghi nhận hộ: có lý do, nguồn manager_entered; nhân viên thường không được
  expect((await call('e2', 'POST', '/work-area-sessions/manager-entry', { employeeId: ids.e1, areaId: kho.id, reason: 'Điện thoại hết pin' })).status).toBe(403);
  await ok('m1', 'POST', '/work-area-sessions/manager-entry', { employeeId: ids.e1, areaId: kho.id, reason: 'Điện thoại hết pin' });
  expect((await q1(`SELECT verification_source FROM work_area_sessions WHERE employee_id=$1 AND status='ACTIVE'`, [ids.e1])).verification_source).toBe('manager_entered');
  expect((await ok('admin', 'GET', `/work-areas/${kho.id}/history`)).some((e: any) => e.event_type === 'qr.revoked')).toBe(true);
  await expect(q(`DELETE FROM work_area_events`)).rejects.toThrow(/bất biến/);
});

test('QR bàn giao bên ngoài: xác nhận công khai idempotent, từ chối có lý do, chặn hoàn thành khi chưa xác nhận', async () => {
  const mk = async (title: string) => {
    const t = await ok('m2', 'POST', '/tasks', { title, description: 'Giao chứng từ cho đối tác', groupId: ids.g2, ownerMemberId: ids.e3, taskTypeId: typeId, complexity: 'simple', requirementLevel: 'normal',
      estimatedHours: 2, dueAt: new Date(Date.now() + 2 * 86400000).toISOString(), criteria: [{ direction: 'output', criterion: 'Đối tác xác nhận' }] });
    await ok('m2', 'POST', `/tasks/${t.id}/handover-details`, { recipientName: 'Phạm Thu Hà', recipientContact: 'ha@doitac.vn', contactType: 'email', description: '02 bộ hợp đồng gốc' });
    return t;
  };
  const t = await mk('Giao hợp đồng gốc cho đối tác An Phú');
  expect((await q1(`SELECT recipient_contact_encrypted FROM task_handover_details WHERE task_id=$1`, [t.id])).recipient_contact_encrypted).not.toContain('ha@doitac.vn');
  await ok('e3', 'POST', `/tasks/${t.id}/start`);
  expect((await call('e3', 'POST', `/tasks/${t.id}/submit`, { outputDescription: 'Đã giao xong' })).body.error.code).toBe('HANDOVER_REQUIRED');
  const qr = await ok('e3', 'POST', `/tasks/${t.id}/handover-qr`);
  expect(qr.path).toMatch(/^\/h\//);
  expect((await q1(`SELECT status, handover_status FROM tasks WHERE id=$1`, [t.id]))).toEqual({ status: 'awaiting_handover', handover_status: 'AWAITING_RECIPIENT' });
  const pub = await ok('', 'POST', '/external-handover/validate', { token: qr.token });
  expect(pub.state).toBe('ready');
  expect(pub.content).toBe('02 bộ hợp đồng gốc');
  expect(JSON.stringify(pub)).not.toMatch(/ha@doitac|owner_id|company_id|task_id/);
  expect((await call('', 'POST', '/external-handover/validate', { token: 'sai-token-1234567890' })).status).toBe(404);
  const [c1, c2] = await Promise.all([call('', 'POST', '/external-handover/confirm', { token: qr.token, displayName: 'Phạm Thu Hà' }), call('', 'POST', '/external-handover/confirm', { token: qr.token, displayName: 'Phạm Thu Hà' })]);
  expect(c1.status).toBeLessThan(300); expect(c2.status).toBeLessThan(300);
  expect((await q1(`SELECT count(*)::int AS n FROM task_handover_confirmations WHERE task_id=$1`, [t.id])).n).toBe(1);
  expect((await q1(`SELECT status, handover_status FROM tasks WHERE id=$1`, [t.id]))).toEqual({ status: 'completed', handover_status: 'CONFIRMED' });
  expect(await q1(`SELECT 1 FROM notifications WHERE member_id=$1 AND reference_id=$2 AND type='handover.confirmed'`, [ids.m2, t.id])).toBeTruthy();
  // Người nhận từ chối: bắt buộc lý do, nhiệm vụ quay lại xử lý; liên kết cũ không dùng lại được
  const t2 = await mk('Giao mẫu vải cho xưởng may');
  const qr2 = await ok('e3', 'POST', `/tasks/${t2.id}/handover-qr`);
  expect((await call('', 'POST', '/external-handover/reject', { token: qr2.token, displayName: 'Hà', reason: '' })).status).toBe(422);
  await ok('', 'POST', '/external-handover/reject', { token: qr2.token, displayName: 'Phạm Thu Hà', reason: 'Thiếu 1 mẫu màu xanh' });
  expect((await q1(`SELECT status, handover_status FROM tasks WHERE id=$1`, [t2.id]))).toEqual({ status: 'in_progress', handover_status: 'RECIPIENT_REJECTED' });
  expect((await ok('', 'POST', '/external-handover/validate', { token: qr2.token })).state).toBe('rejected');
  // Thu hồi / phát hành lại
  const qr3 = await ok('e3', 'POST', `/tasks/${t2.id}/handover-qr`);
  await ok('e3', 'POST', `/tasks/${t2.id}/handover-qr/revoke`);
  expect((await call('', 'POST', '/external-handover/confirm', { token: qr3.token, displayName: 'Hà' })).status).toBe(410);
  // Hủy nhiệm vụ rồi mở link: không cho xác nhận
  const qr4 = await ok('e3', 'POST', `/tasks/${t2.id}/handover-qr`);
  await ok('m2', 'POST', `/tasks/${t2.id}/cancel`, { reason: 'Đối tác hủy đơn hàng' });
  expect((await call('', 'POST', '/external-handover/confirm', { token: qr4.token, displayName: 'Hà' })).status).toBe(409);
  await expect(q(`UPDATE task_handover_confirmations SET reason='sửa'`)).rejects.toThrow(/bất biến/);
});

test('Bỏ qua QR: giải trình bắt buộc → treo chờ duyệt; nhân viên không tự duyệt; từ chối có lý do; giải trình lại tạo bản ghi mới; chấp nhận mới hoàn thành', async () => {
  const t = await ok('m2', 'POST', '/tasks', { title: 'Giao hóa đơn cho khách Bình An', description: 'Giao hóa đơn VAT bản gốc', groupId: ids.g2, ownerMemberId: ids.e3, taskTypeId: typeId,
    complexity: 'simple', requirementLevel: 'normal', estimatedHours: 1, dueAt: new Date(Date.now() + 86400000).toISOString(), criteria: [{ direction: 'output', criterion: 'Khách nhận hóa đơn' }] });
  await ok('m2', 'POST', `/tasks/${t.id}/handover-details`, { recipientName: 'Lê Bình An', description: '01 hóa đơn VAT bản gốc' });
  await ok('e3', 'POST', `/tasks/${t.id}/handover-qr`);
  expect((await call('e3', 'POST', `/tasks/${t.id}/handover-exceptions`, { reason: '' })).status).toBe(422);
  const ex1 = await ok('e3', 'POST', `/tasks/${t.id}/handover-exceptions`, { reason: 'Khách không có điện thoại thông minh, đã ký biên bản giấy', cause: 'no_device' });
  expect((await q1(`SELECT status, handover_status FROM tasks WHERE id=$1`, [t.id]))).toEqual({ status: 'pending_exception_review', handover_status: 'EXCEPTION_PENDING' });
  expect((await call('e3', 'POST', `/handover-exceptions/${ex1.id}/review`, { decision: 'APPROVED' })).status).toBe(403);
  expect((await call('e1', 'POST', `/handover-exceptions/${ex1.id}/review`, { decision: 'APPROVED' })).status).toBe(403);
  expect((await call('m2', 'POST', `/handover-exceptions/${ex1.id}/review`, { decision: 'REJECTED' })).status).toBe(422);
  expect((await ok('m2', 'GET', '/handover-exceptions')).some((x: any) => x.id === ex1.id)).toBe(true);
  await ok('m2', 'POST', `/handover-exceptions/${ex1.id}/review`, { decision: 'REJECTED', reason: 'Cần ảnh chụp biên bản có chữ ký khách' });
  expect((await q1(`SELECT status, handover_status FROM tasks WHERE id=$1`, [t.id]))).toEqual({ status: 'in_progress', handover_status: 'EXCEPTION_REJECTED' });
  const ex2 = await ok('e3', 'POST', `/tasks/${t.id}/handover-exceptions`, { reason: 'Đã bổ sung ảnh biên bản có chữ ký khách Bình An', cause: 'no_device' });
  expect(ex2.id).not.toBe(ex1.id);
  const h = await ok('m2', 'POST', `/handover-exceptions/${ex2.id}/review`, { decision: 'APPROVED', reason: 'Biên bản hợp lệ' });
  expect(h.task.status).toBe('completed');
  expect(h.task.handover_status).toBe('EXCEPTION_APPROVED');
  expect(h.exceptions.length).toBe(2);
  expect(h.exceptions[0].decision).toBe('REJECTED');
  expect((await call('m2', 'POST', `/handover-exceptions/${ex2.id}/review`, { decision: 'APPROVED' })).status).toBe(409);
});
