/* Kiểm thử v7: tăng ca ngoại lệ, giai đoạn con, đơn hàng có sẵn, tự động bắt đầu, mã nhiệm vụ, bàn giao có tài liệu, quyền người giao/người làm, nhiệm vụ thường trực. */
process.env.DATABASE_URL = process.env.TEST_DATABASE_URL || 'postgresql://app:app@localhost:5432/teamapp_test';
process.env.DISABLE_SCHEDULER = 'true';
process.env.UPLOAD_DIR = '/tmp/teamapp-test-uploads';

import { INestApplication } from '@nestjs/common';
import { closePool, q, q1 } from '../src/db/db';
import { createApp } from '../src/main';
import { resetDb, seed } from '../src/db/seed';
import { runScheduledStarts } from '../src/modules/operations.controller';

let app: INestApplication;
let url = '';
const tok: Record<string, string> = {};
const ids: Record<string, string> = {};
async function call(who: string, method: string, path: string, body?: any) {
  const r = await fetch(url + path, { method, headers: { 'Content-Type': 'application/json', ...(tok[who] ? { Authorization: `Bearer ${tok[who]}` } : {}) }, body: body ? JSON.stringify(body) : undefined });
  return { status: r.status, body: (await r.json().catch(() => ({}))) as any };
}
async function ok(who: string, method: string, path: string, body?: any) {
  const r = await call(who, method, path, body);
  if (r.status >= 300) throw new Error(`${method} ${path} -> ${r.status} ${JSON.stringify(r.body)}`);
  return r.body;
}
const PH: Record<string, string> = { admin: '0901000002', m1: '0901000003', m2: '0901000004', e1: '0901000007', e2: '0901000008', e3: '0901000009', e4: '0901000010' };
let typeId = '';
const base = (extra: any = {}) => ({ description: 'Mô tả công việc thử nghiệm', taskTypeId: typeId, complexity: 'simple', requirementLevel: 'normal', estimatedHours: 2,
  dueAt: new Date(Date.now() + 5 * 86400000).toISOString(), criteria: [{ direction: 'output', criterion: 'Hoàn thành' }], ...extra });

beforeAll(async () => {
  await resetDb();
  app = await createApp();
  await app.listen(0);
  url = `http://127.0.0.1:${(app.getHttpServer().address() as any).port}/api/v1`;
  await seed(url);
  for (const [k, p] of Object.entries(PH)) {
    tok[k] = (await ok('', 'POST', '/auth/login', { phone: p, password: 'Demo@123' })).access_token;
    ids[k] = (await q1(`SELECT cm.id FROM company_members cm JOIN users u ON u.id=cm.user_id WHERE u.phone=$1`, [p])).id;
  }
  ids.g1 = (await q1(`SELECT id FROM groups WHERE name='Nhóm Vận hành'`)).id;
  ids.g3 = (await q1(`SELECT id FROM groups WHERE name='Tổ Đóng gói'`)).id;
  typeId = (await q1(`SELECT task_type_id FROM tasks WHERE title='Đóng gói 2.000 túi 1kg'`)).task_type_id;
});
afterAll(async () => { await app.close(); await closePool(); });

test('1. Tăng ca ngoại lệ (máy chấm công hỏng / ngoài xưởng): người yêu cầu phải cao hơn; có hiệu lực ngay', async () => {
  const t0 = new Date(Date.now() - 5 * 3600000).toISOString(); const t1 = new Date(Date.now() - 3 * 3600000).toISOString();
  expect((await call('e1', 'POST', '/overtime-records/exception', { memberIds: [ids.e2], kind: 'timeclock_down', startAt: t0, endAt: t1, cause: 'Máy chấm công hỏng' })).status).toBe(403);
  expect((await call('m1', 'POST', '/overtime-records/exception', { memberIds: [ids.e2], kind: 'offsite', startAt: t0, endAt: t1, cause: 'Làm tại xưởng' })).status).toBe(422);
  const r = await ok('e3', 'POST', '/overtime-records/exception', { memberIds: [ids.e4], kind: 'timeclock_down', startAt: t0, endAt: t1, workMinutes: 480, cause: 'Máy chấm công tổ đóng gói hỏng' });
  const o = await q1(`SELECT * FROM overtime_records WHERE id=$1`, [r.ids[0]]);
  expect(o.approval_status).toBe('confirmed');
  expect(o.requested_by_member_id).toBe(ids.e3);
  expect(o.work_minutes).toBe(480);
  const sum = await ok('e4', 'GET', `/time/summary?memberId=${ids.e4}`);
  expect(sum.members[0].overtime).toBeGreaterThanOrEqual(120);
});

test('2. Chia giai đoạn con: không chọn được giai đoạn đã hoàn thành', async () => {
  const root = await q1(`SELECT id FROM tasks WHERE title='Nhập lô hàng nước giải khát tháng 11'`);
  expect((await call('m1', 'POST', '/tasks', { parentId: root.id, title: 'Bổ sung đặt hàng', groupId: ids.g1, ownerMemberId: ids.e1, stageNo: 1 })).status).toBe(422);
  const ok2 = await ok('m1', 'POST', '/tasks', { parentId: root.id, title: 'Đối chiếu chứng từ', groupId: ids.g1, ownerMemberId: ids.e1, stageNo: 2 });
  expect(ok2.code).toMatch(/^NV-\d{5}\.\d+$/); // phần việc con mang mã nhiệm vụ cha + ".n"
});

test('3+7. Đơn hàng: mã tự chọn, không trùng; thêm nhiệm vụ con vào đơn có sẵn; hiển thị DH-xxx_NV-xxx', async () => {
  const o = await ok('m1', 'POST', '/tasks', base({ title: 'Đơn PO-778', groupId: ids.g1, ownerMemberId: ids.m1, isChain: true, chainCode: 'PO-778' }));
  expect(o.chain_code).toBe('PO-778');
  expect((await call('m1', 'POST', '/tasks', base({ title: 'Trùng mã', groupId: ids.g1, ownerMemberId: ids.m1, isChain: true, chainCode: 'PO-778' }))).status).toBe(409);
  const child = await ok('m1', 'POST', '/tasks', { parentId: o.id, title: 'Nhập hàng', groupId: ids.g1, ownerMemberId: ids.e1, stageNo: 1 });
  expect(child.code).toMatch(/^NV-\d{5}$/); // công đoạn của đơn hàng có mã NV riêng
  expect(child.root_chain_code).toBe('PO-778');
});

test('5. Tự động bắt đầu khi nhận bàn giao (phiên chuyển theo nếu đang làm công đoạn trước) và theo lịch đặt trước', async () => {
  const o = await ok('m1', 'POST', '/tasks', base({ title: 'Đơn tự động', groupId: ids.g1, ownerMemberId: ids.m1, isChain: true }));
  const a = await ok('m1', 'POST', '/tasks', { parentId: o.id, title: 'Soạn hàng', groupId: ids.g1, ownerMemberId: ids.e1, stageNo: 1 });
  const b = await ok('m1', 'POST', '/tasks', { parentId: o.id, title: 'Kiểm & đóng thùng', groupId: ids.g1, ownerMemberId: ids.e1, stageNo: 2, autoStart: 'on_handover' });
  await ok('admin', 'POST', `/chains/${o.id}/order`, { action: 'approve' }); // đơn hàng phải được duyệt mới phát hành công đoạn
  await ok('e1', 'POST', '/sessions/start', { taskId: a.id });
  await ok('e1', 'POST', `/tasks/${a.id}/submit`, { outputDescription: 'Đã soạn đủ 30 thùng', links: ['https://drive.example.com/phieu-soan-30.pdf'] });
  await ok('e1', 'POST', '/sessions/start', { taskId: a.id }).catch(() => null); // phiên đã đóng khi bàn giao; mở lại để kiểm tra chuyển phiên
  await ok('m1', 'POST', `/tasks/${a.id}/review`, { decision: 'approve', scores: { output: 90, quality: 90, schedule: 90, process: 90 } });
  const ho = await q1(`SELECT * FROM handover_contexts WHERE to_task_id=$1`, [b.id]);
  expect(ho.method).toBe('leader_confirmation');
  expect(ho.links).toEqual(['https://drive.example.com/phieu-soan-30.pdf']);
  expect((await q1(`SELECT status FROM tasks WHERE id=$1`, [b.id])).status).toBe('not_started');
  await ok('e1', 'POST', `/handovers/${ho.id}/decide`, { decision: 'accept' });
  const bt = await q1(`SELECT status, auto_started_at FROM tasks WHERE id=$1`, [b.id]);
  expect(bt.status).toBe('in_progress');
  expect(bt.auto_started_at).toBeTruthy();
  await ok('e1', 'POST', '/sessions/end', {});
  // theo lịch
  const s = await ok('m1', 'POST', '/tasks', base({ title: 'Kiểm kê đầu ca', groupId: ids.g1, ownerMemberId: ids.e2, autoStart: 'scheduled', scheduledStartAt: new Date(Date.now() - 60000).toISOString() }));
  expect((await call('m1', 'POST', '/tasks', base({ title: 'Thiếu giờ', groupId: ids.g1, ownerMemberId: ids.e2, autoStart: 'scheduled' }))).status).toBe(422);
  expect(await runScheduledStarts((await q1(`SELECT company_id FROM tasks WHERE id=$1`, [s.id])).company_id)).toBeGreaterThan(0);
  expect((await q1(`SELECT status FROM tasks WHERE id=$1`, [s.id])).status).toBe('in_progress');
});

test('8. Chỉ người được giao mới ghi sản lượng/gửi bàn giao; tăng ca trong sản lượng chỉ trưởng nhóm; người giao chỉnh ưu tiên/ghim', async () => {
  const pack = await q1(`SELECT id FROM tasks WHERE title='Đóng gói 2.000 túi 1kg'`);
  // m1 là người giao việc, không thực hiện
  expect((await call('m1', 'POST', '/production', { taskId: pack.id, actualQty: 10, acceptedQty: 10 })).status).toBe(403);
  expect((await call('m1', 'POST', '/handovers', { fromTaskId: pack.id, toGroupId: ids.g1, content: 'Bàn giao thử nghiệm' })).status).toBe(403);
  const p = await ok('e3', 'POST', '/production', { taskId: pack.id, actualQty: 200, acceptedQty: 190, rejectedQty: 10,
    participantTimes: [{ memberId: ids.e3, workMinutes: 60, otMinutes: 30 }, { memberId: ids.e4, workMinutes: 60, otMinutes: 0 }] });
  expect(Number(p.execution_minutes)).toBe(150);
  expect(Number(p.overtime_minutes)).toBe(30);
  expect(await q1(`SELECT 1 FROM overtime_records WHERE production_record_id=$1 AND member_id=$2 AND approval_status='confirmed'`, [p.id, ids.e3])).toBeTruthy();
  // nhân viên (không phải trưởng nhóm) tự ghi sản lượng việc của mình: được, nhưng không được ghi tăng ca
  const own = await ok('m1', 'POST', '/tasks', base({ title: 'Dán nhãn lô B', groupId: ids.g1, ownerMemberId: ids.e2 }));
  expect((await call('e2', 'POST', '/production', { taskId: own.id, actualQty: 50, acceptedQty: 50, participantTimes: [{ memberId: ids.e2, workMinutes: 30, otMinutes: 20 }] })).status).toBe(403);
  await ok('e2', 'POST', '/production', { taskId: own.id, actualQty: 50, acceptedQty: 50, participantTimes: [{ memberId: ids.e2, workMinutes: 30, otMinutes: 0 }] });
  // bàn giao có phương thức + đường link tài liệu
  const h = await ok('e2', 'POST', '/handovers', { fromTaskId: own.id, toGroupId: ids.g3, content: 'Bàn giao báo cáo dán nhãn', method: 'document_check', links: ['https://docs.example.com/bao-cao-lo-b'] });
  expect(h.method).toBe('document_check');
  expect(h.links).toHaveLength(1);
  // người giao việc: ưu tiên + ghim
  await ok('m1', 'POST', `/tasks/${own.id}/priority`, { priority: 'urgent', pinned: true, reason: 'Khách cần gấp trong ngày' });
  const t = await q1(`SELECT pinned, priority FROM tasks WHERE id=$1`, [own.id]);
  expect(t.pinned).toBe(true);
  const d = await ok('m1', 'GET', `/tasks/${own.id}`);
  expect(d.ops_permissions.can_record_production).toBe(false);
  expect(d.ops_permissions.can_set_priority).toBe(true);
});

test('10. Nhiệm vụ thường trực: thành viên nhóm chọn khi bắt đầu phiên (kèm công đoạn), không lẫn vào danh sách việc/điểm', async () => {
  const opt = await ok('e2', 'GET', '/sessions/options');
  const st = opt.standing.find((x: any) => x.title === 'Trực kho ca ngày');
  expect(st.stages.length).toBe(3);
  expect(st.stages[0].code).toMatch(/\.\d+$/);
  const s = await ok('e2', 'POST', '/sessions/start', { taskId: st.stages[1].id });
  expect(s.active.task_id).toBe(st.stages[1].id);
  await ok('e2', 'POST', '/sessions/end', {});
  expect((await call('e4', 'POST', '/sessions/start', { taskId: st.stages[1].id })).status).toBe(404); // không thuộc nhóm
  const list = await ok('m1', 'GET', '/tasks?limit=200');
  expect(list.items.some((t: any) => t.title === 'Trực kho ca ngày')).toBe(false);
  const sl = await ok('m1', 'GET', '/tasks?standing=true');
  expect(sl.items.some((t: any) => t.title === 'Trực kho ca ngày')).toBe(true);
});
