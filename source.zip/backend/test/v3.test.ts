/* Kiểm thử v3: quyết định nhân sự & bàn giao, mẫu việc, giấy phép, quy trình & sơ đồ tổ chức. */
process.env.DATABASE_URL = process.env.TEST_DATABASE_URL || 'postgresql://app:app@localhost:5432/teamapp_test';
process.env.DISABLE_SCHEDULER = 'true';
process.env.UPLOAD_DIR = '/tmp/teamapp-test-uploads';

import { INestApplication } from '@nestjs/common';
import { closePool, q, q1 } from '../src/db/db';
import { createApp } from '../src/main';
import { resetDb, seed } from '../src/db/seed';
import { sendProcedureTips } from '../src/modules/hr.controller';

let app: INestApplication;
let url = '';
const tok: Record<string, string> = {};
const ids: Record<string, string> = {};
async function call(who: string, method: string, path: string, body?: any) {
  const r = await fetch(url + path, { method, headers: { 'Content-Type': 'application/json', ...(tok[who] ? { Authorization: `Bearer ${tok[who]}` } : {}) }, body: body ? JSON.stringify(body) : undefined });
  return { status: r.status, body: (await r.json().catch(() => ({}))) as any };
}
async function ok(who: string, method: string, path: string, body?: any) {
  const r = await call(who, method, path, body);
  if (r.status >= 300) throw new Error(`${method} ${path} -> ${r.status} ${JSON.stringify(r.body)}`);
  return r.body;
}
const PH: Record<string, string> = { owner: '0901000001', m1: '0901000003', m2: '0901000004', e1: '0901000007', e2: '0901000008', e3: '0901000009', e4: '0901000010', hr: '0901000012', bv: '0901000013', kho: '0901000014' };

beforeAll(async () => {
  await resetDb();
  app = await createApp();
  await app.listen(0);
  url = `http://127.0.0.1:${(app.getHttpServer().address() as any).port}/api/v1`;
  await seed(url);
  for (const [k, p] of Object.entries(PH)) {
    tok[k] = (await ok('', 'POST', '/auth/login', { phone: p, password: 'Demo@123' })).access_token;
    ids[k] = (await q1(`SELECT cm.id FROM company_members cm JOIN users u ON u.id=cm.user_id WHERE u.phone=$1`, [p])).id;
  }
  ids.g1 = (await q1(`SELECT id FROM groups WHERE name='Nhóm Vận hành'`)).id;
  ids.g2 = (await q1(`SELECT id FROM groups WHERE name='Nhóm Kinh doanh'`)).id;
  ids.tt = (await q1(`SELECT id FROM task_types WHERE name='Vận hành'`)).id;
});
afterAll(async () => { await app.close(); await closePool(); });

const newTask = (owner: string, extra: any = {}) => call('m1', 'POST', '/tasks', {
  title: 'Việc kiểm thử v3', description: 'Mô tả phạm vi kiểm thử', groupId: ids.g1, ownerMemberId: owner, taskTypeId: ids.tt,
  complexity: 'simple', requirementLevel: 'normal', estimatedHours: 2, dueAt: new Date(Date.now() + 86400000).toISOString(),
  criteria: [{ direction: 'output', criterion: 'Đạt tiêu chí' }], ...extra,
});

describe('Quyết định nhân sự & bàn giao', () => {
  test('Thôi việc: đang bàn giao thì không nhận việc mới; bàn giao xong + quản lý xác nhận mới hiệu lực', async () => {
    expect((await call('m1', 'POST', '/decisions', { memberId: ids.e3, decisionType: 'termination', effectiveDate: '2026-12-01', handoverDeadline: new Date(Date.now() + 86400000).toISOString(), reason: 'Nghỉ việc theo nguyện vọng cá nhân' })).status).toBe(403);
    const d = await ok('hr', 'POST', '/decisions', {
      memberId: ids.e3, decisionType: 'termination', effectiveDate: '2026-12-01', handoverDeadline: new Date(Date.now() + 86400000).toISOString(),
      handoverReceiverId: ids.e1, reason: 'Nghỉ việc theo nguyện vọng cá nhân',
    });
    expect(d.code).toMatch(/^QD-/);
    expect(d.confirmer_id).toBe(ids.m1); // cấp trên trực tiếp
    expect(d.pdf_file_id).toBeTruthy();
    const owned = d.open_tasks.filter((t: any) => t.assignment_type === 'owner');
    expect(owned.length).toBeGreaterThan(0);
    // không giao việc mới
    const blocked = await newTask(ids.e3);
    expect(blocked.status).toBe(409);
    expect(blocked.body.error.code).toBe('MEMBER_IN_HANDOVER');
    const mine = await ok('e3', 'GET', '/dashboard');
    expect(mine.me.decision.code).toBe(d.code);
    // nhân viên gửi bàn giao; quản lý trả lại; gửi lại; xác nhận
    expect((await call('m1', 'POST', `/decisions/${d.id}/handover`, { note: 'Bàn giao toàn bộ tài liệu' })).status).toBe(403);
    const pick = (t: any) => d.receiver_candidates.find((c: any) => c.group_id === t.group_id && c.id !== ids.e3).id;
    const bad = await call('e3', 'POST', `/decisions/${d.id}/handover`, { note: 'Bàn giao sai người nhận', plan: owned.map((t: any) => ({ taskId: t.id, receiverId: ids.owner })) });
    expect(bad.status).toBe(422);
    await ok('e3', 'POST', `/decisions/${d.id}/handover`, { note: 'Bàn giao sổ sách, chìa khóa tủ hồ sơ số 3', plan: owned.map((t: any) => ({ taskId: t.id, receiverId: pick(t) })) });
    expect((await call('e3', 'POST', `/decisions/${d.id}/confirm`, { decision: 'confirm' })).status).toBe(403);
    await ok('m1', 'POST', `/decisions/${d.id}/confirm`, { decision: 'return', note: 'Bổ sung mật khẩu máy in' });
    await ok('e3', 'POST', `/decisions/${d.id}/handover`, { note: 'Đã bổ sung mật khẩu máy in, sổ sách, chìa khóa', plan: owned.map((t: any) => ({ taskId: t.id, receiverId: pick(t) })) });
    const done = await ok('m1', 'POST', `/decisions/${d.id}/confirm`, { decision: 'confirm' });
    expect(done.status).toBe('completed');
    for (const t of owned) {
      const o = await q1(`SELECT company_member_id FROM task_assignees WHERE task_id=$1 AND active AND assignment_type='owner'`, [t.id]);
      expect(o.company_member_id).toBe(pick(t));
    }
    const m = await q1(`SELECT status FROM company_members WHERE id=$1`, [ids.e3]);
    expect(m.status).toBe('inactive');
    expect((await call('e3', 'GET', '/dashboard')).status).toBe(401);
  });

  test('Điều chuyển (seed): nhân viên chuyển nhóm sau khi bàn giao được xác nhận', async () => {
    const list = await ok('e4', 'GET', '/decisions?scope=mine');
    const d = await ok('e4', 'GET', `/decisions/${list[0].id}`);
    expect(d.decision_type).toBe('transfer');
    await ok('e4', 'POST', `/decisions/${d.id}/handover`, { note: 'Bàn giao danh sách khách hàng và báo giá đang dở', plan: [] });
    const done = await ok('m2', 'POST', `/decisions/${d.id}/confirm`, { decision: 'confirm' });
    expect(done.status).toBe('completed');
    const gm = await q(`SELECT group_id FROM group_members WHERE company_member_id=$1`, [ids.e4]);
    expect(gm.map((x) => x.group_id)).toEqual([ids.g1]);
    expect((await q1(`SELECT supervisor_member_id FROM company_members WHERE id=$1`, [ids.e4])).supervisor_member_id).toBe(ids.m1);
    expect((await newTask(ids.e4)).status).toBe(201);
  });

  test('Thăng chức: đổi vai trò khi xác nhận', async () => {
    const d = await ok('owner', 'POST', '/decisions', { memberId: ids.e1, decisionType: 'promotion', effectiveDate: '2026-12-01', handoverDeadline: new Date(Date.now() + 86400000).toISOString(),
      newRole: 'manager', newTitle: 'Tổ trưởng kho', handoverReceiverId: ids.e2, reason: 'Hoàn thành xuất sắc nhiệm vụ năm 2026' });
    const det = await ok('e1', 'GET', `/decisions/${d.id}`);
    await ok('e1', 'POST', `/decisions/${d.id}/handover`, { note: 'Bàn giao các việc đang làm cho Hùng', plan: det.open_tasks.filter((t: any) => t.assignment_type === 'owner').map((t: any) => ({ taskId: t.id, receiverId: ids.e2 })) });
    await ok('m1', 'POST', `/decisions/${d.id}/confirm`, { decision: 'confirm' });
    const m = await q1(`SELECT role, title FROM company_members WHERE id=$1`, [ids.e1]);
    expect(m.role).toBe('manager');
    expect(m.title).toBe('Tổ trưởng kho');
  });
});

describe('Mẫu giao việc', () => {
  test('Thư viện mẫu mặc định có trường khai báo và giấy phép gợi ý', async () => {
    const t = await ok('m1', 'GET', '/company/task-templates');
    const names = t.map((x: any) => x.name);
    for (const n of ['Nhập kho hàng hóa', 'Xử lý nguyên liệu', 'Giao hàng cho khách', 'Giải quyết hàng tồn', 'Bảo vệ ca trực', 'Giải quyết khiếu nại khách hàng', 'Thụ lý hàng lỗi']) expect(names).toContain(n);
    const gh = t.find((x: any) => x.system_key === 'giao_hang');
    expect(gh.fields.length).toBeGreaterThan(3);
    expect(gh.permit_keys).toEqual(expect.arrayContaining(['gate_pass', 'vehicle_use']));
  });
});

describe('Giấy phép', () => {
  test('Seed: giấy ra cổng khai báo cấp tự động; giấy dùng xe chờ duyệt; bộ phận xem được thông tin việc', async () => {
    const list = await ok('e2', 'GET', '/permits?scope=mine');
    const gate = list.find((p: any) => p.type_key === 'gate_pass');
    const car = list.find((p: any) => p.type_key === 'vehicle_use');
    expect(gate.status).toBe('auto_issued');
    expect(car.status).toBe('pending');
    // Bảo vệ thấy giấy cần hậu kiểm và xem được công việc liên quan
    const bvList = await ok('bv', 'GET', '/permits?scope=handling&review=pending');
    expect(bvList.some((p: any) => p.id === gate.id)).toBe(true);
    const task = await ok('bv', 'GET', `/tasks/${gate.task_id}`);
    expect(task.title).toBe('Giao hàng cho khách Hòa Bình');
    expect((await call('kho', 'GET', `/permits/${gate.id}`)).status).toBe(404);
    // Ghi nhận ra/vào và hậu kiểm vi phạm -> người giao việc chịu trách nhiệm
    await ok('bv', 'POST', `/permits/${gate.id}/track`, { event: 'out' });
    const back = await ok('bv', 'POST', `/permits/${gate.id}/track`, { event: 'in' });
    expect(back.status).toBe('closed');
    expect((await call('bv', 'POST', `/permits/${gate.id}/review`, { result: 'violation', note: 'ngắn' })).status).toBe(422);
    const rv = await ok('bv', 'POST', `/permits/${gate.id}/review`, { result: 'violation', note: 'Xe ra cổng không có phiếu xuất hàng kèm theo' });
    expect(rv.review_status).toBe('violation');
    const n = await ok('m1', 'GET', '/notifications');
    expect(n.items.some((i: any) => i.type === 'permit.violation' && i.reference_id === gate.id)).toBe(true);
    // Giấy dùng xe: bộ phận Hành chính (Admin là trưởng bộ phận) duyệt
    expect((await call('bv', 'POST', `/permits/${car.id}/decide`, { decision: 'approve' })).status).toBe(404);
  });

  test('Nhân viên không tự xin giấy phép; người lập phải quản lý việc; người được cấp phải là người làm', async () => {
    const t = await q1(`SELECT t.id FROM tasks t JOIN task_assignees ta ON ta.task_id=t.id AND ta.active AND ta.company_member_id=$1 WHERE t.group_id=$2 AND t.status IN ('not_started','in_progress') LIMIT 1`, [ids.e2, ids.g1]);
    const base = { typeKey: 'equipment_use', taskId: t.id, data: { thiet_bi: 'Xe nâng XN-02' }, validFrom: new Date().toISOString(), validTo: new Date(Date.now() + 4 * 3600000).toISOString() };
    expect((await call('e2', 'POST', '/permits', { ...base, holderId: ids.e2 })).status).toBe(403);
    expect((await call('m2', 'POST', '/permits', { ...base, holderId: ids.e2 })).status).toBe(403);
    expect((await call('m1', 'POST', '/permits', { ...base, holderId: ids.m2 })).status).toBe(422);
    expect((await call('m1', 'POST', '/permits', { ...base, data: {}, holderId: ids.e2 })).status).toBe(422);
    const p = await ok('m1', 'POST', '/permits', { ...base, holderId: ids.e2 });
    expect(p.status).toBe('pending');
    expect(p.department_name).toBe('Kho vận');
    const a = await ok('kho', 'POST', `/permits/${p.id}/decide`, { decision: 'approve' });
    expect(a.status).toBe('approved');
    const td = await ok('e2', 'GET', `/tasks/${t.id}`);
    expect(td.permits.some((x: any) => x.id === p.id)).toBe(true);
  });
});

describe('Quy trình & hệ thống nhân sự', () => {
  test('Thư viện quy trình: bản chuẩn hóa + bản tham khảo; quy trình bộ phận Bảo vệ', async () => {
    const r = await ok('bv', 'GET', '/hr/procedures');
    const titles = r.items.filter((p: any) => r.mine.includes(p.id)).map((p: any) => p.system_key);
    expect(titles).toContain('cap_phep_cong');
    const m = await ok('m1', 'GET', '/hr/procedures');
    const keys = m.items.map((p: any) => p.system_key);
    expect(keys).toEqual(expect.arrayContaining(['giao_viec_chuan', 'giao_viec_tham_khao']));
  });

  test('Tin vắn quy trình gửi theo bộ phận, không gửi trùng trong ngày', async () => {
    const cid = (await q1(`SELECT company_id FROM company_members WHERE id=$1`, [ids.bv])).company_id;
    // Thứ Hai 16/11/2026 lúc 9:00 giờ VN
    const mon = new Date('2026-11-16T02:00:00Z');
    const n1 = await sendProcedureTips(cid, mon);
    const n2 = await sendProcedureTips(cid, mon);
    expect(n1).toBeGreaterThan(0);
    expect(n2).toBe(0);
    const tip = await q1(`SELECT title FROM notifications WHERE member_id=$1 AND type='procedure.tip'`, [ids.bv]);
    expect(tip.title).toMatch(/📘/);
    expect(await sendProcedureTips(cid, new Date('2026-11-16T00:30:00Z'))).toBe(0); // trước 8:30
  });

  test('Sơ đồ tổ chức trả về cây cấp trên – cấp dưới', async () => {
    const o = await ok('e2', 'GET', '/hr/org-chart');
    const m1 = o.members.find((x: any) => x.id === ids.m1);
    expect(o.members.some((x: any) => x.supervisor_member_id === ids.m1)).toBe(true);
    expect(m1.open_tasks).toBeGreaterThanOrEqual(0);
    expect(o.departments.some((d: any) => d.name === 'Bảo vệ - An ninh')).toBe(true);
  });
});
