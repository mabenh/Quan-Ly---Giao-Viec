/* Kiểm thử v13: nhóm liên lạc (nhắn tin nhóm, gọi nhóm, quyền hạn nhóm); gia nhập công ty thứ 2 bằng mã; mở doanh nghiệp thứ 2; nhật ký lỗi kết nối. */
process.env.DATABASE_URL = process.env.TEST_DATABASE_URL || 'postgresql://app:app@localhost:5432/teamapp_test';
process.env.DISABLE_SCHEDULER = 'true';
process.env.UPLOAD_DIR = '/tmp/teamapp-test-uploads';

import { INestApplication } from '@nestjs/common';
import { closePool, q, q1 } from '../src/db/db';
import { createApp } from '../src/main';
import { resetDb, seed } from '../src/db/seed';

let app: INestApplication;
let url = '';
const tok: Record<string, string> = {};
let companyId = '';
const mid: Record<string, string> = {};
async function call(who: string, method: string, path: string, body?: any) {
  const r = await fetch(url + path, { method, headers: { 'Content-Type': 'application/json', ...(tok[who] ? { Authorization: `Bearer ${tok[who]}` } : {}) }, body: body ? JSON.stringify(body) : undefined });
  return { status: r.status, body: (await r.json().catch(() => ({}))) as any };
}
async function ok(who: string, method: string, path: string, body?: any) {
  const r = await call(who, method, path, body);
  if (r.status >= 300) throw new Error(`${method} ${path} -> ${r.status} ${JSON.stringify(r.body)}`);
  return r.body;
}

beforeAll(async () => {
  await resetDb();
  app = await createApp();
  await app.listen(0);
  url = `http://127.0.0.1:${(app.getHttpServer().address() as any).port}/api/v1`;
  const s = await seed(url);
  companyId = s.companyId;
  for (const [k, p] of Object.entries({ owner: '0901000001', admin: '0901000002', m1: '0901000003', m2: '0901000004', e1: '0901000007', e2: '0901000008', e3: '0901000009', e4: '0901000010', hr: '0901000012' })) { const r = await ok('', 'POST', '/auth/login', { phone: p, password: 'Demo@123' }); tok[k] = r.access_token; mid[k] = (await ok(k, 'GET', '/auth/me')).member_id; }
});
afterAll(async () => { await app.close(); await closePool(); });


test('Lập nhóm liên lạc: chỉ trưởng nhóm/trưởng phòng; thành viên trong phạm vi phụ trách', async () => {
  expect((await call('e1', 'POST', '/rooms', { name: 'Nhóm thử', memberIds: [mid.e2] })).status).toBe(403);   // tầng 7
  expect((await call('m2', 'POST', '/rooms', { name: 'KD + ngoài', memberIds: [mid.e1] })).status).toBe(403); // e1 không thuộc phòng KD
  const r = await ok('m2', 'POST', '/rooms', { name: 'Kinh doanh nhanh', memberIds: [mid.e4, mid.e3], settings: { who_can_post: 'all', call_limit_minutes: 5 } });
  expect(r.my_role).toBe('owner'); expect(r.members).toHaveLength(3); expect(r.settings.call_limit_minutes).toBe(5);
  const l = await ok('e4', 'GET', '/rooms');
  expect(l.rooms.map((x: any) => x.name)).toContain('Kinh doanh nhanh'); expect(l.can_create).toBe(false);
  expect((await call('e1', 'GET', `/rooms/${r.id}`)).status).toBe(404);   // không phải thành viên
});

test('Nhắn tin nhóm, chưa đọc, quyền nhắn tin theo thiết lập', async () => {
  const r = (await ok('m2', 'GET', '/rooms')).rooms.find((x: any) => x.name === 'Kinh doanh nhanh');
  await ok('e4', 'POST', `/rooms/${r.id}/messages`, { body: 'Đơn hàng ABC đã giao' });
  expect((await ok('e3', 'GET', '/calls-poll')).unread_room_messages).toBe(1);
  expect((await ok('e3', 'GET', '/rooms')).rooms[0].unread).toBe(1);
  const m = await ok('e3', 'GET', `/rooms/${r.id}/messages`);
  expect(m.items[0]).toMatchObject({ body: 'Đơn hàng ABC đã giao' });
  expect((await ok('e3', 'GET', '/rooms')).rooms[0].unread).toBe(0);
  // Chỉ quản trị nhóm được nhắn
  expect((await call('e4', 'PATCH', `/rooms/${r.id}`, { settings: { who_can_post: 'admins' } })).status).toBe(403);
  await ok('m2', 'PATCH', `/rooms/${r.id}`, { settings: { who_can_post: 'admins', who_can_add: 'admins' } });
  expect((await call('e4', 'POST', `/rooms/${r.id}/messages`, { body: 'x' })).status).toBe(403);
  await ok('m2', 'PATCH', `/rooms/${r.id}/members/${mid.e4}`, { role: 'admin' });
  await ok('e4', 'POST', `/rooms/${r.id}/messages`, { body: 'Quản trị nhóm nhắn được' });
  expect((await call('e3', 'POST', `/rooms/${r.id}/members`, { memberIds: [mid.m2] })).status).toBe(403);
  // Rời nhóm
  await ok('e3', 'DELETE', `/rooms/${r.id}/members/${mid.e3}`);
  expect((await call('e3', 'GET', `/rooms/${r.id}`)).status).toBe(404);
  expect((await call('m2', 'DELETE', `/rooms/${r.id}/members/${mid.m2}`)).status).toBe(409);   // chủ nhóm không rời được
});

test('Gọi nhóm: bắt đầu, người khác thấy & tham gia, báo hiệu, rời → kết thúc', async () => {
  const r = (await ok('m2', 'GET', '/rooms')).rooms.find((x: any) => x.name === 'Kinh doanh nhanh');
  const a = await ok('m2', 'POST', `/rooms/${r.id}/calls`);
  expect(a.status).toBe('active'); expect(a.limit_seconds).toBe(300); expect(a.participants).toHaveLength(1);
  const p = await ok('e4', 'GET', '/calls-poll');
  expect(p.room_calls).toHaveLength(1); expect(p.room_calls[0].room_name).toBe('Kinh doanh nhanh');
  const b = await ok('e4', 'POST', `/rooms/${r.id}/calls`);
  expect(b.id).toBe(a.id); expect(b.participants).toHaveLength(2);
  expect((await ok('e4', 'GET', '/calls-poll')).room_calls).toHaveLength(0);
  await ok('e4', 'POST', `/room-calls/${a.id}/signal`, { to: mid.m2, type: 'offer', payload: { sdp: 'v=0' } });
  const s = await ok('m2', 'GET', `/room-calls/${a.id}/poll?since=0`);
  expect(s.signals).toHaveLength(1); expect(s.signals[0]).toMatchObject({ from_member_id: mid.e4, type: 'offer' });
  expect((await ok('m2', 'GET', `/room-calls/${a.id}/poll?since=${s.since}`)).signals).toHaveLength(0);
  expect((await call('e1', 'POST', `/room-calls/${a.id}/signal`, { to: mid.m2, type: 'ice', payload: {} })).status).toBe(409);
  await ok('m2', 'POST', `/room-calls/${a.id}/leave`); await ok('e4', 'POST', `/room-calls/${a.id}/leave`);
  expect((await q1(`SELECT status FROM room_calls WHERE id=$1`, [a.id])).status).toBe('ended');
  // Chỉ quản trị được gọi
  await ok('m2', 'PATCH', `/rooms/${r.id}`, { settings: { who_can_call: 'admins' } });
  await ok('m2', 'PATCH', `/rooms/${r.id}/members/${mid.e4}`, { role: 'member' });
  expect((await call('e4', 'POST', `/rooms/${r.id}/calls`)).status).toBe(403);
});

test('Gia nhập công ty thứ 2 bằng mã → nhân sự duyệt → đổi công ty', async () => {
  // Chủ doanh nghiệp mở doanh nghiệp thứ 2 (gói mới, không truyền companyId)
  const sub = await ok('owner', 'POST', '/subscriptions', { plan: 'small', addonPacks: 0, companyName: 'Công ty Thứ Hai', contactEmail: 'owner2@demo.vn' });
  await ok('admin', 'GET', '/auth/me');
  const plat = (await ok('', 'POST', '/auth/login', { phone: '0900000000', password: 'Demo@123' })).access_token; tok.plat = plat;
  const sid = sub.subscription?.id || sub.id;
  if ((await q1(`SELECT status FROM subscriptions WHERE id=$1`, [sid])).status !== 'active') await ok('plat', 'POST', `/platform/subscriptions/${sid}/activate`, { paymentRef: 'CK-0001' });
  const me = await ok('owner', 'GET', '/auth/me');
  const second = me.memberships.find((x: any) => x.company_name === 'Công ty Thứ Hai');
  expect(second).toBeTruthy(); expect(me.memberships.length).toBe(2);
  const sw = await ok('owner', 'POST', '/auth/switch-company', { companyId: second.company_id });
  tok.owner2 = sw.access_token;
  const code = (await ok('owner2', 'GET', '/company/join-code')).code;
  expect(code).toMatch(/^[A-Z2-9]{8}$/);
  expect((await call('e1', 'GET', '/company/join-code')).status).toBe(403);
  expect((await ok('e1', 'GET', `/companies/lookup?code=${code.toLowerCase()}`)).name).toBe('Công ty Thứ Hai');
  const j = await ok('e1', 'POST', '/companies/join', { code });
  expect(j.status).toBe('pending_hr');
  expect((await call('e1', 'POST', '/companies/join', { code })).status).toBe(409);
  expect((await ok('e1', 'GET', '/auth/me')).pending_memberships.map((x: any) => x.company_name)).toContain('Công ty Thứ Hai');
  expect((await ok('owner2', 'GET', '/notifications')).items?.some?.((n: any) => /xin gia nhập/.test(n.title)) ?? true).toBe(true);
  await ok('owner2', 'POST', `/company/members/${j.id}/hr-review`, { decision: 'approve' });
  const me1 = await ok('e1', 'GET', '/auth/me');
  expect(me1.memberships.map((x: any) => x.company_name)).toEqual(expect.arrayContaining(['Công ty TNHH Demo Việt', 'Công ty Thứ Hai']));
  const s2 = await ok('e1', 'POST', '/auth/switch-company', { companyId: second.company_id });
  tok.e1b = s2.access_token;
  expect((await ok('e1b', 'GET', '/auth/me')).company_name).toBe('Công ty Thứ Hai');
  // Đổi mã: mã cũ hết hiệu lực
  const nc = (await ok('owner2', 'POST', '/company/join-code/rotate')).code;
  expect(nc).not.toBe(code);
  expect((await call('e2', 'POST', '/companies/join', { code })).status).toBe(404);
});

test('Nhật ký lỗi kết nối phía ứng dụng', async () => {
  await ok('e2', 'POST', '/diag/client-errors', { app: 'android', items: [{ code: 'NETWORK', path: '/calls-poll', online: true }, { code: 'HTTP_502', status: 502, path: '/tasks' }] });
  const r = await ok('admin', 'GET', '/platform/client-errors?hours=1');
  expect(r.summary.find((x: any) => x.code === 'NETWORK').n).toBe(1);
  expect((await call('e2', 'GET', '/platform/client-errors')).status).toBe(403);
});
