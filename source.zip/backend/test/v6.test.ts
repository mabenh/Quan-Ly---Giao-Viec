/* Kiểm thử v6 — Đặc tả nghiệp vụ v2.0 (mục 15: tiêu chí nghiệm thu cốt lõi). */
process.env.DATABASE_URL = process.env.TEST_DATABASE_URL || 'postgresql://app:app@localhost:5432/teamapp_test';
process.env.DISABLE_SCHEDULER = 'true';
process.env.UPLOAD_DIR = '/tmp/teamapp-test-uploads';

import { INestApplication } from '@nestjs/common';
import { closePool, q, q1 } from '../src/db/db';
import { createApp } from '../src/main';
import { resetDb, seed } from '../src/db/seed';
import { runRiskScan } from '../src/modules/operations.controller';

let app: INestApplication;
let url = '';
const tok: Record<string, string> = {};
const ids: Record<string, string> = {};
async function call(who: string, method: string, path: string, body?: any) {
  const r = await fetch(url + path, { method, headers: { 'Content-Type': 'application/json', ...(tok[who] ? { Authorization: `Bearer ${tok[who]}` } : {}) }, body: body ? JSON.stringify(body) : undefined });
  return { status: r.status, body: (await r.json().catch(() => ({}))) as any };
}
async function ok(who: string, method: string, path: string, body?: any) {
  const r = await call(who, method, path, body);
  if (r.status >= 300) throw new Error(`${method} ${path} -> ${r.status} ${JSON.stringify(r.body)}`);
  return r.body;
}
const PH: Record<string, string> = { owner: '0901000001', admin: '0901000002', m1: '0901000003', m2: '0901000004', e1: '0901000007', e2: '0901000008', e3: '0901000009', e4: '0901000010' };
const task = (title: string) => q1(`SELECT * FROM tasks WHERE title=$1`, [title]);

beforeAll(async () => {
  await resetDb();
  app = await createApp();
  await app.listen(0);
  url = `http://127.0.0.1:${(app.getHttpServer().address() as any).port}/api/v1`;
  await seed(url);
  for (const [k, p] of Object.entries(PH)) {
    tok[k] = (await ok('', 'POST', '/auth/login', { phone: p, password: 'Demo@123' })).access_token;
    ids[k] = (await q1(`SELECT cm.id FROM company_members cm JOIN users u ON u.id=cm.user_id WHERE u.phone=$1`, [p])).id;
  }
  ids.g1 = (await q1(`SELECT id FROM groups WHERE name='Nhóm Vận hành'`)).id;
  ids.g2 = (await q1(`SELECT id FROM groups WHERE name='Nhóm Kinh doanh'`)).id;
  ids.g3 = (await q1(`SELECT id FROM groups WHERE name='Tổ Đóng gói'`)).id;
  ids.chain = (await q1(`SELECT id FROM tasks WHERE is_chain`)).id;
});
afterAll(async () => { await app.close(); await closePool(); });

describe('Phân quyền theo vai trò/phạm vi', () => {
  test('Quản lý nhóm A không xem chi tiết nhóm B; dashboard đúng vai trò', async () => {
    expect((await call('m2', 'GET', `/time/summary?groupId=${ids.g1}`)).status).toBe(403);
    expect((await call('m2', 'GET', `/sessions/team?groupId=${ids.g1}`)).status).toBe(404);
    const d = await ok('m2', 'GET', '/dash/manager');
    expect(d.groups.map((g: any) => g.id)).toEqual([ids.g2]);
    expect((await call('m1', 'GET', '/dash/board')).status).toBe(403);
    expect((await call('e1', 'GET', '/dash/manager')).status).toBe(403);
    const b = await ok('admin', 'GET', '/dash/board?period=month');
    expect(b.groups.length).toBeGreaterThanOrEqual(3);
    expect(b.formulas.efficiency).toContain('thời gian chuẩn');
    // trưởng nhóm (nhân viên) thấy trang trưởng nhóm của tổ mình
    const l = await ok('e3', 'GET', '/dash/leader');
    expect(l.groups.map((g: any) => g.id)).toEqual([ids.g3]);
    expect(l.live.some((m: any) => m.member_id === ids.e3 && m.session_id)).toBe(true);
  });
});

describe('Phiên làm việc & thời gian', () => {
  test('Một phiên đang chạy; chuyển việc đóng phiên cũ trước; vị trí không bắt buộc khi việc không yêu cầu', async () => {
    const tasks = await q(`SELECT t.id FROM tasks t JOIN task_assignees a ON a.task_id=t.id AND a.company_member_id=$1 AND a.active
                            WHERE t.status IN ('not_started','in_progress') AND NOT t.location_required AND t.parent_id IS NULL AND NOT EXISTS (SELECT 1 FROM tasks k WHERE k.parent_id=t.id) LIMIT 2`, [ids.e2]);
    await ok('e2', 'POST', '/sessions/start', { taskId: tasks[0].id });
    const me = await ok('e2', 'POST', '/sessions/start', { taskId: tasks[1].id });
    expect(me.active.task_id).toBe(tasks[1].id);
    const all = await q(`SELECT task_id, ended_at, end_reason FROM work_sessions WHERE member_id=$1 ORDER BY started_at`, [ids.e2]);
    expect(all.filter((s) => !s.ended_at).length).toBe(1);
    expect(all.find((s) => s.task_id === tasks[0].id).end_reason).toBe('switch');
    await expect(q(`INSERT INTO work_sessions(company_id, member_id, task_id) SELECT company_id, member_id, task_id FROM work_sessions WHERE member_id=$1 LIMIT 1`, [ids.e2])).rejects.toThrow();
  });

  test('Hoãn khách quan phân loại riêng, không tính vào mẫu số hiệu quả; trưởng nhóm xác nhận', async () => {
    await ok('e2', 'POST', '/sessions/pause', { category: 'objective_pause', reason: 'Mất điện khu kho' });
    await q(`UPDATE work_time_records SET started_at=now() - interval '30 minutes' WHERE member_id=$1 AND ended_at IS NULL`, [ids.e2]);
    const me = await ok('e2', 'GET', '/dash/me');
    expect(me.time.objective_pause).toBeGreaterThanOrEqual(29);
    const r = await q1(`SELECT id FROM work_time_records WHERE member_id=$1 AND ended_at IS NULL`, [ids.e2]);
    expect((await call('e2', 'POST', `/time-records/${r.id}/confirm`, { objective: true })).status).toBe(403);
    await ok('m1', 'POST', `/time-records/${r.id}/confirm`, { objective: true, note: 'Đúng, mất điện toàn khu' });
    const sum = await ok('m1', 'GET', `/time/summary?memberId=${ids.e2}`);
    expect(sum.members[0].objective_pause).toBeGreaterThan(0);
    expect(sum.members[0]).toHaveProperty('execution');
    expect(sum.members[0]).toHaveProperty('overtime');
    await ok('e2', 'POST', '/sessions/end', {});
  });

  test('Nhiệm vụ yêu cầu vị trí; tự khai công việc bắt buộc chọn vị trí (cho phép ngoài công ty/không xác định)', async () => {
    const t = await ok('m1', 'POST', '/tasks', { title: 'Kiểm kê kho lạnh', description: 'Kiểm kê toàn bộ kho lạnh', groupId: ids.g1, ownerMemberId: ids.e1,
      taskTypeId: (await task('Đóng gói 2.000 túi 1kg')).task_type_id, complexity: 'simple', requirementLevel: 'normal', estimatedHours: 2,
      dueAt: new Date(Date.now() + 86400000).toISOString(), criteria: [{ direction: 'output', criterion: 'Biên bản kiểm kê' }], locationRequired: true });
    expect((await call('e1', 'POST', '/sessions/start', { taskId: t.id })).status).toBe(422);
    const cold = await q1(`SELECT id FROM work_locations WHERE name='Kho lạnh'`);
    const s = await ok('e1', 'POST', '/sessions/start', { taskId: t.id, locationId: cold.id });
    expect(s.active.location_name).toBe('Kho lạnh');
    await ok('e1', 'POST', '/sessions/end', {});
    const t0 = new Date(Date.now() - 3 * 3600000).toISOString(); const t1 = new Date(Date.now() - 2 * 3600000).toISOString();
    expect((await call('e1', 'POST', '/work-records', { recordType: 'routine', initiative: true, title: 'Dọn kho', startAt: t0, endAt: t1 })).status).toBe(422);
    const wr = await ok('e1', 'POST', '/work-records', { recordType: 'routine', initiative: true, title: 'Gặp nhà cung cấp', startAt: t0, endAt: t1, locationSource: 'outside' });
    expect(wr.location_source).toBe('outside');
  });
});

describe('Sản lượng, bàn giao, chuỗi đơn hàng', () => {
  test('Trưởng nhóm ghi nhận sản lượng; không ghi đè âm thầm — điều chỉnh tạo phiên bản có lý do', async () => {
    const pack = await task('Đóng gói 2.000 túi 1kg');
    expect((await call('e4', 'POST', '/production', { taskId: pack.id, actualQty: 10, acceptedQty: 10 })).status).toBe(403);
    const p = await ok('e3', 'POST', '/production', { taskId: pack.id, mode: 'stage', actualQty: 420, acceptedQty: 400, rejectedQty: 15, reworkQty: 5, executionMinutes: 130 });
    expect(p.efficiency).toBe(Math.round((100 * (400 / 100) * 30) / 130));
    expect(p.quality_rate).toBe(Math.round((100 * 400) / 420));
    await expect(q(`UPDATE production_records SET accepted_qty=999 WHERE id=$1`, [p.id])).rejects.toThrow(/không sửa trực tiếp/);
    expect((await call('e3', 'POST', `/production/${p.id}/adjust`, { actualQty: 420, acceptedQty: 405, rejectedQty: 10, reworkQty: 5, executionMinutes: 130 })).status).toBe(422);
    const v2 = await ok('e3', 'POST', `/production/${p.id}/adjust`, { actualQty: 420, acceptedQty: 405, rejectedQty: 10, reworkQty: 5, executionMinutes: 130, reason: 'Đếm lại: 5 túi lỗi là túi đạt' });
    expect(v2.version).toBe(2);
    expect((await q1(`SELECT status FROM production_records WHERE id=$1`, [p.id])).status).toBe('superseded');
    expect(await q1(`SELECT 1 FROM audit_logs WHERE action='production.adjusted' AND reason LIKE 'Đếm lại%'`)).toBeTruthy();
    // bàn giao một lần
    const single = await ok('e3', 'POST', '/production', { taskId: pack.id, mode: 'single', actualQty: 50, acceptedQty: 50, executionMinutes: 15, note: 'Lô bổ sung' });
    expect(single.mode).toBe('single');
  });

  test('Chuỗi có mã chung, nhiệm vụ con mã riêng; bàn giao có nội dung, tiếp nhận/từ chối/bổ sung; chưa tiếp nhận thì chưa bắt đầu', async () => {
    const c = await ok('m1', 'GET', `/chains/${ids.chain}`);
    expect(c.chain_code).toMatch(/^DH-\d{5}$/);
    expect(new Set(c.stages.map((s: any) => s.code)).size).toBe(c.stages.length);
    expect(Number(c.order_value)).toBe(56000000);
    const pack = await task('Đóng gói 2.000 túi 1kg'); const ship = await task('Giao hàng cho siêu thị');
    expect(ship.status).toBe('waiting');
    expect((await call('e2', 'POST', '/sessions/start', { taskId: ship.id })).status).toBe(409);
    // đóng gói xong -> mở giai đoạn giao hàng kèm bàn giao tự động kế thừa kết quả
    await ok('e3', 'POST', `/tasks/${pack.id}/submit`, { outputDescription: 'Đóng xong 2.000 túi, xếp 40 thùng tại khu xuất' });
    const rv = await ok('m1', 'POST', `/tasks/${pack.id}/review`, { decision: 'approve', scores: { output: 90, quality: 85, schedule: 90, process: 90 } });
    expect(rv.status).toBe('completed');
    const ho = await q1(`SELECT * FROM handover_contexts WHERE to_task_id=$1`, [ship.id]);
    expect(ho.content).toContain('2.000 túi');
    expect(Number(ho.quantity)).toBeGreaterThan(0);
    const st = await call('e2', 'POST', '/sessions/start', { taskId: ship.id });
    expect(st.status).toBe(409);
    expect(st.body.error.code).toBe('HANDOVER_NOT_ACCEPTED');
    expect((await call('e2', 'POST', `/handovers/${ho.id}/decide`, { decision: 'reject' })).status).toBe(422);
    await ok('e2', 'POST', `/handovers/${ho.id}/decide`, { decision: 'reject', reason: 'Thiếu phiếu kiểm hàng của lô' });
    expect((await call('e2', 'POST', `/handovers/${ho.id}/supplement`, { content: 'Bên nhận tự bổ sung' })).status).toBe(403);
    await ok('e3', 'POST', `/handovers/${ho.id}/supplement`, { content: 'Đã bổ sung phiếu kiểm KH-221' });
    await ok('e2', 'POST', `/handovers/${ho.id}/decide`, { decision: 'accept' });
    const s = await ok('e2', 'POST', '/sessions/start', { taskId: ship.id });
    expect(s.active.task_id).toBe(ship.id);
    const ev = await q(`SELECT kind FROM handover_events WHERE handover_id=$1 ORDER BY id`, [ho.id]);
    expect(ev.map((e) => e.kind)).toEqual(['submitted', 'rejected', 'supplemented', 'accepted']);
    await ok('e2', 'POST', '/sessions/end', {});
  });

  test('Trường nhạy cảm của chuỗi chỉ Ban quản trị/người tạo; nhân viên chỉ thấy bối cảnh cần thiết', async () => {
    const e = await ok('e2', 'GET', `/chains/${ids.chain}`);
    expect(e).not.toHaveProperty('order_value');
    expect(e).not.toHaveProperty('margin_note');
    const list = await ok('e2', 'GET', '/chains');
    expect(list[0]).not.toHaveProperty('order_value');
    const tdet = await ok('admin', 'GET', `/tasks/${ids.chain}`);
    expect(Number(tdet.order_value)).toBe(56000000);
    const tm = await ok('m2', 'GET', `/tasks?limit=100`);
    expect(tm.items.every((t: any) => t.order_value === undefined || t.created_by === ids.m2)).toBe(true);
  });

  test('Deadline tính ngược theo lịch; cảnh báo ở nhiệm vụ con phản ánh lên chuỗi; công đoạn gây tắc; ưu tiên & bắt đầu sớm có lý do', async () => {
    const root = await ok('m1', 'POST', '/tasks', { title: 'Đơn hàng thử nghiệm gấp', description: 'Đơn 3 công đoạn', groupId: ids.g1, ownerMemberId: ids.m1,
      taskTypeId: (await task('Đóng gói 2.000 túi 1kg')).task_type_id, complexity: 'medium', requirementLevel: 'normal', estimatedHours: 8,
      dueAt: new Date(Date.now() + 10 * 86400000).toISOString(), criteria: [{ direction: 'output', criterion: 'Hoàn tất' }], isChain: true });
    const a = await ok('m1', 'POST', '/tasks', { parentId: root.id, title: 'Công đoạn A', groupId: ids.g1, ownerMemberId: ids.e1, stageNo: 1, standardMinutes: 240 });
    const b1 = await ok('m1', 'POST', '/tasks', { parentId: root.id, title: 'Công đoạn B1', groupId: ids.g1, ownerMemberId: ids.e2, stageNo: 2, standardMinutes: 480 });
    await ok('m1', 'POST', '/tasks', { parentId: root.id, title: 'Công đoạn B2 (song song)', groupId: ids.g1, ownerMemberId: ids.e1, stageNo: 2, standardMinutes: 120 });
    const sch = await ok('m1', 'POST', `/chains/${root.id}/schedule`, { apply: true });
    expect(sch.feasible).toBe(true);
    const A = await q1(`SELECT due_at, planned_start_at FROM tasks WHERE id=$1`, [a.id]); const B = await q1(`SELECT due_at, planned_start_at FROM tasks WHERE id=$1`, [b1.id]);
    expect(new Date(A.due_at).getTime()).toBe(new Date(B.planned_start_at).getTime()); // A phải xong trước khi nhánh dài nhất của GĐ2 bắt đầu
    expect(new Date(B.due_at).getTime()).toBeLessThanOrEqual(new Date(root.due_at).getTime());
    // A gần hạn mà còn nhiều việc -> nguy cơ trễ -> chuỗi nguy cơ trễ, A là công đoạn gây tắc
    await q(`UPDATE tasks SET due_at=now() + interval '30 minutes' WHERE id=$1`, [a.id]);
    const c = await ok('m1', 'GET', `/chains/${root.id}`);
    expect(['at_risk', 'overdue']).toContain(c.risk);
    expect(c.bottleneck.title).toBe('Công đoạn A');
    expect(await runRiskScan((await q1(`SELECT company_id FROM tasks WHERE id=$1`, [a.id])).company_id)).toBeGreaterThan(0);
    const n = await ok('e1', 'GET', '/notifications');
    expect(n.items.some((i: any) => i.type === 'task.risk' && i.reference_id === a.id)).toBe(true);
    expect((await call('m1', 'POST', `/tasks/${a.id}/priority`, { priority: 'urgent' })).status).toBe(422);
    await ok('m1', 'POST', `/tasks/${a.id}/priority`, { priority: 'urgent', reason: 'Khách dời lịch nhận sớm hơn' });
    expect((await call('e2', 'POST', `/tasks/${b1.id}/early-start`, { reason: 'Muốn làm trước' })).status).toBe(403);
    await ok('m1', 'POST', `/tasks/${b1.id}/early-start`, { reason: 'Nguyên liệu đã có sẵn từ đơn trước' });
    expect((await q1(`SELECT status FROM tasks WHERE id=$1`, [b1.id])).status).toBe('not_started');
    const board = await ok('admin', 'GET', '/dash/board');
    expect(board.chains.items.some((x: any) => x.id === root.id && x.bottleneck)).toBe(true);
  });
});

describe('Quỹ nghỉ, phản hồi dữ liệu', () => {
  test('Tích lũy theo chính sách; chỉ dùng khi hoãn khách quan và được duyệt; trừ số phút thực tế; không quy đổi tăng ca', async () => {
    const t = await q1(`SELECT t.id FROM tasks t JOIN task_assignees a ON a.task_id=t.id AND a.company_member_id=$1 AND a.active AND a.assignment_type='owner'
                         WHERE t.status IN ('not_started','in_progress') AND NOT t.location_required AND NOT EXISTS (SELECT 1 FROM tasks k WHERE k.parent_id=t.id)
                           AND NOT EXISTS (SELECT 1 FROM handover_contexts h WHERE h.to_task_id=t.id AND h.status<>'accepted') LIMIT 1`, [ids.e1]);
    await ok('e1', 'POST', '/sessions/start', { taskId: t.id });
    await q(`UPDATE work_sessions SET started_at=now() - interval '370 minutes' WHERE member_id=$1 AND ended_at IS NULL`, [ids.e1]);
    expect((await call('e1', 'POST', '/rest/request', {})).status).toBe(409); // đang làm việc, chưa hoãn
    await ok('e1', 'POST', '/sessions/pause', { category: 'objective_pause', reason: 'Chờ xe hàng về' });
    const l = await ok('e1', 'GET', '/rest/ledger');
    expect(l.balance).toBeGreaterThanOrEqual(30);
    expect(l.note).toContain('không tự động quy đổi');
    const otBefore = (await ok('e1', 'GET', `/time/summary?memberId=${ids.e1}`)).members[0].overtime;
    await ok('e1', 'POST', '/rest/request', { note: 'Nghỉ 15 phút' });
    const reqs = await ok('m1', 'GET', '/rest/requests');
    const rq = reqs.find((r: any) => r.member_id === ids.e1);
    expect((await call('e1', 'POST', `/rest/${rq.id}/decide`, { decision: 'approve' })).status).toBe(403);
    await ok('m1', 'POST', `/rest/${rq.id}/decide`, { decision: 'approve' });
    await q(`UPDATE work_time_records SET started_at=now() - interval '15 minutes' WHERE member_id=$1 AND ended_at IS NULL AND category='rest_internal'`, [ids.e1]);
    await ok('e1', 'POST', '/sessions/resume', {});
    const l2 = await ok('e1', 'GET', '/rest/ledger');
    expect(l2.balance).toBe(l.balance - 15);
    expect((await ok('e1', 'GET', `/time/summary?memberId=${ids.e1}`)).members[0].overtime).toBe(otBefore);
    await ok('e1', 'POST', '/sessions/end', {});
  });

  test('Nhân viên xem kết quả của mình và phản hồi dữ liệu sai; trưởng nhóm xử lý', async () => {
    const me = await ok('e4', 'GET', '/dash/me');
    expect(me.production.length).toBeGreaterThan(0);
    const pr = me.production[0];
    const f = await ok('e4', 'POST', '/feedback', { targetType: 'production', targetId: pr.id, content: 'Tôi tham gia cả ca chiều, số lượng đạt chuẩn phải là 380' });
    expect(f.assigned_to).toBe(ids.e3);
    expect((await call('e4', 'POST', `/feedback/${f.id}/resolve`, { status: 'resolved', resolution: 'tự xử lý' })).status).toBe(403);
    await ok('e3', 'POST', `/feedback/${f.id}/resolve`, { status: 'resolved', resolution: 'Đã đối chiếu và điều chỉnh bản ghi sản lượng (phiên bản mới)' });
    const mine = await ok('e4', 'GET', '/feedback');
    expect(mine[0].status).toBe('resolved');
    expect((await call('e1', 'POST', '/feedback', { targetType: 'production', targetId: pr.id, content: 'Không phải dữ liệu của tôi nhưng muốn sửa' })).status).toBe(404);
  });
});
