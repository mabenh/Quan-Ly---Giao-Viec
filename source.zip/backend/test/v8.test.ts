/* Kiểm thử v8: phân cấp tầng 3–7, chức năng phòng ban, quyền hạn cấu hình, quy trình lập–xem xét–duyệt đơn hàng, mẫu theo phòng ban. */
process.env.DATABASE_URL = process.env.TEST_DATABASE_URL || 'postgresql://app:app@localhost:5432/teamapp_test';
process.env.DISABLE_SCHEDULER = 'true';
process.env.UPLOAD_DIR = '/tmp/teamapp-test-uploads';

import { INestApplication } from '@nestjs/common';
import { closePool, q, q1 } from '../src/db/db';
import { createApp } from '../src/main';
import { resetDb, seed } from '../src/db/seed';

let app: INestApplication;
let url = '';
const tok: Record<string, string> = {};
const ids: Record<string, string> = {};
async function call(who: string, method: string, path: string, body?: any) {
  const r = await fetch(url + path, { method, headers: { 'Content-Type': 'application/json', ...(tok[who] ? { Authorization: `Bearer ${tok[who]}` } : {}) }, body: body ? JSON.stringify(body) : undefined });
  return { status: r.status, body: (await r.json().catch(() => ({}))) as any };
}
async function ok(who: string, method: string, path: string, body?: any) {
  const r = await call(who, method, path, body);
  if (r.status >= 300) throw new Error(`${method} ${path} -> ${r.status} ${JSON.stringify(r.body)}`);
  return r.body;
}
const PH: Record<string, string> = { owner: '0901000001', admin: '0901000002', m1: '0901000003', m2: '0901000004', e1: '0901000007', e3: '0901000009', hr: '0901000012' };
let typeId = '';
const base = (extra: any = {}) => ({ description: 'Mô tả công việc thử nghiệm', taskTypeId: typeId, complexity: 'simple', requirementLevel: 'normal', estimatedHours: 2,
  dueAt: new Date(Date.now() + 5 * 86400000).toISOString(), criteria: [{ direction: 'output', criterion: 'Hoàn thành' }], ...extra });

beforeAll(async () => {
  await resetDb();
  app = await createApp();
  await app.listen(0);
  url = `http://127.0.0.1:${(app.getHttpServer().address() as any).port}/api/v1`;
  await seed(url);
  for (const [k, p] of Object.entries(PH)) {
    tok[k] = (await ok('', 'POST', '/auth/login', { phone: p, password: 'Demo@123' })).access_token;
    ids[k] = (await q1(`SELECT cm.id FROM company_members cm JOIN users u ON u.id=cm.user_id WHERE u.phone=$1`, [p])).id;
  }
  for (const [k, n] of Object.entries({ g1: 'Nhóm Vận hành', g2: 'Nhóm Kinh doanh', g3: 'Tổ Đóng gói', gh: 'Nhóm Nhân sự' })) ids[k] = (await q1(`SELECT id FROM groups WHERE name=$1`, [n])).id;
  typeId = (await q1(`SELECT id FROM task_types WHERE name='Hành chính'`)).id;
});
afterAll(async () => { await app.close(); await closePool(); });

test('Hồ sơ quyền: tầng, chức vụ, phòng ban', async () => {
  const me = await ok('m1', 'GET', '/auth/me');
  expect(me.authority.tier).toBe(5);
  expect(me.authority.position).toBe('Trưởng phòng');
  expect(me.authority.dept_function).toBe('production');
  expect(me.authority.caps).toEqual(expect.arrayContaining(['create_order', 'review_order', 'assign_dept']));
  expect(me.authority.caps).not.toContain('approve_order');
  const hr = await ok('hr', 'GET', '/auth/me');
  expect(hr.authority.hr_scoped).toBe(true);
  expect(hr.authority.caps).not.toContain('create_order');
  const p = await ok('m1', 'GET', '/company/positions');
  expect(Object.keys(p.tiers)).toEqual(['3', '4', '5', '6', '7']);
});

test('Quản lý nhân sự: không lập đơn/đơn con, chỉ giao việc & thấy nhóm trong phòng nhân sự', async () => {
  expect((await call('hr', 'POST', '/tasks', base({ title: 'Đơn thử', groupId: ids.gh, ownerMemberId: ids.hr, isChain: true }))).status).toBe(403);
  const chain = await q1(`SELECT id FROM tasks WHERE is_chain LIMIT 1`);
  expect((await call('hr', 'POST', '/tasks', { parentId: chain.id, title: 'Công đoạn thử', groupId: ids.gh, stageNo: 3 })).status).toBeGreaterThanOrEqual(403);
  expect((await call('hr', 'POST', '/tasks', base({ title: 'Giao sang sản xuất', groupId: ids.g1, ownerMemberId: ids.e1 }))).status).toBe(403);
  const t = await ok('hr', 'POST', '/tasks', base({ title: 'Tổng hợp chấm công tháng 11', groupId: ids.gh, ownerMemberId: ids.hr }));
  expect(t.status).toBe('not_started');
  const groups = await ok('hr', 'GET', '/groups?scope=all');
  expect(groups.map((g: any) => g.id)).toEqual([ids.gh]);
  expect((await call('hr', 'GET', `/groups/${ids.g1}`)).status).toBe(404);
  const tpl = await ok('hr', 'GET', '/company/task-templates');
  expect(tpl.some((x: any) => x.name === 'Tuyển dụng vị trí')).toBe(true);
  expect(tpl.some((x: any) => x.name === 'Lệnh sản xuất theo ca' || x.name === 'Nhập kho hàng hóa')).toBe(false);
});

test('Giao việc theo tầng: công nhân không giao việc; tổ trưởng chỉ giao trong tổ', async () => {
  expect((await call('e1', 'POST', '/tasks', base({ title: 'Tự giao', groupId: ids.g1, ownerMemberId: ids.e1 }))).status).toBe(403);
  const ok3 = await ok('e3', 'POST', '/tasks', base({ title: 'Dán nhãn thùng lô C', groupId: ids.g3, ownerMemberId: ids.e3 }));
  expect(ok3.group_id).toBe(ids.g3);
  expect((await call('e3', 'POST', '/tasks', base({ title: 'Ra lệnh cho nhóm khác', groupId: ids.g1, ownerMemberId: ids.e1 }))).status).toBe(403);
});

test('Đơn hàng: Kinh doanh lập -> Sản xuất xem xét -> cấp cao duyệt -> trưởng nhóm nhận công đoạn lần lượt; trả lại & gửi lại', async () => {
  const lX2 = await q1(`SELECT id FROM work_locations WHERE name='Xưởng số 2'`);
  const o = await ok('m2', 'POST', '/tasks', base({ title: 'Đơn khách Minh Long', groupId: ids.g2, isChain: true, workLocationId: lX2.id }));
  expect(o.order_status).toBe('pending_review');
  expect(o.owner_id).toBe(ids.m2);
  const s1 = await ok('m2', 'POST', '/tasks', { parentId: o.id, title: 'Chuẩn bị nguyên liệu', groupId: ids.g1, stageNo: 1 });
  const s2 = await ok('m2', 'POST', '/tasks', { parentId: o.id, title: 'Đóng gói', groupId: ids.g3, stageNo: 2 });
  expect(s1.status).not.toBe('not_started'); // chưa phát hành
  expect((await q1(`SELECT count(*)::int AS n FROM notifications WHERE reference_id=$1 AND type='task.assigned'`, [s1.id])).n).toBe(0);
  expect((await call('m2', 'POST', `/chains/${o.id}/order`, { action: 'review' })).status).toBe(403);   // người lập không tự xem xét
  expect((await call('e1', 'POST', `/chains/${o.id}/order`, { action: 'review' })).status).toBe(403);
  expect((await call('m1', 'POST', `/chains/${o.id}/order`, { action: 'reject' })).status).toBe(422);
  await ok('m1', 'POST', `/chains/${o.id}/order`, { action: 'reject', note: 'Chưa đủ nguyên liệu, cần dời hạn' });
  await ok('m2', 'POST', `/chains/${o.id}/order`, { action: 'resubmit', note: 'Đã dời hạn giao 2 ngày' });
  const rv = await ok('m1', 'POST', `/chains/${o.id}/order`, { action: 'review', note: 'Đủ năng lực' });
  expect(rv.order.status).toBe('reviewed');
  expect((await call('m1', 'POST', `/chains/${o.id}/order`, { action: 'approve' })).status).toBe(403); // trưởng phòng không duyệt
  const ap = await ok('admin', 'POST', `/chains/${o.id}/order`, { action: 'approve' });
  expect(ap.order.status).toBe('approved');
  expect(ap.order.location).toBe('Xưởng số 2');
  expect((await q1(`SELECT status FROM tasks WHERE id=$1`, [s1.id])).status).toBe('not_started');
  expect((await q1(`SELECT status FROM tasks WHERE id=$1`, [s2.id])).status).toBe('waiting');
  const leader1 = (await q1(`SELECT COALESCE(leader_member_id, manager_member_id) AS id FROM groups WHERE id=$1`, [ids.g1])).id;
  expect(await q1(`SELECT 1 FROM notifications WHERE member_id=$1 AND reference_id=$2 AND type='task.stage_started'`, [leader1, s1.id])).toBeTruthy();
  expect((await q1(`SELECT owner FROM (SELECT company_member_id AS owner FROM task_assignees WHERE task_id=$1 AND assignment_type='owner') x`, [s2.id])).owner).toBe(ids.e3); // trưởng tổ đóng gói
});

test('Mẫu công việc theo phòng ban: chỉ thấy mẫu phòng mình; quản lý phòng ban tự tạo/sửa mẫu của phòng mình', async () => {
  const m2t = await ok('m2', 'GET', '/company/task-templates');
  expect(m2t.some((x: any) => x.name === 'Lập báo giá khách hàng')).toBe(true);
  expect(m2t.some((x: any) => x.name === 'Lệnh sản xuất theo ca')).toBe(false);
  const created = await ok('m1', 'POST', '/company/task-templates', { name: 'Vệ sinh máy cuối ca', taskTypeId: typeId, fields: [{ key: 'may', label: 'Máy', type: 'text', required: true }],
    criteria: [{ direction: 'output', criterion: 'Máy sạch, có ảnh xác nhận' }] });
  const sx = (await q1(`SELECT department_id FROM company_members WHERE id=$1`, [ids.m1])).department_id;
  expect(created.department_id).toBe(sx);
  const kd = (await q1(`SELECT department_id FROM company_members WHERE id=$1`, [ids.m2])).department_id;
  expect((await call('m1', 'POST', '/company/task-templates', { name: 'Mẫu cho kinh doanh', taskTypeId: typeId, departmentId: kd })).status).toBe(403);
  expect((await call('e1', 'POST', '/company/task-templates', { name: 'Mẫu công nhân', taskTypeId: typeId })).status).toBe(403);
  const bg = m2t.find((x: any) => x.name === 'Lập báo giá khách hàng');
  expect((await call('m1', 'PATCH', `/company/task-templates/${bg.id}`, { name: 'Sửa trộm' })).status).toBe(403);
  await ok('m1', 'PATCH', `/company/task-templates/${created.id}`, { estimatedHours: 1 });
  expect((await ok('m2', 'GET', '/company/task-templates')).some((x: any) => x.id === created.id)).toBe(false);
  expect((await ok('m1', 'GET', '/company/task-templates?manage=true')).every((x: any) => x.can_edit)).toBe(true);
});

test('Quyền hạn cấu hình độc lập theo chức vụ (ghi đè mặc định theo tầng)', async () => {
  const p = (await ok('owner', 'GET', '/company/positions')).positions.find((x: any) => x.system_key === 'dept_head');
  expect((await call('m1', 'PATCH', `/company/positions/${p.id}`, { capabilities: { approve_order: true } })).status).toBe(403);
  await ok('owner', 'PATCH', `/company/positions/${p.id}`, { capabilities: { approve_order: true } });
  expect((await ok('m1', 'GET', '/auth/me')).authority.caps).toContain('approve_order');
  await ok('owner', 'PATCH', `/company/positions/${p.id}`, { capabilities: {} });
  expect(await q1(`SELECT 1 FROM audit_logs WHERE action='position.updated'`)).toBeTruthy();
});
