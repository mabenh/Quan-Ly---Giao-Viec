/* Kiểm thử v14: OTP khi đăng ký, đăng nhập bằng mã, quên mật khẩu, đổi mật khẩu bằng OTP; tên rút gọn công ty. */
process.env.OTP_DEV_ECHO = 'true';
process.env.OTP_REQUIRED = 'true';
process.env.DATABASE_URL = process.env.TEST_DATABASE_URL || 'postgresql://app:app@localhost:5432/teamapp_test';
process.env.DISABLE_SCHEDULER = 'true';
process.env.UPLOAD_DIR = '/tmp/teamapp-test-uploads';

import { INestApplication } from '@nestjs/common';
import { closePool, q, q1 } from '../src/db/db';
import { createApp } from '../src/main';
import { resetDb, seed } from '../src/db/seed';

let app: INestApplication;
let url = '';
const tok: Record<string, string> = {};
let companyId = '';
const mid: Record<string, string> = {};
async function call(who: string, method: string, path: string, body?: any) {
  const r = await fetch(url + path, { method, headers: { 'Content-Type': 'application/json', ...(tok[who] ? { Authorization: `Bearer ${tok[who]}` } : {}) }, body: body ? JSON.stringify(body) : undefined });
  return { status: r.status, body: (await r.json().catch(() => ({}))) as any };
}
async function ok(who: string, method: string, path: string, body?: any) {
  const r = await call(who, method, path, body);
  if (r.status >= 300) throw new Error(`${method} ${path} -> ${r.status} ${JSON.stringify(r.body)}`);
  return r.body;
}

beforeAll(async () => {
  await resetDb();
  app = await createApp();
  await app.listen(0);
  url = `http://127.0.0.1:${(app.getHttpServer().address() as any).port}/api/v1`;
  const s = await seed(url);
  companyId = s.companyId;
  for (const [k, p] of Object.entries({ owner: '0901000001', admin: '0901000002', m1: '0901000003', m2: '0901000004', e1: '0901000007', e2: '0901000008', e3: '0901000009', e4: '0901000010', hr: '0901000012' })) { const r = await ok('', 'POST', '/auth/login', { phone: p, password: 'Demo@123' }); tok[k] = r.access_token; mid[k] = (await ok(k, 'GET', '/auth/me')).member_id; }
});
afterAll(async () => { await app.close(); await closePool(); });



test('Đăng ký bắt buộc mã OTP; mã sai/hết lượt; mã đúng → tạo tài khoản và đánh dấu đã xác thực SĐT', async () => {
  const cfg = await ok('', 'GET', '/auth/otp/config');
  expect(cfg.required_for_register).toBe(true);
  expect((await call('', 'POST', '/auth/register', { phone: '0987000111', name: 'Trần Văn Mới', password: 'Matkhau@1' })).body.error.code).toBe('OTP_REQUIRED');
  const r = await ok('', 'POST', '/auth/otp/request', { phone: '0987000111', purpose: 'register' });
  expect(r.dev_code).toMatch(/^\d{6}$/); expect(r.channel).toBe('manual');
  // gửi lại ngay → phải đợi
  expect((await call('', 'POST', '/auth/otp/request', { phone: '0987000111', purpose: 'register' })).body.error.code).toBe('OTP_TOO_SOON');
  const bad = r.dev_code === '000000' ? '111111' : '000000';
  const e1 = await call('', 'POST', '/auth/register', { phone: '0987000111', name: 'Trần Văn Mới', password: 'Matkhau@1', otpCode: bad });
  expect(e1.body.error.code).toBe('OTP_INVALID');
  const reg = await ok('', 'POST', '/auth/register', { phone: '0987000111', name: 'Trần Văn Mới', password: 'Matkhau@1', otpCode: r.dev_code });
  expect(reg.access_token).toBeTruthy();
  expect((await q1(`SELECT phone_verified_at FROM users WHERE phone='0987000111'`)).phone_verified_at).toBeTruthy();
  // mã đã dùng không dùng lại được
  expect((await call('', 'POST', '/auth/register', { phone: '0987000111', name: 'X Y Z W', password: 'Matkhau@1', otpCode: r.dev_code })).status).toBe(409);
  // SĐT đã đăng ký → không gửi mã đăng ký
  expect((await call('', 'POST', '/auth/otp/request', { phone: '0901000007', purpose: 'register' })).body.error.code).toBe('PHONE_TAKEN');
});

test('Sai mã 5 lần thì khóa mã', async () => {
  await q(`DELETE FROM otp_codes WHERE phone='0901000008'`);
  const r = await ok('', 'POST', '/auth/otp/request', { phone: '0901000008', purpose: 'login' });
  const bad = r.dev_code === '000000' ? '111111' : '000000';
  for (let i = 0; i < 5; i++) expect((await call('', 'POST', '/auth/login-otp', { phone: '0901000008', code: bad })).body.error.code).toBe('OTP_INVALID');
  expect((await call('', 'POST', '/auth/login-otp', { phone: '0901000008', code: r.dev_code })).body.error.code).toBe('OTP_LOCKED');
});

test('Đăng nhập bằng mã OTP', async () => {
  await q(`DELETE FROM otp_codes WHERE phone='0901000009'`);
  const r = await ok('', 'POST', '/auth/otp/request', { phone: '0901000009', purpose: 'login' });
  const s = await ok('', 'POST', '/auth/login-otp', { phone: '0901000009', code: r.dev_code });
  expect(s.access_token).toBeTruthy(); expect(s.member_id).toBeTruthy();
});

test('Quên mật khẩu: OTP + mật khẩu mới; phiên cũ bị thu hồi; số chưa đăng ký vẫn phản hồi như nhau', async () => {
  const old = (await ok('', 'POST', '/auth/login', { phone: '0901000010', password: 'Demo@123' })).refresh_token;
  const r = await ok('', 'POST', '/auth/otp/request', { phone: '0901000010', purpose: 'reset' });
  const s = await ok('', 'POST', '/auth/reset-password', { phone: '0901000010', code: r.dev_code, newPassword: 'MoiMoi@2026' });
  expect(s.access_token).toBeTruthy();
  expect((await call('', 'POST', '/auth/login', { phone: '0901000010', password: 'Demo@123' })).status).toBe(401);
  await ok('', 'POST', '/auth/login', { phone: '0901000010', password: 'MoiMoi@2026' });
  expect((await call('', 'POST', '/auth/refresh', { refresh_token: old })).status).toBe(401);
  // số chưa đăng ký: phản hồi giống hệt nhưng không gửi thật
  const g = await ok('', 'POST', '/auth/otp/request', { phone: '0977123456', purpose: 'reset' });
  expect(g.sent).toBe(true);
  expect((await q1(`SELECT delivery FROM otp_codes WHERE phone='0977123456'`)).delivery).toBe('skipped');
});

test('Đổi mật khẩu bằng OTP (không cần mật khẩu cũ)', async () => {
  const r = await ok('e2', 'POST', '/auth/otp/request-change');
  expect(r.phone_masked).toBe('090****008');
  await ok('e2', 'POST', '/auth/change-password', { otpCode: r.dev_code, newPassword: 'DoiQuaOtp@1' });
  await ok('', 'POST', '/auth/login', { phone: '0901000008', password: 'DoiQuaOtp@1' });
  expect((await call('e3', 'POST', '/auth/change-password', { oldPassword: 'sai', newPassword: 'Abcdefgh1' })).status).toBe(422);
});

test('Quản trị nền tảng xem nhật ký OTP (mã chờ hỗ trợ khi chưa có SMS)', async () => {
  const plat = (await ok('', 'POST', '/auth/login', { phone: '0900000000', password: 'Demo@123' })).access_token; tok.plat = plat;
  await ok('', 'POST', '/auth/otp/request', { phone: '0987000222', purpose: 'register' });
  const l = await ok('plat', 'GET', '/platform/otp-log?phone=0987000222');
  expect(l.items[0].manual_code).toMatch(/^\d{6}$/);
  expect((await call('admin', 'GET', '/platform/otp-log')).status).toBe(403);
});

test('Tên rút gọn công ty: tự động và tùy chỉnh', async () => {
  const me = await ok('owner', 'GET', '/auth/me');
  expect(me.company_short_name).toBe('Demo Việt');
  expect(me.memberships[0].company_short_name).toBe('Demo Việt');
  await ok('admin', 'PATCH', '/company/profile', { shortName: 'DV Group' });
  expect((await ok('owner', 'GET', '/auth/me')).company_short_name).toBe('DV Group');
  await ok('admin', 'PATCH', '/company/profile', { shortName: '' });
  expect((await ok('owner', 'GET', '/company')).short_name_auto).toBe('Demo Việt');
  expect((await call('e1', 'PATCH', '/company/profile', { shortName: 'x' })).status).toBe(403);
});

test('v19: thống kê trang chủ, nhắc nhở đơn hàng, phản ánh toàn đơn vị', async () => {
  const s = await ok('owner', 'GET', '/dash/home-stats');
  expect(s.scope).toBe('company'); expect(s.people.total).toBeGreaterThan(5); expect(s.departments.count).toBeGreaterThan(0);
  expect((await ok('m1', 'GET', '/dash/home-stats')).scope).toBe('groups');
  expect((await ok('e1', 'GET', '/dash/home-stats')).scope).toBe('none');
  const o = await ok('owner', 'GET', '/dash/order-alerts');
  expect(o).toHaveProperty('running'); expect(o).toHaveProperty('overdue');
  expect(Array.isArray(await ok('owner', 'GET', '/member-reports?scope=all'))).toBe(true);
});
