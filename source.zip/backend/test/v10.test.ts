/* Kiểm thử v10: thêm nhân viên theo tầng/phòng ban, nhóm theo phòng ban, quyết định nhân sự, ghi nhận chấm công, loại giấy phép, thông báo đơn hàng. */
process.env.DATABASE_URL = process.env.TEST_DATABASE_URL || 'postgresql://app:app@localhost:5432/teamapp_test';
process.env.DISABLE_SCHEDULER = 'true';
process.env.UPLOAD_DIR = '/tmp/teamapp-test-uploads';

import { INestApplication } from '@nestjs/common';
import { closePool, q1 } from '../src/db/db';
import { createApp } from '../src/main';
import { resetDb, seed } from '../src/db/seed';

let app: INestApplication;
let url = '';
const tok: Record<string, string> = {};
const ids: Record<string, string> = {};
async function call(who: string, method: string, path: string, body?: any) {
  const r = await fetch(url + path, { method, headers: { 'Content-Type': 'application/json', ...(tok[who] ? { Authorization: `Bearer ${tok[who]}` } : {}) }, body: body ? JSON.stringify(body) : undefined });
  return { status: r.status, body: (await r.json().catch(() => ({}))) as any };
}
async function ok(who: string, method: string, path: string, body?: any) {
  const r = await call(who, method, path, body);
  if (r.status >= 300) throw new Error(`${method} ${path} -> ${r.status} ${JSON.stringify(r.body)}`);
  return r.body;
}
const PH: Record<string, string> = { owner: '0901000001', admin: '0901000002', m1: '0901000003', m2: '0901000004', e1: '0901000007', e2: '0901000008', e3: '0901000009', hr: '0901000012', kho: '0901000014' };
const dept: Record<string, string> = {};

beforeAll(async () => {
  await resetDb();
  app = await createApp();
  await app.listen(0);
  url = `http://127.0.0.1:${(app.getHttpServer().address() as any).port}/api/v1`;
  await seed(url);
  for (const [k, p] of Object.entries(PH)) {
    tok[k] = (await ok('', 'POST', '/auth/login', { phone: p, password: 'Demo@123' })).access_token;
    ids[k] = (await q1(`SELECT cm.id FROM company_members cm JOIN users u ON u.id=cm.user_id WHERE u.phone=$1`, [p])).id;
  }
  for (const [k, n] of Object.entries({ sx: 'Sản xuất - Vận hành', kd: 'Kinh doanh', kho: 'Kho vận' })) dept[k] = (await q1(`SELECT id FROM departments WHERE name=$1`, [n])).id;
  for (const [k, n] of Object.entries({ g1: 'Nhóm Vận hành', g3: 'Tổ Đóng gói', g2: 'Nhóm Kinh doanh' })) ids[k] = (await q1(`SELECT id FROM groups WHERE name=$1`, [n])).id;
});
afterAll(async () => { await app.close(); await closePool(); });

test('Thêm nhân viên: tầng 3–5 được thêm; tầng 5 chỉ vào phòng ban của mình; tầng 7 không được', async () => {
  const worker = (await q1(`SELECT id FROM positions WHERE system_key='worker'`)).id;
  expect((await call('e1', 'POST', '/company/members', { phone: '0912000001', name: 'Nguyễn Văn Mới' })).status).toBe(403);
  expect((await call('m1', 'POST', '/company/members', { phone: '0912000002', name: 'Trần Văn Kinh', departmentId: dept.kd })).status).toBe(403);
  const r = await ok('m1', 'POST', '/company/members', { phone: '0912000003', name: 'Lê Thị Xưởng', positionId: worker, groupId: ids.g1 });
  const m = await q1(`SELECT department_id, position_id, status FROM company_members WHERE id=$1`, [r.id]);
  expect(m.department_id).toBe(dept.sx);
  expect(m.position_id).toBe(worker);
  expect(m.status).toBe('pending_hr');                       // tầng 5: nhân sự kiểm duyệt
  const a = await ok('admin', 'POST', '/company/members', { phone: '0912000004', name: 'Phạm Văn Kho', departmentId: dept.kho, positionId: worker });
  expect(a.status).toBe('active');                            // tầng 4: hiệu lực ngay
  expect((await call('m1', 'POST', '/company/members', { phone: '0912000005', name: 'Vượt Quyền', positionId: (await q1(`SELECT id FROM positions WHERE system_key='dept_head'`)).id })).status).toBe(403);
});

test('Nhóm: tầng 5 tạo nhóm trong phòng mình, chỉ định trưởng nhóm đơn vị mình quản lý; tầng 4 chọn phòng ban', async () => {
  expect((await call('m2', 'POST', '/groups', { name: 'Nhóm lấn phòng', departmentId: dept.sx })).status).toBe(403);
  expect((await call('m2', 'POST', '/groups', { name: 'Nhóm KD 2', memberIds: [ids.e1] })).status).toBe(403); // e1 thuộc Sản xuất
  const g = await ok('m1', 'POST', '/groups', { name: 'Tổ Bốc xếp', memberIds: [ids.e1, ids.e2] });
  expect(g.department_id).toBe(dept.sx);
  const g4 = await ok('admin', 'POST', '/groups', { name: 'Tổ Kho lạnh', departmentId: dept.kho, managerMemberId: ids.kho, memberIds: [] });
  expect(g4.department_id).toBe(dept.kho);
  expect(g4.manager_member_id).toBe(ids.kho);
  // Trưởng phòng Sản xuất chỉ định trưởng nhóm Tổ Đóng gói (nhóm thuộc phòng mình, do admin tạo)
  await ok('m1', 'PATCH', `/groups/${ids.g3}`, { leaderMemberId: ids.e3 });
  expect((await call('m2', 'PATCH', `/groups/${ids.g3}`, { leaderMemberId: ids.e3 })).status).toBe(403);
  expect((await call('e1', 'POST', '/groups', { name: 'Nhóm công nhân' })).status).toBe(403);
});

test('Quyết định nhân sự: tầng 4 ra quyết định kèm chức vụ mới; tầng 5 không', async () => {
  const foreman = (await q1(`SELECT id FROM positions WHERE system_key='foreman'`)).id;
  const body = { memberId: ids.e2, decisionType: 'promotion', effectiveDate: new Date(Date.now() + 86400000).toISOString().slice(0, 10), handoverDeadline: new Date(Date.now() + 2 * 86400000).toISOString(),
    newPositionId: foreman, reason: 'Hoàn thành tốt nhiệm vụ, đủ năng lực điều hành tổ' };
  expect((await call('m1', 'POST', '/decisions', body)).status).toBe(403);
  const d = await ok('admin', 'POST', '/decisions', body);
  expect(d.code).toMatch(/^QD-/);
  expect((await q1(`SELECT new_position_id FROM personnel_decisions WHERE id=$1`, [d.id])).new_position_id).toBe(foreman);
});

test('Ghi nhận chấm công: quản lý ghi nhận, nhân viên tự khai báo; trùng người/nhiệm vụ/thời gian bị từ chối; không tính tăng ca', async () => {
  const day = new Date(); day.setDate(day.getDate() - 2); day.setHours(8, 0, 0, 0);
  const s = day.toISOString(); const e = new Date(day.getTime() + 4 * 3600000).toISOString();
  const t = await q1(`SELECT t.id FROM tasks t JOIN task_assignees a ON a.task_id=t.id AND a.active WHERE a.company_member_id=$1 AND NOT t.is_chain LIMIT 1`, [ids.e1]);
  const r = await ok('m1', 'POST', '/attendance-records', { memberIds: [ids.e1], kind: 'timeclock_down', startAt: s, endAt: e, taskId: t.id, note: 'Máy chấm công cổng 2 hỏng cả buổi sáng' });
  expect(r.message).toMatch(/đã được ghi nhận/);
  expect(await q1(`SELECT 1 FROM notifications WHERE member_id=$1 AND type='attendance.recorded'`, [ids.e1])).toBeTruthy();
  expect(await q1(`SELECT 1 FROM overtime_records WHERE member_id=$1 AND start_at=$2`, [ids.e1, s])).toBeFalsy();
  // Nhân viên tự khai cùng việc/thời gian -> từ chối
  const dup = await call('e1', 'POST', '/attendance-records', { kind: 'forgot', startAt: s, endAt: e, taskId: t.id, note: 'Quên chấm công buổi sáng' });
  expect(dup.status).toBe(409); expect(dup.body.error.code).toBe('ALREADY_RECORDED');
  // Cùng nhiệm vụ trong ngày (khác giờ) cũng bị từ chối
  expect((await call('e1', 'POST', '/attendance-records', { kind: 'forgot', startAt: new Date(day.getTime() + 5 * 3600000).toISOString(), endAt: new Date(day.getTime() + 6 * 3600000).toISOString(), taskId: t.id, note: 'Làm thêm cùng việc' })).status).toBe(409);
  // Tự khai báo công việc trùng thời gian với ghi nhận của quản lý -> từ chối
  expect((await call('e1', 'POST', '/work-records', { title: 'Kiểm kho buổi sáng', recordType: 'support', reasonNotInSystem: 'Phát sinh', locationSource: 'unknown', startAt: s, endAt: e, requesterMemberId: ids.m1 })).status).toBe(409);
  // Nhân viên tự khai ngày khác -> chờ quản lý xác nhận
  const d2 = new Date(day.getTime() - 86400000);
  const own = await ok('e2', 'POST', '/attendance-records', { kind: 'offsite', place: 'Kho đối tác Long An', startAt: d2.toISOString(), endAt: new Date(d2.getTime() + 3 * 3600000).toISOString(), note: 'Hỗ trợ kiểm hàng tại kho đối tác' });
  expect(own.status).toBe('submitted');
  const rec = await ok('m1', 'GET', '/attendance-records?scope=review');
  const x = rec.find((a: any) => a.id === own.ids[0]);
  expect(x).toBeTruthy();
  // Quản lý ghi nhận trùng bản tự khai báo của nhân viên -> từ chối
  expect((await call('m1', 'POST', '/attendance-records', { memberIds: [ids.e2], kind: 'offsite', place: 'Long An', startAt: d2.toISOString(), endAt: new Date(d2.getTime() + 3600000).toISOString(), note: 'Ghi nhận lại' })).status).toBe(409);
  await ok('m1', 'POST', `/attendance-records/${x.id}/review`, { decision: 'confirm' });
  expect((await call('e1', 'POST', '/attendance-records', { memberIds: [ids.e2], startAt: s, endAt: e, note: 'Công nhân ghi hộ' })).status).toBe(403);
});

test('Giấy phép: tạo loại (bộ phận tiếp nhận, trường thông tin, dùng 1 lần/nhiều lần); người đi cùng; nhân viên bộ phận nhận tin nhưng chỉ cấp quản lý duyệt', async () => {
  const pt = await ok('admin', 'POST', '/permit-types', { name: 'Giấy công tác ngoài', departmentId: dept.kho, usage: 'single', allowCompanions: true,
    fields: [{ key: 'noi_den', label: 'Nơi đến', type: 'text', required: true }, { key: 'phuong_tien', label: 'Phương tiện', type: 'text' }] });
  expect(pt.usage).toBe('single');
  const staff = await ok('admin', 'POST', '/company/members', { phone: '0912000099', name: 'Võ Thị Kho Phó', departmentId: dept.kho, positionId: (await q1(`SELECT id FROM positions WHERE system_key='staff'`)).id });
  const p = await ok('m1', 'POST', '/permits', { typeId: pt.id, holderId: ids.e1, companionIds: [ids.e2], data: { noi_den: 'Kho đối tác' }, validFrom: new Date().toISOString(), validTo: new Date(Date.now() + 86400000).toISOString() });
  expect(p.companions.map((c: any) => c.id)).toEqual([ids.e2]);
  expect(p.issuer_name).toBeTruthy();
  expect(await q1(`SELECT 1 FROM notifications WHERE member_id=$1 AND type='permit.pending' AND reference_id=$2`, [staff.id, p.id])).toBeTruthy(); // nhân viên bộ phận nhận tin
  const stTok = (await ok('', 'POST', '/auth/login', { phone: '0912000099', password: 'Demo@123' }).catch(() => null))?.access_token;
  if (stTok) { tok.st = stTok; expect((await call('st', 'POST', `/permits/${p.id}/decide`, { decision: 'approve' })).status).toBe(403); }
  expect((await ok('e2', 'GET', `/permits/${p.id}`)).id).toBe(p.id);     // người đi cùng xem được
  await ok('kho', 'POST', `/permits/${p.id}/decide`, { decision: 'approve' });   // trưởng bộ phận kho duyệt
  const u = await ok('e1', 'POST', `/permits/${p.id}/use`);
  expect(u.status).toBe('closed');
  expect((await call('e1', 'POST', `/permits/${p.id}/use`)).status).toBe(409);
});

test('Đơn hàng: nhóm điều hành nhận tin khi lập; nhóm công đoạn nhận 2 lần (khi duyệt và khi công đoạn bắt đầu)', async () => {
  const typeId = (await q1(`SELECT id FROM task_types WHERE name='Sản xuất'`))?.id || (await q1(`SELECT id FROM task_types LIMIT 1`)).id;
  const o = await ok('m2', 'POST', '/tasks', { title: 'Đơn bao bì Tân Phú', description: 'Sản xuất 3.000 túi', groupId: ids.g2, isChain: true, taskTypeId: typeId, complexity: 'medium', requirementLevel: 'normal',
    estimatedHours: 8, dueAt: new Date(Date.now() + 6 * 86400000).toISOString(), criteria: [{ direction: 'output', criterion: 'Giao đủ' }] });
  expect(await q1(`SELECT 1 FROM notifications WHERE member_id=$1 AND type='order.created' AND reference_id=$2`, [ids.e3, o.id])).toBeTruthy();
  await ok('m2', 'POST', '/tasks', { parentId: o.id, title: 'Tính toán nguyên liệu', groupId: ids.g1, stageNo: 1 });
  await ok('m2', 'POST', '/tasks', { parentId: o.id, title: 'Đóng gói', groupId: ids.g3, stageNo: 2 });
  expect(await q1(`SELECT 1 FROM notifications WHERE member_id=$1 AND type='order.stage_assigned' AND reference_id=$2`, [ids.e1, o.id])).toBeFalsy(); // chưa duyệt
  await ok('m1', 'POST', `/chains/${o.id}/order`, { action: 'review' });
  await ok('admin', 'POST', `/chains/${o.id}/order`, { action: 'approve' });
  expect(await q1(`SELECT 1 FROM notifications WHERE member_id=$1 AND type='order.stage_assigned' AND reference_id=$2`, [ids.e2, o.id])).toBeTruthy();  // lần 1 (nhóm g1)
  expect(await q1(`SELECT 1 FROM notifications WHERE member_id=$1 AND type='order.stage_assigned' AND reference_id=$2`, [ids.e3, o.id])).toBeTruthy();  // lần 1 (nhóm g3)
  const s1 = await q1(`SELECT id FROM tasks WHERE parent_id=$1 AND stage_no=1`, [o.id]);
  expect(await q1(`SELECT 1 FROM notifications WHERE member_id=$1 AND type='task.stage_started' AND reference_id=$2`, [ids.e2, s1.id])).toBeTruthy();   // lần 2 (công đoạn 1 bắt đầu)
});
