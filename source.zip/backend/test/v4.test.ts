/* Kiểm thử v4: việc nhiều giai đoạn/phân lớp, nghiệm thu đúng cấp, trở ngại giao việc xử lý, khai báo nhanh, vai trò, điểm mới. */
process.env.DATABASE_URL = process.env.TEST_DATABASE_URL || 'postgresql://app:app@localhost:5432/teamapp_test';
process.env.DISABLE_SCHEDULER = 'true';
process.env.UPLOAD_DIR = '/tmp/teamapp-test-uploads';

import { INestApplication } from '@nestjs/common';
import { closePool, q1 } from '../src/db/db';
import { createApp } from '../src/main';
import { resetDb, seed } from '../src/db/seed';

let app: INestApplication;
let url = '';
const tok: Record<string, string> = {};
const ids: Record<string, string> = {};
async function call(who: string, method: string, path: string, body?: any) {
  const r = await fetch(url + path, { method, headers: { 'Content-Type': 'application/json', ...(tok[who] ? { Authorization: `Bearer ${tok[who]}` } : {}) }, body: body ? JSON.stringify(body) : undefined });
  return { status: r.status, body: (await r.json().catch(() => ({}))) as any };
}
async function ok(who: string, method: string, path: string, body?: any) {
  const r = await call(who, method, path, body);
  if (r.status >= 300) throw new Error(`${method} ${path} -> ${r.status} ${JSON.stringify(r.body)}`);
  return r.body;
}
const PH: Record<string, string> = { owner: '0901000001', admin: '0901000002', m1: '0901000003', m2: '0901000004', e1: '0901000007', e2: '0901000008', e3: '0901000009' };
const done = async (who: string, id: string, reviewer: string) => {
  await ok(who, 'POST', `/tasks/${id}/start`);
  await ok(who, 'POST', `/tasks/${id}/submit`, { outputDescription: 'Đã xong phần việc' });
  return ok(reviewer, 'POST', `/tasks/${id}/review`, { decision: 'approve', scores: { output: 90, quality: 85, schedule: 100, process: 80 } });
};

beforeAll(async () => {
  await resetDb();
  app = await createApp();
  await app.listen(0);
  url = `http://127.0.0.1:${(app.getHttpServer().address() as any).port}/api/v1`;
  await seed(url);
  for (const [k, p] of Object.entries(PH)) {
    tok[k] = (await ok('', 'POST', '/auth/login', { phone: p, password: 'Demo@123' })).access_token;
    ids[k] = (await q1(`SELECT cm.id FROM company_members cm JOIN users u ON u.id=cm.user_id WHERE u.phone=$1`, [p])).id;
  }
  ids.g1 = (await q1(`SELECT id FROM groups WHERE name='Nhóm Vận hành'`)).id;
  ids.g2 = (await q1(`SELECT id FROM groups WHERE name='Nhóm Kinh doanh'`)).id;
  ids.root = (await q1(`SELECT id FROM tasks WHERE title='Nhập lô hàng nước giải khát tháng 11'`)).id;
});
afterAll(async () => { await app.close(); await closePool(); });

describe('Việc nhiều giai đoạn', () => {
  test('Giai đoạn sau tự mở khi giai đoạn trước xong; mỗi người chỉ thấy phần việc của mình; việc khung tự chờ nghiệm thu', async () => {
    const root = await ok('m1', 'GET', `/tasks/${ids.root}`);
    expect(root.children.length).toBe(4);
    const byTitle = (t: string) => root.children.find((c: any) => c.title.startsWith(t));
    expect(byTitle('Đặt hàng').status).toBe('completed');
    expect(byTitle('Nhận hàng').status).toBe('not_started');
    expect(byTitle('Kiểm hàng').status).toBe('not_started');
    expect(byTitle('Nhập kho').status).toBe('waiting');
    expect(root.active_stage).toBe(2);
    // nhân viên chỉ thấy phần việc của mình
    expect((await call('e2', 'GET', `/tasks/${byTitle('Kiểm hàng').id}`)).status).toBe(404);
    expect((await call('e1', 'POST', `/tasks/${byTitle('Nhập kho').id}/start`)).status).toBe(409);
    // giai đoạn 2 chạy song song, hai người khác nhau
    await done('e2', byTitle('Nhận hàng').id, 'm1');
    expect((await ok('m1', 'GET', `/tasks/${byTitle('Nhập kho').id}`)).status).toBe('waiting');
    await done('e3', byTitle('Kiểm hàng').id, 'm1');
    expect((await ok('m1', 'GET', `/tasks/${byTitle('Nhập kho').id}`)).status).toBe('not_started');
    const n = await ok('e1', 'GET', '/notifications');
    expect(n.items.some((i: any) => i.type === 'task.stage_started')).toBe(true);
    await done('e1', byTitle('Nhập kho').id, 'm1');
    const r2 = await ok('m1', 'GET', `/tasks/${ids.root}`);
    expect(r2.status).toBe('pending_review');
    expect(r2.permissions.can_submit).toBe(false);
    // việc khung do m1 vừa giao vừa phụ trách -> cấp trên trực tiếp (Admin) nghiệm thu; không nhảy cấp sang người khác
    expect(r2.reviewer_id).toBe(ids.admin);
    expect((await call('m1', 'POST', `/tasks/${ids.root}/review`, { decision: 'approve', scores: { output: 90, quality: 90, schedule: 90, process: 90 } })).status).toBe(403);
    expect((await call('owner', 'POST', `/tasks/${ids.root}/review`, { decision: 'approve', scores: { output: 90, quality: 90, schedule: 90, process: 90 } })).status).toBe(403);
    const fin = await ok('admin', 'POST', `/tasks/${ids.root}/review`, { decision: 'approve', scores: { output: 90, quality: 90, schedule: 90, process: 90 } });
    expect(fin.status).toBe('completed');
  });

  test('Phân lớp qua nhóm mình không quản lý -> chờ cấp trên duyệt; quản lý lớp dưới chỉ được đổi người phụ trách', async () => {
    const root = await ok('m1', 'POST', '/tasks', { title: 'Chuỗi việc liên nhóm', description: 'Đơn hàng đi qua Vận hành rồi Kinh doanh', groupId: ids.g1, ownerMemberId: ids.e1,
      taskTypeId: (await q1(`SELECT task_type_id FROM tasks WHERE id=$1`, [ids.root])).task_type_id, complexity: 'medium', requirementLevel: 'normal', estimatedHours: 8,
      dueAt: new Date(Date.now() + 3 * 86400000).toISOString(), criteria: [{ direction: 'output', criterion: 'Hoàn tất chuỗi' }] });
    await ok('m1', 'POST', '/tasks', { parentId: root.id, title: 'Soạn hàng', groupId: ids.g1, ownerMemberId: ids.e1, stageNo: 1 });
    const cross = await ok('m1', 'POST', '/tasks', { parentId: root.id, title: 'Báo giá & chốt với khách', groupId: ids.g2, stageNo: 2 });
    expect(cross.status).toBe('pending_approval');
    expect(cross.approver_id).toBe(ids.admin);
    expect(cross.owner_id).toBe(ids.m2); // quản lý nhóm nhận phần việc
    const ap = await ok('admin', 'POST', `/tasks/${cross.id}/approve`, { decision: 'approve' });
    expect(ap.status).toBe('waiting');
    // m2 (quản lý lớp dưới) chỉ được đổi người phụ trách
    expect((await call('m2', 'PATCH', `/tasks/${cross.id}`, { title: 'Đổi tên' })).status).toBe(403);
    const ch = await ok('m2', 'PATCH', `/tasks/${cross.id}`, { ownerMemberId: ids.e3, reason: 'Giao cho Lan phụ trách khách này' });
    expect(ch.owner_id).toBe(ids.e3);
    // người giao việc gốc được sửa nội dung trước khi nghiệm thu
    const ed = await ok('m1', 'PATCH', `/tasks/${cross.id}`, { description: 'Báo giá trước 15h, gửi kèm hợp đồng', reason: 'Khách đổi yêu cầu' });
    expect(ed.description).toContain('hợp đồng');
    // m2 tạo phân lớp con cho người dưới quyền mà không cần khai lại
    const sub = await ok('m2', 'POST', '/tasks', { parentId: cross.id, title: 'Gửi báo giá', groupId: ids.g2, ownerMemberId: ids.e3 });
    expect(sub.status).toBe('not_started');
    expect(sub.description).toContain('hợp đồng');
  });
});

describe('Trở ngại: quản lý tự giải quyết bằng giao việc, cấp trên giám sát và thay đổi', () => {
  test('Seed: báo cáo đã giao việc xử lý; cấp trên thấy và đổi người; việc xong -> chờ người báo cáo xác nhận', async () => {
    const w = await q1(`SELECT id FROM workplace_reports WHERE description LIKE 'Kệ hàng số 4%'`);
    const d = await ok('m1', 'GET', `/workplace-reports/${w.id}`);
    expect(d.status).toBe('task_assigned');
    expect(d.decided_by).toBe(ids.m1);
    expect(d.resolution_task_title).toBe('Gia cố kệ hàng số 4 khu B');
    expect(d.accountable.id).toBe(ids.admin);
    expect(d.accepted_by_default).toBe(true);
    const ov = await ok('admin', 'GET', '/workplace-reports?scope=oversight');
    expect(ov.some((x: any) => x.id === w.id)).toBe(true);
    expect((await call('e3', 'POST', `/workplace-reports/${w.id}/override-owner`, { memberId: ids.e1, reason: 'Thử đổi người xử lý' })).status).toBe(403);
    const o = await ok('admin', 'POST', `/workplace-reports/${w.id}/override-owner`, { memberId: ids.e1, reason: 'Giang có kinh nghiệm sửa kệ' });
    expect(o.assignee_id).toBe(ids.e1);
    expect(o.accepted_by_default).toBe(false);
    expect(o.updates.some((u: any) => u.status === 'override' && u.comment.includes('thay vì'))).toBe(true);
    await done('e1', o.resolution_task_id, 'm1');
    const after = await ok('e2', 'GET', `/workplace-reports/${w.id}`);
    expect(after.stage).toBe('reporter_confirm');
  });
});

describe('Khai báo nhanh & vai trò', () => {
  test('Việc thường ngày không cần lý do; ngoài vai trò cần lý do; thêm vào nhánh việc có sẵn', async () => {
    const t0 = new Date(Date.now() - 5 * 3600000).toISOString(); const t1 = new Date(Date.now() - 4 * 3600000).toISOString();
    const r = await ok('e3', 'POST', '/work-records', { locationSource: 'unknown',  recordType: 'routine', initiative: true, title: 'Kiểm đếm hàng trả về', startAt: t0, endAt: t1, groupId: ids.g1 });
    expect(r.in_role).toBe(true);
    expect(r.in_role_suggested).toBe(true);
    expect((await call('e3', 'POST', '/work-records', { locationSource: 'unknown',  recordType: 'outside_role', title: 'Phát tờ rơi', requesterMemberId: ids.m2, startAt: t0, endAt: t1 })).status).toBe(422);
    expect((await call('e3', 'POST', '/work-records', { locationSource: 'unknown',  recordType: 'branch', title: 'Bổ sung', startAt: t0, endAt: t1 })).status).toBe(422);
    const task = await q1(`SELECT t.id FROM tasks t JOIN task_assignees ta ON ta.task_id=t.id AND ta.company_member_id=$1 AND ta.active WHERE t.group_id=$2 AND t.parent_id IS NULL LIMIT 1`, [ids.e3, ids.g1]);
    const br = await ok('e3', 'POST', '/work-records', { locationSource: 'unknown',  recordType: 'branch', relatedTaskId: task.id, title: 'Dán thêm nhãn phụ', startAt: t0, endAt: t1 });
    expect(br.reviewer_member_id).toBe(ids.m1);
    const td = await ok('e3', 'GET', `/tasks/${task.id}`);
    expect(td.branch_records.some((x: any) => x.id === br.id)).toBe(true);
  });

  test('Việc ngoài vai trò được xác nhận là điểm cộng O, không trừ điểm người khác', async () => {
    const rec = await q1(`SELECT id FROM employee_work_records WHERE record_type='outside_role' AND employee_id=$1`, [ids.e2]);
    await ok('m1', 'POST', `/work-records/${rec.id}/reviews`, { decision: 'accept' });
    const rep = await ok('admin', 'GET', '/performance/live?periodType=month&scopeType=company');
    const e2 = rep.members.find((m: any) => m.member_id === ids.e2);
    expect(e2.out_role_hours).toBe(4);
    expect(e2.O).toBe(25);
    expect(e2.O_bonus).toBeCloseTo(2.5, 2);
    expect(e2.E).toBeCloseTo(Math.min(100, e2.E_base + 2.5), 1);
    const e3 = rep.members.find((m: any) => m.member_id === ids.e3);
    expect(e3.O_bonus).toBe(0);
  });

  test('Danh sách vai trò & số việc của thành viên trong nhóm ai cũng xem được', async () => {
    const roles = await ok('e1', 'GET', '/company/job-roles');
    expect(roles.some((r: any) => r.name === 'Nhân viên kho')).toBe(true);
    const g = await ok('e1', 'GET', `/groups/${ids.g1}`);
    const e2 = g.members.find((m: any) => m.member_id === ids.e2);
    expect(e2).toHaveProperty('doing');
    expect(e2).toHaveProperty('done_month');
    expect(g.members.some((m: any) => m.member_id === ids.m1)).toBe(true);
  });
});
