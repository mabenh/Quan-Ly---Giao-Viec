/* Kiểm thử v12: gói cộng thêm, gia hạn/chuyển/hủy gói có hoàn tiền; danh mục chức danh & cấp bậc tiếng Việt; danh mục phòng ban/bộ phận/nhóm. */
process.env.DATABASE_URL = process.env.TEST_DATABASE_URL || 'postgresql://app:app@localhost:5432/teamapp_test';
process.env.DISABLE_SCHEDULER = 'true';
process.env.UPLOAD_DIR = '/tmp/teamapp-test-uploads';

import { INestApplication } from '@nestjs/common';
import { closePool, q, q1 } from '../src/db/db';
import { createApp } from '../src/main';
import { resetDb, seed } from '../src/db/seed';

let app: INestApplication;
let url = '';
const tok: Record<string, string> = {};
let companyId = '';
async function call(who: string, method: string, path: string, body?: any) {
  const r = await fetch(url + path, { method, headers: { 'Content-Type': 'application/json', ...(tok[who] ? { Authorization: `Bearer ${tok[who]}` } : {}) }, body: body ? JSON.stringify(body) : undefined });
  return { status: r.status, body: (await r.json().catch(() => ({}))) as any };
}
async function ok(who: string, method: string, path: string, body?: any) {
  const r = await call(who, method, path, body);
  if (r.status >= 300) throw new Error(`${method} ${path} -> ${r.status} ${JSON.stringify(r.body)}`);
  return r.body;
}

beforeAll(async () => {
  await resetDb();
  app = await createApp();
  await app.listen(0);
  url = `http://127.0.0.1:${(app.getHttpServer().address() as any).port}/api/v1`;
  const s = await seed(url);
  companyId = s.companyId;
  for (const [k, p] of Object.entries({ owner: '0901000001', admin: '0901000002', m1: '0901000003', e1: '0901000007' })) tok[k] = (await ok('', 'POST', '/auth/login', { phone: p, password: 'Demo@123' })).access_token;
});
afterAll(async () => { await app.close(); await closePool(); });

test('Bảng giá: gói cộng thêm theo từng gói và giới hạn tổng thành viên', async () => {
  const p = await ok('', 'GET', '/plans');
  const small = p.plans.find((x: any) => x.plan === 'small');
  expect(small.addon).toMatchObject({ size: 10, price_vnd: 500000, max_total: 90, max_packs: 7 });
  expect(p.plans.find((x: any) => x.plan === 'medium').addon).toMatchObject({ size: 50, price_vnd: 2000000, max_total: 450 });
  expect(p.plans.find((x: any) => x.plan === 'large').addon).toMatchObject({ size: 100, price_vnd: 3500000 });
  const qn = await ok('owner', 'GET', `/subscriptions/quote?action=new&plan=small&packs=2`);
  expect(qn.member_limit).toBe(40); expect(qn.amount_vnd).toBe(1200000 + 1000000);
  expect((await call('owner', 'GET', `/subscriptions/quote?action=new&plan=small&packs=8`)).status).toBe(422);   // vượt 90 thành viên
});

test('Mua thêm gói cộng thêm giữa kỳ (tính theo ngày còn lại), gia hạn tính cả gói cộng thêm', async () => {
  // Đặt kỳ hiện tại: gói vừa, còn ~182 ngày
  await q(`UPDATE companies SET plan='medium', member_limit=100, addon_packs=0, plan_expires_at=now() + interval '182 days 12 hours' WHERE id=$1`, [companyId]);
  const qa = await ok('owner', 'GET', `/subscriptions/quote?action=addon&companyId=${companyId}&packs=1`);
  expect(qa.member_limit).toBe(150);
  expect(qa.amount_vnd).toBeGreaterThan(950000); expect(qa.amount_vnd).toBeLessThan(1050000);      // ≈ 2.000.000 × 182/365
  expect((await call('admin', 'POST', '/subscriptions/addons', { companyId, packs: 1 })).status).toBe(403);   // chỉ Owner
  await ok('owner', 'POST', '/subscriptions/addons', { companyId, packs: 1 });
  let c = await q1(`SELECT member_limit, addon_packs FROM companies WHERE id=$1`, [companyId]);
  expect(c).toEqual({ member_limit: 150, addon_packs: 1 });
  expect((await call('owner', 'POST', '/subscriptions/addons', { companyId, packs: 7 })).status).toBe(422);   // vượt 450
  const r = await ok('owner', 'GET', `/subscriptions/quote?action=renew&companyId=${companyId}`);
  expect(r.amount_vnd).toBe(4800000 + 2000000);
  const before = (await q1(`SELECT plan_expires_at FROM companies WHERE id=$1`, [companyId])).plan_expires_at;
  await ok('owner', 'POST', '/subscriptions/renew', { companyId });
  const after = (await q1(`SELECT plan_expires_at FROM companies WHERE id=$1`, [companyId])).plan_expires_at;
  expect(Math.round((+new Date(after) - +new Date(before)) / 86400000)).toBe(365);
});

test('Chuyển gói: khấu trừ giá trị còn lại; không đủ hạn mức thì từ chối; hủy gói hoàn tiền phần còn lại', async () => {
  await q(`UPDATE companies SET plan='medium', member_limit=150, addon_packs=1, plan_expires_at=now() + interval '91 days 6 hours' WHERE id=$1`, [companyId]);
  const used = (await q1(`SELECT count(*)::int AS n FROM company_members WHERE company_id=$1 AND status IN ('active','pending_hr')`, [companyId])).n;
  if (used > 20) expect((await call('owner', 'POST', '/subscriptions/change', { companyId, plan: 'small', addonPacks: 0 })).status).toBe(409);
  const qc = await ok('owner', 'GET', `/subscriptions/quote?action=change&companyId=${companyId}&plan=large&packs=0`);
  expect(qc.credit_vnd).toBeGreaterThan(1600000); expect(qc.credit_vnd).toBeLessThan(1800000);     // (4,8tr + 2tr) × 91/365 ≈ 1,7tr
  expect(qc.amount_vnd).toBe(12000000 - qc.credit_vnd);
  await ok('owner', 'POST', '/subscriptions/change', { companyId, plan: 'large', addonPacks: 0 });
  let c = await q1(`SELECT plan, member_limit, addon_packs, plan_expires_at FROM companies WHERE id=$1`, [companyId]);
  expect(c.plan).toBe('large'); expect(c.member_limit).toBe(500); expect(c.addon_packs).toBe(0);
  // Hạ xuống gói vừa ngay sau đó: giá trị còn lại lớn hơn giá gói mới -> hoàn phần dư
  const qd = await ok('owner', 'GET', `/subscriptions/quote?action=change&companyId=${companyId}&plan=medium&packs=0`);
  expect(qd.refund_vnd).toBeGreaterThan(7000000); expect(qd.amount_vnd).toBe(0);
  const d = await ok('owner', 'POST', '/subscriptions/change', { companyId, plan: 'medium', addonPacks: 0 });
  expect(d.subscription.status).toBe('refund_pending');
  // Hủy gói
  expect((await call('owner', 'POST', '/subscriptions/cancel-plan', { companyId, reason: 'Ngừng hoạt động' })).status).toBe(422);   // thiếu xác nhận
  const x = await ok('owner', 'POST', '/subscriptions/cancel-plan', { companyId, reason: 'Ngừng hoạt động', confirm: true });
  expect(x.quote.refund_vnd).toBeGreaterThan(4000000);
  expect(x.subscription.status).toBe('refund_pending');
  c = await q1(`SELECT plan FROM companies WHERE id=$1`, [companyId]);
  expect(c.plan).toBeNull();
  expect((await call('owner', 'POST', '/company/members', { phone: '0912000777', name: 'Người Mới Sau Hủy' })).status).toBe(402);   // hết gói
});

test('Chức danh có vai trò & nhiệm vụ; cấp bậc tiếng Việt; thêm nhân viên không cần chọn vai trò', async () => {
  const jt = await ok('m1', 'GET', '/company/job-titles');
  expect(jt.titles.length).toBeGreaterThan(150);
  const tp = jt.titles.find((t: any) => t.title === 'Trưởng phòng');
  expect(tp.tier).toBe(5); expect(tp.duties).toMatch(/phân công công việc/);
  expect(jt.grades).toContain('Nhân sự chuyên môn cao');
  expect(jt.grades).not.toContain('Senior');
});

test('Danh mục phòng ban chuẩn: tạo phòng ban + bộ phận + nhóm; thêm bộ phận; nhóm gắn bộ phận', async () => {
  await q(`UPDATE companies SET plan='large', member_limit=500, plan_expires_at=now() + interval '300 days' WHERE id=$1`, [companyId]);
  const cat = await ok('admin', 'GET', '/company/org-catalog');
  expect(cat.blocks).toHaveLength(4);
  expect(cat.departments.length).toBe(17);
  expect((await call('m1', 'POST', '/company/org-catalog/apply', { keys: ['finance'] })).status).toBe(403);
  const r = await ok('admin', 'POST', '/company/org-catalog/apply', { keys: ['finance', 'scm'] });
  expect(r.departments).toBe(2); expect(r.units).toBe(6); expect(r.groups).toBe(13);
  const again = await ok('admin', 'POST', '/company/org-catalog/apply', { keys: ['finance'] });
  expect(again.departments + again.units + again.groups).toBe(0);                 // không tạo trùng
  const depts = await ok('admin', 'GET', '/company/departments');
  const fin = depts.find((d: any) => d.name === 'Phòng Tài chính - Kế toán');
  expect(fin.block).toMatch(/Back-office/);
  expect(fin.units.find((u: any) => u.name === 'Bộ phận Kế toán thanh toán & Công nợ').groups).toHaveLength(3);
  const u = await ok('admin', 'POST', `/company/departments/${fin.id}/units`, { name: 'Bộ phận Kiểm soát chi phí' });
  const g = await ok('admin', 'POST', '/groups', { name: 'Nhóm Kiểm soát chi phí sản xuất', unitId: u.id, departmentId: fin.id });
  expect((await q1(`SELECT unit_id, department_id FROM groups WHERE id=$1`, [g.id]))).toEqual({ unit_id: u.id, department_id: fin.id });
  // Thêm nhân viên vào bộ phận, không truyền vai trò -> suy ra từ chức vụ
  const worker = (await q1(`SELECT id FROM positions WHERE system_key='staff'`)).id;
  const m = await ok('admin', 'POST', '/company/members', { phone: '0912000888', name: 'Kế Toán Viên Mới', unitId: u.id, positionId: worker, title: 'Kế toán thanh toán', jobGrade: 'Nhân sự có kinh nghiệm' });
  const row = await q1(`SELECT role, department_id, unit_id, job_grade, title FROM company_members WHERE id=$1`, [m.id]);
  expect(row).toEqual({ role: 'employee', department_id: fin.id, unit_id: u.id, job_grade: 'Nhân sự có kinh nghiệm', title: 'Kế toán thanh toán' });
});
