/* Kiểm thử v5: SEC-01 (bảo mật & quyền riêng tư) và UX-ABUSE-01 (báo cáo hành vi, chống lạm dụng). */
process.env.DATABASE_URL = process.env.TEST_DATABASE_URL || 'postgresql://app:app@localhost:5432/teamapp_test';
process.env.DISABLE_SCHEDULER = 'true';
process.env.UPLOAD_DIR = '/tmp/teamapp-test-uploads';

import { INestApplication } from '@nestjs/common';
import { closePool, q, q1 } from '../src/db/db';
import { createApp } from '../src/main';
import { resetDb, seed } from '../src/db/seed';
import { runRetention } from '../src/modules/privacy.controller';
import { resetRateLimits } from '../src/common/privacy';

let app: INestApplication;
let url = '';
const tok: Record<string, string> = {};
const ids: Record<string, string> = {};
const uid: Record<string, string> = {};
async function call(who: string, method: string, path: string, body?: any) {
  const r = await fetch(url + path, { method, headers: { 'Content-Type': 'application/json', ...(tok[who] ? { Authorization: `Bearer ${tok[who]}` } : {}) }, body: body ? JSON.stringify(body) : undefined });
  return { status: r.status, body: (await r.json().catch(() => ({}))) as any };
}
async function ok(who: string, method: string, path: string, body?: any) {
  const r = await call(who, method, path, body);
  if (r.status >= 300) throw new Error(`${method} ${path} -> ${r.status} ${JSON.stringify(r.body)}`);
  return r.body;
}
async function upload(who: string, parentType: string, parentId: string, name: string, mime: string) {
  const fd = new FormData();
  fd.append('file', new Blob([Buffer.from('demo-bytes')], { type: mime }), name);
  const r = await fetch(`${url}/files?parentType=${parentType}&parentId=${parentId}`, { method: 'POST', headers: { Authorization: `Bearer ${tok[who]}` }, body: fd });
  return { status: r.status, body: (await r.json().catch(() => ({}))) as any };
}
const PH: Record<string, string> = { owner: '0901000001', admin: '0901000002', m1: '0901000003', m2: '0901000004', e1: '0901000007', e2: '0901000008', e3: '0901000009', e4: '0901000010', hr: '0901000012', platform: '0900000000' };

beforeAll(async () => {
  await resetDb();
  app = await createApp();
  await app.listen(0);
  url = `http://127.0.0.1:${(app.getHttpServer().address() as any).port}/api/v1`;
  await seed(url);
  for (const [k, p] of Object.entries(PH)) {
    tok[k] = (await ok('', 'POST', '/auth/login', { phone: p, password: 'Demo@123' })).access_token;
    const u = await q1(`SELECT u.id, cm.id AS mid FROM users u LEFT JOIN company_members cm ON cm.user_id=u.id WHERE u.phone=$1`, [p]);
    uid[k] = u.id; ids[k] = u.mid;
  }
  ids.g1 = (await q1(`SELECT id FROM groups WHERE name='Nhóm Vận hành'`)).id;
});
afterAll(async () => { await app.close(); await closePool(); });

describe('SEC-01: cách ly, phân quyền theo trường, nhật ký', () => {
  test('SEC-T01: tài khoản doanh nghiệp khác không đọc được dữ liệu (sửa ID)', async () => {
    const r = await ok('', 'POST', '/auth/register', { phone: '0966555444', name: 'Chủ Công Ty B', password: 'Matkhau123' });
    tok.other = r.access_token;
    const s = await ok('other', 'POST', '/subscriptions', { plan: 'small', companyName: 'Công ty B', contactEmail: 'b@congtyb.vn' });
    tok.other = (await ok('other', 'POST', '/auth/switch-company', { companyId: s.company_id })).access_token;
    const task = await q1(`SELECT id FROM tasks LIMIT 1`);
    const file = await q1(`SELECT id FROM files LIMIT 1`);
    expect((await call('other', 'GET', `/tasks/${task.id}`)).status).toBe(404);
    expect((await call('other', 'GET', `/profiles/${uid.e1}`)).status).toBe(404);
    expect((await call('other', 'GET', `/groups/${ids.g1}`)).status).toBe(404);
    if (file) expect((await call('other', 'GET', `/files/${file.id}`)).status).toBe(404);
    expect((await call('other', 'GET', `/users/${uid.e1}/avatar`)).status).toBe(404);
    const denied = await q1(`SELECT count(*)::int AS n FROM data_access_logs WHERE actor_user_id=$1 AND result='denied'`, [r.user_id || (await q1(`SELECT id FROM users WHERE phone='0966555444'`)).id]);
    expect(denied.n).toBeGreaterThan(0);
  });

  test('SEC-T02: SĐT/email riêng không trả về cho người ngoài phạm vi; chủ thể tự chọn mức hiển thị', async () => {
    const mem = (who: string) => ok(who, 'GET', '/company/members');
    const e1For = async (who: string) => (await mem(who)).find((m: any) => m.id === ids.e1);
    expect((await e1For('m2')).phone).toBeNull();           // quản lý nhóm khác
    expect((await e1For('m2')).email).toBeNull();
    expect((await e1For('e2')).phone).toBe(PH.e1);          // cùng nhóm (mặc định "người liên quan")
    expect((await e1For('hr')).phone).toBe(PH.e1);          // nhân sự quản trị tài khoản
    expect((await e1For('e2')).hr_note).toBeUndefined();
    // không tìm nhân viên theo SĐT nếu không phải nhân sự
    const byPhone = await ok('e2', 'GET', `/company/members?q=${PH.e1}`);
    expect(byPhone.every((m: any) => m.id !== ids.e1 || m.phone === PH.e1)).toBe(true);
    await ok('e1', 'PATCH', '/me/privacy', { fields: { phone: 'only_me' } });
    const g = await ok('e2', 'GET', `/groups/${ids.g1}`);
    expect(g.members.find((m: any) => m.member_id === ids.e1).phone).toBeNull();
    await ok('e1', 'PATCH', '/me/privacy', { fields: { phone: 'related' } });
    // giới hạn liên hệ: người bị giới hạn không thấy SĐT
    await ok('e1', 'POST', '/me/contact-blocks', { memberId: ids.e2 });
    expect((await ok('e2', 'GET', `/groups/${ids.g1}`)).members.find((m: any) => m.member_id === ids.e1).phone).toBeNull();
    await ok('e1', 'DELETE', `/me/contact-blocks/${ids.e2}`);
  });

  test('SEC-T03: quản lý ngoài phạm vi không xem được đánh giá/hồ sơ; lần xem hợp lệ hiện trong lịch sử truy cập của chủ thể', async () => {
    expect((await call('m2', 'GET', `/performance/live?scopeType=member&scopeId=${ids.e1}`)).status).toBe(403);
    expect((await call('m2', 'GET', `/profiles/${uid.e1}`)).status).toBe(404);
    const v = await ok('m1', 'GET', `/profiles/${uid.e1}?purpose=Xem%20xét%20phân%20công`);
    expect(v.profile.dob ?? null).toBeNull(); // ngày sinh mặc định "chỉ mình tôi"
    expect(v.profile).not.toHaveProperty('id_number');
    const log = await ok('e1', 'GET', '/me/privacy-access-log');
    expect(log.some((l: any) => l.action === 'profile.view' && l.actor_member_id === ids.m1 && l.result === 'allowed')).toBe(true);
    expect(log.some((l: any) => l.action === 'profile.view' && l.result === 'denied')).toBe(true);
    // nhật ký chỉ ghi thêm
    await expect(q(`UPDATE data_access_logs SET reason='x'`)).rejects.toThrow(/append-only/);
  });

  test('SEC-T04: xuất báo cáo nhóm phải nêu lý do, có nhật ký và đóng dấu người xuất', async () => {
    expect((await call('m1', 'GET', `/performance/export?format=xlsx&scopeType=group&scopeId=${ids.g1}`)).status).toBe(422);
    expect((await call('e1', 'GET', `/performance/export?format=xlsx&scopeType=company&reason=thu%20xem`)).status).toBe(403);
    const r = await fetch(`${url}/performance/export?format=xlsx&scopeType=group&scopeId=${ids.g1}&reason=Họp%20đánh%20giá%20tháng`, { headers: { Authorization: `Bearer ${tok.m1}` } });
    expect(r.status).toBe(200);
    const l = await q1(`SELECT * FROM data_access_logs WHERE action='performance.export' AND actor_member_id=$1`, [ids.m1]);
    expect(l.reason).toContain('Họp');
    const self = await fetch(`${url}/performance/export?format=xlsx`, { headers: { Authorization: `Bearer ${tok.e1}` } });
    expect(self.status).toBe(200); // báo cáo của chính mình không cần lý do
  });

  test('SEC-T05/T06: tải dữ liệu của tôi (xác thực lại), yêu cầu đính chính có quy trình, người yêu cầu không tự xử lý', async () => {
    expect((await call('e1', 'POST', '/me/data-export', {})).status).toBe(401);
    expect((await call('e1', 'POST', '/me/data-export', { password: 'sai-mat-khau' })).status).toBe(422);
    const ex = await ok('e1', 'POST', '/me/data-export', { password: 'Demo@123' });
    const f = await fetch(`${url}/me/data-export/${ex.id}`, { headers: { Authorization: `Bearer ${tok.e1}` } });
    const json: any = await f.json();
    expect(json.account.phone).toBe(PH.e1);
    expect(Array.isArray(json.tasks)).toBe(true);
    expect((await call('e2', 'GET', `/me/data-export/${ex.id}`)).status).toBe(404);
    const req = await ok('e1', 'POST', '/me/data-requests', { type: 'correction', fieldKey: 'name', proposedValue: 'Vũ Thị Giang Hương', details: 'Tên trên giấy tờ có thêm chữ Hương' });
    expect(req.assigned_to).toBe(ids.hr);
    expect((await call('e2', 'GET', '/privacy/requests')).status).toBe(403);
    await ok('hr', 'POST', `/privacy/requests/${req.id}/resolve`, { status: 'completed', resolution: 'Đã cập nhật theo giấy tờ', apply: true });
    expect((await q1(`SELECT name FROM users WHERE id=$1`, [uid.e1])).name).toBe('Vũ Thị Giang Hương');
    const mine = await ok('e1', 'GET', '/me/data-requests');
    expect(mine.find((x: any) => x.id === req.id).status).toBe('completed');
    const own = await ok('hr', 'POST', '/me/data-requests', { type: 'restriction', details: 'Hạn chế người khác xem hồ sơ CV của tôi' });
    expect(own.assigned_to).not.toBe(ids.hr);
    expect((await call('hr', 'POST', `/privacy/requests/${own.id}/resolve`, { status: 'completed', resolution: 'Tự duyệt' })).status).toBe(403);
    // yêu cầu xóa: không xóa mù, phải nêu phần tiếp tục lưu
    const del = await ok('e2', 'POST', '/me/data-requests', { type: 'deletion', details: 'Xóa ảnh và CV của tôi', scope: ['avatar', 'cv_profile'] });
    expect((await call('hr', 'POST', `/privacy/requests/${del.id}/resolve`, { status: 'partially_completed', resolution: 'Đã xóa ảnh và CV' })).status).toBe(422);
    await ok('hr', 'POST', `/privacy/requests/${del.id}/resolve`, { status: 'partially_completed', resolution: 'Đã xóa ảnh và CV', retainedNote: 'Dữ liệu nhiệm vụ và chấm công lưu theo nghĩa vụ lao động', apply: true });
    expect(await q1(`SELECT 1 FROM data_deletion_jobs WHERE scope LIKE 'dsr:%'`)).toBeTruthy();
  });

  test('SEC-T07: rút lại đồng ý ghi âm -> không đính kèm ghi âm được nữa', async () => {
    const qc = await ok('m1', 'POST', '/quick-claims', { counterpartId: ids.e1, channel: 'call', occurredAt: new Date(Date.now() - 3600000).toISOString(), title: 'Kiểm lại 10 thùng hàng lỗi' });
    expect((await upload('e1', 'quick_claim', qc.id, 'goi.mp3', 'audio/mpeg')).status).toBe(428);
    await ok('e1', 'PATCH', '/me/privacy', { consents: { call_recording: true } });
    expect((await upload('e1', 'quick_claim', qc.id, 'goi.mp3', 'audio/mpeg')).status).toBe(201);
    await ok('e1', 'PATCH', '/me/privacy', { consents: { call_recording: false } });
    expect((await upload('e1', 'quick_claim', qc.id, 'goi2.mp3', 'audio/mpeg')).status).toBe(428);
    const c = await q(`SELECT status FROM consent_records WHERE user_id=$1 AND purpose='call_recording' ORDER BY captured_at`, [uid.e1]);
    expect(c.map((x) => x.status)).toEqual(['granted', 'withdrawn']);
  });

  test('SEC-T08: đăng nhập sai liên tục -> tạm khóa có thời hạn + cảnh báo; dò ID -> cảnh báo (không tự kết luận)', async () => {
    for (let i = 0; i < 5; i++) await call('', 'POST', '/auth/login', { phone: PH.e4, password: 'sai' });
    const r = await call('', 'POST', '/auth/login', { phone: PH.e4, password: 'Demo@123' });
    expect(r.status).toBe(429);
    expect((await q1(`SELECT status FROM users WHERE id=$1`, [uid.e4])).status).toBe('active'); // không khóa vĩnh viễn
    expect(await q1(`SELECT 1 FROM security_alerts WHERE kind='login_failures' AND user_id=$1`, [uid.e4])).toBeTruthy();
    await q(`UPDATE users SET locked_until=NULL WHERE id=$1`, [uid.e4]);
    resetRateLimits();
    for (let i = 0; i < 20; i++) await call('e2', 'GET', `/tasks/00000000-0000-4000-8000-${String(i).padStart(12, '0')}`);
    await new Promise((res) => setTimeout(res, 300));
    const alerts = await ok('admin', 'GET', '/security/alerts');
    expect(alerts.some((a: any) => a.kind === 'id_scan' && a.user_id === uid.e2)).toBe(true);
    expect((await call('e2', 'GET', '/security/alerts')).status).toBe(403);
  });

  test('SEC-T09: thành viên ngừng hoạt động -> token cũ bị từ chối ngay', async () => {
    expect((await call('e4', 'GET', '/tasks')).status).toBe(200);
    await ok('owner', 'PATCH', `/company/members/${ids.e4}`, { status: 'inactive' });
    expect((await call('e4', 'GET', '/tasks')).status).toBe(401);
  });

  test('SEC-T10: hỗ trợ nền tảng không có quyền mặc định; cần doanh nghiệp duyệt, có thời hạn, có nhật ký', async () => {
    const cid = (await q1(`SELECT company_id FROM company_members WHERE id=$1`, [ids.owner])).company_id;
    expect((await call('platform', 'GET', `/support/companies/${cid}/view?scope=members_basic`)).status).toBe(403);
    expect((await call('platform', 'GET', `/users/${uid.e1}/avatar`)).status).toBe(404);
    const req = await ok('platform', 'POST', '/support/access-requests', { companyId: cid, scope: 'members_basic', reason: 'Hỗ trợ lỗi danh sách thành viên', ticket: 'HT-102', hours: 2 });
    expect(req.status).toBe('pending');
    expect((await call('e1', 'POST', `/support/access-requests/${req.id}/decide`, { decision: 'approve' })).status).toBe(403);
    await ok('owner', 'POST', `/support/access-requests/${req.id}/decide`, { decision: 'approve' });
    const v = await ok('platform', 'GET', `/support/companies/${cid}/view?scope=members_basic`);
    expect(v.data[0]).not.toHaveProperty('phone');
    expect((await call('platform', 'GET', `/support/companies/${cid}/view?scope=audit_logs`)).status).toBe(403);
    expect(await q1(`SELECT 1 FROM data_access_logs WHERE action='support.view' AND result='allowed'`)).toBeTruthy();
  });

  test('Lưu trữ: dọn thông báo quá hạn theo chính sách, ghi lại lần xóa', async () => {
    const cid = (await q1(`SELECT company_id FROM company_members WHERE id=$1`, [ids.e1])).company_id;
    await q(`INSERT INTO notifications(company_id, member_id, type, title, created_at) VALUES ($1,$2,'test.old','Cũ', now() - interval '400 days')`, [cid, ids.e1]);
    const r = await runRetention();
    expect(r.notifications).toBeGreaterThan(0);
    expect(await q1(`SELECT 1 FROM notifications WHERE type='test.old'`)).toBeNull();
    expect(await q1(`SELECT 1 FROM data_deletion_jobs WHERE scope='retention'`)).toBeTruthy();
  });
});

describe('UX-ABUSE-01: báo cáo hành vi cần xem xét', () => {
  let caseId = '';
  test('AB-02/AB-04: báo cáo quản lý trực tiếp không chuyển cho chính người đó; gửi được khi không có tệp', async () => {
    const r = await ok('e1', 'POST', '/conduct-cases', { category: 'power_abuse', subcode: 'POW-02', description: 'Liên tục đổi hạn việc bất thường sau khi tôi góp ý trong cuộc họp', reportedMemberId: ids.m1, objectType: 'task', currentRisk: 'none' });
    caseId = r.id;
    expect(r.message).toContain('chưa phải kết luận');
    const c = await q1(`SELECT handler_member_id FROM conduct_cases WHERE id=$1`, [caseId]);
    expect(c.handler_member_id).toBe(ids.hr);
    expect((await call('m1', 'GET', `/conduct-cases/${caseId}`)).status).toBe(404);
    expect((await call('e2', 'GET', `/conduct-cases/${caseId}`)).status).toBe(404);
    const ov = await ok('owner', 'GET', `/conduct-cases/${caseId}`);
    expect(ov.my_role).toBe('oversight');
    expect(ov).not.toHaveProperty('description');
    expect(ov).not.toHaveProperty('reporter_name');
    const mine = await ok('e1', 'GET', `/conduct-cases/${caseId}`);
    expect(mine.handler_label).toBeDefined();
    expect(mine).not.toHaveProperty('handler_name');
  });

  test('Thông báo tối thiểu: không có nội dung/danh tính trong thông báo', async () => {
    const n = await ok('hr', 'GET', '/notifications');
    const item = n.items.find((i: any) => i.reference_id === caseId);
    expect(item.title).not.toContain('đổi hạn');
    expect(item.title).not.toContain('Giang');
    expect(item.body ?? null).toBeNull();
  });

  test('AB-03/AB-07/AB-08: người được báo cáo chỉ thấy tóm tắt khi được mời giải trình; không thấy danh tính/bằng chứng', async () => {
    const f = await upload('e1', 'conduct_case', caseId, 'anh-chup.png', 'image/png');
    expect(f.status).toBe(201);
    expect((await call('m1', 'GET', `/files/${f.body.id}`)).status).toBe(404);
    await ok('hr', 'POST', `/conduct-cases/${caseId}/handle`, { action: 'request_explanation', message: 'Đề nghị giải trình về các lần thay đổi hạn công việc trong tuần qua' });
    const v = await ok('m1', 'GET', `/conduct-cases/${caseId}`);
    expect(v.my_role).toBe('reported');
    expect(v.explanation_summary).toContain('giải trình');
    expect(v).not.toHaveProperty('reporter_name');
    expect(v).not.toHaveProperty('description');
    expect(v.files.length).toBe(0);
    expect((await call('m1', 'GET', `/files/${f.body.id}`)).status).toBe(404);
    await ok('m1', 'POST', `/conduct-cases/${caseId}/explanation`, { body: 'Hạn thay đổi do khách hàng dời lịch nhận hàng, có email kèm theo' });
    const h = await ok('hr', 'GET', `/conduct-cases/${caseId}`);
    expect(h.events.some((e: any) => e.kind === 'explanation' && e.actor === 'Người được báo cáo')).toBe(true);
    expect(h.files.length).toBe(1);
    const rep = await ok('e1', 'GET', `/conduct-cases/${caseId}`);
    expect(rep.events.some((e: any) => e.kind === 'explanation')).toBe(false);
  });

  test('AB-09: thay đổi bất thường liên quan người báo cáo sau báo cáo được đưa vào danh sách rà soát trả đũa', async () => {
    const t = await q1(`SELECT t.id, t.due_at FROM tasks t JOIN task_assignees ta ON ta.task_id=t.id AND ta.company_member_id=$1 AND ta.active WHERE t.status IN ('not_started','in_progress') AND t.created_by=$2 LIMIT 1`, [ids.e1, ids.m1]);
    await ok('m1', 'PATCH', `/tasks/${t.id}`, { dueAt: new Date(new Date(t.due_at).getTime() - 86400000).toISOString(), reason: 'Khách cần sớm hơn' });
    await ok('e1', 'POST', `/conduct-cases/${caseId}/retaliation`, { body: 'Tôi bị rút ngắn hạn việc ngay sau khi báo cáo' });
    const h = await ok('hr', 'GET', `/conduct-cases/${caseId}`);
    expect(h.retaliation_flag).toBe(true);
    expect(h.related_changes.some((x: any) => x.entity_id === t.id)).toBe(true);
  });

  test('AB-13: không đủ cơ sở -> thông báo trung tính; có thể yêu cầu xem xét lại bởi người khác', async () => {
    await ok('hr', 'POST', `/conduct-cases/${caseId}/outcome`, { status: 'insufficient', outcome: 'Chưa đủ thông tin để xác định sự việc', reason: 'Có email khách hàng xác nhận dời lịch' });
    const rep = await ok('e1', 'GET', `/conduct-cases/${caseId}`);
    expect(rep.status_message).toContain('không đồng nghĩa báo cáo của bạn là cố ý sai');
    expect(rep.can_request_review).toBe(true);
    const rr = await ok('e1', 'POST', `/conduct-cases/${caseId}/review-request`, { reason: 'Tôi có thêm tin nhắn cho thấy việc đổi hạn không phải do khách' });
    expect(rr.status).toBe('review_requested');
    const c = await q1(`SELECT handler_member_id FROM conduct_cases WHERE id=$1`, [caseId]);
    expect([ids.hr, ids.m1, ids.e1]).not.toContain(c.handler_member_id);
    expect((await call('hr', 'GET', `/conduct-cases/${caseId}`)).body.my_role).not.toBe('handler');
  });

  test('AB-15 + AB-06: người xử lý có xung đột lợi ích chuyển người khác; nguy cơ an toàn -> hướng dẫn khẩn cấp', async () => {
    const r = await ok('e2', 'POST', '/conduct-cases', { category: 'harassment', subcode: 'HAR-02', description: 'Bị đe dọa sẽ bị gây hại sau giờ làm nếu không nhận ca đêm', currentRisk: 'safety' });
    expect(r.safety).toContain('113');
    const c = await q1(`SELECT handler_member_id, severity FROM conduct_cases WHERE id=$1`, [r.id]);
    expect(c.severity).toBe('S3');
    const handler = Object.entries(ids).find(([, v]) => v === c.handler_member_id)![0];
    const res = await ok(handler, 'POST', `/conduct-cases/${r.id}/conflict`, { reason: 'Tôi có quan hệ họ hàng với người liên quan' });
    expect(res.ok).toBe(true);
    expect((await call(handler, 'GET', `/conduct-cases/${r.id}`)).status).not.toBe(200);
    const c2 = await q1(`SELECT handler_member_id FROM conduct_cases WHERE id=$1`, [r.id]);
    expect([c.handler_member_id, ids.e2]).not.toContain(c2.handler_member_id);
  });
});
