// Service worker v14 — mở app nhanh trên mạng 4G yếu:
// - /assets/* (tên tệp có mã băm, không bao giờ đổi): lấy từ bộ nhớ đệm trước, không tải lại mỗi lần mở app.
// - Trang (index.html): lấy mạng trước, quá 4 giây thì dùng bản đã lưu (vẫn mở được app; banner "phiên bản mới" sẽ báo khi có bản mới).
// - API (/api/*): luôn đi mạng, không lưu đệm.
const SHELL = 'shell-v4';
const ASSETS = 'assets-v1';
self.addEventListener('install', (e) => { e.waitUntil(caches.open(SHELL).then((c) => c.addAll(['/', '/index.html', '/icon-192.png', '/logo.png', '/logo-mark.png', '/manifest.webmanifest']).catch(() => {}))); self.skipWaiting(); });
self.addEventListener('activate', (e) => {
  e.waitUntil(caches.keys().then((ks) => Promise.all(ks.filter((k) => k !== SHELL && k !== ASSETS).map((k) => caches.delete(k)))).then(() => self.clients.claim()));
});
const timeout = (ms) => new Promise((_, rej) => setTimeout(() => rej(new Error('timeout')), ms));
self.addEventListener('fetch', (e) => {
  const u = new URL(e.request.url);
  if (e.request.method !== 'GET' || u.origin !== location.origin || u.pathname.startsWith('/api/')) return;
  if (u.pathname.startsWith('/assets/')) {
    e.respondWith(caches.open(ASSETS).then(async (c) => {
      const hit = await c.match(e.request);
      if (hit) return hit;
      const r = await fetch(e.request);
      if (r.ok) c.put(e.request, r.clone());
      return r;
    }));
    return;
  }
  const isPage = e.request.mode === 'navigate' || u.pathname === '/' || u.pathname.endsWith('.html');
  if (isPage) {
    e.respondWith((async () => {
      const net = fetch(e.request, { cache: 'no-store' }).then((r) => { if (r.ok) { const cp = r.clone(); caches.open(SHELL).then((c) => c.put('/index.html', cp)); } return r; });
      try { return await Promise.race([net, timeout(4000)]); }
      catch { const c = await caches.match('/index.html'); if (c) { net.catch(() => {}); return c; } return net; }
    })());
    return;
  }
  // ảnh, biểu tượng, manifest: lấy mạng, lỗi thì dùng bản lưu
  e.respondWith(fetch(e.request).then((r) => { if (r.ok) { const cp = r.clone(); caches.open(SHELL).then((c) => c.put(e.request, cp)); } return r; }).catch(() => caches.match(e.request)));
});
// Dọn bớt tệp /assets cũ (giữ tối đa 150 tệp)
self.addEventListener('message', (e) => {
  if (e.data === 'trim-assets') caches.open(ASSETS).then(async (c) => { const ks = await c.keys(); for (const k of ks.slice(0, Math.max(0, ks.length - 150))) await c.delete(k); });
});
