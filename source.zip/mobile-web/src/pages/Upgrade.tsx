import { useEffect, useState } from 'react';
import { get, post } from '../api';
import { useAuth } from '../auth';
import { Badge, Card, ErrorBox, Field, Header, KV, Loading, Tabs, useAction, useLoad } from '../ui';
import { PLAN_NAME, fmtD, fmtDT, vnd } from '../labels';

const SUB_STATUS: Record<string, [string, string]> = { pending_payment: ['Chờ thanh toán', 'amber'], active: ['Hoàn tất', 'green'], rejected: ['Bị từ chối', 'red'], cancelled: ['Đã hủy yêu cầu', 'gray'],
  refund_pending: ['Chờ hoàn tiền', 'amber'], refunded: ['Đã hoàn tiền', 'green'] };
const KIND: Record<string, string> = { new: 'Mua gói', renew: 'Gia hạn', change: 'Chuyển gói', addon: 'Mua thêm gói cộng thêm', cancel: 'Hủy gói' };

/** Bảng chi phí của một báo giá. */
function QuoteBox({ q }: { q: any }) {
  if (!q) return null;
  return (
    <Card>
      {q.base_price_vnd > 0 && <KV k={`Gói cơ bản ${PLAN_NAME[q.plan] || ''}`} v={vnd(q.base_price_vnd)} />}
      {q.addon_price_vnd > 0 && <KV k={`Gói cộng thêm × ${q.addon_packs}`} v={vnd(q.addon_price_vnd)} />}
      {q.credit_vnd > 0 && <KV k="Khấu trừ giá trị còn lại gói cũ" v={`− ${vnd(q.credit_vnd)}`} />}
      {q.member_limit && <KV k="Hạn mức thành viên" v={`${q.member_limit} người`} />}
      {q.new_expires_at && <KV k="Hạn mới" v={fmtD(q.new_expires_at)} />}
      <KV k={q.refund_vnd > 0 ? 'Số tiền được hoàn' : 'Cần thanh toán'} v={<b style={{ fontSize: 17, color: q.refund_vnd > 0 ? 'var(--green)' : undefined }}>{vnd(q.refund_vnd > 0 ? q.refund_vnd : q.amount_vnd)}</b>} />
      {q.note && <div className="small muted">{q.note}</div>}
    </Card>
  );
}

function Stepper({ value, max, onChange, label }: { value: number; max: number; onChange: (v: number) => void; label: string }) {
  return (
    <div className="row" style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
      <span style={{ flex: 1 }}>{label}</span>
      <button className="btn sm" disabled={value <= 0} onClick={() => onChange(value - 1)}>−</button>
      <b style={{ minWidth: 24, textAlign: 'center' }}>{value}</b>
      <button className="btn sm" disabled={value >= max} onClick={() => onChange(value + 1)}>＋</button>
    </div>
  );
}

/**
 * Gói doanh nghiệp (v12): chọn gói → chọn gói cộng thêm → xác nhận.
 * Công ty đã có gói: gia hạn (tính cả gói cộng thêm), mua thêm gói cộng thêm (theo ngày còn lại), chuyển gói (khấu trừ phần còn lại), hủy gói (hoàn tiền phần còn lại).
 */
export default function Upgrade() {
  const { me, reload, switchCompany } = useAuth();
  const plans = useLoad(() => get('/plans'), []);
  const mine = useLoad(() => get('/subscriptions/mine'), []);
  const isOwner = me?.role === 'owner';
  const cur = useLoad(() => (isOwner && me?.company_id ? get(`/subscriptions/current?companyId=${me.company_id}`) : Promise.resolve(null)), [isOwner, me?.company_id]);
  const hasPlan = !!cur.data?.company?.plan;
  if (!plans.data || (isOwner && cur.loading && !cur.data)) return <Loading />;
  const after = async (r: any) => { mine.reload(); cur.reload(); if (r?.company_id && r.company_id !== me?.company_id) await switchCompany(r.company_id); else await reload(); };
  return (
    <>
      <Header title={isOwner ? 'Gói doanh nghiệp' : 'Nâng cấp tài khoản doanh nghiệp'} back />
      <div className="page">
        {me?.company_id && !isOwner && <div className="alert warn">Chỉ chủ doanh nghiệp mới quản lý gói của công ty hiện tại. Bạn vẫn có thể tạo doanh nghiệp riêng.</div>}
        {hasPlan ? <Manage cur={cur.data} plans={plans.data} onDone={after} /> : <Buy plans={plans.data} isOwner={isOwner} onDone={after} />}
        <History list={mine.data || []} plans={plans.data} onCancel={async (id) => { await post(`/subscriptions/${id}/cancel`); mine.reload(); }} />
      </div>
    </>
  );
}

function Buy({ plans, isOwner, onDone }: { plans: any; isOwner: boolean; onDone: (r: any) => void }) {
  const { me } = useAuth();
  const [step, setStep] = useState(1);
  const [plan, setPlan] = useState('small');
  const [packs, setPacks] = useState(0);
  const [name, setName] = useState(isOwner ? me?.company_name || '' : '');
  const [email, setEmail] = useState(me?.email || '');
  const a = useAction();
  const p = plans.plans.find((x: any) => x.plan === plan);
  const total = p.price_vnd + packs * p.addon.price_vnd;
  return (
    <>
      <div className="seg"><button className={step === 1 ? 'on' : ''} onClick={() => setStep(1)}>1. Gói cơ bản</button><button className={step === 2 ? 'on' : ''} onClick={() => setStep(2)}>2. Gói cộng thêm</button><button className={step === 3 ? 'on' : ''} onClick={() => setStep(3)}>3. Xác nhận</button></div>
      {step === 1 && <>
        {plans.plans.map((x: any) => (
          <div key={x.plan} className={`plan-card ${plan === x.plan ? 'sel' : ''}`} onClick={() => { setPlan(x.plan); setPacks(0); }} role="radio" aria-checked={plan === x.plan}>
            <div className="row" style={{ display: 'flex', alignItems: 'center' }}><b style={{ flex: 1 }}>{x.name}</b><span className="price">{vnd(x.price_vnd)}</span></div>
            <div className="small muted">{x.member_limit} thành viên · {x.months} tháng · gói cộng thêm +{x.addon.size} người/{vnd(x.addon.price_vnd)}{x.addon.max_total ? ` (tối đa ${x.addon.max_total} người)` : ''}</div>
          </div>
        ))}
        <button className="btn primary block" onClick={() => setStep(2)}>Tiếp: chọn gói cộng thêm ›</button>
      </>}
      {step === 2 && <>
        <Card>
          <b>Gói cộng thêm cho {p.name}</b>
          <div className="small muted">Mỗi gói +{p.addon.size} thành viên, {vnd(p.addon.price_vnd)}/{p.months} tháng{p.addon.max_total ? ` · tổng tối đa ${p.addon.max_total} thành viên` : ''}.</div>
          <Stepper value={packs} max={p.addon.max_packs} onChange={setPacks} label={`Số gói cộng thêm (+${packs * p.addon.size} người)`} />
          <KV k="Tổng thành viên" v={`${p.member_limit + packs * p.addon.size} người`} />
        </Card>
        <button className="btn primary block" onClick={() => setStep(3)}>Tiếp: xác nhận ›</button>
      </>}
      {step === 3 && <>
        <QuoteBox q={{ plan, addon_packs: packs, base_price_vnd: p.price_vnd, addon_price_vnd: packs * p.addon.price_vnd, member_limit: p.member_limit + packs * p.addon.size, amount_vnd: total, credit_vnd: 0, refund_vnd: 0 }} />
        <Field label="Tên công ty" required><input value={name} onChange={(e) => setName(e.target.value)} /></Field>
        <Field label="Email liên hệ" required hint="Nhận hóa đơn, thông báo gia hạn và hoàn tiền"><input type="email" value={email} onChange={(e) => setEmail(e.target.value)} /></Field>
        <ErrorBox error={a.error} />
        <button className="btn primary block" disabled={a.busy} onClick={() => a.run(async () => onDone(await post('/subscriptions', { plan, addonPacks: packs, companyName: name, contactEmail: email, companyId: isOwner ? me?.company_id : undefined })))}>
          {plans.activation === 'auto' ? 'Kích hoạt (dùng thử)' : `Gửi yêu cầu — ${vnd(total)}`}</button>
        {plans.activation === 'auto' && <p className="small muted">Bản thử nghiệm: gói được kích hoạt ngay, chưa thu phí.</p>}
      </>}
    </>
  );
}

function Manage({ cur, plans, onDone }: { cur: any; plans: any; onDone: (r: any) => void }) {
  const c = cur.company;
  const [tab, setTab] = useState('renew');
  const [packs, setPacks] = useState(1);
  const [plan, setPlan] = useState(c.plan);
  const [cPacks, setCPacks] = useState(c.addon_packs || 0);
  const [reason, setReason] = useState('');
  const [quote, setQuote] = useState<any>(null);
  const [qErr, setQErr] = useState<string | null>(null);
  const a = useAction();
  const target = plans.plans.find((x: any) => x.plan === plan);
  useEffect(() => {
    setQuote(null); setQErr(null);
    const qs = tab === 'renew' ? 'action=renew' : tab === 'addon' ? `action=addon&packs=${packs}` : tab === 'change' ? `action=change&plan=${plan}&packs=${cPacks}` : 'action=cancel';
    if (tab === 'change' && plan === c.plan && cPacks === c.addon_packs) return;
    get(`/subscriptions/quote?companyId=${c.id}&${qs}`).then(setQuote).catch((e) => setQErr(e.message));
  }, [tab, packs, plan, cPacks]);
  const done = (r: any) => { setReason(''); onDone(r); };
  return (
    <>
      <Card>
        <div className="row"><b style={{ flex: 1, fontSize: 17 }}>{c.plan_name}</b><Badge tone={c.days_left > 30 ? 'green' : 'amber'}>còn {c.days_left} ngày</Badge></div>
        <KV k="Thành viên" v={`${c.members_used} / ${c.member_limit}`} />
        <KV k="Gói cộng thêm" v={c.addon_packs ? `${c.addon_packs} gói × ${c.addon.size} người` : 'Chưa có'} />
        <KV k="Hết hạn" v={fmtD(c.plan_expires_at)} />
        <KV k="Giá trị một kỳ (gói cơ bản + cộng thêm)" v={vnd(c.period_price_vnd)} />
        <KV k="Giá trị còn lại (dùng để hoàn/khấu trừ)" v={vnd(c.remaining_value_vnd)} />
      </Card>
      <Tabs value={tab} onChange={setTab} tabs={[['renew', 'Gia hạn'], ['addon', 'Mua thêm'], ['change', 'Chuyển gói'], ['cancel', 'Hủy gói']]} />
      {tab === 'renew' && <p className="small muted">Gia hạn thêm một kỳ, tính theo tổng gói cơ bản và các gói cộng thêm đang dùng. Hạn mới cộng tiếp từ ngày hết hạn hiện tại.</p>}
      {tab === 'addon' && <Card>
        <Stepper value={packs} max={Math.max(0, c.max_packs - (c.addon_packs || 0))} onChange={setPacks} label={`Thêm gói +${c.addon.size} người`} />
        <div className="small muted">Đang có {c.addon_packs || 0}/{c.max_packs} gói. Trả theo số ngày còn lại của kỳ hiện tại.</div>
      </Card>}
      {tab === 'change' && <>
        {plans.plans.map((x: any) => (
          <div key={x.plan} className={`plan-card ${plan === x.plan ? 'sel' : ''}`} onClick={() => { setPlan(x.plan); setCPacks(x.plan === c.plan ? c.addon_packs : 0); }} role="radio" aria-checked={plan === x.plan}>
            <div className="row" style={{ display: 'flex' }}><b style={{ flex: 1 }}>{x.name}{x.plan === c.plan ? ' (hiện tại)' : ''}</b><span className="price">{vnd(x.price_vnd)}</span></div>
            <div className="small muted">{x.member_limit} thành viên · +{x.addon.size}/{vnd(x.addon.price_vnd)}{x.addon.max_total ? ` · tối đa ${x.addon.max_total}` : ''}</div>
          </div>
        ))}
        <Card><Stepper value={cPacks} max={target.addon.max_packs} onChange={setCPacks} label={`Gói cộng thêm (+${cPacks * target.addon.size} người)`} /></Card>
        <p className="small muted">Giá trị còn lại của gói hiện tại được khấu trừ vào gói mới; nếu lớn hơn giá gói mới, phần dư được hoàn. Kỳ mới tính từ hôm nay.</p>
      </>}
      {tab === 'cancel' && <>
        <div className="alert warn small">Hủy gói: gói ngừng hiệu lực ngay, không thêm được thành viên mới. Phần giá trị còn lại (gói cơ bản + gói cộng thêm) được hoàn theo số ngày chưa dùng.</div>
        <Field label="Lý do hủy" required><textarea value={reason} onChange={(e) => setReason(e.target.value)} /></Field>
      </>}
      <ErrorBox error={qErr} />
      <QuoteBox q={quote} />
      <ErrorBox error={a.error} />
      {tab === 'renew' && <button className="btn primary block" disabled={a.busy || !quote} onClick={() => a.run(async () => done(await post('/subscriptions/renew', { companyId: c.id })))}>Gia hạn — {quote ? vnd(quote.amount_vnd) : '…'}</button>}
      {tab === 'addon' && <button className="btn primary block" disabled={a.busy || !quote || packs < 1} onClick={() => a.run(async () => done(await post('/subscriptions/addons', { companyId: c.id, packs })))}>Mua thêm {packs} gói — {quote ? vnd(quote.amount_vnd) : '…'}</button>}
      {tab === 'change' && <button className="btn primary block" disabled={a.busy || !quote} onClick={() => a.run(async () => done(await post('/subscriptions/change', { companyId: c.id, plan, addonPacks: cPacks })))}>Chuyển gói{quote ? (quote.refund_vnd > 0 ? ` — hoàn ${vnd(quote.refund_vnd)}` : ` — ${vnd(quote.amount_vnd)}`) : ''}</button>}
      {tab === 'cancel' && <button className="btn danger block" disabled={a.busy || reason.trim().length < 3} onClick={() => confirm('Xác nhận hủy gói doanh nghiệp?') && a.run(async () => done(await post('/subscriptions/cancel-plan', { companyId: c.id, reason, confirm: true })))}>Hủy gói — hoàn {quote ? vnd(quote.refund_vnd) : '…'}</button>}
    </>
  );
}

function History({ list, plans, onCancel }: { list: any[]; plans: any; onCancel: (id: string) => void }) {
  if (!list.length) return null;
  return (
    <>
      <div className="section-title">Lịch sử giao dịch</div>
      {list.map((s: any) => (
        <Card key={s.id}>
          <div className="row" style={{ display: 'flex', gap: 8, alignItems: 'center' }}><b style={{ flex: 1 }}>{KIND[s.kind] || 'Mua gói'} · {PLAN_NAME[s.plan] || ''}</b><Badge tone={SUB_STATUS[s.status]?.[1]}>{SUB_STATUS[s.status]?.[0] || s.status}</Badge></div>
          <div className="small muted">{fmtDT(s.created_at)} · {s.member_limit} thành viên{s.addon_packs ? ` · ${s.addon_packs} gói cộng thêm` : ''}</div>
          <div className="small">{Number(s.refund_vnd) > 0 ? `Hoàn ${vnd(Number(s.refund_vnd))}` : `Thanh toán ${vnd(Number(s.amount_vnd || s.price_vnd))}`}{Number(s.credit_vnd) > 0 ? ` (đã khấu trừ ${vnd(Number(s.credit_vnd))})` : ''}{s.note ? ` · ${s.note}` : ''}</div>
          {s.status === 'pending_payment' && <>
            <div className="alert warn small">{plans.payment_instructions || 'Vui lòng chuyển khoản theo hướng dẫn của Việc Đến, ghi nội dung là số điện thoại của bạn. Gói được kích hoạt sau khi xác nhận thanh toán.'}</div>
            <button className="btn sm" onClick={() => onCancel(s.id)}>Hủy yêu cầu</button>
          </>}
          {s.status === 'refund_pending' && <div className="small muted">Việc Đến sẽ hoàn tiền về tài khoản đã thanh toán và báo khi hoàn tất.</div>}
        </Card>
      ))}
    </>
  );
}
