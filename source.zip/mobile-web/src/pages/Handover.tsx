import { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import QRCode from 'qrcode';
import { api, get, post } from '../api';
import { Badge, Card, Empty, ErrorBox, Field, Header, KV, Loading, Select, useAction, useLoad, Note } from '../ui';
import { Icon } from '../icons';
import { fmtDT } from '../labels';

export const HO_STATE: Record<string, [string, string]> = {
  PENDING: ['Chưa đề nghị bàn giao', 'gray'], AWAITING_RECIPIENT: ['Chờ người nhận xác nhận', 'blue'], CONFIRMED: ['Người nhận đã xác nhận', 'green'],
  RECIPIENT_REJECTED: ['Người nhận không tiếp nhận', 'red'], EXCEPTION_PENDING: ['Treo — chờ người giao duyệt giải trình', 'amber'],
  EXCEPTION_APPROVED: ['Hoàn thành theo ngoại lệ đã duyệt', 'green'], EXCEPTION_REJECTED: ['Giải trình bị từ chối — tiếp tục xử lý', 'red'], CANCELLED: ['Đã hủy', 'gray'],
};
const CAUSE: Record<string, string> = { recipient_absent: 'Người nhận vắng mặt', no_device: 'Người nhận không có điện thoại/thiết bị', network: 'Mất mạng/sóng yếu', qr_error: 'Lỗi mã QR/hệ thống',
  recipient_refused_scan: 'Người nhận không muốn quét', remote_handover: 'Bàn giao từ xa (qua bưu điện, gửi đồ…)', other: 'Khác' };
const EV: Record<string, string> = { 'handover.details_saved': 'Lưu thông tin bàn giao', 'handover.qr_issued': 'Phát hành QR/link', 'handover.qr_revoked': 'Thu hồi QR', 'handover.confirmed': 'Người nhận xác nhận',
  'handover.recipient_rejected': 'Người nhận không tiếp nhận', 'handover.exception_submitted': 'Gửi giải trình bỏ qua QR', 'handover.exception_reviewed': 'Người giao duyệt giải trình' };

/** Khung bàn giao bên ngoài trong chi tiết nhiệm vụ (Đặc tả v2.1 mục 3, 5.2, 5.4). */
export function HandoverPanel({ taskId, onChange }: { taskId: string; onChange?: () => void }) {
  const { data: h, reload, error } = useLoad(() => get(`/tasks/${taskId}/handover-history`), [taskId]);
  const a = useAction();
  const [qr, setQr] = useState<{ img: string; url: string } | null>(null);
  const [ex, setEx] = useState<{ reason: string; cause: string; file: File | null } | null>(null);
  const [rv, setRv] = useState('');
  const done = () => { reload(); onChange?.(); };
  if (error) return null;
  if (!h) return null;
  const p = h.permissions; const st = HO_STATE[h.task.handover_status || 'PENDING'];
  const pending = h.exceptions.find((e: any) => e.status === 'PENDING');
  const issue = () => a.run(async () => {
    const r = await post(`/tasks/${taskId}/handover-qr`);
    const url = r.url && /^https?:/.test(r.url) ? r.url : window.location.origin + r.path;
    setQr({ img: await QRCode.toDataURL(url, { margin: 2, width: 420 }), url }); done();
  });
  const share = async () => {
    if (!qr) return;
    const text = `Vui lòng xác nhận đã nhận bàn giao "${h.details?.description || h.task.title}": ${qr.url}`;
    if ((navigator as any).share) await (navigator as any).share({ title: 'Xác nhận bàn giao', text, url: qr.url }).catch(() => {});
    else { await navigator.clipboard?.writeText(text); alert('Đã sao chép liên kết — gửi qua tin nhắn/email cho người nhận.'); }
  };
  return (
    <Card>
      <div className="row"><b style={{ flex: 1 }}>Giao tiếp – chuyển giao bên ngoài</b><Badge tone={st[1]}>{st[0]}</Badge></div>
      {h.details ? <>
        <KV k="Người nhận" v={h.details.recipient_name} />
        <KV k="Nội dung bàn giao" v={h.details.description} />
        {h.details.location_text && <KV k="Địa điểm" v={h.details.location_text} />}
        {h.details.expected_at && <KV k="Thời hạn" v={fmtDT(h.details.expected_at)} />}
        <div className="small muted">Xác nhận bằng QR/link{h.details.allow_reject ? ' · người nhận được phép từ chối (bắt buộc lý do)' : ''}{h.task.requires_review ? ' · sau bàn giao còn bước nghiệm thu' : ''}</div>
      </> : <div className="small muted">Chưa có thông tin người nhận.</div>}
      {qr && (
        <div style={{ textAlign: 'center', marginTop: 8 }}>
          <img src={qr.img} alt="Mã QR xác nhận bàn giao" style={{ width: '75%', maxWidth: 260 }} />
          <div className="small">Đưa người nhận quét mã, hoặc gửi liên kết. Người nhận không cần cài app.</div>
          <div className="actions"><button className="btn primary" onClick={share}><Icon name="phone" size={16} />Gửi liên kết</button><button className="btn" onClick={() => navigator.clipboard?.writeText(qr.url)}>Sao chép</button></div>
        </div>
      )}
      <div className="actions">
        {p.can_issue_qr && <button className="btn primary" disabled={a.busy} onClick={issue}><Icon name="qr" size={16} />{h.task.status === 'awaiting_handover' ? 'Hiển thị QR mới / gửi lại liên kết' : 'Đề nghị bàn giao (tạo QR)'}</button>}
        {h.task.status === 'awaiting_handover' && (p.can_issue_qr) && <button className="btn" disabled={a.busy} onClick={() => a.run(async () => { await post(`/tasks/${taskId}/handover-qr/revoke`); setQr(null); done(); })}>Thu hồi QR</button>}
        {p.can_submit_exception && !ex && <button className="btn" onClick={() => setEx({ reason: '', cause: 'recipient_absent', file: null })}>Không thể bàn giao bằng QR – gửi giải trình</button>}
      </div>
      {ex && (
        <div className="card" style={{ marginTop: 8 }}>
          <b className="small">Giải trình bỏ qua QR</b>
          <Note>Nhiệm vụ sẽ chuyển <b>treo — chờ người giao duyệt</b>, chưa tính hoàn thành. Chỉ khi được chấp nhận mới ghi nhận hoàn thành.</Note>
          <Field label="Nguyên nhân"><Select value={ex.cause} onChange={(v) => setEx({ ...ex, cause: v })} options={CAUSE} /></Field>
          <Field label="Giải trình" required><textarea value={ex.reason} onChange={(e) => setEx({ ...ex, reason: e.target.value })} placeholder="VD: Khách không có điện thoại, đã ký biên bản giao nhận giấy" /></Field>
          <Field label="Bằng chứng (ảnh biên bản, chứng từ)"><input type="file" accept="image/*,application/pdf" onChange={(e) => setEx({ ...ex, file: e.target.files?.[0] || null })} /></Field>
          <div className="actions"><button className="btn" onClick={() => setEx(null)}>Hủy</button>
            <button className="btn primary" disabled={a.busy || ex.reason.trim().length < 10} onClick={() => a.run(async () => {
              const r = await post(`/tasks/${taskId}/handover-exceptions`, { reason: ex.reason, cause: ex.cause });
              if (ex.file) { const fd = new FormData(); fd.append('file', ex.file); await api('POST', `/files?parentType=handover_exception&parentId=${r.id}`, fd).catch(() => {}); }
              setEx(null); done();
            })}>Gửi giải trình</button></div>
        </div>
      )}
      {p.can_review_exception && pending && (
        <div className="card" style={{ marginTop: 8, borderColor: 'var(--amber)' }}>
          <b className="small">Duyệt giải trình của {pending.submitted_by_name}</b>
          <div className="small">{CAUSE[pending.cause]} — {pending.reason}</div>
          {pending.files.map((f: any) => <a key={f.id} className="small" href="#" onClick={(e) => { e.preventDefault(); (async () => { const res: Response = await api('GET', `/files/${f.id}`, undefined, { raw: true }); window.open(URL.createObjectURL(await res.blob())); })(); }}>📎 {f.filename}</a>)}
          <textarea placeholder="Ghi chú (bắt buộc khi từ chối)" value={rv} onChange={(e) => setRv(e.target.value)} style={{ marginTop: 6 }} />
          <div className="actions">
            <button className="btn primary" disabled={a.busy} onClick={() => a.run(async () => { await post(`/handover-exceptions/${pending.id}/review`, { decision: 'APPROVED', reason: rv || undefined }); setRv(''); done(); })}>Chấp nhận — hoàn thành theo ngoại lệ</button>
            <button className="btn danger" disabled={a.busy || rv.trim().length < 5} onClick={() => a.run(async () => { await post(`/handover-exceptions/${pending.id}/review`, { decision: 'REJECTED', reason: rv }); setRv(''); done(); })}>Từ chối</button>
          </div>
        </div>
      )}
      <ErrorBox error={a.error} />
      {(h.confirmations.length > 0 || h.exceptions.length > 0 || h.events.length > 0) && (
        <details style={{ marginTop: 8 }}>
          <summary className="small">Lịch sử bàn giao ({h.events.length})</summary>
          {h.confirmations.map((c: any) => <div key={c.id} className="small">{c.confirmation_status === 'CONFIRMED' ? '✅' : '⛔'} {c.recipient_display_name} · {fmtDT(c.confirmed_at)}{c.reason ? ` — ${c.reason}` : ''}</div>)}
          {h.exceptions.map((e: any) => <div key={e.id} className="small"><Icon name="edit" size={16} />Giải trình {fmtDT(e.submitted_at)}: {e.reason} → {e.status === 'PENDING' ? 'chờ duyệt' : `${e.decision === 'APPROVED' ? 'chấp nhận' : 'từ chối'} bởi ${e.reviewed_by_name}${e.review_reason ? ` (${e.review_reason})` : ''}`}</div>)}
          {h.events.map((e: any, i: number) => <div key={i} className="small muted">{fmtDT(e.occurred_at)} · {EV[e.event_type] || e.event_type} · {e.actor_type === 'external_recipient' ? 'người nhận' : e.actor_name || 'hệ thống'}</div>)}
        </details>
      )}
    </Card>
  );
}

/** Trang xác nhận công khai cho người nhận bên ngoài: không cần app/tài khoản, chỉ hiện thông tin tối thiểu. */
export function HandoverPublic() {
  const { token } = useParams();
  const [d, setD] = useState<any>(null);
  const [err, setErr] = useState<string | null>(null);
  const [name, setName] = useState('');
  const [reject, setReject] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const call = async (path: string, body: any) => {
    const r = await fetch(`/api/v1${path}`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
    const j = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(j?.error?.message || 'Có lỗi xảy ra');
    return j;
  };
  useEffect(() => { call('/external-handover/validate', { token }).then(setD).catch((e) => setErr(e.message)); }, [token]);
  const act = async (path: string, body: any) => { setBusy(true); setErr(null); try { setD(await call(path, { token, ...body })); } catch (e: any) { setErr(e.message); } finally { setBusy(false); } };
  return (
    <div className="public-page">
      <div className="public-card">
        <div className="brand-row" style={{ justifyContent: 'center' }}><img src="/logo-mark.png" alt="" style={{ height: 32 }} /><b>Xác nhận bàn giao</b></div>
        {!d && !err && <Loading />}
        {err && <div className="alert warn">{err}</div>}
        {d && <>
          <div className="small muted" style={{ textAlign: 'center' }}>{d.company} · Mã tham chiếu <b>{d.reference}</b></div>
          <h2 style={{ textAlign: 'center' }}>{d.title}</h2>
          <KV k="Nội dung bàn giao" v={d.content} />
          {d.location && <KV k="Địa điểm" v={d.location} />}
          {d.recipient_hint && <KV k="Người nhận" v={d.recipient_hint} />}
          {d.performer && <KV k="Người giao" v={d.performer} />}
          {d.state === 'ready' && <>
            <Field label="Họ tên người nhận" required><input value={name} onChange={(e) => setName(e.target.value)} autoComplete="name" /></Field>
            {reject === null ? <>
              <button className="btn primary block" disabled={busy || name.trim().length < 2} onClick={() => act('/external-handover/confirm', { displayName: name })}><Icon name="check" size={16} />Tôi đã nhận đủ</button>
              {d.allow_reject && <button className="btn block" style={{ marginTop: 8 }} onClick={() => setReject('')}>Không tiếp nhận</button>}
            </> : <>
              <Field label="Lý do không tiếp nhận" required><textarea value={reject} onChange={(e) => setReject(e.target.value)} /></Field>
              <button className="btn danger block" disabled={busy || name.trim().length < 2 || reject.trim().length < 5} onClick={() => act('/external-handover/reject', { displayName: name, reason: reject })}>Gửi từ chối</button>
              <button className="btn block" style={{ marginTop: 8 }} onClick={() => setReject(null)}>Quay lại</button>
            </>}
            <Note>Việc xác nhận chỉ ghi nhận bạn đã tiếp nhận nội dung trên; không thay thế chứng từ pháp lý.</Note>
          </>}
          {d.state === 'confirmed' && <div className="alert ok">Đã xác nhận tiếp nhận lúc {fmtDT(d.confirmed_at)}. Cảm ơn bạn!</div>}
          {d.state === 'rejected' && <div className="alert warn">Đã ghi nhận không tiếp nhận. Người bàn giao sẽ liên hệ lại.</div>}
          {['expired', 'revoked', 'used'].includes(d.state) && <div className="alert warn">Liên kết đã hết hạn hoặc đã được thay bằng liên kết mới. Vui lòng liên hệ người bàn giao.</div>}
          {d.state === 'task_cancelled' && <div className="alert warn">Nhiệm vụ đã hủy — không cần xác nhận.</div>}
          {d.state === 'not_ready' && <div className="alert info">Bàn giao chưa sẵn sàng để xác nhận.</div>}
        </>}
      </div>
    </div>
  );
}

/** Danh sách giải trình treo chờ người giao duyệt. */
export function HandoverExceptions() {
  const { data, error, loading } = useLoad(() => get('/handover-exceptions'), []);
  return (
    <>
      <Header title="Bàn giao chờ duyệt giải trình" back />
      <div className="page">
        <Note>Nhân viên không bàn giao được bằng QR đã gửi giải trình. Nhiệm vụ đang treo, chưa tính hoàn thành cho tới khi bạn chấp nhận. Không đánh giá thấp nhân viên chỉ vì có ngoại lệ — xét nguyên nhân khách quan.</Note>
        <ErrorBox error={error} />{loading && !data && <Loading />}
        {data && data.length === 0 && <Empty>Không có giải trình nào chờ duyệt</Empty>}
        {data?.map((e: any) => (
          <Card key={e.id} to={`/tasks/${e.task_id}`}>
            <div className="row"><b style={{ flex: 1 }}>{e.task_code} - {e.task_title}</b><Badge tone={e.waiting_hours > 24 ? 'red' : 'amber'}>chờ {Math.round(e.waiting_hours)} giờ</Badge></div>
            <div className="small muted">{e.submitted_by_name} · {e.group_name} · người nhận {e.recipient_name}</div>
            <div className="small">{CAUSE[e.cause]} — {e.reason}</div>
          </Card>
        ))}
        <Link className="small" to="/work?s=tasks">← Nhiệm vụ</Link>
      </div>
    </>
  );
}
