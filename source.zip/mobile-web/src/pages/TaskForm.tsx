import { useEffect, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { get, post, qs } from '../api';
import { can, isAdminRole, useAuth } from '../auth';
import { Avatar, Badge, ErrorBox, Field, Header, Loading, Select, useAction, useLoad, Note } from '../ui';
import { Icon } from '../icons';
import { AUTO_START, isTicketField } from '../labels';
import { AVAIL, COMPLEXITY, LEAVE_TYPE, PRIORITY, REQ, REQ_STRUCT, UNEXPECTED_CAT, UNEXPECTED_CAUSE, fromLocalInput, isoDate, toLocalInput } from '../labels';

const GUIDE: Record<string, Record<string, string>> = {
  simple: { normal: '2–4 giờ', high: '4–8 giờ' }, medium: { normal: '1–2 ngày', high: '2–3 ngày' },
  complex: { normal: '3–5 ngày', high: '5–8 ngày' }, very_complex: { normal: '1–2 tuần', high: '2–4 tuần' },
};

export default function TaskForm() {
  const nav = useNavigate();
  const { me } = useAuth();
  const a = useAction();
  const groups = useLoad(() => get('/groups'), []);
  const types = useLoad(() => get('/company/task-types'), []);
  const templates = useLoad(() => get('/company/task-templates'), []);
  const permitTypes = useLoad(() => get('/permit-types'), []);
  const [sp] = useSearchParams();
  const presetOwner = sp.get('owner') || '';
  const reportId = sp.get('reportId') || '';
  const report = useLoad(() => (reportId ? get(`/workplace-reports/${reportId}`) : Promise.resolve(null)), [reportId]);
  const allGroups = useLoad(() => get('/groups?scope=all'), []);
  const [f, setF] = useState<any>({
    templateId: '', fieldValues: {} as Record<string, string>, permits: [] as any[],
    title: '', description: '', groupId: sp.get('group') || '', ownerMemberId: presetOwner, collaboratorIds: [] as string[], taskTypeId: '', complexity: 'medium',
    requirementLevel: 'normal', estimatedHours: 8, dueAt: toLocalInput(new Date(Date.now() + 2 * 86400000)), priority: 'normal', resources: '',
    criteria: [{ direction: 'input', criterion: '' }, { direction: 'output', criterion: '' }], isUnexpected: false,
    unexpected: { category: 'ad_hoc', requirementStructure: 'common', cause: 'superior_request', causeDetail: '', impact: '' }, subitems: [] as { title: string; extraHours: number }[], planDate: isoDate(new Date()), pinned: false,
    stages: [] as { stage: number; title: string; groupId: string; groupIds?: string[]; hours: number }[], multiGroupIds: [] as string[],
    isChain: false, customerName: '', importance: 'normal', orderValue: '', marginNote: '', workLocationId: '', locationRequired: false, productionStandardId: '',
    mode: sp.get('chain') ? 'existing_chain' : sp.get('order') ? 'new_chain' : 'single', chainCode: '', chainId: sp.get('chain') || '', chainStage: '', noTicket: {} as Record<string, boolean>,
    autoStart: 'manual', scheduledStartAt: '',
    ho: { recipientName: '', recipientContact: '', contactType: 'phone', description: '', locationText: '', allowReject: true, requiresReview: false },
  });
  const chains = useLoad(() => get('/chains'), []);
  const chainDetail = useLoad(() => (f.chainId ? get(`/chains/${f.chainId}`) : Promise.resolve(null)), [f.chainId]);
  const locs = useLoad(() => get('/company/locations'), []);
  const stds = useLoad(() => get('/company/production-standards'), []);
  const up = (p: any) => setF((x: any) => ({ ...x, ...p }));
  const [step, setStep] = useState(1);
  const managed = (groups.data || []).filter((g: any) => g.is_manager || g.assignable || isAdminRole(me?.role));
  const canOrder = can(me, 'create_order');
  const isOrder = f.mode === 'new_chain';
  // v10: nút thu gọn danh sách mẫu công việc (ghi nhớ trên máy)
  const [tplClosed, setTplClosed] = useState(() => { try { return localStorage.getItem('tpl_closed') === '1'; } catch { return false; } });
  const [permitClosed, setPermitClosed] = useState(() => { try { return localStorage.getItem('permit_closed') !== '0'; } catch { return true; } });
  const togglePermit = () => { const v = !permitClosed; setPermitClosed(v); try { localStorage.setItem('permit_closed', v ? '1' : '0'); } catch { /* */ } };
  const toggleTpl = () => { const v = !tplClosed; setTplClosed(v); try { localStorage.setItem('tpl_closed', v ? '1' : '0'); } catch { /* */ } };
  const coordGroup = useLoad(() => (isOrder && f.groupId ? get(`/groups/${f.groupId}`) : Promise.resolve(null)), [isOrder, f.groupId]);
  const orderLocs = (locs.data || []).filter((l: any) => l.active);
  const group = useLoad(() => (f.groupId ? get(`/groups/${f.groupId}`) : Promise.resolve(null)), [f.groupId]);
  const people: [string, string][] = group.data ? [[group.data.manager_member_id, `${group.data.manager_name} (quản lý)`], ...group.data.members.filter((m: any) => m.member_id !== group.data.manager_member_id).map((m: any) => [m.member_id, m.name] as [string, string])] : [];

  useEffect(() => { if (!f.groupId && managed.length === 1) up({ groupId: managed[0].id }); }, [groups.data]);
  useEffect(() => { if (!f.taskTypeId && types.data?.length) up({ taskTypeId: (f.mode === 'new_chain' && types.data.find((t: any) => t.active && t.name === 'Sản xuất')?.id) || types.data.find((t: any) => t.active)?.id }); }, [types.data]);
  // Giao việc xử lý trở ngại: điền sẵn tiêu đề, mô tả từ báo cáo
  useEffect(() => {
    const w = report.data; if (!w) return;
    const sevHigh = ['high', 'critical'].includes(w.severity);
    up({
      title: `Xử lý trở ngại ${w.code}: ${w.description.split(/[.\n]/)[0].slice(0, 70)}`,
      description: `${w.description}${w.location ? `\nVị trí: ${w.location}` : ''}${w.asset ? `\nTài sản: ${w.asset}` : ''}${w.temp_measure ? `\nBiện pháp tạm thời: ${w.temp_measure}` : ''}\n(Người báo: ${w.reporter_name})`,
      groupId: w.group_id && managed.some((g: any) => g.id === w.group_id) ? w.group_id : (managed[0]?.id || ''),
      complexity: 'simple', estimatedHours: 2, pinned: sevHigh, priority: sevHigh ? 'urgent' : 'high',
      dueAt: w.stage_due_at ? toLocalInput(new Date(w.stage_due_at)) : toLocalInput(new Date(Date.now() + 86400000)),
      criteria: [{ direction: 'output', criterion: 'Trở ngại được khắc phục, người báo cáo xác nhận' }],
    });
  }, [report.data, groups.data]);

  const tpl = templates.data?.find((x: any) => x.id === f.templateId);
  const applyTemplate = (id: string) => {
    const t = templates.data?.find((x: any) => x.id === id);
    if (!t) { up({ templateId: '', permits: [] }); return; }
    const pts = permitTypes.data || [];
    up({ templateId: id, fieldValues: {}, title: t.name, description: t.description || '', taskTypeId: t.task_type_id || f.taskTypeId, complexity: t.complexity, requirementLevel: t.requirement_level,
      estimatedHours: t.estimated_hours, criteria: t.criteria.length ? t.criteria : f.criteria,
      stages: (t.stages || []).flatMap((st: any) => st.items.map((it: any) => ({ stage: st.stage, title: it.title, groupId: f.groupId, hours: it.hours || 2 }))),
      permits: (t.permit_keys || []).map((k: string) => pts.find((p: any) => p.key === k && p.active)).filter(Boolean)
        .map((p: any) => ({ typeId: p.id, enabled: true, mode: p.allow_declaration ? 'declaration' : 'approval', data: {} })) });
  };
  const setPermit = (typeId: string, patch: any) => {
    const ex = f.permits.find((p: any) => p.typeId === typeId);
    up({ permits: ex ? f.permits.map((p: any) => (p.typeId === typeId ? { ...p, ...patch } : p)) : [...f.permits, { typeId, enabled: true, mode: 'approval', data: {}, ...patch }] });
  };
  const suggestDue = async () => {
    const r = await get('/company/calendar/suggest-due' + qs({ hours: f.estimatedHours }));
    up({ dueAt: toLocalInput(new Date(r.due_at)) });
  };
  const setCrit = (i: number, p: any) => up({ criteria: f.criteria.map((c: any, j: number) => (j === i ? { ...c, ...p } : c)) });

  const [stepErr, setStepErr] = useState<string | null>(null);
  const next = () => {
    const tplMiss = (tpl?.fields || []).filter((x: any) => x.required && !(isTicketField(x) && f.noTicket[x.key]) && !String(f.fieldValues[x.key] || '').trim()).map((x: any) => x.label);
    const permitMiss = f.permits.filter((p: any) => p.enabled).flatMap((p: any) => {
      const t = (permitTypes.data || []).find((x: any) => x.id === p.typeId);
      return (t?.fields || []).filter((x: any) => x.required && !String(p.data[x.key] || '').trim()).map((x: any) => `${t.name}: ${x.label}`);
    });
    const standing = f.mode === 'standing'; const inChain = f.mode === 'existing_chain';
    const miss = [...tplMiss, ...permitMiss, !f.title.trim() && 'tiêu đề', !inChain && f.description.trim().length < 5 && 'mô tả/phạm vi', !f.groupId && 'nhóm', !standing && !f.dueAt && 'deadline',
      inChain && !f.chainId && 'đơn hàng', isOrder && !f.workLocationId && 'vị trí làm việc của đơn hàng',
      isOrder && !f.stages.some((x: any) => x.title.trim()) && 'ít nhất một công đoạn sản xuất',
      isOrder && f.stages.some((x: any) => x.title.trim() && !(x.groupIds?.length || x.groupId)) && 'nhóm nhận cho từng công đoạn',
      f.mode === 'external' && f.ho.recipientName.trim().length < 2 && 'tên người nhận', f.mode === 'external' && f.ho.description.trim().length < 3 && 'nội dung bàn giao', inChain && !f.chainStage && 'giai đoạn', f.autoStart === 'scheduled' && !f.scheduledStartAt && 'thời điểm bắt đầu theo lịch',
      !standing && !inChain && !f.criteria.some((c: any) => c.direction === 'output' && c.criterion.trim()) && 'ít nhất một tiêu chí đầu ra'].filter(Boolean);
    if (miss.length) { setStepErr('Còn thiếu: ' + miss.join(', ')); return; }
    setStepErr(null);
    if (presetOwner && f.ownerMemberId) { submit(); return; }
    // Đơn hàng: người nhận từng công đoạn là trưởng nhóm của nhóm được chọn — không cần bước chọn nhân viên
    if (isOrder) { submit(); return; }
    setStep(2); window.scrollTo(0, 0);
  };
  const submit = () => a.run(async () => {
    const filled = (tpl?.fields || []).filter((x: any) => String(f.fieldValues[x.key] || '').trim() || (isTicketField(x) && f.noTicket[x.key]));
    const description = filled.length ? `${f.description}\n\nThông tin khai báo:\n${filled.map((x: any) => `• ${x.label}: ${isTicketField(x) && f.noTicket[x.key] ? 'Không có' : f.fieldValues[x.key]}`).join('\n')}` : f.description;
    if (f.mode === 'existing_chain') {
      // Đơn hàng có sẵn: tạo nhiệm vụ con của đơn, chọn phân đoạn (giai đoạn) công việc
      const child = await post('/tasks', { parentId: f.chainId, title: f.title, description: description.trim().length >= 5 ? description : undefined, groupId: f.groupId, ownerMemberId: f.ownerMemberId,
        collaboratorIds: f.collaboratorIds, stageNo: Number(f.chainStage), estimatedHours: Number(f.estimatedHours) || undefined, standardMinutes: Math.round((Number(f.estimatedHours) || 0) * 60) || undefined,
        dueAt: fromLocalInput(f.dueAt), priority: f.priority, workLocationId: f.workLocationId || undefined, locationRequired: !!f.workLocationId && f.locationRequired,
        productionStandardId: f.productionStandardId || undefined, autoStart: f.autoStart, scheduledStartAt: f.autoStart === 'scheduled' ? fromLocalInput(f.scheduledStartAt) : undefined,
        criteria: f.criteria.filter((c: any) => c.criterion.trim() && c.direction === 'output').length ? f.criteria.filter((c: any) => c.criterion.trim()) : undefined });
      nav(`/tasks/${child.id}`, { replace: true });
      return;
    }
    const body: any = {
      title: f.title, description, groupId: f.groupId, ownerMemberId: isOrder ? f.ownerMemberId || undefined : f.ownerMemberId, collaboratorIds: isOrder ? [] : f.collaboratorIds,
      taskTypeId: f.taskTypeId, complexity: f.complexity, requirementLevel: f.requirementLevel, estimatedHours: Number(f.estimatedHours),
      dueAt: f.mode === 'standing' ? undefined : fromLocalInput(f.dueAt), priority: f.priority, resources: f.resources || undefined, planDate: f.planDate || undefined, pinned: f.pinned, urgent: f.pinned,
      criteria: f.criteria.filter((c: any) => c.criterion.trim()),
      subitems: f.isUnexpected && f.unexpected.requirementStructure === 'diverse' ? f.subitems.filter((s: any) => s.title.trim()) : [],
      unexpected: f.isUnexpected ? { ...f.unexpected, causeDetail: f.unexpected.causeDetail || undefined, impact: f.unexpected.impact || undefined } : undefined,
      sourceReportId: reportId || undefined,
      isChain: f.mode === 'new_chain', chainCode: f.mode === 'new_chain' && f.chainCode.trim() ? f.chainCode.trim() : undefined, isStanding: f.mode === 'standing',
      autoStart: f.mode === 'standing' ? 'manual' : f.autoStart, scheduledStartAt: f.autoStart === 'scheduled' ? fromLocalInput(f.scheduledStartAt) : undefined,
      customerName: f.mode === 'new_chain' && f.customerName ? f.customerName : undefined, importance: f.importance,
      orderValue: f.mode === 'new_chain' && f.orderValue !== '' ? Number(f.orderValue) : undefined, marginNote: f.mode === 'new_chain' && f.marginNote ? f.marginNote : undefined,
      workLocationId: f.workLocationId || undefined, locationRequired: !!f.workLocationId && f.locationRequired, productionStandardId: f.productionStandardId || undefined,
    };
    // Giao cùng lúc cho nhiều trưởng nhóm (việc đơn lẻ): mỗi nhóm một nhiệm vụ, người chịu trách nhiệm là trưởng nhóm
    if (!isOrder && f.mode !== 'external' && f.multiGroupIds.length > 0) {
      const made: any[] = []; const failed: string[] = [];
      for (const gid of f.multiGroupIds) {
        const g = (groups.data || []).find((x: any) => x.id === gid);
        try { made.push(await post('/tasks', { ...body, groupId: gid, ownerMemberId: g?.leader_id, collaboratorIds: [] })); } catch (e: any) { failed.push(`${g?.name}: ${e.message}`); }
      }
      if (failed.length) sessionStorage.setItem('task_notice', 'Lưu ý — ' + failed.join('; '));
      if (!made.length) throw new Error(failed.join('; '));
      nav(made.length === 1 ? `/tasks/${made[0].id}` : '/tasks?tab=tasks&mine=', { replace: true });
      return;
    }
    const t = await post('/tasks', body);
    const failed: string[] = [];
    // v9: Giao tiếp – chuyển giao bên ngoài: lưu thông tin người nhận; người thực hiện tạo QR khi đề nghị bàn giao
    if (f.mode === 'external') {
      try { await post(`/tasks/${t.id}/handover-details`, { recipientName: f.ho.recipientName, recipientContact: f.ho.recipientContact || undefined, contactType: f.ho.recipientContact ? f.ho.contactType : undefined,
        description: f.ho.description, locationText: f.ho.locationText || undefined, allowReject: f.ho.allowReject, requiresReview: f.ho.requiresReview }); } catch (e: any) { failed.push(`Thông tin bàn giao: ${e.message}`); }
    }
    // Phân lớp: tạo phần việc con theo giai đoạn (mỗi phòng ban/nhóm nhận phần của mình; giai đoạn sau mở khi giai đoạn trước xong)
    for (const st of f.stages.filter((x: any) => x.title.trim())) {
      // Một công đoạn có thể giao cùng lúc cho nhiều trưởng nhóm: mỗi nhóm nhận một phần việc song song
      const gids: string[] = st.groupIds?.length ? st.groupIds : [st.groupId || f.groupId];
      for (const gid of gids) {
        try {
          await post('/tasks', { parentId: t.id, title: st.title.trim(), groupId: gid, stageNo: st.stage, estimatedHours: Number(st.hours) || undefined, standardMinutes: Math.round((Number(st.hours) || 0) * 60) || undefined,
            ownerMemberId: !isOrder && gid === f.groupId ? f.ownerMemberId : undefined });
        } catch (e: any) { failed.push(`Phần việc "${st.title}": ${e.message}`); }
      }
    }
    for (const p of f.permits.filter((x: any) => x.enabled)) {
      const pt = (permitTypes.data || []).find((x: any) => x.id === p.typeId);
      try {
        await post('/permits', { typeId: p.typeId, taskId: t.id, holderId: f.ownerMemberId, data: p.data, mode: p.mode, companionIds: (p.companionIds || []).filter((x: string) => x !== f.ownerMemberId),
          validFrom: new Date().toISOString(), validTo: fromLocalInput(f.dueAt) });
      } catch (e: any) { failed.push(`${pt?.name}: ${e.message}`); }
    }
    // Chuỗi đơn hàng: tính deadline từng công đoạn ngược từ hạn đơn (nhánh dài nhất, theo lịch làm việc)
    if (f.mode === 'new_chain' && f.stages.some((x: any) => x.title.trim())) {
      try { const sch = await post(`/chains/${t.id}/schedule`, { apply: true }); if (!sch.feasible) failed.push(sch.note); } catch (e: any) { failed.push(`Tính deadline: ${e.message}`); }
    }
    if (failed.length) sessionStorage.setItem('task_notice', 'Lưu ý — ' + failed.join('; '));
    nav(`/tasks/${t.id}`, { replace: true });
  });

  return (
    <>
      <Header title={isOrder ? 'Lập đơn hàng — chuỗi sản xuất' : step === 1 ? (presetOwner ? 'Giao việc nhanh' : 'Giao việc mới · 1/2 Nội dung') : 'Giao việc mới · 2/2 Chọn nhân viên'} back />
      <div className="page">
        {step === 1 && <>
        <div className="section-title" style={{ marginTop: 4 }}>Loại công việc giao</div>
        <div className="seg">
          {([['single', 'Việc đơn lẻ'], ...(canOrder ? [['new_chain', 'Đơn hàng mới'], ['existing_chain', 'Thuộc đơn hàng có sẵn']] : []), ['standing', 'Nhiệm vụ thường trực'], ['external', 'Chuyển giao bên ngoài']] as [string, string][]).map(([k, l]) => (
            <button key={k} type="button" className={f.mode === k ? 'on' : ''} onClick={() => up({ mode: k, isChain: k === 'new_chain', ...(k === 'new_chain' ? { taskTypeId: (types.data || []).find((t: any) => t.active && t.name === 'Sản xuất')?.id || f.taskTypeId, templateId: '' } : {}) })}>{l}</button>))}
        </div>
        {!canOrder && <Note>Lập đơn hàng/đơn hàng con chỉ dành cho Ban điều hành, quản lý cấp cao và Trưởng/Phó phòng Kinh doanh – Kế hoạch – Sản xuất.</Note>}
        {f.mode === 'new_chain' && (
          <div className="card">
            <div className="alert info small" style={{ marginTop: 0 }}>
              <b>Nhiệm vụ chuỗi sản xuất.</b> Đơn hàng không dùng mẫu công việc: khai báo các công đoạn và nhóm nhận ở phần “Công đoạn sản xuất”.
              {can(me, 'approve_order') ? ' Bạn có quyền duyệt — đơn được phát hành ngay sau khi lập.' : ' Sau khi lập, đơn chờ Kế hoạch/Sản xuất xem xét năng lực và Ban điều hành/quản lý cấp cao duyệt; chỉ khi được duyệt, trưởng nhóm mới lần lượt nhận công đoạn của mình.'}
            </div>
            <Field label="Vị trí làm việc" required hint="Nơi thực hiện đơn hàng">
              <div className="seg">{orderLocs.map((l: any) => <button key={l.id} type="button" className={f.workLocationId === l.id ? 'on' : ''} onClick={() => up({ workLocationId: l.id })}>{l.name}</button>)}</div>
              {orderLocs.length === 0 && <span className="small muted">Chưa khai báo vị trí — vào Cài đặt › Vị trí làm việc.</span>}
            </Field>
            <div className="grid2">
              <Field label="Mã đơn hàng" hint="Để trống: hệ thống tự tạo DH-xxxxx"><input value={f.chainCode} onChange={(e) => up({ chainCode: e.target.value })} placeholder="VD: PO-2024-118" /></Field>
              <Field label="Khách hàng"><input value={f.customerName} onChange={(e) => up({ customerName: e.target.value })} /></Field>
            </div>
            <div className="grid2">
              <Field label="Mức quan trọng"><Select value={f.importance} onChange={(v) => up({ importance: v })} options={{ normal: 'Thường', high: 'Quan trọng', critical: 'Rất quan trọng' }} /></Field>
              <Field label="Giá trị đơn (đ)" hint="Nhạy cảm: chỉ Ban quản trị và bạn thấy"><input type="number" min={0} value={f.orderValue} onChange={(e) => up({ orderValue: e.target.value })} /></Field>
            </div>
            <Field label="Ghi chú lợi nhuận" hint="Nhạy cảm"><input value={f.marginNote} onChange={(e) => up({ marginNote: e.target.value })} /></Field>
            <Note>Deadline bên dưới là hạn đơn hàng. Nhập thời lượng (giờ) cho từng công đoạn ở phần "Phân lớp / giai đoạn" — hệ thống tính ngược hạn từng công đoạn theo lịch làm việc.</Note>
          </div>
        )}
        {f.mode === 'existing_chain' && (
          <div className="card">
            <Field label="Mã đơn hàng" required><Select value={f.chainId} onChange={(v) => up({ chainId: v, chainStage: '' })} options={(chains.data || []).filter((c: any) => c.risk !== 'done').map((c: any) => [c.id, `${c.chain_code} - ${c.title}`])} placeholder="— Chọn đơn hàng —" /></Field>
            {chainDetail.data && (() => {
              const stg = chainDetail.data.stages as any[];
              const max = Math.max(0, ...stg.map((s) => s.stage_no));
              const open = stg.filter((s) => !['completed', 'cancelled'].includes(s.status)).map((s) => s.stage_no);
              const min = open.length ? Math.min(...open) : max + 1;
              const opts: [string, string][] = Array.from({ length: max + 1 }, (_, i) => i + 1).filter((n) => n >= min)
                .map((n) => [String(n), n <= max ? `Giai đoạn ${n}: ${stg.filter((s) => s.stage_no === n).map((s) => s.title).join(', ')} (song song)` : `Giai đoạn ${n} (mới — sau cùng)`]);
              return <Field label="Phân đoạn công việc" required hint="Không chọn được giai đoạn đã hoàn thành"><Select value={f.chainStage} onChange={(v) => up({ chainStage: v })} options={opts} placeholder="— Chọn giai đoạn —" /></Field>;
            })()}
            <Note>Nhiệm vụ sẽ là nhiệm vụ con của đơn hàng (hiển thị dạng {chainDetail.data?.chain_code || 'DH-xxxxx'}_NV-xxxxx); mô tả, loại việc kế thừa từ đơn.</Note>
          </div>
        )}
        {f.mode === 'external' && (
          <div className="card">
            <Note><b>Giao tiếp – chuyển giao bên ngoài công ty.</b> Khi xong, người thực hiện bấm “Đề nghị bàn giao” để tạo QR/link; người nhận xác nhận trên web, không cần cài app. Không quét được QR thì phải gửi giải trình và chờ bạn duyệt.</Note>
            <div className="grid2">
              <Field label="Người nhận" required><input value={f.ho.recipientName} onChange={(e) => up({ ho: { ...f.ho, recipientName: e.target.value } })} placeholder="Tên khách hàng/đối tác" /></Field>
              <Field label="Liên hệ người nhận" hint="Mã hóa khi lưu; chỉ nhập khi cần"><input value={f.ho.recipientContact} onChange={(e) => up({ ho: { ...f.ho, recipientContact: e.target.value } })} placeholder="SĐT hoặc email" /></Field>
            </div>
            <Field label="Nội dung bàn giao" required><textarea value={f.ho.description} onChange={(e) => up({ ho: { ...f.ho, description: e.target.value } })} placeholder="VD: 01 bộ hồ sơ báo giá + 05 mẫu bao bì" /></Field>
            <Field label="Địa điểm (nếu có)"><input value={f.ho.locationText} onChange={(e) => up({ ho: { ...f.ho, locationText: e.target.value } })} placeholder="Có thể bàn giao từ xa" /></Field>
            <label className="check"><input type="checkbox" checked={f.ho.allowReject} onChange={(e) => up({ ho: { ...f.ho, allowReject: e.target.checked } })} /> Cho phép người nhận “Không tiếp nhận” (bắt buộc lý do)</label>
            <label className="check"><input type="checkbox" checked={f.ho.requiresReview} onChange={(e) => up({ ho: { ...f.ho, requiresReview: e.target.checked } })} /> Sau khi người nhận xác nhận, còn bước nghiệm thu của tôi</label>
          </div>
        )}
        {f.mode === 'standing' && <Note>Nhiệm vụ thường trực không có hạn; thành viên nhóm chọn nó khi bắt đầu phiên làm việc. Có thể chia công đoạn ở phần "Phân lớp / giai đoạn".</Note>}
        {report.data && <div className="alert info small">Giao việc xử lý trở ngại <b>{report.data.code}</b> — tiêu đề và mô tả đã điền sẵn từ báo cáo. Khi việc hoàn thành, người báo cáo được mời xác nhận.</div>}
        {!isOrder && f.mode !== 'existing_chain' && templates.data?.length > 0 && (
          <>
            <div className="row" style={{ display: 'flex', alignItems: 'center', marginTop: 6 }}>
              <div className="section-title" style={{ flex: 1, margin: 0 }}>Chọn mẫu công việc <span className="small muted">— mẫu thuộc phòng ban bạn được giao việc{tplClosed && tpl ? ` · đang dùng: ${tpl.name}` : ''}</span></div>
              <button type="button" className="btn sm" onClick={toggleTpl} aria-expanded={!tplClosed}><Icon name={tplClosed ? 'chevron' : 'down'} size={16} />{tplClosed ? 'Mở rộng' : 'Thu gọn'}</button>
            </div>
            {!tplClosed && <div className="tpl-grid">
              {templates.data.map((t: any) => (
                <button key={t.id} type="button" className={`tpl ${f.templateId === t.id ? 'sel' : ''}`} onClick={() => applyTemplate(f.templateId === t.id ? '' : t.id)} aria-pressed={f.templateId === t.id}>
                  <span className="ichip blue" style={{ width: 36, height: 36 }}><Icon name={t.icon || 'work'} size={19} /></span>{t.name}
                </button>
              ))}
            </div>}
          </>
        )}
        {!isOrder && tpl?.fields?.length > 0 && (
          <div className="card">
            <b className="small">Khai báo theo mẫu “{tpl.name}”</b>
            {tpl.fields.map((x: any) => (
              <Field key={x.key} label={x.label} required={x.required && !(isTicketField(x) && f.noTicket[x.key])}>
                {isTicketField(x) && <label className="check" style={{ margin: '0 0 4px' }}><input type="checkbox" checked={!!f.noTicket[x.key]} onChange={(e) => up({ noTicket: { ...f.noTicket, [x.key]: e.target.checked }, fieldValues: { ...f.fieldValues, [x.key]: e.target.checked ? '' : f.fieldValues[x.key] } })} /> Không có {x.label.toLowerCase()}</label>}
                {isTicketField(x) && f.noTicket[x.key] ? null : x.type === 'textarea'
                  ? <textarea value={f.fieldValues[x.key] || ''} onChange={(e) => up({ fieldValues: { ...f.fieldValues, [x.key]: e.target.value } })} />
                  : <input type={x.type === 'number' ? 'number' : x.type === 'date' ? 'date' : x.type === 'datetime' ? 'datetime-local' : 'text'} value={f.fieldValues[x.key] || ''} onChange={(e) => up({ fieldValues: { ...f.fieldValues, [x.key]: e.target.value } })} />}
              </Field>
            ))}
          </div>
        )}
        <Field label="Tiêu đề" required><input value={f.title} onChange={(e) => up({ title: e.target.value })} /></Field>
        <Field label="Mô tả / phạm vi" required hint="Bối cảnh, yêu cầu, giới hạn và nội dung cần thực hiện"><textarea value={f.description} onChange={(e) => up({ description: e.target.value })} /></Field>
        <div className="grid2">
          <Field label={isOrder ? 'Nhóm phụ trách điều hành' : 'Nhóm'} required hint={isOrder ? 'Thành viên nhóm nhận thông báo khi đơn được lập' : undefined}><Select value={f.groupId} onChange={(v) => up({ groupId: v, ownerMemberId: '', collaboratorIds: [] })} options={(isOrder ? (allGroups.data || managed) : managed).map((g: any) => [g.id, g.name])} placeholder="— Chọn nhóm —" /></Field>
          {isOrder ? <Field label="Loại công việc"><input value="Chuỗi công việc sản xuất" disabled /></Field>
            : <Field label="Loại công việc" required><Select value={f.taskTypeId} onChange={(v) => up({ taskTypeId: v })} options={(types.data || []).filter((t: any) => t.active).map((t: any) => [t.id, t.name])} /></Field>}
        </div>
        {isOrder && <Field label="Người phụ trách điều hành" hint="Có thể là chính người lập đơn"><Select value={f.ownerMemberId} onChange={(v) => up({ ownerMemberId: v })}
          options={[[me?.member_id || '', `${me?.name} (tôi — người lập đơn)`] as [string, string], ...(coordGroup.data ? [[coordGroup.data.manager_member_id, `${coordGroup.data.manager_name} (quản lý nhóm)`] as [string, string], ...coordGroup.data.members.filter((m: any) => m.member_id !== coordGroup.data.manager_member_id && m.member_id !== me?.member_id).map((m: any) => [m.member_id, m.name] as [string, string])] : [])].filter((x, i, arr) => x[0] && arr.findIndex((y) => y[0] === x[0]) === i)}
          placeholder="— Trưởng nhóm điều hành —" /></Field>}
        <div className="grid2">
        </div>
        <div className="grid2">
          <Field label="Độ phức tạp" required><Select value={f.complexity} onChange={(v) => up({ complexity: v })} options={COMPLEXITY} /></Field>
          <Field label="Mức yêu cầu" required><Select value={f.requirementLevel} onChange={(v) => up({ requirementLevel: v })} options={REQ} /></Field>
        </div>
        <div className="grid2">
          <Field label="Thời lượng dự kiến (giờ)" required hint={`Tham khảo: ${GUIDE[f.complexity]?.[f.requirementLevel === 'normal' ? 'normal' : 'high']}`}>
            <input type="number" min={0.5} step={0.5} value={f.estimatedHours} onChange={(e) => up({ estimatedHours: e.target.value })} />
          </Field>
          <Field label="Ưu tiên"><Select value={f.priority} onChange={(v) => up({ priority: v })} options={PRIORITY} /></Field>
        </div>
        <Field label="Deadline" required hint="Tính theo giờ làm việc của công ty khi dùng gợi ý">
          <div className="row" style={{ display: 'flex', gap: 8 }}>
            <input type="datetime-local" value={f.dueAt} onChange={(e) => up({ dueAt: e.target.value })} />
            <button type="button" className="btn sm" onClick={suggestDue}>Gợi ý</button>
          </div>
        </Field>
        <div className="grid2">
          <Field label="Ngày bắt đầu làm (lịch)" hint="Hiện trong danh sách việc của ngày này"><input type="date" value={f.planDate} onChange={(e) => up({ planDate: e.target.value })} /></Field>
          <Field label="Việc gấp"><label className="check" style={{ margin: '10px 0' }}><input type="checkbox" checked={f.pinned} onChange={(e) => up({ pinned: e.target.checked })} /> 📌 Ghim lên đầu danh sách</label></Field>
        </div>
        <Field label="Nguồn lực / phụ thuộc"><input value={f.resources} onChange={(e) => up({ resources: e.target.value })} placeholder="Tài liệu, thiết bị, ngân sách, phòng ban hỗ trợ" /></Field>

        <div className="section-title">Đầu vào & tiêu chí đầu ra (nghiệm thu)</div>
        {f.criteria.map((c: any, i: number) => (
          <div key={i} style={{ display: 'flex', gap: 6, marginBottom: 6 }}>
            <select style={{ width: 110 }} value={c.direction} onChange={(e) => setCrit(i, { direction: e.target.value })}><option value="input">Đầu vào</option><option value="output">Đầu ra</option></select>
            <input value={c.criterion} placeholder={c.direction === 'output' ? 'Điều kiện nghiệm thu' : 'Yêu cầu/dữ liệu đầu vào'} onChange={(e) => setCrit(i, { criterion: e.target.value })} />
            <button type="button" className="icon-btn" aria-label="Xóa" onClick={() => up({ criteria: f.criteria.filter((_: any, j: number) => j !== i) })}><Icon name="close" size={20} /></button>
          </div>
        ))}
        <div className="actions">
          <button type="button" className="btn sm" onClick={() => up({ criteria: [...f.criteria, { direction: 'output', criterion: '' }] })}><Icon name="plus" size={16} />Tiêu chí đầu ra</button>
          <button type="button" className="btn sm" onClick={() => up({ criteria: [...f.criteria, { direction: 'input', criterion: '' }] })}><Icon name="plus" size={16} />Đầu vào</button>
        </div>

        {false && (
          <div className="card">
            <div className="grid2">
              <Field label="Khách hàng"><input value={f.customerName} onChange={(e) => up({ customerName: e.target.value })} /></Field>
              <Field label="Mức quan trọng"><Select value={f.importance} onChange={(v) => up({ importance: v })} options={{ normal: 'Thường', high: 'Quan trọng', critical: 'Rất quan trọng' }} /></Field>
            </div>
            <div className="grid2">
              <Field label="Giá trị đơn (đ)" hint="Nhạy cảm: chỉ Ban quản trị và bạn thấy"><input type="number" min={0} value={f.orderValue} onChange={(e) => up({ orderValue: e.target.value })} /></Field>
              <Field label="Ghi chú lợi nhuận" hint="Nhạy cảm"><input value={f.marginNote} onChange={(e) => up({ marginNote: e.target.value })} /></Field>
            </div>
            <Note>Deadline ở trên là hạn đơn hàng. Nhập thời lượng chuẩn (giờ) cho từng công đoạn bên dưới — hệ thống tính ngược hạn từng công đoạn theo lịch làm việc và cảnh báo nếu không đủ thời gian. Điều phối do người có thẩm quyền quyết định.</Note>
          </div>
        )}
        <div className="grid2">
          {!isOrder && <Field label="Vị trí làm việc (không bắt buộc)"><Select value={f.workLocationId} onChange={(v) => up({ workLocationId: v })} options={(locs.data || []).filter((l: any) => l.active).map((l: any) => [l.id, l.name])} placeholder="— Không cố định —" /></Field>}
          <Field label="Định mức sản lượng"><Select value={f.productionStandardId} onChange={(v) => up({ productionStandardId: v })} options={(stds.data || []).filter((s: any) => s.active).map((s: any) => [s.id, `${s.name} (${Number(s.quantity)} ${s.unit}/${Number(s.minutes)}p)`])} placeholder="— Không áp dụng —" /></Field>
        </div>
        {f.workLocationId && !isOrder && <label className="check"><input type="checkbox" checked={f.locationRequired} onChange={(e) => up({ locationRequired: e.target.checked })} /> Bắt buộc ghi nhận vị trí khi bắt đầu phiên (việc có địa điểm cố định)</label>}
        {f.mode !== 'standing' && <Field label="Bắt đầu"><Select value={f.autoStart} onChange={(v) => up({ autoStart: v })} options={f.mode === 'existing_chain' ? AUTO_START : { manual: AUTO_START.manual, scheduled: AUTO_START.scheduled }} /></Field>}
        {f.autoStart === 'scheduled' && <Field label="Thời điểm bắt đầu theo lịch" required><input type="datetime-local" value={f.scheduledStartAt} onChange={(e) => up({ scheduledStartAt: e.target.value })} /></Field>}
        {f.mode !== 'existing_chain' && <StageBuilder f={f} up={up} groups={(allGroups.data || groups.data || []).filter((g: any) => !isOrder || g.department_function !== 'hr')} order={isOrder} />}

        <div className="row" style={{ display: 'flex', alignItems: 'center' }}>
          <div className="section-title" style={{ flex: 1 }}>Giấy phép cần chuẩn bị{permitClosed && f.permits.filter((x: any) => x.enabled).length ? ` · đã chọn ${f.permits.filter((x: any) => x.enabled).length}` : ''}</div>
          <button type="button" className="btn sm" onClick={togglePermit} aria-expanded={!permitClosed}><Icon name={permitClosed ? 'chevron' : 'down'} size={16} />{permitClosed ? 'Mở rộng' : 'Thu gọn'}</button>
        </div>
        {!permitClosed && <>
        <Note>Thiết bị dùng trong phòng ban / vị trí thực hiện không cần giấy phép; chỉ cần khi mang ra – vào. Người giao việc chuẩn bị sẵn giấy phép — nhân viên không phải tự đi xin. Giấy phép gửi tới phòng ban phụ trách; chọn “Khai báo” để có hiệu lực ngay (phòng ban hậu kiểm sau, quy trình sai người giao chịu trách nhiệm).</Note>
        {(permitTypes.data || []).filter((pt: any) => pt.active).map((pt: any) => {
          const p = f.permits.find((x: any) => x.typeId === pt.id);
          const on = !!p?.enabled;
          return (
            <div key={pt.id} className="card" style={{ padding: 10 }}>
              <label className="check" style={{ margin: 0 }}>
                <input type="checkbox" checked={on} onChange={(e) => setPermit(pt.id, { enabled: e.target.checked, mode: p?.mode || (pt.allow_declaration ? 'declaration' : 'approval') })} />
                <Icon name={pt.icon || 'permit'} size={18} /> <b>{pt.name}</b>
              </label>
              {on && (
                <div style={{ marginTop: 6 }}>
                  <div className="small muted">Phòng ban xử lý: {pt.department_name || 'Quản trị công ty'}</div>
                  <Select value={p.mode} onChange={(v) => setPermit(pt.id, { mode: v })} options={pt.allow_declaration ? { declaration: 'Khai báo — cấp tự động, hậu kiểm sau', approval: 'Chờ phòng ban duyệt' } : { approval: 'Chờ phòng ban duyệt' }} />
                  {(pt.fields || []).map((x: any) => (
                    <Field key={x.key} label={x.label} required={x.required}>
                      {x.type === 'textarea' ? <textarea value={p.data[x.key] || ''} onChange={(e) => setPermit(pt.id, { data: { ...p.data, [x.key]: e.target.value } })} />
                        : <input type={x.type === 'number' ? 'number' : 'text'} value={p.data[x.key] || ''} onChange={(e) => setPermit(pt.id, { data: { ...p.data, [x.key]: e.target.value } })} />}
                    </Field>
                  ))}
                  {pt.allow_companions && people.length > 1 && (
                    <Field label="Người đi cùng (nếu có)">
                      <div className="chip-row">{people.filter(([pid]) => pid !== f.ownerMemberId).map(([pid, n]) => { const on = (p.companionIds || []).includes(pid); return <button key={pid} type="button" className={`btn sm ${on ? 'primary' : ''}`} onClick={() => setPermit(pt.id, { companionIds: on ? p.companionIds.filter((x: string) => x !== pid) : [...(p.companionIds || []), pid] })}>{n}</button>; })}</div>
                    </Field>
                  )}
                  <div className="small muted">Người cấp phép: bạn (người giao việc) · Người sử dụng: người được giao việc · {pt.usage === 'single' ? 'Dùng 1 lần' : 'Dùng nhiều lần'} · hiệu lực từ lúc giao đến deadline.</div>
                </div>
              )}
            </div>
          );
        })}

        </>}
        <label className="check"><input type="checkbox" checked={f.isUnexpected} onChange={(e) => up({ isUnexpected: e.target.checked })} /> Đây là công việc đột xuất / phát sinh</label>
        {f.isUnexpected && (
          <div className="card">
            <div className="grid2">
              <Field label="Loại phát sinh"><Select value={f.unexpected.category} onChange={(v) => up({ unexpected: { ...f.unexpected, category: v } })} options={UNEXPECTED_CAT} /></Field>
              <Field label="Cấu trúc yêu cầu"><Select value={f.unexpected.requirementStructure} onChange={(v) => up({ unexpected: { ...f.unexpected, requirementStructure: v } })} options={REQ_STRUCT} /></Field>
            </div>
            <Field label="Nguyên nhân phát sinh"><Select value={f.unexpected.cause} onChange={(v) => up({ unexpected: { ...f.unexpected, cause: v } })} options={UNEXPECTED_CAUSE} /></Field>
            <Field label="Chi tiết nguyên nhân"><input value={f.unexpected.causeDetail} onChange={(e) => up({ unexpected: { ...f.unexpected, causeDetail: e.target.value } })} /></Field>
            <Field label="Ảnh hưởng đến việc thường xuyên/deadline khác/nguồn lực"><textarea value={f.unexpected.impact} onChange={(e) => up({ unexpected: { ...f.unexpected, impact: e.target.value } })} /></Field>
            {f.unexpected.requirementStructure === 'diverse' && (
              <>
                <div className="section-title">Yêu cầu thành phần</div>
                {f.subitems.map((s: any, i: number) => (
                  <div key={i} style={{ display: 'flex', gap: 6, marginBottom: 6 }}>
                    <input value={s.title} placeholder="Đầu việc con" onChange={(e) => up({ subitems: f.subitems.map((x: any, j: number) => (j === i ? { ...x, title: e.target.value } : x)) })} />
                    <button type="button" className="icon-btn" aria-label="Xóa" onClick={() => up({ subitems: f.subitems.filter((_: any, j: number) => j !== i) })}><Icon name="close" size={20} /></button>
                  </div>
                ))}
                <button type="button" className="btn sm" onClick={() => up({ subitems: [...f.subitems, { title: '', extraHours: 0 }] })}><Icon name="plus" size={16} />Đầu việc con</button>
              </>
            )}
          </div>
        )}
        <ErrorBox error={stepErr} />
        {presetOwner && f.ownerMemberId ? (
          <>
            <div className="alert info small">Người nhận việc: <b>{people.find((p) => p[0] === f.ownerMemberId)?.[1] || '…'}</b></div>
            <button className="btn primary block" disabled={a.busy} onClick={next}><Icon name="assign" size={18} />{a.busy ? 'Đang giao…' : 'Giao việc'}</button>
            <ErrorBox error={a.error} />
            <button className="btn block" style={{ marginTop: 8 }} onClick={() => { setStepErr(null); setStep(2); }}>Chọn người khác ›</button>
          </>
        ) : isOrder ? (
          <>
            <button className="btn primary block" disabled={a.busy} onClick={next}><Icon name="flow" size={18} />{a.busy ? 'Đang lập đơn…' : can(me, 'approve_order') ? 'Lập & phát hành đơn hàng' : 'Lập đơn & gửi xem xét'}</button>
            <ErrorBox error={a.error} />
          </>
        ) : <button className="btn primary block" onClick={next}>Tiếp: chọn nhân viên ›</button>}
        </>}
        {step === 2 && <PickPeople f={f} up={up} people={people} groups={managed} canMulti={(can(me, 'assign_dept') || can(me, 'assign_all')) && f.mode !== 'external'} onBack={() => setStep(1)} onSubmit={submit} busy={a.busy} error={a.error} />}
      </div>
    </>
  );
}

/** Bước 2: chọn người thực hiện, xem trạng thái nhân viên (nghỉ phép, khối lượng việc) trước khi giao. */
function PickPeople({ f, up, people, groups, canMulti, onBack, onSubmit, busy, error }: { f: any; up: (p: any) => void; people: [string, string][]; groups: any[]; canMulti: boolean; onBack: () => void; onSubmit: () => void; busy: boolean; error: string | null }) {
  const multi = f.multiGroupIds.length > 0;
  const leaders = groups.filter((g: any) => g.leader_id);
  if (canMulti && leaders.length > 1 && (multi || f.pickMode === 'multi')) {
    const toggle = (id: string) => up({ multiGroupIds: f.multiGroupIds.includes(id) ? f.multiGroupIds.filter((x: string) => x !== id) : [...f.multiGroupIds, id] });
    return (
      <>
        <div className="seg"><button type="button" onClick={() => up({ pickMode: 'one', multiGroupIds: [] })}>Một người</button><button type="button" className="on">Nhiều trưởng nhóm</button></div>
        <Note>Mỗi nhóm được chọn nhận một nhiệm vụ riêng với cùng nội dung; trưởng nhóm chịu trách nhiệm và tự phân công trong nhóm.</Note>
        {leaders.map((g: any) => (
          <button key={g.id} className={`pick ${f.multiGroupIds.includes(g.id) ? 'sel' : ''}`} onClick={() => toggle(g.id)} aria-pressed={f.multiGroupIds.includes(g.id)}>
            <div className="main"><b>{g.name}</b><div className="small muted">Trưởng nhóm: {g.leader_name}{g.department_name ? ` · ${g.department_name}` : ''} · {g.open_tasks} việc đang mở</div></div>
            {f.multiGroupIds.includes(g.id) && <Badge tone="blue">Đã chọn</Badge>}
          </button>
        ))}
        <ErrorBox error={error} />
        <div className="actions">
          <button className="btn" onClick={onBack}><Icon name="back" size={16} />Quay lại</button>
          <button className="btn primary" style={{ flex: 1 }} disabled={busy || f.multiGroupIds.length === 0} onClick={onSubmit}>{busy ? 'Đang giao việc…' : `Giao cho ${f.multiGroupIds.length} trưởng nhóm`}</button>
        </div>
      </>
    );
  }
  const from = isoDate(new Date());
  const to = f.dueAt ? f.dueAt.slice(0, 10) : from;
  const av = useLoad(() => get('/team/availability' + qs({ from, to: to < from ? from : to, groupId: f.groupId })), [f.groupId, to]);
  const byId = Object.fromEntries((av.data?.members || []).map((m: any) => [m.member_id, m]));
  const ids = people.map(([id]) => id);
  return (
    <>
      {canMulti && leaders.length > 1 && <div className="seg"><button type="button" className="on">Một người</button><button type="button" onClick={() => up({ pickMode: 'multi' })}>Nhiều trưởng nhóm</button></div>}
      <div className="alert info small">Trạng thái tính trong khoảng {new Date(from).toLocaleDateString('vi-VN')} – {new Date(to < from ? from : to).toLocaleDateString('vi-VN')} (đến deadline). Ưu tiên người đang sẵn sàng.</div>
      <div className="section-title">Người chịu trách nhiệm chính</div>
      {av.loading && !av.data && <Loading />}
      {ids.map((id) => {
        const m = byId[id]; const name = people.find((p) => p[0] === id)?.[1];
        const st = m ? AVAIL[m.status] : null;
        return (
          <button key={id} className={`pick ${f.ownerMemberId === id ? 'sel' : ''}`} onClick={() => up({ ownerMemberId: id, collaboratorIds: f.collaboratorIds.filter((x: string) => x !== id) })} aria-pressed={f.ownerMemberId === id}>
            <Avatar userId={m?.user_id} name={name} has={m?.has_avatar} />
            <div className="main">
              <b>{name}</b>
              {m && <div className="small muted">{m.open_tasks} việc đang mở · {m.open_hours} giờ dự kiến{m.overdue ? ` · ${m.overdue} quá hạn` : ''}{m.pinned ? ` · ${m.pinned} việc gấp` : ''}</div>}
              {m?.leaves?.length > 0 && <div className="small" style={{ color: 'var(--teal)' }}><Icon name="leave" size={16} />{m.leaves.map((l: any) => `${LEAVE_TYPE[l.leave_type]} ${new Date(l.start_at).toLocaleDateString('vi-VN')}${l.status === 'pending' ? ' (chờ duyệt)' : ''}`).join('; ')}</div>}
            </div>
            {st && <Badge tone={st[1]}>{st[0]}</Badge>}
          </button>
        );
      })}
      {ids.length > 1 && f.ownerMemberId && (
        <Field label="Cộng tác viên (không bắt buộc)">
          <div className="chip-row">
            {people.filter(([id]) => id !== f.ownerMemberId).map(([id, n]) => (
              <label key={id} className="check" style={{ margin: 0, marginRight: 10 }}>
                <input type="checkbox" checked={f.collaboratorIds.includes(id)} onChange={(e) => up({ collaboratorIds: e.target.checked ? [...f.collaboratorIds, id] : f.collaboratorIds.filter((x: string) => x !== id) })} />{n}{byId[id]?.status === 'on_leave' ? ' 🌴' : ''}
              </label>
            ))}
          </div>
        </Field>
      )}
      {byId[f.ownerMemberId]?.status === 'on_leave' && <div className="alert warn small">Người này có lịch nghỉ phép trong thời gian thực hiện — cân nhắc đổi người hoặc điều chỉnh deadline.</div>}
      <ErrorBox error={error} />
      <div className="actions">
        <button className="btn" onClick={onBack}><Icon name="back" size={16} />Quay lại</button>
        <button className="btn primary" style={{ flex: 1 }} disabled={busy || !f.ownerMemberId} onClick={onSubmit}>{busy ? 'Đang giao việc…' : 'Giao việc'}</button>
      </div>
    </>
  );
}

/** Phân lớp công việc qua các giai đoạn / phòng ban. Cùng giai đoạn = song song; phòng ban không do bạn quản lý cần cấp trên duyệt. */
function StageBuilder({ f, up, groups, order }: { f: any; up: (p: any) => void; groups: any[]; order?: boolean }) {
  const st: any[] = f.stages;
  const set = (i: number, p: any) => up({ stages: st.map((x, j) => (j === i ? { ...x, ...p } : x)) });
  const maxStage = Math.max(0, ...st.map((x) => x.stage));
  const add = (stage: number) => up({ stages: [...st, { stage, title: '', groupId: order ? '' : f.groupId, groupIds: [], hours: 2 }].sort((a, b) => a.stage - b.stage) });
  const toggleG = (i: number, gid: string) => { const cur: string[] = st[i].groupIds || []; set(i, { groupIds: cur.includes(gid) ? cur.filter((x) => x !== gid) : [...cur, gid] }); };
  const stages = [...new Set(st.map((x) => x.stage))].sort((a, b) => a - b);
  return (
    <>
      <div className="section-title">{order ? 'Công đoạn sản xuất' : 'Phân lớp / giai đoạn (tùy chọn)'}</div>
      {order && <Note>Mỗi công đoạn chọn một hoặc nhiều nhóm — trưởng nhóm của nhóm đó nhận việc. Trưởng nhóm nhận công đoạn lần lượt: giai đoạn sau chỉ mở khi giai đoạn trước hoàn thành (cùng giai đoạn chạy song song).</Note>}
      {!order && <Note>Ví dụ nhập hàng: GĐ1 đặt hàng → GĐ2 nhận hàng + kiểm hàng (song song, có thể hai người khác nhau) → GĐ3 nhập kho. Mỗi phần việc có thể giao cho phòng ban khác; quản lý phòng ban đó nhận và theo dõi. Giai đoạn sau tự nhận thông báo khi giai đoạn trước xong.</Note>}
      {stages.map((sn) => (
        <div key={sn} className="stage-box">
          <div className="stage-h">Giai đoạn {sn}</div>
          {st.map((x, i) => x.stage !== sn ? null : (
            <div key={i} style={{ display: 'grid', gridTemplateColumns: '1fr auto', gap: 6, marginBottom: 6 }}>
              <input value={x.title} placeholder="Tên phần việc" onChange={(e) => set(i, { title: e.target.value })} />
              <button type="button" className="icon-btn" aria-label="Xóa" onClick={() => up({ stages: st.filter((_, j) => j !== i) })}><Icon name="close" size={20} /></button>
              {order ? (
                <div style={{ gridColumn: '1 / -1' }}>
                  <div className="chip-row">
                    {groups.map((g: any) => {
                      const on = (x.groupIds || []).includes(g.id);
                      return <button key={g.id} type="button" className={`btn sm ${on ? 'primary' : ''}`} onClick={() => toggleG(i, g.id)} aria-pressed={on}>{g.name}</button>;
                    })}
                  </div>
                  {(x.groupIds || []).length > 0 && <div className="small muted">Trưởng nhóm nhận: {(x.groupIds || []).map((id: string) => { const g = groups.find((y: any) => y.id === id); return g ? `${g.leader_name || g.manager_name} (${g.name})` : ''; }).join(', ')}</div>}
                  <input style={{ width: 120, marginTop: 4 }} type="number" min={0.5} step={0.5} value={x.hours} onChange={(e) => set(i, { hours: e.target.value })} aria-label="Giờ chuẩn" title="Giờ chuẩn của công đoạn" />
                </div>
              ) : <div style={{ display: 'flex', gap: 6, gridColumn: '1 / -1' }}>
                <select value={x.groupId || f.groupId} onChange={(e) => set(i, { groupId: e.target.value })} aria-label="Phòng ban/nhóm">
                  {groups.map((g: any) => <option key={g.id} value={g.id}>{g.name}{g.is_manager ? '' : ' · nhóm khác'}</option>)}
                </select>
                <input style={{ width: 80 }} type="number" min={0.5} step={0.5} value={x.hours} onChange={(e) => set(i, { hours: e.target.value })} aria-label="Giờ dự kiến" title="Giờ dự kiến" />
              </div>}
            </div>
          ))}
          <button type="button" className="btn sm" onClick={() => add(sn)}><Icon name="plus" size={16} />Việc song song trong GĐ {sn}</button>
        </div>
      ))}
      <div className="actions">
        <button type="button" className="btn sm" onClick={() => add(maxStage + 1)}><Icon name="plus" size={16} />Thêm giai đoạn {maxStage + 1}</button>
        {order && st.length === 0 && <button type="button" className="btn sm primary" onClick={() => up({ stages: STD_CHAIN.map(([title, h], i) => ({ stage: i + 1, title, groupId: '', groupIds: [], hours: h })) })}>Dùng chuỗi sản xuất chuẩn</button>}
      </div>
      {order && <Note>Chuỗi chuẩn: Tính toán nguyên liệu → Thiết kế lại bao bì (nếu cần, xóa nếu không) → Mua nguyên liệu → Sản xuất → Đóng gói → Giao hàng. Mỗi công đoạn chọn nhóm nhỏ phụ trách; thành viên nhóm được báo 2 lần: khi đơn được duyệt và khi công đoạn của họ bắt đầu.</Note>}
    </>
  );
}

/** Chuỗi công việc sản xuất chuẩn (v10). */
const STD_CHAIN: [string, number][] = [['Tính toán nguyên liệu', 2], ['Thiết kế lại bao bì (nếu cần)', 4], ['Mua nguyên liệu', 8], ['Sản xuất', 16], ['Đóng gói', 8], ['Giao hàng', 4]];
