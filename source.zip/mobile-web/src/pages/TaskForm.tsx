import { useEffect, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { get, post, qs } from '../api';
import { isAdminRole, useAuth } from '../auth';
import { Avatar, Badge, ErrorBox, Field, Header, Loading, Select, useAction, useLoad } from '../ui';
import { Icon } from '../icons';
import { AVAIL, COMPLEXITY, LEAVE_TYPE, PRIORITY, REQ, REQ_STRUCT, UNEXPECTED_CAT, UNEXPECTED_CAUSE, fromLocalInput, isoDate, toLocalInput } from '../labels';

const GUIDE: Record<string, Record<string, string>> = {
  simple: { normal: '2–4 giờ', high: '4–8 giờ' }, medium: { normal: '1–2 ngày', high: '2–3 ngày' },
  complex: { normal: '3–5 ngày', high: '5–8 ngày' }, very_complex: { normal: '1–2 tuần', high: '2–4 tuần' },
};

export default function TaskForm() {
  const nav = useNavigate();
  const { me } = useAuth();
  const a = useAction();
  const groups = useLoad(() => get('/groups'), []);
  const types = useLoad(() => get('/company/task-types'), []);
  const templates = useLoad(() => get('/company/task-templates'), []);
  const permitTypes = useLoad(() => get('/permit-types'), []);
  const [sp] = useSearchParams();
  const presetOwner = sp.get('owner') || '';
  const reportId = sp.get('reportId') || '';
  const report = useLoad(() => (reportId ? get(`/workplace-reports/${reportId}`) : Promise.resolve(null)), [reportId]);
  const allGroups = useLoad(() => get('/groups?scope=all'), []);
  const [f, setF] = useState<any>({
    templateId: '', fieldValues: {} as Record<string, string>, permits: [] as any[],
    title: '', description: '', groupId: sp.get('group') || '', ownerMemberId: presetOwner, collaboratorIds: [] as string[], taskTypeId: '', complexity: 'medium',
    requirementLevel: 'normal', estimatedHours: 8, dueAt: toLocalInput(new Date(Date.now() + 2 * 86400000)), priority: 'normal', resources: '',
    criteria: [{ direction: 'input', criterion: '' }, { direction: 'output', criterion: '' }], isUnexpected: false,
    unexpected: { category: 'ad_hoc', requirementStructure: 'common', cause: 'superior_request', causeDetail: '', impact: '' }, subitems: [] as { title: string; extraHours: number }[], planDate: isoDate(new Date()), pinned: false,
    stages: [] as { stage: number; title: string; groupId: string; hours: number }[],
    isChain: false, customerName: '', importance: 'normal', orderValue: '', marginNote: '', workLocationId: '', locationRequired: false, productionStandardId: '',
  });
  const locs = useLoad(() => get('/company/locations'), []);
  const stds = useLoad(() => get('/company/production-standards'), []);
  const up = (p: any) => setF((x: any) => ({ ...x, ...p }));
  const [step, setStep] = useState(1);
  const managed = (groups.data || []).filter((g: any) => g.is_manager || isAdminRole(me?.role));
  const group = useLoad(() => (f.groupId ? get(`/groups/${f.groupId}`) : Promise.resolve(null)), [f.groupId]);
  const people: [string, string][] = group.data ? [[group.data.manager_member_id, `${group.data.manager_name} (quản lý)`], ...group.data.members.filter((m: any) => m.member_id !== group.data.manager_member_id).map((m: any) => [m.member_id, m.name] as [string, string])] : [];

  useEffect(() => { if (!f.groupId && managed.length === 1) up({ groupId: managed[0].id }); }, [groups.data]);
  useEffect(() => { if (!f.taskTypeId && types.data?.length) up({ taskTypeId: types.data.find((t: any) => t.active)?.id }); }, [types.data]);
  // Giao việc xử lý trở ngại: điền sẵn tiêu đề, mô tả từ báo cáo
  useEffect(() => {
    const w = report.data; if (!w) return;
    const sevHigh = ['high', 'critical'].includes(w.severity);
    up({
      title: `Xử lý trở ngại ${w.code}: ${w.description.split(/[.\n]/)[0].slice(0, 70)}`,
      description: `${w.description}${w.location ? `\nVị trí: ${w.location}` : ''}${w.asset ? `\nTài sản: ${w.asset}` : ''}${w.temp_measure ? `\nBiện pháp tạm thời: ${w.temp_measure}` : ''}\n(Người báo: ${w.reporter_name})`,
      groupId: w.group_id && managed.some((g: any) => g.id === w.group_id) ? w.group_id : (managed[0]?.id || ''),
      complexity: 'simple', estimatedHours: 2, pinned: sevHigh, priority: sevHigh ? 'urgent' : 'high',
      dueAt: w.stage_due_at ? toLocalInput(new Date(w.stage_due_at)) : toLocalInput(new Date(Date.now() + 86400000)),
      criteria: [{ direction: 'output', criterion: 'Trở ngại được khắc phục, người báo cáo xác nhận' }],
    });
  }, [report.data, groups.data]);

  const tpl = templates.data?.find((x: any) => x.id === f.templateId);
  const applyTemplate = (id: string) => {
    const t = templates.data?.find((x: any) => x.id === id);
    if (!t) { up({ templateId: '', permits: [] }); return; }
    const pts = permitTypes.data || [];
    up({ templateId: id, fieldValues: {}, title: t.name, description: t.description || '', taskTypeId: t.task_type_id || f.taskTypeId, complexity: t.complexity, requirementLevel: t.requirement_level,
      estimatedHours: t.estimated_hours, criteria: t.criteria.length ? t.criteria : f.criteria,
      stages: (t.stages || []).flatMap((st: any) => st.items.map((it: any) => ({ stage: st.stage, title: it.title, groupId: f.groupId, hours: it.hours || 2 }))),
      permits: (t.permit_keys || []).map((k: string) => pts.find((p: any) => p.key === k && p.active)).filter(Boolean)
        .map((p: any) => ({ typeId: p.id, enabled: true, mode: p.allow_declaration ? 'declaration' : 'approval', data: {} })) });
  };
  const setPermit = (typeId: string, patch: any) => {
    const ex = f.permits.find((p: any) => p.typeId === typeId);
    up({ permits: ex ? f.permits.map((p: any) => (p.typeId === typeId ? { ...p, ...patch } : p)) : [...f.permits, { typeId, enabled: true, mode: 'approval', data: {}, ...patch }] });
  };
  const suggestDue = async () => {
    const r = await get('/company/calendar/suggest-due' + qs({ hours: f.estimatedHours }));
    up({ dueAt: toLocalInput(new Date(r.due_at)) });
  };
  const setCrit = (i: number, p: any) => up({ criteria: f.criteria.map((c: any, j: number) => (j === i ? { ...c, ...p } : c)) });

  const [stepErr, setStepErr] = useState<string | null>(null);
  const next = () => {
    const tplMiss = (tpl?.fields || []).filter((x: any) => x.required && !String(f.fieldValues[x.key] || '').trim()).map((x: any) => x.label);
    const permitMiss = f.permits.filter((p: any) => p.enabled).flatMap((p: any) => {
      const t = (permitTypes.data || []).find((x: any) => x.id === p.typeId);
      return (t?.fields || []).filter((x: any) => x.required && !String(p.data[x.key] || '').trim()).map((x: any) => `${t.name}: ${x.label}`);
    });
    const miss = [...tplMiss, ...permitMiss, !f.title.trim() && 'tiêu đề', f.description.trim().length < 5 && 'mô tả/phạm vi', !f.groupId && 'nhóm', !f.dueAt && 'deadline',
      !f.criteria.some((c: any) => c.direction === 'output' && c.criterion.trim()) && 'ít nhất một tiêu chí đầu ra'].filter(Boolean);
    if (miss.length) { setStepErr('Còn thiếu: ' + miss.join(', ')); return; }
    setStepErr(null);
    if (presetOwner && f.ownerMemberId) { submit(); return; }
    setStep(2); window.scrollTo(0, 0);
  };
  const submit = () => a.run(async () => {
    const filled = (tpl?.fields || []).filter((x: any) => String(f.fieldValues[x.key] || '').trim());
    const description = filled.length ? `${f.description}\n\nThông tin khai báo:\n${filled.map((x: any) => `• ${x.label}: ${f.fieldValues[x.key]}`).join('\n')}` : f.description;
    const body: any = {
      title: f.title, description, groupId: f.groupId, ownerMemberId: f.ownerMemberId, collaboratorIds: f.collaboratorIds,
      taskTypeId: f.taskTypeId, complexity: f.complexity, requirementLevel: f.requirementLevel, estimatedHours: Number(f.estimatedHours),
      dueAt: fromLocalInput(f.dueAt), priority: f.priority, resources: f.resources || undefined, planDate: f.planDate || undefined, pinned: f.pinned, urgent: f.pinned,
      criteria: f.criteria.filter((c: any) => c.criterion.trim()),
      subitems: f.isUnexpected && f.unexpected.requirementStructure === 'diverse' ? f.subitems.filter((s: any) => s.title.trim()) : [],
      unexpected: f.isUnexpected ? { ...f.unexpected, causeDetail: f.unexpected.causeDetail || undefined, impact: f.unexpected.impact || undefined } : undefined,
      sourceReportId: reportId || undefined,
      isChain: f.isChain, customerName: f.isChain && f.customerName ? f.customerName : undefined, importance: f.importance,
      orderValue: f.isChain && f.orderValue !== '' ? Number(f.orderValue) : undefined, marginNote: f.isChain && f.marginNote ? f.marginNote : undefined,
      workLocationId: f.workLocationId || undefined, locationRequired: !!f.workLocationId && f.locationRequired, productionStandardId: f.productionStandardId || undefined,
    };
    const t = await post('/tasks', body);
    const failed: string[] = [];
    // Phân lớp: tạo phần việc con theo giai đoạn (mỗi bộ phận/nhóm nhận phần của mình; giai đoạn sau mở khi giai đoạn trước xong)
    for (const st of f.stages.filter((x: any) => x.title.trim())) {
      try {
        await post('/tasks', { parentId: t.id, title: st.title.trim(), groupId: st.groupId || f.groupId, stageNo: st.stage, estimatedHours: Number(st.hours) || undefined, standardMinutes: Math.round((Number(st.hours) || 0) * 60) || undefined,
          ownerMemberId: (st.groupId || f.groupId) === f.groupId ? f.ownerMemberId : undefined });
      } catch (e: any) { failed.push(`Phần việc "${st.title}": ${e.message}`); }
    }
    for (const p of f.permits.filter((x: any) => x.enabled)) {
      const pt = (permitTypes.data || []).find((x: any) => x.id === p.typeId);
      try {
        await post('/permits', { typeId: p.typeId, taskId: t.id, holderId: f.ownerMemberId, data: p.data, mode: p.mode,
          validFrom: new Date().toISOString(), validTo: fromLocalInput(f.dueAt) });
      } catch (e: any) { failed.push(`${pt?.name}: ${e.message}`); }
    }
    // Chuỗi đơn hàng: tính deadline từng công đoạn ngược từ hạn đơn (nhánh dài nhất, theo lịch làm việc)
    if (f.isChain && f.stages.some((x: any) => x.title.trim())) {
      try { const sch = await post(`/chains/${t.id}/schedule`, { apply: true }); if (!sch.feasible) failed.push(sch.note); } catch (e: any) { failed.push(`Tính deadline: ${e.message}`); }
    }
    if (failed.length) sessionStorage.setItem('task_notice', 'Lưu ý — ' + failed.join('; '));
    nav(`/tasks/${t.id}`, { replace: true });
  });

  return (
    <>
      <Header title={step === 1 ? (presetOwner ? 'Giao việc nhanh' : 'Giao việc mới · 1/2 Nội dung') : 'Giao việc mới · 2/2 Chọn nhân viên'} back />
      <div className="page">
        {step === 1 && <>
        {report.data && <div className="alert info small">Giao việc xử lý trở ngại <b>{report.data.code}</b> — tiêu đề và mô tả đã điền sẵn từ báo cáo. Khi việc hoàn thành, người báo cáo được mời xác nhận.</div>}
        {templates.data?.length > 0 && (
          <>
            <div className="section-title" style={{ marginTop: 6 }}>Chọn mẫu công việc</div>
            <div className="tpl-grid">
              {templates.data.map((t: any) => (
                <button key={t.id} type="button" className={`tpl ${f.templateId === t.id ? 'sel' : ''}`} onClick={() => applyTemplate(f.templateId === t.id ? '' : t.id)} aria-pressed={f.templateId === t.id}>
                  <span className="ichip blue" style={{ width: 36, height: 36 }}><Icon name={t.icon || 'work'} size={19} /></span>{t.name}
                </button>
              ))}
            </div>
          </>
        )}
        {tpl?.fields?.length > 0 && (
          <div className="card">
            <b className="small">Khai báo theo mẫu “{tpl.name}”</b>
            {tpl.fields.map((x: any) => (
              <Field key={x.key} label={x.label} required={x.required}>
                {x.type === 'textarea'
                  ? <textarea value={f.fieldValues[x.key] || ''} onChange={(e) => up({ fieldValues: { ...f.fieldValues, [x.key]: e.target.value } })} />
                  : <input type={x.type === 'number' ? 'number' : x.type === 'date' ? 'date' : x.type === 'datetime' ? 'datetime-local' : 'text'} value={f.fieldValues[x.key] || ''} onChange={(e) => up({ fieldValues: { ...f.fieldValues, [x.key]: e.target.value } })} />}
              </Field>
            ))}
          </div>
        )}
        <Field label="Tiêu đề" required><input value={f.title} onChange={(e) => up({ title: e.target.value })} /></Field>
        <Field label="Mô tả / phạm vi" required hint="Bối cảnh, yêu cầu, giới hạn và nội dung cần thực hiện"><textarea value={f.description} onChange={(e) => up({ description: e.target.value })} /></Field>
        <div className="grid2">
          <Field label="Nhóm" required><Select value={f.groupId} onChange={(v) => up({ groupId: v, ownerMemberId: '', collaboratorIds: [] })} options={managed.map((g: any) => [g.id, g.name])} placeholder="— Chọn nhóm —" /></Field>
          <Field label="Loại công việc" required><Select value={f.taskTypeId} onChange={(v) => up({ taskTypeId: v })} options={(types.data || []).filter((t: any) => t.active).map((t: any) => [t.id, t.name])} /></Field>
        </div>
        <div className="grid2">
          <Field label="Độ phức tạp" required><Select value={f.complexity} onChange={(v) => up({ complexity: v })} options={COMPLEXITY} /></Field>
          <Field label="Mức yêu cầu" required><Select value={f.requirementLevel} onChange={(v) => up({ requirementLevel: v })} options={REQ} /></Field>
        </div>
        <div className="grid2">
          <Field label="Thời lượng dự kiến (giờ)" required hint={`Tham khảo: ${GUIDE[f.complexity]?.[f.requirementLevel === 'normal' ? 'normal' : 'high']}`}>
            <input type="number" min={0.5} step={0.5} value={f.estimatedHours} onChange={(e) => up({ estimatedHours: e.target.value })} />
          </Field>
          <Field label="Ưu tiên"><Select value={f.priority} onChange={(v) => up({ priority: v })} options={PRIORITY} /></Field>
        </div>
        <Field label="Deadline" required hint="Tính theo giờ làm việc của công ty khi dùng gợi ý">
          <div className="row" style={{ display: 'flex', gap: 8 }}>
            <input type="datetime-local" value={f.dueAt} onChange={(e) => up({ dueAt: e.target.value })} />
            <button type="button" className="btn sm" onClick={suggestDue}>Gợi ý</button>
          </div>
        </Field>
        <div className="grid2">
          <Field label="Ngày bắt đầu làm (lịch)" hint="Hiện trong danh sách việc của ngày này"><input type="date" value={f.planDate} onChange={(e) => up({ planDate: e.target.value })} /></Field>
          <Field label="Việc gấp"><label className="check" style={{ margin: '10px 0' }}><input type="checkbox" checked={f.pinned} onChange={(e) => up({ pinned: e.target.checked })} /> 📌 Ghim lên đầu danh sách</label></Field>
        </div>
        <Field label="Nguồn lực / phụ thuộc"><input value={f.resources} onChange={(e) => up({ resources: e.target.value })} placeholder="Tài liệu, thiết bị, ngân sách, bộ phận hỗ trợ" /></Field>

        <div className="section-title">Đầu vào & tiêu chí đầu ra (nghiệm thu)</div>
        {f.criteria.map((c: any, i: number) => (
          <div key={i} style={{ display: 'flex', gap: 6, marginBottom: 6 }}>
            <select style={{ width: 110 }} value={c.direction} onChange={(e) => setCrit(i, { direction: e.target.value })}><option value="input">Đầu vào</option><option value="output">Đầu ra</option></select>
            <input value={c.criterion} placeholder={c.direction === 'output' ? 'Điều kiện nghiệm thu' : 'Yêu cầu/dữ liệu đầu vào'} onChange={(e) => setCrit(i, { criterion: e.target.value })} />
            <button type="button" className="icon-btn" aria-label="Xóa" onClick={() => up({ criteria: f.criteria.filter((_: any, j: number) => j !== i) })}>✕</button>
          </div>
        ))}
        <div className="actions">
          <button type="button" className="btn sm" onClick={() => up({ criteria: [...f.criteria, { direction: 'output', criterion: '' }] })}>＋ Tiêu chí đầu ra</button>
          <button type="button" className="btn sm" onClick={() => up({ criteria: [...f.criteria, { direction: 'input', criterion: '' }] })}>＋ Đầu vào</button>
        </div>

        <label className="check"><input type="checkbox" checked={f.isChain} onChange={(e) => up({ isChain: e.target.checked })} /> Đây là <b>đơn hàng / chuỗi công việc liên bộ phận</b> (có mã chuỗi chung, theo dõi tiến độ & rủi ro)</label>
        {f.isChain && (
          <div className="card">
            <div className="grid2">
              <Field label="Khách hàng"><input value={f.customerName} onChange={(e) => up({ customerName: e.target.value })} /></Field>
              <Field label="Mức quan trọng"><Select value={f.importance} onChange={(v) => up({ importance: v })} options={{ normal: 'Thường', high: 'Quan trọng', critical: 'Rất quan trọng' }} /></Field>
            </div>
            <div className="grid2">
              <Field label="Giá trị đơn (đ)" hint="Nhạy cảm: chỉ Ban quản trị và bạn thấy"><input type="number" min={0} value={f.orderValue} onChange={(e) => up({ orderValue: e.target.value })} /></Field>
              <Field label="Ghi chú lợi nhuận" hint="Nhạy cảm"><input value={f.marginNote} onChange={(e) => up({ marginNote: e.target.value })} /></Field>
            </div>
            <p className="small muted">Deadline ở trên là hạn đơn hàng. Nhập thời lượng chuẩn (giờ) cho từng công đoạn bên dưới — hệ thống tính ngược hạn từng công đoạn theo lịch làm việc và cảnh báo nếu không đủ thời gian. Điều phối do người có thẩm quyền quyết định.</p>
          </div>
        )}
        <div className="grid2">
          <Field label="Vị trí làm việc (không bắt buộc)"><Select value={f.workLocationId} onChange={(v) => up({ workLocationId: v })} options={(locs.data || []).filter((l: any) => l.active).map((l: any) => [l.id, l.name])} placeholder="— Không cố định —" /></Field>
          <Field label="Định mức sản lượng"><Select value={f.productionStandardId} onChange={(v) => up({ productionStandardId: v })} options={(stds.data || []).filter((s: any) => s.active).map((s: any) => [s.id, `${s.name} (${Number(s.quantity)} ${s.unit}/${Number(s.minutes)}p)`])} placeholder="— Không áp dụng —" /></Field>
        </div>
        {f.workLocationId && <label className="check"><input type="checkbox" checked={f.locationRequired} onChange={(e) => up({ locationRequired: e.target.checked })} /> Bắt buộc ghi nhận vị trí khi bắt đầu phiên (việc có địa điểm cố định)</label>}
        <StageBuilder f={f} up={up} groups={allGroups.data || groups.data || []} />

        <div className="section-title">Giấy phép cần chuẩn bị</div>
        <p className="small muted">Người giao việc chuẩn bị sẵn giấy phép — nhân viên không phải tự đi xin. Giấy phép gửi tới bộ phận phụ trách; chọn “Khai báo” để có hiệu lực ngay (bộ phận hậu kiểm sau, quy trình sai người giao chịu trách nhiệm).</p>
        {(permitTypes.data || []).filter((pt: any) => pt.active).map((pt: any) => {
          const p = f.permits.find((x: any) => x.typeId === pt.id);
          const on = !!p?.enabled;
          return (
            <div key={pt.id} className="card" style={{ padding: 10 }}>
              <label className="check" style={{ margin: 0 }}>
                <input type="checkbox" checked={on} onChange={(e) => setPermit(pt.id, { enabled: e.target.checked, mode: p?.mode || (pt.allow_declaration ? 'declaration' : 'approval') })} />
                <Icon name={pt.icon || 'permit'} size={18} /> <b>{pt.name}</b>
              </label>
              {on && (
                <div style={{ marginTop: 6 }}>
                  <div className="small muted">Bộ phận xử lý: {pt.department_name || 'Quản trị công ty'}</div>
                  <Select value={p.mode} onChange={(v) => setPermit(pt.id, { mode: v })} options={pt.allow_declaration ? { declaration: 'Khai báo — cấp tự động, hậu kiểm sau', approval: 'Chờ bộ phận duyệt' } : { approval: 'Chờ bộ phận duyệt' }} />
                  {(pt.fields || []).map((x: any) => (
                    <Field key={x.key} label={x.label} required={x.required}>
                      {x.type === 'textarea' ? <textarea value={p.data[x.key] || ''} onChange={(e) => setPermit(pt.id, { data: { ...p.data, [x.key]: e.target.value } })} />
                        : <input type={x.type === 'number' ? 'number' : 'text'} value={p.data[x.key] || ''} onChange={(e) => setPermit(pt.id, { data: { ...p.data, [x.key]: e.target.value } })} />}
                    </Field>
                  ))}
                  <div className="small muted">Hiệu lực: từ lúc giao đến deadline.</div>
                </div>
              )}
            </div>
          );
        })}

        <label className="check"><input type="checkbox" checked={f.isUnexpected} onChange={(e) => up({ isUnexpected: e.target.checked })} /> Đây là công việc đột xuất / phát sinh</label>
        {f.isUnexpected && (
          <div className="card">
            <div className="grid2">
              <Field label="Loại phát sinh"><Select value={f.unexpected.category} onChange={(v) => up({ unexpected: { ...f.unexpected, category: v } })} options={UNEXPECTED_CAT} /></Field>
              <Field label="Cấu trúc yêu cầu"><Select value={f.unexpected.requirementStructure} onChange={(v) => up({ unexpected: { ...f.unexpected, requirementStructure: v } })} options={REQ_STRUCT} /></Field>
            </div>
            <Field label="Nguyên nhân phát sinh"><Select value={f.unexpected.cause} onChange={(v) => up({ unexpected: { ...f.unexpected, cause: v } })} options={UNEXPECTED_CAUSE} /></Field>
            <Field label="Chi tiết nguyên nhân"><input value={f.unexpected.causeDetail} onChange={(e) => up({ unexpected: { ...f.unexpected, causeDetail: e.target.value } })} /></Field>
            <Field label="Ảnh hưởng đến việc thường xuyên/deadline khác/nguồn lực"><textarea value={f.unexpected.impact} onChange={(e) => up({ unexpected: { ...f.unexpected, impact: e.target.value } })} /></Field>
            {f.unexpected.requirementStructure === 'diverse' && (
              <>
                <div className="section-title">Yêu cầu thành phần</div>
                {f.subitems.map((s: any, i: number) => (
                  <div key={i} style={{ display: 'flex', gap: 6, marginBottom: 6 }}>
                    <input value={s.title} placeholder="Đầu việc con" onChange={(e) => up({ subitems: f.subitems.map((x: any, j: number) => (j === i ? { ...x, title: e.target.value } : x)) })} />
                    <button type="button" className="icon-btn" aria-label="Xóa" onClick={() => up({ subitems: f.subitems.filter((_: any, j: number) => j !== i) })}>✕</button>
                  </div>
                ))}
                <button type="button" className="btn sm" onClick={() => up({ subitems: [...f.subitems, { title: '', extraHours: 0 }] })}>＋ Đầu việc con</button>
              </>
            )}
          </div>
        )}
        <ErrorBox error={stepErr} />
        {presetOwner && f.ownerMemberId ? (
          <>
            <div className="alert info small">Người nhận việc: <b>{people.find((p) => p[0] === f.ownerMemberId)?.[1] || '…'}</b></div>
            <button className="btn primary block" disabled={a.busy} onClick={next}><Icon name="assign" size={18} />{a.busy ? 'Đang giao…' : 'Giao việc'}</button>
            <ErrorBox error={a.error} />
            <button className="btn block" style={{ marginTop: 8 }} onClick={() => { setStepErr(null); setStep(2); }}>Chọn người khác ›</button>
          </>
        ) : <button className="btn primary block" onClick={next}>Tiếp: chọn nhân viên ›</button>}
        </>}
        {step === 2 && <PickPeople f={f} up={up} people={people} onBack={() => setStep(1)} onSubmit={submit} busy={a.busy} error={a.error} />}
      </div>
    </>
  );
}

/** Bước 2: chọn người thực hiện, xem trạng thái nhân viên (nghỉ phép, khối lượng việc) trước khi giao. */
function PickPeople({ f, up, people, onBack, onSubmit, busy, error }: { f: any; up: (p: any) => void; people: [string, string][]; onBack: () => void; onSubmit: () => void; busy: boolean; error: string | null }) {
  const from = isoDate(new Date());
  const to = f.dueAt ? f.dueAt.slice(0, 10) : from;
  const av = useLoad(() => get('/team/availability' + qs({ from, to: to < from ? from : to, groupId: f.groupId })), [f.groupId, to]);
  const byId = Object.fromEntries((av.data?.members || []).map((m: any) => [m.member_id, m]));
  const ids = people.map(([id]) => id);
  return (
    <>
      <div className="alert info small">Trạng thái tính trong khoảng {new Date(from).toLocaleDateString('vi-VN')} – {new Date(to < from ? from : to).toLocaleDateString('vi-VN')} (đến deadline). Ưu tiên người đang sẵn sàng.</div>
      <div className="section-title">Người chịu trách nhiệm chính</div>
      {av.loading && !av.data && <Loading />}
      {ids.map((id) => {
        const m = byId[id]; const name = people.find((p) => p[0] === id)?.[1];
        const st = m ? AVAIL[m.status] : null;
        return (
          <button key={id} className={`pick ${f.ownerMemberId === id ? 'sel' : ''}`} onClick={() => up({ ownerMemberId: id, collaboratorIds: f.collaboratorIds.filter((x: string) => x !== id) })} aria-pressed={f.ownerMemberId === id}>
            <Avatar userId={m?.user_id} name={name} has={m?.has_avatar} />
            <div className="main">
              <b>{name}</b>
              {m && <div className="small muted">{m.open_tasks} việc đang mở · {m.open_hours} giờ dự kiến{m.overdue ? ` · ${m.overdue} quá hạn` : ''}{m.pinned ? ` · ${m.pinned} việc gấp` : ''}</div>}
              {m?.leaves?.length > 0 && <div className="small" style={{ color: 'var(--teal)' }}>🌴 {m.leaves.map((l: any) => `${LEAVE_TYPE[l.leave_type]} ${new Date(l.start_at).toLocaleDateString('vi-VN')}${l.status === 'pending' ? ' (chờ duyệt)' : ''}`).join('; ')}</div>}
            </div>
            {st && <Badge tone={st[1]}>{st[0]}</Badge>}
          </button>
        );
      })}
      {ids.length > 1 && f.ownerMemberId && (
        <Field label="Cộng tác viên (không bắt buộc)">
          <div className="chip-row">
            {people.filter(([id]) => id !== f.ownerMemberId).map(([id, n]) => (
              <label key={id} className="check" style={{ margin: 0, marginRight: 10 }}>
                <input type="checkbox" checked={f.collaboratorIds.includes(id)} onChange={(e) => up({ collaboratorIds: e.target.checked ? [...f.collaboratorIds, id] : f.collaboratorIds.filter((x: string) => x !== id) })} />{n}{byId[id]?.status === 'on_leave' ? ' 🌴' : ''}
              </label>
            ))}
          </div>
        </Field>
      )}
      {byId[f.ownerMemberId]?.status === 'on_leave' && <div className="alert warn small">Người này có lịch nghỉ phép trong thời gian thực hiện — cân nhắc đổi người hoặc điều chỉnh deadline.</div>}
      <ErrorBox error={error} />
      <div className="actions">
        <button className="btn" onClick={onBack}>‹ Quay lại</button>
        <button className="btn primary" style={{ flex: 1 }} disabled={busy || !f.ownerMemberId} onClick={onSubmit}>{busy ? 'Đang giao việc…' : 'Giao việc'}</button>
      </div>
    </>
  );
}

/** Phân lớp công việc qua các giai đoạn / bộ phận. Cùng giai đoạn = song song; bộ phận không do bạn quản lý cần cấp trên duyệt. */
function StageBuilder({ f, up, groups }: { f: any; up: (p: any) => void; groups: any[] }) {
  const st: any[] = f.stages;
  const set = (i: number, p: any) => up({ stages: st.map((x, j) => (j === i ? { ...x, ...p } : x)) });
  const maxStage = Math.max(0, ...st.map((x) => x.stage));
  const add = (stage: number) => up({ stages: [...st, { stage, title: '', groupId: f.groupId, hours: 2 }].sort((a, b) => a.stage - b.stage) });
  const stages = [...new Set(st.map((x) => x.stage))].sort((a, b) => a - b);
  return (
    <>
      <div className="section-title">Phân lớp / giai đoạn (tùy chọn)</div>
      <p className="small muted">Ví dụ nhập hàng: GĐ1 đặt hàng → GĐ2 nhận hàng + kiểm hàng (song song, có thể hai người khác nhau) → GĐ3 nhập kho. Mỗi phần việc có thể giao cho bộ phận khác; quản lý bộ phận đó nhận và theo dõi. Giai đoạn sau tự nhận thông báo khi giai đoạn trước xong.</p>
      {stages.map((sn) => (
        <div key={sn} className="stage-box">
          <div className="stage-h">Giai đoạn {sn}</div>
          {st.map((x, i) => x.stage !== sn ? null : (
            <div key={i} style={{ display: 'grid', gridTemplateColumns: '1fr auto', gap: 6, marginBottom: 6 }}>
              <input value={x.title} placeholder="Tên phần việc" onChange={(e) => set(i, { title: e.target.value })} />
              <button type="button" className="icon-btn" aria-label="Xóa" onClick={() => up({ stages: st.filter((_, j) => j !== i) })}>✕</button>
              <div style={{ display: 'flex', gap: 6, gridColumn: '1 / -1' }}>
                <select value={x.groupId || f.groupId} onChange={(e) => set(i, { groupId: e.target.value })} aria-label="Bộ phận/nhóm">
                  {groups.map((g: any) => <option key={g.id} value={g.id}>{g.name}{g.is_manager ? '' : ' · nhóm khác'}</option>)}
                </select>
                <input style={{ width: 80 }} type="number" min={0.5} step={0.5} value={x.hours} onChange={(e) => set(i, { hours: e.target.value })} aria-label="Giờ dự kiến" title="Giờ dự kiến" />
              </div>
            </div>
          ))}
          <button type="button" className="btn sm" onClick={() => add(sn)}>＋ Việc song song trong GĐ {sn}</button>
        </div>
      ))}
      <button type="button" className="btn sm" onClick={() => add(maxStage + 1)}>＋ Thêm giai đoạn {maxStage + 1}</button>
    </>
  );
}
