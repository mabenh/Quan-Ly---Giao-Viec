import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { get, post, qs } from '../api';
import { isAdminRole, useAuth } from '../auth';
import { ErrorBox, Field, Header, Select, useAction, useLoad } from '../ui';
import { COMPLEXITY, PRIORITY, REQ, REQ_STRUCT, UNEXPECTED_CAT, UNEXPECTED_CAUSE, fromLocalInput, toLocalInput } from '../labels';

const GUIDE: Record<string, Record<string, string>> = {
  simple: { normal: '2–4 giờ', high: '4–8 giờ' }, medium: { normal: '1–2 ngày', high: '2–3 ngày' },
  complex: { normal: '3–5 ngày', high: '5–8 ngày' }, very_complex: { normal: '1–2 tuần', high: '2–4 tuần' },
};

export default function TaskForm() {
  const nav = useNavigate();
  const { me } = useAuth();
  const a = useAction();
  const groups = useLoad(() => get('/groups'), []);
  const types = useLoad(() => get('/company/task-types'), []);
  const templates = useLoad(() => get('/company/task-templates'), []);
  const [f, setF] = useState<any>({
    title: '', description: '', groupId: '', ownerMemberId: '', collaboratorIds: [] as string[], taskTypeId: '', complexity: 'medium',
    requirementLevel: 'normal', estimatedHours: 8, dueAt: toLocalInput(new Date(Date.now() + 2 * 86400000)), priority: 'normal', resources: '',
    criteria: [{ direction: 'input', criterion: '' }, { direction: 'output', criterion: '' }], isUnexpected: false,
    unexpected: { category: 'ad_hoc', requirementStructure: 'common', cause: 'superior_request', causeDetail: '', impact: '' }, subitems: [] as { title: string; extraHours: number }[],
  });
  const up = (p: any) => setF((x: any) => ({ ...x, ...p }));
  const managed = (groups.data || []).filter((g: any) => g.is_manager || isAdminRole(me?.role));
  const group = useLoad(() => (f.groupId ? get(`/groups/${f.groupId}`) : Promise.resolve(null)), [f.groupId]);
  const people: [string, string][] = group.data ? [[group.data.manager_member_id, `${group.data.manager_name} (quản lý)`], ...group.data.members.filter((m: any) => m.member_id !== group.data.manager_member_id).map((m: any) => [m.member_id, m.name] as [string, string])] : [];

  useEffect(() => { if (!f.groupId && managed.length === 1) up({ groupId: managed[0].id }); }, [groups.data]);
  useEffect(() => { if (!f.taskTypeId && types.data?.length) up({ taskTypeId: types.data.find((t: any) => t.active)?.id }); }, [types.data]);

  const applyTemplate = (id: string) => {
    const t = templates.data?.find((x: any) => x.id === id);
    if (!t) return;
    up({ title: t.name, description: t.description || '', taskTypeId: t.task_type_id, complexity: t.complexity, requirementLevel: t.requirement_level,
      estimatedHours: t.estimated_hours, criteria: t.criteria.length ? t.criteria : f.criteria });
  };
  const suggestDue = async () => {
    const r = await get('/company/calendar/suggest-due' + qs({ hours: f.estimatedHours }));
    up({ dueAt: toLocalInput(new Date(r.due_at)) });
  };
  const setCrit = (i: number, p: any) => up({ criteria: f.criteria.map((c: any, j: number) => (j === i ? { ...c, ...p } : c)) });

  const submit = () => a.run(async () => {
    const body: any = {
      title: f.title, description: f.description, groupId: f.groupId, ownerMemberId: f.ownerMemberId, collaboratorIds: f.collaboratorIds,
      taskTypeId: f.taskTypeId, complexity: f.complexity, requirementLevel: f.requirementLevel, estimatedHours: Number(f.estimatedHours),
      dueAt: fromLocalInput(f.dueAt), priority: f.priority, resources: f.resources || undefined,
      criteria: f.criteria.filter((c: any) => c.criterion.trim()),
      subitems: f.isUnexpected && f.unexpected.requirementStructure === 'diverse' ? f.subitems.filter((s: any) => s.title.trim()) : [],
      unexpected: f.isUnexpected ? { ...f.unexpected, causeDetail: f.unexpected.causeDetail || undefined, impact: f.unexpected.impact || undefined } : undefined,
    };
    const t = await post('/tasks', body);
    nav(`/tasks/${t.id}`, { replace: true });
  });

  return (
    <>
      <Header title="Giao việc mới" back />
      <div className="page">
        {templates.data?.length > 0 && (
          <Field label="Tạo nhanh từ mẫu (yêu cầu chung)"><Select value="" onChange={applyTemplate} options={templates.data.map((t: any) => [t.id, t.name])} placeholder="— Chọn mẫu —" /></Field>
        )}
        <Field label="Tiêu đề" required><input value={f.title} onChange={(e) => up({ title: e.target.value })} /></Field>
        <Field label="Mô tả / phạm vi" required hint="Bối cảnh, yêu cầu, giới hạn và nội dung cần thực hiện"><textarea value={f.description} onChange={(e) => up({ description: e.target.value })} /></Field>
        <div className="grid2">
          <Field label="Nhóm" required><Select value={f.groupId} onChange={(v) => up({ groupId: v, ownerMemberId: '', collaboratorIds: [] })} options={managed.map((g: any) => [g.id, g.name])} placeholder="— Chọn nhóm —" /></Field>
          <Field label="Loại công việc" required><Select value={f.taskTypeId} onChange={(v) => up({ taskTypeId: v })} options={(types.data || []).filter((t: any) => t.active).map((t: any) => [t.id, t.name])} /></Field>
        </div>
        <Field label="Người chịu trách nhiệm chính" required><Select value={f.ownerMemberId} onChange={(v) => up({ ownerMemberId: v, collaboratorIds: f.collaboratorIds.filter((x: string) => x !== v) })} options={people} placeholder={f.groupId ? '— Chọn người —' : 'Chọn nhóm trước'} /></Field>
        {people.length > 1 && (
          <Field label="Cộng tác viên (không bắt buộc)">
            <div className="chip-row">
              {people.filter(([id]) => id !== f.ownerMemberId).map(([id, n]) => (
                <label key={id} className="check" style={{ margin: 0, marginRight: 10 }}>
                  <input type="checkbox" checked={f.collaboratorIds.includes(id)} onChange={(e) => up({ collaboratorIds: e.target.checked ? [...f.collaboratorIds, id] : f.collaboratorIds.filter((x: string) => x !== id) })} />{n}
                </label>
              ))}
            </div>
          </Field>
        )}
        <div className="grid2">
          <Field label="Độ phức tạp" required><Select value={f.complexity} onChange={(v) => up({ complexity: v })} options={COMPLEXITY} /></Field>
          <Field label="Mức yêu cầu" required><Select value={f.requirementLevel} onChange={(v) => up({ requirementLevel: v })} options={REQ} /></Field>
        </div>
        <div className="grid2">
          <Field label="Thời lượng dự kiến (giờ)" required hint={`Tham khảo: ${GUIDE[f.complexity]?.[f.requirementLevel === 'normal' ? 'normal' : 'high']}`}>
            <input type="number" min={0.5} step={0.5} value={f.estimatedHours} onChange={(e) => up({ estimatedHours: e.target.value })} />
          </Field>
          <Field label="Ưu tiên"><Select value={f.priority} onChange={(v) => up({ priority: v })} options={PRIORITY} /></Field>
        </div>
        <Field label="Deadline" required hint="Tính theo giờ làm việc của công ty khi dùng gợi ý">
          <div className="row" style={{ display: 'flex', gap: 8 }}>
            <input type="datetime-local" value={f.dueAt} onChange={(e) => up({ dueAt: e.target.value })} />
            <button type="button" className="btn sm" onClick={suggestDue}>Gợi ý</button>
          </div>
        </Field>
        <Field label="Nguồn lực / phụ thuộc"><input value={f.resources} onChange={(e) => up({ resources: e.target.value })} placeholder="Tài liệu, thiết bị, ngân sách, bộ phận hỗ trợ" /></Field>

        <div className="section-title">Đầu vào & tiêu chí đầu ra (nghiệm thu)</div>
        {f.criteria.map((c: any, i: number) => (
          <div key={i} style={{ display: 'flex', gap: 6, marginBottom: 6 }}>
            <select style={{ width: 110 }} value={c.direction} onChange={(e) => setCrit(i, { direction: e.target.value })}><option value="input">Đầu vào</option><option value="output">Đầu ra</option></select>
            <input value={c.criterion} placeholder={c.direction === 'output' ? 'Điều kiện nghiệm thu' : 'Yêu cầu/dữ liệu đầu vào'} onChange={(e) => setCrit(i, { criterion: e.target.value })} />
            <button type="button" className="icon-btn" aria-label="Xóa" onClick={() => up({ criteria: f.criteria.filter((_: any, j: number) => j !== i) })}>✕</button>
          </div>
        ))}
        <div className="actions">
          <button type="button" className="btn sm" onClick={() => up({ criteria: [...f.criteria, { direction: 'output', criterion: '' }] })}>＋ Tiêu chí đầu ra</button>
          <button type="button" className="btn sm" onClick={() => up({ criteria: [...f.criteria, { direction: 'input', criterion: '' }] })}>＋ Đầu vào</button>
        </div>

        <label className="check"><input type="checkbox" checked={f.isUnexpected} onChange={(e) => up({ isUnexpected: e.target.checked })} /> Đây là công việc đột xuất / phát sinh</label>
        {f.isUnexpected && (
          <div className="card">
            <div className="grid2">
              <Field label="Loại phát sinh"><Select value={f.unexpected.category} onChange={(v) => up({ unexpected: { ...f.unexpected, category: v } })} options={UNEXPECTED_CAT} /></Field>
              <Field label="Cấu trúc yêu cầu"><Select value={f.unexpected.requirementStructure} onChange={(v) => up({ unexpected: { ...f.unexpected, requirementStructure: v } })} options={REQ_STRUCT} /></Field>
            </div>
            <Field label="Nguyên nhân phát sinh"><Select value={f.unexpected.cause} onChange={(v) => up({ unexpected: { ...f.unexpected, cause: v } })} options={UNEXPECTED_CAUSE} /></Field>
            <Field label="Chi tiết nguyên nhân"><input value={f.unexpected.causeDetail} onChange={(e) => up({ unexpected: { ...f.unexpected, causeDetail: e.target.value } })} /></Field>
            <Field label="Ảnh hưởng đến việc thường xuyên/deadline khác/nguồn lực"><textarea value={f.unexpected.impact} onChange={(e) => up({ unexpected: { ...f.unexpected, impact: e.target.value } })} /></Field>
            {f.unexpected.requirementStructure === 'diverse' && (
              <>
                <div className="section-title">Yêu cầu thành phần</div>
                {f.subitems.map((s: any, i: number) => (
                  <div key={i} style={{ display: 'flex', gap: 6, marginBottom: 6 }}>
                    <input value={s.title} placeholder="Đầu việc con" onChange={(e) => up({ subitems: f.subitems.map((x: any, j: number) => (j === i ? { ...x, title: e.target.value } : x)) })} />
                    <button type="button" className="icon-btn" aria-label="Xóa" onClick={() => up({ subitems: f.subitems.filter((_: any, j: number) => j !== i) })}>✕</button>
                  </div>
                ))}
                <button type="button" className="btn sm" onClick={() => up({ subitems: [...f.subitems, { title: '', extraHours: 0 }] })}>＋ Đầu việc con</button>
              </>
            )}
          </div>
        )}
        <ErrorBox error={a.error} />
        <button className="btn primary block" disabled={a.busy} onClick={submit}>{a.busy ? 'Đang giao việc…' : 'Giao việc'}</button>
      </div>
    </>
  );
}
