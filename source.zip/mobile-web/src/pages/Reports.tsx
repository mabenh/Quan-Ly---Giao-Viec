import { Link, useSearchParams } from 'react-router-dom';
import { get, qs } from '../api';
import { useAuth } from '../auth';
import { Empty, ErrorBox, Header, Loading, Select, Tabs, useLoad, Note } from '../ui';
import { Icon } from '../icons';
import { RP_STATUS } from '../labels';
import { ReportCard } from './Work';

const OPEN = 'submitted,manager_review,assigned,acknowledged,in_progress,waiting,reopened,escalated,task_assigned';

/** Danh sách báo cáo trở ngại: quản lý nhận báo cáo do nhân viên mình quản lý gửi lên; cấp trên theo dõi quyết định của cấp dưới. */
export default function Reports() {
  const { me } = useAuth();
  const [sp, setSp] = useSearchParams();
  const isMgr = me?.role !== 'employee';
  const scope = sp.get('scope') || (isMgr ? 'handling' : 'mine');
  const status = sp.get('status') ?? (scope === 'mine' ? '' : OPEN);
  const { data, error, loading } = useLoad(() => get('/workplace-reports' + qs({ scope, status })), [scope, status]);
  const tabs: [string, string][] = isMgr ? [['handling', 'Cần tôi xử lý'], ['oversight', 'Cấp dưới đã quyết định'], ['mine', 'Tôi báo cáo']] : [['mine', 'Tôi báo cáo']];
  return (
    <>
      <Header title="Báo cáo trở ngại" back="/" right={isMgr ? <Link className="btn sm" to="/tech"><Icon name="wrench" size={16} /> Kỹ thuật</Link> : undefined} />
      <div className="page">
        <Note>
          {scope === 'handling' && 'Báo cáo do nhân viên bạn quản lý gửi lên. Chọn: chuyển lên cấp, thông báo nhóm kỹ thuật, hoặc tự giải quyết bằng cách giao việc cho người xử lý.'}
          {scope === 'oversight' && 'Quyết định xử lý của quản lý cấp dưới. Bạn có thể thay đổi (đổi phòng ban / đổi người xử lý); không thay đổi thì mặc nhiên chấp nhận và bạn chịu trách nhiệm cuối cùng.'}
          {scope === 'mine' && 'Trở ngại bạn đã báo từ trang chi tiết công việc. Muốn báo trở ngại mới, mở công việc bị ảnh hưởng và chọn "Báo trở ngại".'}
        </Note>
        {tabs.length > 1 && <Tabs value={scope} onChange={(v) => setSp({ scope: v }, { replace: true })} tabs={tabs} />}
        <div className="filters">
          <Select value={status === OPEN ? 'open' : status} onChange={(v) => { const n = new URLSearchParams(sp); n.set('status', v === 'open' ? OPEN : v); setSp(n, { replace: true }); }}
            options={[['open', 'Đang mở'], ...Object.entries(RP_STATUS).filter(([k]) => !['comment', 'override'].includes(k))] as [string, string][]} placeholder="Mọi trạng thái" aria-label="Trạng thái" />
        </div>
        <ErrorBox error={error} />
        {loading && !data && <Loading />}
        {data && data.length === 0 && <Empty>Không có báo cáo trở ngại</Empty>}
        {data?.map((w: any) => <ReportCard key={w.id} w={w} />)}
      </div>
    </>
  );
}
