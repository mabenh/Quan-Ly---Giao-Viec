import { useState } from 'react';
import { HandoverPanel } from './Handover';
import { Link, useParams } from 'react-router-dom';
import { download, get, patch, post, upload } from '../api';
import { useAuth } from '../auth';
import { Icon } from '../icons';
import { Dot, TaskMarks } from '../marks';
import { TaskOps } from './TaskOps';
import { Badge, Card, ErrorBox, Field, Header, KV, Loading, Select, Sheet, Timeline, useAction, useLoad } from '../ui';
import {
  AUDIT_ACTION, COMPLEXITY, EVAL_LABEL, PRIORITY, REQ, REQ_STRUCT, RP_STATUS, SEVERITY, TASK_STATUS, TASK_TONE, UNEXPECTED_CAT, UNEXPECTED_CAUSE,
  OT_STATUS, PERMIT_STATUS, PERMIT_TONE, WR_STATUS, WR_TONE, fmtDT, hours, relDue, toLocalInput, fromLocalInput, taskLabel, AUTO_START,
} from '../labels';

const REGULAR = ['output', 'quality', 'schedule', 'process'];
const UNEXP = ['requirement', 'response', 'handling', 'quality', 'coordination'];
const W: Record<string, number> = { output: 40, quality: 30, schedule: 20, process: 10, requirement: 35, response: 20, handling: 20, coordination: 10 };
const WU: Record<string, number> = { quality: 15 };

export default function TaskDetail() {
  const { id } = useParams();
  const { me } = useAuth();
  const { data: t, error, loading, reload, setData } = useLoad(() => get(`/tasks/${id}`), [id]);
  const [sheet, setSheet] = useState<string | null>(null);
  const [showHistory, setShowHistory] = useState(false);
  const [notice] = useState(() => { const n = sessionStorage.getItem('task_notice'); sessionStorage.removeItem('task_notice'); return n; });
  const a = useAction();
  const act = (fn: () => Promise<any>) => a.run(async () => { const r = await fn(); if (r?.id) setData(r); else await reload(); setSheet(null); });
  if (loading && !t) return <Loading />;
  if (!t) return <div className="page"><ErrorBox error={error} /></div>;
  const p = t.permissions;
  const outputs = t.criteria.filter((c: any) => c.direction === 'output');
  const inputs = t.criteria.filter((c: any) => c.direction === 'input');
  const collabs = t.assignees.filter((x: any) => x.assignment_type === 'collaborator' && x.active);

  return (
    <>
      <Header title={t.code || 'Nhiệm vụ'} back="/work?tab=tasks" />
      <div className="page">
        {t.parent_id && <div className="small"><Icon name="layers" size={14} /> Thuộc <Link to={`/tasks/${t.parent_id}`}>{t.parent_code} · {t.parent_title}</Link>{t.stage_no ? ` · giai đoạn ${t.stage_no}` : ''}</div>}
        <h2 className="row" style={{ gap: 8 }}><TaskMarks t={t} size={14} /><span>{taskLabel(t, t.is_chain ? t.chain_code : t.root_chain_code)}</span></h2>
        {t.is_standing && <div className="alert info small">Nhiệm vụ thường trực — không có hạn; thành viên nhóm chọn khi bắt đầu phiên làm việc để ghi nhận thời gian.</div>}
        {t.auto_start !== 'manual' && t.status === 'not_started' && <div className="alert info small">{AUTO_START[t.auto_start]}{t.scheduled_start_at ? `: ${fmtDT(t.scheduled_start_at)}` : ''}.</div>}
        <div className="chip-row">
          <Badge tone={TASK_TONE[t.status]}>{TASK_STATUS[t.status]}</Badge>
          {!t.pinned && t.urgent && <Badge tone="red">Gấp</Badge>}
          {t.carry_count > 0 && <Badge tone="amber">↪ Chuyển từ {new Date(t.original_plan_date).toLocaleDateString('vi-VN')} ({t.carry_count} ngày)</Badge>}
          {t.is_overdue && <Badge tone="red">{relDue(t.due_at)}</Badge>}
          {t.submitted_late && <Badge tone="amber">Bàn giao trễ hạn</Badge>}
          {t.is_unexpected && <Badge tone="purple">⚡ {UNEXPECTED_CAT[t.unexpected?.category]} · {REQ_STRUCT[t.unexpected?.requirement_structure]}</Badge>}
          {t.impediment_confirmed && <Badge tone="amber">🛑 Có trở ngại đã xác nhận — không tự động trừ điểm tiến độ</Badge>}
        </div>
        {notice && <div className="alert warn small">{notice}</div>}
        {t.status === 'pending_approval' && (
          <div className="alert warn small">
            Việc này giao sang nhóm mà người giao không quản lý — đang chờ <b>{t.approver_name || 'cấp quản lý cao hơn'}</b> duyệt.
            {p.can_approve && <div className="actions" style={{ marginTop: 8 }}>
              <button className="btn primary" disabled={a.busy} onClick={() => act(() => post(`/tasks/${id}/approve`, { decision: 'approve' }))}>✔ Duyệt giao việc</button>
              <button className="btn danger" onClick={() => setSheet('reject')}>Không duyệt</button>
            </div>}
          </div>
        )}
        {t.status === 'waiting' && <div className="alert info small">Phần việc thuộc giai đoạn {t.stage_no}. Sẽ tự mở và báo cho bạn khi giai đoạn trước hoàn thành.</div>}
        <ErrorBox error={a.error} />
        <div className="actions">
          {p.can_start && <button className="btn primary" disabled={a.busy} onClick={() => act(() => post(`/tasks/${id}/start`))}><Icon name="clock" size={18} />{t.status === 'revision_requested' ? 'Tiếp tục chỉnh sửa' : 'Bắt đầu'}</button>}
          {p.can_submit && !t.external_handover && <button className="btn primary" onClick={() => setSheet('submit')}><Icon name="ok" size={18} />Bàn giao kết quả</button>}
          {p.can_review && <button className="btn primary" onClick={() => setSheet('review')}><Icon name="ok" size={18} />Nghiệm thu</button>}
          {/* Người giao việc (không thực hiện): chỉ điều chỉnh ưu tiên, điều chỉnh nội dung khi chưa nghiệm thu, hủy */}
          {(p.can_edit_full || p.can_edit_assignees) && !['completed', 'cancelled'].includes(t.status) && !t.ops_permissions?.is_assignee && <button className="btn" onClick={() => setSheet('edit')}><Icon name="settings" size={18} />{p.can_edit_full ? 'Điều chỉnh' : 'Đổi người phụ trách'}</button>}
          {t.ops_permissions?.is_assignee && !['completed', 'cancelled'].includes(t.status) && !t.is_standing && <button className="btn" onClick={() => setSheet('plan')}><Icon name="calendar" size={18} />Đổi ngày làm</button>}
          {p.can_cancel && <button className="btn danger" onClick={() => setSheet('cancel')}>Hủy nhiệm vụ</button>}
          {t.ops_permissions?.is_assignee && <Link className="btn" to={`/reports/new?taskId=${t.id}&groupId=${t.group_id}`}><Icon name="alert" size={18} />Báo trở ngại</Link>}
          {t.ops_permissions?.is_assignee && !['completed', 'cancelled'].includes(t.status) && <Link className="btn" to={`/support/new?taskId=${t.id}`}><Icon name="users" size={18} />Yêu cầu hỗ trợ</Link>}
        </div>
        {t.status === 'pending_exception_review' && <div className="alert warn small">Nhiệm vụ đang <b>treo</b> chờ người giao duyệt giải trình bỏ qua QR — chưa tính hoàn thành.</div>}
        {t.external_handover && <HandoverPanel taskId={t.id} onChange={reload} />}

        <Card>
          <KV k="Nhóm" v={t.group_name} />
          <KV k="Người chịu trách nhiệm" v={t.owner_name} />
          <KV k="Người nghiệm thu" v={t.reviewer_name ? `${t.reviewer_name} (quản lý trực tiếp)` : '—'} />
          <KV k="Cộng tác viên" v={collabs.map((c: any) => c.name).join(', ') || '—'} />
          <KV k="Loại công việc" v={t.task_type_name} />
          <KV k="Độ phức tạp / Mức yêu cầu" v={`${COMPLEXITY[t.complexity]} / ${REQ[t.requirement_level]}`} />
          <KV k="Thời lượng dự kiến" v={`${t.estimated_hours} giờ`} />
          <KV k="Deadline" v={fmtDT(t.due_at)} />
          <KV k="Ngày làm (lịch)" v={t.plan_date ? new Date(t.plan_date).toLocaleDateString('vi-VN') : '—'} />
          <KV k="Ưu tiên" v={PRIORITY[t.priority]} />
          <KV k="Phiên bản phạm vi" v={`v${t.scope_version} · tiêu chí v${t.criteria_version}`} />
          {t.resources && <KV k="Nguồn lực/phụ thuộc" v={t.resources} />}
          {t.cancel_reason && <KV k="Lý do hủy" v={t.cancel_reason} />}
        </Card>

        <TaskOps t={t} reload={reload} />
        {(t.children?.length > 0 || t.hidden_children > 0 || p.can_add_children) && <Stages t={t} onAdd={p.can_add_children ? () => setSheet('child') : undefined} />}
        {t.branch_records?.length > 0 && (
          <>
            <div className="section-title">Việc khai thêm vào nhánh này ({t.branch_records.length})</div>
            {t.branch_records.map((r: any) => (
              <Card key={r.id} to={`/work-records/${r.id}`}>
                <div className="row"><span style={{ flex: 1 }}>{r.title}</span><Badge tone={WR_TONE[r.status]}>{WR_STATUS[r.status]}</Badge></div>
                <div className="small muted">{r.employee_name} · {hours(r.claimed_minutes)} · {fmtDT(r.created_at)}</div>
              </Card>
            ))}
          </>
        )}

        <div className="section-title">Mô tả / phạm vi</div>
        <Card><div className="crit">{t.description}</div></Card>

        <div className="section-title">Đầu vào & tiêu chí nghiệm thu (v{t.criteria_version})</div>
        <Card>
          {inputs.length > 0 && <><b className="small">Đầu vào</b><ul>{inputs.map((c: any) => <li key={c.id}>{c.criterion}</li>)}</ul></>}
          <b className="small">Tiêu chí đầu ra</b><ul>{outputs.map((c: any) => <li key={c.id}>{c.criterion}</li>)}</ul>
          {t.criteria_history.some((c: any) => c.version < t.criteria_version) && (
            <button className="btn sm" onClick={() => setShowHistory(!showHistory)}>{showHistory ? 'Ẩn' : 'Xem'} các phiên bản trước</button>
          )}
          {showHistory && t.criteria_history.filter((c: any) => c.version < t.criteria_version).map((c: any) => (
            <div key={c.id} className="small muted">v{c.version} · {c.direction === 'output' ? 'Đầu ra' : 'Đầu vào'}: {c.criterion} ({c.created_by_name}, {fmtDT(c.created_at)})</div>
          ))}
        </Card>

        {(t.permits?.length > 0 || p.can_manage) && (
          <>
            <div className="section-title">Giấy phép kèm công việc ({t.permits?.length || 0})</div>
            {t.permits?.map((x: any) => (
              <Card key={x.id} to={`/permits/${x.id}`}>
                <div className="row"><span className="ichip teal" style={{ width: 34, height: 34 }}><Icon name={x.type_icon || 'permit'} size={17} /></span>
                  <div style={{ flex: 1, minWidth: 0 }}><b>{x.code}</b> · {x.type_name}<div className="small muted">{x.holder_name} · đến {fmtDT(x.valid_to)}</div></div>
                  <Badge tone={PERMIT_TONE[x.status]}>{PERMIT_STATUS[x.status]}</Badge></div>
              </Card>
            ))}
            {p.can_manage && !['completed', 'cancelled'].includes(t.status) && <Link className="btn sm" to={`/permits/new?taskId=${t.id}`}><Icon name="plus" size={16} />Lập giấy phép cho việc này</Link>}
          </>
        )}

        {t.unexpected && (
          <>
            <div className="section-title">Thông tin phát sinh</div>
            <Card>
              <KV k="Nguyên nhân" v={`${UNEXPECTED_CAUSE[t.unexpected.cause]}${t.unexpected.cause_detail ? ' — ' + t.unexpected.cause_detail : ''}`} />
              <KV k="Người yêu cầu" v={t.unexpected.requester_name} />
              <KV k="Thời điểm yêu cầu" v={fmtDT(t.unexpected.requested_at)} />
              {t.unexpected.impact && <KV k="Ảnh hưởng" v={t.unexpected.impact} />}
            </Card>
          </>
        )}

        {(t.subitems.length > 0 || (p.can_manage && t.is_unexpected)) && <SubItems t={t} onChange={setData} />}

        {t.evaluations.length > 0 && (
          <>
            <div className="section-title">Nghiệm thu & đánh giá</div>
            {t.evaluations.map((e: any) => (
              <Card key={e.id}>
                <div className="row"><b>{e.decision === 'approved' ? `Đạt — ${e.total_score} điểm` : 'Yêu cầu chỉnh sửa'}</b><span className="spacer" /><span className="small muted">{e.evaluator_name} · {fmtDT(e.created_at)}</span></div>
                {e.scores && <div className="small">{Object.entries(e.scores).map(([k, v]) => `${EVAL_LABEL[k] || k}: ${v}`).join(' · ')}</div>}
                {e.comment && <div className="small">{e.comment}</div>}
              </Card>
            ))}
          </>
        )}

        {t.submissions.length > 0 && (
          <>
            <div className="section-title">Bàn giao</div>
            {t.submissions.map((s: any) => <Card key={s.id}><div className="small muted">{s.name} · {fmtDT(s.created_at)} · {s.completion_percent}%</div><div className="crit">{s.output_description}</div>{(s.links || []).map((l: string, i: number) => <div key={i} className="small">🔗 <a href={l} target="_blank" rel="noreferrer">{l}</a></div>)}</Card>)}
          </>
        )}

        {t.reports.length > 0 && (
          <>
            <div className="section-title">Báo cáo trở ngại liên quan</div>
            {t.reports.map((r: any) => (
              <Card key={r.id} to={`/reports/${r.id}`}>
                <div className="row"><b>{r.code}</b><Badge tone="amber">{SEVERITY[r.severity]}</Badge><span className="spacer" />{RP_STATUS[r.status]}{r.impact_confirmed && <Badge tone="amber">Đã xác nhận ảnh hưởng</Badge>}</div>
                <div className="small ellipsis">{r.description}</div>
              </Card>
            ))}
          </>
        )}
        {t.overtime.length > 0 && (
          <>
            <div className="section-title">Tăng ca liên quan</div>
            {t.overtime.map((o: any) => <Card key={o.id} to={`/overtime/${o.id}`}><span>{o.name} · {hours(o.minutes)} · {fmtDT(o.start_at)}</span> <Badge>{OT_STATUS[o.approval_status]}</Badge></Card>)}
          </>
        )}

        <Files parentType="task" parentId={t.id} files={t.files} onDone={reload} />
        <Comments t={t} onChange={setData} />

        <div className="section-title">Lịch sử thay đổi</div>
        <Timeline items={t.activities.map((x: any) => ({
          at: x.created_at, title: `${AUDIT_ACTION[x.action] || x.action} · ${x.actor_name || 'Hệ thống'}`,
          body: [x.reason ? `Lý do: ${x.reason}` : '', x.new_value?.status ? `→ ${TASK_STATUS[x.new_value.status] || x.new_value.status}` : '', x.new_value?.due_at ? `Deadline mới: ${fmtDT(x.new_value.due_at)}` : ''].filter(Boolean).join(' · ') || undefined,
        }))} />
      </div>

      <Sheet open={sheet === 'unpin'} onClose={() => setSheet(null)} title="Gỡ ghim việc gấp">
        <p className="small">Người thực hiện sẽ nhận được thông báo.</p>
        <div className="actions stack">
          <button className="btn" disabled={a.busy} onClick={() => act(() => post(`/tasks/${id}/pin`, { pinned: false, urgent: true }))}>Gỡ ghim, vẫn giữ là việc gấp</button>
          <button className="btn primary" disabled={a.busy} onClick={() => act(() => post(`/tasks/${id}/pin`, { pinned: false, urgent: false }))}>Gỡ ghim, không còn gấp</button>
        </div>
      </Sheet>
      <Sheet open={sheet === 'plan'} onClose={() => setSheet(null)} title="Đổi ngày làm trong lịch">
        <PlanForm t={t} busy={a.busy} onSubmit={(d) => act(() => post(`/tasks/${id}/plan`, { planDate: d }))} />
      </Sheet>
      <Sheet open={sheet === 'submit'} onClose={() => setSheet(null)} title="Bàn giao kết quả"><SubmitForm taskId={t.id} busy={a.busy} error={a.error} onSubmit={(b) => act(() => post(`/tasks/${id}/submit`, b))} /></Sheet>
      <Sheet open={sheet === 'review'} onClose={() => setSheet(null)} title="Nghiệm thu nhiệm vụ"><ReviewForm t={t} busy={a.busy} error={a.error} onSubmit={(b) => act(() => post(`/tasks/${id}/review`, b))} /></Sheet>
      <Sheet open={sheet === 'cancel'} onClose={() => setSheet(null)} title="Hủy nhiệm vụ"><CancelForm busy={a.busy} error={a.error} onSubmit={(b) => act(() => post(`/tasks/${id}/cancel`, b))} /></Sheet>
      <Sheet open={sheet === 'edit'} onClose={() => setSheet(null)} title={p.can_edit_full ? 'Điều chỉnh nhiệm vụ' : 'Thêm / đổi người phụ trách'}><EditForm t={t} full={!!p.can_edit_full} busy={a.busy} error={a.error} onSubmit={(b) => act(() => patch(`/tasks/${id}`, b))} /></Sheet>
      <Sheet open={sheet === 'child'} onClose={() => setSheet(null)} title="Chia phần việc con / giai đoạn"><ChildForm t={t} busy={a.busy} error={a.error} onSubmit={(b) => act(async () => { await post('/tasks', b); return get(`/tasks/${id}`); })} /></Sheet>
      <Sheet open={sheet === 'reject'} onClose={() => setSheet(null)} title="Không duyệt giao việc"><RejectForm busy={a.busy} error={a.error} onSubmit={(note) => act(() => post(`/tasks/${id}/approve`, { decision: 'reject', note }))} /></Sheet>
    </>
  );
}

function PlanForm({ t, busy, onSubmit }: { t: any; busy: boolean; onSubmit: (d: string) => void }) {
  const [d, setD] = useState(t.plan_date?.slice(0, 10) || '');
  return (<><Field label="Ngày làm"><input type="date" value={d} onChange={(e) => setD(e.target.value)} /></Field><button className="btn primary block" disabled={busy || !d} onClick={() => onSubmit(d)}>Lưu</button></>);
}

function SubmitForm({ taskId, onSubmit, busy, error }: { taskId: string; onSubmit: (b: any) => void; busy: boolean; error: string | null }) {
  const [d, setD] = useState(''); const [pct, setPct] = useState(100); const [links, setLinks] = useState(''); const [files, setFiles] = useState<File[]>([]);
  const a = useAction();
  const linkList = links.split(/\s+/).map((x) => x.trim()).filter(Boolean);
  return (
    <>
      <Field label="Kết quả thực tế / sản phẩm bàn giao" required><textarea value={d} onChange={(e) => setD(e.target.value)} /></Field>
      <Field label={`Mức độ hoàn thành: ${pct}%`}><input type="range" min={0} max={100} step={5} value={pct} onChange={(e) => setPct(+e.target.value)} /></Field>
      <Field label="Đường link tài liệu (báo cáo, file online…)" hint="Mỗi dòng một link (Google Drive, OneDrive, Docs…)"><textarea rows={2} value={links} onChange={(e) => setLinks(e.target.value)} placeholder="https://..." /></Field>
      <Field label="Đính kèm tài liệu / ảnh"><input type="file" multiple accept="image/*,video/*,application/pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.txt" onChange={(e) => setFiles(Array.from(e.target.files || []))} /></Field>
      <ErrorBox error={error || a.error} />
      <button className="btn primary block" disabled={busy || a.busy} onClick={() => a.run(async () => {
        for (const f of files) await upload('task', taskId, f);
        onSubmit({ outputDescription: d, completionPercent: pct, links: linkList });
      })}>Bàn giao</button>
    </>
  );
}

function ReviewForm({ t, onSubmit, busy, error }: { t: any; onSubmit: (b: any) => void; busy: boolean; error: string | null }) {
  const keys = t.is_unexpected ? UNEXP : REGULAR;
  const [s, setS] = useState<Record<string, number>>(() => Object.fromEntries(keys.map((k) => [k, k === 'schedule' && t.suggested_schedule_score !== null ? t.suggested_schedule_score : 80])));
  const [comment, setComment] = useState('');
  const weights = (k: string) => (t.is_unexpected ? WU[k] ?? W[k] : W[k]);
  const total = keys.reduce((a, k) => a + (weights(k) / 100) * (s[k] || 0), 0);
  return (
    <>
      <p className="small muted">Chấm theo tiêu chí đã xác định trước khi thực hiện (thang 0–100 mỗi tiêu chí). {t.is_unexpected ? 'Công việc đột xuất dùng bộ tiêu chí riêng.' : ''}</p>
      <Card><b className="small">Tiêu chí đầu ra</b><ul>{t.criteria.filter((c: any) => c.direction === 'output').map((c: any) => <li key={c.id}>{c.criterion}</li>)}</ul></Card>
      {keys.map((k) => (
        <Field key={k} label={`${t.is_unexpected && k === 'quality' ? 'Chất lượng/độ chính xác' : EVAL_LABEL[k]} (${weights(k)}%): ${s[k]}`}
          hint={k === 'schedule' && t.suggested_schedule_score !== null ? `Gợi ý theo thời điểm bàn giao: ${t.suggested_schedule_score}${t.impediment_confirmed ? ' (có trở ngại đã xác nhận)' : ''}` : undefined}>
          <input type="range" min={0} max={100} step={5} value={s[k]} onChange={(e) => setS({ ...s, [k]: +e.target.value })} />
        </Field>
      ))}
      <div className="alert info">Tổng điểm nhiệm vụ: <b>{Math.round(total * 10) / 10}</b>/100</div>
      <Field label="Nhận xét (bắt buộc khi yêu cầu sửa)"><textarea value={comment} onChange={(e) => setComment(e.target.value)} /></Field>
      <ErrorBox error={error} />
      <div className="actions">
        <button className="btn primary" disabled={busy} onClick={() => onSubmit({ decision: 'approve', scores: s, comment: comment || undefined })}>✔ Xác nhận hoàn thành</button>
        <button className="btn danger" disabled={busy} onClick={() => onSubmit({ decision: 'revision', comment })}>↩ Yêu cầu chỉnh sửa</button>
      </div>
    </>
  );
}

function CancelForm({ onSubmit, busy, error }: { onSubmit: (b: any) => void; busy: boolean; error: string | null }) {
  const [reason, setReason] = useState(''); const [biz, setBiz] = useState(true);
  return (
    <>
      <Field label="Lý do hủy" required><textarea value={reason} onChange={(e) => setReason(e.target.value)} /></Field>
      <label className="check"><input type="checkbox" checked={biz} onChange={(e) => setBiz(e.target.checked)} /> Hủy do quyết định của doanh nghiệp (không tính là thất bại của nhân viên)</label>
      <ErrorBox error={error} />
      <button className="btn danger block" disabled={busy} onClick={() => onSubmit({ reason, businessDecision: biz })}>Xác nhận hủy</button>
    </>
  );
}

function EditForm({ t, full, onSubmit, busy, error }: { t: any; full: boolean; onSubmit: (b: any) => void; busy: boolean; error: string | null }) {
  const group = useLoad(() => get(`/groups/${t.group_id}`), [t.group_id]);
  const [title, setTitle] = useState(t.title);
  const [desc, setDesc] = useState(t.description);
  const [collabs, setCollabs] = useState<string[]>(t.assignees.filter((x: any) => x.assignment_type === 'collaborator' && x.active).map((x: any) => x.member_id));
  const [due, setDue] = useState(toLocalInput(new Date(t.due_at)));
  const [est, setEst] = useState(String(t.estimated_hours));
  const [owner, setOwner] = useState(t.owner_id);
  const [outputs, setOutputs] = useState<string>(t.criteria.filter((c: any) => c.direction === 'output').map((c: any) => c.criterion).join('\n'));
  const [reason, setReason] = useState('');
  const people: [string, string][] = group.data ? Array.from(new Map<string, string>([[group.data.manager_member_id, group.data.manager_name], ...group.data.members.map((m: any) => [m.member_id, m.name] as [string, string])]).entries()) : [];
  const curCollabs = t.assignees.filter((x: any) => x.assignment_type === 'collaborator' && x.active).map((x: any) => x.member_id);
  const submit = () => {
    const body: any = { reason: reason || undefined };
    if (owner !== t.owner_id) body.ownerMemberId = owner;
    if ([...collabs].sort().join() !== [...curCollabs].sort().join()) body.collaboratorIds = collabs.filter((c) => c !== owner);
    if (!full) return onSubmit(body);
    if (title.trim() !== t.title) body.title = title.trim();
    if (desc.trim() !== t.description) body.description = desc.trim();
    if (fromLocalInput(due) !== new Date(t.due_at).toISOString()) body.dueAt = fromLocalInput(due);
    if (Number(est) !== t.estimated_hours) body.estimatedHours = Number(est);
    const curOut = t.criteria.filter((c: any) => c.direction === 'output').map((c: any) => c.criterion).join('\n');
    if (outputs.trim() !== curOut) {
      body.criteria = [...t.criteria.filter((c: any) => c.direction === 'input').map((c: any) => ({ direction: 'input', criterion: c.criterion })),
        ...outputs.split('\n').map((x) => x.trim()).filter(Boolean).map((criterion) => ({ direction: 'output', criterion }))];
    }
    onSubmit(body);
  };
  return (
    <>
      <p className="small muted">{full ? 'Bạn là người giao việc: được sửa mô tả, deadline, tiêu chí, người vận hành khi việc chưa nghiệm thu. Thay đổi được lưu phiên bản và cần lý do.' : 'Phần việc trong chuỗi phân lớp: quản lý lớp dưới chỉ được thêm/đổi người phụ trách. Nội dung do người giao việc điều chỉnh.'}</p>
      {full && <Field label="Tiêu đề"><input value={title} onChange={(e) => setTitle(e.target.value)} /></Field>}
      {full && <Field label="Mô tả / phạm vi"><textarea value={desc} onChange={(e) => setDesc(e.target.value)} /></Field>}
      {full && <Field label="Deadline"><input type="datetime-local" value={due} onChange={(e) => setDue(e.target.value)} /></Field>}
      {full && <Field label="Thời lượng dự kiến (giờ)"><input type="number" value={est} onChange={(e) => setEst(e.target.value)} /></Field>}
      <Field label="Người chịu trách nhiệm (vận hành chính)"><Select value={owner} onChange={setOwner} options={people} /></Field>
      <Field label="Người cùng thực hiện">
        <div className="chip-row">{people.filter(([pid]) => pid !== owner).map(([pid, name]) => (
          <label key={pid} className="check"><input type="checkbox" checked={collabs.includes(pid)} onChange={(e) => setCollabs(e.target.checked ? [...collabs, pid] : collabs.filter((x) => x !== pid))} /> {name}</label>
        ))}</div>
      </Field>
      {full && <Field label="Tiêu chí đầu ra (mỗi dòng một tiêu chí — tạo phiên bản mới)"><textarea value={outputs} onChange={(e) => setOutputs(e.target.value)} /></Field>}
      <Field label="Lý do điều chỉnh" required={t.status !== 'not_started'}><textarea value={reason} onChange={(e) => setReason(e.target.value)} /></Field>
      <ErrorBox error={error} />
      <button className="btn primary block" disabled={busy} onClick={submit}>Lưu thay đổi</button>
    </>
  );
}

function SubItems({ t, onChange }: { t: any; onChange: (x: any) => void }) {
  const [title, setTitle] = useState(''); const [extra, setExtra] = useState('0');
  const a = useAction();
  return (
    <>
      <div className="section-title">Yêu cầu thành phần (phạm vi v{t.scope_version})</div>
      <Card>
        {t.subitems.map((s: any) => (
          <label key={s.id} className="check" style={{ alignItems: 'flex-start' }}>
            <input type="checkbox" checked={s.done} onChange={(e) => a.run(async () => onChange(await patch(`/tasks/${t.id}/subitems/${s.id}`, { done: e.target.checked })))} />
            <span>{s.title}<br /><span className="small muted">v{s.scope_version} · {s.requested_by_name} · {fmtDT(s.created_at)}{s.extra_hours ? ` · +${s.extra_hours}h` : ''}</span></span>
          </label>
        ))}
        {t.permissions.can_manage && !['completed', 'cancelled'].includes(t.status) && (
          <div style={{ display: 'flex', gap: 6, marginTop: 8 }}>
            <input placeholder="Yêu cầu bổ sung" value={title} onChange={(e) => setTitle(e.target.value)} />
            <input style={{ width: 80 }} type="number" min={0} value={extra} onChange={(e) => setExtra(e.target.value)} aria-label="Giờ thêm" title="Giờ phát sinh thêm" />
            <button className="btn sm" disabled={a.busy || !title} onClick={() => a.run(async () => { onChange(await post(`/tasks/${t.id}/subitems`, { title, extraHours: Number(extra) })); setTitle(''); setExtra('0'); })}>Thêm</button>
          </div>
        )}
        <ErrorBox error={a.error} />
      </Card>
    </>
  );
}

function Comments({ t, onChange }: { t: any; onChange: (x: any) => void }) {
  const { me } = useAuth();
  const [c, setC] = useState(''); const a = useAction();
  return (
    <>
      <div className="section-title">Bình luận ({t.comments.length})</div>
      {t.comments.map((x: any) => (
        <Card key={x.id}>
          <div className="row small muted"><span style={{ flex: 1 }}>{x.name} · {fmtDT(x.created_at)}</span>
            {x.member_id !== me?.member_id && <Link className="small muted" to={`/conduct/new?objectType=comment&objectId=${x.id}&objectLabel=${encodeURIComponent(`Bình luận của ${x.name} trong ${t.code} lúc ${fmtDT(x.created_at)}`)}&reported=${x.member_id}`} title="Báo cáo hành vi cần xem xét" aria-label="Báo cáo bình luận">Báo cáo</Link>}
          </div>
          <div className="crit">{x.content}</div>
        </Card>
      ))}
      <div style={{ display: 'flex', gap: 6 }}>
        <input placeholder="Viết bình luận…" value={c} onChange={(e) => setC(e.target.value)} />
        <button className="btn" disabled={a.busy || !c.trim()} onClick={() => a.run(async () => { onChange(await post(`/tasks/${t.id}/comments`, { content: c })); setC(''); })}>Gửi</button>
      </div>
      <ErrorBox error={a.error} />
    </>
  );
}

export function Files({ parentType, parentId, files, onDone, canUpload = true }: { parentType: string; parentId: string; files: any[]; onDone: () => void; canUpload?: boolean }) {
  const a = useAction();
  return (
    <>
      <div className="section-title">Tệp đính kèm / bằng chứng ({files.length})</div>
      {files.map((f) => (
        <Card key={f.id} onClick={() => a.run(() => download(`/files/${f.id}`, f.filename))}>
          <div className="row"><span>📎 {f.filename}</span><span className="spacer" /><span className="small muted">{Math.round(f.size / 1024)} KB</span></div>
        </Card>
      ))}
      {canUpload && (
        <label className="btn sm" style={{ marginTop: 4 }}>
          {a.busy ? 'Đang tải lên…' : '＋ Tải tệp (ảnh/video/tài liệu, ≤20MB)'}
          <input type="file" hidden accept="image/*,video/*,application/pdf,.doc,.docx,.xls,.xlsx,.txt" onChange={(e) => { const f = e.target.files?.[0]; if (f) a.run(async () => { await upload(parentType, parentId, f); onDone(); }); e.target.value = ''; }} />
        </label>
      )}
      <ErrorBox error={a.error} />
    </>
  );
}

/** Các giai đoạn / phần việc con: cùng giai đoạn làm song song, giai đoạn sau mở khi giai đoạn trước xong. */
function Stages({ t, onAdd }: { t: any; onAdd?: () => void }) {
  const byStage = new Map<number, any[]>();
  for (const c of t.children) { const k = c.stage_no || 1; byStage.set(k, [...(byStage.get(k) || []), c]); }
  const stages = [...byStage.keys()].sort((x, y) => x - y);
  const doneN = t.children.filter((c: any) => c.status === 'completed').length;
  return (
    <>
      <div className="section-title">{t.is_standing ? 'Công đoạn' : 'Phần việc con'} · {doneN}/{t.children.length} phần xong{t.active_stage && !t.is_standing ? ` · đang ở giai đoạn ${t.active_stage}` : ''}</div>
      {stages.map((st) => {
        const items = byStage.get(st)!;
        const allDone = items.every((c) => ['completed', 'cancelled'].includes(c.status));
        return (
          <div key={st} className={`stage-box ${t.active_stage === st ? 'active' : ''}`}>
            <div className="stage-h"><Dot k={allDone ? 'completed' : t.active_stage === st ? 'in_progress' : 'waiting'} size={10} />Giai đoạn {st}{items.length > 1 ? ` · ${items.length} việc song song` : ''}</div>
            {items.map((c) => (
              <Link key={c.id} to={`/tasks/${c.id}`} className="sub-row">
                <TaskMarks t={c} size={10} />
                <span style={{ flex: 1, minWidth: 0 }}><span className="ellipsis">{taskLabel(c, t.is_chain ? t.chain_code : c.root_chain_code)}</span><span className="small muted"> · {c.group_name} · {c.owner_name}</span></span>
                <span className="small muted">{c.child_count > 0 ? `${c.child_count} con` : TASK_STATUS[c.status]}</span>
              </Link>
            ))}
          </div>
        );
      })}
      {t.hidden_children > 0 && <p className="small muted">+ {t.hidden_children} phần việc của người/bộ phận khác (bạn chỉ thấy phần việc của mình trong chuỗi).</p>}
      {t.status !== 'completed' && t.children.length > 0 && !t.is_standing && <p className="small muted">Việc khung tự chuyển sang chờ nghiệm thu khi mọi phần việc con hoàn thành; người nghiệm thu là quản lý trực tiếp của nhóm.</p>}
      {onAdd && <button className="btn sm" onClick={onAdd}><Icon name="layers" size={16} />{t.is_standing ? 'Thêm công đoạn' : `Chia phần việc con (${t.is_chain ? 'công đoạn của đơn hàng' : `mã ${t.code}.n`})`}</button>}
    </>
  );
}

function ChildForm({ t, busy, error, onSubmit }: { t: any; busy: boolean; error: string | null; onSubmit: (b: any) => void }) {
  const groups = useLoad(() => get('/groups?scope=all'), []);
  const maxStage = Math.max(0, ...(t.children || []).map((c: any) => c.stage_no || 1));
  const openStages = (t.children || []).filter((c: any) => !['completed', 'cancelled'].includes(c.status)).map((c: any) => c.stage_no || 1);
  const minStage = openStages.length ? Math.min(...openStages) : maxStage + 1 || 1; // không chọn giai đoạn đã hoàn thành
  const [autoStart, setAutoStart] = useState('manual'); const [sched, setSched] = useState('');
  const [title, setTitle] = useState('');
  const [groupId, setGroupId] = useState(t.group_id);
  const [owner, setOwner] = useState('');
  const [stage, setStage] = useState(String(Math.max(minStage, maxStage || 1)));
  const [est, setEst] = useState('2');
  const [due, setDue] = useState(toLocalInput(new Date(t.due_at)));
  const [desc, setDesc] = useState('');
  const g = useLoad(() => (groupId ? get(`/groups/${groupId}`) : Promise.resolve(null)), [groupId]);
  const people: [string, string][] = g.data ? Array.from(new Map<string, string>([[g.data.manager_member_id, `${g.data.manager_name} (quản lý nhóm)`], ...g.data.members.map((m: any) => [m.member_id, `${m.name} · đang làm ${m.doing ?? 0}`] as [string, string])]).entries()) : [];
  const grp = (groups.data || []).find((x: any) => x.id === groupId);
  const notMine = !!grp && !grp.is_manager && groupId !== t.group_id;
  const stageOpts: [string, string][] = Array.from({ length: maxStage + 1 }, (_, i) => i + 1).filter((n) => n >= minStage)
    .map((n) => [String(n), n <= maxStage ? `Giai đoạn ${n} (song song với việc đang làm)` : `Giai đoạn ${n} (mới — làm sau)`]);
  const nextCode = t.is_chain ? 'NV-xxxxx (mã riêng, thuộc ' + t.chain_code + ')' : `${t.code}.${(t.children?.length || 0) + (t.hidden_children || 0) + 1}`;
  return (
    <>
      <p className="small muted">Không cần khai lại: loại việc, mức yêu cầu, mô tả và hạn được kế thừa từ việc cha. Cùng giai đoạn = làm song song (có thể hai người khác nhau); giai đoạn sau chỉ bắt đầu khi giai đoạn trước hoàn thành.</p>
      <Field label="Tên phần việc" required hint={`Mã: ${nextCode}`}><input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="VD: Kiểm hàng" /></Field>
      <Field label="Giai đoạn"><Select value={stage} onChange={setStage} options={stageOpts} /></Field>
      <Field label="Bộ phận / nhóm thực hiện" hint={notMine ? 'Nhóm bạn không quản lý: quản lý nhóm đó nhận việc; cần cấp quản lý cao hơn duyệt.' : undefined}>
        <Select value={groupId} onChange={(v) => { setGroupId(v); setOwner(''); }} options={(groups.data || []).map((x: any) => [x.id, x.name])} />
      </Field>
      <Field label="Người phụ trách"><Select value={owner} onChange={setOwner} options={people} placeholder="— Quản lý nhóm nhận và tự phân công —" /></Field>
      <div className="row" style={{ gap: 8 }}>
        <Field label="Giờ dự kiến"><input type="number" min={0.5} step={0.5} value={est} onChange={(e) => setEst(e.target.value)} /></Field>
        <Field label="Hạn"><input type="datetime-local" value={due} onChange={(e) => setDue(e.target.value)} /></Field>
      </div>
      {!t.is_standing && <Field label="Bắt đầu"><Select value={autoStart} onChange={setAutoStart} options={AUTO_START} /></Field>}
      {autoStart === 'scheduled' && <Field label="Thời điểm bắt đầu"><input type="datetime-local" value={sched} onChange={(e) => setSched(e.target.value)} /></Field>}
      <Field label="Ghi chú riêng (tùy chọn)" hint="Để trống sẽ dùng mô tả việc cha"><textarea value={desc} onChange={(e) => setDesc(e.target.value)} /></Field>
      <ErrorBox error={error} />
      <button className="btn primary block" disabled={busy || title.trim().length < 3} onClick={() => onSubmit({
        parentId: t.id, title: title.trim(), groupId, ownerMemberId: owner || undefined, stageNo: Number(stage), estimatedHours: Number(est) || undefined,
        dueAt: fromLocalInput(due), description: desc.trim().length >= 5 ? desc.trim() : undefined, autoStart, scheduledStartAt: autoStart === 'scheduled' ? fromLocalInput(sched) : undefined,
        standardMinutes: Math.round((Number(est) || 0) * 60) || undefined,
      })}>Thêm phần việc</button>
    </>
  );
}

function RejectForm({ busy, error, onSubmit }: { busy: boolean; error: string | null; onSubmit: (n: string) => void }) {
  const [n, setN] = useState('');
  return (<><Field label="Lý do không duyệt" required><textarea value={n} onChange={(e) => setN(e.target.value)} /></Field><ErrorBox error={error} /><button className="btn danger block" disabled={busy || n.trim().length < 5} onClick={() => onSubmit(n)}>Không duyệt</button></>);
}
