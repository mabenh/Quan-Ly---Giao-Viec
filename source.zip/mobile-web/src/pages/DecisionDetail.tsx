import { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { download, get, post } from '../api';
import { Avatar, Badge, Card, ErrorBox, Field, Header, KV, Loading, Select, useAction, useLoad } from '../ui';
import { Icon } from '../icons';
import { DECISION_STATUS, DECISION_TONE, DECISION_TYPE, ROLE, TASK_STATUS, fmtD, fmtDT, relDue } from '../labels';

export default function DecisionDetail() {
  const { id } = useParams();
  const { data: d, error, loading, setData } = useLoad(() => get(`/decisions/${id}`), [id]);
  const [plan, setPlan] = useState<Record<string, string>>({});
  const [note, setNote] = useState('');
  const [cnote, setCnote] = useState('');
  const a = useAction();
  useEffect(() => {
    if (!d) return;
    const prev = Object.fromEntries((d.handover_plan || []).map((p: any) => [p.taskId, p.receiverId || '']));
    setPlan(Object.fromEntries(d.open_tasks.map((t: any) => {
      const def = prev[t.id] || (d.receiver_candidates.some((c: any) => c.id === d.handover_receiver_id && c.group_id === t.group_id) ? d.handover_receiver_id : '');
      return [t.id, def];
    })));
    setNote(d.handover_note || '');
  }, [d?.id, d?.status]);
  if (loading && !d) return <Loading />;
  if (!d) return <div className="page"><ErrorBox error={error} /></div>;
  const p = d.permissions;
  const owned = d.open_tasks.filter((t: any) => t.assignment_type === 'owner');
  return (
    <>
      <Header title={`Quyết định ${d.code}`} back />
      <div className="page">
        <div className="hero">
          <div className="small" style={{ opacity: .85 }}>{DECISION_TYPE[d.decision_type]}</div>
          <h1>{d.member_name}</h1>
          <div className="muted small">Hiệu lực {fmtD(d.effective_date)} · Hạn bàn giao {fmtDT(d.handover_deadline)} ({relDue(d.handover_deadline)})</div>
          <div className="chips"><Badge tone={DECISION_TONE[d.status]}>{DECISION_STATUS[d.status]}</Badge>{d.overdue_handover && <Badge tone="red">Quá hạn bàn giao</Badge>}</div>
        </div>
        {['handover', 'pending_confirm'].includes(d.status) && <div className="alert warn small">Trong thời gian bàn giao, {d.member_name} không nhận việc mới. Quyết định có hiệu lực sau khi <b>{d.confirmer_name}</b> xác nhận bàn giao.</div>}
        <Card>
          {d.new_role && <KV k="Vai trò mới" v={`${ROLE[d.current_role]} → ${ROLE[d.new_role]}`} />}
          {d.new_title && <KV k="Chức danh mới" v={d.new_title} />}
          {d.new_group_name && <KV k="Nhóm mới" v={d.new_group_name} />}
          {d.new_department_name && <KV k="Bộ phận mới" v={d.new_department_name} />}
          {d.new_supervisor_name && <KV k="Cấp trên mới" v={d.new_supervisor_name} />}
          <KV k="Lý do" v={d.reason} />
          <KV k="Người ra quyết định" v={d.created_by_name} />
          <KV k="Người xác nhận bàn giao" v={d.confirmer_name} />
          {d.receiver_name && <KV k="Người nhận bàn giao mặc định" v={d.receiver_name} />}
          {d.confirmed_by_name && <KV k="Đã xác nhận" v={`${d.confirmed_by_name} · ${fmtDT(d.confirmed_at)}`} />}
          {d.confirm_note && <KV k="Ghi chú của quản lý" v={d.confirm_note} />}
        </Card>
        <div className="actions">{d.pdf_file_id && <button className="btn" onClick={() => a.run(() => download(`/decisions/${id}/pdf`, `Quyet-dinh-${d.code}.pdf`))}><Icon name="decision" size={18} />Tải quyết định (PDF)</button>}</div>

        <div className="section-title">Công việc cần bàn giao ({owned.length})</div>
        {d.open_tasks.length === 0 && <div className="empty">Không có việc đang mở</div>}
        {d.open_tasks.map((t: any) => {
          const cands = d.receiver_candidates.filter((c: any) => c.group_id === t.group_id);
          return (
            <Card key={t.id}>
              <div className="row"><Link to={`/tasks/${t.id}`} className="title" style={{ flex: 1 }}>{t.code} · {t.title}</Link><Badge>{TASK_STATUS[t.status]}</Badge></div>
              <div className="small muted">{t.group_name} · hạn {fmtDT(t.due_at)}{t.assignment_type === 'collaborator' ? ' · cộng tác viên (tự rút khỏi việc)' : ''}</div>
              {t.assignment_type === 'owner' && (p.can_handover
                ? <Field label="Người nhận bàn giao"><Select value={plan[t.id] || ''} onChange={(v) => setPlan({ ...plan, [t.id]: v })} options={cands.map((c: any) => [c.id, c.name])} placeholder="— Chọn người nhận —" /></Field>
                : d.handover_plan && <div className="small">→ {d.receiver_candidates.find((c: any) => c.id === (d.handover_plan.find((x: any) => x.taskId === t.id)?.receiverId))?.name || '—'}</div>)}
            </Card>
          );
        })}
        {p.can_handover && (
          <>
            <Field label="Ghi chú bàn giao" required hint="Tài liệu, tài sản, chìa khóa, mật khẩu, tình trạng từng việc…"><textarea value={note} onChange={(e) => setNote(e.target.value)} /></Field>
            <ErrorBox error={a.error} />
            <button className="btn primary block" disabled={a.busy} onClick={() => a.run(async () => setData(await post(`/decisions/${id}/handover`, { note, plan: owned.map((t: any) => ({ taskId: t.id, receiverId: plan[t.id] || null })) })))}>Gửi bàn giao cho {d.confirmer_name}</button>
          </>
        )}
        {d.handover_note && !p.can_handover && <Card><b className="small">Ghi chú bàn giao</b><div className="crit">{d.handover_note}</div><div className="small muted">Gửi lúc {fmtDT(d.handover_submitted_at)}</div></Card>}
        {p.can_confirm && (
          <Card>
            <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}><Avatar userId={d.user_id} name={d.member_name} has={d.has_avatar} /><b>{d.member_name} đã gửi bàn giao</b></div>
            <Field label="Ghi chú (bắt buộc khi trả lại)"><textarea value={cnote} onChange={(e) => setCnote(e.target.value)} /></Field>
            <ErrorBox error={a.error} />
            <div className="actions">
              <button className="btn primary" disabled={a.busy} onClick={() => a.run(async () => setData(await post(`/decisions/${id}/confirm`, { decision: 'confirm', note: cnote || undefined })))}><Icon name="ok" size={18} />Xác nhận bàn giao</button>
              <button className="btn danger" disabled={a.busy} onClick={() => a.run(async () => setData(await post(`/decisions/${id}/confirm`, { decision: 'return', note: cnote })))}>Trả lại bổ sung</button>
            </div>
          </Card>
        )}
        {p.can_cancel && <button className="btn" style={{ marginTop: 10 }} disabled={a.busy} onClick={() => confirm('Hủy quyết định này?') && a.run(async () => setData(await post(`/decisions/${id}/cancel`, {})))}>Hủy quyết định</button>}
      </div>
    </>
  );
}
