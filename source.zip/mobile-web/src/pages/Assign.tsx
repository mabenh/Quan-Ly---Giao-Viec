import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { get } from '../api';
import { isAdminRole, isHRRole, useAuth } from '../auth';
import { Avatar, Badge, ErrorBox, Loading, Sheet, useLoad } from '../ui';
import { Icon } from '../icons';
import { ROLE } from '../labels';
import { rememberContact, telHref } from '../contact';

/** Giao việc: danh sách thành viên theo nhóm (thu gọn được), bấm avatar để giao việc nhanh. */
export default function Assign() {
  const { me } = useAuth();
  const nav = useNavigate();
  const { data, error, loading } = useLoad(() => get('/hr/org-chart'), []);
  const [collapsed, setCollapsed] = useState<Record<string, boolean>>({});
  const [allCollapsed, setAllCollapsed] = useState(false);
  const [pick, setPick] = useState<{ m: any; groupId: string } | null>(null);
  const [q, setQ] = useState('');
  if (loading && !data) return <Loading />;
  if (!data) return <div className="page"><ErrorBox error={error} /></div>;
  const byId = Object.fromEntries(data.members.map((m: any) => [m.id, m]));
  const seeAll = isAdminRole(me?.role) || isHRRole(me?.role);
  const groups = data.groups.filter((g: any) => seeAll || g.manager_member_id === me?.member_id);
  const match = (m: any) => !q || m.name.toLowerCase().includes(q.toLowerCase());
  const toggleAll = () => { const v = !allCollapsed; setAllCollapsed(v); setCollapsed(Object.fromEntries(groups.map((g: any) => [g.id, v]))); };
  return (
    <div className="page">
      <div className="row" style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
        <h1 style={{ flex: 1 }}>Giao việc</h1>
        <button className="btn sm" onClick={toggleAll}><Icon name={allCollapsed ? 'list' : 'grid'} size={16} />{allCollapsed ? 'Mở rộng' : 'Thu gọn nhóm'}</button>
      </div>
      <p className="small muted">Bấm vào ảnh đại diện để giao việc nhanh. Số dưới ảnh là số việc người đó đang có.</p>
      <div className="quick">
        <Link className="btn primary" to="/tasks/new"><Icon name="plus" size={18} />Giao việc mới</Link>
        <Link className="btn" to="/quick/new"><Icon name="phone" size={18} />Khai việc nhanh</Link>
      </div>
      <input placeholder="Tìm nhân viên…" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Tìm nhân viên" />
      {groups.length === 0 && <div className="empty">Bạn chưa quản lý nhóm nào. <Link to="/groups">Tạo nhóm</Link></div>}
      {groups.map((g: any) => {
        const ids = [...new Set([g.manager_member_id, ...(g.member_ids || [])])].filter((id) => byId[id]);
        const people = ids.map((id) => byId[id]).filter(match);
        const total = people.reduce((a: number, m: any) => a + m.open_tasks, 0);
        const isC = collapsed[g.id];
        return (
          <div key={g.id} className="grp">
            <button className="grp-head" onClick={() => setCollapsed({ ...collapsed, [g.id]: !isC })} aria-expanded={!isC}>
              <Icon name={isC ? 'chevron' : 'down'} size={18} /><b>{g.name}</b>
              <span className="n">{people.length} người · {total} việc</span>
            </button>
            {!isC && (
              <div className="card" style={{ padding: 0, marginTop: 6 }}>
                {people.map((m: any) => {
                  const st = m.handover_code ? ['Đang bàn giao', 'purple'] : m.on_leave ? ['Đang nghỉ phép', 'teal'] : m.open_tasks >= 8 ? ['Nhiều việc', 'red'] : null;
                  return (
                    <div key={m.id} className="mem-row">
                      <button className="mem-av" onClick={() => setPick({ m, groupId: g.id })} aria-label={`Giao việc cho ${m.name}`}>
                        <Avatar userId={m.user_id} name={m.name} has={m.has_avatar} />
                        <span className={`cnt ${m.open_tasks === 0 ? 'zero' : m.open_tasks >= 8 ? 'heavy' : ''}`}>{m.open_tasks} việc</span>
                      </button>
                      <div style={{ flex: 1, minWidth: 0 }}>
                        <b>{m.name}</b>{m.id === g.manager_member_id && <span className="small muted"> · quản lý nhóm</span>}
                        <div className="small muted ellipsis">{m.title || ROLE[m.role]}</div>
                        {st && <Badge tone={st[1]}>{st[0]}</Badge>}
                      </div>
                      <button className="btn sm" disabled={!!m.handover_code} onClick={() => nav(`/tasks/new?owner=${m.id}&group=${g.id}`)} title="Giao việc nhanh"><Icon name="assign" size={16} />Giao</button>
                    </div>
                  );
                })}
                {people.length === 0 && <div className="small muted" style={{ padding: 12 }}>Không có thành viên phù hợp</div>}
              </div>
            )}
          </div>
        );
      })}
      <Sheet open={!!pick} onClose={() => setPick(null)} title={pick?.m.name || ''}>
        {pick && (
          <>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
              <Avatar userId={pick.m.user_id} name={pick.m.name} has={pick.m.has_avatar} size="lg" />
              <div><b>{pick.m.name}</b><div className="small muted">{pick.m.title || ROLE[pick.m.role]}</div><div className="small">{pick.m.open_tasks} việc đang mở{pick.m.on_leave ? ' · đang nghỉ phép' : ''}</div></div>
            </div>
            {pick.m.handover_code && <div className="alert warn small">Đang bàn giao theo quyết định {pick.m.handover_code} — chưa nhận việc mới.</div>}
            <div className="actions stack">
              <button className="btn primary" disabled={!!pick.m.handover_code} onClick={() => nav(`/tasks/new?owner=${pick.m.id}&group=${pick.groupId}`)}><Icon name="assign" size={18} />Giao việc nhanh</button>
              <Link className="btn" to={`/quick/new?c=${pick.m.id}`}><Icon name="headset" size={18} />Khai việc đã giao qua điện thoại</Link>
              {pick.m.phone && <a className="btn" href={telHref(pick.m.phone)} onClick={() => rememberContact({ memberId: pick.m.id, name: pick.m.name, channel: 'call', at: new Date().toISOString() })}><Icon name="phone" size={18} />Gọi {pick.m.phone}</a>}
              <Link className="btn" to={`/work?tab=tasks&memberId=${pick.m.id}`}><Icon name="tasks" size={18} />Xem việc đang có</Link>
              <Link className="btn" to={`/people/${pick.m.user_id}`}><Icon name="record" size={18} />Hồ sơ</Link>
            </div>
          </>
        )}
      </Sheet>
    </div>
  );
}
