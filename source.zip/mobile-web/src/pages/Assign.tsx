import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { get } from '../api';
import { can, isAdminRole, useAuth } from '../auth';
import { Avatar, Badge, ErrorBox, Loading, Sheet, useLoad, Note } from '../ui';
import { Icon } from '../icons';
import { ROLE } from '../labels';
import { useComms } from '../comms';

/** Giao việc: danh sách thành viên theo nhóm (thu gọn được), bấm avatar để giao việc nhanh. */
export default function Assign() {
  const { me } = useAuth();
  const nav = useNavigate();
  const { startCall } = useComms();
  const { data, error, loading } = useLoad(() => get('/hr/org-chart'), []);
  const mine = useLoad(() => get('/groups'), []);
  const [collapsed, setCollapsed] = useState<Record<string, boolean>>({});
  const [allCollapsed, setAllCollapsed] = useState(false);
  const [pick, setPick] = useState<{ m: any; groupId: string } | null>(null);
  const [q, setQ] = useState('');
  if (loading && !data) return <Loading />;
  if (!data) return <div className="page"><ErrorBox error={error} /></div>;
  const byId = Object.fromEntries(data.members.map((m: any) => [m.id, m]));
  // v8: chỉ hiện nhóm trong phạm vi giao việc (toàn công ty / phòng ban / nhóm mình phụ trách); Quản lý nhân sự chỉ thấy nhóm phòng nhân sự
  const assignable = new Set((mine.data || []).filter((g: any) => g.assignable).map((g: any) => g.id));
  const seeAll = (isAdminRole(me?.role) || can(me, 'assign_all')) && !me?.authority?.hr_scoped;
  const groups = data.groups.filter((g: any) => seeAll || assignable.has(g.id) || g.manager_member_id === me?.member_id);
  const match = (m: any) => !q || m.name.toLowerCase().includes(q.toLowerCase());
  const toggleAll = () => { const v = !allCollapsed; setAllCollapsed(v); setCollapsed(Object.fromEntries(groups.map((g: any) => [g.id, v]))); };
  return (
    <div className="page">
      <div className="row" style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
        <h1 style={{ flex: 1 }}>Giao việc</h1>
        <button className="btn sm" onClick={toggleAll}><Icon name={allCollapsed ? 'list' : 'grid'} size={16} />{allCollapsed ? 'Mở rộng' : 'Thu gọn nhóm'}</button>
      </div>
      <Note>Bấm vào ảnh đại diện để giao việc nhanh. Số dưới ảnh là số việc người đó đang có.</Note>
      <div className="quick">
        <Link className="btn primary" to="/tasks/new"><Icon name="plus" size={18} />Giao việc mới</Link>
        <Link className="btn" to="/quick/new"><Icon name="phone" size={18} />Khai việc nhanh</Link>
      </div>
      <div className="quick">
        {can(me, 'create_order') ? <Link className="btn" to="/chains"><Icon name="flow" size={18} />Đơn hàng</Link> : <Link className="btn" to="/tasks"><Icon name="tasks" size={18} />Danh sách nhiệm vụ</Link>}
        {(can(me, 'manage_templates_all') || can(me, 'manage_templates_dept')) ? <Link className="btn" to="/templates"><Icon name="clipboard-check" size={18} />Mẫu công việc</Link> : <Link className="btn" to="/tasks?tab=tasks&mine=owner">Việc tôi giao</Link>}
      </div>
      {me?.authority && <p className="small muted">Phạm vi giao việc của bạn: {me.authority.position || 'chưa gán chức vụ'} (tầng {me.authority.tier}){me.authority.department ? ` · ${me.authority.department}` : ''} — {can(me, 'assign_all') ? 'toàn đơn vị' : can(me, 'assign_dept') ? 'các nhóm trong phòng ban' : 'nhóm bạn phụ trách'}.</p>}
      <input placeholder="Tìm nhân viên…" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Tìm nhân viên" />
      {groups.length === 0 && <div className="empty">Bạn chưa quản lý nhóm nào. <Link to="/groups">Tạo nhóm</Link></div>}
      {groups.map((g: any) => {
        const ids = [...new Set([g.manager_member_id, ...(g.member_ids || [])])].filter((id) => byId[id]);
        const people = ids.map((id) => byId[id]).filter(match);
        const total = people.reduce((a: number, m: any) => a + m.open_tasks, 0);
        const isC = collapsed[g.id];
        return (
          <div key={g.id} className="grp">
            <button className="grp-head" onClick={() => setCollapsed({ ...collapsed, [g.id]: !isC })} aria-expanded={!isC}>
              <Icon name={isC ? 'chevron' : 'down'} size={18} /><b>{g.name}</b>
              <span className="n">{people.length} người · {total} việc</span>
            </button>
            {!isC && (
              <div className="card" style={{ padding: 0, marginTop: 6 }}>
                {people.map((m: any) => {
                  const st = m.handover_code ? ['Đang bàn giao', 'purple'] : m.on_leave ? ['Đang nghỉ phép', 'teal'] : m.open_tasks >= 8 ? ['Nhiều việc', 'red'] : null;
                  return (
                    <div key={m.id} className="mem-row">
                      <button className="mem-av" onClick={() => setPick({ m, groupId: g.id })} aria-label={`Giao việc cho ${m.name}`}>
                        <Avatar userId={m.user_id} name={m.name} has={m.has_avatar} />
                        <span className={`cnt ${m.open_tasks === 0 ? 'zero' : m.open_tasks >= 8 ? 'heavy' : ''}`}>{m.open_tasks} việc</span>
                      </button>
                      <div style={{ flex: 1, minWidth: 0 }}>
                        <b>{m.name}</b>{m.id === g.manager_member_id && <span className="small muted"> · quản lý nhóm</span>}
                        <div className="small muted ellipsis">{m.title || ROLE[m.role]}</div>
                        {st && <Badge tone={st[1]}>{st[0]}</Badge>}
                      </div>
                      <button className="btn sm" disabled={!!m.handover_code} onClick={() => nav(`/tasks/new?owner=${m.id}&group=${g.id}`)} title="Giao việc nhanh"><Icon name="assign" size={16} />Giao</button>
                    </div>
                  );
                })}
                {people.length === 0 && <div className="small muted" style={{ padding: 12 }}>Không có thành viên phù hợp</div>}
              </div>
            )}
          </div>
        );
      })}
      <Sheet open={!!pick} onClose={() => setPick(null)} title={pick?.m.name || ''}>
        {pick && (
          <>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
              <Avatar userId={pick.m.user_id} name={pick.m.name} has={pick.m.has_avatar} size="lg" />
              <div><b>{pick.m.name}</b><div className="small muted">{pick.m.title || ROLE[pick.m.role]}</div><div className="small">{pick.m.open_tasks} việc đang mở{pick.m.on_leave ? ' · đang nghỉ phép' : ''}</div></div>
            </div>
            {pick.m.handover_code && <div className="alert warn small">Đang bàn giao theo quyết định {pick.m.handover_code} — chưa nhận việc mới.</div>}
            <div className="actions stack">
              <button className="btn primary" disabled={!!pick.m.handover_code} onClick={() => nav(`/tasks/new?owner=${pick.m.id}&group=${pick.groupId}`)}><Icon name="assign" size={18} />Giao việc nhanh</button>
              <Link className="btn" to={`/quick/new?c=${pick.m.id}`}><Icon name="headset" size={18} />Khai việc đã giao qua điện thoại</Link>
              <button className="btn" onClick={() => { startCall(pick.m.id, pick.m.name); setPick(null); }}><Icon name="phone" size={18} />Gọi qua app (tối đa 3 phút)</button>
              <Link className="btn" to={`/messages/${pick.m.id}`}><Icon name="message-alert" size={18} />Nhắn tin</Link>
              <Link className="btn" to={`/work?tab=tasks&memberId=${pick.m.id}`}><Icon name="tasks" size={18} />Xem việc đang có</Link>
              <Link className="btn" to={`/people/${pick.m.user_id}`}><Icon name="record" size={18} />Hồ sơ</Link>
            </div>
          </>
        )}
      </Sheet>
    </div>
  );
}
