import { useState } from 'react';
import { Link } from 'react-router-dom';
import { get, patch, post } from '../api';
import { isAdminRole, tierOf, useAuth } from '../auth';
import { Avatar, Badge, Card, ErrorBox, Field, Header, Loading, Select, Sheet, useAction, useLoad, Note } from '../ui';
import { DECISION_TYPE, MEMBER_STATUS, PLAN_NAME, ROLE, isoDate, toLocalInput, fromLocalInput } from '../labels';
import { Icon } from '../icons';
import { JoinCodeCard } from '../appstatus';
import { useNavigate } from 'react-router-dom';

export default function AdminMembers() {
  const { me } = useAuth();
  const [search, setSearch] = useState('');
  const { data, error, loading, reload } = useLoad(() => get(`/company/members?q=${encodeURIComponent(search)}`), [search]);
  const depts = useLoad(() => get('/company/departments'), []);
  const [edit, setEdit] = useState<any>(null);
  const [invite, setInvite] = useState(false);
  const [review, setReview] = useState<any>(null);
  const [decision, setDecision] = useState<{ m: any; type: string } | null>(null);
  const nav = useNavigate();
  const hr = ['owner', 'admin', 'hr'].includes(me?.role || '');
  const admin = isAdminRole(me?.role);
  const roles = me?.role === 'owner' ? ROLE : Object.fromEntries(Object.entries(ROLE).filter(([k]) => k !== 'owner'));
  // v10: tầng 3–5 quản lý thành viên; tầng 5 (không phải nhân sự) chỉ thấy phòng ban của mình
  const tier = tierOf(me);
  const myDept = me?.authority?.department_id || null;
  const deptScoped = !hr && tier === 5;
  const scoped = (data || []).filter((m: any) => !deptScoped || m.department_id === myDept);
  const pending = scoped.filter((m: any) => m.status === 'pending_hr');
  const active = scoped.filter((m: any) => m.status !== 'pending_hr');
  const [by, setBy] = useState<'tier' | 'dept'>('tier');
  const [closed, setClosed] = useState<Record<string, boolean>>({});
  const groupsOf = (list: any[]) => {
    const map = new Map<string, { label: string; sort: string; items: any[] }>();
    for (const m of list) {
      const key = by === 'tier' ? String(m.tier || (m.role === 'owner' ? 3 : m.role === 'admin' ? 4 : m.role === 'employee' ? 7 : 5)) : (m.department_id || 'none');
      const label = by === 'tier' ? `Tầng ${key} · ${TIER_NAME[key] || ''}` : (m.department_name || 'Chưa thuộc phòng ban');
      if (!map.has(key)) map.set(key, { label, sort: by === 'tier' ? key : (m.department_name ? '0' + m.department_name : 'z'), items: [] });
      map.get(key)!.items.push(m);
    }
    return [...map.entries()].sort((a, b) => a[1].sort.localeCompare(b[1].sort, 'vi'));
  };
  const canManage = hr || tier <= 5;
  const used = (data || []).filter((m: any) => ['active', 'pending_hr'].includes(m.status)).length;
  return (
    <>
      <Header title={deptScoped ? `Thành viên · ${me?.authority?.department || ''}` : 'Thành viên'} back right={canManage ? <button className="btn primary sm" onClick={() => setInvite(true)}><Icon name="plus" size={16} />Thêm nhân viên</button> : undefined} />
      <div className="page">
        {me?.plan && <div className="small muted">Gói {PLAN_NAME[me.plan]}: {used}/{me.member_limit} thành viên{me.role === 'owner' && <> · <Link to="/upgrade">Nâng cấp gói</Link></>}</div>}
        {['owner', 'admin', 'hr'].includes(me?.role || '') && <JoinCodeCard />}
        <input placeholder="Tìm theo tên / SĐT" value={search} onChange={(e) => setSearch(e.target.value)} />
        <ErrorBox error={error} />
        {loading && !data && <Loading />}
        {pending.length > 0 && (
          <>
            <div className="section-title">Chờ nhân sự kiểm duyệt ({pending.length})</div>
            {pending.map((m: any) => (
              <Card key={m.id} className="pinned" onClick={() => setReview(m)}>
                <div className="row"><Avatar userId={m.user_id} name={m.name} has={m.has_avatar} /><div style={{ flex: 1 }}><b>{m.name}</b><div className="small muted">{m.phone} · đề nghị bởi {m.added_by_name || '—'}</div></div><Badge tone="amber">Chờ duyệt</Badge></div>
              </Card>
            ))}
          </>
        )}
        <div className="row" style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <div className="section-title" style={{ flex: 1 }}>Thành viên ({active.length})</div>
          <div className="seg" style={{ margin: 0 }}><button className={by === 'tier' ? 'on' : ''} onClick={() => setBy('tier')}>Theo tầng chức vụ</button><button className={by === 'dept' ? 'on' : ''} onClick={() => setBy('dept')}>Theo phòng ban</button></div>
        </div>
        {groupsOf(active).map(([key, g]) => (
          <div key={key}>
            <button className="grp-head" onClick={() => setClosed({ ...closed, [key]: !closed[key] })} aria-expanded={!closed[key]}>
              <Icon name={closed[key] ? 'chevron' : 'down'} size={18} /><b>{g.label}</b><span className="n">{g.items.length} người</span>
            </button>
            {!closed[key] && g.items.map((m: any) => (
          <Card key={m.id} onClick={() => canManage ? setEdit(m) : undefined}>
            <div className="row">
              <Avatar userId={m.user_id} name={m.name} has={m.has_avatar} />
              <div style={{ flex: 1, minWidth: 0 }}><b>{m.name}</b><div className="small muted">{m.position_name ? `T${m.tier} ${m.position_name}` : m.title || '—'}{by === 'tier' && m.department_name ? ` · ${m.department_name}` : ''}{by === 'dept' && m.tier ? ` · tầng ${m.tier}` : ''}{hr && m.phone ? ` · ${m.phone}` : ''}</div></div>
              <Badge tone="blue">{ROLE[m.role]}</Badge>
            </div>
            <div className="chip-row">
              {m.user_status === 'invited' && <Badge tone="amber">Chưa kích hoạt (chờ đăng ký bằng SĐT)</Badge>}
              {m.user_status === 'locked' && <Badge tone="red">Bị khóa</Badge>}
              {m.status === 'inactive' && <Badge tone="gray">Ngừng hoạt động</Badge>}
              <span className="small">Cấp trên: {m.supervisor_name || '—'}</span>
              <Link className="small" to={`/people/${m.user_id}`} onClick={(e) => e.stopPropagation()}>Xem hồ sơ</Link>
            </div>
          </Card>
            ))}
          </div>
        ))}
      </div>
      <Sheet open={!!edit} onClose={() => setEdit(null)} title={edit?.name || ''}>
        {edit && admin && <MemberForm m={edit} roles={roles} members={active} depts={depts.data || []} onDone={() => { setEdit(null); reload(); }} />}
        {edit && !admin && <div className="small muted">{edit.position_name ? `Tầng ${edit.tier} · ${edit.position_name}` : edit.title}{edit.department_name ? ` · ${edit.department_name}` : ''}</div>}
        {edit && tier <= 5 && edit.status === 'active' && <LeaderAssign m={edit} deptId={deptScoped ? myDept : null} onDone={() => { setEdit(null); reload(); }} />}
        {edit && (hr || tier <= 4) && edit.role !== 'owner' && edit.status === 'active' && edit.id !== me?.member_id && (
          <>
            <div className="section-title">Quyết định nhân sự</div>
            <div className="actions">
              <button className="btn" onClick={() => setDecision({ m: edit, type: 'transfer' })}><Icon name="transfer" size={18} />Điều chuyển</button>
              <button className="btn" onClick={() => setDecision({ m: edit, type: 'promotion' })}><Icon name="promote" size={18} />Thăng chức</button>
              <button className="btn danger" onClick={() => setDecision({ m: edit, type: 'termination' })}><Icon name="terminate" size={18} />Thôi việc</button>
            </div>
            <Note>Nhân viên nhận quyết định trên app, bàn giao việc trước hạn; chỉ khi quản lý xác nhận bàn giao, quyết định mới có hiệu lực và người đó mới nhận việc mới.</Note>
          </>
        )}
      </Sheet>
      <Sheet open={!!decision} onClose={() => setDecision(null)} title={decision ? `${DECISION_TYPE[decision.type]}: ${decision.m.name}` : ''}>
        {decision && <DecisionForm m={decision.m} type={decision.type} members={active} depts={depts.data || []} onDone={(id) => { setDecision(null); setEdit(null); nav(`/decisions/${id}`); }} />}
      </Sheet>
      <Sheet open={invite} onClose={() => setInvite(false)} title="Thêm thành viên bằng số điện thoại">
        {invite && <InviteForm roles={admin ? roles : { employee: ROLE.employee }} members={active} depts={depts.data || []} lockDept={deptScoped ? myDept : null} myTier={admin ? 2 : tier} onDone={() => reload()} />}
      </Sheet>
      <Sheet open={!!review} onClose={() => setReview(null)} title="Kiểm duyệt thành viên">
        {review && <ReviewForm m={review} canReview={['owner', 'admin', 'hr'].includes(me?.role || '')} onDone={() => { setReview(null); reload(); }} />}
      </Sheet>
    </>
  );
}

function ReviewForm({ m, canReview, onDone }: { m: any; canReview: boolean; onDone: () => void }) {
  const [note, setNote] = useState('');
  const a = useAction();
  return (
    <>
      <div className="row" style={{ display: 'flex', gap: 10, alignItems: 'center' }}><Avatar userId={m.user_id} name={m.name} has={m.has_avatar} size="lg" /><div><b>{m.name}</b><div className="small muted">{m.phone}</div><div className="small">Đề nghị bởi {m.added_by_name}{m.hr_note ? ` · ${m.hr_note}` : ''}</div></div></div>
      <Link className="btn block" style={{ margin: '10px 0' }} to={`/people/${m.user_id}`}>📄 Xem hồ sơ xin việc</Link>
      {canReview ? (
        <>
          <Field label="Ghi chú (bắt buộc khi từ chối)"><textarea value={note} onChange={(e) => setNote(e.target.value)} /></Field>
          <ErrorBox error={a.error} />
          <div className="actions">
            <button className="btn primary" disabled={a.busy} onClick={() => a.run(async () => { await post(`/company/members/${m.id}/hr-review`, { decision: 'approve', note: note || undefined }); onDone(); })}><Icon name="check" size={16} />Duyệt</button>
            <button className="btn danger" disabled={a.busy} onClick={() => a.run(async () => { await post(`/company/members/${m.id}/hr-review`, { decision: 'reject', note }); onDone(); })}>Từ chối</button>
          </div>
        </>
      ) : <div className="alert info small">Chỉ thành viên vai trò Quản lý nhân sự (hoặc Chủ doanh nghiệp/Quản trị) được kiểm duyệt.</div>}
    </>
  );
}

/** Chọn chức danh theo danh mục (tài liệu phân cấp tầng 3–7): hiện vai trò & nhiệm vụ của chức danh. */
export function TitleSelect({ value, onChange, tier, onTier }: { value: string; onChange: (v: string) => void; tier?: number | null; onTier?: (t: number) => void }) {
  const jt = useLoad(() => get('/company/job-titles'), []);
  const [custom, setCustom] = useState(false);
  const all: any[] = jt.data?.titles || [];
  const list = tier ? all.filter((t) => t.tier === tier || t.title === value) : all;
  const groups = [...new Set(list.map((t) => t.group))];
  const cur = all.find((t) => t.title === value);
  const known = !value || !!cur;
  return (
    <Field label="Chức danh" hint={tier ? `Gợi ý theo tầng ${tier} của chức vụ đã chọn` : undefined}>
      {custom || !known ? <div style={{ display: 'flex', gap: 6 }}><input value={value} onChange={(e) => onChange(e.target.value)} placeholder="Nhập chức danh khác" /><button type="button" className="btn sm" onClick={() => { setCustom(false); onChange(''); }}>Danh mục</button></div>
        : <select value={value} onChange={(e) => { if (e.target.value === '__custom') { setCustom(true); onChange(''); return; } onChange(e.target.value); const t = all.find((x) => x.title === e.target.value); if (t && onTier) onTier(t.tier); }}>
          <option value="">— Chọn chức danh —</option>
          {groups.map((g) => <optgroup key={g} label={g}>{list.filter((t) => t.group === g).map((t) => <option key={g + t.title} value={t.title}>{t.title}</option>)}</optgroup>)}
          <option value="__custom"><Icon name="plus" size={16} />Chức danh khác…</option>
        </select>}
      {cur && <div className="small" style={{ marginTop: 4, background: 'var(--surface-2)', padding: '6px 8px', borderRadius: 8 }}><b>Vai trò & nhiệm vụ:</b> {cur.duties} <span className="muted">· Tầng {cur.tier}</span></div>}
    </Field>
  );
}

/** Phòng ban → Bộ phận → Nhóm. */
function OrgPicker({ depts, f, up, lockDept }: { depts: any[]; f: any; up: (p: any) => void; lockDept?: string | null }) {
  const groups = useLoad(() => get('/groups?scope=all'), []);
  const d = depts.find((x) => x.id === f.departmentId);
  const units: any[] = d?.units || [];
  const grp = (groups.data || []).filter((g: any) => g.department_id === f.departmentId && (!f.unitId || g.unit_id === f.unitId || (!g.unit_id && !f.unitId)));
  return (
    <>
      <Field label="Phòng ban" required={!!lockDept} hint={lockDept ? 'Tầng 5 chỉ thêm nhân viên vào phòng ban của mình' : undefined}>
        {lockDept ? <input value={depts.find((x) => x.id === lockDept)?.name || ''} disabled /> : <Select value={f.departmentId} onChange={(v) => up({ departmentId: v, unitId: '', groupId: '' })} options={depts.map((x) => [x.id, x.name])} placeholder="— Chọn phòng ban —" />}
      </Field>
      {d?.description && <div className="small muted" style={{ marginTop: -6, marginBottom: 6 }}>{d.description}</div>}
      <div className="grid2">
        <Field label="Bộ phận"><Select value={f.unitId || ''} onChange={(v) => up({ unitId: v, groupId: '' })} options={units.filter((u) => u.active !== false).map((u) => [u.id, u.name])} placeholder={units.length ? '— Không thuộc bộ phận —' : 'Phòng chưa có bộ phận'} /></Field>
        {'groupId' in f && <Field label="Nhóm"><Select value={f.groupId} onChange={(v) => up({ groupId: v })} options={grp.map((g: any) => [g.id, g.name])} placeholder={grp.length ? '— Chưa xếp nhóm —' : 'Chưa có nhóm'} /></Field>}
      </div>
    </>
  );
}

function InviteForm({ roles, members, depts, lockDept, myTier, onDone }: { roles: Record<string, string>; members: any[]; depts: any[]; lockDept: string | null; myTier: number; onDone: () => void }) {
  void roles;
  const [f, setF] = useState<any>({ phone: '', name: '', title: '', departmentId: lockDept || '', unitId: '', supervisorMemberId: '', groupId: '', positionId: '', jobGrade: '' });
  const positions = useLoad(() => get('/company/positions'), []);
  const posList = (positions.data?.positions || []).filter((p: any) => p.active && p.tier > myTier);
  const posOpts = posList.map((p: any) => [p.id, `Tầng ${p.tier} · ${p.name}`] as [string, string]);
  const tier = posList.find((p: any) => p.id === f.positionId)?.tier ?? null;
  const [msg, setMsg] = useState<string | null>(null);
  const a = useAction();
  const up = (p: any) => setF((x: any) => ({ ...x, ...p }));
  const gradeDesc = positions.data?.grade_desc || {};
  return (
    <>
      <Field label="Số điện thoại" required><input type="tel" inputMode="tel" value={f.phone} onChange={(e) => up({ phone: e.target.value })} /></Field>
      <Field label="Họ và tên đầy đủ" hint="Bắt buộc nếu số này chưa có tài khoản"><input value={f.name} onChange={(e) => up({ name: e.target.value })} /></Field>
      <div className="grid2">
        <Field label="Chức vụ (tầng)" required><Select value={f.positionId} onChange={(v) => up({ positionId: v })} options={posOpts} placeholder="— Chọn —" /></Field>
        <Field label="Cấp bậc nghề nghiệp"><Select value={f.jobGrade} onChange={(v) => up({ jobGrade: v })} options={(positions.data?.job_grades || []).map((g: string) => [g, g])} placeholder="— Không —" /></Field>
      </div>
      {f.jobGrade && gradeDesc[f.jobGrade] && <div className="small muted" style={{ marginTop: -6, marginBottom: 6 }}>{gradeDesc[f.jobGrade]}</div>}
      <TitleSelect value={f.title} onChange={(v) => up({ title: v })} tier={tier} />
      <OrgPicker depts={depts} f={f} up={up} lockDept={lockDept} />
      <Field label="Cấp trên trực tiếp"><Select value={f.supervisorMemberId} onChange={(v) => up({ supervisorMemberId: v })} options={members.filter((x) => !f.departmentId || x.department_id === f.departmentId || (x.tier && x.tier <= 4)).map((x) => [x.id, `${x.name}${x.position_name ? ` (${x.position_name})` : ''}`])} placeholder="— Không —" /></Field>
      <Note>Vai trò hệ thống được xác định tự động theo chức vụ (tầng) và phòng ban.</Note>
      {msg && <div className="alert ok small">{msg}</div>}
      <ErrorBox error={a.error} />
      <button className="btn primary block" disabled={a.busy || !f.phone || !f.positionId} onClick={() => a.run(async () => {
        const r = await post('/company/members', { phone: f.phone, name: f.name || undefined, title: f.title || undefined, departmentId: f.departmentId || undefined, unitId: f.unitId || undefined,
          supervisorMemberId: f.supervisorMemberId || undefined, groupId: f.groupId || undefined, positionId: f.positionId || undefined, jobGrade: f.jobGrade || undefined });
        setMsg(`Đã ${r.status === 'pending_hr' ? 'gửi nhân sự duyệt' : 'thêm'} ${r.name}.${r.message ? ' ' + r.message : ''}`);
        setF({ ...f, phone: '', name: '' }); onDone();
      })}>Thêm</button>
    </>
  );
}

function MemberForm({ m, roles, members, depts, onDone }: { m: any; roles: Record<string, string>; members: any[]; depts: any[]; onDone: () => void }) {
  const [f, setF] = useState<any>({
    role: m.role, title: m.title || '', departmentId: m.department_id || '', supervisorMemberId: m.supervisor_member_id || '',
    canCrossGroupAssign: !!m.can_cross_group_assign, status: m.status, jobRoleId: m.job_role_id || '', positionId: m.position_id || '', jobGrade: m.job_grade || '', unitId: m.unit_id || '',
  });
  const [adv, setAdv] = useState(false);
  const jobRoles = useLoad(() => get('/company/job-roles'), []);
  const positions = useLoad(() => get('/company/positions'), []);
  const a = useAction();
  const up = (p: any) => setF((x: any) => ({ ...x, ...p }));
  return (
    <>
      <p className="small muted">{m.phone} · {MEMBER_STATUS[m.status]}</p>
      <div className="grid2">
        <Field label="Chức vụ (tầng quản lý)" hint="Quyết định quyền giao việc, lập/duyệt đơn hàng"><Select value={f.positionId} onChange={(v) => up({ positionId: v })}
          options={(positions.data?.positions || []).filter((p: any) => p.active || p.id === f.positionId).map((p: any) => [p.id, `T${p.tier} · ${p.name}`])} placeholder="— Theo vai trò —" /></Field>
        <Field label="Cấp bậc nghề nghiệp"><Select value={f.jobGrade} onChange={(v) => up({ jobGrade: v })} options={(positions.data?.job_grades || []).map((g: string) => [g, g])} placeholder="— Không —" /></Field>
      </div>
      <TitleSelect value={f.title} onChange={(v) => up({ title: v })} tier={(positions.data?.positions || []).find((p: any) => p.id === f.positionId)?.tier ?? null} />
      <Field label="Mô tả công việc (vai trò)" hint="Dùng để phân loại việc trong vai trò / ngoài vai trò"><Select value={f.jobRoleId} onChange={(v) => up({ jobRoleId: v })} options={(jobRoles.data || []).filter((r: any) => r.active).map((r: any) => [r.id, r.name])} placeholder="— Chưa gán —" /></Field>
      <OrgPicker depts={depts} f={f} up={up} />
      <Field label="Cấp trên trực tiếp" hint="Dùng cho duyệt nghỉ phép, chuyển cấp và khiếu nại"><Select value={f.supervisorMemberId} onChange={(v) => up({ supervisorMemberId: v })} options={members.filter((x) => x.id !== m.id).map((x) => [x.id, `${x.name} (${ROLE[x.role]})`])} placeholder="— Không —" /></Field>
      <label className="check"><input type="checkbox" checked={f.canCrossGroupAssign} onChange={(e) => up({ canCrossGroupAssign: e.target.checked })} /> Được giao việc chéo nhóm</label>
      <Field label="Trạng thái"><Select value={f.status} onChange={(v) => up({ status: v })} options={{ active: 'Hoạt động', inactive: 'Ngừng hoạt động' }} /></Field>
      <button type="button" className="btn sm" onClick={() => setAdv(!adv)}><Icon name={adv ? 'down' : 'chevron'} size={16} />Nâng cao</button>
      {adv && <Field label="Vai trò hệ thống" hint="Chỉ dùng khi cần cấp quyền quản trị đặc biệt — bình thường xác định theo chức vụ"><Select value={f.role} onChange={(v) => up({ role: v })} options={roles} /></Field>}
      <ErrorBox error={a.error} />
      <button className="btn primary block" disabled={a.busy} onClick={() => a.run(async () => {
        await patch(`/company/members/${m.id}`, { role: f.role, title: f.title || null, departmentId: f.departmentId || null, supervisorMemberId: f.supervisorMemberId || null, canCrossGroupAssign: f.canCrossGroupAssign, status: f.status, jobRoleId: f.jobRoleId || null, positionId: f.positionId || null, jobGrade: f.jobGrade || null, unitId: f.unitId || null });
        onDone();
      })}>Lưu</button>
      <div className="actions">
        <Link className="btn" to={`/people/${m.user_id}`}>Xem hồ sơ</Link>
        <button className="btn danger" disabled={a.busy} onClick={() => a.run(async () => { await patch(`/company/members/${m.id}`, { lockUser: m.user_status !== 'locked' }); onDone(); })}>
          {m.user_status === 'locked' ? 'Mở khóa tài khoản' : 'Khóa tài khoản & thu hồi phiên'}
        </button>
      </div>
    </>
  );
}

export function DecisionForm({ m, type, members, depts, onDone }: { m: any; type: string; members: any[]; depts: any[]; onDone: (id: string) => void }) {
  const groups = useLoad(() => get('/groups'), []);
  const d3 = new Date(Date.now() + 3 * 86400000); d3.setHours(17, 0, 0, 0);
  const [f, setF] = useState<any>({ effectiveDate: isoDate(new Date(Date.now() + 7 * 86400000)), handoverDeadline: toLocalInput(d3), newRole: '', newTitle: '', newGroupId: '',
    removeFromGroups: true, newDepartmentId: '', newSupervisorId: '', handoverReceiverId: '', confirmerId: '', reason: '', newPositionId: '' });
  const positions = useLoad(() => get('/company/positions'), []);
  const posField = <Field label="Chức vụ mới (tầng)"><Select value={f.newPositionId} onChange={(v) => up({ newPositionId: v })} options={(positions.data?.positions || []).filter((p: any) => p.active).map((p: any) => [p.id, `Tầng ${p.tier} · ${p.name}`])} placeholder="— Giữ nguyên —" /></Field>;
  const a = useAction();
  const up = (p: any) => setF((x: any) => ({ ...x, ...p }));
  const others = members.filter((x) => x.id !== m.id && x.status === 'active');
  return (
    <>
      <div className="alert info small">Hiện tại: {m.title || ROLE[m.role]}{m.department_name ? ` · ${m.department_name}` : ''}. Cấp trên: {m.supervisor_name || '—'}</div>
      <div className="grid2">
        <Field label="Ngày hiệu lực" required><input type="date" value={f.effectiveDate} onChange={(e) => up({ effectiveDate: e.target.value })} /></Field>
        <Field label="Hạn bàn giao" required><input type="datetime-local" value={f.handoverDeadline} onChange={(e) => up({ handoverDeadline: e.target.value })} /></Field>
      </div>
      {type === 'promotion' && (
        <>
          {posField}
          <Field label="Vai trò mới"><Select value={f.newRole} onChange={(v) => up({ newRole: v })} options={Object.fromEntries(Object.entries(ROLE).filter(([k]) => k !== 'owner'))} placeholder="— Giữ nguyên —" /></Field>
          <Field label="Chức danh mới"><input value={f.newTitle} onChange={(e) => up({ newTitle: e.target.value })} placeholder="VD: Tổ trưởng kho" /></Field>
        </>
      )}
      {type === 'transfer' && (
        <>
          <Field label="Chuyển tới nhóm"><Select value={f.newGroupId} onChange={(v) => up({ newGroupId: v })} options={(groups.data || []).map((g: any) => [g.id, g.name])} placeholder="— Không đổi nhóm —" /></Field>
          <label className="check"><input type="checkbox" checked={f.removeFromGroups} onChange={(e) => up({ removeFromGroups: e.target.checked })} /> Rời các nhóm hiện tại</label>
          {posField}
          <Field label="Phòng ban mới"><Select value={f.newDepartmentId} onChange={(v) => up({ newDepartmentId: v })} options={depts.map((d) => [d.id, d.name])} placeholder="— Không đổi —" /></Field>
          <Field label="Cấp trên mới"><Select value={f.newSupervisorId} onChange={(v) => up({ newSupervisorId: v })} options={others.map((x) => [x.id, `${x.name} (${ROLE[x.role]})`])} placeholder="— Không đổi —" /></Field>
          <Field label="Chức danh mới"><input value={f.newTitle} onChange={(e) => up({ newTitle: e.target.value })} /></Field>
        </>
      )}
      <Field label="Người nhận bàn giao mặc định" hint="Có thể chọn riêng từng việc khi bàn giao"><Select value={f.handoverReceiverId} onChange={(v) => up({ handoverReceiverId: v })} options={others.map((x) => [x.id, x.name])} placeholder="— Để nhân viên chọn —" /></Field>
      <Field label="Người xác nhận bàn giao" hint="Mặc định: cấp trên trực tiếp hoặc quản lý nhóm"><Select value={f.confirmerId} onChange={(v) => up({ confirmerId: v })} options={others.filter((x) => x.role !== 'employee').map((x) => [x.id, x.name])} placeholder="— Mặc định —" /></Field>
      <Field label="Lý do / căn cứ" required><textarea value={f.reason} onChange={(e) => up({ reason: e.target.value })} /></Field>
      <ErrorBox error={a.error} />
      <button className={`btn block ${type === 'termination' ? 'danger' : 'primary'}`} disabled={a.busy} onClick={() => a.run(async () => {
        const r = await post('/decisions', { memberId: m.id, decisionType: type, effectiveDate: f.effectiveDate, handoverDeadline: fromLocalInput(f.handoverDeadline),
          newRole: f.newRole || undefined, newTitle: f.newTitle || undefined, newGroupId: f.newGroupId || undefined, removeFromGroups: f.removeFromGroups,
          newDepartmentId: f.newDepartmentId || undefined, newSupervisorId: f.newSupervisorId || undefined, handoverReceiverId: f.handoverReceiverId || undefined,
          confirmerId: f.confirmerId || undefined, reason: f.reason, newPositionId: f.newPositionId || undefined });
        onDone(r.id);
      })}>Ban hành quyết định</button>
    </>
  );
}

const TIER_NAME: Record<string, string> = { '3': 'Điều hành', '4': 'Quản lý cấp cao', '5': 'Quản lý trung gian', '6': 'Quản lý trực tiếp', '7': 'Nhân sự thực thi' };

/** Tầng 5 chỉ định trưởng nhóm cho các nhóm thuộc đơn vị mình quản lý (tầng 3–4: mọi nhóm). */
function LeaderAssign({ m, deptId, onDone }: { m: any; deptId: string | null; onDone: () => void }) {
  const groups = useLoad(() => get('/groups'), []);
  const [g, setG] = useState('');
  const a = useAction();
  const list = (groups.data || []).filter((x: any) => x.assignable && (!deptId || x.department_id === deptId));
  if (!list.length) return null;
  return (
    <div className="card" style={{ marginTop: 10 }}>
      <b className="small">Chỉ định trưởng nhóm</b>
      <div className="small muted">Nhóm hiện tại: {list.filter((x: any) => x.leader_id === m.id).map((x: any) => x.name).join(', ') || 'chưa là trưởng nhóm'}</div>
      <div style={{ display: 'flex', gap: 6, marginTop: 6 }}>
        <Select value={g} onChange={setG} options={list.map((x: any) => [x.id, `${x.name}${x.leader_name ? ` (hiện: ${x.leader_name})` : ''}`])} placeholder="— Chọn nhóm —" />
        <button className="btn primary" disabled={a.busy || !g} onClick={() => a.run(async () => {
          await post(`/groups/${g}/members`, { memberIds: [m.id] }).catch(() => {});
          await patch(`/groups/${g}`, { leaderMemberId: m.id }); onDone();
        })}>Chỉ định</button>
      </div>
      <ErrorBox error={a.error} />
    </div>
  );
}
