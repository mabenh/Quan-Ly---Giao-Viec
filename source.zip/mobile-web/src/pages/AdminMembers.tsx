import { useState } from 'react';
import { Link } from 'react-router-dom';
import { get, patch, post } from '../api';
import { isAdminRole, useAuth } from '../auth';
import { Avatar, Badge, Card, ErrorBox, Field, Header, Loading, Select, Sheet, useAction, useLoad } from '../ui';
import { DECISION_TYPE, MEMBER_STATUS, PLAN_NAME, ROLE, isoDate, toLocalInput, fromLocalInput } from '../labels';
import { Icon } from '../icons';
import { useNavigate } from 'react-router-dom';

export default function AdminMembers() {
  const { me } = useAuth();
  const [search, setSearch] = useState('');
  const { data, error, loading, reload } = useLoad(() => get(`/company/members?q=${encodeURIComponent(search)}`), [search]);
  const depts = useLoad(() => get('/company/departments'), []);
  const [edit, setEdit] = useState<any>(null);
  const [invite, setInvite] = useState(false);
  const [review, setReview] = useState<any>(null);
  const [decision, setDecision] = useState<{ m: any; type: string } | null>(null);
  const nav = useNavigate();
  const hr = ['owner', 'admin', 'hr'].includes(me?.role || '');
  const admin = isAdminRole(me?.role);
  const roles = me?.role === 'owner' ? ROLE : Object.fromEntries(Object.entries(ROLE).filter(([k]) => k !== 'owner'));
  const pending = (data || []).filter((m: any) => m.status === 'pending_hr');
  const active = (data || []).filter((m: any) => m.status !== 'pending_hr');
  const used = (data || []).filter((m: any) => ['active', 'pending_hr'].includes(m.status)).length;
  return (
    <>
      <Header title="Thành viên" back="/me" right={<button className="btn primary sm" onClick={() => setInvite(true)}>＋ Thêm bằng SĐT</button>} />
      <div className="page">
        {me?.plan && <div className="small muted">Gói {PLAN_NAME[me.plan]}: {used}/{me.member_limit} thành viên{me.role === 'owner' && <> · <Link to="/upgrade">Nâng cấp gói</Link></>}</div>}
        <input placeholder="Tìm theo tên / SĐT" value={search} onChange={(e) => setSearch(e.target.value)} />
        <ErrorBox error={error} />
        {loading && !data && <Loading />}
        {pending.length > 0 && (
          <>
            <div className="section-title">Chờ nhân sự kiểm duyệt ({pending.length})</div>
            {pending.map((m: any) => (
              <Card key={m.id} className="pinned" onClick={() => setReview(m)}>
                <div className="row"><Avatar userId={m.user_id} name={m.name} has={m.has_avatar} /><div style={{ flex: 1 }}><b>{m.name}</b><div className="small muted">{m.phone} · đề nghị bởi {m.added_by_name || '—'}</div></div><Badge tone="amber">Chờ duyệt</Badge></div>
              </Card>
            ))}
          </>
        )}
        <div className="section-title">Thành viên ({active.length})</div>
        {active.map((m: any) => (
          <Card key={m.id} onClick={() => (admin || hr) ? setEdit(m) : undefined}>
            <div className="row">
              <Avatar userId={m.user_id} name={m.name} has={m.has_avatar} />
              <div style={{ flex: 1, minWidth: 0 }}><b>{m.name}</b><div className="small muted">{m.phone || m.email} · {m.title || '—'}{m.department_name ? ` · ${m.department_name}` : ''}</div></div>
              <Badge tone="blue">{ROLE[m.role]}</Badge>
            </div>
            <div className="chip-row">
              {m.user_status === 'invited' && <Badge tone="amber">Chưa kích hoạt (chờ đăng ký bằng SĐT)</Badge>}
              {m.user_status === 'locked' && <Badge tone="red">Bị khóa</Badge>}
              {m.status === 'inactive' && <Badge tone="gray">Ngừng hoạt động</Badge>}
              <span className="small">Cấp trên: {m.supervisor_name || '—'}</span>
              <Link className="small" to={`/people/${m.user_id}`} onClick={(e) => e.stopPropagation()}>Xem hồ sơ</Link>
            </div>
          </Card>
        ))}
      </div>
      <Sheet open={!!edit} onClose={() => setEdit(null)} title={edit?.name || ''}>
        {edit && admin && <MemberForm m={edit} roles={roles} members={active} depts={depts.data || []} onDone={() => { setEdit(null); reload(); }} />}
        {edit && hr && edit.role !== 'owner' && edit.status === 'active' && edit.id !== me?.member_id && (
          <>
            <div className="section-title">Quyết định nhân sự</div>
            <div className="actions">
              <button className="btn" onClick={() => setDecision({ m: edit, type: 'transfer' })}><Icon name="transfer" size={18} />Điều chuyển</button>
              <button className="btn" onClick={() => setDecision({ m: edit, type: 'promotion' })}><Icon name="promote" size={18} />Thăng chức</button>
              <button className="btn danger" onClick={() => setDecision({ m: edit, type: 'termination' })}><Icon name="terminate" size={18} />Thôi việc</button>
            </div>
            <p className="small muted">Nhân viên nhận quyết định trên app, bàn giao việc trước hạn; chỉ khi quản lý xác nhận bàn giao, quyết định mới có hiệu lực và người đó mới nhận việc mới.</p>
          </>
        )}
      </Sheet>
      <Sheet open={!!decision} onClose={() => setDecision(null)} title={decision ? `${DECISION_TYPE[decision.type]}: ${decision.m.name}` : ''}>
        {decision && <DecisionForm m={decision.m} type={decision.type} members={active} depts={depts.data || []} onDone={(id) => { setDecision(null); setEdit(null); nav(`/decisions/${id}`); }} />}
      </Sheet>
      <Sheet open={invite} onClose={() => setInvite(false)} title="Thêm thành viên bằng số điện thoại">
        {invite && <InviteForm roles={admin ? roles : { employee: ROLE.employee }} members={active} depts={depts.data || []} onDone={() => reload()} />}
      </Sheet>
      <Sheet open={!!review} onClose={() => setReview(null)} title="Kiểm duyệt thành viên">
        {review && <ReviewForm m={review} canReview={['owner', 'admin', 'hr'].includes(me?.role || '')} onDone={() => { setReview(null); reload(); }} />}
      </Sheet>
    </>
  );
}

function ReviewForm({ m, canReview, onDone }: { m: any; canReview: boolean; onDone: () => void }) {
  const [note, setNote] = useState('');
  const a = useAction();
  return (
    <>
      <div className="row" style={{ display: 'flex', gap: 10, alignItems: 'center' }}><Avatar userId={m.user_id} name={m.name} has={m.has_avatar} size="lg" /><div><b>{m.name}</b><div className="small muted">{m.phone}</div><div className="small">Đề nghị bởi {m.added_by_name}{m.hr_note ? ` · ${m.hr_note}` : ''}</div></div></div>
      <Link className="btn block" style={{ margin: '10px 0' }} to={`/people/${m.user_id}`}>📄 Xem hồ sơ xin việc</Link>
      {canReview ? (
        <>
          <Field label="Ghi chú (bắt buộc khi từ chối)"><textarea value={note} onChange={(e) => setNote(e.target.value)} /></Field>
          <ErrorBox error={a.error} />
          <div className="actions">
            <button className="btn primary" disabled={a.busy} onClick={() => a.run(async () => { await post(`/company/members/${m.id}/hr-review`, { decision: 'approve', note: note || undefined }); onDone(); })}>✔ Duyệt</button>
            <button className="btn danger" disabled={a.busy} onClick={() => a.run(async () => { await post(`/company/members/${m.id}/hr-review`, { decision: 'reject', note }); onDone(); })}>Từ chối</button>
          </div>
        </>
      ) : <div className="alert info small">Chỉ thành viên vai trò Quản lý nhân sự (hoặc Chủ doanh nghiệp/Quản trị) được kiểm duyệt.</div>}
    </>
  );
}

function InviteForm({ roles, members, depts, onDone }: { roles: Record<string, string>; members: any[]; depts: any[]; onDone: () => void }) {
  const [f, setF] = useState<any>({ phone: '', name: '', role: 'employee', title: '', departmentId: '', supervisorMemberId: '' });
  const [msg, setMsg] = useState<string | null>(null);
  const a = useAction();
  const up = (p: any) => setF((x: any) => ({ ...x, ...p }));
  return (
    <>
      <Field label="Số điện thoại" required><input type="tel" inputMode="tel" value={f.phone} onChange={(e) => up({ phone: e.target.value })} /></Field>
      <Field label="Họ và tên đầy đủ" hint="Bắt buộc nếu số này chưa có tài khoản"><input value={f.name} onChange={(e) => up({ name: e.target.value })} /></Field>
      <Field label="Vai trò"><Select value={f.role} onChange={(v) => up({ role: v })} options={roles} /></Field>
      <Field label="Chức danh"><input value={f.title} onChange={(e) => up({ title: e.target.value })} /></Field>
      <Field label="Bộ phận"><Select value={f.departmentId} onChange={(v) => up({ departmentId: v })} options={depts.map((d) => [d.id, d.name])} placeholder="— Không —" /></Field>
      <Field label="Cấp trên trực tiếp"><Select value={f.supervisorMemberId} onChange={(v) => up({ supervisorMemberId: v })} options={members.map((x) => [x.id, `${x.name} (${ROLE[x.role]})`])} placeholder="— Không —" /></Field>
      {msg && <div className="alert ok small">{msg}</div>}
      <ErrorBox error={a.error} />
      <button className="btn primary block" disabled={a.busy || !f.phone} onClick={() => a.run(async () => {
        const r = await post('/company/members', { phone: f.phone, name: f.name || undefined, role: f.role, title: f.title || undefined, departmentId: f.departmentId || undefined, supervisorMemberId: f.supervisorMemberId || undefined });
        setMsg(`Đã ${r.status === 'pending_hr' ? 'gửi nhân sự duyệt' : 'thêm'} ${r.name}.${r.message ? ' ' + r.message : ''}`);
        setF({ ...f, phone: '', name: '' }); onDone();
      })}>Thêm</button>
    </>
  );
}

function MemberForm({ m, roles, members, depts, onDone }: { m: any; roles: Record<string, string>; members: any[]; depts: any[]; onDone: () => void }) {
  const [f, setF] = useState<any>({
    role: m.role, title: m.title || '', departmentId: m.department_id || '', supervisorMemberId: m.supervisor_member_id || '',
    canCrossGroupAssign: !!m.can_cross_group_assign, status: m.status,
  });
  const a = useAction();
  const up = (p: any) => setF((x: any) => ({ ...x, ...p }));
  return (
    <>
      <p className="small muted">{m.phone} · {MEMBER_STATUS[m.status]}</p>
      <Field label="Vai trò" hint="Nâng cấp thành viên lên Quản lý / Quản lý nhân sự / Quản trị"><Select value={f.role} onChange={(v) => up({ role: v })} options={roles} /></Field>
      <Field label="Chức danh"><input value={f.title} onChange={(e) => up({ title: e.target.value })} /></Field>
      <Field label="Bộ phận"><Select value={f.departmentId} onChange={(v) => up({ departmentId: v })} options={depts.map((d) => [d.id, d.name])} placeholder="— Không —" /></Field>
      <Field label="Cấp trên trực tiếp" hint="Dùng cho duyệt nghỉ phép, chuyển cấp và khiếu nại"><Select value={f.supervisorMemberId} onChange={(v) => up({ supervisorMemberId: v })} options={members.filter((x) => x.id !== m.id).map((x) => [x.id, `${x.name} (${ROLE[x.role]})`])} placeholder="— Không —" /></Field>
      <label className="check"><input type="checkbox" checked={f.canCrossGroupAssign} onChange={(e) => up({ canCrossGroupAssign: e.target.checked })} /> Được giao việc chéo nhóm</label>
      <Field label="Trạng thái"><Select value={f.status} onChange={(v) => up({ status: v })} options={{ active: 'Hoạt động', inactive: 'Ngừng hoạt động' }} /></Field>
      <ErrorBox error={a.error} />
      <button className="btn primary block" disabled={a.busy} onClick={() => a.run(async () => {
        await patch(`/company/members/${m.id}`, { role: f.role, title: f.title || null, departmentId: f.departmentId || null, supervisorMemberId: f.supervisorMemberId || null, canCrossGroupAssign: f.canCrossGroupAssign, status: f.status });
        onDone();
      })}>Lưu</button>
      <div className="actions">
        <Link className="btn" to={`/people/${m.user_id}`}>Xem hồ sơ</Link>
        <button className="btn danger" disabled={a.busy} onClick={() => a.run(async () => { await patch(`/company/members/${m.id}`, { lockUser: m.user_status !== 'locked' }); onDone(); })}>
          {m.user_status === 'locked' ? 'Mở khóa tài khoản' : 'Khóa tài khoản & thu hồi phiên'}
        </button>
      </div>
    </>
  );
}

function DecisionForm({ m, type, members, depts, onDone }: { m: any; type: string; members: any[]; depts: any[]; onDone: (id: string) => void }) {
  const groups = useLoad(() => get('/groups'), []);
  const d3 = new Date(Date.now() + 3 * 86400000); d3.setHours(17, 0, 0, 0);
  const [f, setF] = useState<any>({ effectiveDate: isoDate(new Date(Date.now() + 7 * 86400000)), handoverDeadline: toLocalInput(d3), newRole: '', newTitle: '', newGroupId: '',
    removeFromGroups: true, newDepartmentId: '', newSupervisorId: '', handoverReceiverId: '', confirmerId: '', reason: '' });
  const a = useAction();
  const up = (p: any) => setF((x: any) => ({ ...x, ...p }));
  const others = members.filter((x) => x.id !== m.id && x.status === 'active');
  return (
    <>
      <div className="alert info small">Hiện tại: {m.title || ROLE[m.role]}{m.department_name ? ` · ${m.department_name}` : ''}. Cấp trên: {m.supervisor_name || '—'}</div>
      <div className="grid2">
        <Field label="Ngày hiệu lực" required><input type="date" value={f.effectiveDate} onChange={(e) => up({ effectiveDate: e.target.value })} /></Field>
        <Field label="Hạn bàn giao" required><input type="datetime-local" value={f.handoverDeadline} onChange={(e) => up({ handoverDeadline: e.target.value })} /></Field>
      </div>
      {type === 'promotion' && (
        <>
          <Field label="Vai trò mới"><Select value={f.newRole} onChange={(v) => up({ newRole: v })} options={Object.fromEntries(Object.entries(ROLE).filter(([k]) => k !== 'owner'))} placeholder="— Giữ nguyên —" /></Field>
          <Field label="Chức danh mới"><input value={f.newTitle} onChange={(e) => up({ newTitle: e.target.value })} placeholder="VD: Tổ trưởng kho" /></Field>
        </>
      )}
      {type === 'transfer' && (
        <>
          <Field label="Chuyển tới nhóm"><Select value={f.newGroupId} onChange={(v) => up({ newGroupId: v })} options={(groups.data || []).map((g: any) => [g.id, g.name])} placeholder="— Không đổi nhóm —" /></Field>
          <label className="check"><input type="checkbox" checked={f.removeFromGroups} onChange={(e) => up({ removeFromGroups: e.target.checked })} /> Rời các nhóm hiện tại</label>
          <Field label="Bộ phận mới"><Select value={f.newDepartmentId} onChange={(v) => up({ newDepartmentId: v })} options={depts.map((d) => [d.id, d.name])} placeholder="— Không đổi —" /></Field>
          <Field label="Cấp trên mới"><Select value={f.newSupervisorId} onChange={(v) => up({ newSupervisorId: v })} options={others.map((x) => [x.id, `${x.name} (${ROLE[x.role]})`])} placeholder="— Không đổi —" /></Field>
          <Field label="Chức danh mới"><input value={f.newTitle} onChange={(e) => up({ newTitle: e.target.value })} /></Field>
        </>
      )}
      <Field label="Người nhận bàn giao mặc định" hint="Có thể chọn riêng từng việc khi bàn giao"><Select value={f.handoverReceiverId} onChange={(v) => up({ handoverReceiverId: v })} options={others.map((x) => [x.id, x.name])} placeholder="— Để nhân viên chọn —" /></Field>
      <Field label="Người xác nhận bàn giao" hint="Mặc định: cấp trên trực tiếp hoặc quản lý nhóm"><Select value={f.confirmerId} onChange={(v) => up({ confirmerId: v })} options={others.filter((x) => x.role !== 'employee').map((x) => [x.id, x.name])} placeholder="— Mặc định —" /></Field>
      <Field label="Lý do / căn cứ" required><textarea value={f.reason} onChange={(e) => up({ reason: e.target.value })} /></Field>
      <ErrorBox error={a.error} />
      <button className={`btn block ${type === 'termination' ? 'danger' : 'primary'}`} disabled={a.busy} onClick={() => a.run(async () => {
        const r = await post('/decisions', { memberId: m.id, decisionType: type, effectiveDate: f.effectiveDate, handoverDeadline: fromLocalInput(f.handoverDeadline),
          newRole: f.newRole || undefined, newTitle: f.newTitle || undefined, newGroupId: f.newGroupId || undefined, removeFromGroups: f.removeFromGroups,
          newDepartmentId: f.newDepartmentId || undefined, newSupervisorId: f.newSupervisorId || undefined, handoverReceiverId: f.handoverReceiverId || undefined,
          confirmerId: f.confirmerId || undefined, reason: f.reason });
        onDone(r.id);
      })}>Ban hành quyết định</button>
    </>
  );
}
