import { useState } from 'react';
import { get, patch, post } from '../api';
import { useAuth } from '../auth';
import { Badge, Card, ErrorBox, Field, Header, Loading, Select, Sheet, useAction, useLoad } from '../ui';
import { ROLE } from '../labels';

export default function AdminMembers() {
  const { me } = useAuth();
  const [search, setSearch] = useState('');
  const { data, error, loading, reload } = useLoad(() => get(`/company/members?q=${encodeURIComponent(search)}`), [search]);
  const depts = useLoad(() => get('/company/departments'), []);
  const [edit, setEdit] = useState<any>(null);
  const [invite, setInvite] = useState(false);
  const roles = me?.role === 'owner' ? ROLE : Object.fromEntries(Object.entries(ROLE).filter(([k]) => k !== 'owner'));
  return (
    <>
      <Header title="Thành viên" back="/me" right={<button className="btn primary sm" onClick={() => setInvite(true)}>＋ Mời</button>} />
      <div className="page">
        <input placeholder="Tìm theo tên/email" value={search} onChange={(e) => setSearch(e.target.value)} />
        <ErrorBox error={error} />
        {loading && !data && <Loading />}
        {data?.map((m: any) => (
          <Card key={m.id} onClick={() => setEdit(m)}>
            <div className="row"><b style={{ flex: 1 }}>{m.name}</b><Badge tone="blue">{ROLE[m.role]}</Badge>{(m.status !== 'active' || m.user_status === 'locked') && <Badge tone="red">{m.user_status === 'locked' ? 'Bị khóa' : 'Ngừng hoạt động'}</Badge>}</div>
            <div className="small muted">{m.email} · {m.title || '—'}{m.department_name ? ` · ${m.department_name}` : ''}</div>
            <div className="small">Cấp trên: {m.supervisor_name || '—'}{m.can_cross_group_assign ? ' · được giao việc chéo nhóm' : ''}</div>
          </Card>
        ))}
      </div>
      <Sheet open={!!edit} onClose={() => setEdit(null)} title={edit?.name || ''}>
        {edit && <MemberForm m={edit} roles={roles} members={data || []} depts={depts.data || []} onDone={() => { setEdit(null); reload(); }} />}
      </Sheet>
      <Sheet open={invite} onClose={() => setInvite(false)} title="Mời thành viên">
        <MemberForm roles={roles} members={data || []} depts={depts.data || []} onDone={() => { setInvite(false); reload(); }} />
      </Sheet>
    </>
  );
}

function MemberForm({ m, roles, members, depts, onDone }: { m?: any; roles: Record<string, string>; members: any[]; depts: any[]; onDone: () => void }) {
  const [f, setF] = useState<any>({
    name: m?.name || '', email: m?.email || '', role: m?.role || 'employee', title: m?.title || '', departmentId: m?.department_id || '',
    supervisorMemberId: m?.supervisor_member_id || '', canCrossGroupAssign: !!m?.can_cross_group_assign, status: m?.status || 'active',
  });
  const [temp, setTemp] = useState<string | null>(null);
  const a = useAction();
  const up = (p: any) => setF((x: any) => ({ ...x, ...p }));
  const save = () => a.run(async () => {
    const common = { role: f.role, title: f.title || undefined, departmentId: f.departmentId || null, supervisorMemberId: f.supervisorMemberId || null, canCrossGroupAssign: f.canCrossGroupAssign };
    if (m) { await patch(`/company/members/${m.id}`, { ...common, status: f.status }); onDone(); }
    else { const r = await post('/company/members', { name: f.name, email: f.email, ...common }); if (r.tempPassword) setTemp(r.tempPassword); else onDone(); }
  });
  if (temp) return (<><div className="alert ok">Đã tạo tài khoản. Mật khẩu tạm thời: <b>{temp}</b> — gửi cho nhân viên và yêu cầu đổi mật khẩu.</div><button className="btn block" onClick={onDone}>Xong</button></>);
  return (
    <>
      {!m && <><Field label="Họ tên" required><input value={f.name} onChange={(e) => up({ name: e.target.value })} /></Field><Field label="Email" required><input type="email" value={f.email} onChange={(e) => up({ email: e.target.value })} /></Field></>}
      <Field label="Vai trò"><Select value={f.role} onChange={(v) => up({ role: v })} options={roles} /></Field>
      <Field label="Chức danh"><input value={f.title} onChange={(e) => up({ title: e.target.value })} /></Field>
      <Field label="Bộ phận"><Select value={f.departmentId} onChange={(v) => up({ departmentId: v })} options={depts.map((d) => [d.id, d.name])} placeholder="— Không —" /></Field>
      <Field label="Cấp trên trực tiếp" hint="Dùng cho tuyến chuyển cấp và giải quyết khiếu nại"><Select value={f.supervisorMemberId} onChange={(v) => up({ supervisorMemberId: v })} options={members.filter((x) => x.id !== m?.id).map((x) => [x.id, `${x.name} (${ROLE[x.role]})`])} placeholder="— Không —" /></Field>
      <label className="check"><input type="checkbox" checked={f.canCrossGroupAssign} onChange={(e) => up({ canCrossGroupAssign: e.target.checked })} /> Được giao việc chéo nhóm</label>
      {m && <Field label="Trạng thái"><Select value={f.status} onChange={(v) => up({ status: v })} options={{ active: 'Hoạt động', inactive: 'Ngừng hoạt động' }} /></Field>}
      <ErrorBox error={a.error} />
      <button className="btn primary block" disabled={a.busy} onClick={save}>Lưu</button>
      {m && (
        <div className="actions">
          <button className="btn danger" disabled={a.busy} onClick={() => a.run(async () => { await patch(`/company/members/${m.id}`, { lockUser: m.user_status !== 'locked' }); onDone(); })}>
            {m.user_status === 'locked' ? 'Mở khóa tài khoản' : 'Khóa tài khoản & thu hồi phiên'}
          </button>
        </div>
      )}
    </>
  );
}
