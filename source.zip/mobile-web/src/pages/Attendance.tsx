import { useState } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { get, post, qs } from '../api';
import { tierOf, useAuth } from '../auth';
import { Badge, Card, Empty, ErrorBox, Field, Header, Loading, Select, Tabs, useAction, useLoad } from '../ui';
import { Icon } from '../icons';
import { fmtDT, fromLocalInput, hours, toLocalInput } from '../labels';

export const ATT_KIND: Record<string, string> = { timeclock_down: 'Máy chấm công không hoạt động', offsite: 'Làm việc ngoài công ty/xưởng', field: 'Công tác hiện trường', forgot: 'Quên chấm công', other: 'Khác' };
const ATT_ST: Record<string, [string, string]> = { submitted: ['Chờ quản lý xác nhận', 'amber'], confirmed: ['Đã ghi nhận', 'green'], rejected: ['Từ chối', 'red'] };

/** Quản lý (tầng ≤6): "Ghi nhận chấm công" cho nhân viên. Nhân viên: "Tự khai báo chấm công" cho chính mình. Không tự tính tăng ca. */
export function attLabel(me: any) { return tierOf(me) <= 6 ? 'Ghi nhận chấm công' : 'Tự khai báo chấm công'; }

export function AttendanceForm() {
  const { me } = useAuth();
  const nav = useNavigate();
  const manager = tierOf(me) <= 6;
  const [sp] = useSearchParams();
  const [mode, setMode] = useState<'others' | 'self'>(manager && !sp.get('self') ? 'others' : 'self');
  const people = useLoad(() => (manager ? get('/hr/org-chart') : Promise.resolve(null)), [manager]);
  const tasks = useLoad(() => get('/tasks' + qs({ mine: mode === 'self' ? 'any' : undefined, status: 'not_started,in_progress,pending_review,revision_requested,completed', limit: 100 })), [mode]);
  const now = new Date(); now.setMinutes(0, 0, 0);
  const [f, setF] = useState<any>({ memberIds: [] as string[], kind: 'timeclock_down', place: '', startAt: toLocalInput(new Date(now.getTime() - 4 * 3600000)), endAt: toLocalInput(now), taskId: '', note: '' });
  const [msg, setMsg] = useState<string | null>(null);
  const a = useAction();
  const up = (p: any) => setF((x: any) => ({ ...x, ...p }));
  const mins = Math.round((new Date(f.endAt).getTime() - new Date(f.startAt).getTime()) / 60000);
  const mine = (people.data?.groups || []).filter((g: any) => g.manager_member_id === me?.member_id || g.leader_member_id === me?.member_id);
  const memberOpts = new Map<string, string>();
  for (const g of (mine.length ? mine : people.data?.groups || [])) for (const id of g.member_ids || []) { const m = people.data.members.find((x: any) => x.id === id); if (m && m.id !== me?.member_id) memberOpts.set(m.id, m.name); }
  const toggle = (id: string) => up({ memberIds: f.memberIds.includes(id) ? f.memberIds.filter((x: string) => x !== id) : [...f.memberIds, id] });
  const submit = () => a.run(async () => {
    const r = await post('/attendance-records', { memberIds: mode === 'others' ? f.memberIds : undefined, kind: f.kind, place: f.place || undefined, startAt: fromLocalInput(f.startAt), endAt: fromLocalInput(f.endAt),
      taskId: f.taskId || undefined, note: f.note });
    setMsg(r.message);
    setTimeout(() => nav('/work?s=declare&view=attendance', { replace: true }), 1200);
  });
  return (
    <>
      <Header title={mode === 'others' ? 'Ghi nhận chấm công' : 'Tự khai báo chấm công'} back />
      <div className="page">
        {manager && <div className="seg"><button className={mode === 'others' ? 'on' : ''} onClick={() => setMode('others')}>Ghi nhận cho nhân viên</button><button className={mode === 'self' ? 'on' : ''} onClick={() => setMode('self')}>Tự khai báo cho tôi</button></div>}
        <p className="small muted">Ghi nhận thời gian làm việc khi máy chấm công không hoạt động, làm ngoài xưởng, quên chấm công… Chỉ ghi nhận giờ bắt đầu – kết thúc, <b>không tự tính tăng ca</b>. Hệ thống đối chiếu người và nhiệm vụ: nếu công việc đã được ghi nhận (bởi quản lý hoặc chính nhân viên) sẽ không chấp nhận ghi trùng.</p>
        {mode === 'others' && (
          <Field label="Nhân viên được ghi nhận" required>
            <div className="chip-row">{[...memberOpts.entries()].map(([id, n]) => <button key={id} type="button" className={`btn sm ${f.memberIds.includes(id) ? 'primary' : ''}`} onClick={() => toggle(id)}>{n}</button>)}</div>
            {people.loading && <Loading />}
          </Field>
        )}
        <Field label="Trường hợp"><Select value={f.kind} onChange={(v) => up({ kind: v })} options={ATT_KIND} /></Field>
        {['offsite', 'field'].includes(f.kind) && <Field label="Nơi làm việc" required><input value={f.place} onChange={(e) => up({ place: e.target.value })} placeholder="VD: Kho đối tác Long An" /></Field>}
        <div className="grid2">
          <Field label="Bắt đầu" required><input type="datetime-local" value={f.startAt} onChange={(e) => up({ startAt: e.target.value })} /></Field>
          <Field label="Kết thúc" required><input type="datetime-local" value={f.endAt} onChange={(e) => up({ endAt: e.target.value })} /></Field>
        </div>
        <div className="small muted">Thời gian làm việc: <b>{mins > 0 ? hours(mins) : '—'}</b></div>
        <Field label="Nhiệm vụ (nếu có)" hint="Dùng để đối chiếu trùng"><Select value={f.taskId} onChange={(v) => up({ taskId: v })} options={(tasks.data?.items || []).map((t: any) => [t.id, `${t.code} - ${t.title}`])} placeholder="— Không gắn nhiệm vụ —" /></Field>
        <Field label="Nội dung công việc / lý do" required><textarea value={f.note} onChange={(e) => up({ note: e.target.value })} /></Field>
        {msg && <div className="alert ok small">✓ {msg}</div>}
        <ErrorBox error={a.error} />
        <button className="btn primary block" disabled={a.busy || f.note.trim().length < 5 || mins <= 0 || (mode === 'others' && !f.memberIds.length)} onClick={submit}><Icon name="clock" size={18} />{mode === 'others' ? 'Ghi nhận' : 'Gửi tự khai báo'}</button>
      </div>
    </>
  );
}

export function AttendanceList() {
  const { me } = useAuth();
  const manager = tierOf(me) <= 6;
  const [scope, setScope] = useState('mine');
  const { data, error, loading, reload } = useLoad(() => get('/attendance-records' + qs({ scope })), [scope]);
  const a = useAction();
  const [note, setNote] = useState<Record<string, string>>({});
  return (
    <>
      <div className="quick">
        <Link className="btn primary" to="/attendance/new"><Icon name="clock" size={18} />{attLabel(me)}</Link>
        {manager ? <Link className="btn" to="/attendance/new?self=1"><Icon name="record" size={18} />Tự khai báo cho tôi</Link> : <span />}
      </div>
      <Tabs value={scope} onChange={setScope} tabs={[['mine', 'Của tôi'], ...(manager ? [['recorded', 'Tôi đã ghi nhận'] as [string, string], ['review', 'Cần tôi xác nhận'] as [string, string]] : [])]} />
      <ErrorBox error={error || a.error} />
      {loading && !data && <Loading />}
      {data && data.length === 0 && <Empty>Chưa có bản ghi chấm công</Empty>}
      {data?.map((r: any) => (
        <Card key={r.id}>
          <div className="row"><b style={{ flex: 1 }}>{r.code} · {scope === 'mine' ? ATT_KIND[r.kind] : r.member_name}</b><Badge tone={ATT_ST[r.status][1]}>{ATT_ST[r.status][0]}</Badge></div>
          <div className="small">{fmtDT(r.start_at)} → {fmtDT(r.end_at)} · {hours(r.minutes)}{r.place ? ` · ${r.place}` : ''}</div>
          <div className="small muted">{r.source === 'manager' ? `Quản lý ${r.recorded_by_name} ghi nhận` : 'Tự khai báo'}{r.task_title ? ` · ${r.task_code} - ${r.task_title}` : ''} — {r.note}</div>
          {scope === 'review' && r.status === 'submitted' && (
            <div style={{ marginTop: 6 }}>
              <input placeholder="Ghi chú (bắt buộc khi từ chối)" value={note[r.id] || ''} onChange={(e) => setNote({ ...note, [r.id]: e.target.value })} />
              <div className="actions">
                <button className="btn primary sm" disabled={a.busy} onClick={() => a.run(async () => { await post(`/attendance-records/${r.id}/review`, { decision: 'confirm', note: note[r.id] || undefined }); reload(); })}>Xác nhận</button>
                <button className="btn danger sm" disabled={a.busy || (note[r.id] || '').length < 5} onClick={() => a.run(async () => { await post(`/attendance-records/${r.id}/review`, { decision: 'reject', note: note[r.id] }); reload(); })}>Từ chối</button>
              </div>
            </div>
          )}
        </Card>
      ))}
    </>
  );
}
