import { useEffect, useState } from 'react';
import { get, patch, post, put } from '../api';
import { Badge, Card, ErrorBox, Field, Header, Loading, Select, Tabs, useAction, useLoad } from '../ui';
import { COMPLEXITY, REQ, SEVERITY, fmtDT } from '../labels';

const DAYS: [number, string][] = [[1, 'T2'], [2, 'T3'], [3, 'T4'], [4, 'T5'], [5, 'T6'], [6, 'T7'], [7, 'CN']];

export default function AdminSettings() {
  const [tab, setTab] = useState(() => new URLSearchParams(window.location.search).get('tab') || 'calendar');
  return (
    <>
      <Header title="Cấu hình công ty" back="/me" />
      <div className="page">
        <Tabs value={tab} onChange={setTab} tabs={[['positions', 'Chức vụ & quyền hạn'], ['calendar', 'Lịch & chính sách'], ['sla', 'SLA'], ['perf', 'Trọng số'], ['dept', 'Bộ phận'], ['permits', 'Giấy phép'], ['handover', 'Bàn giao'], ['types', 'Danh mục'], ['locations', 'Vị trí'], ['standards', 'Định mức'], ['worktime', 'Thời gian & quỹ nghỉ'], ['privacy', 'Quyền riêng tư'], ['audit', 'Audit']]} />
        {tab === 'positions' && <Positions />}
        {tab === 'calendar' && <CalendarPolicies />}
        {tab === 'sla' && <Sla />}
        {tab === 'perf' && <Perf />}
        {tab === 'dept' && <Departments />}
        {tab === 'permits' && <PermitTypes />}
        {tab === 'handover' && <HandoverSettings />}
        {tab === 'types' && <TaskTypes />}
        {tab === 'locations' && <Locations />}
        {tab === 'standards' && <Standards />}
        {tab === 'worktime' && <WorkTime />}
        {tab === 'privacy' && <PrivacySettings />}
        {tab === 'audit' && <Audit />}
      </div>
    </>
  );
}

function CalendarPolicies() {
  const { data, loading } = useLoad(() => get('/company'), []);
  const [s, setS] = useState<any>(null);
  const a = useAction(); const [ok, setOk] = useState(false);
  useEffect(() => { if (data) setS({ name: data.name, timezone: data.timezone, ...data.settings, holidaysText: data.settings.calendar.holidays.join('\n') }); }, [data]);
  if (loading || !s) return <Loading />;
  const c = s.calendar; const p = s.policies;
  const upC = (x: any) => setS({ ...s, calendar: { ...c, ...x } });
  const upP = (x: any) => setS({ ...s, policies: { ...p, ...x } });
  const save = () => a.run(async () => {
    await patch('/company/settings', { name: s.name, timezone: s.timezone,
      calendar: { ...c, holidays: s.holidaysText.split(/\s+/).filter(Boolean) }, policies: p });
    setOk(true); setTimeout(() => setOk(false), 2500);
  });
  return (
    <>
      <Field label="Tên công ty"><input value={s.name} onChange={(e) => setS({ ...s, name: e.target.value })} /></Field>
      <Field label="Múi giờ (D06)"><input value={s.timezone} onChange={(e) => setS({ ...s, timezone: e.target.value })} /></Field>
      <div className="section-title">Lịch làm việc — dùng tính deadline & SLA</div>
      <div className="chip-row">{DAYS.map(([d, l]) => (
        <label key={d} className="check" style={{ margin: 0, marginRight: 8 }}><input type="checkbox" checked={c.workdays.includes(d)} onChange={(e) => upC({ workdays: e.target.checked ? [...c.workdays, d].sort() : c.workdays.filter((x: number) => x !== d) })} />{l}</label>
      ))}</div>
      <div className="grid2">
        <Field label="Giờ bắt đầu"><input type="time" value={c.start} onChange={(e) => upC({ start: e.target.value })} /></Field>
        <Field label="Giờ kết thúc"><input type="time" value={c.end} onChange={(e) => upC({ end: e.target.value })} /></Field>
        <Field label="Nghỉ trưa từ"><input type="time" value={c.breakStart || ''} onChange={(e) => upC({ breakStart: e.target.value })} /></Field>
        <Field label="Nghỉ trưa đến"><input type="time" value={c.breakEnd || ''} onChange={(e) => upC({ breakEnd: e.target.value })} /></Field>
      </div>
      <Field label="Ngày nghỉ lễ (YYYY-MM-DD, mỗi dòng một ngày)"><textarea value={s.holidaysText} onChange={(e) => setS({ ...s, holidaysText: e.target.value })} /></Field>
      <div className="section-title">Chính sách (mục 18)</div>
      <label className="check"><input type="checkbox" checked={p.multiGroup} onChange={(e) => upP({ multiGroup: e.target.checked })} /> D01 — Nhân viên được tham gia nhiều nhóm</label>
      <Field label="D02 — Nhân viên xem nhiệm vụ"><Select value={p.employeeTaskVisibility} onChange={(v) => upP({ employeeTaskVisibility: v })} options={{ group: 'Toàn bộ nhiệm vụ của nhóm mình', related: 'Chỉ nhiệm vụ liên quan đến mình' }} /></Field>
      <Field label="D04 — Ngưỡng khiếu nại (lần từ chối liên tiếp thứ N)"><input type="number" min={1} value={p.appealThreshold} onChange={(e) => upP({ appealThreshold: +e.target.value })} /></Field>
      <Field label="D05 — Thời hạn quản lý xác nhận bản ghi (phút làm việc)" hint="480 = 1 ngày làm việc"><input type="number" min={30} value={p.workRecordReviewMinutes} onChange={(e) => upP({ workRecordReviewMinutes: +e.target.value })} /></Field>
      <Field label="Nhắc trước hạn nhiệm vụ (phút)"><input type="number" value={p.taskDueSoonMinutes} onChange={(e) => upP({ taskDueSoonMinutes: +e.target.value })} /></Field>
      <Field label="Nhắc SLA khi còn lại ≤ tỷ lệ thời hạn"><input type="number" step={0.05} min={0.05} max={0.9} value={p.reminderRatio} onChange={(e) => upP({ reminderRatio: +e.target.value })} /></Field>
      <label className="check"><input type="checkbox" checked={p.resetChainOnAccept} onChange={(e) => upP({ resetChainOnAccept: e.target.checked })} /> Đặt lại chuỗi từ chối khi nhân viên chấp nhận kết quả</label>
      <p className="small muted">D03 (giao việc chéo nhóm) cấp theo từng người tại mục Thành viên. D07 (tuyến chuyển cấp) theo "Cấp trên trực tiếp" của từng thành viên → Admin/Owner → reviewer độc lập.</p>
      <ErrorBox error={a.error} />{ok && <div className="alert ok">Đã lưu</div>}
      <button className="btn primary block" disabled={a.busy} onClick={save}>Lưu cấu hình</button>
    </>
  );
}

function Sla() {
  const { data, loading } = useLoad(() => get('/company/sla'), []);
  const [rows, setRows] = useState<any[]>([]);
  const a = useAction(); const [ok, setOk] = useState(false);
  useEffect(() => { if (data) setRows(data); }, [data]);
  if (loading) return <Loading />;
  const up = (i: number, k: string, v: number) => setRows(rows.map((r, j) => (j === i ? { ...r, [k]: v } : r)));
  return (
    <>
      <p className="small muted">Đơn vị: phút làm việc (theo lịch). Mức Nghiêm trọng tính theo thời gian thực 24/7. Sự cố an toàn phải kích hoạt quy trình ngoài app.</p>
      {rows.map((r, i) => (
        <Card key={r.severity}>
          <b>{SEVERITY[r.severity]}</b>
          <div className="grid2">
            <Field label="Quản lý tiếp nhận/chuyển"><input type="number" value={r.manager_review_minutes} onChange={(e) => up(i, 'manager_review_minutes', +e.target.value)} /></Field>
            <Field label="Bộ phận xác nhận tiếp nhận"><input type="number" value={r.acknowledge_minutes} onChange={(e) => up(i, 'acknowledge_minutes', +e.target.value)} /></Field>
          </div>
          <Field label="Thời gian xử lý mục tiêu"><input type="number" value={r.resolve_minutes} onChange={(e) => up(i, 'resolve_minutes', +e.target.value)} /></Field>
        </Card>
      ))}
      <ErrorBox error={a.error} />{ok && <div className="alert ok">Đã lưu</div>}
      <button className="btn primary block" disabled={a.busy} onClick={() => a.run(async () => { setRows(await put('/company/sla', rows.map(({ severity, manager_review_minutes, acknowledge_minutes, resolve_minutes }) => ({ severity, manager_review_minutes, acknowledge_minutes, resolve_minutes })))); setOk(true); })}>Lưu SLA</button>
    </>
  );
}

function Perf() {
  const { data, loading, reload } = useLoad(() => get('/company/performance-config'), []);
  const [c, setC] = useState<any>(null);
  const a = useAction();
  useEffect(() => { if (data) setC(data.current.config); }, [data]);
  if (loading || !c) return <Loading />;
  const grp = (key: string, labels: Record<string, string>) => (
    <Card>
      {Object.keys(c[key]).map((k) => (
        <div className="kv" key={k}><span>{labels[k] || k}</span>
          <input style={{ width: 90, minHeight: 34 }} type="number" step={0.05} value={c[key][k]} onChange={(e) => setC({ ...c, [key]: { ...c[key], [k]: +e.target.value } })} /></div>
      ))}
    </Card>
  );
  return (
    <>
      <p className="small muted">Mỗi lần lưu tạo phiên bản công thức mới (hiện tại v{data.current.version}). Báo cáo đã chốt giữ nguyên phiên bản cũ. Hãy chạy thử trên dữ liệu pilot trước khi dùng chính thức (D09).</p>
      <div className="section-title">Điểm nhiệm vụ thường xuyên (tổng = 1)</div>
      {grp('regularWeights', { output: 'Kết quả đầu ra', quality: 'Chất lượng', schedule: 'Tiến độ', process: 'Quá trình/phối hợp' })}
      <div className="section-title">Điểm việc đột xuất (tổng = 1)</div>
      {grp('unexpectedWeights', { requirement: 'Đáp ứng yêu cầu', response: 'Tốc độ phản ứng', handling: 'Xử lý tình huống', quality: 'Chất lượng', coordination: 'Phối hợp' })}
      <div className="section-title">Hệ số độ phức tạp</div>
      {grp('complexityFactors', COMPLEXITY)}
      <div className="section-title">Hệ số mức yêu cầu</div>
      {grp('requirementFactors', REQ)}
      <div className="section-title">Chỉ số nhân viên E (tổng = 1)</div>
      {grp('employeeWeights', { V: 'V — Khối lượng', T: 'T — Tiến độ', Q: 'Q — Chất lượng', D: 'D — Độ khó', R: 'R — Độ tin cậy' })}
      <Card><div className="kv"><span>Phần ghi nhận người chịu trách nhiệm khi có cộng tác viên</span><input style={{ width: 90, minHeight: 34 }} type="number" step={0.05} value={c.ownerShare} onChange={(e) => setC({ ...c, ownerShare: +e.target.value })} /></div></Card>
      <ErrorBox error={a.error} />
      <button className="btn primary block" disabled={a.busy} onClick={() => a.run(async () => { await post('/company/performance-config', c); reload(); })}>Lưu phiên bản mới</button>
      <div className="section-title">Lịch sử phiên bản</div>
      {data.history.map((h: any) => <div key={h.id} className="small">v{h.version} · {fmtDT(h.created_at)}</div>)}
    </>
  );
}

function Departments() {
  const { data, reload } = useLoad(() => get('/company/departments'), []);
  const members = useLoad(() => get('/company/members'), []);
  const [name, setName] = useState(''); const [head, setHead] = useState(''); const [fn, setFn] = useState('other');
  const a = useAction();
  const opts = (members.data || []).map((m: any) => [m.id, m.name] as [string, string]);
  return (
    <>
      <p className="small muted">Phòng ban/bộ phận và chức năng của nó. Chức năng quyết định quyền lập/xem xét đơn hàng (Kinh doanh, Kế hoạch, Sản xuất), phạm vi của Quản lý nhân sự (Nhân sự) và mẫu công việc mặc định. Trưởng bộ phận tiếp nhận báo cáo trở ngại chuyển đến.</p>
      {data?.map((d: any) => (
        <Card key={d.id}>
          <b>{d.name}</b> <span className="small muted">· {d.member_count} người</span>
          <Field label="Chức năng"><Select value={d.function || 'other'} onChange={(v) => a.run(async () => { await patch(`/company/departments/${d.id}`, { function: v }); reload(); })} options={DEPT_FUNC} /></Field>
          <Field label="Trưởng bộ phận"><Select value={d.head_member_id || ''} onChange={(v) => a.run(async () => { await patch(`/company/departments/${d.id}`, { headMemberId: v || null }); reload(); })} options={opts} placeholder="— Chưa có —" /></Field>
        </Card>
      ))}
      <Card>
        <Field label="Bộ phận mới"><input value={name} onChange={(e) => setName(e.target.value)} /></Field>
        <Field label="Trưởng bộ phận"><Select value={head} onChange={setHead} options={opts} placeholder="— Chưa có —" /></Field>
        <Field label="Chức năng"><Select value={fn} onChange={setFn} options={DEPT_FUNC} /></Field>
        <button className="btn primary" disabled={a.busy || !name} onClick={() => a.run(async () => { await post('/company/departments', { name, headMemberId: head || undefined, function: fn }); setName(''); setHead(''); reload(); })}>Thêm</button>
      </Card>
      <ErrorBox error={a.error} />
    </>
  );
}

function TaskTypes() {
  const { data, reload } = useLoad(() => get('/company/task-types'), []);
  const [name, setName] = useState('');
  const a = useAction();
  return (
    <>
      {data?.map((t: any) => (
        <Card key={t.id}><div className="row"><span style={{ flex: 1 }}>{t.name}</span>
          <button className="btn sm" onClick={() => a.run(async () => { await patch(`/company/task-types/${t.id}`, { active: !t.active }); reload(); })}>{t.active ? 'Ngừng dùng' : 'Dùng lại'}</button></div></Card>
      ))}
      <div style={{ display: 'flex', gap: 6 }}>
        <input placeholder="Loại công việc mới" value={name} onChange={(e) => setName(e.target.value)} />
        <button className="btn primary" disabled={a.busy || !name} onClick={() => a.run(async () => { await post('/company/task-types', { name }); setName(''); reload(); })}>Thêm</button>
      </div>
      <ErrorBox error={a.error} />
    </>
  );
}

function Audit() {
  const { data, loading } = useLoad(() => get('/company/audit-logs?limit=200'), []);
  if (loading) return <Loading />;
  return (
    <>
      <p className="small muted">Nhật ký bất biến: thay đổi quyền, deadline, tiêu chí, đánh giá, từ chối, khiếu nại và chuyển cấp.</p>
      {data?.map((x: any) => (
        <Card key={x.id}>
          <div className="row"><b>{x.action}</b><span className="spacer" /><span className="small muted">{fmtDT(x.created_at)}</span></div>
          <div className="small muted">{x.entity_type} · {x.actor_name || 'Hệ thống'}{x.reason ? ` · Lý do: ${x.reason}` : ''}</div>
        </Card>
      ))}
    </>
  );
}

const USAGE: Record<string, string> = { single: 'Dùng 1 lần', multi: 'Dùng nhiều lần (trong thời hạn)' };
const FTYPE: Record<string, string> = { text: 'Chữ', textarea: 'Đoạn văn', number: 'Số', date: 'Ngày', datetime: 'Ngày giờ' };
const slugK = (s: string) => s.normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/đ/gi, 'd').toLowerCase().replace(/[^a-z0-9]+/g, '_').replace(/^_|_$/g, '').slice(0, 40) || 'truong';

function FieldsEditor({ fields, onChange }: { fields: any[]; onChange: (f: any[]) => void }) {
  return (
    <>
      {fields.map((x: any, i: number) => (
        <div key={i} style={{ display: 'grid', gridTemplateColumns: '1fr 96px auto', gap: 6, marginBottom: 6, alignItems: 'center' }}>
          <input value={x.label} placeholder="Tên thông tin (VD: Biển số xe)" onChange={(e) => onChange(fields.map((y, j) => (j === i ? { ...y, label: e.target.value } : y)))} />
          <select value={x.type || 'text'} onChange={(e) => onChange(fields.map((y, j) => (j === i ? { ...y, type: e.target.value } : y)))}>{Object.entries(FTYPE).map(([k, l]) => <option key={k} value={k}>{l}</option>)}</select>
          <button type="button" className="icon-btn" aria-label="Xóa" onClick={() => onChange(fields.filter((_, j) => j !== i))}>✕</button>
          <label className="check" style={{ margin: 0, gridColumn: '1 / -1' }}><input type="checkbox" checked={!!x.required} onChange={(e) => onChange(fields.map((y, j) => (j === i ? { ...y, required: e.target.checked } : y)))} /> Bắt buộc</label>
        </div>
      ))}
      <button type="button" className="btn sm" onClick={() => onChange([...fields, { label: '', type: 'text', required: false }])}>＋ Thông tin cần điền</button>
    </>
  );
}

/**
 * Giấy phép (v10): tạo loại giấy phép — bộ phận tiếp nhận, thông tin người lập cần điền, dùng 1 lần / nhiều lần.
 * Trong giấy phép: người cấp phép (người giao việc), người sử dụng (người được giao việc), người đi cùng (nếu có).
 * Bộ phận xử lý nhận thông tin; chỉ cấp quản lý của bộ phận mới duyệt.
 */
function PermitTypes() {
  const { data, reload } = useLoad(() => get('/permit-types'), []);
  const depts = useLoad(() => get('/company/departments'), []);
  const a = useAction();
  const [nw, setNw] = useState<any>(null);
  const [open, setOpen] = useState<string | null>(null);
  const upd = (id: string, b: any) => a.run(async () => { await patch(`/permit-types/${id}`, b); reload(); });
  const blank = { name: '', description: '', departmentId: '', usage: 'single', allowCompanions: true, allowDeclaration: false, tracks: 'none', fields: [{ label: 'Nội dung / mục đích', type: 'textarea', required: true }] };
  const norm = (fields: any[]) => { const seen = new Set<string>(); return fields.filter((x) => x.label?.trim()).map((x) => { let k = x.key || slugK(x.label); while (seen.has(k)) k = (k + '_2').slice(0, 40); seen.add(k); return { key: k, label: x.label.trim(), type: x.type || 'text', required: !!x.required }; }); };
  return (
    <>
      <p className="small muted">Mỗi giấy phép có <b>người cấp phép</b> (người giao việc), <b>người sử dụng</b> (người được giao việc) và <b>người đi cùng</b> (nếu có). Bộ phận xử lý nhận thông tin giấy phép; chỉ <b>cấp quản lý của bộ phận</b> (trưởng bộ phận, tầng 3–5) mới duyệt.</p>
      {!nw && <button className="btn primary block" onClick={() => setNw(blank)}>＋ Tạo giấy phép</button>}
      {nw && (
        <Card>
          <b>Loại giấy phép mới</b>
          <Field label="Tên giấy phép" required><input value={nw.name} onChange={(e) => setNw({ ...nw, name: e.target.value })} placeholder="VD: Giấy công tác ngoài, Giấy mượn dụng cụ" /></Field>
          <Field label="Mô tả"><input value={nw.description} onChange={(e) => setNw({ ...nw, description: e.target.value })} /></Field>
          <div className="grid2">
            <Field label="Bộ phận tiếp nhận"><Select value={nw.departmentId} onChange={(v) => setNw({ ...nw, departmentId: v })} options={(depts.data || []).map((d: any) => [d.id, d.name])} placeholder="— Quản trị công ty —" /></Field>
            <Field label="Loại sử dụng"><Select value={nw.usage} onChange={(v) => setNw({ ...nw, usage: v })} options={USAGE} /></Field>
          </div>
          <Field label="Theo dõi"><Select value={nw.tracks} onChange={(v) => setNw({ ...nw, tracks: v })} options={{ none: 'Không theo dõi ra/vào', gate: 'Ghi nhận ra – vào cổng', equipment: 'Ghi nhận giao – trả thiết bị' }} /></Field>
          <label className="check"><input type="checkbox" checked={nw.allowCompanions} onChange={(e) => setNw({ ...nw, allowCompanions: e.target.checked })} /> Cho phép người đi cùng</label>
          <label className="check"><input type="checkbox" checked={nw.allowDeclaration} onChange={(e) => setNw({ ...nw, allowDeclaration: e.target.checked })} /> Cho phép cấp tự động bằng khai báo (hậu kiểm sau)</label>
          <div className="section-title">Thông tin người lập cần điền</div>
          <FieldsEditor fields={nw.fields} onChange={(f) => setNw({ ...nw, fields: f })} />
          <div className="actions">
            <button className="btn" onClick={() => setNw(null)}>Hủy</button>
            <button className="btn primary" disabled={a.busy || nw.name.trim().length < 3} onClick={() => a.run(async () => {
              await post('/permit-types', { ...nw, departmentId: nw.departmentId || null, description: nw.description || undefined, fields: norm(nw.fields) }); setNw(null); reload();
            })}>Tạo giấy phép</button>
          </div>
        </Card>
      )}
      {data?.map((t: any) => (
        <Card key={t.id}>
          <div className="row" onClick={() => setOpen(open === t.id ? null : t.id)} style={{ cursor: 'pointer' }}><b style={{ flex: 1 }}>{t.name}</b><Badge tone={t.usage === 'single' ? 'blue' : 'teal'}>{USAGE[t.usage] || t.usage}</Badge>{!t.active && <Badge tone="gray">Ngừng dùng</Badge>}</div>
          <div className="small muted">{t.department_name || 'Quản trị công ty'} · {(t.fields || []).length} thông tin cần điền{t.allow_companions ? ' · có người đi cùng' : ''}</div>
          {open === t.id && <>
            <Field label="Bộ phận tiếp nhận"><Select value={t.department_id || ''} onChange={(v) => upd(t.id, { departmentId: v || null })} options={(depts.data || []).map((d: any) => [d.id, d.name])} placeholder="— Quản trị công ty —" /></Field>
            <Field label="Loại sử dụng"><Select value={t.usage} onChange={(v) => upd(t.id, { usage: v })} options={USAGE} /></Field>
            <label className="check"><input type="checkbox" checked={t.allow_companions} onChange={(e) => upd(t.id, { allowCompanions: e.target.checked })} /> Cho phép người đi cùng</label>
            <label className="check"><input type="checkbox" checked={t.allow_declaration} onChange={(e) => upd(t.id, { allowDeclaration: e.target.checked })} /> Cho phép cấp tự động bằng đơn khai báo (hậu kiểm sau)</label>
            <label className="check"><input type="checkbox" checked={t.active} onChange={(e) => upd(t.id, { active: e.target.checked })} /> Đang sử dụng</label>
            <div className="section-title">Thông tin người lập cần điền</div>
            <PermitFieldsEdit t={t} onSave={(f) => upd(t.id, { fields: norm(f) })} />
          </>}
        </Card>
      ))}
      <ErrorBox error={a.error} />
    </>
  );
}
function PermitFieldsEdit({ t, onSave }: { t: any; onSave: (f: any[]) => void }) {
  const [f, setF] = useState<any[]>(t.fields || []);
  return <><FieldsEditor fields={f} onChange={setF} /><button className="btn sm primary" style={{ marginLeft: 6 }} onClick={() => onSave(f)}>Lưu thông tin</button></>;
}

/** Thiết lập bàn giao (v10): bàn giao liên bộ phận và bàn giao bên ngoài (QR). */
function HandoverSettings() {
  const { data } = useLoad(() => get('/company'), []);
  const [h, setH] = useState<any>(null);
  const a = useAction(); const [ok, setOk] = useState(false);
  if (data && !h) setH(data.settings.handover);
  if (!h) return <Loading />;
  const up = (p: any) => { setH({ ...h, ...p }); setOk(false); };
  return (
    <>
      <div className="section-title">Bàn giao liên bộ phận</div>
      <Card>
        <label className="check"><input type="checkbox" checked={h.internalRequireAccept} onChange={(e) => up({ internalRequireAccept: e.target.checked })} /> Công đoạn sau phải tiếp nhận bàn giao trước khi bắt đầu</label>
        <Field label="Thời hạn tiếp nhận bàn giao (giờ)"><input type="number" min={1} max={72} value={h.internalAcceptHours} onChange={(e) => up({ internalAcceptHours: Number(e.target.value) })} /></Field>
      </Card>
      <div className="section-title">Bàn giao bên ngoài (QR) & duyệt giải trình</div>
      <Card>
        <Field label="Hạn hiệu lực QR/link bàn giao (ngày)"><input type="number" min={1} max={60} value={h.externalQrDays} onChange={(e) => up({ externalQrDays: Number(e.target.value) })} /></Field>
        <label className="check"><input type="checkbox" checked={h.externalAllowRejectDefault} onChange={(e) => up({ externalAllowRejectDefault: e.target.checked })} /> Mặc định cho phép người nhận "Không tiếp nhận"</label>
        <label className="check"><input type="checkbox" checked={h.externalRequireReviewDefault} onChange={(e) => up({ externalRequireReviewDefault: e.target.checked })} /> Mặc định còn bước nghiệm thu sau khi người nhận xác nhận</label>
        <Field label="SLA duyệt giải trình bỏ qua QR (giờ)" hint="Quá hạn sẽ nhắc người giao"><input type="number" min={1} max={240} value={h.exceptionSlaHours} onChange={(e) => up({ exceptionSlaHours: Number(e.target.value) })} /></Field>
        <label className="check"><input type="checkbox" checked={h.exceptionRequireEvidence} onChange={(e) => up({ exceptionRequireEvidence: e.target.checked })} /> Giải trình bắt buộc đính kèm bằng chứng</label>
      </Card>
      <p className="small muted">Danh sách bàn giao và giải trình chờ duyệt nằm ở Công việc › Cần tôi xử lý › Bàn giao.</p>
      {ok && <div className="alert ok small">Đã lưu thiết lập bàn giao</div>}
      <ErrorBox error={a.error} />
      <button className="btn primary block" disabled={a.busy} onClick={() => a.run(async () => { await patch('/company/settings', { handover: h }); setOk(true); })}>Lưu</button>
    </>
  );
}

/** Quyền riêng tư, lưu trữ, đầu mối báo cáo hành vi (SEC-01, UX-ABUSE-01). */
function PrivacySettings() {
  const { data } = useLoad(() => get('/company'), []);
  const members = useLoad(() => get('/company/members?status=active'), []);
  const [p, setP] = useState<any>(null);
  const a = useAction(); const [ok, setOk] = useState(false);
  if (data && !p) setP(data.settings.privacy);
  if (!p) return <Loading />;
  const r = p.retention;
  const setR = (k: string, v: string) => setP({ ...p, retention: { ...r, [k]: Number(v) } });
  const cands = (members.data || []).filter((m: any) => ['hr', 'owner', 'admin', 'reviewer'].includes(m.role));
  return (
    <>
      <div className="section-title">Đầu mối tiếp nhận báo cáo hành vi</div>
      <p className="small muted">Để trống: hệ thống chọn Nhân sự, rồi Chủ doanh nghiệp/Quản trị. Người được báo cáo và người báo cáo không bao giờ là người xử lý hồ sơ của chính họ.</p>
      {cands.map((m: any) => (
        <label key={m.id} className="check"><input type="checkbox" checked={p.conductHandlerIds.includes(m.id)} onChange={(e) => setP({ ...p, conductHandlerIds: e.target.checked ? [...p.conductHandlerIds, m.id] : p.conductHandlerIds.filter((x: string) => x !== m.id) })} /> {m.name}</label>
      ))}
      <label className="check"><input type="checkbox" checked={p.allowAnonymousToHandler} onChange={(e) => setP({ ...p, allowAnonymousToHandler: e.target.checked })} /> Cho phép ẩn danh với cả người xử lý</label>
      <Field label="Đầu mối an toàn khẩn cấp (hiện cho người báo cáo khi có nguy cơ)"><textarea value={p.safetyContact} onChange={(e) => setP({ ...p, safetyContact: e.target.value })} /></Field>
      <div className="section-title">Yêu cầu dữ liệu cá nhân & lưu trữ</div>
      <p className="small muted">Thời hạn lưu cần được pháp chế/nhân sự chốt theo nghĩa vụ lưu trữ và hợp đồng. Hệ thống tự xóa khi quá hạn và ghi lại lần xóa.</p>
      <div className="grid2">
        <Field label="Hạn xử lý yêu cầu (ngày)"><input type="number" value={p.requestDueDays} onChange={(e) => setP({ ...p, requestDueDays: Number(e.target.value) })} /></Field>
        <Field label="Thông báo (ngày)"><input type="number" value={r.notificationsDays} onChange={(e) => setR('notificationsDays', e.target.value)} /></Field>
        <Field label="Ghi âm cuộc gọi (ngày)"><input type="number" value={r.recordingsDays} onChange={(e) => setR('recordingsDays', e.target.value)} /></Field>
        <Field label="Nhật ký truy cập (ngày)"><input type="number" value={r.accessLogsDays} onChange={(e) => setR('accessLogsDays', e.target.value)} /></Field>
        <Field label="Tệp tải dữ liệu (giờ)"><input type="number" value={r.exportFileHours} onChange={(e) => setR('exportFileHours', e.target.value)} /></Field>
        <Field label="Hồ sơ hành vi đã đóng (ngày)"><input type="number" value={r.closedConductCaseDays} onChange={(e) => setR('closedConductCaseDays', e.target.value)} /></Field>
      </div>
      <ErrorBox error={a.error} />{ok && <div className="alert ok">Đã lưu</div>}
      <button className="btn primary block" disabled={a.busy} onClick={() => a.run(async () => { const d = await patch('/company/settings', { privacy: p }); setP(d.settings.privacy); setOk(true); setTimeout(() => setOk(false), 2000); })}>Lưu</button>
    </>
  );
}

const LOC_KIND_OPTS: Record<string, string> = { department: 'Phòng ban', machine_room: 'Phòng máy', raw_store: 'Kho nguyên liệu', cold_store: 'Kho lạnh', production_floor: 'Sàn sản xuất', packing: 'Khu đóng gói', office: 'Văn phòng', outside: 'Ngoài công ty', area: 'Khu vực khác' };
/** Danh mục vị trí làm việc — chỉ dữ liệu tham khảo; không GPS. */
function Locations() {
  const { data, reload } = useLoad(() => get('/company/locations'), []);
  const [n, setN] = useState(''); const [k, setK] = useState('area');
  const a = useAction();
  return (
    <>
      <p className="small muted">Vị trí chỉ là dữ liệu tham khảo; chỉ bắt buộc với nhiệm vụ có địa điểm cố định. Vị trí chưa xác minh không dùng để kết luận vi phạm/hiệu suất.</p>
      <div className="row" style={{ gap: 6 }}><input placeholder="Tên vị trí" value={n} onChange={(e) => setN(e.target.value)} /><Select value={k} onChange={setK} options={LOC_KIND_OPTS} />
        <button className="btn" disabled={a.busy || n.trim().length < 2} onClick={() => a.run(async () => { await post('/company/locations', { name: n, kind: k }); setN(''); reload(); })}>Thêm</button></div>
      <ErrorBox error={a.error} />
      {data?.map((l: any) => <Card key={l.id}><div className="row"><span style={{ flex: 1 }}>{l.name} <span className="small muted">· {LOC_KIND_OPTS[l.kind]}</span></span>
        <button className="btn sm" onClick={() => a.run(async () => { await patch(`/company/locations/${l.id}`, { active: !l.active }); reload(); })}>{l.active ? 'Ngừng dùng' : 'Dùng lại'}</button></div></Card>)}
    </>
  );
}

/** Định mức sản lượng; đổi định mức tạo phiên bản mới, có lý do. */
function Standards() {
  const { data, reload } = useLoad(() => get('/company/production-standards'), []);
  const [f, setF] = useState<any>({ name: '', unit: 'sản phẩm', quantity: '', minutes: '' });
  const [edit, setEdit] = useState<any>(null);
  const a = useAction();
  return (
    <>
      <p className="small muted">Hiệu suất công đoạn = thời gian chuẩn quy đổi từ sản lượng đạt chuẩn ÷ thời gian thực hiện. Ví dụ định mức 100 túi/30 phút, đạt 360 túi = 108 phút chuẩn; làm 120 phút → 90%. Chất lượng tính riêng; không tự áp hệ số chất lượng khi chưa được duyệt.</p>
      <div className="grid2">
        <Field label="Tên công đoạn/sản phẩm"><input value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} /></Field>
        <Field label="Đơn vị"><input value={f.unit} onChange={(e) => setF({ ...f, unit: e.target.value })} /></Field>
        <Field label="Số lượng"><input type="number" value={f.quantity} onChange={(e) => setF({ ...f, quantity: e.target.value })} /></Field>
        <Field label="Trong (phút)"><input type="number" value={f.minutes} onChange={(e) => setF({ ...f, minutes: e.target.value })} /></Field>
      </div>
      <button className="btn" disabled={a.busy || !f.name || !f.quantity || !f.minutes} onClick={() => a.run(async () => { await post('/company/production-standards', { ...f, quantity: Number(f.quantity), minutes: Number(f.minutes) }); setF({ name: '', unit: 'sản phẩm', quantity: '', minutes: '' }); reload(); })}>Thêm định mức</button>
      <ErrorBox error={a.error} />
      {data?.map((s: any) => <Card key={s.id}><div className="row"><span style={{ flex: 1 }}><b>{s.name}</b> · {Number(s.quantity)} {s.unit}/{Number(s.minutes)} phút <span className="small muted">v{s.version}{s.active ? '' : ' · ngừng dùng'}</span></span>
        {s.active && <button className="btn sm" onClick={() => setEdit({ ...s, quantity: Number(s.quantity), minutes: Number(s.minutes), reason: '' })}>Đổi</button>}</div></Card>)}
      {edit && (
        <Card>
          <b>Đổi định mức “{edit.name}” (tạo phiên bản mới)</b>
          <div className="grid2"><Field label="Số lượng"><input type="number" value={edit.quantity} onChange={(e) => setEdit({ ...edit, quantity: e.target.value })} /></Field>
            <Field label="Phút"><input type="number" value={edit.minutes} onChange={(e) => setEdit({ ...edit, minutes: e.target.value })} /></Field></div>
          <Field label="Lý do" required><input value={edit.reason} onChange={(e) => setEdit({ ...edit, reason: e.target.value })} /></Field>
          <div className="actions"><button className="btn" onClick={() => setEdit(null)}>Hủy</button>
            <button className="btn primary" disabled={a.busy || edit.reason.trim().length < 5} onClick={() => a.run(async () => { await patch(`/company/production-standards/${edit.id}`, { quantity: Number(edit.quantity), minutes: Number(edit.minutes), reason: edit.reason }); setEdit(null); reload(); })}>Lưu phiên bản mới</button></div>
        </Card>
      )}
    </>
  );
}

/** Thời gian làm việc & quỹ nghỉ bổ sung (thông số do doanh nghiệp/HR/pháp chế chốt — D-01, D-02). */
function WorkTime() {
  const { data } = useLoad(() => get('/company'), []);
  const [w, setW] = useState<any>(null);
  const a = useAction(); const [ok, setOk] = useState(false);
  if (data && !w) setW(data.settings.workTime);
  if (!w) return <Loading />;
  const r = w.rest; const setR = (p: any) => setW({ ...w, rest: { ...r, ...p } });
  return (
    <>
      <div className="alert warn small">Quỹ nghỉ bổ sung là chính sách nội bộ, tách khỏi nghỉ giữa giờ theo luật và giờ làm thêm. Hệ thống không tự quy đổi số dư nghỉ thành giờ làm thêm hay tiền lương. Thông số cần HR/pháp chế rà soát trước khi bật.</div>
      <label className="check"><input type="checkbox" checked={r.enabled} onChange={(e) => setR({ enabled: e.target.checked })} /> Áp dụng quỹ nghỉ bổ sung tích lũy</label>
      <div className="grid2">
        <Field label="Làm liên tục (phút) để tích lũy"><input type="number" value={r.continuousMinutes} onChange={(e) => setR({ continuousMinutes: Number(e.target.value) })} /></Field>
        <Field label="Trần số dư (phút)"><input type="number" value={r.capMinutes} onChange={(e) => setR({ capMinutes: Number(e.target.value) })} /></Field>
        <Field label="Tích lũy ca ngày (phút)"><input type="number" value={r.dayAccrual} onChange={(e) => setR({ dayAccrual: Number(e.target.value) })} /></Field>
        <Field label="Tích lũy ca đêm (phút)"><input type="number" value={r.nightAccrual} onChange={(e) => setR({ nightAccrual: Number(e.target.value) })} /></Field>
        <Field label="Ca đêm từ"><input type="time" value={r.nightStart} onChange={(e) => setR({ nightStart: e.target.value })} /></Field>
        <Field label="Đến"><input type="time" value={r.nightEnd} onChange={(e) => setR({ nightEnd: e.target.value })} /></Field>
      </div>
      <label className="check"><input type="checkbox" checked={r.requireApproval} onChange={(e) => setR({ requireApproval: e.target.checked })} /> Dùng quỹ nghỉ phải được trưởng nhóm cho phép</label>
      <div className="section-title">Phiên làm việc & cảnh báo</div>
      <div className="grid2">
        <Field label="Tự đóng phiên quên kết thúc sau (giờ)"><input type="number" value={w.autoCloseSessionHours} onChange={(e) => setW({ ...w, autoCloseSessionHours: Number(e.target.value) })} /></Field>
        <Field label="Hệ số nguy cơ trễ" hint="Nguy cơ trễ khi thời gian còn lại < thời gian cần × hệ số"><input type="number" step={0.1} value={w.atRiskBufferRatio} onChange={(e) => setW({ ...w, atRiskBufferRatio: Number(e.target.value) })} /></Field>
      </div>
      <label className="check"><input type="checkbox" checked={w.objectivePauseNeedsConfirm} onChange={(e) => setW({ ...w, objectivePauseNeedsConfirm: e.target.checked })} /> Hoãn khách quan cần trưởng nhóm xác nhận</label>
      <ErrorBox error={a.error} />{ok && <div className="alert ok">Đã lưu</div>}
      <button className="btn primary block" disabled={a.busy} onClick={() => a.run(async () => { const d = await patch('/company/settings', { workTime: w }); setW(d.settings.workTime); setOk(true); setTimeout(() => setOk(false), 2000); })}>Lưu</button>
    </>
  );
}

export const DEPT_FUNC: Record<string, string> = { production: 'Sản xuất / vận hành', planning: 'Kế hoạch', sales: 'Kinh doanh', warehouse: 'Kho vận', qa: 'Chất lượng (QA/QC)', hr: 'Nhân sự', admin: 'Hành chính',
  finance: 'Tài chính – Kế toán', it: 'Kỹ thuật – CNTT', marketing: 'Marketing', hse: 'An toàn – Môi trường', security: 'Bảo vệ – An ninh', cs: 'Chăm sóc khách hàng', other: 'Khác' };

/** Chức vụ & quyền hạn (v8): chức vụ thuộc một tầng 3–7; quyền giao việc / xem xét / phê duyệt / xem báo cáo cấu hình độc lập, ghi đè mặc định theo tầng. */
function Positions() {
  const { data, error, reload } = useLoad(() => get('/company/positions'), []);
  const a = useAction();
  const [open, setOpen] = useState<string | null>(null);
  const [nw, setNw] = useState({ name: '', tier: '7' });
  if (!data) return <><ErrorBox error={error} />{!error && <Loading />}</>;
  const caps = Object.entries(data.capabilities as Record<string, string>);
  const save = (p: any, c: Record<string, boolean>) => a.run(async () => { await patch(`/company/positions/${p.id}`, { capabilities: c }); reload(); });
  return (
    <>
      <p className="small muted">Tách bạch <b>chức vụ</b> (vị trí trong cơ cấu), <b>tầng quản lý</b> (3 Điều hành → 7 Nhân sự thực thi), <b>vai trò hệ thống</b> và <b>cấp bậc nghề nghiệp</b>. Quyền mặc định theo tầng; có thể bật/tắt riêng cho từng chức vụ. Quản lý phòng ban chỉ có quyền lập/xem xét đơn hàng khi phòng ban có chức năng Kinh doanh/Kế hoạch/Sản xuất.</p>
      {Object.entries(data.tiers as Record<string, string>).map(([tier, label]) => (
        <div key={tier}>
          <div className="section-title">{label}</div>
          {data.positions.filter((p: any) => String(p.tier) === tier).map((p: any) => {
            const ov = (p.capabilities || {}) as Record<string, boolean>;
            const eff = (k: string) => (k in ov ? ov[k] : p.default_caps.includes(k));
            return (
              <Card key={p.id}>
                <div className="row" onClick={() => setOpen(open === p.id ? null : p.id)} style={{ cursor: 'pointer' }}>
                  <b style={{ flex: 1 }}>{p.name}{!p.active ? ' (ngừng dùng)' : ''}</b><span className="small muted">{p.member_count} người · {Object.keys(ov).length ? 'đã tùy chỉnh' : 'mặc định'}</span>
                </div>
                {open === p.id && (
                  <div style={{ marginTop: 6 }}>
                    {caps.map(([k, l]) => (
                      <label key={k} className="check" style={{ margin: '2px 0' }}>
                        <input type="checkbox" checked={eff(k)} disabled={a.busy} onChange={(e) => save(p, { ...ov, [k]: e.target.checked })} /> {l}{k in ov ? ' •' : ''}
                      </label>
                    ))}
                    <div className="actions">
                      <button className="btn sm" disabled={a.busy || !Object.keys(ov).length} onClick={() => save(p, {})}>Về mặc định theo tầng</button>
                      <button className="btn sm" disabled={a.busy} onClick={() => a.run(async () => { await patch(`/company/positions/${p.id}`, { active: !p.active }); reload(); })}>{p.active ? 'Ngừng dùng' : 'Dùng lại'}</button>
                    </div>
                    <div className="small muted">• = khác mặc định của tầng. Thay đổi được ghi nhật ký kiểm toán.</div>
                  </div>
                )}
              </Card>
            );
          })}
        </div>
      ))}
      <Card>
        <Field label="Chức vụ mới"><input value={nw.name} onChange={(e) => setNw({ ...nw, name: e.target.value })} placeholder="VD: Trưởng ca đêm" /></Field>
        <Field label="Tầng"><Select value={nw.tier} onChange={(v) => setNw({ ...nw, tier: v })} options={Object.entries(data.tiers as Record<string, string>).map(([k, l]) => [k, l]) as [string, string][]} /></Field>
        <button className="btn primary" disabled={a.busy || nw.name.trim().length < 2} onClick={() => a.run(async () => { await post('/company/positions', { name: nw.name, tier: Number(nw.tier) }); setNw({ name: '', tier: '7' }); reload(); })}>Thêm chức vụ</button>
      </Card>
      <ErrorBox error={a.error} />
    </>
  );
}
