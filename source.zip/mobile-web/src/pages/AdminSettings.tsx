import { useEffect, useState } from 'react';
import { get, patch, post, put } from '../api';
import { Card, ErrorBox, Field, Header, Loading, Select, Tabs, useAction, useLoad } from '../ui';
import { COMPLEXITY, REQ, SEVERITY, fmtDT } from '../labels';

const DAYS: [number, string][] = [[1, 'T2'], [2, 'T3'], [3, 'T4'], [4, 'T5'], [5, 'T6'], [6, 'T7'], [7, 'CN']];

export default function AdminSettings() {
  const [tab, setTab] = useState('calendar');
  return (
    <>
      <Header title="Cấu hình công ty" back="/me" />
      <div className="page">
        <Tabs value={tab} onChange={setTab} tabs={[['calendar', 'Lịch & chính sách'], ['sla', 'SLA'], ['perf', 'Trọng số'], ['dept', 'Bộ phận'], ['permits', 'Giấy phép'], ['types', 'Danh mục'], ['audit', 'Audit']]} />
        {tab === 'calendar' && <CalendarPolicies />}
        {tab === 'sla' && <Sla />}
        {tab === 'perf' && <Perf />}
        {tab === 'dept' && <Departments />}
        {tab === 'permits' && <PermitTypes />}
        {tab === 'types' && <TaskTypes />}
        {tab === 'audit' && <Audit />}
      </div>
    </>
  );
}

function CalendarPolicies() {
  const { data, loading } = useLoad(() => get('/company'), []);
  const [s, setS] = useState<any>(null);
  const a = useAction(); const [ok, setOk] = useState(false);
  useEffect(() => { if (data) setS({ name: data.name, timezone: data.timezone, ...data.settings, holidaysText: data.settings.calendar.holidays.join('\n') }); }, [data]);
  if (loading || !s) return <Loading />;
  const c = s.calendar; const p = s.policies;
  const upC = (x: any) => setS({ ...s, calendar: { ...c, ...x } });
  const upP = (x: any) => setS({ ...s, policies: { ...p, ...x } });
  const save = () => a.run(async () => {
    await patch('/company/settings', { name: s.name, timezone: s.timezone,
      calendar: { ...c, holidays: s.holidaysText.split(/\s+/).filter(Boolean) }, policies: p });
    setOk(true); setTimeout(() => setOk(false), 2500);
  });
  return (
    <>
      <Field label="Tên công ty"><input value={s.name} onChange={(e) => setS({ ...s, name: e.target.value })} /></Field>
      <Field label="Múi giờ (D06)"><input value={s.timezone} onChange={(e) => setS({ ...s, timezone: e.target.value })} /></Field>
      <div className="section-title">Lịch làm việc — dùng tính deadline & SLA</div>
      <div className="chip-row">{DAYS.map(([d, l]) => (
        <label key={d} className="check" style={{ margin: 0, marginRight: 8 }}><input type="checkbox" checked={c.workdays.includes(d)} onChange={(e) => upC({ workdays: e.target.checked ? [...c.workdays, d].sort() : c.workdays.filter((x: number) => x !== d) })} />{l}</label>
      ))}</div>
      <div className="grid2">
        <Field label="Giờ bắt đầu"><input type="time" value={c.start} onChange={(e) => upC({ start: e.target.value })} /></Field>
        <Field label="Giờ kết thúc"><input type="time" value={c.end} onChange={(e) => upC({ end: e.target.value })} /></Field>
        <Field label="Nghỉ trưa từ"><input type="time" value={c.breakStart || ''} onChange={(e) => upC({ breakStart: e.target.value })} /></Field>
        <Field label="Nghỉ trưa đến"><input type="time" value={c.breakEnd || ''} onChange={(e) => upC({ breakEnd: e.target.value })} /></Field>
      </div>
      <Field label="Ngày nghỉ lễ (YYYY-MM-DD, mỗi dòng một ngày)"><textarea value={s.holidaysText} onChange={(e) => setS({ ...s, holidaysText: e.target.value })} /></Field>
      <div className="section-title">Chính sách (mục 18)</div>
      <label className="check"><input type="checkbox" checked={p.multiGroup} onChange={(e) => upP({ multiGroup: e.target.checked })} /> D01 — Nhân viên được tham gia nhiều nhóm</label>
      <Field label="D02 — Nhân viên xem nhiệm vụ"><Select value={p.employeeTaskVisibility} onChange={(v) => upP({ employeeTaskVisibility: v })} options={{ group: 'Toàn bộ nhiệm vụ của nhóm mình', related: 'Chỉ nhiệm vụ liên quan đến mình' }} /></Field>
      <Field label="D04 — Ngưỡng khiếu nại (lần từ chối liên tiếp thứ N)"><input type="number" min={1} value={p.appealThreshold} onChange={(e) => upP({ appealThreshold: +e.target.value })} /></Field>
      <Field label="D05 — Thời hạn quản lý xác nhận bản ghi (phút làm việc)" hint="480 = 1 ngày làm việc"><input type="number" min={30} value={p.workRecordReviewMinutes} onChange={(e) => upP({ workRecordReviewMinutes: +e.target.value })} /></Field>
      <Field label="Nhắc trước hạn nhiệm vụ (phút)"><input type="number" value={p.taskDueSoonMinutes} onChange={(e) => upP({ taskDueSoonMinutes: +e.target.value })} /></Field>
      <Field label="Nhắc SLA khi còn lại ≤ tỷ lệ thời hạn"><input type="number" step={0.05} min={0.05} max={0.9} value={p.reminderRatio} onChange={(e) => upP({ reminderRatio: +e.target.value })} /></Field>
      <label className="check"><input type="checkbox" checked={p.resetChainOnAccept} onChange={(e) => upP({ resetChainOnAccept: e.target.checked })} /> Đặt lại chuỗi từ chối khi nhân viên chấp nhận kết quả</label>
      <p className="small muted">D03 (giao việc chéo nhóm) cấp theo từng người tại mục Thành viên. D07 (tuyến chuyển cấp) theo "Cấp trên trực tiếp" của từng thành viên → Admin/Owner → reviewer độc lập.</p>
      <ErrorBox error={a.error} />{ok && <div className="alert ok">Đã lưu</div>}
      <button className="btn primary block" disabled={a.busy} onClick={save}>Lưu cấu hình</button>
    </>
  );
}

function Sla() {
  const { data, loading } = useLoad(() => get('/company/sla'), []);
  const [rows, setRows] = useState<any[]>([]);
  const a = useAction(); const [ok, setOk] = useState(false);
  useEffect(() => { if (data) setRows(data); }, [data]);
  if (loading) return <Loading />;
  const up = (i: number, k: string, v: number) => setRows(rows.map((r, j) => (j === i ? { ...r, [k]: v } : r)));
  return (
    <>
      <p className="small muted">Đơn vị: phút làm việc (theo lịch). Mức Nghiêm trọng tính theo thời gian thực 24/7. Sự cố an toàn phải kích hoạt quy trình ngoài app.</p>
      {rows.map((r, i) => (
        <Card key={r.severity}>
          <b>{SEVERITY[r.severity]}</b>
          <div className="grid2">
            <Field label="Quản lý tiếp nhận/chuyển"><input type="number" value={r.manager_review_minutes} onChange={(e) => up(i, 'manager_review_minutes', +e.target.value)} /></Field>
            <Field label="Bộ phận xác nhận tiếp nhận"><input type="number" value={r.acknowledge_minutes} onChange={(e) => up(i, 'acknowledge_minutes', +e.target.value)} /></Field>
          </div>
          <Field label="Thời gian xử lý mục tiêu"><input type="number" value={r.resolve_minutes} onChange={(e) => up(i, 'resolve_minutes', +e.target.value)} /></Field>
        </Card>
      ))}
      <ErrorBox error={a.error} />{ok && <div className="alert ok">Đã lưu</div>}
      <button className="btn primary block" disabled={a.busy} onClick={() => a.run(async () => { setRows(await put('/company/sla', rows.map(({ severity, manager_review_minutes, acknowledge_minutes, resolve_minutes }) => ({ severity, manager_review_minutes, acknowledge_minutes, resolve_minutes })))); setOk(true); })}>Lưu SLA</button>
    </>
  );
}

function Perf() {
  const { data, loading, reload } = useLoad(() => get('/company/performance-config'), []);
  const [c, setC] = useState<any>(null);
  const a = useAction();
  useEffect(() => { if (data) setC(data.current.config); }, [data]);
  if (loading || !c) return <Loading />;
  const grp = (key: string, labels: Record<string, string>) => (
    <Card>
      {Object.keys(c[key]).map((k) => (
        <div className="kv" key={k}><span>{labels[k] || k}</span>
          <input style={{ width: 90, minHeight: 34 }} type="number" step={0.05} value={c[key][k]} onChange={(e) => setC({ ...c, [key]: { ...c[key], [k]: +e.target.value } })} /></div>
      ))}
    </Card>
  );
  return (
    <>
      <p className="small muted">Mỗi lần lưu tạo phiên bản công thức mới (hiện tại v{data.current.version}). Báo cáo đã chốt giữ nguyên phiên bản cũ. Hãy chạy thử trên dữ liệu pilot trước khi dùng chính thức (D09).</p>
      <div className="section-title">Điểm nhiệm vụ thường xuyên (tổng = 1)</div>
      {grp('regularWeights', { output: 'Kết quả đầu ra', quality: 'Chất lượng', schedule: 'Tiến độ', process: 'Quá trình/phối hợp' })}
      <div className="section-title">Điểm việc đột xuất (tổng = 1)</div>
      {grp('unexpectedWeights', { requirement: 'Đáp ứng yêu cầu', response: 'Tốc độ phản ứng', handling: 'Xử lý tình huống', quality: 'Chất lượng', coordination: 'Phối hợp' })}
      <div className="section-title">Hệ số độ phức tạp</div>
      {grp('complexityFactors', COMPLEXITY)}
      <div className="section-title">Hệ số mức yêu cầu</div>
      {grp('requirementFactors', REQ)}
      <div className="section-title">Chỉ số nhân viên E (tổng = 1)</div>
      {grp('employeeWeights', { V: 'V — Khối lượng', T: 'T — Tiến độ', Q: 'Q — Chất lượng', D: 'D — Độ khó', R: 'R — Độ tin cậy' })}
      <Card><div className="kv"><span>Phần ghi nhận người chịu trách nhiệm khi có cộng tác viên</span><input style={{ width: 90, minHeight: 34 }} type="number" step={0.05} value={c.ownerShare} onChange={(e) => setC({ ...c, ownerShare: +e.target.value })} /></div></Card>
      <ErrorBox error={a.error} />
      <button className="btn primary block" disabled={a.busy} onClick={() => a.run(async () => { await post('/company/performance-config', c); reload(); })}>Lưu phiên bản mới</button>
      <div className="section-title">Lịch sử phiên bản</div>
      {data.history.map((h: any) => <div key={h.id} className="small">v{h.version} · {fmtDT(h.created_at)}</div>)}
    </>
  );
}

function Departments() {
  const { data, reload } = useLoad(() => get('/company/departments'), []);
  const members = useLoad(() => get('/company/members'), []);
  const [name, setName] = useState(''); const [head, setHead] = useState('');
  const a = useAction();
  const opts = (members.data || []).map((m: any) => [m.id, m.name] as [string, string]);
  return (
    <>
      <p className="small muted">Bộ phận tiếp nhận báo cáo trở ngại (kỹ thuật, hành chính, cơ sở vật chất…). Trưởng bộ phận là người xác nhận tiếp nhận.</p>
      {data?.map((d: any) => (
        <Card key={d.id}>
          <b>{d.name}</b> <span className="small muted">· {d.member_count} người</span>
          <Field label="Trưởng bộ phận"><Select value={d.head_member_id || ''} onChange={(v) => a.run(async () => { await patch(`/company/departments/${d.id}`, { headMemberId: v || null }); reload(); })} options={opts} placeholder="— Chưa có —" /></Field>
        </Card>
      ))}
      <Card>
        <Field label="Bộ phận mới"><input value={name} onChange={(e) => setName(e.target.value)} /></Field>
        <Field label="Trưởng bộ phận"><Select value={head} onChange={setHead} options={opts} placeholder="— Chưa có —" /></Field>
        <button className="btn primary" disabled={a.busy || !name} onClick={() => a.run(async () => { await post('/company/departments', { name, headMemberId: head || undefined }); setName(''); setHead(''); reload(); })}>Thêm</button>
      </Card>
      <ErrorBox error={a.error} />
    </>
  );
}

function TaskTypes() {
  const { data, reload } = useLoad(() => get('/company/task-types'), []);
  const [name, setName] = useState('');
  const a = useAction();
  return (
    <>
      {data?.map((t: any) => (
        <Card key={t.id}><div className="row"><span style={{ flex: 1 }}>{t.name}</span>
          <button className="btn sm" onClick={() => a.run(async () => { await patch(`/company/task-types/${t.id}`, { active: !t.active }); reload(); })}>{t.active ? 'Ngừng dùng' : 'Dùng lại'}</button></div></Card>
      ))}
      <div style={{ display: 'flex', gap: 6 }}>
        <input placeholder="Loại công việc mới" value={name} onChange={(e) => setName(e.target.value)} />
        <button className="btn primary" disabled={a.busy || !name} onClick={() => a.run(async () => { await post('/company/task-types', { name }); setName(''); reload(); })}>Thêm</button>
      </div>
      <ErrorBox error={a.error} />
    </>
  );
}

function Audit() {
  const { data, loading } = useLoad(() => get('/company/audit-logs?limit=200'), []);
  if (loading) return <Loading />;
  return (
    <>
      <p className="small muted">Nhật ký bất biến: thay đổi quyền, deadline, tiêu chí, đánh giá, từ chối, khiếu nại và chuyển cấp.</p>
      {data?.map((x: any) => (
        <Card key={x.id}>
          <div className="row"><b>{x.action}</b><span className="spacer" /><span className="small muted">{fmtDT(x.created_at)}</span></div>
          <div className="small muted">{x.entity_type} · {x.actor_name || 'Hệ thống'}{x.reason ? ` · Lý do: ${x.reason}` : ''}</div>
        </Card>
      ))}
    </>
  );
}

function PermitTypes() {
  const { data, reload } = useLoad(() => get('/permit-types'), []);
  const depts = useLoad(() => get('/company/departments'), []);
  const a = useAction();
  const upd = (id: string, b: any) => a.run(async () => { await patch(`/permit-types/${id}`, b); reload(); });
  return (
    <>
      <p className="small muted">Chọn bộ phận xử lý từng loại giấy phép (bảo vệ, kho, hành chính…). Người của bộ phận đó nhận yêu cầu, xem thông tin công việc, cấp phép, ghi nhận ra–vào/nhận–trả và hậu kiểm đơn khai báo.</p>
      {data?.map((t: any) => (
        <Card key={t.id}>
          <b>{t.name}</b>
          <Field label="Bộ phận xử lý"><Select value={t.department_id || ''} onChange={(v) => upd(t.id, { departmentId: v || null })} options={(depts.data || []).map((d: any) => [d.id, d.name])} placeholder="— Quản trị công ty —" /></Field>
          <label className="check"><input type="checkbox" checked={t.allow_declaration} onChange={(e) => upd(t.id, { allowDeclaration: e.target.checked })} /> Cho phép cấp tự động bằng đơn khai báo (hậu kiểm sau)</label>
          <label className="check"><input type="checkbox" checked={t.active} onChange={(e) => upd(t.id, { active: e.target.checked })} /> Đang sử dụng</label>
        </Card>
      ))}
      <ErrorBox error={a.error} />
    </>
  );
}
