import { useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { get, post } from '../api';
import { Badge, Card, Empty, ErrorBox, Header, KV, Loading, Tabs, useAction, useLoad } from '../ui';
import { HO_STATUS, IMPORTANCE, RISK, TASK_STATUS, TIME_CAT, fmtDT, mins } from '../labels';
import { Dot } from '../marks';
import { ChainRow } from './Dashboards';

export function ChainList() {
  const { data, error } = useLoad(() => get('/chains'), []);
  const [f, setF] = useState('open');
  const items = (data || []).filter((c: any) => (f === 'open' ? c.risk !== 'done' : f === 'risk' ? ['at_risk', 'overdue'].includes(c.risk) : c.risk === 'done'));
  return (
    <>
      <Header title="Đơn hàng / chuỗi công việc" back="/" />
      <div className="page">
        <p className="small muted">Mỗi đơn hàng có mã chuỗi chung; mỗi công đoạn là nhiệm vụ con có mã riêng, có thể chạy song song. Bạn thấy các đơn có phần việc liên quan đến mình.</p>
        <Tabs value={f} onChange={setF} tabs={[['open', 'Đang chạy'], ['risk', 'Có rủi ro'], ['done', 'Hoàn thành']]} />
        <ErrorBox error={error} />{!data && !error && <Loading />}
        {items.map((c: any) => <ChainRow key={c.id} c={c} />)}
        {data && !items.length && <Empty>Không có đơn hàng</Empty>}
      </div>
    </>
  );
}

export function ChainDetail() {
  const { id } = useParams();
  const { data: c, error, reload } = useLoad(() => get(`/chains/${id}`), [id]);
  const a = useAction();
  const [plan, setPlan] = useState<any>(null);
  if (!c) return <><Header title="Đơn hàng" back="/chains" /><div className="page"><ErrorBox error={error} />{!error && <Loading />}</div></>;
  const r = RISK[c.risk] || RISK.normal;
  const stages = [...new Set(c.stages.map((s: any) => s.stage_no))].sort((x: any, y: any) => x - y) as number[];
  const tByStage = (s: number, cat: string) => c.time.filter((x: any) => x.stage_no === s && x.category === cat).reduce((a: number, x: any) => a + x.minutes, 0);
  return (
    <>
      <Header title={c.chain_code} back="/chains" />
      <div className="page">
        <h2>{c.title}</h2>
        <div className="chip-row"><Badge tone={r[1]}>{r[0]}</Badge>{c.importance !== 'normal' && <Badge tone="amber">{IMPORTANCE[c.importance]}</Badge>}<Badge>{TASK_STATUS[c.status]}</Badge></div>
        <div className="timebar"><i style={{ width: `${c.progress}%`, background: '#12a150' }} /></div>
        <Card>
          <KV k="Tiến độ" v={`${c.done}/${c.total} công đoạn (${c.progress}%)`} />
          <KV k="Hạn đơn hàng" v={fmtDT(c.due_at)} />
          {c.customer_name && <KV k="Khách hàng" v={c.customer_name} />}
          {c.order_value !== undefined && c.order_value !== null && <KV k="Giá trị đơn (nhạy cảm)" v={`${Number(c.order_value).toLocaleString('vi-VN')} đ`} />}
          {c.margin_note && <KV k="Lợi nhuận (nhạy cảm)" v={c.margin_note} />}
          {c.bottleneck && <KV k={['at_risk', 'overdue'].includes(c.bottleneck.risk) ? 'Công đoạn gây tắc' : 'Công đoạn đang chạy'} v={c.bottleneck.id ? <Link to={`/tasks/${c.bottleneck.id}`}>{c.bottleneck.title} ({c.bottleneck.group_name})</Link> : `${c.bottleneck.title} (${c.bottleneck.group_name})`} />}
        </Card>
        <div className="actions">
          <Link className="btn" to={`/tasks/${c.id}`}>Mở việc gốc</Link>
          {c.permissions.can_schedule && <button className="btn" disabled={a.busy} onClick={() => a.run(async () => setPlan(await post(`/chains/${id}/schedule`, { apply: false })))}>Tính deadline ngược</button>}
        </div>
        {plan && (
          <Card>
            <div className={`alert ${plan.feasible ? 'ok' : 'warn'} small`}>{plan.note} Bắt đầu sớm nhất cần: {fmtDT(plan.earliest_start)}</div>
            {plan.plan.map((p: any) => <div key={p.id} className="small">GĐ{p.stage_no} · {p.title}: {fmtDT(p.planned_start_at)} → {fmtDT(p.due_at)} ({mins(p.minutes)}){p.locked ? ' · đã xong' : ''}</div>)}
            <button className="btn primary sm" disabled={a.busy} onClick={() => a.run(async () => { await post(`/chains/${id}/schedule`, { apply: true }); setPlan(null); reload(); })}>Áp dụng lịch này</button>
          </Card>
        )}
        <ErrorBox error={a.error} />
        <div className="section-title">Các công đoạn</div>
        {stages.map((s) => (
          <div key={s} className="stage-box">
            <div className="stage-h">Giai đoạn {s}{c.stages.filter((x: any) => x.stage_no === s).length > 1 ? ' · song song' : ''}
              {c.full_view && <span className="small muted" style={{ fontWeight: 400 }}> · chờ {mins(tByStage(s, 'waiting'))} · hoãn KQ {mins(tByStage(s, 'objective_pause'))}</span>}</div>
            {c.stages.filter((x: any) => x.stage_no === s).map((k: any, i: number) => {
              const kr = RISK[k.risk] || RISK.normal;
              const body = (
                <>
                  <Dot k={k.status === 'completed' ? 'completed' : k.status === 'waiting' ? 'waiting' : ['at_risk', 'overdue'].includes(k.risk) ? 'overdue' : k.status === 'in_progress' ? 'in_progress' : 'not_started'} size={10} />
                  <span style={{ flex: 1, minWidth: 0 }}><span className="ellipsis">{k.code ? `${c.chain_code}_${k.code} - ` : ''}{k.title}</span><span className="small muted"> · {k.group_name}{k.owner_name ? ` · ${k.owner_name}` : ''}</span>
                    {k.due_at && <div className="small muted">{k.planned_start_at ? `${fmtDT(k.planned_start_at)} → ` : 'hạn '}{fmtDT(k.due_at)}{k.standard_minutes ? ` · chuẩn ${mins(k.standard_minutes)}` : ''}{k.executed_minutes ? ` · đã làm ${mins(k.executed_minutes)}` : ''}</div>}</span>
                  {k.risk !== 'done' && k.risk !== 'normal' ? <Badge tone={kr[1]}>{kr[0]}</Badge> : <span className="small muted">{TASK_STATUS[k.status]}</span>}
                </>
              );
              return k.can_open ? <Link key={k.id} to={`/tasks/${k.id}`} className="sub-row">{body}</Link> : <div key={i} className="sub-row">{body}</div>;
            })}
          </div>
        ))}
        {!c.full_view && <p className="small muted">Bạn thấy bối cảnh đơn hàng cần cho phần việc của mình; chi tiết các công đoạn khác do quản lý liên quan theo dõi.</p>}
        {c.production.length > 0 && <><div className="section-title">Sản lượng theo giai đoạn</div>
          {c.production.map((p: any) => <Card key={p.stage_no}><div className="row"><span style={{ flex: 1 }}>Giai đoạn {p.stage_no}</span><b>{Number(p.accepted)}/{Number(p.actual)} {p.unit}</b></div><div className="small muted">Lỗi {Number(p.rejected)} · làm lại {Number(p.rework)}</div></Card>)}</>}
        {c.handovers.length > 0 && <><div className="section-title">Lịch sử bàn giao</div>
          {c.handovers.map((h: any) => <div key={h.id} className="small row" style={{ gap: 6, margin: '4px 0' }}><Badge tone={HO_STATUS[h.status][1]}>{HO_STATUS[h.status][0]}</Badge><span style={{ flex: 1 }}>{h.from_title} → {h.to_title || '—'} · {fmtDT(h.submitted_at)}{h.reject_count ? ` · bị trả ${h.reject_count} lần` : ''}</span></div>)}</>}
        {c.time.length > 0 && <p className="small muted">Thời gian ghi nhận: {Object.entries(c.time.reduce((acc: any, x: any) => ({ ...acc, [x.category]: (acc[x.category] || 0) + x.minutes }), {})).map(([k, v]) => `${TIME_CAT[k]?.[0]} ${mins(v as number)}`).join(' · ')}</p>}
      </div>
    </>
  );
}

export function HandoverList() {
  const [scope, setScope] = useState('incoming');
  const { data } = useLoad(() => get(`/handovers?scope=${scope}`), [scope]);
  return (
    <>
      <Header title="Bàn giao" back />
      <div className="page">
        <Tabs value={scope} onChange={setScope} tabs={[['incoming', 'Gửi đến tôi/nhóm tôi'], ['outgoing', 'Tôi/nhóm tôi gửi']]} />
        {data?.map((h: any) => (
          <Card key={h.id} to={`/tasks/${scope === 'incoming' ? h.to_task_id || h.from_task_id : h.from_task_id}`}>
            <div className="row"><b style={{ flex: 1 }}>{h.from_group} → {h.to_group}{h.chain_code ? ` · ${h.chain_code}` : ''}</b><Badge tone={HO_STATUS[h.status][1]}>{HO_STATUS[h.status][0]}</Badge></div>
            <div className="small">{h.from_title}{h.to_title ? ` → ${h.to_title}` : ''}</div>
            <div className="small muted ellipsis">{h.content}</div>
            {h.rejection_reason && <div className="small" style={{ color: 'var(--red)' }}>{h.rejection_reason}</div>}
          </Card>
        ))}
        {data && !data.length && <Empty>Không có bàn giao</Empty>}
      </div>
    </>
  );
}
