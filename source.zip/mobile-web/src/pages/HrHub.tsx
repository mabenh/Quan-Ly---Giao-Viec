import { Link } from 'react-router-dom';
import { isHRRole, isManagerRole, useAuth } from '../auth';
import { IconChip, Icon } from '../icons';

/** Hệ thống nhân sự: sơ đồ tổ chức, tình trạng nhân sự tuần, quyết định, quy trình, hướng dẫn giao việc. */
export default function HrHub() {
  const { me } = useAuth();
  const mgr = isManagerRole(me?.role) || me?.role === 'reviewer' || me?.role === 'hr';
  const items: [string, string, string, string, string, boolean][] = [
    ['/hr/org', 'tree', 'blue', 'Sơ đồ tổ chức', 'Cây nhân sự theo cấp quản lý, bộ phận, nhóm', true],
    ['/team', 'calendar', 'teal', 'Tình trạng nhân sự tuần', 'Nghỉ phép, khối lượng việc, bàn giao', mgr],
    ['/hr/decisions', 'decision', 'purple', 'Quyết định nhân sự', 'Điều chuyển, thăng chức, thôi việc & bàn giao', true],
    ['/hr/procedures', 'book', 'green', 'Quy trình & thủ tục', 'Bản chuẩn hóa của công ty và bản tham khảo', true],
    ['/hr/flow', 'flow', 'amber', 'Sơ đồ quy trình giao việc', 'Đường đi của một công việc từ lúc giao tới khi đánh giá', true],
    ['/hr/guide', 'route', 'blue', 'Hướng dẫn giao việc', 'Cách giao việc đúng, nhanh, công bằng', true],
    ['/performance', 'perf', 'teal', 'Đánh giá & báo cáo', 'Điểm hiệu suất, báo cáo tháng/quý/năm', true],
    ['/admin/members', 'userCog', 'red', 'Thành viên & kiểm duyệt', 'Thêm bằng SĐT, phân vai trò, ra quyết định', isHRRole(me?.role)],
    ['/groups', 'users', 'gray', 'Nhóm', 'Danh sách nhóm và thành viên', true],
  ];
  return (
    <div className="page">
      <div className="hero">
        <div className="small" style={{ opacity: .85 }}>{me?.company_name}</div>
        <h1>Hệ thống nhân sự</h1>
        <div className="muted small">Con người, quy trình và cách chúng ta giao việc</div>
      </div>
      <div className="menu">
        {items.filter((x) => x[5]).map(([to, ic, tone, t, sub]) => (
          <Link key={to} to={to}><IconChip name={ic} tone={tone} /><span className="grow"><b>{t}</b><div className="sub">{sub}</div></span><Icon name="chevron" className="chev" /></Link>
        ))}
      </div>
    </div>
  );
}
