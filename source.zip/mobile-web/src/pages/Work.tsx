import { useSearchParams, Link, Navigate, useLocation } from 'react-router-dom';
import WorkHub from './WorkHub';
import { get, qs } from '../api';
import { canAssignAny, isManagerRole, useAuth } from '../auth';
import { Badge, Card, Empty, ErrorBox, Loading, Select, Tabs, useLoad } from '../ui';
import { Icon } from '../icons';
import { MarkFilter, TaskMarks } from '../marks';
import {
  PERMIT_STATUS, PERMIT_TONE, CHANNEL, CLAIM_STATUS, CLAIM_TONE, LEAVE_STATUS, LEAVE_TONE, LEAVE_TYPE, OT_STATUS, OT_TONE, OT_TYPE, RP_CAT, RP_STATUS, RP_TONE, SEVERITY, SEV_TONE, STAGE, TASK_STATUS, TASK_TONE, WR_STATUS, WR_TONE, WR_TYPE,
  fmtD, fmtDT, hours, relDue, UNEXPECTED_CAT, taskLabel,
} from '../labels';

export default function Work() {
  const [sp, setSp] = useSearchParams();
  const path = useLocation().pathname;
  const tab = sp.get('tab') || '';
  // v9: Công việc = Tổng quan (vai trò, phòng ban, tin phòng, thông báo) · Nhiệm vụ · Khai báo công việc · Báo cáo trở ngại.
  // Liên kết cũ: tab=tasks -> mục Nhiệm vụ; records/claims -> Khai báo công việc. Giấy phép/Nghỉ phép/Tăng ca giữ trang riêng.
  if (tab === 'records' || tab === 'claims') return <WorkHub initial={{ section: 'declare', view: sp.get('scope') === 'review' ? 'review' : 'mine' }} />;
  if (tab === 'tasks' || (path === '/tasks' && !tab)) return <WorkHub initial={{ section: 'tasks' }} />;
  if (tab === 'permits' || tab === 'leaves') {
    const n = new URLSearchParams(sp); n.delete('tab'); n.set('s', 'todo'); n.set('t', tab === 'permits' ? 'permit' : 'leave');
    return <Navigate to={`/work?${n.toString()}`} replace />;
  }
  if (tab !== 'overtime') return <WorkHub />;
  const set = (patch: Record<string, string | null>) => {
    const n = new URLSearchParams(sp);
    for (const [k, v] of Object.entries(patch)) (v === null || v === '' ? n.delete(k) : n.set(k, v));
    setSp(n, { replace: true });
  };
  return (
    <div className="page">
      <Link className="small" to="/work?s=declare&view=attendance">← Công việc</Link>
      <OvertimeList sp={sp} set={set} />
    </div>
  );
}

export type P = { sp: URLSearchParams; set: (p: Record<string, string | null>) => void };

export function TaskList({ sp, set }: P) {
  const { me } = useAuth();
  const f = { status: sp.get('status') || '', groupId: sp.get('groupId') || '', mine: sp.get('mine') || '', overdue: sp.get('overdue') || '', search: sp.get('search') || '', unexpected: sp.get('unexpected') || '', pinned: sp.get('pinned') || '', memberId: sp.get('memberId') || '' };
  const groups = useLoad(() => get('/groups'), []);
  const { data, error, loading } = useLoad(() => get('/tasks' + qs({ ...f, limit: 100 })), [JSON.stringify(f)]);
  const STATUS_MARKS = ['pending_review', 'in_progress', 'completed', 'cancelled'];
  const active = [...(f.pinned ? ['pin'] : []), ...(f.overdue ? ['overdue'] : []), ...(f.unexpected ? ['unexpected'] : []), ...f.status.split(',').filter((x) => STATUS_MARKS.includes(x))];
  const toggle = (k: string) => {
    if (k === 'pin') return set({ pinned: f.pinned ? null : 'true' });
    if (k === 'overdue') return set({ overdue: f.overdue ? null : 'true' });
    if (k === 'unexpected') return set({ unexpected: f.unexpected ? null : 'true' });
    const cur = f.status.split(',').filter(Boolean);
    const next = cur.includes(k) ? cur.filter((x) => x !== k) : [...cur, k];
    set({ status: next.join(',') || null });
  };
  return (
    <>
      <div className="quick">
        {canAssignAny(me) || isManagerRole(me?.role) ? <Link className="btn primary" to="/tasks/new"><Icon name="plus" size={18} />Giao việc</Link> : <Link className="btn primary" to="/work-records/new"><Icon name="record" size={18} />Tự khai báo</Link>}
        <Link className="btn" to="/support/new"><Icon name="users" size={18} />Yêu cầu hỗ trợ</Link>
      </div>
      <input placeholder="Tìm theo tên hoặc mã nhiệm vụ…" value={f.search} onChange={(e) => set({ search: e.target.value })} aria-label="Tìm kiếm" />
      <MarkFilter active={active} onToggle={toggle} />
      <div className="filters">
        <Select value={f.groupId} onChange={(v) => set({ groupId: v })} options={(groups.data || []).map((g: any) => [g.id, g.name])} placeholder="Mọi nhóm" aria-label="Nhóm" />
        <Select value={f.mine} onChange={(v) => set({ mine: v })} options={{ any: 'Việc của tôi', owner: 'Tôi chịu trách nhiệm' }} placeholder="Tất cả việc được xem" aria-label="Phạm vi" />
      </div>
      <ErrorBox error={error} />
      {loading && !data && <Loading />}
      {data && data.items.length === 0 && <Empty>Không có nhiệm vụ phù hợp</Empty>}
      {data?.items.map((t: any) => (
        <Card key={t.id} to={`/tasks/${t.id}`} className={t.pinned ? 'pinned' : ''}>
          <div className="row"><TaskMarks t={t} /><span className="title" style={{ flex: 1 }}>{taskLabel(t)}</span>{t.unread_comments > 0 && <Badge tone="red">💬 {t.unread_comments} mới</Badge>}{t.child_count > 0 && <span className="small muted">{t.child_count} phần việc</span>}</div>
          <div className="small muted" style={{ marginTop: 4 }}>{t.group_name} · {t.owner_name}{t.parent_title ? ` · thuộc ${t.parent_code} - ${t.parent_title}` : ''}</div>
          <div className="small muted">{t.is_overdue ? <span style={{ color: 'var(--red)' }}>{relDue(t.due_at)}</span> : `Hạn ${fmtDT(t.due_at)}`}
            {['waiting', 'pending_approval', 'revision_requested'].includes(t.status) ? ` · ${TASK_STATUS[t.status]}` : ''}
            {t.impediment_confirmed ? ' · có trở ngại' : ''}{t.carry_count > 0 ? ` · chuyển ${t.carry_count} ngày` : ''}</div>
        </Card>
      ))}
    </>
  );
}

function RecordList({ sp, set }: P) {
  const { me } = useAuth();
  const scope = sp.get('scope') || 'mine';
  const { data, error, loading } = useLoad(() => get('/work-records' + qs({ scope })), [scope]);
  const canReview = me?.role !== 'employee';
  return (
    <>
      <div className="quick"><Link className="btn primary" to="/work-records/new">📝 Khai báo công việc</Link><Link className="btn" to="/work-records/new?type=routine">Việc thường ngày</Link></div>
      <p className="small muted">Khai nhanh: thêm vào việc đang có, việc thường ngày (chỉ cần mô tả), việc ngoài vai trò (người giao, lý do, bằng chứng). Quản lý trực tiếp bắt buộc phản hồi trong thời hạn.</p>
      <Tabs value={scope} onChange={(v) => set({ scope: v })} tabs={[['mine', 'Của tôi'], ...(canReview ? [['review', 'Cần tôi xác nhận'] as [string, string]] : []), ['all', 'Tất cả được xem']]} />
      <ErrorBox error={error} />
      {loading && !data && <Loading />}
      {data && data.length === 0 && <Empty>Chưa có bản ghi</Empty>}
      {data?.map((r: any) => (
        <Card key={r.id} to={`/work-records/${r.id}`}>
          <div className="row"><span className="title" style={{ flex: 1 }}>{r.title}</span><Badge tone={WR_TONE[r.status]}>{WR_STATUS[r.status]}</Badge></div>
          <div className="small muted" style={{ marginTop: 4 }}>{r.employee_name} · {WR_TYPE[r.record_type]} · {fmtD(r.work_date)} · {hours(r.claimed_minutes)}</div>
          <div className="chip-row">
            {r.overdue && <Badge tone="red">Quá hạn phản hồi</Badge>}
            {r.escalation_level > 0 && <Badge tone="red">Đã chuyển cấp {r.escalation_level}</Badge>}
            {r.consecutive_rejections > 0 && <Badge tone="amber">Từ chối liên tiếp: {r.consecutive_rejections}</Badge>}
            {r.overlap_warning && <Badge tone="amber">Trùng thời gian</Badge>}
            {r.status === 'submitted' || r.status === 'disputed' ? <span className="small muted">Hạn phản hồi: {fmtDT(r.review_due_at)} · {r.reviewer_name}</span> : null}
          </div>
        </Card>
      ))}
    </>
  );
}

function OvertimeList({ sp, set }: P) {
  const { me } = useAuth();
  const scope = sp.get('scope') || 'mine';
  const status = sp.get('status') || '';
  const { data, error, loading } = useLoad(() => get('/overtime-records' + qs({ scope, status })), [scope, status]);
  const total = (data || []).reduce((a: number, o: any) => a + o.minutes, 0);
  return (
    <>
      <div className="quick"><Link className="btn primary" to="/overtime/new">⏱ Ghi nhận tăng ca</Link><span /></div>
      <p className="small muted">Giờ tăng ca là chỉ số điều kiện vận hành, không cộng vào điểm hiệu suất và không tự tính lương.</p>
      <div className="filters">
        {me?.role !== 'employee' && <Select value={scope} onChange={(v) => set({ scope: v })} options={{ mine: 'Của tôi', team: 'Nhóm/cấp dưới' }} aria-label="Phạm vi" />}
        <Select value={status} onChange={(v) => set({ status: v })} options={OT_STATUS} placeholder="Mọi trạng thái" aria-label="Trạng thái" />
      </div>
      <ErrorBox error={error} />
      {loading && !data && <Loading />}
      {data && <div className="small muted">{data.length} bản ghi · tổng {hours(total)}</div>}
      {data && data.length === 0 && <Empty>Chưa có bản ghi tăng ca</Empty>}
      {data?.map((o: any) => (
        <Card key={o.id} to={`/overtime/${o.id}`}>
          <div className="row"><span className="title" style={{ flex: 1 }}>{hours(o.minutes)} · {o.member_name}</span><Badge tone={OT_TONE[o.approval_status]}>{OT_STATUS[o.approval_status]}</Badge></div>
          <div className="small muted">{fmtDT(o.start_at)} → {fmtDT(o.end_at)}</div>
          <div className="small">{OT_TYPE[o.ot_type]} — {o.cause}</div>
        </Card>
      ))}
    </>
  );
}

export function ReportCard({ w }: { w: any }) {
  return (
    <Card to={`/reports/${w.id}`}>
      <div className="row"><b>{w.code}</b><Badge tone={SEV_TONE[w.severity]}>{SEVERITY[w.severity]}</Badge><span className="spacer" /><Badge tone={RP_TONE[w.status]}>{RP_STATUS[w.status]}</Badge></div>
      <div className="ellipsis" style={{ marginTop: 4 }}>{w.description}</div>
      <div className="small muted">{RP_CAT[w.category]} · {w.reporter_name}{w.department_name ? ` → ${w.department_name}` : ''}</div>
      <div className="chip-row">
        <span className="small">{STAGE[w.stage]}{w.holder_name ? ` · ${w.holder_name}` : ''}</span>
        {w.stage_due_at && w.stage !== 'closed' && (w.is_overdue ? <Badge tone="red">Quá SLA · {relDue(w.stage_due_at)}</Badge> : <Badge tone="gray">SLA {relDue(w.stage_due_at)}</Badge>)}
        {w.escalation_level > 0 && <Badge tone="red">Chuyển cấp {w.escalation_level}</Badge>}
        {w.safety_risk && <Badge tone="red">⚠ An toàn</Badge>}
      </div>
      {decisionText(w) && <div className="small trail" style={{ marginTop: 4 }}>↳ {decisionText(w)}</div>}
    </Card>
  );
}

function ClaimList({ sp, set }: P) {
  const status = sp.get('status') || '';
  const { me } = useAuth();
  const { data, error, loading } = useLoad(() => get('/quick-claims' + qs({ status })), [status]);
  return (
    <>
      <div className="quick"><Link className="btn primary" to="/quick/new">📞 Khai việc nhanh</Link><span /></div>
      <p className="small muted">Việc giao qua gọi điện/tin nhắn: ai khai trước thì người kia chỉ cần xác nhận. Xác nhận xong sẽ thành nhiệm vụ chính thức.</p>
      <div className="filters"><Select value={status} onChange={(v) => set({ status: v })} options={CLAIM_STATUS} placeholder="Mọi trạng thái" aria-label="Trạng thái" /></div>
      <ErrorBox error={error} />
      {loading && !data && <Loading />}
      {data && data.length === 0 && <Empty>Chưa có khai việc</Empty>}
      {data?.map((c: any) => {
        const needMe = c.status === 'pending' && c.counterpart_id === me?.member_id;
        return (
          <Card key={c.id} to={`/quick/${c.id}`} className={needMe ? 'pinned' : ''}>
            <div className="row"><span className="title" style={{ flex: 1 }}>{c.title}</span><Badge tone={CLAIM_TONE[c.status]}>{needMe ? 'Cần bạn xác nhận' : CLAIM_STATUS[c.status]}</Badge></div>
            <div className="small muted">{CHANNEL[c.channel]} · {fmtDT(c.occurred_at)} · {c.manager_name} → {c.assignee_name}</div>
            <div className="small">Người khai: {c.creator_name}</div>
          </Card>
        );
      })}
    </>
  );
}

export function LeaveList({ sp, set }: P) {
  const { me } = useAuth();
  const scope = sp.get('scope') || 'mine';
  const { data, error, loading } = useLoad(() => get('/leaves' + qs({ scope })), [scope]);
  const tabs: [string, string][] = [['mine', 'Của tôi']];
  if (me?.role !== 'employee') tabs.push(['approve', 'Cần tôi duyệt']);
  if (['owner', 'admin', 'hr'].includes(me?.role || '')) tabs.push(['hr', 'Đơn đã duyệt (nhân sự)']);
  return (
    <>
      <div className="quick"><Link className="btn primary" to="/leaves/new">🌴 Xin nghỉ phép</Link>{me?.role !== 'employee' ? <Link className="btn" to="/team">👥 Tình trạng nhân sự</Link> : <span />}</div>
      {tabs.length > 1 && <Tabs value={scope} onChange={(v) => set({ scope: v })} tabs={tabs} />}
      <ErrorBox error={error} />
      {loading && !data && <Loading />}
      {data && data.length === 0 && <Empty>Chưa có đơn nghỉ</Empty>}
      {data?.map((l: any) => (
        <Card key={l.id} to={`/leaves/${l.id}`}>
          <div className="row"><b>{l.code}</b><span className="title" style={{ flex: 1 }}>{scope === 'mine' ? '' : l.member_name}</span><Badge tone={LEAVE_TONE[l.status]}>{LEAVE_STATUS[l.status]}</Badge></div>
          <div className="small">{LEAVE_TYPE[l.leave_type]} · {fmtDT(l.start_at)} → {fmtDT(l.end_at)}</div>
          <div className="small muted">{hours(l.minutes)} · {l.reason}{l.late_notice ? ' · ⚠ báo trước ít hơn quy định' : ''}</div>
        </Card>
      ))}
    </>
  );
}

export function PermitList({ sp, set }: P) {
  const { me } = useAuth();
  const handler = me?.role !== 'employee' || (me?.headed_departments?.length ?? 0) > 0;
  const scope = sp.get('scope') || (me?.role === 'handler' ? 'handling' : 'mine');
  const status = sp.get('status') || ''; const review = sp.get('review') || '';
  const { data, error, loading } = useLoad(() => get('/permits' + qs({ scope, status, review })), [scope, status, review]);
  const tabs: [string, string][] = [['mine', 'Được cấp cho tôi']];
  if (isManagerRole(me?.role) || me?.role === 'hr') tabs.push(['requested', 'Tôi lập']);
  if (handler) tabs.push(['handling', 'Phòng ban tôi xử lý']);
  return (
    <>
      <p className="small muted">Giấy ra vào cổng, sử dụng xe/thiết bị… do người giao việc chuẩn bị, đính kèm công việc. Bảo vệ/thủ kho kiểm tra bằng mã QR.</p>
      {tabs.length > 1 && <Tabs value={scope} onChange={(v) => set({ scope: v, status: null, review: null })} tabs={tabs} />}
      {scope === 'handling' && (
        <div className="filters">
          <button className={`btn sm ${status === 'pending' ? 'primary' : ''}`} onClick={() => set({ status: status === 'pending' ? null : 'pending', review: null })}>Chờ cấp phép</button>
          <button className={`btn sm ${review ? 'primary' : ''}`} onClick={() => set({ review: review ? null : 'pending', status: null })}>Cần hậu kiểm</button>
        </div>
      )}
      <ErrorBox error={error} />
      {loading && !data && <Loading />}
      {data && data.length === 0 && <Empty>Không có giấy phép</Empty>}
      {data?.map((p: any) => (
        <Card key={p.id} to={`/permits/${p.id}`}>
          <div className="row"><span className="ichip teal" style={{ width: 36, height: 36 }}><Icon name={p.type_icon || 'permit'} size={18} /></span>
            <div style={{ flex: 1, minWidth: 0 }}><b>{p.code}</b> · {p.type_name}<div className="small muted ellipsis">{p.holder_name}{p.task_title ? ` · ${p.task_title}` : ''}</div></div>
            <Badge tone={PERMIT_TONE[p.status]}>{PERMIT_STATUS[p.status]}</Badge></div>
          <div className="small muted">{fmtDT(p.valid_from)} → {fmtDT(p.valid_to)}{p.mode === 'declaration' && !p.review_status ? ' · chờ hậu kiểm' : ''}{p.review_status === 'violation' ? ' · ⚠ vi phạm' : ''}</div>
        </Card>
      ))}
    </>
  );
}

/** Trạng thái quyết định: "đã được A chuyển đến B", "đã được A giao cho C giải quyết", kèm thay đổi của cấp trên. */
export function decisionText(w: any): string {
  const parts: string[] = [];
  const who = w.decided_by_name || w.manager_name;
  if (w.resolution_task_title) parts.push(`${who} đã giao cho ${w.assignee_name || '—'} giải quyết (${w.resolution_task_code})`);
  else if (w.department_name) parts.push(`${who} đã chuyển đến ${w.department_name}${w.assignee_name ? ' / ' + w.assignee_name : ''}`);
  else if (w.status === 'escalated') parts.push(`${who} đã chuyển lên cấp trên`);
  if (w.overridden_by_name) parts.push(`${w.overridden_by_name} đã thay đổi quyết định`);
  return parts.join(' · ');
}
