import { useSearchParams, Link } from 'react-router-dom';
import { get, qs } from '../api';
import { isManagerRole, useAuth } from '../auth';
import { Badge, Card, Empty, ErrorBox, Loading, Select, Tabs, useLoad } from '../ui';
import {
  OT_STATUS, OT_TONE, OT_TYPE, RP_CAT, RP_STATUS, RP_TONE, SEVERITY, SEV_TONE, STAGE, TASK_STATUS, TASK_TONE, WR_STATUS, WR_TONE, WR_TYPE,
  fmtD, fmtDT, hours, relDue, UNEXPECTED_CAT,
} from '../labels';

export default function Work() {
  const [sp, setSp] = useSearchParams();
  const tab = sp.get('tab') || 'tasks';
  const set = (patch: Record<string, string | null>) => {
    const n = new URLSearchParams(sp);
    for (const [k, v] of Object.entries(patch)) (v === null || v === '' ? n.delete(k) : n.set(k, v));
    setSp(n, { replace: true });
  };
  return (
    <div className="page">
      <Tabs value={tab} onChange={(t) => setSp({ tab: t }, { replace: true })}
        tabs={[['tasks', 'Nhiệm vụ'], ['records', 'Tự khai báo'], ['overtime', 'Tăng ca'], ['reports', 'Trở ngại']]} />
      {tab === 'tasks' && <TaskList sp={sp} set={set} />}
      {tab === 'records' && <RecordList sp={sp} set={set} />}
      {tab === 'overtime' && <OvertimeList sp={sp} set={set} />}
      {tab === 'reports' && <ReportList sp={sp} set={set} />}
    </div>
  );
}

type P = { sp: URLSearchParams; set: (p: Record<string, string | null>) => void };

function TaskList({ sp, set }: P) {
  const { me } = useAuth();
  const f = { status: sp.get('status') || '', groupId: sp.get('groupId') || '', mine: sp.get('mine') || '', overdue: sp.get('overdue') || '', search: sp.get('search') || '', unexpected: sp.get('unexpected') || '' };
  const groups = useLoad(() => get('/groups'), []);
  const { data, error, loading } = useLoad(() => get('/tasks' + qs({ ...f, limit: 100 })), [JSON.stringify(f)]);
  return (
    <>
      <div className="quick">
        {isManagerRole(me?.role) ? <Link className="btn primary" to="/tasks/new">＋ Giao việc</Link> : <Link className="btn" to="/work-records/new">📝 Ghi nhận công việc</Link>}
        <Link className="btn" to="/reports/new">⚠️ Báo cáo trở ngại</Link>
      </div>
      <input placeholder="Tìm theo tên hoặc mã nhiệm vụ…" value={f.search} onChange={(e) => set({ search: e.target.value })} aria-label="Tìm kiếm" />
      <div className="filters">
        <Select value={f.status} onChange={(v) => set({ status: v })} options={TASK_STATUS} placeholder="Mọi trạng thái" aria-label="Trạng thái" />
        <Select value={f.groupId} onChange={(v) => set({ groupId: v })} options={(groups.data || []).map((g: any) => [g.id, g.name])} placeholder="Mọi nhóm" aria-label="Nhóm" />
        <Select value={f.mine} onChange={(v) => set({ mine: v })} options={{ any: 'Việc của tôi', owner: 'Tôi chịu trách nhiệm' }} placeholder="Tất cả việc được xem" aria-label="Phạm vi" />
      </div>
      <div className="filters">
        <label className="check"><input type="checkbox" checked={f.overdue === 'true'} onChange={(e) => set({ overdue: e.target.checked ? 'true' : null })} /> Chỉ việc quá hạn</label>
        <label className="check"><input type="checkbox" checked={f.unexpected === 'true'} onChange={(e) => set({ unexpected: e.target.checked ? 'true' : null })} /> Việc đột xuất</label>
      </div>
      <ErrorBox error={error} />
      {loading && !data && <Loading />}
      {data && data.items.length === 0 && <Empty>Không có nhiệm vụ phù hợp</Empty>}
      {data?.items.map((t: any) => (
        <Card key={t.id} to={`/tasks/${t.id}`}>
          <div className="row"><span className="title" style={{ flex: 1 }}>{t.title}</span><Badge tone={TASK_TONE[t.status]}>{TASK_STATUS[t.status]}</Badge></div>
          <div className="small muted" style={{ marginTop: 4 }}>{t.code} · {t.group_name} · {t.owner_name}</div>
          <div className="chip-row">
            {t.is_overdue ? <Badge tone="red">⏰ Quá hạn · {relDue(t.due_at)}</Badge> : <Badge tone="gray">Hạn {fmtDT(t.due_at)}</Badge>}
            {t.is_unexpected && <Badge tone="purple">⚡ {UNEXPECTED_CAT[t.unexpected_category] || 'Đột xuất'}</Badge>}
            {t.impediment_confirmed && <Badge tone="amber">🛑 Có trở ngại đã xác nhận</Badge>}
            {t.priority === 'urgent' && <Badge tone="red">Khẩn</Badge>}
          </div>
        </Card>
      ))}
    </>
  );
}

function RecordList({ sp, set }: P) {
  const { me } = useAuth();
  const scope = sp.get('scope') || 'mine';
  const { data, error, loading } = useLoad(() => get('/work-records' + qs({ scope })), [scope]);
  const canReview = me?.role !== 'employee';
  return (
    <>
      <div className="quick"><Link className="btn primary" to="/work-records/new">📝 Ghi nhận công việc</Link><span /></div>
      <p className="small muted">Ghi nhận việc được giao ngoài app, việc bị ghi thiếu, ngoài giờ hoặc hỗ trợ nhóm khác. Quản lý bắt buộc phản hồi trong thời hạn.</p>
      <Tabs value={scope} onChange={(v) => set({ scope: v })} tabs={[['mine', 'Của tôi'], ...(canReview ? [['review', 'Cần tôi xác nhận'] as [string, string]] : []), ['all', 'Tất cả được xem']]} />
      <ErrorBox error={error} />
      {loading && !data && <Loading />}
      {data && data.length === 0 && <Empty>Chưa có bản ghi</Empty>}
      {data?.map((r: any) => (
        <Card key={r.id} to={`/work-records/${r.id}`}>
          <div className="row"><span className="title" style={{ flex: 1 }}>{r.title}</span><Badge tone={WR_TONE[r.status]}>{WR_STATUS[r.status]}</Badge></div>
          <div className="small muted" style={{ marginTop: 4 }}>{r.employee_name} · {WR_TYPE[r.record_type]} · {fmtD(r.work_date)} · {hours(r.claimed_minutes)}</div>
          <div className="chip-row">
            {r.overdue && <Badge tone="red">Quá hạn phản hồi</Badge>}
            {r.escalation_level > 0 && <Badge tone="red">Đã chuyển cấp {r.escalation_level}</Badge>}
            {r.consecutive_rejections > 0 && <Badge tone="amber">Từ chối liên tiếp: {r.consecutive_rejections}</Badge>}
            {r.overlap_warning && <Badge tone="amber">Trùng thời gian</Badge>}
            {r.status === 'submitted' || r.status === 'disputed' ? <span className="small muted">Hạn phản hồi: {fmtDT(r.review_due_at)} · {r.reviewer_name}</span> : null}
          </div>
        </Card>
      ))}
    </>
  );
}

function OvertimeList({ sp, set }: P) {
  const { me } = useAuth();
  const scope = sp.get('scope') || 'mine';
  const status = sp.get('status') || '';
  const { data, error, loading } = useLoad(() => get('/overtime-records' + qs({ scope, status })), [scope, status]);
  const total = (data || []).reduce((a: number, o: any) => a + o.minutes, 0);
  return (
    <>
      <div className="quick"><Link className="btn primary" to="/overtime/new">⏱ Ghi nhận tăng ca</Link><span /></div>
      <p className="small muted">Giờ tăng ca là chỉ số điều kiện vận hành, không cộng vào điểm hiệu suất và không tự tính lương.</p>
      <div className="filters">
        {me?.role !== 'employee' && <Select value={scope} onChange={(v) => set({ scope: v })} options={{ mine: 'Của tôi', team: 'Nhóm/cấp dưới' }} aria-label="Phạm vi" />}
        <Select value={status} onChange={(v) => set({ status: v })} options={OT_STATUS} placeholder="Mọi trạng thái" aria-label="Trạng thái" />
      </div>
      <ErrorBox error={error} />
      {loading && !data && <Loading />}
      {data && <div className="small muted">{data.length} bản ghi · tổng {hours(total)}</div>}
      {data && data.length === 0 && <Empty>Chưa có bản ghi tăng ca</Empty>}
      {data?.map((o: any) => (
        <Card key={o.id} to={`/overtime/${o.id}`}>
          <div className="row"><span className="title" style={{ flex: 1 }}>{hours(o.minutes)} · {o.member_name}</span><Badge tone={OT_TONE[o.approval_status]}>{OT_STATUS[o.approval_status]}</Badge></div>
          <div className="small muted">{fmtDT(o.start_at)} → {fmtDT(o.end_at)}</div>
          <div className="small">{OT_TYPE[o.ot_type]} — {o.cause}</div>
        </Card>
      ))}
    </>
  );
}

function ReportList({ sp, set }: P) {
  const { me } = useAuth();
  const scope = sp.get('scope') || 'mine';
  const status = sp.get('status') || '';
  const { data, error, loading } = useLoad(() => get('/workplace-reports' + qs({ scope, status })), [scope, status]);
  return (
    <>
      <div className="quick"><Link className="btn primary" to="/reports/new">⚠️ Báo cáo trở ngại</Link>{me?.role !== 'employee' ? <Link className="btn" to="/tech">🛠 Bảng kỹ thuật</Link> : <span />}</div>
      <Tabs value={scope} onChange={(v) => set({ scope: v })} tabs={[['mine', 'Tôi báo cáo'], ['handling', 'Tôi xử lý'], ['all', 'Tất cả được xem']]} />
      <div className="filters"><Select value={status} onChange={(v) => set({ status: v })} options={RP_STATUS} placeholder="Mọi trạng thái" aria-label="Trạng thái" /></div>
      <ErrorBox error={error} />
      {loading && !data && <Loading />}
      {data && data.length === 0 && <Empty>Không có báo cáo trở ngại</Empty>}
      {data?.map((w: any) => <ReportCard key={w.id} w={w} />)}
    </>
  );
}

export function ReportCard({ w }: { w: any }) {
  return (
    <Card to={`/reports/${w.id}`}>
      <div className="row"><b>{w.code}</b><Badge tone={SEV_TONE[w.severity]}>{SEVERITY[w.severity]}</Badge><span className="spacer" /><Badge tone={RP_TONE[w.status]}>{RP_STATUS[w.status]}</Badge></div>
      <div className="ellipsis" style={{ marginTop: 4 }}>{w.description}</div>
      <div className="small muted">{RP_CAT[w.category]} · {w.reporter_name}{w.department_name ? ` → ${w.department_name}` : ''}</div>
      <div className="chip-row">
        <span className="small">{STAGE[w.stage]}{w.holder_name ? ` · ${w.holder_name}` : ''}</span>
        {w.stage_due_at && w.stage !== 'closed' && (w.is_overdue ? <Badge tone="red">Quá SLA · {relDue(w.stage_due_at)}</Badge> : <Badge tone="gray">SLA {relDue(w.stage_due_at)}</Badge>)}
        {w.escalation_level > 0 && <Badge tone="red">Chuyển cấp {w.escalation_level}</Badge>}
        {w.safety_risk && <Badge tone="red">⚠ An toàn</Badge>}
      </div>
    </Card>
  );
}
