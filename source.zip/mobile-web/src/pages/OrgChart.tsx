import { useState } from 'react';
import { Link } from 'react-router-dom';
import { get } from '../api';
import { Avatar, Badge, ErrorBox, Header, Loading, Tabs, useLoad } from '../ui';
import { Icon } from '../icons';
import { ROLE } from '../labels';

function Node({ m, kids, byParent, depth }: { m: any; kids: any[]; byParent: Record<string, any[]>; depth: number }) {
  const [open, setOpen] = useState(depth < 2);
  return (
    <li>
      <div className="node">
        <Avatar userId={m.user_id} name={m.name} has={m.has_avatar} />
        <div className="grow">
          <Link to={`/people/${m.user_id}`}><b>{m.name}</b></Link>
          <div className="small muted ellipsis">{m.title || ROLE[m.role]}{m.department_name ? ` · ${m.department_name}` : ''}</div>
          <div className="chip-row" style={{ marginTop: 3 }}>
            <Badge tone="blue">{m.open_tasks} việc</Badge>
            {m.on_leave && <Badge tone="teal">Nghỉ phép</Badge>}
            {m.handover_code && <Badge tone="purple">Bàn giao {m.handover_code}</Badge>}
            {kids.length > 0 && <Badge>{kids.length} cấp dưới</Badge>}
          </div>
        </div>
        {kids.length > 0 && <button className="tg" onClick={() => setOpen(!open)} aria-label={open ? 'Thu gọn' : 'Mở rộng'} aria-expanded={open}><Icon name={open ? 'down' : 'chevron'} /></button>}
      </div>
      {open && kids.length > 0 && (
        <ul className="tree">{kids.map((k) => <Node key={k.id} m={k} kids={byParent[k.id] || []} byParent={byParent} depth={depth + 1} />)}</ul>
      )}
    </li>
  );
}

export default function OrgChart() {
  const { data, error, loading } = useLoad(() => get('/hr/org-chart'), []);
  const [view, setView] = useState('tree');
  if (loading && !data) return <Loading />;
  if (!data) return <div className="page"><ErrorBox error={error} /></div>;
  const ids = new Set(data.members.map((m: any) => m.id));
  const byParent: Record<string, any[]> = {};
  const roots: any[] = [];
  for (const m of data.members) {
    if (m.supervisor_member_id && ids.has(m.supervisor_member_id) && m.supervisor_member_id !== m.id) (byParent[m.supervisor_member_id] ||= []).push(m);
    else roots.push(m);
  }
  const byId = Object.fromEntries(data.members.map((m: any) => [m.id, m]));
  const Row = ({ m, tag }: { m: any; tag?: string }) => (
    <div className="node" style={{ margin: '6px 0' }}><Avatar userId={m.user_id} name={m.name} has={m.has_avatar} /><div className="grow"><b>{m.name}</b><div className="small muted">{tag || m.title || ROLE[m.role]} · {m.open_tasks} việc</div></div></div>
  );
  return (
    <>
      <Header title="Sơ đồ tổ chức" back="/hr" />
      <div className="page">
        <Tabs value={view} onChange={setView} tabs={[['tree', 'Theo cấp quản lý'], ['dept', 'Theo bộ phận'], ['group', 'Theo nhóm']]} />
        <p className="small muted">{data.company} · {data.members.length} nhân sự đang hoạt động</p>
        {view === 'tree' && <ul className="tree root">{roots.map((m) => <Node key={m.id} m={m} kids={byParent[m.id] || []} byParent={byParent} depth={0} />)}</ul>}
        {view === 'dept' && (
          <>
            {data.departments.map((d: any) => {
              const ms = data.members.filter((m: any) => m.department_id === d.id);
              return (
                <div key={d.id} className="grp">
                  <div className="grp-head"><Icon name="company" size={18} /><b>{d.name}</b><span className="n">{ms.length} người</span></div>
                  {d.head_member_id && byId[d.head_member_id] && <Row m={byId[d.head_member_id]} tag="Trưởng bộ phận" />}
                  {ms.filter((m: any) => m.id !== d.head_member_id).map((m: any) => <Row key={m.id} m={m} />)}
                </div>
              );
            })}
            <div className="grp"><div className="grp-head"><b>Chưa thuộc bộ phận</b><span className="n">{data.members.filter((m: any) => !m.department_id).length} người</span></div>
              {data.members.filter((m: any) => !m.department_id).map((m: any) => <Row key={m.id} m={m} />)}</div>
          </>
        )}
        {view === 'group' && data.groups.map((g: any) => (
          <div key={g.id} className="grp">
            <div className="grp-head"><Icon name="users" size={18} /><b>{g.name}</b><span className="n">{(g.member_ids || []).length} thành viên</span></div>
            {byId[g.manager_member_id] && <Row m={byId[g.manager_member_id]} tag="Quản lý nhóm" />}
            {(g.member_ids || []).filter((x: string) => x !== g.manager_member_id && byId[x]).map((x: string) => <Row key={x} m={byId[x]} />)}
          </div>
        ))}
      </div>
    </>
  );
}
