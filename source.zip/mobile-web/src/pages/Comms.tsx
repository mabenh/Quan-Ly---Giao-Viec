import { useEffect, useRef, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { download, get, post } from '../api';
import { useAuth } from '../auth';
import { Avatar, Badge, Card, Empty, ErrorBox, Field, Header, Loading, Tabs, useLoad } from '../ui';
import { Icon } from '../icons';
import { ContactButtons, fmtSec, useComms } from '../comms';
import { fmtDT } from '../labels';

const CALL_ST: Record<string, [string, string]> = { ended: ['Đã nghe', 'green'], missed: ['Nhỡ', 'red'], declined: ['Từ chối', 'amber'], cancelled: ['Đã hủy', 'gray'], ringing: ['Đang đổ chuông', 'blue'], active: ['Đang gọi', 'blue'], failed: ['Lỗi', 'red'] };

/** Nhật ký liên lạc: cuộc gọi trong app 30 ngày gần nhất, ghi âm, và khai báo công việc từ cuộc gọi. */
export function CallLog({ compact }: { compact?: boolean }) {
  const { data, error, loading } = useLoad(() => get('/calls'), []);
  const { startCall } = useComms();
  return (
    <>
      {!compact && <p className="small muted">Cuộc gọi thực hiện trong app (không qua nhà mạng, không hiển thị số). Nhật ký và ghi âm tự xóa sau 30 ngày; khi khai báo công việc từ cuộc gọi, ghi âm được giữ lại trong bản khai làm tài liệu.</p>}
      <ErrorBox error={error} />
      {loading && !data && <Loading />}
      {data && data.length === 0 && <Empty>Chưa có cuộc gọi nào trong 30 ngày qua. Gọi đồng nghiệp từ Danh bạ hoặc trang nhóm.</Empty>}
      {data?.map((c: any) => {
        const st = CALL_ST[c.status] || [c.status, 'gray'];
        return (
          <Card key={c.id}>
            <div className="row">
              <Avatar userId={c.other_user_id} name={c.other_name} has={false} />
              <div style={{ flex: 1, minWidth: 0 }}>
                <b>{c.direction === 'out' ? '↗' : '↙'} {c.other_name}</b>
                <div className="small muted">{fmtDT(c.created_at)}{c.duration_seconds ? ` · ${fmtSec(c.duration_seconds)}` : ''}{c.end_reason === 'limit' ? ' · hết 3 phút' : ''}</div>
              </div>
              <Badge tone={st[1]}>{st[0]}</Badge>
            </div>
            <div className="chip-row">
              {c.has_recording && <button className="btn sm" onClick={() => download(`/files/${c.recording_file_id}`, 'ghi-am-cuoc-goi.webm').catch((e) => alert(e.message))}><Icon name="mic" size={14} />Tải ghi âm</button>}
              {c.work_record_id ? <Link className="btn sm" to={`/work-records/${c.work_record_id}`}><Icon name="record" size={14} />Đã khai báo</Link>
                : c.status === 'ended' && <Link className="btn sm primary" to={`/work-records/new?callId=${c.id}`}><Icon name="record" size={14} />Khai báo công việc</Link>}
              <button className="btn sm" onClick={() => startCall(c.other_id, c.other_name)}><Icon name="phone" size={14} />Gọi lại</button>
              <span className="small muted">tự xóa {new Date(c.expires_at).toLocaleDateString('vi-VN')}</span>
            </div>
          </Card>
        );
      })}
    </>
  );
}

/** Liên lạc: danh bạ (chỉ tên), tin nhắn, nhật ký cuộc gọi. */
export function Contacts() {
  const [tab, setTab] = useState('people');
  const [qq, setQ] = useState('');
  const people = useLoad(() => get('/contacts'), []);
  const threads = useLoad(() => get('/messages/threads'), []);
  const { unread } = useComms();
  const list = (people.data || []).filter((m: any) => !qq || m.name.toLowerCase().includes(qq.toLowerCase()) || (m.groups || '').toLowerCase().includes(qq.toLowerCase()));
  return (
    <>
      <Header title="Liên lạc" back right={<Link className="btn sm" to="/settings/sound"><Icon name="settings" size={16} />Âm thanh</Link>} />
      <div className="page">
        <Tabs value={tab} onChange={setTab} tabs={[['people', 'Danh bạ'], ['messages', <>Tin nhắn {unread > 0 && <Badge tone="red">{unread}</Badge>}</>], ['calls', 'Nhật ký cuộc gọi']]} />
        {tab === 'people' && <>
          <p className="small muted">Số điện thoại được ẩn. Gọi, nhắn tin và Zalo đều chuyển qua ứng dụng. Mỗi cuộc gọi tối đa 3 phút.</p>
          <input placeholder="Tìm theo tên hoặc nhóm…" value={qq} onChange={(e) => setQ(e.target.value)} aria-label="Tìm" />
          <ErrorBox error={people.error} />{people.loading && !people.data && <Loading />}
          {list.map((m: any) => (
            <Card key={m.id}>
              <div className="row"><Avatar userId={m.user_id} name={m.name} has={m.has_avatar} />
                <div style={{ flex: 1, minWidth: 0 }}><b>{m.name}</b><div className="small muted ellipsis">{m.title || ''}{m.groups ? ` · ${m.groups}` : ''}</div></div></div>
              <ContactButtons memberId={m.id} name={m.name} zalo={m.has_zalo} />
            </Card>
          ))}
        </>}
        {tab === 'messages' && <>
          <ErrorBox error={threads.error} />{threads.loading && !threads.data && <Loading />}
          {threads.data && threads.data.length === 0 && <Empty>Chưa có tin nhắn. Chọn người trong Danh bạ để bắt đầu.</Empty>}
          {threads.data?.map((t: any) => (
            <Card key={t.other_id} to={`/messages/${t.other_id}`} className={t.unread ? 'pinned' : ''}>
              <div className="row"><Avatar userId={t.other_user_id} name={t.other_name} has={false} />
                <div style={{ flex: 1, minWidth: 0 }}><b>{t.other_name}</b><div className="small muted ellipsis">{t.last_mine ? 'Bạn: ' : ''}{t.last_body}</div></div>
                {t.unread > 0 ? <Badge tone="red">{t.unread}</Badge> : <span className="small muted">{fmtDT(t.last_at)}</span>}</div>
            </Card>
          ))}
          <p className="small muted">Tin nhắn tự xóa sau 30 ngày.</p>
        </>}
        {tab === 'calls' && <CallLog />}
      </div>
    </>
  );
}

/** Nhắn tin trực tiếp trong app. */
export function Chat() {
  const { memberId } = useParams();
  const { me } = useAuth();
  const { startCall } = useComms();
  const { data, error, reload, setData } = useLoad(() => get(`/messages/with/${memberId}`), [memberId]);
  const [text, setText] = useState('');
  const [busy, setBusy] = useState(false);
  const end = useRef<HTMLDivElement | null>(null);
  useEffect(() => { const t = setInterval(reload, 4000); return () => clearInterval(t); }, [reload]);
  useEffect(() => { end.current?.scrollIntoView({ block: 'end' }); }, [data?.items?.length]);
  const send = async () => {
    if (!text.trim()) return; setBusy(true);
    try { const m = await post('/messages', { to: memberId, body: text.trim() }); setText(''); setData((d: any) => ({ ...d, items: [...d.items, m] })); } catch (e: any) { alert(e.message); } finally { setBusy(false); }
  };
  return (
    <>
      <Header title={data?.other?.name || 'Tin nhắn'} back="/contacts" right={data?.other && <button className="btn sm" onClick={() => startCall(data.other.id, data.other.name)}><Icon name="phone" size={16} />Gọi</button>} />
      <div className="page chat">
        <ErrorBox error={error} />
        {!data && !error && <Loading />}
        {data && <p className="small muted" style={{ textAlign: 'center' }}>Tin nhắn trong app — tự xóa sau {data.retention_days} ngày. Việc được giao qua tin nhắn, hãy khai báo công việc để có căn cứ.</p>}
        {data?.items.map((m: any) => (
          <div key={m.id} className={`bubble ${m.sender_id === me?.member_id ? 'mine' : ''}`}><div>{m.body}</div><span className="small muted">{fmtDT(m.created_at)}</span></div>
        ))}
        <div ref={end} />
      </div>
      <div className="chat-input">
        <textarea rows={1} value={text} onChange={(e) => setText(e.target.value)} placeholder="Nhập tin nhắn…" onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); } }} />
        <button className="btn primary" disabled={busy || !text.trim()} onClick={send}>Gửi</button>
      </div>
    </>
  );
}

/** Cài đặt âm thanh & thông báo. */
export function SoundSettings() {
  const { prefs, setPrefs } = useComms();
  const [err, setErr] = useState<string | null>(null);
  if (!prefs) return <><Header title="Âm thanh & thông báo" back /><div className="page"><Loading /></div></>;
  const save = (p: any) => setPrefs(p).catch((e) => setErr(e.message));
  const MUTE: [string, string][] = [['calls', 'Cuộc gọi đến'], ['messages', 'Tin nhắn'], ['tasks', 'Nhiệm vụ'], ['reports', 'Báo cáo trở ngại'], ['support', 'Yêu cầu hỗ trợ'], ['department', 'Tin phòng ban']];
  return (
    <>
      <Header title="Âm thanh & thông báo" back />
      <div className="page">
        <div className="section-title">Cuộc gọi</div>
        <Card>
          <label className="check"><input type="checkbox" checked={prefs.ringtone} onChange={(e) => save({ ringtone: e.target.checked })} /> Chuông khi có cuộc gọi đến</label>
          <Field label={`Âm lượng chuông: ${prefs.ringVolume}%`}><input type="range" min={0} max={100} step={10} value={prefs.ringVolume} onChange={(e) => save({ ringVolume: Number(e.target.value) })} /></Field>
          <label className="check"><input type="checkbox" checked={prefs.vibrate} onChange={(e) => save({ vibrate: e.target.checked })} /> Rung</label>
          <p className="small muted">Mỗi cuộc gọi tối đa {fmtSec(prefs.call_limit_seconds)} phút để tránh trò chuyện dài ảnh hưởng hiệu suất. Nhật ký liên lạc lưu {prefs.retention_days} ngày.</p>
        </Card>
        <div className="section-title">Thông báo</div>
        <Card>
          <label className="check"><input type="checkbox" checked={prefs.messageSound} onChange={(e) => save({ messageSound: e.target.checked })} /> Âm báo tin nhắn mới</label>
          <label className="check"><input type="checkbox" checked={prefs.notificationSound} onChange={(e) => save({ notificationSound: e.target.checked })} /> Âm báo thông báo</label>
          <div className="small muted" style={{ marginTop: 8 }}>Tắt tiếng theo loại:</div>
          {MUTE.map(([k, l]) => <label key={k} className="check" style={{ margin: '2px 0' }}><input type="checkbox" checked={!!prefs.mute[k]} onChange={(e) => save({ mute: { [k]: e.target.checked } })} /> Tắt tiếng {l.toLowerCase()}</label>)}
        </Card>
        <div className="section-title">Giờ yên lặng</div>
        <Card>
          <label className="check"><input type="checkbox" checked={prefs.quietHours.enabled} onChange={(e) => save({ quietHours: { ...prefs.quietHours, enabled: e.target.checked } })} /> Không đổ chuông/âm báo trong khung giờ</label>
          <div className="grid2">
            <Field label="Từ"><input type="time" value={prefs.quietHours.start} onChange={(e) => save({ quietHours: { ...prefs.quietHours, start: e.target.value } })} /></Field>
            <Field label="Đến"><input type="time" value={prefs.quietHours.end} onChange={(e) => save({ quietHours: { ...prefs.quietHours, end: e.target.value } })} /></Field>
          </div>
          <p className="small muted">Trong giờ yên lặng, cuộc gọi vẫn hiển thị nhưng không đổ chuông.</p>
        </Card>
        <ErrorBox error={err} />
      </div>
    </>
  );
}
