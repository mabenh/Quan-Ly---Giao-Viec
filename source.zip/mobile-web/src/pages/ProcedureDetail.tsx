import { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { get, patch, post } from '../api';
import { isHRRole, useAuth } from '../auth';
import { Badge, Card, ErrorBox, Field, Header, Loading, Select, useAction, useLoad } from '../ui';
import { Icon } from '../icons';
import { AUDIENCE, REMINDER, fmtDT } from '../labels';

export default function ProcedureDetail() {
  const { id } = useParams();
  const isNew = id === 'new';
  const nav = useNavigate();
  const { me } = useAuth();
  const { data: p, error, loading, setData } = useLoad(() => (isNew ? Promise.resolve(null) : get(`/hr/procedures/${id}`)), [id]);
  const depts = useLoad(() => get('/company/departments'), []);
  const [edit, setEdit] = useState(isNew);
  const [f, setF] = useState<any>({ title: '', category: 'Giao việc', summary: '', audience: 'all', departmentId: '', reminder: 'weekly', steps: [{ title: '', detail: '', role: '' }], notify: true });
  const a = useAction();
  useEffect(() => { if (p) setF({ title: p.title, category: p.category || '', summary: p.summary || '', audience: p.audience, departmentId: p.department_id || '', reminder: p.reminder, steps: p.steps.length ? p.steps : [{ title: '', detail: '' }], notify: true }); }, [p]);
  if (!isNew && loading && !p) return <Loading />;
  if (!isNew && !p) return <div className="page"><ErrorBox error={error} /></div>;
  const can = isHRRole(me?.role);
  const setStep = (i: number, x: any) => setF({ ...f, steps: f.steps.map((s: any, j: number) => (j === i ? { ...s, ...x } : s)) });
  const save = () => a.run(async () => {
    const body = { title: f.title, category: f.category, summary: f.summary, audience: f.audience, departmentId: f.audience === 'department' ? f.departmentId : null, reminder: f.reminder,
      steps: f.steps.filter((s: any) => s.title.trim()).map((s: any) => ({ title: s.title, detail: s.detail || '', role: s.role || undefined })) };
    if (isNew) { const r = await post('/hr/procedures', body); nav(`/hr/procedures/${r.id}`, { replace: true }); }
    else { setData(await patch(`/hr/procedures/${id}`, { ...body, notify: f.notify })); setEdit(false); }
  });
  if (edit && can) return (
    <>
      <Header title={isNew ? 'Thêm quy trình' : 'Sửa quy trình'} back />
      <div className="page">
        <Field label="Tên quy trình" required><input value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} /></Field>
        <div className="grid2">
          <Field label="Nhóm"><input value={f.category} onChange={(e) => setF({ ...f, category: e.target.value })} /></Field>
          <Field label="Nhắc tin vắn"><Select value={f.reminder} onChange={(v) => setF({ ...f, reminder: v })} options={REMINDER} /></Field>
        </div>
        <Field label="Áp dụng cho"><Select value={f.audience} onChange={(v) => setF({ ...f, audience: v })} options={AUDIENCE} /></Field>
        {f.audience === 'department' && <Field label="Bộ phận"><Select value={f.departmentId} onChange={(v) => setF({ ...f, departmentId: v })} options={(depts.data || []).map((d: any) => [d.id, d.name])} placeholder="— Chọn —" /></Field>}
        <Field label="Tóm tắt"><textarea value={f.summary} onChange={(e) => setF({ ...f, summary: e.target.value })} /></Field>
        <div className="section-title">Các bước</div>
        {f.steps.map((s: any, i: number) => (
          <Card key={i}>
            <div className="row" style={{ display: 'flex', gap: 6 }}><b>Bước {i + 1}</b><span className="spacer" /><button className="icon-btn" aria-label="Xóa bước" onClick={() => setF({ ...f, steps: f.steps.filter((_: any, j: number) => j !== i) })}>✕</button></div>
            <input placeholder="Tên bước" value={s.title} onChange={(e) => setStep(i, { title: e.target.value })} />
            <textarea placeholder="Nội dung chi tiết" value={s.detail} onChange={(e) => setStep(i, { detail: e.target.value })} style={{ marginTop: 6 }} />
            <input placeholder="Vai trò thực hiện (tùy chọn)" value={s.role || ''} onChange={(e) => setStep(i, { role: e.target.value })} style={{ marginTop: 6 }} />
          </Card>
        ))}
        <button className="btn sm" onClick={() => setF({ ...f, steps: [...f.steps, { title: '', detail: '' }] })}><Icon name="plus" size={16} />Thêm bước</button>
        {!isNew && <label className="check"><input type="checkbox" checked={f.notify} onChange={(e) => setF({ ...f, notify: e.target.checked })} /> Thông báo cập nhật cho người áp dụng</label>}
        <ErrorBox error={a.error} />
        <div className="actions"><button className="btn primary" disabled={a.busy} onClick={save}>Lưu</button>{!isNew && <button className="btn" onClick={() => setEdit(false)}>Hủy</button>}</div>
      </div>
    </>
  );
  return (
    <>
      <Header title="Quy trình" back="/hr/procedures" right={can ? <button className="btn sm" onClick={() => setEdit(true)}>Sửa</button> : undefined} />
      <div className="page">
        <h2>{p.title}</h2>
        <div className="chip-row">
          <Badge tone="blue">{p.category}</Badge><Badge>{p.audience === 'department' ? p.department_name : AUDIENCE[p.audience]}</Badge>
          <Badge tone="teal">Nhắc: {REMINDER[p.reminder]}</Badge>{!p.active && <Badge tone="red">Ngừng áp dụng</Badge>}
        </div>
        {p.summary && <Card><div className="crit">{p.summary}</div></Card>}
        <div className="section-title">Các bước thực hiện</div>
        <Card>
          <ol className="steps">
            {p.steps.map((s: any, i: number) => <li key={i}>{s.role && <div className="role">{s.role}</div>}<b>{s.title}</b><div className="small">{s.detail}</div></li>)}
          </ol>
        </Card>
        {p.reference && <div className="alert info small"><b>Nguồn tham khảo:</b> {p.reference}</div>}
        <p className="small muted">Phiên bản {p.version}{p.updated_by_name ? ` · cập nhật bởi ${p.updated_by_name}` : ''} · {fmtDT(p.updated_at)}</p>
      </div>
    </>
  );
}
