import { useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { del, download, get, patch, post } from '../api';
import { useAuth } from '../auth';
import { Badge, Card, Empty, ErrorBox, Field, Header, Loading, Select, Sheet, Tabs, useAction, useLoad, Note } from '../ui';
import { fmtDT, ROLE } from '../labels';
import { Icon } from '../icons';

const VIS: Record<string, string> = { only_me: 'Chỉ mình tôi', related: 'Người liên quan (cùng nhóm, cấp trên/dưới trực tiếp)', company: 'Thành viên công ty' };
export const DSR_TYPE: Record<string, string> = { access: 'Xem dữ liệu', export: 'Tải dữ liệu', correction: 'Đính chính', deletion: 'Xóa dữ liệu', restriction: 'Hạn chế xử lý', consent_withdrawal: 'Rút lại đồng ý' };
export const DSR_STATUS: Record<string, [string, string]> = {
  submitted: ['Đã gửi', 'blue'], in_review: ['Đang xem xét', 'amber'], completed: ['Đã thực hiện', 'green'], partially_completed: ['Thực hiện một phần', 'amber'], rejected: ['Không thể thực hiện', 'red'], cancelled: ['Đã hủy', 'gray'],
};
export const ACCESS_ACTION: Record<string, string> = {
  'profile.view': 'Xem hồ sơ của bạn', 'file.download': 'Tải tệp', 'auth.login': 'Đăng nhập', 'auth.throttled': 'Tạm khóa đăng nhập do sai nhiều lần', 'privacy.updated': 'Đổi thiết lập quyền riêng tư',
  'data.export_self': 'Tạo bản tải dữ liệu', 'data.export_download': 'Tải bản dữ liệu', 'dsr.create': 'Gửi yêu cầu dữ liệu', 'dsr.resolve': 'Xử lý yêu cầu dữ liệu của bạn', 'avatar.deleted': 'Xóa ảnh đại diện',
};
const DELETION_SCOPE: Record<string, string> = { avatar: 'Ảnh đại diện', cv_profile: 'Hồ sơ CV (học vấn, kỹ năng, ngày sinh, địa chỉ…)', self_history: 'Lịch sử làm việc tự khai', notifications: 'Thông báo cũ' };

export default function Privacy() {
  const { me } = useAuth();
  const [sp, setSp] = useSearchParams();
  const tab = sp.get('tab') || 'visibility';
  const tabs: [string, string][] = [['visibility', 'Hiển thị'], ['consents', 'Đồng ý'], ['data', 'Dữ liệu'], ['requests', 'Yêu cầu'], ['access', 'Lịch sử truy cập']];
  if (me?.company_id) tabs.push(['contacts', 'Liên hệ an toàn']);
  return (
    <>
      <Header title="Quyền riêng tư & dữ liệu" back="/me" />
      <div className="page">
        <Tabs value={tab} onChange={(t) => setSp({ tab: t }, { replace: true })} tabs={tabs} />
        {tab === 'visibility' && <Visibility />}
        {tab === 'consents' && <Consents />}
        {tab === 'data' && <DataTab />}
        {tab === 'requests' && <Requests />}
        {tab === 'access' && <AccessLog />}
        {tab === 'contacts' && <Contacts />}
      </div>
    </>
  );
}

function Visibility() {
  const { data, error, setData } = useLoad(() => get('/me/privacy'), []);
  const a = useAction();
  if (!data) return <><ErrorBox error={error} /><Loading /></>;
  return (
    <>
      <Note>Chọn ai được xem từng thông tin của bạn. Dữ liệu cá nhân mặc định riêng tư; chỉ mở khi có nhu cầu công việc.</Note>
      {data.fields.map((f: any) => (
        <Field key={f.key} label={f.label} hint={f.visibility === f.default ? 'Mặc định' : undefined}>
          <Select value={f.visibility} onChange={(v) => a.run(async () => setData(await patch('/me/privacy', { fields: { [f.key]: v } })))} options={VIS} />
        </Field>
      ))}
      <ErrorBox error={a.error} />
      <div className="alert info small">{data.notes.map((n: string, i: number) => <div key={i}>• {n}</div>)}</div>
    </>
  );
}

function Consents() {
  const { data, setData } = useLoad(() => get('/me/privacy'), []);
  const a = useAction();
  if (!data) return <Loading />;
  return (
    <>
      <Note>Mỗi mục đích được đồng ý riêng. Rút lại đồng ý sẽ dừng xử lý cho mục đích đó từ thời điểm rút; dữ liệu đã có không tự xóa — bạn có thể gửi yêu cầu xóa riêng.</Note>
      {Object.entries(data.consents).map(([k, c]: any) => (
        <Card key={k}>
          <div className="row"><b style={{ flex: 1 }}>{c.label}</b><Badge tone={c.status === 'granted' ? 'green' : 'gray'}>{c.status === 'granted' ? 'Đã đồng ý' : c.status === 'withdrawn' ? 'Đã rút lại' : 'Chưa đồng ý'}</Badge></div>
          <div className="small muted" style={{ margin: '4px 0 8px' }}>{c.detail}</div>
          {c.at && <div className="small muted">Cập nhật: {fmtDT(c.at)}</div>}
          <button className={`btn sm ${c.status === 'granted' ? '' : 'primary'}`} disabled={a.busy} onClick={() => a.run(async () => setData(await patch('/me/privacy', { consents: { [k]: c.status !== 'granted' } })))}>
            {c.status === 'granted' ? 'Rút lại đồng ý' : 'Đồng ý'}
          </button>
        </Card>
      ))}
      <ErrorBox error={a.error} />
    </>
  );
}

function DataTab() {
  const { data } = useLoad(() => get('/me/data'), []);
  const [pw, setPw] = useState(''); const [open, setOpen] = useState(false); const [res, setRes] = useState<any>(null);
  const a = useAction();
  return (
    <>
      <div className="row" style={{ gap: 8, margin: '6px 0 10px' }}>
        <button className="btn primary" onClick={() => setOpen(true)}><Icon name="download" size={16} />Tải dữ liệu của tôi</button>
      </div>
      <Note>Dữ liệu đang được lưu về bạn, mục đích, thời hạn lưu dự kiến và ai nhận được. Chúng tôi không bán dữ liệu cá nhân và không dùng dữ liệu công việc để huấn luyện AI.</Note>
      {!data && <Loading />}
      {data?.map((d: any) => (
        <Card key={d.key}>
          <b>{d.label}</b>
          <div className="small">{d.items}</div>
          <div className="kv small"><span>Mục đích</span><b>{d.purpose}</b></div>
          <div className="kv small"><span>Thời hạn lưu</span><b>{d.retention}</b></div>
          <div className="kv small"><span>Ai nhận được</span><b>{d.recipients}</b></div>
        </Card>
      ))}
      <Sheet open={open} onClose={() => { setOpen(false); setRes(null); setPw(''); }} title="Tải dữ liệu của tôi">
        {!res ? (
          <>
            <p className="small">Bạn đang yêu cầu xuất dữ liệu cá nhân. Hoạt động này được ghi nhận để bảo vệ dữ liệu. Tệp chỉ tải được trong thời gian ngắn rồi tự xóa.</p>
            <Field label="Nhập lại mật khẩu để xác nhận" required><input type="password" value={pw} onChange={(e) => setPw(e.target.value)} autoComplete="current-password" /></Field>
            <ErrorBox error={a.error} />
            <button className="btn primary block" disabled={a.busy || !pw} onClick={() => a.run(async () => setRes(await post('/me/data-export', { password: pw })))}>Tạo tệp dữ liệu</button>
          </>
        ) : (
          <>
            <div className="alert ok small">{res.message}</div>
            <ErrorBox error={a.error} />
            <button className="btn primary block" onClick={() => a.run(() => download(`/me/data-export/${res.id}`, `du-lieu-cua-toi-${res.code}.json`))}><Icon name="download" size={16} />Tải tệp ({res.code})</button>
          </>
        )}
      </Sheet>
    </>
  );
}

function Requests() {
  const { me } = useAuth();
  const { data, reload } = useLoad(() => get('/me/data-requests'), []);
  const [form, setForm] = useState<string | null>(null);
  const a = useAction();
  return (
    <>
      {me?.company_id && (
        <div className="actions">
          <button className="btn" onClick={() => setForm('correction')}>Đính chính</button>
          <button className="btn" onClick={() => setForm('restriction')}>Hạn chế xử lý</button>
          <button className="btn" onClick={() => setForm('deletion')}>Yêu cầu xóa</button>
        </div>
      )}
      <Note>Mỗi yêu cầu có mã hồ sơ, người xử lý và hạn xử lý. Dữ liệu có nghĩa vụ lưu trữ hợp lệ sẽ không bị xóa mù — bạn sẽ được giải thích phần tiếp tục lưu và lý do.</Note>
      {data && data.length === 0 && <Empty>Chưa có yêu cầu</Empty>}
      {data?.map((r: any) => (
        <Card key={r.id}>
          <div className="row"><b>{r.code}</b><span className="small" style={{ flex: 1 }}> · {DSR_TYPE[r.request_type]}</span><Badge tone={DSR_STATUS[r.status][1]}>{DSR_STATUS[r.status][0]}</Badge></div>
          {r.details && <div className="small">{r.details}</div>}
          {r.field_key && <div className="small muted">Trường: {r.field_key} → {r.proposed_value}</div>}
          <div className="small muted">Gửi {fmtDT(r.created_at)}{r.due_at && ['submitted', 'in_review'].includes(r.status) ? ` · hạn xử lý ${fmtDT(r.due_at)}` : ''}</div>
          {r.resolution && <div className="small" style={{ marginTop: 4 }}>Kết quả: {r.resolution}</div>}
          {r.retained_note && <div className="small muted">Tiếp tục lưu: {r.retained_note}</div>}
          {r.downloadable && <button className="btn sm" onClick={() => a.run(() => download(`/me/data-export/${r.id}`, `du-lieu-cua-toi-${r.code}.json`))}><Icon name="download" size={16} />Tải lại (đến {fmtDT(r.file_expires_at)})</button>}
          {['submitted', 'in_review'].includes(r.status) && <button className="btn sm" onClick={() => a.run(async () => { await post(`/me/data-requests/${r.id}/cancel`); reload(); })}>Hủy yêu cầu</button>}
        </Card>
      ))}
      <ErrorBox error={a.error} />
      <Sheet open={!!form} onClose={() => setForm(null)} title={form ? DSR_TYPE[form] : ''}>{form && <RequestForm type={form} onDone={() => { setForm(null); reload(); }} />}</Sheet>
    </>
  );
}

function RequestForm({ type, onDone }: { type: string; onDone: () => void }) {
  const [field, setField] = useState('name'); const [val, setVal] = useState(''); const [details, setDetails] = useState(''); const [scope, setScope] = useState<string[]>([]);
  const a = useAction();
  return (
    <>
      {type === 'correction' && (
        <>
          <Field label="Thông tin cần sửa"><Select value={field} onChange={setField} options={{ name: 'Họ và tên', title: 'Chức danh', department: 'Phòng ban', other: 'Khác' }} /></Field>
          <Field label="Giá trị đề nghị"><input value={val} onChange={(e) => setVal(e.target.value)} /></Field>
        </>
      )}
      {type === 'deletion' && (
        <Field label="Dữ liệu muốn xóa">
          {Object.entries(DELETION_SCOPE).map(([k, l]) => <label key={k} className="check"><input type="checkbox" checked={scope.includes(k)} onChange={(e) => setScope(e.target.checked ? [...scope, k] : scope.filter((x) => x !== k))} /> {l}</label>)}
          <span className="hint">Ảnh và hồ sơ CV bạn cũng có thể tự xóa ngay trong mục Hồ sơ.</span>
        </Field>
      )}
      <Field label={type === 'restriction' ? 'Bạn muốn hạn chế việc xử lý nào?' : 'Mô tả / căn cứ'} required hint={type === 'correction' ? 'Có thể đính kèm tài liệu chứng minh khi người xử lý yêu cầu' : undefined}>
        <textarea value={details} onChange={(e) => setDetails(e.target.value)} placeholder={type === 'restriction' ? 'VD: Không cho quản lý xem hồ sơ CV của tôi' : ''} />
      </Field>
      <ErrorBox error={a.error} />
      <button className="btn primary block" disabled={a.busy || details.trim().length < 5} onClick={() => a.run(async () => {
        await post('/me/data-requests', { type, details, ...(type === 'correction' ? { fieldKey: field, proposedValue: val } : {}), ...(type === 'deletion' ? { scope } : {}) });
        onDone();
      })}>Gửi yêu cầu</button>
    </>
  );
}

function AccessLog() {
  const { data } = useLoad(() => get('/me/privacy-access-log'), []);
  return (
    <>
      <Note>Các lần truy cập đáng kể vào dữ liệu của bạn. Nếu thấy truy cập đáng ngờ, bạn có thể báo cáo để được xem xét.</Note>
      {!data && <Loading />}
      {data && data.length === 0 && <Empty>Chưa có lượt truy cập nào được ghi nhận</Empty>}
      {data?.map((l: any) => (
        <Card key={l.id}>
          <div className="row"><b style={{ flex: 1 }}>{ACCESS_ACTION[l.action] || l.action}</b>{l.result === 'denied' && <Badge tone="amber">Bị từ chối</Badge>}</div>
          <div className="small muted">{l.actor_name}{l.actor_role ? ` · ${ROLE[l.actor_role] || l.actor_role}` : ''} · {fmtDT(l.created_at)}</div>
          {l.reason && l.result === 'allowed' && <div className="small">Mục đích: {l.reason}</div>}
          {l.actor_name !== 'Bạn' && l.actor_member_id && (
            <Link className="small" to={`/conduct/new?category=privacy_data&subcode=DAT-01&objectType=access_log&objectLabel=${encodeURIComponent(`${ACCESS_ACTION[l.action] || l.action} lúc ${fmtDT(l.created_at)}`)}&reported=${l.actor_member_id}`}>Báo cáo truy cập đáng ngờ</Link>
          )}
        </Card>
      ))}
    </>
  );
}

function Contacts() {
  const { data, setData } = useLoad(() => get('/me/contact-blocks'), []);
  const members = useLoad(() => get('/company/members?status=active'), []);
  const [pick, setPick] = useState('');
  const a = useAction();
  return (
    <>
      <Note>Giới hạn liên hệ phi công việc: người được chọn sẽ không thấy số điện thoại của bạn và không gọi/nhắn/Zalo được từ ứng dụng. Thông báo nghiệp vụ thiết yếu (giao việc, nghiệm thu…) vẫn hoạt động bình thường.</Note>
      <div className="row" style={{ gap: 6 }}>
        <Select value={pick} onChange={setPick} options={(members.data || []).map((m: any) => [m.id, m.name])} placeholder="— Chọn người —" />
        <button className="btn" disabled={!pick || a.busy} onClick={() => a.run(async () => { setData(await post('/me/contact-blocks', { memberId: pick })); setPick(''); })}>Giới hạn</button>
      </div>
      <ErrorBox error={a.error} />
      {data?.map((b: any) => (
        <Card key={b.member_id}><div className="row"><span style={{ flex: 1 }}>{b.name}</span><button className="btn sm" onClick={() => a.run(async () => setData(await del(`/me/contact-blocks/${b.member_id}`)))}>Bỏ giới hạn</button></div></Card>
      ))}
      <Note style={{ marginTop: 12 }}>Nếu bạn bị quấy rối, đe dọa hoặc gây áp lực, hãy <Link to="/conduct/new">báo cáo hành vi cần xem xét</Link> — hồ sơ chỉ được chia sẻ với đầu mối xử lý.</Note>
    </>
  );
}
