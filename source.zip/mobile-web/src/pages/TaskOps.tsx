import { useState } from 'react';
import { Link } from 'react-router-dom';
import { get, post } from '../api';
import { Badge, Card, ErrorBox, Field, KV, Select, Sheet, useAction, useLoad } from '../ui';
import { Icon } from '../icons';
import { HO_STATUS, IMPORTANCE, PRIORITY, RISK, TIME_CAT, fmtDT, mins } from '../labels';
import { SwitchForm } from '../session';

/** Phần vận hành của nhiệm vụ: chuỗi đơn hàng, cảnh báo, phiên, bàn giao liên bộ phận, sản lượng & chất lượng, thời gian. */
export function TaskOps({ t, reload }: { t: any; reload: () => void }) {
  const p = t.ops_permissions || {};
  const [sheet, setSheet] = useState<string | null>(null);
  const [cur, setCur] = useState<any>(null);
  const a = useAction();
  const done = (fn: () => Promise<any>) => a.run(async () => { await fn(); setSheet(null); setCur(null); reload(); });
  const risk = RISK[t.risk] || RISK.normal;
  const pendingIn = (t.handovers_in || []).filter((h: any) => h.status === 'submitted');
  return (
    <>
      <div className="chip-row">
        {t.chain && <Link to={`/chains/${t.chain.id}`}><Badge tone="blue">⛓ {t.chain.code} · {t.chain.progress}%</Badge></Link>}
        {t.risk && t.risk !== 'done' && <Badge tone={risk[1]}>{risk[0]}</Badge>}
        {t.location && <Badge tone="teal">📍 {t.location.name}{t.location_required ? ' (bắt buộc)' : ''}</Badge>}
        {t.importance && t.importance !== 'normal' && <Badge tone="amber">{IMPORTANCE[t.importance]}</Badge>}
        {t.early_start_reason && <Badge tone="purple">Bắt đầu sớm: {t.early_start_reason}</Badge>}
      </div>
      {pendingIn.length > 0 && <div className="alert warn small">Có {pendingIn.length} bàn giao từ công đoạn trước cần tiếp nhận trước khi bắt đầu.</div>}
      <div className="actions">
        {p.can_session && <button className="btn primary" onClick={() => setSheet('session')}><Icon name="timer" size={18} />Bắt đầu phiên làm việc</button>}
        {p.can_record_production && <button className="btn" onClick={() => setSheet('prod')}><Icon name="boxes" size={18} />Ghi nhận sản lượng</button>}
        {p.can_send_handover && <button className="btn" onClick={() => setSheet('handover')}><Icon name="route" size={18} />Gửi bàn giao</button>}
        {p.can_early_start && <button className="btn" onClick={() => setSheet('early')}>Cho phép bắt đầu sớm</button>}
        {p.can_set_priority && !['completed', 'cancelled'].includes(t.status) && <button className="btn" onClick={() => setSheet('priority')}>Ưu tiên</button>}
      </div>
      <ErrorBox error={a.error} />

      {(t.handovers_in?.length > 0 || t.handovers_out?.length > 0) && <div className="section-title">Bàn giao liên bộ phận</div>}
      {t.handovers_in?.map((h: any) => (
        <Card key={h.id}>
          <div className="row"><b style={{ flex: 1 }}>⬅ Nhận từ {h.from_group} · {h.from_title}</b><Badge tone={HO_STATUS[h.status][1]}>{HO_STATUS[h.status][0]}</Badge></div>
          <div className="small crit">{h.content}</div>
          {h.acceptance_criteria && <div className="small muted">Điều kiện tiếp nhận: {h.acceptance_criteria}</div>}
          {h.quantity !== null && <div className="small">Số lượng: {Number(h.quantity)} {h.unit || ''}</div>}
          <div className="small muted">{h.submitted_by_name || 'Hệ thống'} · {fmtDT(h.submitted_at)}{h.accepted_by_name ? ` · tiếp nhận: ${h.accepted_by_name} ${fmtDT(h.accepted_at)}` : ''}{h.rejection_reason ? ` · lý do từ chối: ${h.rejection_reason}` : ''}</div>
          {p.can_accept_handover && h.status === 'submitted' && (
            <div className="actions">
              <button className="btn sm primary" disabled={a.busy} onClick={() => done(() => post(`/handovers/${h.id}/decide`, { decision: 'accept' }))}>✔ Tiếp nhận</button>
              <button className="btn sm danger" onClick={() => { setCur(h); setSheet('reject'); }}>Chưa đạt — yêu cầu bổ sung</button>
            </div>
          )}
        </Card>
      ))}
      {t.handovers_out?.map((h: any) => (
        <Card key={h.id}>
          <div className="row"><b style={{ flex: 1 }}>➡ Giao cho {h.to_group}{h.to_title ? ` · ${h.to_title}` : ''}</b><Badge tone={HO_STATUS[h.status][1]}>{HO_STATUS[h.status][0]}</Badge></div>
          <div className="small crit">{h.content}</div>
          {h.rejection_reason && <div className="small" style={{ color: 'var(--red)' }}>Bên nhận yêu cầu: {h.rejection_reason}</div>}
          {p.can_send_handover && h.status === 'rejected' && <button className="btn sm" onClick={() => { setCur(h); setSheet('supplement'); }}>Bổ sung bàn giao</button>}
        </Card>
      ))}

      {(t.production?.length > 0 || p.can_record_production) && (
        <>
          <div className="section-title">Sản lượng & chất lượng{t.production_standard ? ` · định mức ${Number(t.production_standard.quantity)} ${t.production_standard.unit}/${Number(t.production_standard.minutes)} phút` : ''}</div>
          {t.production?.length === 0 && <div className="small muted">Chưa có bản ghi. Trưởng nhóm ghi nhận theo phiên/công đoạn — nhân viên không phải nhập từng sản phẩm.</div>}
          {t.production?.map((r: any) => (
            <Card key={r.id}>
              <div className="row"><b style={{ flex: 1 }}>{Number(r.accepted_qty)}/{Number(r.actual_qty)} {r.unit} đạt chuẩn</b>
                {r.efficiency !== null && <Badge tone={r.efficiency >= 90 ? 'green' : r.efficiency >= 70 ? 'amber' : 'red'}>Hiệu suất {r.efficiency}%</Badge>}
                {r.version > 1 && <Badge tone="purple">Điều chỉnh v{r.version}</Badge>}</div>
              <div className="small">Lỗi {Number(r.rejected_qty)} · làm lại {Number(r.rework_qty)} · tồn {Number(r.backlog_qty)} · thực hiện {mins(Number(r.execution_minutes))}{r.standard_minutes !== null ? ` · chuẩn ${mins(r.standard_minutes)}` : ''} · {r.mode === 'single' ? 'bàn giao một lần' : 'theo công đoạn/phiên'}</div>
              <div className="small muted">{(r.participant_names || []).join(', ')} · ghi nhận bởi {r.recorded_by_name} · {fmtDT(r.created_at)}{r.change_reason ? ` · lý do điều chỉnh: ${r.change_reason}` : ''}</div>
              {r.note && <div className="small">{r.note}</div>}
              {p.can_record_production && <button className="btn sm" onClick={() => { setCur(r); setSheet('adjust'); }}>Điều chỉnh (có lý do)</button>}
            </Card>
          ))}
        </>
      )}

      {(t.time_by_member?.length > 0 || t.pauses?.length > 0) && (
        <>
          <div className="section-title">Thời gian thực hiện · {mins(t.executed_minutes)}{t.standard_minutes ? ` / chuẩn ${mins(t.standard_minutes)}` : ''}</div>
          <Card>
            {t.time_by_member.map((m: any) => <KV key={m.member_id} k={`${m.name}${m.active ? ' (đang làm)' : ''}`} v={mins(m.minutes)} />)}
            {t.pauses.map((x: any) => (
              <div key={x.id} className="row small" style={{ gap: 6, marginTop: 4 }}>
                <Badge tone={TIME_CAT[x.category][1]}>{TIME_CAT[x.category][0]}</Badge>
                <span style={{ flex: 1 }}>{x.name} · {x.reason} · {fmtDT(x.started_at)}{x.ended_at ? ` (${mins((new Date(x.ended_at).getTime() - new Date(x.started_at).getTime()) / 60000)})` : ' · đang hoãn'}</span>
                {x.confirmed_by ? <span className="muted">đã xác nhận</span> : p.can_confirm_pause && x.category !== 'waiting' && (
                  <><button className="btn sm" disabled={a.busy} onClick={() => done(() => post(`/time-records/${x.id}/confirm`, { objective: true }))}>Xác nhận khách quan</button>
                    <button className="btn sm" onClick={() => { setCur(x); setSheet('notobjective'); }}>Không phải</button></>
                )}
              </div>
            ))}
          </Card>
        </>
      )}

      <Sheet open={sheet === 'session'} onClose={() => setSheet(null)} title="Bắt đầu phiên làm việc"><SwitchForm presetTaskId={t.id} busy={a.busy} error={a.error} onSubmit={(b) => done(() => post('/sessions/start', b))} /></Sheet>
      <Sheet open={sheet === 'prod'} onClose={() => setSheet(null)} title="Ghi nhận sản lượng"><ProdForm t={t} busy={a.busy} error={a.error} onSubmit={(b) => done(() => post('/production', { ...b, taskId: t.id }))} /></Sheet>
      <Sheet open={sheet === 'adjust'} onClose={() => setSheet(null)} title="Điều chỉnh sản lượng">{cur && <ProdForm t={t} init={cur} adjust busy={a.busy} error={a.error} onSubmit={(b) => done(() => post(`/production/${cur.id}/adjust`, b))} />}</Sheet>
      <Sheet open={sheet === 'handover'} onClose={() => setSheet(null)} title="Gửi bàn giao"><HandoverForm t={t} busy={a.busy} error={a.error} onSubmit={(b) => done(() => post('/handovers', { ...b, fromTaskId: t.id }))} /></Sheet>
      <Sheet open={sheet === 'reject'} onClose={() => setSheet(null)} title="Bàn giao chưa đạt"><Reason label="Cần bổ sung gì / lý do chưa tiếp nhận" busy={a.busy} error={a.error} onSubmit={(r) => done(() => post(`/handovers/${cur.id}/decide`, { decision: 'reject', reason: r }))} /></Sheet>
      <Sheet open={sheet === 'supplement'} onClose={() => setSheet(null)} title="Bổ sung bàn giao"><Reason label="Nội dung bổ sung" busy={a.busy} error={a.error} onSubmit={(r) => done(() => post(`/handovers/${cur.id}/supplement`, { content: r }))} /></Sheet>
      <Sheet open={sheet === 'early'} onClose={() => setSheet(null)} title="Cho phép bắt đầu sớm"><Reason label="Lý do cho phép bắt đầu trước khi công đoạn trước hoàn thành" busy={a.busy} error={a.error} onSubmit={(r) => done(() => post(`/tasks/${t.id}/early-start`, { reason: r }))} /></Sheet>
      <Sheet open={sheet === 'notobjective'} onClose={() => setSheet(null)} title="Không xác nhận hoãn khách quan"><Reason label="Lý do (ghi nhận là hoãn chủ quan)" busy={a.busy} error={a.error} onSubmit={(r) => done(() => post(`/time-records/${cur.id}/confirm`, { objective: false, note: r }))} /></Sheet>
      <Sheet open={sheet === 'priority'} onClose={() => setSheet(null)} title="Điều chỉnh ưu tiên"><PriorityForm t={t} busy={a.busy} error={a.error} onSubmit={(b) => done(() => post(`/tasks/${t.id}/priority`, b))} /></Sheet>
    </>
  );
}

function Reason({ label, busy, error, onSubmit }: { label: string; busy: boolean; error: string | null; onSubmit: (r: string) => void }) {
  const [r, setR] = useState('');
  return (<><Field label={label} required><textarea value={r} onChange={(e) => setR(e.target.value)} /></Field><ErrorBox error={error} /><button className="btn primary block" disabled={busy || r.trim().length < 5} onClick={() => onSubmit(r.trim())}>Gửi</button></>);
}

function ProdForm({ t, init, adjust, busy, error, onSubmit }: { t: any; init?: any; adjust?: boolean; busy: boolean; error: string | null; onSubmit: (b: any) => void }) {
  const stds = useLoad(() => get('/company/production-standards'), []);
  const people = t.assignees.filter((x: any) => x.active);
  const n = (v: any) => (v === null || v === undefined ? '' : String(Number(v)));
  const [f, setF] = useState<any>({
    mode: init?.mode || t.handover_mode || 'stage', standardId: init?.standard_id || t.production_standard_id || '', participants: init?.participants || people.map((x: any) => x.member_id),
    plannedQty: n(init?.planned_qty), actualQty: n(init?.actual_qty), acceptedQty: n(init?.accepted_qty), rejectedQty: n(init?.rejected_qty) || '0', reworkQty: n(init?.rework_qty) || '0', backlogQty: n(init?.backlog_qty) || '0',
    executionMinutes: n(init?.execution_minutes), note: init?.note || '', reason: '',
  });
  const up = (p: any) => setF((x: any) => ({ ...x, ...p }));
  const num = (v: string) => (v === '' ? undefined : Number(v));
  const std = (stds.data || []).find((s: any) => s.id === f.standardId);
  const eff = std && Number(f.executionMinutes) > 0 && f.acceptedQty !== '' ? Math.round((100 * (Number(f.acceptedQty) / Number(std.quantity)) * Number(std.minutes)) / Number(f.executionMinutes)) : null;
  return (
    <>
      {adjust && <div className="alert info small">Bản ghi cũ được giữ lại (thay thế bởi phiên bản mới). Bắt buộc nêu lý do.</div>}
      <Field label="Hình thức"><Select value={f.mode} onChange={(v) => up({ mode: v })} options={{ stage: 'Theo công đoạn / phiên', single: 'Bàn giao một lần' }} /></Field>
      <Field label="Định mức"><Select value={f.standardId} onChange={(v) => up({ standardId: v })} options={(stds.data || []).filter((s: any) => s.active).map((s: any) => [s.id, `${s.name} — ${Number(s.quantity)} ${s.unit}/${Number(s.minutes)}p`])} placeholder="— Không dùng định mức —" /></Field>
      <Field label="Thành viên tham gia">
        <div className="chip-row">{people.map((x: any) => <label key={x.member_id} className="check"><input type="checkbox" checked={f.participants.includes(x.member_id)} onChange={(e) => up({ participants: e.target.checked ? [...f.participants, x.member_id] : f.participants.filter((y: string) => y !== x.member_id) })} /> {x.name}</label>)}</div>
      </Field>
      <div className="grid2">
        <Field label="Kế hoạch"><input type="number" min={0} value={f.plannedQty} onChange={(e) => up({ plannedQty: e.target.value })} /></Field>
        <Field label="Thực tế" required><input type="number" min={0} value={f.actualQty} onChange={(e) => up({ actualQty: e.target.value })} /></Field>
        <Field label="Đạt chuẩn" required><input type="number" min={0} value={f.acceptedQty} onChange={(e) => up({ acceptedQty: e.target.value })} /></Field>
        <Field label="Lỗi"><input type="number" min={0} value={f.rejectedQty} onChange={(e) => up({ rejectedQty: e.target.value })} /></Field>
        <Field label="Làm lại"><input type="number" min={0} value={f.reworkQty} onChange={(e) => up({ reworkQty: e.target.value })} /></Field>
        <Field label="Tồn"><input type="number" min={0} value={f.backlogQty} onChange={(e) => up({ backlogQty: e.target.value })} /></Field>
      </div>
      <Field label="Thời gian thực hiện (phút)" hint="Để trống: hệ thống tính từ các phiên làm việc của người tham gia"><input type="number" min={0} value={f.executionMinutes} onChange={(e) => up({ executionMinutes: e.target.value })} /></Field>
      {eff !== null && <div className="small">Hiệu suất ước tính: <b>{eff}%</b> (thời gian chuẩn quy đổi ÷ thời gian thực hiện)</div>}
      <Field label="Ghi chú / vấn đề tồn"><input value={f.note} onChange={(e) => up({ note: e.target.value })} /></Field>
      {adjust && <Field label="Lý do điều chỉnh" required><input value={f.reason} onChange={(e) => up({ reason: e.target.value })} /></Field>}
      <ErrorBox error={error} />
      <button className="btn primary block" disabled={busy || f.actualQty === '' || f.acceptedQty === '' || (adjust && f.reason.trim().length < 5)} onClick={() => onSubmit({
        mode: f.mode, standardId: f.standardId || undefined, participants: f.participants, plannedQty: num(f.plannedQty), actualQty: Number(f.actualQty), acceptedQty: Number(f.acceptedQty),
        rejectedQty: Number(f.rejectedQty || 0), reworkQty: Number(f.reworkQty || 0), backlogQty: Number(f.backlogQty || 0), executionMinutes: num(f.executionMinutes), note: f.note || undefined, ...(adjust ? { reason: f.reason } : {}),
      })}>{adjust ? 'Lưu phiên bản điều chỉnh' : 'Xác nhận sản lượng'}</button>
    </>
  );
}

function HandoverForm({ t, busy, error, onSubmit }: { t: any; busy: boolean; error: string | null; onSubmit: (b: any) => void }) {
  const groups = useLoad(() => get('/groups?scope=all'), []);
  const [g, setG] = useState(''); const [c, setC] = useState(''); const [cr, setCr] = useState(''); const [qty, setQty] = useState('');
  return (
    <>
      <Field label="Nhóm/bộ phận nhận"><Select value={g} onChange={setG} options={(groups.data || []).filter((x: any) => x.id !== t.group_id).map((x: any) => [x.id, x.name])} placeholder="— Chọn —" /></Field>
      <Field label="Nội dung bàn giao" required><textarea value={c} onChange={(e) => setC(e.target.value)} placeholder="Kết quả, yêu cầu, dữ liệu kèm theo" /></Field>
      <Field label="Điều kiện để bên nhận tiếp nhận"><input value={cr} onChange={(e) => setCr(e.target.value)} /></Field>
      <Field label="Số lượng (nếu có)"><input type="number" min={0} value={qty} onChange={(e) => setQty(e.target.value)} /></Field>
      <ErrorBox error={error} />
      <button className="btn primary block" disabled={busy || !g || c.trim().length < 5} onClick={() => onSubmit({ toGroupId: g, content: c, acceptanceCriteria: cr || undefined, quantity: qty === '' ? undefined : Number(qty) })}>Gửi bàn giao</button>
    </>
  );
}

function PriorityForm({ t, busy, error, onSubmit }: { t: any; busy: boolean; error: string | null; onSubmit: (b: any) => void }) {
  const [p, setP] = useState(t.priority); const [i, setI] = useState(t.importance || 'normal'); const [r, setR] = useState('');
  return (
    <>
      <Field label="Ưu tiên"><Select value={p} onChange={setP} options={PRIORITY} /></Field>
      <Field label="Mức quan trọng"><Select value={i} onChange={setI} options={IMPORTANCE} /></Field>
      <Field label="Lý do" required><input value={r} onChange={(e) => setR(e.target.value)} /></Field>
      <ErrorBox error={error} />
      <button className="btn primary block" disabled={busy || r.trim().length < 5} onClick={() => onSubmit({ priority: p, importance: i, reason: r })}>Lưu (có lưu vết)</button>
    </>
  );
}
