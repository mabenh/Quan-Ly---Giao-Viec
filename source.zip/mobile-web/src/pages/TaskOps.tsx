import { useState } from 'react';
import { Link } from 'react-router-dom';
import { get, post } from '../api';
import { Badge, Card, ErrorBox, Field, KV, Select, Sheet, useAction, useLoad, Note } from '../ui';
import { Icon } from '../icons';
import { HO_METHOD, HO_STATUS, IMPORTANCE, PRIORITY, RISK, TIME_CAT, fmtDT, mins } from '../labels';
import { upload } from '../api';
import { SwitchForm } from '../session';

/** Phần vận hành của nhiệm vụ: chuỗi đơn hàng, cảnh báo, phiên, bàn giao liên phòng ban, sản lượng & chất lượng, thời gian. */
export function TaskOps({ t, reload }: { t: any; reload: () => void }) {
  const p = t.ops_permissions || {};
  const [sheet, setSheet] = useState<string | null>(null);
  const [cur, setCur] = useState<any>(null);
  const a = useAction();
  const done = (fn: () => Promise<any>) => a.run(async () => { await fn(); setSheet(null); setCur(null); reload(); });
  const risk = RISK[t.risk] || RISK.normal;
  const pendingIn = (t.handovers_in || []).filter((h: any) => h.status === 'submitted');
  return (
    <>
      <div className="chip-row">
        {t.chain && <Link to={`/chains/${t.chain.id}`}><Badge tone="blue">⛓ {t.chain.code} · {t.chain.progress}%</Badge></Link>}
        {t.risk && t.risk !== 'done' && <Badge tone={risk[1]}>{risk[0]}</Badge>}
        {t.location && <Badge tone="teal"><Icon name="map-pin" size={13} />{t.location.name}{t.location_required ? ' (bắt buộc)' : ''}</Badge>}
        {t.importance && t.importance !== 'normal' && <Badge tone="amber">{IMPORTANCE[t.importance]}</Badge>}
        {t.early_start_reason && <Badge tone="purple">Bắt đầu sớm: {t.early_start_reason}</Badge>}
      </div>
      {pendingIn.length > 0 && <div className="alert warn small">Có {pendingIn.length} bàn giao từ công đoạn trước cần tiếp nhận trước khi bắt đầu.</div>}
      <div className="actions">
        {p.can_session && <button className="btn primary" onClick={() => setSheet('session')}><Icon name="timer" size={18} />Bắt đầu phiên làm việc</button>}
        {p.can_record_production && <button className="btn" onClick={() => setSheet('prod')}><Icon name="boxes" size={18} />Ghi nhận sản lượng</button>}
        {p.can_send_handover && <button className="btn" onClick={() => setSheet('handover')}><Icon name="route" size={18} />Gửi bàn giao</button>}
        {p.can_early_start && <button className="btn" onClick={() => setSheet('early')}>Cho phép bắt đầu sớm</button>}
        {p.can_set_priority && !['completed', 'cancelled'].includes(t.status) && <button className="btn" onClick={() => setSheet('priority')}>Ưu tiên</button>}
      </div>
      <ErrorBox error={a.error} />

      {(t.handovers_in?.length > 0 || t.handovers_out?.length > 0) && <div className="section-title">Bàn giao liên phòng ban</div>}
      {t.handovers_in?.map((h: any) => (
        <Card key={h.id}>
          <div className="row"><b style={{ flex: 1 }}>⬅ Nhận từ {h.from_group} · {h.from_title}</b><Badge tone={HO_STATUS[h.status][1]}>{HO_STATUS[h.status][0]}</Badge></div>
          <div className="small crit">{h.content}</div>
          <div className="small">Phương thức bàn giao: <b>{HO_METHOD[h.method] || h.method}{h.method === 'leader_confirmation' && t.group_leader_name ? ` (${t.group_leader_name})` : ''}</b>{h.method_note ? ` — ${h.method_note}` : ''}</div>
          <Links links={h.links} />
          {h.quantity !== null && <div className="small">Số lượng: {Number(h.quantity)} {h.unit || ''}</div>}
          <div className="small muted">{h.submitted_by_name || 'Hệ thống'} · {fmtDT(h.submitted_at)}{h.accepted_by_name ? ` · tiếp nhận: ${h.accepted_by_name} ${fmtDT(h.accepted_at)}` : ''}{h.rejection_reason ? ` · lý do từ chối: ${h.rejection_reason}` : ''}</div>
          {p.can_accept_handover && h.status === 'submitted' && (
            <div className="actions">
              <button className="btn sm primary" disabled={a.busy} onClick={() => done(() => post(`/handovers/${h.id}/decide`, { decision: 'accept' }))}><Icon name="check" size={16} />Tiếp nhận</button>
              <button className="btn sm danger" onClick={() => { setCur(h); setSheet('reject'); }}>Chưa đạt — yêu cầu bổ sung</button>
            </div>
          )}
        </Card>
      ))}
      {t.handovers_out?.map((h: any) => (
        <Card key={h.id}>
          <div className="row"><b style={{ flex: 1 }}>➡ Giao cho {h.to_group}{h.to_title ? ` · ${h.to_title}` : ''}</b><Badge tone={HO_STATUS[h.status][1]}>{HO_STATUS[h.status][0]}</Badge></div>
          <div className="small crit">{h.content}</div>
          <div className="small muted">Phương thức: {HO_METHOD[h.method] || h.method}</div>
          <Links links={h.links} />
          {h.rejection_reason && <div className="small" style={{ color: 'var(--red)' }}>Bên nhận yêu cầu: {h.rejection_reason}</div>}
          {p.can_send_handover && h.status === 'rejected' && <button className="btn sm" onClick={() => { setCur(h); setSheet('supplement'); }}>Bổ sung bàn giao</button>}
        </Card>
      ))}

      {(t.production?.length > 0 || p.can_record_production) && (
        <>
          <div className="section-title">Sản lượng & chất lượng{t.production_standard ? ` · định mức ${Number(t.production_standard.quantity)} ${t.production_standard.unit}/${Number(t.production_standard.minutes)} phút` : ''}</div>
          {t.production?.length === 0 && <div className="small muted">Chưa có bản ghi. Trưởng nhóm ghi nhận theo phiên/công đoạn — nhân viên không phải nhập từng sản phẩm.</div>}
          {t.production?.map((r: any) => (
            <Card key={r.id}>
              <div className="row"><b style={{ flex: 1 }}>{Number(r.accepted_qty)}/{Number(r.actual_qty)} {r.unit} đạt chuẩn</b>
                {r.efficiency !== null && <Badge tone={r.efficiency >= 90 ? 'green' : r.efficiency >= 70 ? 'amber' : 'red'}>Hiệu suất {r.efficiency}%</Badge>}
                {r.version > 1 && <Badge tone="purple">Điều chỉnh v{r.version}</Badge>}</div>
              {(r.participant_times || []).length > 0 && <div className="small">{r.participant_times.map((pt: any) => `${t.assignees.find((x: any) => x.member_id === pt.member_id)?.name || 'Thành viên'}: ${mins(pt.work_minutes)}${pt.ot_minutes ? ` + tăng ca ${mins(pt.ot_minutes)}` : ''}`).join(' · ')}</div>}
              <div className="small">Lỗi {Number(r.rejected_qty)} · làm lại {Number(r.rework_qty)} · tồn {Number(r.backlog_qty)} · tổng thời gian {mins(Number(r.execution_minutes))}{Number(r.overtime_minutes) ? ` (gồm tăng ca ${mins(Number(r.overtime_minutes))})` : ''}{r.standard_minutes !== null ? ` · chuẩn ${mins(r.standard_minutes)}` : ''} · {r.mode === 'single' ? 'bàn giao một lần' : 'theo công đoạn/phiên'}</div>
              <div className="small muted">{(r.participant_names || []).join(', ')} · ghi nhận bởi {r.recorded_by_name} · {fmtDT(r.created_at)}{r.change_reason ? ` · lý do điều chỉnh: ${r.change_reason}` : ''}</div>
              {r.note && <div className="small">{r.note}</div>}
              {p.can_record_production && <button className="btn sm" onClick={() => { setCur(r); setSheet('adjust'); }}>Điều chỉnh (có lý do)</button>}
            </Card>
          ))}
        </>
      )}

      {(t.time_by_member?.length > 0 || t.pauses?.length > 0) && (
        <>
          <div className="section-title">Thời gian thực hiện · {mins(t.executed_minutes)}{t.standard_minutes ? ` / chuẩn ${mins(t.standard_minutes)}` : ''}</div>
          <Card>
            {t.time_by_member.map((m: any) => <KV key={m.member_id} k={`${m.name}${m.active ? ' (đang làm)' : ''}`} v={mins(m.minutes)} />)}
            {t.pauses.map((x: any) => (
              <div key={x.id} className="row small" style={{ gap: 6, marginTop: 4 }}>
                <Badge tone={TIME_CAT[x.category][1]}>{TIME_CAT[x.category][0]}</Badge>
                <span style={{ flex: 1 }}>{x.name} · {x.reason} · {fmtDT(x.started_at)}{x.ended_at ? ` (${mins((new Date(x.ended_at).getTime() - new Date(x.started_at).getTime()) / 60000)})` : ' · đang hoãn'}</span>
                {x.confirmed_by ? <span className="muted">đã xác nhận</span> : p.can_confirm_pause && x.category !== 'waiting' && (
                  <><button className="btn sm" disabled={a.busy} onClick={() => done(() => post(`/time-records/${x.id}/confirm`, { objective: true }))}>Xác nhận khách quan</button>
                    <button className="btn sm" onClick={() => { setCur(x); setSheet('notobjective'); }}>Không phải</button></>
                )}
              </div>
            ))}
          </Card>
        </>
      )}

      <Sheet open={sheet === 'session'} onClose={() => setSheet(null)} title="Bắt đầu phiên làm việc"><SwitchForm presetTaskId={t.id} busy={a.busy} error={a.error} onSubmit={(b) => done(() => post('/sessions/start', b))} /></Sheet>
      <Sheet open={sheet === 'prod'} onClose={() => setSheet(null)} title="Ghi nhận sản lượng"><ProdForm t={t} canOt={!!p.can_record_overtime} busy={a.busy} error={a.error} onSubmit={(b) => done(() => post('/production', { ...b, taskId: t.id }))} /></Sheet>
      <Sheet open={sheet === 'adjust'} onClose={() => setSheet(null)} title="Điều chỉnh sản lượng">{cur && <ProdForm t={t} canOt={!!p.can_record_overtime} init={cur} adjust busy={a.busy} error={a.error} onSubmit={(b) => done(() => post(`/production/${cur.id}/adjust`, b))} />}</Sheet>
      <Sheet open={sheet === 'handover'} onClose={() => setSheet(null)} title="Gửi bàn giao"><HandoverForm t={t} busy={a.busy} error={a.error} onSubmit={(b) => done(() => post('/handovers', { ...b, fromTaskId: t.id }))} /></Sheet>
      <Sheet open={sheet === 'reject'} onClose={() => setSheet(null)} title="Bàn giao chưa đạt"><Reason label="Cần bổ sung gì / lý do chưa tiếp nhận" busy={a.busy} error={a.error} onSubmit={(r) => done(() => post(`/handovers/${cur.id}/decide`, { decision: 'reject', reason: r }))} /></Sheet>
      <Sheet open={sheet === 'supplement'} onClose={() => setSheet(null)} title="Bổ sung bàn giao"><Reason label="Nội dung bổ sung" busy={a.busy} error={a.error} onSubmit={(r) => done(() => post(`/handovers/${cur.id}/supplement`, { content: r }))} /></Sheet>
      <Sheet open={sheet === 'early'} onClose={() => setSheet(null)} title="Cho phép bắt đầu sớm"><Reason label="Lý do cho phép bắt đầu trước khi công đoạn trước hoàn thành" busy={a.busy} error={a.error} onSubmit={(r) => done(() => post(`/tasks/${t.id}/early-start`, { reason: r }))} /></Sheet>
      <Sheet open={sheet === 'notobjective'} onClose={() => setSheet(null)} title="Không xác nhận hoãn khách quan"><Reason label="Lý do (ghi nhận là hoãn chủ quan)" busy={a.busy} error={a.error} onSubmit={(r) => done(() => post(`/time-records/${cur.id}/confirm`, { objective: false, note: r }))} /></Sheet>
      <Sheet open={sheet === 'priority'} onClose={() => setSheet(null)} title="Điều chỉnh ưu tiên"><PriorityForm t={t} busy={a.busy} error={a.error} onSubmit={(b) => done(() => post(`/tasks/${t.id}/priority`, b))} /></Sheet>
    </>
  );
}

function Reason({ label, busy, error, onSubmit }: { label: string; busy: boolean; error: string | null; onSubmit: (r: string) => void }) {
  const [r, setR] = useState('');
  return (<><Field label={label} required><textarea value={r} onChange={(e) => setR(e.target.value)} /></Field><ErrorBox error={error} /><button className="btn primary block" disabled={busy || r.trim().length < 5} onClick={() => onSubmit(r.trim())}>Gửi</button></>);
}

function ProdForm({ t, canOt, init, adjust, busy, error, onSubmit }: { t: any; canOt: boolean; init?: any; adjust?: boolean; busy: boolean; error: string | null; onSubmit: (b: any) => void }) {
  const stds = useLoad(() => get('/company/production-standards'), []);
  const grp = useLoad(() => get(`/groups/${t.group_id}`).catch(() => null), [t.group_id]);
  // Người tham gia: người được giao + thành viên nhóm thực hiện (trưởng nhóm ghi cho cả nhóm)
  const people = Array.from(new Map<string, any>([...t.assignees.filter((x: any) => x.active).map((x: any) => [x.member_id, { member_id: x.member_id, name: x.name }]),
    ...((grp.data?.members || []) as any[]).map((m: any) => [m.member_id, { member_id: m.member_id, name: m.name }])] as [string, any][]).values());
  const n = (v: any) => (v === null || v === undefined ? '' : String(Number(v)));
  const [f, setF] = useState<any>({
    mode: init?.mode || t.handover_mode || 'stage', standardId: init?.standard_id || t.production_standard_id || '', participants: init?.participants || people.map((x: any) => x.member_id),
    plannedQty: n(init?.planned_qty), actualQty: n(init?.actual_qty), acceptedQty: n(init?.accepted_qty), rejectedQty: n(init?.rejected_qty) || '0', reworkQty: n(init?.rework_qty) || '0', backlogQty: n(init?.backlog_qty) || '0',
    executionMinutes: n(init?.execution_minutes), note: init?.note || '', reason: '',
    times: Object.fromEntries(people.map((x: any) => { const pt = (init?.participant_times || []).find((y: any) => y.member_id === x.member_id); return [x.member_id, { w: pt ? String(pt.work_minutes) : '', o: pt ? String(pt.ot_minutes || '') : '' }]; })),
  });
  const setTime = (mid: string, k: 'w' | 'o', v: string) => setF((x: any) => ({ ...x, times: { ...x.times, [mid]: { ...(x.times[mid] || {}), [k]: v } } }));
  const timeRows = f.participants.map((mid: string) => ({ memberId: mid, workMinutes: Number(f.times[mid]?.w || 0), otMinutes: canOt ? Number(f.times[mid]?.o || 0) : 0 }));
  const totalMin = timeRows.reduce((s: number, r: any) => s + r.workMinutes + r.otMinutes, 0);
  const up = (p: any) => setF((x: any) => ({ ...x, ...p }));
  const num = (v: string) => (v === '' ? undefined : Number(v));
  const std = (stds.data || []).find((s: any) => s.id === f.standardId);
  const eff = std && totalMin > 0 && f.acceptedQty !== '' ? Math.round((100 * (Number(f.acceptedQty) / Number(std.quantity)) * Number(std.minutes)) / totalMin) : null;
  return (
    <>
      {adjust && <Note>Bản ghi cũ được giữ lại (thay thế bởi phiên bản mới). Bắt buộc nêu lý do.</Note>}
      <Field label="Hình thức"><Select value={f.mode} onChange={(v) => up({ mode: v })} options={{ stage: 'Theo công đoạn / phiên', single: 'Bàn giao một lần' }} /></Field>
      <Field label="Định mức"><Select value={f.standardId} onChange={(v) => up({ standardId: v })} options={(stds.data || []).filter((s: any) => s.active).map((s: any) => [s.id, `${s.name} — ${Number(s.quantity)} ${s.unit}/${Number(s.minutes)}p`])} placeholder="— Không dùng định mức —" /></Field>
      <Field label="Thành viên tham gia">
        <div className="chip-row">{people.map((x: any) => <label key={x.member_id} className="check"><input type="checkbox" checked={f.participants.includes(x.member_id)} onChange={(e) => up({ participants: e.target.checked ? [...f.participants, x.member_id] : f.participants.filter((y: string) => y !== x.member_id) })} /> {x.name}</label>)}</div>
      </Field>
      <div className="grid2">
        <Field label="Kế hoạch"><input type="number" min={0} value={f.plannedQty} onChange={(e) => up({ plannedQty: e.target.value })} /></Field>
        <Field label="Thực tế" required><input type="number" min={0} value={f.actualQty} onChange={(e) => up({ actualQty: e.target.value })} /></Field>
        <Field label="Đạt chuẩn" required><input type="number" min={0} value={f.acceptedQty} onChange={(e) => up({ acceptedQty: e.target.value })} /></Field>
        <Field label="Lỗi"><input type="number" min={0} value={f.rejectedQty} onChange={(e) => up({ rejectedQty: e.target.value })} /></Field>
        <Field label="Làm lại"><input type="number" min={0} value={f.reworkQty} onChange={(e) => up({ reworkQty: e.target.value })} /></Field>
        <Field label="Tồn"><input type="number" min={0} value={f.backlogQty} onChange={(e) => up({ backlogQty: e.target.value })} /></Field>
      </div>
      <Field label={canOt ? 'Thời gian làm việc và tăng ca của từng người (phút)' : 'Thời gian làm việc của từng người (phút)'} hint={canOt ? 'Tăng ca chỉ là tham số tính hiệu suất (app không tính lương)' : 'Giờ tăng ca do trưởng nhóm ghi nhận'}>
        {f.participants.map((mid: string) => (
          <div key={mid} className="row" style={{ gap: 6, marginBottom: 4 }}>
            <span className="small" style={{ flex: 1 }}>{people.find((x: any) => x.member_id === mid)?.name}</span>
            <input style={{ width: 90 }} type="number" min={0} placeholder="Làm việc" aria-label="Phút làm việc" value={f.times[mid]?.w || ''} onChange={(e) => setTime(mid, 'w', e.target.value)} />
            {canOt && <input style={{ width: 90 }} type="number" min={0} placeholder="Tăng ca" aria-label="Phút tăng ca" value={f.times[mid]?.o || ''} onChange={(e) => setTime(mid, 'o', e.target.value)} />}
          </div>
        ))}
        <span className="hint">Tổng: {mins(totalMin)}</span>
      </Field>
      {eff !== null && <div className="small">Hiệu suất ước tính: <b>{eff}%</b> (thời gian chuẩn quy đổi ÷ thời gian thực hiện)</div>}
      <Field label="Ghi chú / vấn đề tồn"><input value={f.note} onChange={(e) => up({ note: e.target.value })} /></Field>
      {adjust && <Field label="Lý do điều chỉnh" required><input value={f.reason} onChange={(e) => up({ reason: e.target.value })} /></Field>}
      <ErrorBox error={error} />
      <button className="btn primary block" disabled={busy || f.actualQty === '' || f.acceptedQty === '' || (adjust && f.reason.trim().length < 5)} onClick={() => onSubmit({
        mode: f.mode, standardId: f.standardId || undefined, participants: f.participants, plannedQty: num(f.plannedQty), actualQty: Number(f.actualQty), acceptedQty: Number(f.acceptedQty),
        rejectedQty: Number(f.rejectedQty || 0), reworkQty: Number(f.reworkQty || 0), backlogQty: Number(f.backlogQty || 0), participantTimes: totalMin > 0 ? timeRows : undefined, note: f.note || undefined, ...(adjust ? { reason: f.reason } : {}),
      })}>{adjust ? 'Lưu phiên bản điều chỉnh' : 'Xác nhận sản lượng'}</button>
    </>
  );
}

function HandoverForm({ t, busy, error, onSubmit }: { t: any; busy: boolean; error: string | null; onSubmit: (b: any) => void }) {
  const groups = useLoad(() => get('/groups?scope=all'), []);
  const [g, setG] = useState(''); const [c, setC] = useState(''); const [cr, setCr] = useState(''); const [qty, setQty] = useState('');
  const [method, setMethod] = useState('direct_inspection'); const [links, setLinks] = useState('');
  return (
    <>
      <Field label="Nhóm/phòng ban nhận"><Select value={g} onChange={setG} options={(groups.data || []).filter((x: any) => x.id !== t.group_id).map((x: any) => [x.id, x.name])} placeholder="— Chọn —" /></Field>
      <Field label="Nội dung bàn giao" required><textarea value={c} onChange={(e) => setC(e.target.value)} placeholder="Kết quả, yêu cầu, dữ liệu kèm theo" /></Field>
      <Field label="Phương thức bàn giao"><Select value={method} onChange={setMethod} options={HO_METHOD} /></Field>
      <Field label="Ghi chú phương thức (tùy chọn)" hint="VD: tên khách hàng xác nhận, người kiểm tra tài liệu"><input value={cr} onChange={(e) => setCr(e.target.value)} /></Field>
      <Field label="Đường link tài liệu (mỗi dòng một link)"><textarea rows={2} value={links} onChange={(e) => setLinks(e.target.value)} placeholder="https://..." /></Field>
      <Note>Tệp đính kèm: tải lên ở mục Tệp của nhiệm vụ trước khi gửi, bên nhận xem được từ công đoạn của họ qua đường link hoặc tệp của nhiệm vụ.</Note>
      <Field label="Số lượng (nếu có)"><input type="number" min={0} value={qty} onChange={(e) => setQty(e.target.value)} /></Field>
      <ErrorBox error={error} />
      <button className="btn primary block" disabled={busy || !g || c.trim().length < 5} onClick={() => onSubmit({ toGroupId: g, content: c, method, methodNote: cr || undefined, links: links.split(/\s+/).map((x) => x.trim()).filter(Boolean), quantity: qty === '' ? undefined : Number(qty) })}>Gửi bàn giao</button>
    </>
  );
}

function PriorityForm({ t, busy, error, onSubmit }: { t: any; busy: boolean; error: string | null; onSubmit: (b: any) => void }) {
  const [p, setP] = useState(t.priority); const [i, setI] = useState(t.importance || 'normal'); const [r, setR] = useState(''); const [pin, setPin] = useState(!!t.pinned);
  return (
    <>
      <Field label="Ưu tiên"><Select value={p} onChange={setP} options={PRIORITY} /></Field>
      <Field label="Mức quan trọng"><Select value={i} onChange={setI} options={IMPORTANCE} /></Field>
      <label className="check"><input type="checkbox" checked={pin} onChange={(e) => setPin(e.target.checked)} /> 📌 Ghim là việc gấp (lên đầu danh sách, báo người làm)</label>
      <Field label="Lý do" required><input value={r} onChange={(e) => setR(e.target.value)} /></Field>
      <ErrorBox error={error} />
      <button className="btn primary block" disabled={busy || r.trim().length < 5} onClick={() => onSubmit({ priority: p, importance: i, pinned: pin, reason: r })}>Lưu (có lưu vết)</button>
    </>
  );
}

function Links({ links }: { links?: string[] }) {
  if (!links?.length) return null;
  return <div className="small">{links.map((l, i) => <div key={i}>🔗 <a href={l} target="_blank" rel="noreferrer">{l.length > 60 ? l.slice(0, 57) + '…' : l}</a></div>)}</div>;
}
