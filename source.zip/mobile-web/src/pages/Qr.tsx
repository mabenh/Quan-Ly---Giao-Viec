import { useEffect, useRef, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import QRCode from 'qrcode';
import jsQR from 'jsqr';
import { get, post } from '../api';
import { useAuth } from '../auth';
import { Badge, Card, Empty, ErrorBox, Field, Header, KV, Loading, Select, Sheet, useAction, useLoad, Note } from '../ui';
import { Icon, IconChip } from '../icons';
import { SwitchForm } from '../session';
import { MyTime } from './Dashboards';
import { fmtDT, mins } from '../labels';

/** Lấy token từ nội dung mã QR (URL /qr/a/<token> hoặc /h/<token>, hoặc token thô). */
export function parseQr(text: string): { kind: 'area' | 'handover' | 'unknown'; token: string } {
  const m = text.match(/\/qr\/a\/([A-Za-z0-9_-]{16,})/); if (m) return { kind: 'area', token: m[1] };
  const h = text.match(/\/h\/([A-Za-z0-9_-]{16,})/); if (h) return { kind: 'handover', token: h[1] };
  if (/^[A-Za-z0-9_-]{24,64}$/.test(text.trim())) return { kind: 'area', token: text.trim() };
  return { kind: 'unknown', token: '' };
}

/** Quét QR bằng camera: BarcodeDetector (nếu có) hoặc jsQR. */
export function QrScanner({ onResult }: { onResult: (text: string) => void }) {
  const video = useRef<HTMLVideoElement | null>(null);
  const canvas = useRef<HTMLCanvasElement | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const done = useRef(false);
  useEffect(() => {
    let stream: MediaStream | null = null; let raf = 0; let alive = true;
    const Detector = (window as any).BarcodeDetector;
    const det = Detector ? new Detector({ formats: ['qr_code'] }) : null;
    (async () => {
      try {
        stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
        if (!alive || !video.current) return;
        video.current.srcObject = stream; await video.current.play();
        const loop = async () => {
          if (!alive || done.current || !video.current) return;
          const v = video.current;
          if (v.readyState >= 2) {
            try {
              let text: string | null = null;
              if (det) { const r = await det.detect(v); text = r[0]?.rawValue || null; }
              else if (canvas.current) {
                const c = canvas.current; c.width = v.videoWidth; c.height = v.videoHeight;
                const ctx = c.getContext('2d', { willReadFrequently: true })!; ctx.drawImage(v, 0, 0);
                text = jsQR(ctx.getImageData(0, 0, c.width, c.height).data, c.width, c.height)?.data || null;
              }
              if (text) { done.current = true; if (navigator.vibrate) navigator.vibrate(80); onResult(text); return; }
            } catch { /* tiếp tục quét */ }
          }
          raf = requestAnimationFrame(loop);
        };
        loop();
      } catch (e: any) { setErr(e?.name === 'NotAllowedError' ? 'Cần cho phép dùng camera để quét mã QR.' : 'Không mở được camera trên thiết bị này.'); }
    })();
    return () => { alive = false; cancelAnimationFrame(raf); stream?.getTracks().forEach((t) => t.stop()); };
  }, []);
  return (
    <div className="qr-scan">
      <video ref={video} playsInline muted />
      <canvas ref={canvas} style={{ display: 'none' }} />
      <div className="qr-frame" />
      {err && <div className="alert warn small">{err}</div>}
    </div>
  );
}

/**
 * Luồng A — Kết nối khu vực: quét → hiển thị khu vực để xác nhận → tạo phiên khu vực (xác nhận chuyển nếu đang ở khu vực khác)
 * → mở mẫu bắt đầu phiên làm việc với vị trí điền sẵn; nhiệm vụ do nhân viên tự chọn.
 */
export function ScanPage() {
  const { token: urlToken } = useParams();
  const nav = useNavigate();
  const [token, setToken] = useState(urlToken || '');
  const [manual, setManual] = useState('');
  const [v, setV] = useState<any>(null);
  const [transfer, setTransfer] = useState<string | null>(null);
  const [connected, setConnected] = useState<any>(null);
  const [startOpen, setStartOpen] = useState(false);
  const a = useAction();
  useEffect(() => { if (token) a.run(async () => setV(await post('/area-qr/validate', { token }))); }, [token]);
  const onScan = (text: string) => {
    const p = parseQr(text);
    if (p.kind === 'handover') { nav(`/h/${p.token}`); return; }
    if (p.kind === 'unknown') { a.run(async () => { throw new Error('Mã QR không thuộc Việc Đến'); }); return; }
    setToken(p.token);
  };
  const connect = (confirmTransfer = false) => a.run(async () => {
    try {
      const r = await post('/work-area-sessions/connect', { token, confirmTransfer });
      setConnected(r); setTransfer(null); setStartOpen(true);
    } catch (e: any) { if (e.code === 'TRANSFER_REQUIRED') setTransfer(e.message); else throw e; }
  });
  return (
    <>
      <Header title="Quét QR khu vực" back />
      <div className="page">
        {!token && <>
          <Note>Hướng camera vào tem QR dán tại khu vực/trạm làm việc. Kết nối khu vực chỉ là ngữ cảnh vận hành — <b>không phải chấm công</b>.</Note>
          <QrScanner onResult={onScan} />
          <Field label="Hoặc nhập mã dưới tem"><div style={{ display: 'flex', gap: 6 }}><input value={manual} onChange={(e) => setManual(e.target.value)} /><button className="btn" onClick={() => manual && onScan(manual)}>Kiểm tra</button></div></Field>
        </>}
        <ErrorBox error={a.error} />
        {token && !v && !a.error && <Loading />}
        {a.error && token && <button className="btn block" onClick={() => { setToken(''); setV(null); a.setError(null); }}>Quét lại</button>}
        {v && !connected && (
          <Card>
            <div className="small muted">Khu vực trên mã QR</div>
            <h2 style={{ margin: '2px 0' }}>{v.area.name}</h2>
            <div className="small">{v.area.site_name}{v.area.workstation_name ? ` · Trạm ${v.area.workstation_name}` : ''}{v.area.location_name ? ` · Vị trí: ${v.area.location_name}` : ''}</div>
            {v.current && !v.same && <div className="alert warn small">Bạn đang kết nối <b>{v.current.area_name}</b> từ {fmtDT(v.current.started_at)}.</div>}
            {v.same && <div className="alert info small">Bạn đang kết nối khu vực này.</div>}
            {transfer ? <>
              <div className="alert warn small">{transfer}</div>
              <button className="btn primary block" disabled={a.busy} onClick={() => connect(true)}>Xác nhận chuyển khu vực</button>
            </> : <button className="btn primary block" disabled={a.busy} onClick={() => connect(false)}><Icon name="ok" size={18} />{v.same ? 'Tiếp tục ở khu vực này' : 'Xác nhận kết nối'}</button>}
          </Card>
        )}
        {connected && (
          <Card>
            <div className="row"><span className="live-dot" /><b style={{ flex: 1 }}>Đã kết nối: {connected.active.area_name}</b></div>
            <Note>Phiên làm việc mới sẽ được tạo với vị trí điền sẵn. Bạn tự chọn nhiệm vụ đang làm.</Note>
            <button className="btn primary block" onClick={() => setStartOpen(true)}><Icon name="timer" size={18} />Bắt đầu phiên làm việc</button>
            <Link className="btn block" style={{ marginTop: 8 }} to="/my-area">Xem vị trí phiên làm việc hôm nay</Link>
          </Card>
        )}
        <Sheet open={startOpen && !!connected} onClose={() => setStartOpen(false)} title={`Phiên làm việc tại ${connected?.active?.area_name || ''}`}>
          {connected && <StartFromQr s={connected.active} onDone={() => nav('/my-area', { replace: true })} />}
        </Sheet>
      </div>
    </>
  );
}

function StartFromQr({ s, onDone }: { s: any; onDone: () => void }) {
  const a = useAction();
  return <SwitchForm busy={a.busy} error={a.error} presetLocationId={s.work_location_id || undefined} areaSessionId={s.id} areaName={s.area_name}
    onSubmit={(b) => a.run(async () => { await post('/sessions/start', { ...b, locationSource: 'qr', workAreaSessionId: s.id }); onDone(); })} />;
}

/** Thẻ vị trí phiên làm việc: khu vực đang kết nối + lịch sử khu vực đã qua trong ngày và thời gian ở lại. */
/** Bộ đếm thời gian từ lúc kết nối khu vực (cập nhật mỗi giây). */
function ElapsedTimer({ since }: { since: string }) {
  const [now, setNow] = useState(Date.now());
  useEffect(() => { const t = setInterval(() => setNow(Date.now()), 1000); return () => clearInterval(t); }, []);
  const s = Math.max(0, Math.floor((now - new Date(since).getTime()) / 1000));
  const p = (n: number) => String(n).padStart(2, '0');
  return <span className="timer"><Icon name="timer" size={14} />{p(Math.floor(s / 3600))}:{p(Math.floor((s % 3600) / 60))}:{p(s % 60)}</span>;
}

export function AreaTrail({ compact }: { compact?: boolean }) {
  const { data, reload } = useLoad(() => get('/work-area-sessions/me'), []);
  const a = useAction();
  if (!data) return null;
  if (compact && !data.active) return (
    <div className="area-trail idle"><Link className="btn sm qr-btn" to="/scan"><Icon name="qr" size={18} />Quét QR khu vực</Link></div>
  );
  if (compact) return (
    <div className="area-trail live">
      <span className="live-dot" />
      <div style={{ flex: 1, minWidth: 0 }}><b className="ellipsis" style={{ display: 'block' }}>{data.active.area_name}</b><ElapsedTimer since={data.active.started_at} /></div>
      <Link to="/my-area" className="tile mini" title="Vị trí phiên làm việc"><IconChip name="qr" tone="green" size={18} /><span>Vị trí phiên</span></Link>
      <Link className="icon-btn" to="/scan" aria-label="Quét QR khác" title="Quét QR khác"><Icon name="refresh" size={18} /></Link>
    </div>
  );
  return (
    <div className="area-trail">
      <div className="row" style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
        <Icon name="qr" size={16} />
        <b className="small" style={{ flex: 1 }}>{data.active ? `Đang ở: ${data.active.area_name}` : 'Không kết nối khu vực'}</b>
        <Link className="btn sm" to="/scan">Quét QR</Link>
        {data.active && !compact && <button className="btn sm" disabled={a.busy} onClick={() => a.run(async () => { await post(`/work-area-sessions/${data.active.id}/disconnect`, {}); reload(); })}>Ngắt</button>}
      </div>
      {data.today.length > 0 && (
        <div className="trail">
          {data.today.map((x: any, i: number) => (
            <span key={x.id} className={`step ${x.status === 'ACTIVE' ? 'now' : ''}`}>
              {i > 0 && <span className="arrow">→</span>}
              <b>{x.area_name}</b> <span className="small muted">{new Date(x.started_at).toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' })} · {mins(x.minutes)}{x.source === 'manager_entered' ? ' · QL ghi hộ' : ''}</span>
            </span>
          ))}
        </div>
      )}
      {!compact && data.totals.length > 0 && <div className="cnt-row">{data.totals.map((t: any) => <span key={t.area_name}>{t.area_name} <b>{mins(t.minutes)}</b></span>)}</div>}
      {!compact && <Note style={{ margin: '4px 0 0' }}>{data.note}</Note>}
    </div>
  );
}

/** Vị trí phiên làm việc (thay mục "Thời gian & kết quả", kế thừa toàn bộ nội dung). */
export function MyArea() {
  return <MyTime title="Vị trí phiên làm việc" extra={<><AreaTrail /><SupportHistory /></>} />;
}

/** Lịch sử hỗ trợ & thời gian hỗ trợ (thống kê cá nhân). */
export function SupportHistory({ memberId }: { memberId?: string }) {
  const { data } = useLoad(() => get('/support-history' + (memberId ? `?memberId=${memberId}` : '')), [memberId]);
  const [open, setOpen] = useState(false);
  if (!data || (!data.sessions && !data.received.length)) return null;
  return (
    <div className="area-trail">
      <div className="row" style={{ display: 'flex', alignItems: 'center', cursor: 'pointer' }} onClick={() => setOpen(!open)}>
        <Icon name="users" size={16} /><b className="small" style={{ flex: 1 }}> Hỗ trợ: {data.sessions} lượt · {mins(data.total_minutes)} (30 ngày: {mins(data.last30_minutes)})</b><Icon name={open ? 'down' : 'chevron'} size={16} />
      </div>
      {open && <>
        {data.given.map((g: any) => <div key={g.id} className="small" style={{ marginTop: 4 }}>🤝 {fmtDT(g.started_at)} · {mins(g.minutes)} · hỗ trợ {g.requester_name} — {g.code} {g.title}{g.task_code ? ` (${g.task_code})` : ''}{g.response_status === 'confirmed' ? ' · đã xác nhận' : ''}</div>)}
        {data.received.length > 0 && <div className="small muted" style={{ marginTop: 6 }}>Tôi yêu cầu/kêu gọi: {data.received.map((r: any) => `${r.code} (${r.helpers} người, ${mins(r.minutes)})`).join(' · ')}</div>}
      </>}
    </div>
  );
}

// =================== Quản trị khu vực ===================
export function AreaAdmin() {
  const sites = useLoad(() => get('/work-sites'), []);
  const areas = useLoad(() => get('/work-areas'), []);
  const locs = useLoad(() => get('/company/locations'), []);
  const groups = useLoad(() => get('/groups?scope=all'), []);
  const a = useAction();
  const [site, setSite] = useState({ name: '', address: '' });
  const [area, setArea] = useState({ siteId: '', name: '', workLocationId: '', groupId: '' });
  const [open, setOpen] = useState<string | null>(null);
  return (
    <>
      <Header title="Khu vực & mã QR" back />
      <div className="page">
        <Note>Cơ sở → Khu vực → Trạm (tùy chọn) → QR. Mã chỉ chứa token ngẫu nhiên (máy chủ lưu bản băm), có thể in, thu hồi, cấp lại. QR khu vực không phải chấm công và không dùng làm chỉ số năng suất.</Note>
        <ErrorBox error={sites.error || areas.error || a.error} />
        {(sites.data || []).map((s: any) => (
          <div key={s.id}>
            <div className="section-title">{s.name}{s.address ? ` · ${s.address}` : ''}</div>
            {(areas.data || []).filter((x: any) => x.site_id === s.id).map((x: any) => (
              <Card key={x.id} onClick={() => setOpen(x.id)}>
                <div className="row"><b style={{ flex: 1 }}>{x.name}</b>{x.status !== 'active' && <Badge tone="gray">{x.status === 'locked' ? 'Tạm khóa' : x.status}</Badge>}
                  <Badge tone={x.active_qr ? 'green' : 'amber'}>{x.active_qr ? 'Có QR' : 'Chưa có QR'}</Badge></div>
                <div className="small muted">{x.location_name ? `Vị trí: ${x.location_name}` : 'Chưa gắn vị trí'}{x.group_name ? ` · ${x.group_name}` : ''} · {x.active_sessions} người đang kết nối</div>
              </Card>
            ))}
          </div>
        ))}
        {sites.data && sites.data.length === 0 && <Empty>Chưa có cơ sở. Thêm cơ sở trước, sau đó thêm khu vực.</Empty>}
        <div className="section-title">Thêm khu vực</div>
        <Card>
          <Field label="Cơ sở"><Select value={area.siteId} onChange={(v) => setArea({ ...area, siteId: v })} options={(sites.data || []).map((s: any) => [s.id, s.name])} placeholder="— Chọn —" /></Field>
          <Field label="Tên khu vực"><input value={area.name} onChange={(e) => setArea({ ...area, name: e.target.value })} placeholder="VD: Khu đóng gói" /></Field>
          <div className="grid2">
            <Field label="Vị trí làm việc tương ứng" hint="Điền sẵn khi bắt đầu phiên"><Select value={area.workLocationId} onChange={(v) => setArea({ ...area, workLocationId: v })} options={(locs.data || []).map((l: any) => [l.id, l.name])} placeholder="— Không —" /></Field>
            <Field label="Nhóm phụ trách"><Select value={area.groupId} onChange={(v) => setArea({ ...area, groupId: v })} options={(groups.data || []).map((g: any) => [g.id, g.name])} placeholder="— Không —" /></Field>
          </div>
          <button className="btn primary" disabled={a.busy || !area.siteId || area.name.trim().length < 2} onClick={() => a.run(async () => {
            await post('/work-areas', { siteId: area.siteId, name: area.name, workLocationId: area.workLocationId || null, groupId: area.groupId || null });
            setArea({ ...area, name: '' }); areas.reload();
          })}>Thêm khu vực</button>
        </Card>
        <div className="section-title">Thêm cơ sở</div>
        <Card>
          <div className="grid2">
            <Field label="Tên cơ sở"><input value={site.name} onChange={(e) => setSite({ ...site, name: e.target.value })} /></Field>
            <Field label="Địa chỉ"><input value={site.address} onChange={(e) => setSite({ ...site, address: e.target.value })} /></Field>
          </div>
          <button className="btn" disabled={a.busy || site.name.trim().length < 2} onClick={() => a.run(async () => { await post('/work-sites', { name: site.name, address: site.address || undefined }); setSite({ name: '', address: '' }); sites.reload(); })}>Thêm cơ sở</button>
        </Card>
      </div>
      <Sheet open={!!open} onClose={() => { setOpen(null); areas.reload(); }} title="Chi tiết khu vực">{open && <AreaDetail id={open} />}</Sheet>
    </>
  );
}

function AreaDetail({ id }: { id: string }) {
  const { data: d, reload } = useLoad(() => get(`/work-areas/${id}`), [id]);
  const hist = useLoad(() => get(`/work-areas/${id}/history`), [id]);
  const { me } = useAuth();
  const a = useAction();
  const [issued, setIssued] = useState<{ img: string; url: string; label: string } | null>(null);
  const [st, setSt] = useState({ code: '', name: '' });
  if (!d) return <Loading />;
  const issue = (workstationId?: string, label?: string) => a.run(async () => {
    const r = await post(`/work-areas/${id}/qr-codes`, { workstationId: workstationId || null });
    const url = (r.url && /^https?:/.test(r.url) ? r.url : window.location.origin + r.path);
    setIssued({ img: await QRCode.toDataURL(url, { margin: 2, width: 512 }), url, label: label || d.name }); reload(); hist.reload();
  });
  const print = () => {
    if (!issued) return;
    const w = window.open('', '_blank'); if (!w) return;
    w.document.write(`<html><head><title>QR ${issued.label}</title></head><body style="font-family:sans-serif;text-align:center;padding:24px"><h2>${d.site_name} · ${issued.label}</h2><img src="${issued.img}" style="width:70%;max-width:420px"/><p>Quét bằng ứng dụng Việc Đến để kết nối khu vực</p><p style="font-size:10px;color:#666">Phát hành ${new Date().toLocaleString('vi-VN')} bởi ${me?.name || ''}</p><script>setTimeout(()=>print(),300)</script></body></html>`);
  };
  return (
    <>
      <KV k="Cơ sở" v={d.site_name} /><KV k="Vị trí làm việc" v={d.location_name || '—'} /><KV k="Nhóm phụ trách" v={d.group_name || '—'} />
      {issued && (
        <div className="card" style={{ textAlign: 'center' }}>
          <img src={issued.img} alt="Mã QR khu vực" style={{ width: '80%', maxWidth: 280 }} />
          <div className="small">Mã chỉ hiển thị một lần — hãy in và dán ngay tại {issued.label}.</div>
          <div className="actions"><button className="btn primary" onClick={print}>In tem QR</button><button className="btn" onClick={() => navigator.clipboard?.writeText(issued.url)}>Sao chép link</button></div>
        </div>
      )}
      {d.can_manage && <div className="actions">
        <button className="btn primary" disabled={a.busy} onClick={() => issue()}>{d.active_qr ? 'Cấp lại QR khu vực' : 'Phát hành QR khu vực'}</button>
        <button className="btn" disabled={a.busy} onClick={() => a.run(async () => { await (await import('../api')).patch(`/work-areas/${id}`, { status: d.status === 'active' ? 'locked' : 'active' }); reload(); })}>{d.status === 'active' ? 'Tạm khóa khu vực' : 'Mở khóa'}</button>
      </div>}
      <ErrorBox error={a.error} />
      <div className="section-title">Trạm làm việc</div>
      {d.workstations.map((w: any) => <div key={w.id} className="row small" style={{ display: 'flex', gap: 6, alignItems: 'center', margin: '4px 0' }}><span style={{ flex: 1 }}>{w.code} · {w.name}</span>{d.can_manage && <button className="btn sm" onClick={() => issue(w.id, `${d.name} – ${w.name}`)}>QR trạm</button>}</div>)}
      {d.can_manage && <div style={{ display: 'flex', gap: 6 }}><input style={{ width: 90 }} placeholder="Mã" value={st.code} onChange={(e) => setSt({ ...st, code: e.target.value })} /><input placeholder="Tên trạm" value={st.name} onChange={(e) => setSt({ ...st, name: e.target.value })} />
        <button className="btn sm" disabled={!st.code || st.name.length < 2} onClick={() => a.run(async () => { await post(`/work-areas/${id}/workstations`, st); setSt({ code: '', name: '' }); reload(); })}>Thêm</button></div>}
      <div className="section-title">Mã QR đã phát hành</div>
      {d.qr_codes.map((x: any) => (
        <div key={x.id} className="row small" style={{ display: 'flex', gap: 6, alignItems: 'center', margin: '4px 0' }}>
          <Badge tone={x.status === 'active' ? 'green' : 'gray'}>{x.status === 'active' ? 'Hiệu lực' : x.status === 'revoked' ? 'Thu hồi' : x.status}</Badge>
          <span style={{ flex: 1 }}>{x.workstation_name || 'Khu vực'} · {fmtDT(x.issued_at)} · {x.created_by_name}{x.revoke_reason ? ` · ${x.revoke_reason}` : ''}</span>
          {x.status === 'active' && d.can_manage && <button className="btn sm danger" onClick={() => { const r = prompt('Lý do thu hồi (VD: tem bị rách, bị chụp lại)'); if (r) a.run(async () => { await post(`/area-qr/${x.id}/revoke`, { reason: r }); reload(); hist.reload(); }); }}>Thu hồi</button>}
        </div>
      ))}
      <div className="section-title">Đang kết nối & 24 giờ qua</div>
      {d.sessions.length === 0 && <div className="small muted">Chưa có phiên — nhãn: “chưa có thông tin kết nối khu vực” (không phải vắng mặt).</div>}
      {d.sessions.map((s: any) => <div key={s.id} className="small" style={{ margin: '3px 0' }}>{s.status === 'ACTIVE' ? '🟢' : '⚪'} {s.employee_name} · {fmtDT(s.started_at)}{s.ended_at ? ` → ${fmtDT(s.ended_at)}` : ''} · {s.verification_source === 'manager_entered' ? 'quản lý ghi hộ' : 'quét QR'}</div>)}
      {hist.data && hist.data.length > 0 && <>
        <div className="section-title">Lịch sử sự kiện</div>
        {hist.data.slice(0, 20).map((e: any) => <div key={e.id} className="small muted">{fmtDT(e.occurred_at)} · {e.event_type} · {e.actor_name || 'hệ thống'}</div>)}
      </>}
    </>
  );
}
