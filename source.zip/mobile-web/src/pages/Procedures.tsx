import { useState } from 'react';
import { Link } from 'react-router-dom';
import { get } from '../api';
import { isHRRole, useAuth } from '../auth';
import { Badge, ErrorBox, Header, Loading, Tabs, useLoad } from '../ui';
import { IconChip, Icon } from '../icons';
import { AUDIENCE, REMINDER } from '../labels';

const CAT_ICON: Record<string, [string, string]> = { 'Giao việc': ['assign', 'blue'], 'Nhân sự': ['users', 'purple'], 'Thủ tục': ['permit', 'teal'], 'Vận hành': ['alert', 'amber'] };

export default function Procedures() {
  const { me } = useAuth();
  const { data, error, loading } = useLoad(() => get('/hr/procedures'), []);
  const [tab, setTab] = useState('mine');
  if (loading && !data) return <Loading />;
  if (!data) return <div className="page"><ErrorBox error={error} /></div>;
  const items = data.items.filter((p: any) => tab === 'all' || data.mine.includes(p.id));
  const cats = [...new Set(items.map((p: any) => p.category || 'Khác'))] as string[];
  return (
    <>
      <Header title="Quy trình & thủ tục" back="/hr" right={isHRRole(me?.role) ? <Link className="btn sm primary" to="/hr/procedures/new"><Icon name="plus" size={16} />Thêm</Link> : undefined} />
      <div className="page">
        <Tabs value={tab} onChange={setTab} tabs={[['mine', 'Áp dụng cho tôi'], ['all', 'Tất cả']]} />
        <p className="small muted">Bạn sẽ nhận tin vắn nhắc quy trình của bộ phận mình theo chu kỳ (mục Thông báo).</p>
        {cats.map((c) => (
          <div key={c}>
            <div className="section-title">{c}</div>
            <div className="menu">
              {items.filter((p: any) => (p.category || 'Khác') === c).map((p: any) => (
                <Link key={p.id} to={`/hr/procedures/${p.id}`}>
                  <IconChip name={(CAT_ICON[c] || ['book'])[0]} tone={(CAT_ICON[c] || ['', 'gray'])[1]} />
                  <span className="grow"><b>{p.title}</b><div className="sub">{p.audience === 'department' ? p.department_name : AUDIENCE[p.audience]} · {REMINDER[p.reminder]}{!p.active ? ' · ngừng áp dụng' : ''}</div></span>
                  {p.system_key === 'giao_viec_tham_khao' && <Badge tone="teal">Tham khảo</Badge>}
                  {p.system_key === 'giao_viec_chuan' && <Badge tone="blue">Chuẩn công ty</Badge>}
                  <Icon name="chevron" className="chev" />
                </Link>
              ))}
            </div>
          </div>
        ))}
      </div>
    </>
  );
}
