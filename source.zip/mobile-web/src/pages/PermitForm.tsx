import { useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { get, post } from '../api';
import { ErrorBox, Field, Header, Loading, Select, useAction, useLoad } from '../ui';
import { Icon } from '../icons';
import { fromLocalInput, toLocalInput } from '../labels';

/** Lập giấy phép cho một công việc đã giao (người giao việc chuẩn bị). */
export default function PermitForm() {
  const nav = useNavigate();
  const [sp] = useSearchParams();
  const taskId = sp.get('taskId') || '';
  const types = useLoad(() => get('/permit-types'), []);
  const task = useLoad(() => (taskId ? get(`/tasks/${taskId}`) : Promise.resolve(null)), [taskId]);
  const [typeId, setTypeId] = useState('');
  const [holder, setHolder] = useState('');
  const [mode, setMode] = useState('approval');
  const [data, setData] = useState<Record<string, string>>({});
  const [from, setFrom] = useState(toLocalInput(new Date()));
  const [to, setTo] = useState(toLocalInput(new Date(Date.now() + 8 * 3600000)));
  const a = useAction();
  if (!types.data || (taskId && !task.data)) return <Loading />;
  const pt = types.data.find((x: any) => x.id === typeId);
  const people = (task.data?.assignees || []).filter((x: any) => x.active);
  return (
    <>
      <Header title="Lập giấy phép" back />
      <div className="page">
        {task.data && <div className="alert info small">Cho công việc <b>{task.data.code} · {task.data.title}</b></div>}
        <div className="tpl-grid">
          {types.data.filter((x: any) => x.active).map((x: any) => (
            <button key={x.id} type="button" className={`tpl ${typeId === x.id ? 'sel' : ''}`} onClick={() => { setTypeId(x.id); setMode(x.allow_declaration ? 'declaration' : 'approval'); setData({}); }}>
              <span className="ichip teal" style={{ width: 36, height: 36 }}><Icon name={x.icon || 'permit'} size={19} /></span>{x.name}
            </button>
          ))}
        </div>
        {pt && (
          <>
            <p className="small muted">{pt.description} · Bộ phận xử lý: {pt.department_name || 'Quản trị công ty'}</p>
            <Field label="Người được cấp phép" required><Select value={holder} onChange={setHolder} options={people.map((x: any) => [x.member_id, x.name])} placeholder="— Chọn —" /></Field>
            <Field label="Hình thức"><Select value={mode} onChange={setMode} options={pt.allow_declaration ? { declaration: 'Khai báo — cấp tự động, hậu kiểm sau', approval: 'Chờ bộ phận duyệt' } : { approval: 'Chờ bộ phận duyệt' }} /></Field>
            {(pt.fields || []).map((x: any) => (
              <Field key={x.key} label={x.label} required={x.required}>
                {x.type === 'textarea' ? <textarea value={data[x.key] || ''} onChange={(e) => setData({ ...data, [x.key]: e.target.value })} /> : <input value={data[x.key] || ''} onChange={(e) => setData({ ...data, [x.key]: e.target.value })} />}
              </Field>
            ))}
            <div className="grid2">
              <Field label="Hiệu lực từ"><input type="datetime-local" value={from} onChange={(e) => setFrom(e.target.value)} /></Field>
              <Field label="Đến"><input type="datetime-local" value={to} onChange={(e) => setTo(e.target.value)} /></Field>
            </div>
            {mode === 'declaration' && <div className="alert warn small">Bạn khai báo để giấy phép có hiệu lực ngay. Nếu hậu kiểm phát hiện quy trình sai, bạn là người chịu trách nhiệm.</div>}
            <ErrorBox error={a.error} />
            <button className="btn primary block" disabled={a.busy || !holder} onClick={() => a.run(async () => {
              const r = await post('/permits', { typeId, taskId: taskId || undefined, holderId: holder, data, mode, validFrom: fromLocalInput(from), validTo: fromLocalInput(to) });
              nav(`/permits/${r.id}`, { replace: true });
            })}>Lập giấy phép</button>
          </>
        )}
      </div>
    </>
  );
}
