import { useEffect, useRef, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { api, del, get, patch, post } from '../api';
import { useAuth } from '../auth';
import { Avatar, Badge, Card, Empty, ErrorBox, Field, Header, Loading, Select, Sheet, useAction, useLoad, Note } from '../ui';
import { Icon } from '../icons';
import { useGroupCall } from '../groupcall';
import { fmtDT } from '../labels';

const WHO: Record<string, string> = { all: 'Mọi thành viên', admins: 'Chỉ quản trị nhóm' };
const ROOM_ROLE: Record<string, string> = { owner: 'Chủ nhóm', admin: 'Quản trị nhóm', member: 'Thành viên' };

/** Danh sách nhóm liên lạc (tab "Nhóm" trong Liên lạc). */
export function RoomList() {
  const { data, error, loading, reload } = useLoad(() => get('/rooms'), []);
  const [create, setCreate] = useState(false);
  const { joinRoomCall } = useGroupCall();
  const nav = useNavigate();
  return (
    <>
      <Note>Nhắn tin nhóm và gọi nhóm trong app (tối đa 8 người/cuộc gọi). Trưởng nhóm, trưởng phòng lập nhóm với thành viên trong phạm vi phụ trách và thiết lập quyền hạn nhóm.</Note>
      {data?.can_create && <button className="btn primary block" onClick={() => setCreate(true)}><Icon name="plus" size={16} />Lập nhóm liên lạc mới</button>}
      <ErrorBox error={error} />{loading && !data && <Loading />}
      {data && data.rooms.length === 0 && <Empty>Bạn chưa thuộc nhóm liên lạc nào.{data.can_create ? ' Bấm "Lập nhóm liên lạc mới" để tạo.' : ' Trưởng nhóm / trưởng phòng sẽ thêm bạn vào nhóm.'}</Empty>}
      {data?.rooms.map((r: any) => (
        <Card key={r.id} to={`/rooms/${r.id}`} className={r.unread ? 'pinned' : ''}>
          <div className="row">
            <span className="ci-mark" style={{ width: 40, height: 40, borderRadius: 12, display: 'grid', placeItems: 'center', background: 'var(--primary-soft)', color: 'var(--primary)', flex: 'none' }}><Icon name="users" size={20} /></span>
            <div style={{ flex: 1, minWidth: 0 }}>
              <b>{r.name}</b> <span className="small muted">· {r.member_count} người</span>
              <div className="small muted ellipsis">{r.last ? `${r.last.name}: ${r.last.body}` : 'Chưa có tin nhắn'}</div>
            </div>
            {r.unread > 0 ? <Badge tone="red">{r.unread}</Badge> : r.last && <span className="small muted">{fmtDT(r.last.at)}</span>}
          </div>
          {r.active_call && r.active_call.count > 0 && (
            <div className="row" style={{ marginTop: 6 }} onClick={(e) => e.preventDefault()}>
              <span className="live-dot" /><span className="small" style={{ flex: 1 }}>Đang gọi nhóm · {r.active_call.count} người</span>
              <button className="btn sm primary" onClick={(e) => { e.preventDefault(); e.stopPropagation(); joinRoomCall(r.id); }}>Tham gia</button>
            </div>
          )}
        </Card>
      ))}
      <Sheet open={create} onClose={() => setCreate(false)} title="Lập nhóm liên lạc">
        {create && <RoomForm onDone={(r) => { setCreate(false); reload(); nav(`/rooms/${r.id}`); }} />}
      </Sheet>
    </>
  );
}

function PermFields({ s, up }: { s: any; up: (p: any) => void }) {
  return (
    <>
      <div className="perm-row"><span>Ai được nhắn tin</span><Select value={s.who_can_post} onChange={(v) => up({ who_can_post: v })} options={WHO} /></div>
      <div className="perm-row"><span>Ai được bắt đầu gọi nhóm</span><Select value={s.who_can_call} onChange={(v) => up({ who_can_call: v })} options={WHO} /></div>
      <div className="perm-row"><span>Ai được thêm thành viên</span><Select value={s.who_can_add} onChange={(v) => up({ who_can_add: v })} options={WHO} /></div>
      <div className="perm-row"><span>Thời lượng tối đa mỗi cuộc gọi</span><Select value={String(s.call_limit_minutes)} onChange={(v) => up({ call_limit_minutes: Number(v) })} options={[3, 5, 10, 15, 20, 30].map((m) => [String(m), `${m} phút`])} /></div>
    </>
  );
}

/** Chọn thành viên trong phạm vi phụ trách. */
function MemberPicker({ value, onChange, exclude = [] }: { value: string[]; onChange: (v: string[]) => void; exclude?: string[] }) {
  const el = useLoad(() => get('/rooms-eligible'), []);
  const [qq, setQ] = useState('');
  const list = (el.data?.members || []).filter((m: any) => !exclude.includes(m.id) && (!qq || (m.name + ' ' + (m.department || '') + ' ' + (m.title || '')).toLowerCase().includes(qq.toLowerCase())));
  const depts = [...new Set(list.map((m: any) => m.department || 'Chưa có phòng ban'))] as string[];
  const toggle = (id: string) => onChange(value.includes(id) ? value.filter((x) => x !== id) : [...value, id]);
  return (
    <>
      <div className="small muted" style={{ marginBottom: 4 }}>{el.data?.scope === 'limited' ? 'Chỉ hiện thành viên trong phạm vi bạn phụ trách.' : 'Toàn công ty.'} Đã chọn {value.length}.</div>
      <input placeholder="Tìm tên, phòng ban, chức danh…" value={qq} onChange={(e) => setQ(e.target.value)} />
      <ErrorBox error={el.error} />
      <div className="pick-list">
        {el.loading && !el.data && <Loading />}
        {depts.map((d) => {
          const ms = list.filter((m: any) => (m.department || 'Chưa có phòng ban') === d);
          const all = ms.every((m: any) => value.includes(m.id));
          return (
            <div key={d}>
              <label style={{ fontWeight: 600 }}><input type="checkbox" checked={all} onChange={() => onChange(all ? value.filter((x) => !ms.some((m: any) => m.id === x)) : [...new Set([...value, ...ms.map((m: any) => m.id)])])} />{d} ({ms.length})</label>
              {ms.map((m: any) => <label key={m.id} style={{ paddingLeft: 18 }}><input type="checkbox" checked={value.includes(m.id)} onChange={() => toggle(m.id)} /><span>{m.name}<span className="small muted">{m.title ? ` · ${m.title}` : ''}</span></span></label>)}
            </div>
          );
        })}
        {el.data && list.length === 0 && <div className="small muted" style={{ padding: 8 }}>Không có thành viên phù hợp.</div>}
      </div>
    </>
  );
}

function RoomForm({ onDone }: { onDone: (r: any) => void }) {
  const [name, setName] = useState('');
  const [ids, setIds] = useState<string[]>([]);
  const [s, setS] = useState<any>({ who_can_post: 'all', who_can_call: 'all', who_can_add: 'admins', call_limit_minutes: 10 });
  const a = useAction();
  return (
    <>
      <Field label="Tên nhóm" required><input value={name} onChange={(e) => setName(e.target.value)} placeholder="VD: Ca sáng Tổ đóng gói" /></Field>
      <Field label="Thành viên"><MemberPicker value={ids} onChange={setIds} /></Field>
      <details><summary className="small"><b>Quyền hạn nhóm</b> (có thể đổi sau)</summary><PermFields s={s} up={(p) => setS({ ...s, ...p })} /></details>
      <ErrorBox error={a.error} />
      <button className="btn primary block" style={{ marginTop: 10 }} disabled={a.busy || name.trim().length < 2} onClick={() => a.run(async () => onDone(await post('/rooms', { name: name.trim(), memberIds: ids, settings: s })))}>Lập nhóm ({ids.length + 1} người)</button>
    </>
  );
}

/** Nhắn tin nhóm + gọi nhóm + thiết lập. */
export function RoomChat() {
  const { id } = useParams();
  const { me } = useAuth();
  const nav = useNavigate();
  const room = useLoad(() => get(`/rooms/${id}`), [id]);
  const msgs = useLoad(() => get(`/rooms/${id}/messages`), [id]);
  const { joinRoomCall, activeRoomId } = useGroupCall();
  const [text, setText] = useState('');
  const [busy, setBusy] = useState(false);
  const [sheet, setSheet] = useState<string | null>(null);
  const end = useRef<HTMLDivElement | null>(null);
  useEffect(() => {
    const t = setInterval(() => {
      if (document.hidden) return;
      api<any>('GET', `/rooms/${id}/messages`, undefined, { retries: 0 }).then((d) => msgs.setData(d)).catch(() => {});
      api<any>('GET', `/rooms/${id}`, undefined, { retries: 0 }).then((d) => room.setData(d)).catch(() => {});
    }, 5000);
    return () => clearInterval(t);
  }, [id]); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => { end.current?.scrollIntoView({ block: 'end' }); }, [msgs.data?.items?.length]);
  const r = room.data;
  const send = async () => {
    if (!text.trim()) return; setBusy(true);
    try { const m = await post(`/rooms/${id}/messages`, { body: text.trim() }); setText(''); msgs.setData((d: any) => ({ ...d, items: [...(d?.items || []), m] })); } catch (e: any) { alert(e.message); } finally { setBusy(false); }
  };
  if (room.error) return <><Header title="Nhóm liên lạc" back="/contacts?tab=rooms" /><div className="page"><ErrorBox error={room.error} /></div></>;
  const inCall = activeRoomId === id;
  return (
    <>
      <Header title={r?.name || 'Nhóm liên lạc'} back="/contacts?tab=rooms" right={r && <div className="chip-row" style={{ margin: 0, flexWrap: 'nowrap' }}>
        {(r.permissions.can_call || r.active_call) && <button className={`btn sm ${r.active_call ? 'primary' : ''}`} disabled={inCall} onClick={() => joinRoomCall(id!)}><Icon name="phone" size={16} />{inCall ? 'Đang gọi' : r.active_call ? `Tham gia (${r.active_call.count})` : 'Gọi nhóm'}</button>}
        <button className="btn sm" aria-label="Thông tin nhóm" onClick={() => setSheet('info')}><Icon name="settings" size={16} /></button></div>} />
      <div className="page chat">
        <ErrorBox error={msgs.error} />
        {!r && <Loading />}
        {r && <p className="small muted" style={{ textAlign: 'center' }}>{r.members.length} thành viên · tin nhắn tự xóa sau {r.retention_days} ngày{!r.permissions.can_post ? ' · chỉ quản trị nhóm được nhắn' : ''}</p>}
        {msgs.data?.items.map((m: any) => {
          const mine = m.sender_id === me?.member_id;
          return <div key={m.id} className={`bubble ${mine ? 'mine' : ''}`}>{!mine && <span className="who">{m.sender_name}</span>}<div>{m.body}</div><span className="small muted">{fmtDT(m.created_at)}</span></div>;
        })}
        {msgs.data && msgs.data.items.length === 0 && <Empty>Chưa có tin nhắn trong nhóm.</Empty>}
        <div ref={end} />
      </div>
      {r?.permissions.can_post ? (
        <div className="chat-input">
          <textarea rows={1} value={text} onChange={(e) => setText(e.target.value)} placeholder="Nhắn cho cả nhóm…" onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); } }} />
          <button className="btn primary" disabled={busy || !text.trim()} onClick={send}>Gửi</button>
        </div>
      ) : r && <div className="chat-input"><span className="small muted" style={{ flex: 1, textAlign: 'center', padding: 10 }}>Theo thiết lập nhóm, chỉ quản trị nhóm được nhắn tin.</span></div>}
      <Sheet open={sheet === 'info'} onClose={() => setSheet(null)} title={r?.name || 'Nhóm'}>
        {r && <RoomInfo room={r} onChange={(d) => room.setData(d)} onLeft={() => nav('/contacts?tab=rooms', { replace: true })} />}
      </Sheet>
    </>
  );
}

function RoomInfo({ room, onChange, onLeft }: { room: any; onChange: (d: any) => void; onLeft: () => void }) {
  const { me } = useAuth();
  const [s, setS] = useState<any>(room.settings);
  const [name, setName] = useState(room.name);
  const [adding, setAdding] = useState<string[] | null>(null);
  const a = useAction();
  const p = room.permissions;
  const dirty = JSON.stringify(s) !== JSON.stringify(room.settings) || name !== room.name;
  return (
    <>
      {p.can_manage && <>
        <Field label="Tên nhóm"><input value={name} onChange={(e) => setName(e.target.value)} /></Field>
        <b className="small">Quyền hạn nhóm</b>
        <PermFields s={s} up={(x) => setS({ ...s, ...x })} />
        {dirty && <button className="btn primary block" style={{ marginTop: 8 }} disabled={a.busy} onClick={() => a.run(async () => onChange(await patch(`/rooms/${room.id}`, { name, settings: s })))}>Lưu thiết lập</button>}
      </>}
      {!p.can_manage && <div className="small muted">Nhắn tin: {WHO[room.settings.who_can_post]} · Gọi nhóm: {WHO[room.settings.who_can_call]} · Thêm thành viên: {WHO[room.settings.who_can_add]} · Tối đa {room.settings.call_limit_minutes} phút/cuộc gọi</div>}
      <div className="row" style={{ marginTop: 12 }}><b style={{ flex: 1 }}>Thành viên ({room.members.length})</b>{p.can_add && adding === null && <button className="btn sm" onClick={() => setAdding([])}><Icon name="plus" size={16} />Thêm</button>}</div>
      {adding !== null && <>
        <MemberPicker value={adding} onChange={setAdding} exclude={room.members.map((m: any) => m.member_id)} />
        <div className="chip-row"><button className="btn sm primary" disabled={a.busy || !adding.length} onClick={() => a.run(async () => { onChange(await post(`/rooms/${room.id}/members`, { memberIds: adding })); setAdding(null); })}>Thêm {adding.length} người</button><button className="btn sm" onClick={() => setAdding(null)}>Hủy</button></div>
      </>}
      {room.members.map((m: any) => (
        <div key={m.member_id} className="row" style={{ padding: '6px 0', borderBottom: '1px solid var(--border)' }}>
          <Avatar userId={m.user_id} name={m.name} has={false} size="sm" />
          <div style={{ flex: 1, minWidth: 0 }}><b>{m.name}</b>{m.member_id === me?.member_id && ' (bạn)'}<div className="small muted">{ROOM_ROLE[m.role]}{m.title ? ` · ${m.title}` : ''}</div></div>
          {room.my_role === 'owner' && m.role !== 'owner' && <button className="btn sm" disabled={a.busy} onClick={() => a.run(async () => onChange(await patch(`/rooms/${room.id}/members/${m.member_id}`, { role: m.role === 'admin' ? 'member' : 'admin' })))}>{m.role === 'admin' ? 'Bỏ quản trị' : 'Cho quản trị'}</button>}
          {p.can_manage && m.role !== 'owner' && m.member_id !== me?.member_id && <button className="btn sm" disabled={a.busy} onClick={() => confirm(`Xóa ${m.name} khỏi nhóm?`) && a.run(async () => onChange(await del(`/rooms/${room.id}/members/${m.member_id}`)))}>Xóa</button>}
        </div>
      ))}
      <ErrorBox error={a.error} />
      {room.my_role !== 'owner' && <button className="btn block danger" style={{ marginTop: 12 }} disabled={a.busy} onClick={() => confirm('Rời nhóm liên lạc này?') && a.run(async () => { await del(`/rooms/${room.id}/members/${me?.member_id}`); onLeft(); })}>Rời nhóm</button>}
      {room.my_role === 'owner' && <button className="btn block" style={{ marginTop: 12 }} disabled={a.busy} onClick={() => confirm('Giải tán (lưu trữ) nhóm? Thành viên sẽ không thấy nhóm nữa.') && a.run(async () => { await patch(`/rooms/${room.id}`, { archived: true }); onLeft(); })}>Giải tán nhóm</button>}
    </>
  );
}
