import { useEffect, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { get, post, qs, upload } from '../api';
import { useAuth } from '../auth';
import { ErrorBox, Field, Header, Select, useAction, useLoad, Note } from '../ui';
import { WR_TYPE, fromLocalInput, toLocalInput } from '../labels';

type Mode = 'branch' | 'routine' | 'outside_role' | 'other';
const MODES: [Mode, string, string][] = [
  ['branch', 'Thêm vào việc đang có', 'Bổ sung phần việc vào nhánh công việc hiện có — không cần tạo mới, cấp trên dễ theo dõi'],
  ['routine', 'Việc thường ngày', 'Việc trong vai trò: chỉ cần mô tả, chọn được yêu cầu hay tự chủ động'],
  ['outside_role', 'Việc ngoài vai trò', 'Việc không thuộc mô tả công việc của bạn: người giao, lý do, bằng chứng'],
  ['other', 'Khác', 'Giao ngoài app, bị ghi thiếu, ngoài giờ, hỗ trợ'],
];

export default function WorkRecordForm() {
  const nav = useNavigate();
  const { me } = useAuth();
  const [sp] = useSearchParams();
  const a = useAction();
  const callId = sp.get('callId') || '';
  const initial = (sp.get('type') as Mode) || (sp.get('taskId') ? 'branch' : callId ? 'other' : 'routine');
  const [mode, setMode] = useState<Mode>(MODES.some((m) => m[0] === initial) ? initial : 'routine');
  const groups = useLoad(() => get('/groups'), []);
  const members = useLoad(() => get('/company/members'), []);
  const roles = useLoad(() => get('/company/job-roles'), []);
  const locs = useLoad(() => get('/company/locations'), []);
  const [loc, setLoc] = useState('');
  const myTasks = useLoad(() => get('/tasks' + qs({ mine: 'any', status: 'not_started,in_progress,revision_requested,waiting', limit: 100 })), []);
  const now = new Date(); now.setMinutes(0, 0, 0);
  const [f, setF] = useState<any>({
    title: '', description: '', groupId: '', requesterMemberId: '', unknown: false, requesterUnknownNote: '', initiative: false,
    startAt: toLocalInput(new Date(now.getTime() - 2 * 3600000)), endAt: toLocalInput(now), isEstimated: false,
    recordType: 'assigned_outside', result: '', completionStatus: 'done', reasonNotInSystem: '', relatedTaskId: sp.get('taskId') || '',
  });
  const [file, setFile] = useState<File | null>(null);
  // v9: khai báo từ cuộc gọi trong app — điền sẵn người giao, thời gian; ghi âm của cuộc gọi tự đính kèm
  const callInfo = useLoad(() => (callId ? get(`/calls/${callId}`) : Promise.resolve(null)), [callId]);
  useEffect(() => {
    const c = callInfo.data; if (!c) return;
    const st = new Date(c.answered_at || c.created_at); const en = new Date(c.ended_at || Date.now());
    if (en.getTime() - st.getTime() < 60000) en.setTime(st.getTime() + 60000);
    up({ title: `Việc trao đổi qua cuộc gọi với ${c.other_name}`, requesterMemberId: c.other_id, recordType: 'assigned_outside', reasonNotInSystem: 'Được giao/trao đổi qua cuộc gọi trong app Việc Đến',
      startAt: toLocalInput(st), endAt: toLocalInput(en) });
  }, [callInfo.data]);
  const up = (p: any) => setF((x: any) => ({ ...x, ...p }));
  const mins = Math.round((new Date(f.endAt).getTime() - new Date(f.startAt).getTime()) / 60000);
  const meRow = (members.data || []).find((m: any) => m.id === me?.member_id);
  const myRole = (roles.data || []).find((r: any) => r.id === meRow?.job_role_id);
  const people = (members.data || []).filter((m: any) => m.id !== me?.member_id).map((m: any) => [m.id, `${m.name}${m.title ? ' — ' + m.title : ''}`] as [string, string]);

  const submit = () => a.run(async () => {
    const recordType = mode === 'other' ? f.recordType : mode;
    if (!loc) throw new Error('Chọn vị trí làm việc (hoặc Ngoài công ty / Không xác định)');
    const body: any = {
      title: f.title, description: f.description || undefined, startAt: fromLocalInput(f.startAt), endAt: fromLocalInput(f.endAt), isEstimated: f.isEstimated, recordType,
      locationSource: loc === 'outside' || loc === 'unknown' ? loc : 'location', workLocationId: loc === 'outside' || loc === 'unknown' ? undefined : loc,
    };
    if (mode === 'branch') Object.assign(body, { relatedTaskId: f.relatedTaskId || undefined, result: f.description || undefined });
    if (mode === 'routine') Object.assign(body, { initiative: f.initiative, requesterMemberId: f.initiative ? undefined : f.requesterMemberId || undefined, groupId: f.groupId || undefined, result: f.description || undefined });
    if (mode === 'outside_role') Object.assign(body, { requesterMemberId: f.requesterMemberId || undefined, reasonNotInSystem: f.reasonNotInSystem, groupId: f.groupId || undefined, result: f.description || undefined });
    if (mode === 'other') Object.assign(body, {
      groupId: f.groupId || undefined, requesterMemberId: f.unknown ? undefined : f.requesterMemberId || undefined, requesterUnknownNote: f.unknown ? f.requesterUnknownNote : undefined,
      result: f.result, completionStatus: f.completionStatus, reasonNotInSystem: f.reasonNotInSystem,
    });
    if (callId) body.callId = callId;
    const r = await post('/work-records', body);
    if (file) await upload('work_record', r.id, file).catch(() => {});
    nav(`/work-records/${r.id}`, { replace: true });
  });

  const timeFields = (
    <>
      <div className="grid2">
        <Field label="Bắt đầu" required><input type="datetime-local" value={f.startAt} onChange={(e) => up({ startAt: e.target.value })} /></Field>
        <Field label="Kết thúc" required><input type="datetime-local" value={f.endAt} onChange={(e) => up({ endAt: e.target.value })} /></Field>
      </div>
      <div className="small muted">Thời lượng: {mins > 0 ? `${Math.floor(mins / 60)} giờ ${mins % 60} phút` : 'không hợp lệ'}</div>
      <Field label="Vị trí làm việc" required hint="Khai nếu xác định được; có thể chọn Ngoài công ty hoặc Không xác định">
        <Select value={loc} onChange={setLoc} options={[...(locs.data || []).filter((l: any) => l.active).map((l: any) => [l.id, l.name] as [string, string]), ['outside', 'Ngoài công ty'], ['unknown', 'Không xác định']]} placeholder="— Chọn —" />
      </Field>
    </>
  );
  const roleHint = myRole && (mode === 'routine' || mode === 'outside_role') && (
    <details className="card small" style={{ padding: 10 }}>
      <summary>Vai trò của tôi: <b>{myRole.name}</b> — xem nhiệm vụ trong vai trò</summary>
      {myRole.description && <p className="muted">{myRole.description}</p>}
      <ul>{(myRole.duties || []).map((d: string, i: number) => <li key={i}>{d}</li>)}</ul>
      <div className="muted">Việc nằm trong danh sách trên là "việc thường ngày"; ngoài danh sách là "việc ngoài vai trò" (được tính điểm cộng khi được xác nhận).</div>
    </details>
  );

  return (
    <>
      <Header title="Khai báo công việc" back />
      <div className="page">
        {callInfo.data && <div className="alert info small">Khai báo từ cuộc gọi với <b>{callInfo.data.other_name}</b> ({Math.round((callInfo.data.duration_seconds || 0) / 6) / 10} phút){callInfo.data.recording ? ' — ghi âm cuộc gọi sẽ được đính kèm làm tài liệu.' : '.'}</div>}
        <div className="seg" role="tablist">
          {MODES.map(([k, l]) => <button key={k} role="tab" aria-selected={mode === k} className={mode === k ? 'on' : ''} onClick={() => setMode(k)}>{l}</button>)}
        </div>
        <Note>{MODES.find((m) => m[0] === mode)![2]}</Note>
        {roleHint}

        {mode === 'branch' && (
          <>
            <Field label="Công việc đang có" required hint="Phần khai thêm được gắn vào nhánh này; quản lý trực tiếp của nhóm xác nhận">
              <Select value={f.relatedTaskId} onChange={(v) => up({ relatedTaskId: v })} options={(myTasks.data?.items || []).map((t: any) => [t.id, `${t.code} · ${t.title}`])} placeholder="— Chọn việc —" />
            </Field>
            <Field label="Phần việc đã làm thêm" required><input value={f.title} onChange={(e) => up({ title: e.target.value })} placeholder="VD: Dán thêm nhãn phụ cho 20 thùng" /></Field>
            <Field label="Mô tả ngắn"><textarea value={f.description} onChange={(e) => up({ description: e.target.value })} /></Field>
            {timeFields}
          </>
        )}

        {mode === 'routine' && (
          <>
            <Field label="Mô tả công việc" required><input value={f.title} onChange={(e) => up({ title: e.target.value })} placeholder="VD: Kiểm đếm hàng trả về" /></Field>
            <Field label="Chi tiết (tùy chọn)"><textarea value={f.description} onChange={(e) => up({ description: e.target.value })} /></Field>
            <div className="seg">
              <button className={!f.initiative ? 'on' : ''} onClick={() => up({ initiative: false })}>Được yêu cầu</button>
              <button className={f.initiative ? 'on' : ''} onClick={() => up({ initiative: true, requesterMemberId: '' })}>Tự chủ động</button>
            </div>
            {!f.initiative && <Field label="Người yêu cầu" required><Select value={f.requesterMemberId} onChange={(v) => up({ requesterMemberId: v })} options={people} placeholder="— Chọn người —" /></Field>}
            <Field label="Nhóm"><Select value={f.groupId} onChange={(v) => up({ groupId: v })} options={(groups.data || []).map((g: any) => [g.id, g.name])} placeholder="— Nhóm chính của tôi —" /></Field>
            {timeFields}
          </>
        )}

        {mode === 'outside_role' && (
          <>
            <Field label="Công việc đã làm" required><input value={f.title} onChange={(e) => up({ title: e.target.value })} /></Field>
            <Field label="Người giao" required><Select value={f.requesterMemberId} onChange={(v) => up({ requesterMemberId: v })} options={people} placeholder="— Chọn người —" /></Field>
            <Field label="Lý do" required hint="Vì sao bạn làm việc này (ngoài mô tả vai trò)"><textarea value={f.reasonNotInSystem} onChange={(e) => up({ reasonNotInSystem: e.target.value })} /></Field>
            <Field label="Bằng chứng (nếu có)"><input type="file" accept="image/*,application/pdf,video/*" onChange={(e) => setFile(e.target.files?.[0] || null)} /></Field>
            {timeFields}
          </>
        )}

        {mode === 'other' && (
          <>
            <Field label="Tên/nội dung công việc" required><input value={f.title} onChange={(e) => up({ title: e.target.value })} /></Field>
            <Field label="Loại ghi nhận" required><Select value={f.recordType} onChange={(v) => up({ recordType: v })} options={Object.fromEntries(Object.entries(WR_TYPE).filter(([k]) => !['routine', 'outside_role', 'branch'].includes(k)))} /></Field>
            <Field label="Nhóm liên quan" hint="Quản lý nhóm sẽ là người xác nhận; để trống thì gửi cấp trên trực tiếp">
              <Select value={f.groupId} onChange={(v) => up({ groupId: v })} options={(groups.data || []).map((g: any) => [g.id, g.name])} placeholder="— Không chọn —" />
            </Field>
            <Field label="Người giao / người yêu cầu" required>
              {!f.unknown && <Select value={f.requesterMemberId} onChange={(v) => up({ requesterMemberId: v })} options={people} placeholder="— Chọn người —" />}
              <label className="check"><input type="checkbox" checked={f.unknown} onChange={(e) => up({ unknown: e.target.checked })} /> Không rõ người giao</label>
              {f.unknown && <input placeholder="Giải thích vì sao không rõ" value={f.requesterUnknownNote} onChange={(e) => up({ requesterUnknownNote: e.target.value })} />}
            </Field>
            {timeFields}
            <label className="check"><input type="checkbox" checked={f.isEstimated} onChange={(e) => up({ isEstimated: e.target.checked })} /> Thời gian là ước tính</label>
            <Field label="Kết quả đã thực hiện" required><textarea value={f.result} onChange={(e) => up({ result: e.target.value })} /></Field>
            <Field label="Trạng thái hoàn thành"><Select value={f.completionStatus} onChange={(v) => up({ completionStatus: v })} options={{ done: 'Đã hoàn thành', partial: 'Hoàn thành một phần', in_progress: 'Đang làm' }} /></Field>
            <Field label="Lý do chưa có trên hệ thống" required><textarea value={f.reasonNotInSystem} onChange={(e) => up({ reasonNotInSystem: e.target.value })} /></Field>
            <Field label="Bằng chứng (khuyến nghị)"><input type="file" accept="image/*,application/pdf,video/*" onChange={(e) => setFile(e.target.files?.[0] || null)} /></Field>
          </>
        )}
        <ErrorBox error={a.error} />
        <button className="btn primary block" disabled={a.busy} onClick={submit}>{a.busy ? 'Đang gửi…' : 'Gửi khai báo'}</button>
      </div>
    </>
  );
}
