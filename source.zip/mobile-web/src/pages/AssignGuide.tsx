import { useState } from 'react';
import { Link } from 'react-router-dom';
import { get } from '../api';
import { Card, Header, Loading, Tabs, useLoad } from '../ui';
import { Icon, IconChip } from '../icons';

const HOW: [string, string, string, string][] = [
  ['assign', 'blue', 'Mở tab Giao việc', 'Danh sách thành viên theo nhóm; số dưới ảnh là số việc đang có. Bấm ảnh → "Giao việc nhanh".'],
  ['grid', 'teal', 'Chọn mẫu công việc', 'Nhập kho, giao hàng, xử lý nguyên liệu, khiếu nại… Mẫu tự điền mô tả, tiêu chí và gợi ý giấy phép.'],
  ['permit', 'amber', 'Chuẩn bị giấy phép ngay khi giao', 'Đánh dấu giấy cần thiết. "Khai báo" để có hiệu lực ngay — bạn chịu trách nhiệm nếu quy trình sai.'],
  ['calendar', 'purple', 'Xem tình trạng trước khi giao', 'Người đang nghỉ phép, đang bàn giao hoặc quá tải được đánh dấu rõ.'],
  ['phone', 'green', 'Lỡ giao qua điện thoại?', 'Khai việc nhanh trong ngày; người nhận chỉ cần xác nhận.'],
  ['ok', 'blue', 'Nghiệm thu đúng hạn', 'Phản hồi trong 1 ngày làm việc, chấm theo tiêu chí đã giao.'],
];

export default function AssignGuide() {
  const { data } = useLoad(() => get('/hr/procedures'), []);
  const [tab, setTab] = useState('how');
  const std = data?.items.find((p: any) => p.system_key === 'giao_viec_chuan');
  const ref = data?.items.find((p: any) => p.system_key === 'giao_viec_tham_khao');
  const show = tab === 'std' ? std : tab === 'ref' ? ref : null;
  return (
    <>
      <Header title="Hướng dẫn giao việc" back="/hr" />
      <div className="page">
        <Tabs value={tab} onChange={setTab} tabs={[['how', 'Trên app'], ['std', 'Chuẩn công ty'], ['ref', 'Tham khảo']]} />
        {tab === 'how' && (
          <>
            <div className="menu">
              {HOW.map(([ic, tone, t, d]) => <div key={t} style={{ display: 'flex', gap: 12, padding: '12px 14px', borderBottom: '1px solid var(--border)' }}><IconChip name={ic} tone={tone} /><div><b>{t}</b><div className="small muted">{d}</div></div></div>)}
            </div>
            <div className="actions"><Link className="btn primary" to="/assign"><Icon name="assign" size={18} />Bắt đầu giao việc</Link><Link className="btn" to="/hr/flow">Xem sơ đồ quy trình</Link></div>
          </>
        )}
        {tab !== 'how' && !data && <Loading />}
        {show && (
          <>
            <Card><b>{show.title}</b><div className="small" style={{ marginTop: 4 }}>{show.summary}</div></Card>
            <Card><ol className="steps">{show.steps.map((s: any, i: number) => <li key={i}>{s.role && <div className="role">{s.role}</div>}<b>{s.title}</b><div className="small">{s.detail}</div></li>)}</ol></Card>
            {show.reference && <div className="alert info small"><b>Nguồn:</b> {show.reference}</div>}
            <Link className="btn" to={`/hr/procedures/${show.id}`}>Mở quy trình đầy đủ</Link>
          </>
        )}
      </div>
    </>
  );
}
