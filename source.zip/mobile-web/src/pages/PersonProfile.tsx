import { Link, useParams } from 'react-router-dom';
import { useAuth } from '../auth';
import { get } from '../api';
import { Avatar, Card, ErrorBox, Header, KV, Loading, useLoad, Note } from '../ui';
import { ROLE, fmtD } from '../labels';
import { Icon } from '../icons';

export function AutoHistory({ items }: { items: any[] }) {
  if (!items?.length) return <div className="empty">Chưa có dữ liệu — sẽ tự cập nhật khi làm việc trong doanh nghiệp dùng Việc Đến.</div>;
  return (
    <>
      {items.map((h, i) => (
        <Card key={i}>
          <div className="row" style={{ display: 'flex', gap: 8 }}><b style={{ flex: 1 }}>{h.company_name}</b><span className="small muted">{fmtD(h.joined_at)} → {h.status === 'active' ? 'nay' : fmtD(h.left_at)}</span></div>
          <div className="small muted">{ROLE[h.role]}{h.title ? ` · ${h.title}` : ''}{h.department ? ` · ${h.department}` : ''}{h.groups.length ? ` · Nhóm: ${h.groups.join(', ')}` : ''}</div>
          <KV k="Nhiệm vụ hoàn thành" v={`${h.tasks_completed} (đúng hạn ${h.on_time_rate ?? '—'}%)`} />
          <KV k="Điểm nghiệm thu trung bình" v={h.avg_task_score ?? '—'} />
          <KV k="Việc phức tạp / đột xuất" v={`${h.complex_completed} / ${h.unexpected_completed}`} />
          <KV k="Việc tự khai được xác nhận" v={`${h.accepted_self_reports} (${h.accepted_self_report_hours} giờ)`} />
          <KV k="Tăng ca đã xác nhận" v={`${h.confirmed_overtime_hours} giờ`} />
          <KV k="Nghỉ phép đã duyệt" v={`${h.approved_leave_hours} giờ (đột xuất: ${h.sudden_leaves})`} />
          {h.finalized_scores.length > 0 && <KV k="Điểm hiệu suất đã chốt" v={h.finalized_scores.map((s: any) => `${s.period}: ${s.E}`).join(' · ')} />}
        </Card>
      ))}
    </>
  );
}

export default function PersonProfile() {
  const { userId } = useParams();
  const { me } = useAuth();
  const { data: d, error, loading } = useLoad(() => get(`/profiles/${userId}`), [userId]);
  if (loading && !d) return <Loading />;
  if (!d) return <div className="page"><ErrorBox error={error} /></div>;
  const p = d.profile;
  return (
    <>
      <Header title="Hồ sơ nhân sự" back />
      <div className="page">
        <Card>
          <div style={{ display: 'flex', gap: 14, alignItems: 'center' }}>
            <Avatar userId={d.user.id} name={d.user.name} has={d.user.has_avatar} size="lg" />
            <div><h2>{d.user.name}</h2><div className="small muted">{d.user.phone ? d.user.phone : 'Liên lạc qua ứng dụng'}{d.user.email ? ` · ${d.user.email}` : ''}</div>{p.desired_position && <div className="small">Mong muốn: {p.desired_position}</div>}</div>
          </div>
        </Card>
        <div className="section-title">Thông tin cá nhân</div>
        <Card>
          <KV k="Ngày sinh" v={p.dob ? fmtD(p.dob) : 'Ẩn / không khai'} /><KV k="Địa chỉ" v={p.address || 'Ẩn / không khai'} />
          <KV k="Email liên hệ" v={p.contact_email || 'Ẩn / không khai'} /><KV k="Học vấn" v={p.education} />
          {p.summary && <div className="crit small" style={{ marginTop: 6 }}>{p.summary}</div>}
        </Card>
        <div className="section-title">Kinh nghiệm</div>
        <Card><KV k="Số năm" v={p.years_experience} /><KV k="Lĩnh vực" v={p.field} /><KV k="Kỹ năng" v={p.skills} /><KV k="Chứng chỉ" v={p.certificates} /></Card>
        <div className="section-title">Lịch sử làm việc (tự khai)</div>
        {d.work_history.length === 0 && <div className="empty">{d.work_history_hidden ? 'Người dùng chọn không chia sẻ' : 'Chưa khai'}</div>}
        {d.work_history.map((h: any) => <Card key={h.id}><b>{h.position || '—'}</b> · {h.company_name}<div className="small muted">{h.start_date?.slice(0, 7) || '?'} → {h.end_date?.slice(0, 7) || 'nay'}</div>{h.description && <div className="small">{h.description}</div>}</Card>)}
        <div className="section-title">Quá trình làm việc do Việc Đến ghi nhận</div>
        {d.other_companies_hidden && <Note>Người này chưa đồng ý chia sẻ lịch sử ở doanh nghiệp khác; chỉ hiện dữ liệu tại doanh nghiệp của bạn.</Note>}
        <AutoHistory items={d.auto_history} />
        {d.privacy_note && <Note style={{ marginTop: 12 }}><Icon name="lock" size={14} />{d.privacy_note}</Note>}
        {d.user.id !== me?.user_id && <p className="small" style={{ marginTop: 8 }}><Link to={`/conduct/new?objectType=profile&objectLabel=${encodeURIComponent('Hồ sơ ' + d.user.name)}&reportedUser=${d.user.id}`} className="muted">Báo cáo hành vi cần xem xét</Link></p>}
      </div>
    </>
  );
}
