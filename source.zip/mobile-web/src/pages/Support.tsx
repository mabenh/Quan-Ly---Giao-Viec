import { useState } from 'react';
import { useNavigate, useParams, useSearchParams } from 'react-router-dom';
import { get, post } from '../api';
import { tierOf, useAuth } from '../auth';
import { Badge, Card, ErrorBox, Field, Header, KV, Loading, Select, useAction, useLoad, Note } from '../ui';
import { Icon } from '../icons';
import { ContactButtons } from '../comms';
import { fmtDT } from '../labels';

export const SR_STATUS: Record<string, [string, string]> = { open: ['Đang cần hỗ trợ', 'amber'], accepted: ['Đã đủ người', 'blue'], closed: ['Đã đóng', 'gray'], cancelled: ['Đã hủy', 'gray'] };
const RESP: Record<string, [string, string]> = { declined: ['Từ chối', 'gray'], cancelled: ['Yêu cầu đã hủy', 'gray'], accepted: ['Đồng ý / đã tiếp nhận', 'blue'], done: ['Chờ người yêu cầu xác nhận', 'amber'], confirmed: ['Đã xác nhận — đã ghi nhận công', 'green'], rejected: ['Không xác nhận', 'red'], withdrawn: ['Rút lại', 'gray'] };

/** Gửi yêu cầu hỗ trợ: thông báo tới các thành viên khác trong nhóm. */
export function SupportForm() {
  const nav = useNavigate();
  const [sp] = useSearchParams();
  const taskId = sp.get('taskId') || '';
  const groups = useLoad(() => get('/groups'), []);
  const task = useLoad(() => (taskId ? get(`/tasks/${taskId}`) : Promise.resolve(null)), [taskId]);
  const { me } = useAuth();
  const ledGroups = (groups.data || []).filter((g: any) => g.leader_id === me?.member_id || g.manager_member_id === me?.member_id || g.assignable);
  const canDept = tierOf(me) <= 5 && !!me?.authority?.department_id;
  const canCall = canDept || ledGroups.length > 0;
  const [f, setF] = useState({ title: '', description: '', groupId: '', neededPeople: 1, mode: sp.get('call') ? 'group' : 'ask' });
  const a = useAction();
  return (
    <>
      <Header title="Yêu cầu hỗ trợ" back />
      <div className="page">
        {canCall && <div className="seg"><button className={f.mode === 'ask' ? 'on' : ''} onClick={() => setF({ ...f, mode: 'ask' })}>Yêu cầu hỗ trợ</button>
          {ledGroups.length > 0 && <button className={f.mode === 'group' ? 'on' : ''} onClick={() => setF({ ...f, mode: 'group', groupId: f.groupId || ledGroups[0]?.id || '' })}>Kêu gọi toàn nhóm</button>}
          {canDept && <button className={f.mode === 'department' ? 'on' : ''} onClick={() => setF({ ...f, mode: 'department' })}>Kêu gọi toàn phòng</button>}</div>}
        <Note>{f.mode === 'ask' ? <>Yêu cầu được đẩy ra mục thông báo của các thành viên trong nhóm. Ai rảnh có thể bấm <b>Tiếp nhận</b>; phần hỗ trợ chỉ được ghi nhận công khi <b>bạn xác nhận</b>.</>
          : <>Kêu gọi gửi tới <b>{f.mode === 'department' ? `toàn phòng ${me?.authority?.department || ''}` : 'toàn bộ thành viên nhóm'}</b>. Mỗi người chọn <b>Đồng ý</b> hoặc <b>Từ chối</b> — hỗ trợ không bắt buộc, không phát sinh giao việc/khai việc; người đồng ý có tên trong danh sách hỗ trợ và thời gian hỗ trợ được ghi nhận. Yêu cầu nằm trong "Việc của tôi" của bạn.</>}</Note>
        {task.data && <div className="alert info small">Cho nhiệm vụ <b>{task.data.code} - {task.data.title}</b></div>}
        <Field label="Cần hỗ trợ việc gì" required><input value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} placeholder="VD: Cần 1 người phụ bốc xếp 40 bao lên xe" /></Field>
        <Field label="Chi tiết (thời gian, địa điểm, dụng cụ…)"><textarea value={f.description} onChange={(e) => setF({ ...f, description: e.target.value })} /></Field>
        <div className="grid2">
          {!taskId && f.mode !== 'department' && <Field label="Nhóm"><Select value={f.groupId} onChange={(v) => setF({ ...f, groupId: v })} options={(f.mode === 'group' ? ledGroups : groups.data || []).map((g: any) => [g.id, g.name])} placeholder="— Nhóm của tôi —" /></Field>}
          <Field label="Số người cần"><input type="number" min={1} max={20} value={f.neededPeople} onChange={(e) => setF({ ...f, neededPeople: Number(e.target.value) || 1 })} /></Field>
        </div>
        <ErrorBox error={a.error} />
        <button className="btn primary block" disabled={a.busy || f.title.trim().length < 3} onClick={() => a.run(async () => {
          const r = await post('/support-requests', { title: f.title, description: f.description || undefined, taskId: taskId || undefined, groupId: f.groupId || undefined, neededPeople: f.neededPeople,
            broadcast: f.mode === 'ask' ? undefined : f.mode });
          nav(`/support/${r.id}`, { replace: true });
        })}><Icon name="users" size={18} />{f.mode === 'ask' ? 'Gửi yêu cầu hỗ trợ' : 'Gửi kêu gọi hỗ trợ'}</button>
      </div>
    </>
  );
}

export function SupportDetail() {
  const { id } = useParams();
  const { me } = useAuth();
  const { data: r, error, reload } = useLoad(() => get(`/support-requests/${id}`), [id]);
  const a = useAction();
  const [mins, setMins] = useState(''); const [note, setNote] = useState('');
  const [dec, setDec] = useState<Record<string, { minutes: string; note: string }>>({});
  if (!r) return <><Header title="Yêu cầu hỗ trợ" back /><div className="page"><ErrorBox error={error} />{!error && <Loading />}</div></>;
  const st = SR_STATUS[r.status];
  const act = (fn: () => Promise<any>) => a.run(async () => { await fn(); reload(); });
  return (
    <>
      <Header title={r.code} back />
      <div className="page">
        <h2>{r.title}</h2>
        <div className="chip-row"><Badge tone={st[1]}>{st[0]}</Badge>{r.broadcast && <Badge tone="purple">Kêu gọi {r.broadcast === 'department' ? 'toàn phòng' : 'toàn nhóm'}</Badge>}<span className="small muted">Cần {r.needed_people} người · {r.responses.filter((x: any) => ['accepted', 'done', 'confirmed'].includes(x.status)).length} đồng ý</span></div>
        {r.cancel_reason && <div className="alert warn small">Đã hủy: {r.cancel_reason}</div>}
        <Card>
          <KV k="Người yêu cầu" v={r.requester_name} />
          <KV k="Nhóm" v={r.group_name || '—'} />
          {r.task_code && <KV k="Nhiệm vụ" v={`${r.task_code} - ${r.task_title}`} />}
          <KV k="Lúc" v={fmtDT(r.created_at)} />
          {r.description && <p className="small" style={{ whiteSpace: 'pre-wrap' }}>{r.description}</p>}
          {r.requester_id !== me?.member_id && <ContactButtons memberId={r.requester_id} name={r.requester_name} zalo={false} />}
        </Card>
        {(r.permissions.can_accept || r.permissions.can_decline) && (
          <div className="actions">
            {r.permissions.can_accept && <button className="btn primary" style={{ flex: 1 }} disabled={a.busy} onClick={() => act(() => post(`/support-requests/${id}/accept`))}><Icon name="ok" size={18} />{r.broadcast ? 'Đồng ý hỗ trợ' : 'Tiếp nhận hỗ trợ'}</button>}
            {r.permissions.can_decline && <button className="btn" disabled={a.busy} onClick={() => act(() => post(`/support-requests/${id}/decline`, {}))}>Từ chối</button>}
          </div>
        )}
        {r.permissions.can_start && <button className="btn primary block" disabled={a.busy} onClick={() => act(() => post(`/support-requests/${id}/start`))}><Icon name="timer" size={18} />Bắt đầu hỗ trợ (ghi nhận thời gian)</button>}
        {r.permissions.is_supporting && <div className="alert info small">Bạn đang hỗ trợ yêu cầu này — kết thúc trên thẻ phiên làm việc ở Trang chủ hoặc <button className="btn sm" onClick={() => act(() => post('/support-sessions/end', {}))}>Kết thúc hỗ trợ</button></div>}
        {r.permissions.can_done && (
          <Card>
            <b className="small">Báo đã hỗ trợ xong</b>
            <div className="grid2">
              <Field label="Số phút đã hỗ trợ" required><input type="number" min={1} value={mins} onChange={(e) => setMins(e.target.value)} /></Field>
              <Field label="Ghi chú"><input value={note} onChange={(e) => setNote(e.target.value)} /></Field>
            </div>
            <button className="btn primary block" disabled={a.busy || !Number(mins)} onClick={() => act(() => post(`/support-requests/${id}/done`, { minutes: Number(mins), note: note || undefined }))}>Gửi để người yêu cầu xác nhận</button>
            <Note>Phần hỗ trợ chỉ được ghi nhận khi người yêu cầu xác nhận.</Note>
          </Card>
        )}
        <div className="section-title">Danh sách hỗ trợ</div>
        {r.responses.length === 0 && <div className="empty">Chưa có ai tiếp nhận</div>}
        {r.responses.map((x: any) => {
          const s = RESP[x.status]; const d = dec[x.id] || { minutes: String(x.minutes || ''), note: '' };
          return (
            <Card key={x.id}>
              <div className="row"><b style={{ flex: 1 }}>{x.helper_name}</b><Badge tone={s[1]}>{s[0]}</Badge></div>
              <div className="small muted">Tiếp nhận {fmtDT(x.accepted_at)}{x.minutes ? ` · khai ${x.minutes} phút` : ''}{x.note ? ` · ${x.note}` : ''}</div>
              {x.decision_note && <div className="small">Phản hồi: {x.decision_note}</div>}
              {r.permissions.can_confirm && ['accepted', 'done'].includes(x.status) && (
                <div style={{ marginTop: 6 }}>
                  <div className="grid2">
                    <Field label="Số phút xác nhận"><input type="number" min={1} value={d.minutes} onChange={(e) => setDec({ ...dec, [x.id]: { ...d, minutes: e.target.value } })} /></Field>
                    <Field label="Ghi chú (bắt buộc khi không xác nhận)"><input value={d.note} onChange={(e) => setDec({ ...dec, [x.id]: { ...d, note: e.target.value } })} /></Field>
                  </div>
                  <div className="actions">
                    <button className="btn primary" disabled={a.busy || !Number(d.minutes)} onClick={() => act(() => post(`/support-requests/${id}/responses/${x.id}/decide`, { decision: 'confirm', minutes: Number(d.minutes), note: d.note || undefined }))}>Xác nhận đã hỗ trợ</button>
                    <button className="btn danger" disabled={a.busy || d.note.trim().length < 5} onClick={() => act(() => post(`/support-requests/${id}/responses/${x.id}/decide`, { decision: 'reject', note: d.note }))}>Không xác nhận</button>
                  </div>
                </div>
              )}
            </Card>
          );
        })}
        {r.permissions.can_close && <div className="actions"><button className="btn" disabled={a.busy} onClick={() => act(() => post(`/support-requests/${id}/close`, {}))}>Đóng yêu cầu</button>
          <button className="btn danger" disabled={a.busy} onClick={() => { const reason = prompt('Lý do hủy (người đã nhận sẽ được báo):') ?? undefined; if (reason !== undefined) act(() => post(`/support-requests/${id}/close`, { cancel: true, reason: reason || undefined })); }}>Hủy yêu cầu</button></div>}
        <ErrorBox error={a.error} />
      </div>
    </>
  );
}
