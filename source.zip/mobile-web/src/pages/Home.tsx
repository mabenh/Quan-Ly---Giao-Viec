import { Link } from 'react-router-dom';
import { get } from '../api';
import { isManagerRole, useAuth } from '../auth';
import { Badge, Card, ErrorBox, Loading, useLoad } from '../ui';
import { TASK_STATUS, TASK_TONE, relDue } from '../labels';

const Stat = ({ n, l, to, tone }: { n: number; l: string; to: string; tone?: 'warn' | 'attn' }) => (
  <Link to={to} className={`stat ${n > 0 && tone ? tone : ''}`}><div className="n">{n}</div><div className="l">{l}</div></Link>
);

export default function Home() {
  const { me } = useAuth();
  const { data: d, error, loading } = useLoad(() => get('/dashboard'), []);
  if (loading && !d) return <Loading />;
  if (!d) return <div className="page"><ErrorBox error={error} /></div>;
  const m = d.me; const g = d.manage;
  const mgr = isManagerRole(me?.role) || me?.role === 'reviewer';
  const handler = me?.role === 'handler' || (me?.headed_departments?.length ?? 0) > 0;
  return (
    <div className="page">
      <h1 style={{ margin: '6px 0 2px' }}>Xin chào, {me?.name?.split(' ').slice(-1)[0]} 👋</h1>
      <p className="muted small" style={{ margin: 0 }}>{new Date().toLocaleDateString('vi-VN', { weekday: 'long', day: '2-digit', month: '2-digit', year: 'numeric' })}</p>

      <div className="quick">
        <Link className="btn" to="/work-records/new">📝 Ghi nhận công việc</Link>
        <Link className="btn" to="/reports/new">⚠️ Báo cáo trở ngại</Link>
      </div>

      <div className="section-title">Việc của tôi</div>
      <div className="stats">
        <Stat n={m.tasks.due_today} l="Đến hạn hôm nay" to="/work?tab=tasks&mine=any" tone="attn" />
        <Stat n={m.tasks.due_soon} l="Sắp đến hạn (48h)" to="/work?tab=tasks&mine=any" tone="attn" />
        <Stat n={m.tasks.overdue} l="Quá hạn" to="/work?tab=tasks&mine=any&overdue=true" tone="warn" />
        <Stat n={m.tasks.revision} l="Cần chỉnh sửa" to="/work?tab=tasks&mine=any&status=revision_requested" tone="warn" />
        <Stat n={m.work_records.need_response} l="Bản ghi cần tôi phản hồi" to="/work?tab=records" tone="warn" />
        <Stat n={m.work_records.waiting_manager} l="Bản ghi chờ xác nhận" to="/work?tab=records" />
        <Stat n={m.reports.open} l="Trở ngại đang mở" to="/work?tab=reports" />
        <Stat n={m.reports.need_confirm} l="Trở ngại chờ tôi xác nhận" to="/work?tab=reports" tone="attn" />
      </div>

      {(mgr || g.work_records_to_review.n > 0 || g.escalations_open > 0 || g.appeals_to_resolve > 0) && (
        <>
          <div className="section-title">Cần tôi xử lý</div>
          <div className="stats">
            <Stat n={g.tasks_pending_review} l="Việc chờ nghiệm thu" to="/work?tab=tasks&status=pending_review" tone="attn" />
            <Stat n={g.work_records_to_review.n} l={`Bản ghi cần xác nhận${g.work_records_to_review.overdue ? ` (${g.work_records_to_review.overdue} quá hạn)` : ''}`} to="/work?tab=records&scope=review" tone="warn" />
            <Stat n={g.overtime_pending} l="Tăng ca chờ xác nhận" to="/work?tab=overtime&scope=team" tone="attn" />
            <Stat n={g.appeals_to_resolve} l="Khiếu nại cần giải quyết" to="/work?tab=records&scope=review" tone="warn" />
            <Stat n={g.reports_holding.n} l={`Báo cáo trở ngại đang giữ${g.reports_holding.near_due ? ` · ${g.reports_holding.near_due} gần hạn` : ''}`} to="/work?tab=reports&scope=handling" tone="attn" />
            <Stat n={g.reports_holding.overdue} l="Trở ngại quá SLA" to="/work?tab=reports&scope=handling" tone="warn" />
            <Stat n={g.escalations_open} l="Chuyển cấp đến tôi" to="/escalations" tone="warn" />
            <Stat n={g.team_tasks.overdue} l={`Việc nhóm quá hạn / ${g.team_tasks.open} đang mở`} to="/work?tab=tasks&overdue=true" tone="warn" />
          </div>
        </>
      )}
      {handler && <Link to="/tech" className="btn block" style={{ marginTop: 12 }}>🛠 Bảng điều khiển kỹ thuật</Link>}

      <div className="section-title">Nhiệm vụ đang mở của tôi</div>
      {m.tasks_list.length === 0 && <div className="empty">Không có nhiệm vụ đang mở 🎉</div>}
      {m.tasks_list.map((t: any) => (
        <Card key={t.id} to={`/tasks/${t.id}`}>
          <div className="row"><span className="title ellipsis" style={{ flex: 1 }}>{t.title}</span><Badge tone={TASK_TONE[t.status]}>{TASK_STATUS[t.status]}</Badge></div>
          <div className="row small muted" style={{ marginTop: 4 }}>
            <span>{t.code} · {t.group_name}</span><span className="spacer" />
            {t.is_overdue ? <Badge tone="red">⏰ {relDue(t.due_at)}</Badge> : <span>Hạn: {relDue(t.due_at)}</span>}
          </div>
        </Card>
      ))}
    </div>
  );
}
