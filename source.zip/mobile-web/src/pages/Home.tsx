import { useState } from 'react';
import { Link } from 'react-router-dom';
import { get, qs } from '../api';
import { isHRRole, isManagerRole, useAuth } from '../auth';
import { Badge, Card, ErrorBox, Loading, Tabs, useLoad } from '../ui';
import Calendar from '../Calendar';
import { Icon, IconChip } from '../icons';
import { DECISION_STATUS, DECISION_TYPE, LEAVE_TYPE, TASK_STATUS, TASK_TONE, fmtD, fmtDT, isoDate, relDue } from '../labels';

type Tile = [number, string, string, ('warn' | 'attn')?, string?];
const Stat = ({ t: [n, l, to, tone, ic] }: { t: Tile }) => (
  <Link to={to} className={`stat ${n > 0 && tone ? tone : ''}`}>
    <IconChip name={ic || 'list'} tone={tone === 'warn' ? 'red' : tone === 'attn' ? 'amber' : 'blue'} size={19} />
    <div style={{ minWidth: 0 }}><div className="n">{n}</div><div className="l">{l}</div></div>
  </Link>
);

export function TaskRow({ t, showOwner }: { t: any; showOwner?: boolean }) {
  return (
    <Card to={`/tasks/${t.id}`} className={t.pinned ? 'pinned' : ''}>
      <div className="row">{t.pinned && <span className="pin" title="Việc gấp được ghim">📌</span>}<span className="title" style={{ flex: 1 }}>{t.title}</span><Badge tone={TASK_TONE[t.status]}>{TASK_STATUS[t.status]}</Badge></div>
      <div className="row small muted" style={{ marginTop: 4 }}>
        <span>{t.code} · {t.group_name}{showOwner && t.owner_name ? ` · ${t.owner_name}` : ''}</span><span className="spacer" />
        {t.is_overdue ? <Badge tone="red">⏰ {relDue(t.due_at)}</Badge> : <span>Hạn: {relDue(t.due_at)}</span>}
      </div>
      {(t.urgent || t.carry_count > 0) && (
        <div className="chip-row">
          {t.urgent && <Badge tone="red">Gấp</Badge>}
          {t.carry_count > 0 && <Badge tone="amber">↪ Chuyển từ {fmtD(t.original_plan_date)} ({t.carry_count} ngày)</Badge>}
        </div>
      )}
    </Card>
  );
}

export default function Home() {
  const { me } = useAuth();
  const [day, setDay] = useState(isoDate(new Date()));
  const [today, setToday] = useState(isoDate(new Date()));
  const [picked, setPicked] = useState(false);
  const mgr = isManagerRole(me?.role) || me?.role === 'reviewer';
  const [scope, setScope] = useState<'mine' | 'team'>('mine');
  const { data: d, error, loading } = useLoad(() => get('/dashboard'), []);
  const dayList = useLoad(() => get('/tasks' + qs({ planDate: day, mine: scope === 'mine' ? 'any' : undefined, limit: 100 })), [day, scope]);
  const cal = useLoad(() => get('/calendar' + qs({ from: day, to: day, scope })), [day, scope]);
  if (loading && !d) return <Loading />;
  if (!d) return <div className="page"><ErrorBox error={error} /></div>;
  const m = d.me; const g = d.manage;
  const isToday = day === today;
  const myTiles: Tile[] = ([
    [m.tasks.pinned, 'Việc gấp được ghim', '/work?tab=tasks&mine=any&pinned=true', 'warn', 'pin'],
    [m.tasks.overdue, 'Quá hạn', '/work?tab=tasks&mine=any&overdue=true', 'warn', 'clock'],
    [m.tasks.revision, 'Cần chỉnh sửa', '/work?tab=tasks&mine=any&status=revision_requested', 'warn', 'warn'],
    [m.tasks.due_soon, 'Sắp đến hạn (48h)', '/work?tab=tasks&mine=any', 'attn', 'timer'],
    [g.claims_to_confirm, 'Khai việc chờ tôi xác nhận', '/work?tab=claims', 'warn', 'headset'],
    [m.work_records.need_response, 'Bản ghi cần tôi phản hồi', '/work?tab=records', 'warn', 'record'],
    [m.reports.need_confirm, 'Trở ngại chờ tôi xác nhận', '/work?tab=reports', 'attn', 'alert'],
    [m.claims_waiting, 'Khai việc chờ người kia xác nhận', '/work?tab=claims', undefined, 'headset'],
    [m.work_records.waiting_manager, 'Bản ghi chờ quản lý xác nhận', '/work?tab=records', undefined, 'record'],
    [m.leaves.pending, 'Đơn nghỉ chờ duyệt', '/work?tab=leaves', undefined, 'leave'],
    [m.permits_active, 'Giấy phép đang hiệu lực', '/work?tab=permits', undefined, 'permit'],
    [m.reports.open, 'Trở ngại tôi báo đang mở', '/work?tab=reports', undefined, 'alert'],
  ] as Tile[]).filter((t) => t[0] > 0);
  const manageTiles: Tile[] = ([
    [g.tasks_pending_review, 'Việc chờ nghiệm thu', '/work?tab=tasks&status=pending_review', 'attn', 'ok'],
    [g.decisions_to_confirm, 'Bàn giao chờ tôi xác nhận', '/hr/decisions', 'warn', 'decision'],
    [g.permits_to_decide, 'Giấy phép chờ bộ phận cấp', '/work?tab=permits&scope=handling&status=pending', 'warn', 'permit'],
    [g.permits_to_review, 'Giấy phép khai báo cần hậu kiểm', '/work?tab=permits&scope=handling&review=pending', 'attn', 'permit'],
    [g.work_records_to_review.n, `Bản ghi cần xác nhận${g.work_records_to_review.overdue ? ` (${g.work_records_to_review.overdue} quá hạn)` : ''}`, '/work?tab=records&scope=review', 'warn', 'record'],
    [g.leaves_to_approve, 'Đơn nghỉ cần duyệt', '/work?tab=leaves&scope=approve', 'warn', 'leave'],
    [g.members_pending_hr, 'Thành viên chờ nhân sự duyệt', '/admin/members', 'warn', 'userCog'],
    [g.overtime_pending, 'Tăng ca chờ xác nhận', '/work?tab=overtime&scope=team', 'attn', 'timer'],
    [g.appeals_to_resolve, 'Khiếu nại cần giải quyết', '/work?tab=records&scope=review', 'warn', 'warn'],
    [g.reports_holding.n, `Trở ngại đang giữ${g.reports_holding.near_due ? ` · ${g.reports_holding.near_due} gần hạn` : ''}`, '/work?tab=reports&scope=handling', 'attn', 'alert'],
    [g.reports_holding.overdue, 'Trở ngại quá SLA', '/work?tab=reports&scope=handling', 'warn', 'alert'],
    [g.escalations_open, 'Chuyển cấp đến tôi', '/escalations', 'warn', 'promote'],
    [mgr ? g.team_tasks.overdue : 0, 'Việc nhóm quá hạn', '/work?tab=tasks&overdue=true', 'warn', 'clock'],
  ] as Tile[]).filter((t) => t[0] > 0);
  const leaves = cal.data?.days?.[0]?.leaves || [];
  const dueToday = cal.data?.days?.[0]?.due_open || 0;

  return (
    <div className="page">
      <div className="hero">
        <div className="muted small">{new Date().toLocaleDateString('vi-VN', { weekday: 'long', day: '2-digit', month: '2-digit', year: 'numeric' })}</div>
        <h1>Xin chào, {me?.name?.split(' ').slice(-1)[0]}</h1>
        <div className="chips">
          <Link to="/work?tab=tasks&mine=any"><Icon name="tasks" size={14} />{m.tasks.open} việc đang mở</Link>
          {m.tasks.overdue > 0 && <Link to="/work?tab=tasks&mine=any&overdue=true"><Icon name="clock" size={14} />{m.tasks.overdue} quá hạn</Link>}
          {d.unread_notifications > 0 && <Link to="/notifications"><Icon name="bell" size={14} />{d.unread_notifications} thông báo</Link>}
        </div>
      </div>
      {m.decision && (
        <Link to={`/decisions/${m.decision.id}`} className="banner amber">
          <IconChip name="decision" tone="amber" />
          <div style={{ flex: 1 }}><b>Quyết định {DECISION_TYPE[m.decision.decision_type].toLowerCase()} {m.decision.code}</b>
            <div className="small">{DECISION_STATUS[m.decision.status]} · hạn bàn giao {fmtDT(m.decision.handover_deadline)}. Chưa nhận việc mới cho tới khi bàn giao được xác nhận.</div></div>
          <Icon name="chevron" />
        </Link>
      )}
      {mgr && <Tabs value={scope} onChange={(v) => setScope(v as any)} tabs={[['mine', 'Lịch của tôi'], ['team', 'Lịch nhóm tôi quản lý']]} />}
      <Calendar selected={day} onSelect={(d) => { setPicked(true); setDay(d); }} scope={scope} refreshKey={scope} onToday={(t) => { setToday(t); if (!picked) setDay(t); }} />

      <div className="row" style={{ display: 'flex', alignItems: 'center', marginTop: 4 }}>
        <div className="section-title" style={{ flex: 1, margin: '10px 0 4px' }}>{isToday ? 'Việc hôm nay' : `Việc ngày ${fmtD(day)}`} ({dayList.data?.items.length ?? 0})</div>
        {dueToday > 0 && <Badge tone="amber">{dueToday} hạn chót</Badge>}
      </div>
      {leaves.length > 0 && <div className="alert info small">🌴 Nghỉ phép: {leaves.map((l: any) => `${l.name} (${LEAVE_TYPE[l.leave_type].toLowerCase()}${l.status === 'pending' ? ', chờ duyệt' : ''})`).join('; ')}</div>}
      {dayList.data && dayList.data.items.length === 0 && <div className="empty">Không có việc trong ngày này 🎉</div>}
      {dayList.data?.items.map((t: any) => <TaskRow key={t.id} t={t} showOwner={scope === 'team'} />)}
      {isToday && <p className="small muted">Việc chưa được xác nhận hoàn thành sẽ tự chuyển sang danh sách ngày hôm sau.</p>}

      <div className="tiles">
        {(mgr ? [['/assign', 'assign', 'blue', 'Giao việc']] : [['/work-records/new', 'record', 'blue', 'Ghi nhận công việc']]).concat([
          ['/quick/new', 'headset', 'teal', 'Khai việc nhanh'], ['/leaves/new', 'leave', 'green', 'Xin nghỉ phép'], ['/reports/new', 'alert', 'amber', 'Báo trở ngại'],
        ]).map(([to, ic, tone, l]) => <Link key={to} to={to} className="tile"><IconChip name={ic} tone={tone} />{l}</Link>)}
      </div>

      {myTiles.length > 0 && <><div className="section-title">Việc của tôi</div><div className="stats">{myTiles.map((t) => <Stat key={t[1]} t={t} />)}</div></>}
      {manageTiles.length > 0 && <><div className="section-title">Cần tôi xử lý</div><div className="stats">{manageTiles.map((t) => <Stat key={t[1]} t={t} />)}</div></>}
      {myTiles.length === 0 && manageTiles.length === 0 && <div className="empty">Không có mục nào cần bạn xử lý lúc này ✅</div>}
      <div className="actions">
        {mgr && <Link to="/team" className="btn"><Icon name="calendar" size={18} />Tình trạng nhân sự tuần</Link>}
        {(me?.role === 'handler' || (me?.headed_departments?.length ?? 0) > 0) && <Link to="/work?tab=permits&scope=handling" className="btn"><Icon name="permit" size={18} />Giấy phép bộ phận</Link>}
        {(me?.role === 'handler' || (me?.headed_departments?.length ?? 0) > 0) && <Link to="/tech" className="btn"><Icon name="wrench" size={18} />Bảng kỹ thuật</Link>}
        {isHRRole(me?.role) && g.members_pending_hr > 0 && <Link to="/admin/members" className="btn"><Icon name="userCog" size={18} />Duyệt thành viên</Link>}
      </div>
    </div>
  );
}
