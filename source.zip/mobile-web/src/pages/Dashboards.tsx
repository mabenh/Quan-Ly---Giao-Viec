import { useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { get, post } from '../api';
import { Badge, Card, Empty, ErrorBox, Field, Header, KV, Loading, Select, Sheet, Tabs, useAction, useLoad } from '../ui';
import { RISK, TIME_CAT, fmtD, fmtDT, mins } from '../labels';
import { SessionCard } from '../session';

const PERIODS: [string, string][] = [['day', 'Hôm nay'], ['week', 'Tuần này'], ['month', 'Tháng này']];

function Kpi({ n, l, d, good = 'up', to }: { n: any; l: string; d?: number | null; good?: 'up' | 'down'; to?: string }) {
  const cls = d === null || d === undefined || d === 0 ? '' : (d > 0) === (good === 'up') ? 'up' : 'down';
  const body = <><div className="n">{n ?? '—'}</div><div className="l">{l}</div>{d !== null && d !== undefined && d !== 0 && <div className={`d ${cls}`}>{d > 0 ? '▲' : '▼'} {Math.abs(d)} so với kỳ trước</div>}</>;
  return to ? <Link to={to} className="kpi">{body}</Link> : <div className="kpi">{body}</div>;
}

function Trend({ data }: { data: any[] }) {
  const max = Math.max(1, ...data.map((d) => Math.max(d.created, d.completed)));
  return (
    <>
      <div className="bars" aria-label="Việc mới và hoàn thành 14 ngày">
        {data.map((d) => <div className="b" key={d.day} title={`${fmtD(d.day)}: mới ${d.created}, xong ${d.completed}`}><i className="n" style={{ height: `${(d.created / max) * 60}px` }} /><i className="c" style={{ height: `${(d.completed / max) * 60}px` }} /></div>)}
      </div>
      <div className="small muted">14 ngày gần nhất · <span style={{ color: '#1d6fe0' }}>■</span> hoàn thành · <span style={{ color: '#98a2b3' }}>■</span> việc mới</div>
    </>
  );
}

function GroupTable({ groups }: { groups: any[] }) {
  return (
    <div className="tbl-wrap"><table className="tbl">
      <thead><tr><th>Nhóm</th><th className="num">Xong</th><th className="num">Đúng hạn</th><th className="num">Tồn</th><th className="num">Quá hạn</th><th className="num">Đạt chuẩn</th><th className="num">Lỗi %</th><th className="num">Hiệu suất</th><th className="num">Chờ</th><th className="num">BG đạt</th></tr></thead>
      <tbody>{groups.map((g) => (
        <tr key={g.id}><td><Link to={`/groups/${g.id}`}>{g.name}</Link></td><td className="num">{g.completed}</td><td className="num">{g.on_time_rate ?? '—'}%</td><td className="num">{g.backlog}</td>
          <td className="num" style={{ color: g.overdue ? 'var(--red)' : undefined }}>{g.overdue}</td><td className="num">{g.accepted_qty || '—'}</td><td className="num">{g.defect_rate ?? '—'}</td>
          <td className="num">{g.efficiency !== null ? `${g.efficiency}%` : '—'}</td><td className="num">{mins(g.waiting_minutes)}</td><td className="num">{g.handover_pass_rate !== null ? `${g.handover_pass_rate}%` : '—'}</td></tr>
      ))}</tbody>
    </table></div>
  );
}

export function ChainRow({ c }: { c: any }) {
  const r = RISK[c.risk] || RISK.normal;
  return (
    <Card to={`/chains/${c.id}`}>
      <div className="row"><b>{c.chain_code}</b><span className="ellipsis" style={{ flex: 1 }}> · {c.title}</span><Badge tone={r[1]}>{r[0]}</Badge></div>
      <div className="timebar"><i style={{ width: `${c.progress}%`, background: '#12a150' }} /></div>
      <div className="small muted">{c.done}/{c.total} công đoạn · hạn {fmtDT(c.due_at)}{c.customer_name ? ` · ${c.customer_name}` : ''}{c.order_value ? ` · ${Number(c.order_value).toLocaleString('vi-VN')} đ` : ''}</div>
      {c.bottleneck && <div className="small" style={{ color: ['at_risk', 'overdue'].includes(c.bottleneck.risk) ? 'var(--red)' : undefined }}>↳ Công đoạn {['at_risk', 'overdue'].includes(c.bottleneck.risk) ? 'gây tắc' : 'đang chạy'}: {c.bottleneck.title} ({c.bottleneck.group_name})</div>}
    </Card>
  );
}

function Overview({ d }: { d: any }) {
  const c = d.compare;
  return (
    <>
      <div className="kpis">
        <Kpi n={d.totals.new} l="Việc mới" /><Kpi n={d.totals.in_progress} l="Đang làm" /><Kpi n={d.totals.paused} l="Đang hoãn" />
        <Kpi n={d.totals.overdue} l="Quá hạn" to="/work?tab=tasks&overdue=true" /><Kpi n={d.totals.completed} l="Hoàn thành" d={c.completed.delta} />
        <Kpi n={c.on_time_rate.cur !== null ? `${c.on_time_rate.cur}%` : null} l="Đúng hạn" d={c.on_time_rate.delta} />
        <Kpi n={c.accepted_qty.cur || null} l="Sản lượng đạt chuẩn" d={c.accepted_qty.delta} /><Kpi n={c.defect_rate.cur !== null ? `${c.defect_rate.cur}%` : null} l="Tỷ lệ lỗi" d={c.defect_rate.delta} good="down" />
        <Kpi n={c.efficiency.cur !== null ? `${c.efficiency.cur}%` : null} l="Hiệu suất công đoạn" d={c.efficiency.delta} />
      </div>
      <Card><Trend data={d.trend} /></Card>
    </>
  );
}

function Formulas({ f }: { f: any }) {
  return <details className="small muted" style={{ margin: '10px 0' }}><summary>Công thức chỉ số</summary><ul>{Object.values(f).map((x: any, i) => <li key={i}>{x}</li>)}</ul></details>;
}

function Risks({ d }: { d: any }) {
  return (
    <>
      {d.risks.tasks.map((t: any) => (
        <Card key={t.id} to={`/tasks/${t.id}`}><div className="row"><span className="ellipsis" style={{ flex: 1 }}>{t.code} · {t.title}</span><Badge tone={RISK[new Date(t.due_at) < new Date() ? 'overdue' : t.risk_level]?.[1] || 'red'}>{RISK[new Date(t.due_at) < new Date() ? 'overdue' : t.risk_level]?.[0]}</Badge></div>
          <div className="small muted">{t.group_name}{t.chain_code ? ` · ${t.chain_code}` : ''} · hạn {fmtDT(t.due_at)}</div></Card>
      ))}
      {d.risks.handovers.map((h: any) => (
        <Card key={h.id} to={`/tasks/${h.to_task_id || h.from_task_id}`}><div className="small"><b>{h.status === 'rejected' ? 'Bàn giao bị từ chối' : `Bàn giao chờ tiếp nhận ${Math.round(h.hours_waiting)} giờ`}</b>: {h.from_title} → {h.to_title || '—'}{h.rejection_reason ? ` · ${h.rejection_reason}` : ''}</div></Card>
      ))}
      {d.risks.workplace_reports.open > 0 && <Card to="/reports?scope=handling"><div className="small">Trở ngại đang mở: <b>{d.risks.workplace_reports.open}</b> · quá hạn xử lý: <b>{d.risks.workplace_reports.overdue}</b></div></Card>}
      {!d.risks.tasks.length && !d.risks.handovers.length && !d.risks.workplace_reports.open && <Empty>Không có rủi ro nổi bật</Empty>}
    </>
  );
}

function Workforce({ w }: { w: any }) {
  return (
    <Card>
      <KV k="Nhân sự trong phạm vi" v={w.total} /><KV k="Đang làm việc" v={w.working_now} /><KV k="Đang chờ / hoãn khách quan" v={w.waiting_now} />
      <KV k="Quá tải (>40 giờ việc mở hoặc ≥8 việc)" v={w.overloaded.map((x: any) => `${x.name} (${x.open_tasks})`).join(', ') || '—'} />
      <KV k="Chưa có việc" v={w.idle.map((x: any) => x.name).join(', ') || '—'} />
      <KV k="Tham gia nhiều nhóm" v={w.multi_group.map((x: any) => `${x.name} (${x.groups})`).join(', ') || '—'} />
    </Card>
  );
}

/** Ban quản trị: tổng quan công ty | hiệu suất nhóm | đơn hàng | nhân lực | chất lượng | rủi ro. */
export function BoardDash() {
  const [p, setP] = useState('week'); const [tab, setTab] = useState('overview');
  const { data: d, error } = useLoad(() => get(`/dash/board?period=${p}`), [p]);
  return (
    <>
      <Header title="Tổng quan công ty" back="/" />
      <div className="page">
        <Tabs value={p} onChange={setP} tabs={PERIODS} />
        <ErrorBox error={error} />{!d && !error && <Loading />}
        {d && <>
          <Tabs value={tab} onChange={setTab} tabs={[['overview', 'Tổng quan'], ['groups', 'Nhóm'], ['chains', `Đơn hàng (${d.chains.total})`], ['people', 'Nhân lực'], ['quality', 'Chất lượng'], ['risk', 'Rủi ro']]} />
          {tab === 'overview' && <Overview d={d} />}
          {tab === 'groups' && <GroupTable groups={d.groups} />}
          {tab === 'chains' && <>{d.chains.at_risk + d.chains.overdue > 0 && <div className="alert warn small">{d.chains.at_risk} đơn có nguy cơ trễ · {d.chains.overdue} đơn quá hạn</div>}{d.chains.items.map((c: any) => <ChainRow key={c.id} c={c} />)}{!d.chains.items.length && <Empty>Chưa có đơn hàng đang chạy</Empty>}</>}
          {tab === 'people' && <Workforce w={d.workforce} />}
          {tab === 'quality' && <>{d.quality_by_stage.map((x: any, i: number) => <Card key={i}><div className="row"><span style={{ flex: 1 }}>{x.title} · {x.group_name}</span><b>{Math.round((1000 * (Number(x.rejected) + Number(x.rework))) / Number(x.actual)) / 10}%</b></div><div className="small muted">Lỗi {Number(x.rejected)} · làm lại {Number(x.rework)} / {Number(x.actual)}</div></Card>)}{!d.quality_by_stage.length && <Empty>Chưa có lỗi được ghi nhận trong kỳ</Empty>}</>}
          {tab === 'risk' && <Risks d={d} />}
          <Formulas f={d.formulas} />
          <p className="small muted">Số liệu cá nhân chỉ truy xuất khi cần, theo quyền; không công khai xếp hạng.</p>
        </>}
      </div>
    </>
  );
}

/** Quản lý: tổng quan phạm vi | công việc | thành viên & hiệu suất | đơn hàng liên quan | trở ngại. */
export function ScopeDash() {
  const [p, setP] = useState('week'); const [tab, setTab] = useState('overview');
  const { data: d, error } = useLoad(() => get(`/dash/manager?period=${p}`), [p]);
  return (
    <>
      <Header title="Tổng quan phạm vi" back="/" />
      <div className="page">
        <Tabs value={p} onChange={setP} tabs={PERIODS} />
        <ErrorBox error={error} />{!d && !error && <Loading />}
        {d && <>
          {(d.pending.handovers + d.pending.rest + d.pending.feedback) > 0 && (
            <div className="chip-row">
              {d.pending.handovers > 0 && <Link to="/handovers"><Badge tone="amber">{d.pending.handovers} bàn giao chờ tiếp nhận</Badge></Link>}
              {d.pending.rest > 0 && <Link to="/team-live"><Badge tone="amber">{d.pending.rest} yêu cầu nghỉ</Badge></Link>}
              {d.pending.feedback > 0 && <Link to="/feedback"><Badge tone="amber">{d.pending.feedback} phản hồi dữ liệu</Badge></Link>}
            </div>
          )}
          <Tabs value={tab} onChange={setTab} tabs={[['overview', 'Tổng quan'], ['members', 'Thành viên'], ['groups', 'Nhóm'], ['chains', 'Đơn hàng'], ['risk', 'Trở ngại & rủi ro']]} />
          {tab === 'overview' && <Overview d={d} />}
          {tab === 'members' && (
            <div className="tbl-wrap"><table className="tbl">
              <thead><tr><th>Nhân viên</th><th className="num">Mở</th><th className="num">Quá hạn</th><th className="num">Xong</th><th className="num">Đúng hạn</th><th className="num">Thực hiện</th><th className="num">Chờ</th><th className="num">Hoãn KQ</th><th className="num">Tăng ca</th></tr></thead>
              <tbody>{d.members.map((m: any) => (
                <tr key={m.member_id}><td><Link to={`/my-time?memberId=${m.member_id}`}>{m.name}</Link></td><td className="num">{m.open}</td><td className="num" style={{ color: m.overdue ? 'var(--red)' : undefined }}>{m.overdue}</td>
                  <td className="num">{m.completed}</td><td className="num">{m.on_time_rate ?? '—'}%</td><td className="num">{mins(m.execution)}</td><td className="num">{mins(m.waiting)}</td><td className="num">{mins(m.objective_pause)}</td><td className="num">{mins(m.overtime)}</td></tr>
              ))}</tbody>
            </table><p className="small muted">Căn cứ: việc được giao, đúng hạn, thời gian theo phiên. Hoãn khách quan không tính là chậm. Không so sánh số lượng thô giữa các loại việc khác nhau.</p></div>
          )}
          {tab === 'groups' && <GroupTable groups={d.groups} />}
          {tab === 'chains' && <>{d.chains.items.map((c: any) => <ChainRow key={c.id} c={c} />)}{!d.chains.items.length && <Empty>Không có đơn hàng liên quan</Empty>}</>}
          {tab === 'risk' && <Risks d={d} />}
          <Formulas f={d.formulas} />
        </>}
      </div>
    </>
  );
}

/** Trưởng nhóm: công việc nhóm | thành viên đang làm | sản lượng & bàn giao | phiên, nghỉ, chờ. */
export function TeamLive() {
  const [sp, setSp] = useSearchParams();
  const gid = sp.get('groupId') || '';
  const { data: d, error, reload } = useLoad(() => get(`/dash/leader${gid ? `?groupId=${gid}` : ''}`), [gid]);
  const [tab, setTab] = useState('live');
  const [rej, setRej] = useState<any>(null);
  const a = useAction();
  const act = (fn: () => Promise<any>) => a.run(async () => { await fn(); reload(); });
  return (
    <>
      <Header title="Nhóm đang làm" back="/" />
      <div className="page">
        <ErrorBox error={error || a.error} />{!d && !error && <Loading />}
        {d && <>
          <div className="actions"><Link className="btn sm" to="/overtime/new">⏱ Ghi nhận giờ làm ngoài máy chấm công</Link></div>
          {d.groups.length > 1 && <div className="filters"><Select value={gid} onChange={(v) => setSp(v ? { groupId: v } : {}, { replace: true })} options={d.groups.map((g: any) => [g.id, g.name])} placeholder="Tất cả nhóm" /></div>}
          <div className="kpis">
            <Kpi n={d.totals.working} l="Đang làm" /><Kpi n={d.totals.paused} l="Hoãn / chờ" /><Kpi n={d.totals.resting} l="Đang nghỉ (quỹ)" />
            <Kpi n={d.totals.idle} l="Chưa có phiên" /><Kpi n={d.totals.accepted_today} l="Đạt chuẩn hôm nay" /><Kpi n={d.totals.defects_today} l="Lỗi/làm lại hôm nay" />
          </div>
          {d.rest_requests.map((r: any) => (
            <div key={r.id} className="alert warn small row" style={{ gap: 6 }}><span style={{ flex: 1 }}><b>{r.name}</b> xin dùng quỹ nghỉ{r.reason ? ` — ${r.reason}` : ''}</span>
              <button className="btn sm primary" disabled={a.busy} onClick={() => act(() => post(`/rest/${r.id}/decide`, { decision: 'approve' }))}>Cho nghỉ</button>
              <button className="btn sm" disabled={a.busy} onClick={() => act(() => post(`/rest/${r.id}/decide`, { decision: 'reject', note: 'Cần quay lại làm việc' }))}>Không</button></div>
          ))}
          <Tabs value={tab} onChange={setTab} tabs={[['live', 'Thành viên'], ['tasks', `Công việc (${d.tasks.length})`], ['prod', 'Sản lượng'], ['handover', `Bàn giao (${d.handovers_incoming.length})`], ['time', 'Nghỉ/chờ']]} />
          {tab === 'live' && d.live.map((m: any) => (
            <Card key={m.member_id}>
              <div className="row"><b style={{ flex: 1 }}>{m.name}</b>{m.session_id ? <Badge tone="blue">Đang làm · {mins((Date.now() - new Date(m.session_started_at).getTime()) / 60000)}</Badge> : m.record_category ? <Badge tone={TIME_CAT[m.record_category][1]}>{TIME_CAT[m.record_category][0]}</Badge> : <Badge>Chưa có phiên</Badge>}</div>
              <div className="small muted">{m.session_task ? <><Link to={`/tasks/${m.session_task_id}`}>{m.session_task}</Link> · </> : m.record_task ? `${m.record_task} · ` : ''}{[m.location_name && `📍 ${m.location_name}`, m.record_reason, `${m.open_tasks} việc mở`, m.group_name].filter(Boolean).join(' · ')}</div>
            </Card>
          ))}
          {tab === 'tasks' && d.tasks.map((t: any) => (
            <Card key={t.id} to={`/tasks/${t.id}`}><div className="row"><span className="ellipsis" style={{ flex: 1 }}>{t.code} · {t.title}</span>{t.open_pause && <Badge tone={TIME_CAT[t.open_pause][1]}>{TIME_CAT[t.open_pause][0]}</Badge>}{t.risk_level !== 'normal' && RISK[t.risk_level] && <Badge tone={RISK[t.risk_level][1]}>{RISK[t.risk_level][0]}</Badge>}</div>
              <div className="small muted">{t.owner_name} · hạn {fmtDT(t.due_at)}{t.pause_reason ? ` · ${t.pause_reason}` : ''}</div></Card>
          ))}
          {tab === 'prod' && <>
            {d.production.map((r: any) => <Card key={r.id} to={`/tasks/${r.task_id}`}><div className="row"><span style={{ flex: 1 }}>{r.task_title}</span><b>{Number(r.accepted_qty)}/{Number(r.actual_qty)} {r.unit}</b></div>
              <div className="small muted">Lỗi {Number(r.rejected_qty)} · làm lại {Number(r.rework_qty)}{r.efficiency !== null ? ` · hiệu suất ${r.efficiency}%` : ''} · {fmtDT(r.created_at)}</div></Card>)}
            {!d.production.length && <Empty>Chưa ghi nhận sản lượng hôm nay — mở nhiệm vụ và chọn "Ghi nhận sản lượng"</Empty>}
            {d.adjustments.length > 0 && <><div className="section-title">Lịch sử điều chỉnh</div>{d.adjustments.map((x: any) => <div key={x.id} className="small">v{x.version} · {x.task_title} · {x.recorded_by_name} · {fmtDT(x.created_at)} — {x.change_reason}</div>)}</>}
          </>}
          {tab === 'handover' && <>
            {d.handovers_incoming.map((h: any) => <HandoverCard key={h.id} h={h} onReject={() => setRej(h)} onAccept={() => act(() => post(`/handovers/${h.id}/decide`, { decision: 'accept' }))} busy={a.busy} />)}
            {d.handovers_rejected_outgoing.map((h: any) => <Card key={h.id} to={`/tasks/${h.from_task_id}`}><div className="small" style={{ color: 'var(--red)' }}>Bàn giao của nhóm bị trả lại: {h.from_title} → {h.to_group} · {h.rejection_reason}</div></Card>)}
            {!d.handovers_incoming.length && !d.handovers_rejected_outgoing.length && <Empty>Không có bàn giao chờ xử lý</Empty>}
          </>}
          {tab === 'time' && d.pauses.map((x: any) => (
            <Card key={x.id}><div className="row"><Badge tone={TIME_CAT[x.category][1]}>{TIME_CAT[x.category][0]}</Badge><span className="small" style={{ flex: 1 }}> {x.name} · {x.task_title || ''}</span>
              {!x.confirmed_by && x.category === 'objective_pause' && <button className="btn sm" disabled={a.busy} onClick={() => act(() => post(`/time-records/${x.id}/confirm`, { objective: true }))}>Xác nhận KQ</button>}</div>
              <div className="small muted">{x.reason} · từ {fmtDT(x.started_at)}</div></Card>
          ))}
        </>}
      </div>
      <Sheet open={!!rej} onClose={() => setRej(null)} title="Bàn giao chưa đạt"><RejectForm busy={a.busy} onSubmit={(r) => act(async () => { await post(`/handovers/${rej.id}/decide`, { decision: 'reject', reason: r }); setRej(null); })} /></Sheet>
    </>
  );
}

function HandoverCard({ h, onAccept, onReject, busy }: { h: any; onAccept: () => void; onReject: () => void; busy: boolean }) {
  return (
    <Card>
      <div className="row"><b style={{ flex: 1 }}>{h.from_group} → {h.to_group}{h.chain_code ? ` · ${h.chain_code}` : ''}</b><Badge tone={h.status === 'rejected' ? 'red' : 'amber'}>{h.status === 'rejected' ? 'Chờ bổ sung' : 'Chờ tiếp nhận'}</Badge></div>
      <div className="small"><Link to={`/tasks/${h.to_task_id || h.from_task_id}`}>{h.to_title || h.from_title}</Link></div>
      <div className="small crit">{h.content}</div>
      {h.status === 'submitted' && <div className="actions"><button className="btn sm primary" disabled={busy} onClick={onAccept}>✔ Tiếp nhận</button><button className="btn sm danger" onClick={onReject}>Chưa đạt</button></div>}
    </Card>
  );
}
function RejectForm({ busy, onSubmit }: { busy: boolean; onSubmit: (r: string) => void }) {
  const [r, setR] = useState('');
  return <><Field label="Cần bổ sung gì" required><textarea value={r} onChange={(e) => setR(e.target.value)} /></Field><button className="btn primary block" disabled={busy || r.trim().length < 5} onClick={() => onSubmit(r)}>Gửi</button></>;
}

/** Nhân viên: thời gian & nghỉ | kết quả của tôi | lịch sử | phản hồi dữ liệu. Quản lý có thể xem của nhân viên trong phạm vi (memberId). */
export function MyTime() {
  const [sp] = useSearchParams();
  const memberId = sp.get('memberId');
  const [p, setP] = useState('week'); const [tab, setTab] = useState('time');
  const { data: d, error, reload } = useLoad(() => (memberId ? Promise.resolve(null) : get(`/dash/me?period=${p}`)), [p, memberId]);
  const other = useLoad(() => (memberId ? get(`/time/summary?memberId=${memberId}&from=${new Date(Date.now() - (p === 'day' ? 1 : p === 'week' ? 7 : 30) * 86400000).toISOString()}`) : Promise.resolve(null)), [memberId, p]);
  const ledger = useLoad(() => get(`/rest/ledger${memberId ? `?memberId=${memberId}` : ''}`), [memberId]);
  const [fb, setFb] = useState<any>(null);
  const a = useAction();
  const time = memberId ? other.data?.members?.[0] : d?.time;
  const total = time ? Object.entries(time).filter(([k]) => TIME_CAT[k] && k !== 'overtime').reduce((s, [, v]) => s + Number(v), 0) : 0;
  return (
    <>
      <Header title={memberId ? `Thời gian · ${other.data?.members?.[0]?.name || ''}` : 'Thời gian & kết quả của tôi'} back />
      <div className="page">
        {!memberId && <SessionCard onChange={reload} />}
        <Tabs value={p} onChange={setP} tabs={PERIODS} />
        <ErrorBox error={error || other.error} />
        {!memberId && <Tabs value={tab} onChange={setTab} tabs={[['time', 'Thời gian & nghỉ'], ['results', 'Kết quả'], ['history', 'Lịch sử'], ['feedback', 'Phản hồi']]} />}
        {(tab === 'time' || memberId) && time && (
          <>
            <div className="timebar">{Object.entries(time).filter(([k, v]) => TIME_CAT[k] && k !== 'overtime' && Number(v) > 0).map(([k, v]) => (
              <i key={k} title={TIME_CAT[k][0]} style={{ width: `${(100 * Number(v)) / Math.max(1, total)}%`, background: `var(--${TIME_CAT[k][1] === 'gray' ? 'gray' : TIME_CAT[k][1]})` }} />))}</div>
            <Card>{Object.entries(TIME_CAT).map(([k, [l]]) => <KV key={k} k={l} v={mins(Number(time[k] || 0))} />)}</Card>
            <p className="small muted">Thời gian thực hiện, chờ, hoãn khách quan, nghỉ bổ sung và tăng ca được tách riêng. Nghỉ giữa giờ theo luật được quản lý riêng, không trừ vào quỹ nghỉ bổ sung.</p>
            {ledger.data?.policy?.enabled && (
              <>
                <div className="section-title">Quỹ nghỉ bổ sung · còn {ledger.data.balance} phút</div>
                <p className="small muted">{ledger.data.note} Tích lũy: {ledger.data.policy.dayAccrual} phút (ca ngày) / {ledger.data.policy.nightAccrual} phút (ca đêm) cho mỗi {ledger.data.policy.continuousMinutes / 60} giờ làm việc liên tục; trần {ledger.data.policy.capMinutes} phút. Chỉ dùng khi việc bị hoãn khách quan/không có việc phù hợp và được trưởng nhóm cho phép.</p>
                {ledger.data.items.map((x: any) => <div key={x.id} className="small row"><span style={{ flex: 1 }}>{fmtDT(x.created_at)} · {x.kind === 'accrual' ? 'Tích lũy' : x.kind === 'use' ? 'Sử dụng' : x.kind === 'adjust' ? 'Điều chỉnh' : 'Hết hạn'}{x.status !== 'posted' ? ` (${x.status === 'pending' ? 'chờ duyệt' : x.status === 'approved' ? 'đang nghỉ' : 'từ chối'})` : ''}{x.reason ? ` — ${x.reason}` : ''}</span><b>{x.minutes > 0 ? '+' : ''}{x.minutes}p</b></div>)}
              </>
            )}
          </>
        )}
        {!memberId && d && tab === 'results' && (
          <>
            <div className="kpis">
              <Kpi n={d.results.completed} l="Hoàn thành tháng này" /><Kpi n={d.results.on_time_rate !== null ? `${d.results.on_time_rate}%` : null} l="Đúng hạn" /><Kpi n={d.results.avg_score} l="Điểm nghiệm thu TB" />
              <Kpi n={d.results.efficiency !== null ? `${d.results.efficiency}%` : null} l="Hiệu suất công đoạn" /><Kpi n={d.results.quality_rate !== null ? `${d.results.quality_rate}%` : null} l="Tỷ lệ đạt chuẩn" /><Kpi n={d.results.utilization !== null ? `${d.results.utilization}%` : null} l="Sử dụng quỹ thời gian" />
            </div>
            <p className="small muted">{d.note}</p>
            <div className="section-title">Sản lượng có tôi tham gia</div>
            {d.production.map((r: any) => <Card key={r.id}><div className="row"><span style={{ flex: 1 }}><Link to={`/tasks/${r.task_id}`}>{r.title}</Link></span><b>{Number(r.accepted_qty)}/{Number(r.actual_qty)} {r.unit}</b></div>
              <div className="row small muted"><span style={{ flex: 1 }}>{fmtDT(r.created_at)}{r.version > 1 ? ` · đã điều chỉnh v${r.version}` : ''}</span><button className="btn sm" onClick={() => setFb({ targetType: 'production', targetId: r.id, label: r.title })}>Phản hồi</button></div></Card>)}
            <div className="section-title">Đánh giá gần đây</div>
            {d.evaluations.map((e: any) => <Card key={e.id}><div className="row"><span style={{ flex: 1 }}><Link to={`/tasks/${e.task_id}`}>{e.title}</Link></span><b>{e.decision === 'approved' ? e.total_score : 'Yêu cầu sửa'}</b></div>
              <div className="row small muted"><span style={{ flex: 1 }}>{fmtDT(e.created_at)}</span><button className="btn sm" onClick={() => setFb({ targetType: 'evaluation', targetId: e.id, label: e.title })}>Phản hồi</button></div></Card>)}
            <Formulas f={d.formulas} />
          </>
        )}
        {!memberId && d && tab === 'history' && (
          <>
            {d.sessions.map((s: any) => <Card key={s.id}><div className="row"><span style={{ flex: 1 }}><Link to={`/tasks/${s.task_id}`}>{s.title}</Link></span><span className="small">{mins(((s.ended_at ? new Date(s.ended_at).getTime() : Date.now()) - new Date(s.started_at).getTime()) / 60000)}</span></div>
              <div className="row small muted"><span style={{ flex: 1 }}>{fmtDT(s.started_at)}{s.ended_at ? ` → ${fmtDT(s.ended_at)}` : ' · đang chạy'}{s.location_name ? ` · ${s.location_name}` : ''}{s.end_reason === 'auto' ? ' · tự đóng' : ''}</span>
                <button className="btn sm" onClick={() => setFb({ targetType: 'session', targetId: s.id, label: s.title })}>Phản hồi</button></div></Card>)}
            {d.time_records.map((r: any) => <div key={r.id} className="small row"><Badge tone={TIME_CAT[r.category][1]}>{TIME_CAT[r.category][0]}</Badge><span style={{ flex: 1 }}> {r.title || ''} · {fmtDT(r.started_at)}{r.reason ? ` · ${r.reason}` : ''}{r.confirmed ? ' · đã xác nhận' : ''}</span>
              <button className="btn sm" onClick={() => setFb({ targetType: 'time_record', targetId: r.id, label: TIME_CAT[r.category][0] })}>Phản hồi</button></div>)}
          </>
        )}
        {!memberId && d && tab === 'feedback' && (
          <>
            <p className="small muted">Nếu dữ liệu công việc, thời gian, sản lượng hoặc kết quả ghi nhận chưa chính xác, gửi phản hồi từ các thẻ ở tab Kết quả/Lịch sử. Trưởng nhóm/quản lý xử lý và điều chỉnh có lưu vết.</p>
            {d.feedback.map((f: any) => <Card key={f.id}><div className="row"><span style={{ flex: 1 }} className="small">{f.content}</span><Badge tone={f.status === 'open' ? 'amber' : f.status === 'resolved' ? 'green' : 'gray'}>{f.status === 'open' ? 'Đang xử lý' : f.status === 'resolved' ? 'Đã xử lý' : 'Không chấp nhận'}</Badge></div>
              {f.resolution && <div className="small muted">{f.resolution}</div>}</Card>)}
            {!d.feedback.length && <Empty>Chưa có phản hồi</Empty>}
          </>
        )}
      </div>
      <Sheet open={!!fb} onClose={() => setFb(null)} title={`Phản hồi dữ liệu · ${fb?.label || ''}`}>
        {fb && <FeedbackForm busy={a.busy} error={a.error} onSubmit={(content) => a.run(async () => { await post('/feedback', { targetType: fb.targetType, targetId: fb.targetId, content }); setFb(null); reload(); setTab('feedback'); })} />}
      </Sheet>
    </>
  );
}
function FeedbackForm({ busy, error, onSubmit }: { busy: boolean; error: string | null; onSubmit: (c: string) => void }) {
  const [c, setC] = useState('');
  return <><Field label="Dữ liệu nào chưa đúng, giá trị đúng theo bạn là gì?" required><textarea value={c} onChange={(e) => setC(e.target.value)} /></Field><ErrorBox error={error} /><button className="btn primary block" disabled={busy || c.trim().length < 10} onClick={() => onSubmit(c)}>Gửi phản hồi</button></>;
}

/** Trưởng nhóm/quản lý xử lý phản hồi dữ liệu. */
export function FeedbackInbox() {
  const { data, reload } = useLoad(() => get('/feedback?scope=handling'), []);
  const [cur, setCur] = useState<any>(null); const [r, setR] = useState(''); const [st, setSt] = useState('resolved');
  const a = useAction();
  return (
    <>
      <Header title="Phản hồi dữ liệu" back />
      <div className="page">
        <p className="small muted">Điều chỉnh dữ liệu đã xác nhận phải tạo bản ghi điều chỉnh có lý do (không sửa âm thầm).</p>
        {data?.map((f: any) => <Card key={f.id} onClick={f.status === 'open' ? () => setCur(f) : undefined}><div className="row"><b style={{ flex: 1 }}>{f.member_name}</b><Badge tone={f.status === 'open' ? 'amber' : 'gray'}>{f.status === 'open' ? 'Chờ xử lý' : 'Đã đóng'}</Badge></div>
          <div className="small">{f.content}</div><div className="small muted">{f.target_type} · {fmtDT(f.created_at)}{f.resolution ? ` · ${f.resolution}` : ''}</div></Card>)}
        {data && !data.length && <Empty>Không có phản hồi</Empty>}
      </div>
      <Sheet open={!!cur} onClose={() => setCur(null)} title="Xử lý phản hồi">
        <p className="small">{cur?.content}</p>
        <Field label="Kết quả"><Select value={st} onChange={setSt} options={{ resolved: 'Đã đối chiếu / điều chỉnh', rejected: 'Dữ liệu đúng — không điều chỉnh' }} /></Field>
        <Field label="Giải thích" required><textarea value={r} onChange={(e) => setR(e.target.value)} /></Field>
        <ErrorBox error={a.error} />
        <button className="btn primary block" disabled={a.busy || r.trim().length < 5} onClick={() => a.run(async () => { await post(`/feedback/${cur.id}/resolve`, { status: st, resolution: r }); setCur(null); setR(''); reload(); })}>Lưu</button>
      </Sheet>
    </>
  );
}
