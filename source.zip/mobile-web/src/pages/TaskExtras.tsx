import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { get, patch, post } from '../api';
import { useAuth } from '../auth';
import { Badge, Card, ErrorBox, Field, Select, useAction, useLoad, Note } from '../ui';
import { Icon } from '../icons';
import { fmtDT, mins } from '../labels';

const KIND: Record<string, [string, string]> = { event: ['•', 'gray'], session: ['▶', 'blue'], blocker: ['⛔', 'red'], support: ['🤝', 'teal'], report_case: ['⚑', 'amber'] };

/** Dòng thời gian chi tiết: công đoạn, sự kiện, đoạn bị vướng (bao lâu, giải quyết thế nào), phản ánh ảnh hưởng tiến độ/chất lượng. */
export function TaskTimeline({ taskId }: { taskId: string }) {
  const [open, setOpen] = useState(false);
  const [onlyBlock, setOnlyBlock] = useState(false);
  const { data: d, error } = useLoad(() => (open ? get(`/tasks/${taskId}/timeline`) : Promise.resolve(null)), [open, taskId]);
  return (
    <Card>
      <div className="row" style={{ cursor: 'pointer' }} onClick={() => setOpen(!open)}>
        <Icon name="flow" size={18} /><b style={{ flex: 1 }}> Dòng thời gian & điểm vướng</b><Icon name={open ? 'down' : 'chevron'} size={18} />
      </div>
      {open && <>
        <ErrorBox error={error} />
        {d && <>
          <div className="cnt-row" style={{ marginTop: 6 }}>
            <span>Đã diễn ra <b>{mins(d.summary.elapsed_minutes)}</b></span>
            <span>Bị vướng <b style={{ color: d.summary.blocked_minutes ? 'var(--red)' : undefined }}>{mins(d.summary.blocked_minutes)}</b> ({d.summary.blocker_count} lần)</span>
            {d.summary.open_blockers > 0 && <span style={{ color: 'var(--red)' }}>Đang vướng <b>{d.summary.open_blockers}</b></span>}
          </div>
          {d.summary.longest.length > 0 && (
            <div className="alert warn small" style={{ marginTop: 6 }}>
              <b>Vướng lâu nhất:</b>
              {d.summary.longest.map((l: any, i: number) => <div key={i}>{l.task ? `[${l.task}] ` : ''}{l.title}: {mins(l.minutes)} — {l.resolution}</div>)}
            </div>
          )}
          {d.stages.length > 0 && <>
            <div className="section-title">Công đoạn</div>
            {d.stages.map((s: any) => (
              <div key={s.id} className="small" style={{ display: 'flex', gap: 6, margin: '3px 0' }}>
                <span style={{ width: 34 }}>GĐ{s.stage_no ?? '-'}</span>
                <span style={{ flex: 1 }}><Link to={`/tasks/${s.id}`}>{s.code} {s.title}</Link> <span className="muted">· {s.group_name}</span></span>
                <span>{s.started_at ? mins(s.minutes) : 'chưa bắt đầu'}{s.blocked_minutes ? <span style={{ color: 'var(--red)' }}> · vướng {mins(s.blocked_minutes)}</span> : ''}</span>
              </div>
            ))}
          </>}
          <div className="row" style={{ display: 'flex', alignItems: 'center', marginTop: 8 }}>
            <div className="section-title" style={{ flex: 1, margin: 0 }}>Chuỗi sự kiện ({d.events.length})</div>
            <label className="check" style={{ margin: 0 }}><input type="checkbox" checked={onlyBlock} onChange={(e) => setOnlyBlock(e.target.checked)} /> Chỉ điểm vướng</label>
          </div>
          <div className="tl">
            {d.events.filter((e: any) => !onlyBlock || e.kind === 'blocker' || e.kind === 'report_case').map((e: any, i: number) => (
              <div key={i} className={`tl-row ${e.kind}`}>
                <span className="tl-dot">{KIND[e.kind]?.[0]}</span>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div><b>{e.title}</b>{e.task ? <span className="small muted"> · {e.task}</span> : ''}{e.open && <Badge tone="red">đang diễn ra</Badge>}</div>
                  <div className="small muted">{fmtDT(e.at)}{e.until ? ` → ${fmtDT(e.until)}` : ''}{typeof e.minutes === 'number' ? ` · ${mins(e.minutes)}` : ''}{e.who ? ` · ${e.who}` : ''}</div>
                  {e.cause && <div className="small">Nguyên nhân: {e.cause}</div>}
                  {e.resolution && <div className="small">Giải quyết: {e.resolution}</div>}
                  {e.detail && <div className="small">{e.detail}</div>}
                  {e.impact && <div className="small" style={{ color: 'var(--amber)' }}>Ảnh hưởng: {e.impact}</div>}
                </div>
              </div>
            ))}
          </div>
        </>}
      </>}
    </Card>
  );
}

/** Bình luận: 3 tin mới nhất, "Xem thêm" để đọc toàn bộ; trích dẫn để trả lời. */
export function TaskComments({ t, onChange }: { t: any; onChange: (x: any) => void }) {
  const { me } = useAuth();
  const [c, setC] = useState(''); const [reply, setReply] = useState<any>(null); const [all, setAll] = useState<any[] | null>(null);
  const a = useAction();
  useEffect(() => { get(`/tasks/${t.id}/comments?limit=3`).catch(() => {}); }, [t.id]);   // đánh dấu đã đọc
  const list = all || t.comments.slice(-3);
  const send = () => a.run(async () => {
    const d = await post(`/tasks/${t.id}/comments`, { content: c, replyToId: reply?.id });
    onChange(d); setC(''); setReply(null); if (all) setAll((await get(`/tasks/${t.id}/comments`)).items);
  });
  return (
    <>
      <div className="section-title">Bình luận ({t.comments.length})</div>
      <Note>Thảo luận giúp mọi người hiểu nhiệm vụ hơn — bình luận mới sẽ đẩy nhiệm vụ lên đầu danh sách.</Note>
      {!all && t.comments.length > 3 && <button className="btn sm block" onClick={async () => setAll((await get(`/tasks/${t.id}/comments`)).items)}>Xem thêm {t.comments.length - 3} bình luận trước</button>}
      {list.map((x: any) => (
        <Card key={x.id}>
          <div className="row small muted"><span style={{ flex: 1 }}>{x.name} · {fmtDT(x.created_at)}</span>
            <button className="btn sm" style={{ padding: '2px 8px' }} onClick={() => setReply(x)}>↩ Trả lời</button>
            {x.member_id !== me?.member_id && <Link className="small muted" to={`/conduct/new?objectType=comment&objectId=${x.id}&objectLabel=${encodeURIComponent(`Bình luận của ${x.name} trong ${t.code} lúc ${fmtDT(x.created_at)}`)}&reported=${x.member_id}`} style={{ marginLeft: 8 }}>Báo cáo</Link>}
          </div>
          {x.reply_to_id && <div className="quote small">“{(x.reply_content || '').slice(0, 160)}” — {x.reply_name}</div>}
          <div className="crit">{x.content}</div>
        </Card>
      ))}
      {reply && <div className="quote small" style={{ display: 'flex', gap: 6 }}><span style={{ flex: 1 }}>Trả lời {reply.name}: “{reply.content.slice(0, 120)}”</span><button className="icon-btn" onClick={() => setReply(null)} aria-label="Bỏ trích dẫn"><Icon name="close" size={20} /></button></div>}
      <div style={{ display: 'flex', gap: 6 }}>
        <input placeholder={reply ? `Trả lời ${reply.name}…` : 'Viết bình luận…'} value={c} onChange={(e) => setC(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter' && c.trim()) send(); }} />
        <button className="btn" disabled={a.busy || !c.trim()} onClick={send}>Gửi</button>
      </div>
      <ErrorBox error={a.error} />
    </>
  );
}

/** Khai báo thiết bị: vị trí ban đầu (người nhận nhiệm vụ khai/sửa), mang ra – vào cần giấy phép, kiểm kê cuối ngày / khi hoàn thành. */
export function TaskEquipment({ taskId }: { taskId: string }) {
  const { data: d, setData, error } = useLoad(() => get(`/tasks/${taskId}/equipment`), [taskId]);
  const a = useAction();
  const [nw, setNw] = useState<any>(null);
  const [check, setCheck] = useState<{ kind: string; loc: Record<string, string> } | null>(null);
  const [edit, setEdit] = useState<Record<string, string>>({});
  if (!d) return error ? null : null;
  if (!d.items.length && !d.can_edit) return null;
  const doCheck = (kind: string) => setCheck({ kind, loc: Object.fromEntries(d.items.map((e: any) => [e.id, e.current_location || e.origin_location || ''])) });
  return (
    <Card>
      <div className="row"><Icon name="wrench" size={18} /><b style={{ flex: 1 }}> Thiết bị sử dụng ({d.items.length})</b>
        {d.items.length > 0 && (d.checked_today ? <Badge tone="green">Đã kiểm kê hôm nay</Badge> : <Badge tone="amber">Chưa kiểm kê hôm nay</Badge>)}</div>
      <Note>Thiết bị dùng trong phòng ban/vị trí thực hiện không cần giấy phép; mang ra – vào khu vực phải có giấy phép. Không kiểm kê khi đổi phiên/khu vực (mặc định không mang theo thiết bị) — chỉ kiểm kê cuối ngày hoặc khi hoàn thành nhiệm vụ.</Note>
      {d.items.map((e: any) => (
        <div key={e.id} className="eq-row">
          <div style={{ flex: 1, minWidth: 0 }}>
            <b>{e.name}</b>{e.code ? ` · ${e.code}` : ''}{e.quantity > 1 ? ` × ${e.quantity}` : ''}{e.moved_out && <Badge tone="purple">Mang ra · {e.permit_code || 'giấy phép'}</Badge>}
            <div className="small">Vị trí ban đầu: {e.origin_location || <span style={{ color: 'var(--amber)' }}>chưa khai</span>} · Hiện tại: {e.current_location || <span style={{ color: 'var(--red)' }}>chưa khai</span>}</div>
            {e.checks?.[0] && <div className="small muted">Kiểm kê gần nhất: {e.checks[0].location} · {fmtDT(e.checks[0].at)} · {e.checks[0].by}</div>}
          </div>
          {d.can_edit && !e.origin_location && (
            <div style={{ display: 'flex', gap: 4 }}>
              <input style={{ width: 130 }} placeholder="Vị trí ban đầu" value={edit[e.id] || ''} onChange={(x) => setEdit({ ...edit, [e.id]: x.target.value })} />
              <button className="btn sm" disabled={!edit[e.id]} onClick={() => a.run(async () => setData(await patch(`/tasks/${taskId}/equipment/${e.id}`, { originLocation: edit[e.id] })))}>Lưu</button>
            </div>
          )}
        </div>
      ))}
      {d.can_edit && !nw && !check && (
        <div className="actions">
          <button className="btn sm" onClick={() => setNw({ name: '', code: '', quantity: 1, originLocation: '', movedOut: false, permitId: '' })}><Icon name="plus" size={14} />Khai báo thiết bị</button>
          {d.items.length > 0 && <button className="btn sm" onClick={() => doCheck('daily')}>Kiểm kê cuối ngày</button>}
          {d.items.length > 0 && <button className="btn sm primary" onClick={() => doCheck('completion')}>Kiểm kê khi hoàn thành</button>}
        </div>
      )}
      {nw && (
        <div className="card" style={{ marginTop: 6 }}>
          <div className="grid2">
            <Field label="Tên thiết bị" required><input value={nw.name} onChange={(e) => setNw({ ...nw, name: e.target.value })} /></Field>
            <Field label="Mã / số hiệu"><input value={nw.code} onChange={(e) => setNw({ ...nw, code: e.target.value })} /></Field>
          </div>
          <div className="grid2">
            <Field label="Số lượng"><input type="number" min={1} value={nw.quantity} onChange={(e) => setNw({ ...nw, quantity: Number(e.target.value) || 1 })} /></Field>
            <Field label="Vị trí ban đầu" hint="Có thể bổ sung sau"><input value={nw.originLocation} onChange={(e) => setNw({ ...nw, originLocation: e.target.value })} placeholder="VD: Tủ dụng cụ xưởng 1" /></Field>
          </div>
          <label className="check"><input type="checkbox" checked={nw.movedOut} onChange={(e) => setNw({ ...nw, movedOut: e.target.checked })} /> Mang ra – vào khỏi phòng ban / vị trí thực hiện (cần giấy phép)</label>
          {nw.movedOut && <Field label="Giấy phép của nhiệm vụ" required><Select value={nw.permitId} onChange={(v) => setNw({ ...nw, permitId: v })} options={d.permits.map((p: any) => [p.id, `${p.code} · ${p.type_name}`])} placeholder={d.permits.length ? '— Chọn giấy phép —' : 'Nhiệm vụ chưa có giấy phép được cấp'} /></Field>}
          <div className="actions"><button className="btn" onClick={() => setNw(null)}>Hủy</button>
            <button className="btn primary" disabled={a.busy || nw.name.trim().length < 2} onClick={() => a.run(async () => { setData(await post(`/tasks/${taskId}/equipment`, { ...nw, code: nw.code || undefined, originLocation: nw.originLocation || undefined, permitId: nw.permitId || undefined })); setNw(null); })}>Lưu thiết bị</button></div>
        </div>
      )}
      {check && (
        <div className="card" style={{ marginTop: 6 }}>
          <b className="small">{check.kind === 'daily' ? 'Kiểm kê cuối ngày' : 'Kiểm kê khi hoàn thành — bắt buộc trước khi bàn giao'}</b>
          {d.items.map((e: any) => <Field key={e.id} label={`Vị trí hiện tại: ${e.name}`} required><input value={check.loc[e.id] || ''} onChange={(x) => setCheck({ ...check, loc: { ...check.loc, [e.id]: x.target.value } })} /></Field>)}
          <div className="actions"><button className="btn" onClick={() => setCheck(null)}>Hủy</button>
            <button className="btn primary" disabled={a.busy || d.items.some((e: any) => (check.loc[e.id] || '').trim().length < 2)} onClick={() => a.run(async () => { setData(await post(`/tasks/${taskId}/equipment/check`, { kind: check.kind, items: d.items.map((e: any) => ({ id: e.id, location: check.loc[e.id] })) })); setCheck(null); })}>Xác nhận kiểm kê</button></div>
        </div>
      )}
      <ErrorBox error={a.error} />
    </Card>
  );
}
