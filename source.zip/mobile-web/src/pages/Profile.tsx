import { useState } from 'react';
import { Link } from 'react-router-dom';
import { post } from '../api';
import { can, isAdminRole, isHRRole, tierOf, useAuth } from '../auth';
import { Avatar, Card, ErrorBox, Field, KV, Sheet, useAction } from '../ui';
import { Icon, IconChip } from '../icons';
import { ROLE } from '../labels';

export default function Profile() {
  const { me, logout, switchCompany } = useAuth();
  const [pw, setPw] = useState(false);
  if (!me) return null;
  type It = [string, string, string, string, string?];
  const M = ({ items }: { items: It[] }) => (
    <div className="menu">{items.map(([to, ic, tone, t, sub]) => <Link key={to} to={to}><IconChip name={ic} tone={tone} size={19} /><span className="grow"><b>{t}</b>{sub && <div className="sub">{sub}</div>}</span><Icon name="chevron" className="chev" /></Link>)}</div>
  );
  // v10: trang Cá nhân chỉ giữ các mục mang tính THIẾT LẬP; danh sách/công năng nằm ở Công việc, Nhân sự, Trang chủ.
  const tier = tierOf(me); const board = isAdminRole(me.role);
  const personal: It[] = [['/profile', 'record', 'blue', 'Hồ sơ cá nhân & ảnh đại diện', 'Hồ sơ xin việc, kinh nghiệm, lịch sử làm việc'], ['/privacy', 'key', 'teal', 'Quyền riêng tư và dữ liệu cá nhân', 'Ai xem được gì, đồng ý, tải dữ liệu, lịch sử truy cập']];
  if (me.company_id) personal.push(['/settings/sound', 'bell', 'blue', 'Âm thanh & thông báo', 'Chuông, rung, giờ yên lặng, tắt tiếng theo loại']);
  const ops: It[] = me.company_id ? [
    ...(board ? [['/board', 'perf', 'blue', 'Tổng quan công ty', 'Hiệu suất nhóm, đơn hàng, nhân lực, chất lượng, rủi ro'] as It] : []),
    ...(board || tier <= 5 ? [['/admin/areas', 'qr', 'gray', 'Khu vực & mã QR', 'Cơ sở, khu vực, trạm; phát hành/in/thu hồi QR'] as It] : []),
  ] : [];
  const handoverSetup: It[] = me.company_id && board ? [
    ['/admin/settings?tab=handover', 'route', 'teal', 'Thiết lập bàn giao liên phòng ban', 'Bắt buộc tiếp nhận trước khi bắt đầu, thời hạn tiếp nhận'],
    ['/admin/settings?tab=handover', 'decision', 'amber', 'Thiết lập bàn giao chờ duyệt (QR bên ngoài)', 'Hạn QR, cho phép từ chối, SLA duyệt giải trình, bằng chứng bắt buộc'],
  ] : [];
  const work: It[] = [];
  const admin: It[] = [];
  if (isHRRole(me.role) || tier <= 5) admin.push(['/admin/members', 'userCog', 'red', 'Thành viên, phòng ban & chức vụ', tier === 5 && !isHRRole(me.role) ? 'Thêm nhân viên vào phòng ban của bạn, chỉ định trưởng nhóm' : 'Thêm nhân viên, phân loại theo tầng/phòng ban, kiểm duyệt']);
  if (can(me, 'manage_templates_all') || can(me, 'manage_templates_dept')) admin.push(['/templates', 'clipboard-check', 'blue', 'Mẫu công việc của phòng ban', 'Tạo và sửa mẫu dùng khi giao việc']);
  if (isAdminRole(me.role) || me.is_platform_admin) admin.push(['/admin/security', 'shield', 'red', 'An toàn dữ liệu', 'Cảnh báo bất thường, quyền hỗ trợ kỹ thuật']);
  if (isAdminRole(me.role)) admin.push(['/admin/settings', 'settings', 'gray', 'Cấu hình công ty', 'Lịch làm việc, SLA, trọng số, giấy phép, danh mục']);
  if (me.role === 'owner' || !me.company_id) admin.push(['/upgrade', 'company', 'blue', me.role === 'owner' ? 'Gói doanh nghiệp' : 'Nâng cấp tài khoản doanh nghiệp']);
  if (me.is_platform_admin) admin.push(['/platform', 'settings', 'purple', 'Quản trị nền tảng']);
  return (
    <div className="page">
      <div className="hero" style={{ display: 'flex', gap: 14, alignItems: 'center' }}>
        <Avatar userId={me.user_id} name={me.name} has={!!me.has_avatar} size="lg" />
        <div style={{ minWidth: 0, position: 'relative', zIndex: 1 }}>
          <h1>{me.name}</h1>
          <div className="muted small">{me.phone}{me.email ? ` · ${me.email}` : ''}</div>
          <div className="muted small">{ROLE[me.role] || 'Tài khoản cá nhân'}{me.title ? ` · ${me.title}` : ''}{me.company_name ? ` · ${me.company_name}` : ''}</div>
        </div>
      </div>
      {me.memberships.length > 1 && (
        <Card>
          <b>Chuyển công ty</b>
          {me.memberships.map((m) => (
            <button key={m.company_id} className="btn block sm" style={{ marginTop: 6 }} disabled={m.company_id === me.company_id} onClick={() => switchCompany(m.company_id)}>{m.company_name} · {ROLE[m.role]}</button>
          ))}
        </Card>
      )}
      <div className="section-title">Cá nhân</div><M items={personal} />
      {ops.length > 0 && <><div className="section-title">Vận hành &amp; hiệu suất</div><M items={ops} /></>}
      {handoverSetup.length > 0 && <><div className="section-title">Bàn giao</div><M items={handoverSetup} /></>}
      {work.length > 0 && <><div className="section-title">Công việc</div><M items={work} /></>}
      {admin.length > 0 && <><div className="section-title">Quản trị</div><M items={admin} /></>}
      {me.company_id && <Card><KV k="Nhóm quản lý" v={me.managed_groups?.map((g) => g.name).join(', ') || '—'} /><KV k="Phòng ban phụ trách" v={me.headed_departments?.map((g) => g.name).join(', ') || '—'} /></Card>}
      <div className="section-title">Tài khoản</div>
      <div className="menu">
        <button onClick={() => setPw(true)}><IconChip name="key" tone="gray" size={19} /><span className="grow"><b>Đổi mật khẩu</b></span></button>
        <button onClick={logout}><IconChip name="terminate" tone="red" size={19} /><span className="grow"><b style={{ color: 'var(--red)' }}>Đăng xuất</b></span></button>
      </div>
      <Sheet open={pw} onClose={() => setPw(false)} title="Đổi mật khẩu"><ChangePw onDone={() => { setPw(false); logout(); }} /></Sheet>
    </div>
  );
}

function ChangePw({ onDone }: { onDone: () => void }) {
  const [o, setO] = useState(''); const [n, setN] = useState('');
  const a = useAction();
  return (
    <>
      <Field label="Mật khẩu hiện tại"><input type="password" value={o} onChange={(e) => setO(e.target.value)} /></Field>
      <Field label="Mật khẩu mới" hint="Tối thiểu 8 ký tự. Mọi phiên đăng nhập khác sẽ bị thu hồi."><input type="password" value={n} onChange={(e) => setN(e.target.value)} /></Field>
      <ErrorBox error={a.error} />
      <button className="btn primary block" disabled={a.busy} onClick={() => a.run(async () => { await post('/auth/change-password', { oldPassword: o, newPassword: n }); onDone(); })}>Cập nhật</button>
    </>
  );
}
