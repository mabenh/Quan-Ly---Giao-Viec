import { useState } from 'react';
import { get, post } from '../api';
import { Badge, Card, Empty, ErrorBox, Field, Header, Loading, Select, Sheet, Tabs, useAction, useLoad } from '../ui';
import { fmtDT } from '../labels';
import { DSR_STATUS, DSR_TYPE } from './Privacy';

/** Nhân sự xử lý yêu cầu của chủ thể dữ liệu (đính chính, xóa, hạn chế). */
export function PrivacyRequests() {
  const [tab, setTab] = useState('open');
  const { data, error, setData } = useLoad(() => get(`/privacy/requests${tab === 'open' ? '?status=submitted,in_review' : ''}`), [tab]);
  const [cur, setCur] = useState<any>(null);
  return (
    <>
      <Header title="Yêu cầu về dữ liệu cá nhân" back="/hr" />
      <div className="page">
        <p className="small muted">Xử lý trong hạn. Không tự xử lý yêu cầu của chính mình. Không xóa dữ liệu có nghĩa vụ lưu trữ — nêu rõ phần tiếp tục lưu và căn cứ.</p>
        <Tabs value={tab} onChange={setTab} tabs={[['open', 'Đang mở'], ['all', 'Tất cả']]} />
        <ErrorBox error={error} />
        {!data && !error && <Loading />}
        {data && data.length === 0 && <Empty>Không có yêu cầu</Empty>}
        {data?.map((r: any) => (
          <Card key={r.id} onClick={r.is_mine ? undefined : () => setCur(r)}>
            <div className="row"><b>{r.code}</b><span className="small" style={{ flex: 1 }}> · {DSR_TYPE[r.request_type]} · {r.user_name}</span><Badge tone={DSR_STATUS[r.status][1]}>{DSR_STATUS[r.status][0]}</Badge></div>
            <div className="small">{r.details}</div>
            {r.field_key && <div className="small muted">Đề nghị: {r.field_key} → {r.proposed_value}</div>}
            {r.scope && <div className="small muted">Phạm vi xóa: {r.scope.join(', ')}</div>}
            <div className="small muted">Hạn xử lý {fmtDT(r.due_at)}{r.overdue ? ' · QUÁ HẠN' : ''} · phụ trách {r.assigned_name || '—'}{r.is_mine ? ' · (yêu cầu của bạn — người khác xử lý)' : ''}</div>
            {r.resolution && <div className="small">Kết quả: {r.resolution}</div>}
          </Card>
        ))}
      </div>
      <Sheet open={!!cur} onClose={() => setCur(null)} title={cur ? `${cur.code} · ${DSR_TYPE[cur.request_type]}` : ''}>
        {cur && <ResolveForm r={cur} onDone={(d) => { setData(d); setCur(null); }} />}
      </Sheet>
    </>
  );
}

function ResolveForm({ r, onDone }: { r: any; onDone: (d: any) => void }) {
  const [st, setSt] = useState(r.request_type === 'deletion' ? 'partially_completed' : 'completed');
  const [res, setRes] = useState(''); const [ret, setRet] = useState(''); const [apply, setApply] = useState(true);
  const a = useAction();
  const canApply = (r.request_type === 'correction' && ['name', 'title'].includes(r.field_key)) || r.request_type === 'restriction' || r.request_type === 'deletion';
  return (
    <>
      <p className="small">{r.details}</p>
      <Field label="Quyết định"><Select value={st} onChange={setSt} options={{ in_review: 'Đang xem xét (chưa đóng)', completed: 'Đã thực hiện', partially_completed: 'Thực hiện một phần', rejected: 'Không thể thực hiện' }} /></Field>
      {canApply && st !== 'rejected' && st !== 'in_review' && (
        <label className="check"><input type="checkbox" checked={apply} onChange={(e) => setApply(e.target.checked)} />
          {r.request_type === 'correction' ? ` Cập nhật ${r.field_key === 'name' ? 'họ tên' : 'chức danh'} thành “${r.proposed_value}”` : r.request_type === 'restriction' ? ' Bật hạn chế: chỉ Nhân sự xem được hồ sơ CV' : ` Xóa: ${(r.scope || []).join(', ') || '(chưa chọn phạm vi)'}`}
        </label>
      )}
      <Field label="Kết quả / lý do (người yêu cầu sẽ thấy)" required><textarea value={res} onChange={(e) => setRes(e.target.value)} /></Field>
      {(st === 'partially_completed' || st === 'rejected') && <Field label="Phần dữ liệu tiếp tục lưu, căn cứ và thời hạn" required={r.request_type === 'deletion'}><textarea value={ret} onChange={(e) => setRet(e.target.value)} placeholder="VD: Dữ liệu nhiệm vụ, chấm công lưu theo nghĩa vụ lao động" /></Field>}
      <ErrorBox error={a.error} />
      <button className="btn primary block" disabled={a.busy || res.trim().length < 5} onClick={() => a.run(async () => onDone(await post(`/privacy/requests/${r.id}/resolve`, { status: st, resolution: res, retainedNote: ret || undefined, apply })))}>Lưu</button>
    </>
  );
}

const SCOPE: Record<string, string> = { company_settings: 'Cấu hình công ty', members_basic: 'Danh sách thành viên (tên, vai trò)', audit_logs: 'Nhật ký thay đổi' };
const PA_STATUS: Record<string, [string, string]> = { pending: ['Chờ duyệt', 'amber'], approved: ['Đang hiệu lực', 'green'], rejected: ['Từ chối', 'red'], expired: ['Hết hạn', 'gray'], revoked: ['Đã thu hồi', 'gray'] };

/** Quản trị: cảnh báo hành vi bất thường + duyệt quyền truy cập tạm thời của hỗ trợ nền tảng. */
export function SecurityCenter() {
  const [tab, setTab] = useState('alerts');
  const [st, setSt] = useState('open');
  const alerts = useLoad(() => get(`/security/alerts?status=${st}`), [st]);
  const access = useLoad(() => get('/support/access-requests'), []);
  const [rev, setRev] = useState<any>(null);
  const a = useAction();
  return (
    <>
      <Header title="An toàn dữ liệu" back="/me" />
      <div className="page">
        <Tabs value={tab} onChange={setTab} tabs={[['alerts', 'Cảnh báo bất thường'], ['support', 'Quyền hỗ trợ kỹ thuật']]} />
        {tab === 'alerts' && (
          <>
            <p className="small muted">Cảnh báo là tín hiệu để rà soát, không phải kết luận vi phạm. Không tự khóa tài khoản chỉ vì một tín hiệu. Cảnh báo liên quan chính bạn cần người khác rà soát.</p>
            <div className="filters"><Select value={st} onChange={setSt} options={{ open: 'Chưa rà soát', reviewed: 'Đã rà soát', dismissed: 'Đã bỏ qua', all: 'Tất cả' }} /></div>
            {alerts.data && alerts.data.length === 0 && <Empty>Không có cảnh báo</Empty>}
            {alerts.data?.map((x: any) => (
              <Card key={x.id} onClick={x.status === 'open' ? () => setRev(x) : undefined}>
                <div className="row"><b style={{ flex: 1 }}>{x.detail}</b>{x.count > 1 && <Badge tone="amber">×{x.count}</Badge>}</div>
                <div className="small muted">{x.user_name || 'Không rõ tài khoản'} · {fmtDT(x.created_at)}{x.review_note ? ` · ${x.review_note}` : ''}</div>
              </Card>
            ))}
          </>
        )}
        {tab === 'support' && (
          <>
            <p className="small muted">Nhân viên hỗ trợ nền tảng không có quyền đọc dữ liệu công ty theo mặc định. Mỗi lần truy cập phải được bạn duyệt, có thời hạn, có lý do và được ghi nhật ký. Truy cập khẩn cấp (tối đa 1 giờ) cần bạn hậu kiểm.</p>
            {access.data && access.data.length === 0 && <Empty>Chưa có yêu cầu</Empty>}
            {access.data?.map((p: any) => (
              <Card key={p.id}>
                <div className="row"><b style={{ flex: 1 }}>{SCOPE[p.scope]}</b>{p.emergency && <Badge tone="red">Khẩn cấp</Badge>}<Badge tone={PA_STATUS[p.status][1]}>{PA_STATUS[p.status][0]}</Badge></div>
                <div className="small">{p.reason}{p.ticket ? ` · phiếu ${p.ticket}` : ''}</div>
                <div className="small muted">{p.requester_name} · {fmtDT(p.created_at)} · {p.hours} giờ{p.expires_at ? ` · hết hạn ${fmtDT(p.expires_at)}` : ''}</div>
                <div className="actions">
                  {p.status === 'pending' && <><button className="btn sm primary" disabled={a.busy} onClick={() => a.run(async () => access.setData(await post(`/support/access-requests/${p.id}/decide`, { decision: 'approve' })))}>Duyệt</button>
                    <button className="btn sm" disabled={a.busy} onClick={() => a.run(async () => access.setData(await post(`/support/access-requests/${p.id}/decide`, { decision: 'reject' })))}>Từ chối</button></>}
                  {p.status === 'approved' && <button className="btn sm danger" disabled={a.busy} onClick={() => a.run(async () => access.setData(await post(`/support/access-requests/${p.id}/decide`, { decision: 'revoke', note: 'Thu hồi' })))}>Thu hồi ngay</button>}
                </div>
              </Card>
            ))}
            <ErrorBox error={a.error} />
          </>
        )}
      </div>
      <Sheet open={!!rev} onClose={() => setRev(null)} title="Rà soát cảnh báo">{rev && <AlertReview x={rev} onDone={(d) => { alerts.setData(d); setRev(null); }} />}</Sheet>
    </>
  );
}

function AlertReview({ x, onDone }: { x: any; onDone: (d: any) => void }) {
  const [st, setSt] = useState('reviewed'); const [n, setN] = useState('');
  const a = useAction();
  return (
    <>
      <p className="small">{x.detail}</p>
      <Field label="Kết luận rà soát"><Select value={st} onChange={setSt} options={{ reviewed: 'Đã rà soát (có hành động/ghi nhận)', dismissed: 'Bỏ qua — hoạt động công việc bình thường' }} /></Field>
      <Field label="Ghi chú" required><textarea value={n} onChange={(e) => setN(e.target.value)} /></Field>
      <ErrorBox error={a.error} />
      <button className="btn primary block" disabled={a.busy || n.trim().length < 3} onClick={() => a.run(async () => onDone(await post(`/security/alerts/${x.id}/review`, { status: st, note: n })))}>Lưu</button>
    </>
  );
}
