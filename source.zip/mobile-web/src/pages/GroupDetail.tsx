import { useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { del, get, patch, post } from '../api';
import { isAdminRole, useAuth } from '../auth';
import { Badge, Card, ErrorBox, Field, Header, Loading, Select, Sheet, useAction, useLoad } from '../ui';
import { ROLE } from '../labels';

export default function GroupDetail() {
  const { id } = useParams();
  const { me } = useAuth();
  const { data: g, error, loading, setData } = useLoad(() => get(`/groups/${id}`), [id]);
  const members = useLoad(() => get('/company/members'), []);
  const [add, setAdd] = useState(false); const [edit, setEdit] = useState(false);
  const [pick, setPick] = useState<string[]>([]);
  const a = useAction();
  if (loading && !g) return <Loading />;
  if (!g) return <div className="page"><ErrorBox error={error} /></div>;
  const inGroup = new Set(g.members.map((m: any) => m.member_id));
  return (
    <>
      <Header title={g.name} back="/groups" />
      <div className="page">
        {g.description && <p className="muted">{g.description}</p>}
        <Card><div className="row"><span>Quản lý chính:</span><b>{g.manager_name}</b></div></Card>
        <div className="actions">
          <Link className="btn" to={`/work?tab=tasks&groupId=${g.id}`}>Nhiệm vụ của nhóm</Link>
          {g.can_manage && <Link className="btn" to={`/performance?scopeType=group&scopeId=${g.id}`}>Báo cáo nhóm</Link>}
          {g.can_manage && <button className="btn primary" onClick={() => setAdd(true)}>＋ Thêm thành viên</button>}
          {g.can_manage && <button className="btn" onClick={() => setEdit(true)}>Sửa nhóm</button>}
        </div>
        <ErrorBox error={a.error} />
        <div className="section-title">Thành viên ({g.members.length})</div>
        {g.members.map((m: any) => (
          <Card key={m.member_id}>
            <div className="row">
              <div style={{ flex: 1 }}><b>{m.name}</b><div className="small muted">{m.title || ROLE[m.role]} · {m.email}</div></div>
              <Badge>{ROLE[m.role]}</Badge>
              {g.can_manage && m.member_id !== g.manager_member_id && (
                <button className="btn sm danger" disabled={a.busy} onClick={() => confirm(`Xóa ${m.name} khỏi nhóm?`) && a.run(async () => setData(await del(`/groups/${id}/members/${m.member_id}`)))}>Xóa</button>
              )}
            </div>
          </Card>
        ))}
      </div>
      <Sheet open={add} onClose={() => setAdd(false)} title="Thêm thành viên">
        {(members.data || []).filter((m: any) => !inGroup.has(m.id) && m.status === 'active').map((m: any) => (
          <label key={m.id} className="check"><input type="checkbox" checked={pick.includes(m.id)} onChange={(e) => setPick(e.target.checked ? [...pick, m.id] : pick.filter((x) => x !== m.id))} />{m.name} <span className="small muted">{ROLE[m.role]}</span></label>
        ))}
        <ErrorBox error={a.error} />
        <button className="btn primary block" disabled={a.busy || !pick.length} onClick={() => a.run(async () => { setData(await post(`/groups/${id}/members`, { memberIds: pick })); setPick([]); setAdd(false); })}>Thêm {pick.length} người</button>
      </Sheet>
      <Sheet open={edit} onClose={() => setEdit(false)} title="Sửa nhóm"><EditGroup g={g} isAdmin={isAdminRole(me?.role)} members={members.data || []} onDone={(x) => { setData(x); setEdit(false); }} /></Sheet>
    </>
  );
}

function EditGroup({ g, isAdmin, members, onDone }: { g: any; isAdmin: boolean; members: any[]; onDone: (x: any) => void }) {
  const [name, setName] = useState(g.name); const [desc, setDesc] = useState(g.description || ''); const [mgr, setMgr] = useState(g.manager_member_id);
  const a = useAction();
  return (
    <>
      <Field label="Tên nhóm"><input value={name} onChange={(e) => setName(e.target.value)} /></Field>
      <Field label="Mô tả"><textarea value={desc} onChange={(e) => setDesc(e.target.value)} /></Field>
      {isAdmin && <Field label="Quản lý chính"><Select value={mgr} onChange={setMgr} options={members.filter((m) => ['manager', 'admin', 'owner'].includes(m.role)).map((m) => [m.id, m.name])} /></Field>}
      <ErrorBox error={a.error} />
      <button className="btn primary block" disabled={a.busy} onClick={() => a.run(async () => onDone(await patch(`/groups/${g.id}`, { name, description: desc, ...(mgr !== g.manager_member_id ? { managerMemberId: mgr } : {}) })))}>Lưu</button>
    </>
  );
}
