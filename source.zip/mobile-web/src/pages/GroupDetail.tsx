import { useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { del, get, patch, post } from '../api';
import { isAdminRole, isManagerRole, useAuth } from '../auth';
import { Avatar, Badge, Card, ErrorBox, Field, Header, Loading, Select, Sheet, Tabs, useAction, useLoad } from '../ui';
import { ROLE } from '../labels';
import { ContactButtons } from '../comms';
import { Dot } from '../marks';

export default function GroupDetail() {
  const { id } = useParams();
  const { me } = useAuth();
  const { data: g, error, loading, setData, reload } = useLoad(() => get(`/groups/${id}`), [id]);
  const members = useLoad(() => get('/company/members?status=active'), []);
  const [add, setAdd] = useState(false); const [edit, setEdit] = useState(false);
  const a = useAction();
  if (loading && !g) return <Loading />;
  if (!g) return <div className="page"><ErrorBox error={error} /></div>;
  const byMember = Object.fromEntries((members.data || []).map((m: any) => [m.id, m]));
  const canSeeProfile = isManagerRole(me?.role) || me?.role === 'hr';
  const seen = new Set<string>();
  const raw = [...g.members.filter((m: any) => m.member_id === g.manager_member_id), ...g.members.filter((m: any) => m.member_id !== g.manager_member_id)];
  if (!raw.some((m: any) => m.member_id === g.manager_member_id)) raw.unshift({ member_id: g.manager_member_id, name: g.manager_name, role: 'manager' });
  const list = raw.filter((m: any) => (seen.has(m.member_id) ? false : (seen.add(m.member_id), true))).map((m: any) => ({ ...m, isMgr: m.member_id === g.manager_member_id }));
  const tot = list.reduce((acc: any, m: any) => ({ doing: acc.doing + (m.doing || 0), reviewing: acc.reviewing + (m.reviewing || 0), done: acc.done + (m.done_month || 0), overdue: acc.overdue + (m.overdue || 0) }), { doing: 0, reviewing: 0, done: 0, overdue: 0 });
  return (
    <>
      <Header title={g.name} back="/groups" />
      <div className="page">
        {g.description && <p className="muted">{g.description}</p>}
        <div className="actions">
          <Link className="btn" to={`/work?tab=tasks&groupId=${g.id}`}>Nhiệm vụ của nhóm</Link>
          {g.can_manage && <Link className="btn" to={`/performance?scopeType=group&scopeId=${g.id}`}>Báo cáo nhóm</Link>}
          {g.can_manage && <Link className="btn" to="/team">Tình trạng tuần</Link>}
          {g.can_manage && <button className="btn primary" onClick={() => setAdd(true)}>＋ Thêm thành viên</button>}
          {g.can_manage && <button className="btn" onClick={() => setEdit(true)}>Sửa nhóm</button>}
        </div>
        <ErrorBox error={a.error} />
        <div className="stats" style={{ gridTemplateColumns: 'repeat(4, 1fr)' }}>
          <div className="stat"><div className="n">{tot.doing}</div><div className="l">Đang làm</div></div>
          <div className="stat attn"><div className="n">{tot.reviewing}</div><div className="l">Chờ nghiệm thu</div></div>
          <div className="stat"><div className="n">{tot.done}</div><div className="l">Xong tháng này</div></div>
          <div className={`stat ${tot.overdue ? 'warn' : ''}`}><div className="n">{tot.overdue}</div><div className="l">Quá hạn</div></div>
        </div>
        <div className="section-title">Thành viên ({list.length}) · số việc được giao</div>
        {list.map((m: any) => {
          const info = { ...(byMember[m.member_id] || {}), ...(m.phone ? { phone: m.phone } : {}), ...(m.user_id ? { user_id: m.user_id } : {}), ...(m.has_avatar !== undefined ? { has_avatar: m.has_avatar } : {}) };
          const self = m.member_id === me?.member_id;
          return (
            <Card key={m.member_id}>
              <div className="row">
                <Avatar userId={info.user_id} name={m.name} has={info.has_avatar} />
                <div style={{ flex: 1, minWidth: 0 }}><b>{m.name}</b><div className="small muted">{m.title || ROLE[m.role]}</div></div>
                {m.isMgr ? <Badge tone="blue">Quản lý</Badge> : <Badge>{ROLE[m.role]}</Badge>}
              </div>
              {m.doing !== undefined && (
                <div className="cnt-row" aria-label="Số việc được giao">
                  <span><Dot k="in_progress" size={8} /> Đang làm <b>{m.doing}</b></span>
                  <span><Dot k="pending_review" size={8} /> Chờ nghiệm thu <b>{m.reviewing}</b></span>
                  <span><Dot k="completed" size={8} /> Xong tháng <b>{m.done_month}</b></span>
                  {m.overdue > 0 && <span><Dot k="overdue" size={8} /> Quá hạn <b>{m.overdue}</b></span>}
                </div>
              )}
              {!self && <ContactButtons memberId={m.member_id} name={m.name} />}
              {!self && (canSeeProfile && info.user_id || (g.can_manage && !m.isMgr)) && (
                <div className="actions">
                  {canSeeProfile && info.user_id && <Link className="btn sm" to={`/people/${info.user_id}`}>Hồ sơ</Link>}
                  {g.can_manage && !m.isMgr && <button className="btn sm danger" disabled={a.busy} onClick={() => confirm(`Xóa ${m.name} khỏi nhóm?`) && a.run(async () => setData(await del(`/groups/${id}/members/${m.member_id}`)))}>Xóa</button>}
                </div>
              )}
            </Card>
          );
        })}
      </div>
      <Sheet open={add} onClose={() => setAdd(false)} title="Thêm thành viên">
        {add && <AddMember groupId={g.id} inGroup={new Set(list.map((m: any) => m.member_id))} members={members.data || []} onDone={() => { setAdd(false); reload(); members.reload(); }} />}
      </Sheet>
      <Sheet open={edit} onClose={() => setEdit(false)} title="Sửa nhóm"><EditGroup g={g} isAdmin={isAdminRole(me?.role)} members={members.data || []} onDone={(x) => { setData(x); setEdit(false); }} /></Sheet>
    </>
  );
}

function AddMember({ groupId, inGroup, members, onDone }: { groupId: string; inGroup: Set<string>; members: any[]; onDone: () => void }) {
  const { me } = useAuth();
  const [mode, setMode] = useState('phone');
  const [phone, setPhone] = useState(''); const [name, setName] = useState('');
  const [pick, setPick] = useState<string[]>([]);
  const [msg, setMsg] = useState<string | null>(null);
  const a = useAction();
  const direct = ['owner', 'admin', 'hr'].includes(me?.role || '');
  return (
    <>
      <Tabs value={mode} onChange={setMode} tabs={[['phone', 'Bằng số điện thoại'], ['company', 'Từ thành viên công ty']]} />
      {mode === 'phone' && (
        <>
          <Field label="Số điện thoại" required><input type="tel" inputMode="tel" value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="0912 345 678" /></Field>
          <Field label="Họ và tên đầy đủ" hint="Bắt buộc nếu số này chưa có tài khoản Việc Đến"><input value={name} onChange={(e) => setName(e.target.value)} /></Field>
          {!direct && <div className="alert info small">Thành viên mới sẽ được thêm sau khi phòng ban nhân sự kiểm duyệt.</div>}
          {msg && <div className="alert ok small">{msg}</div>}
          <ErrorBox error={a.error} />
          <button className="btn primary block" disabled={a.busy || !phone} onClick={() => a.run(async () => {
            const r = await post('/company/members', { phone, name: name || undefined, groupId });
            setMsg(`${r.name}: ${r.status === 'pending_hr' ? 'đã gửi nhân sự duyệt' : 'đã thêm vào nhóm'}.${r.message ? ' ' + r.message : ''}`);
            setPhone(''); setName('');
            if (r.status !== 'pending_hr' && !r.invited) onDone();
          })}>{direct ? 'Thêm thành viên' : 'Gửi đề nghị thêm'}</button>
        </>
      )}
      {mode === 'company' && (
        <>
          {members.filter((m) => !inGroup.has(m.id) && m.status === 'active').map((m) => (
            <label key={m.id} className="check"><input type="checkbox" checked={pick.includes(m.id)} onChange={(e) => setPick(e.target.checked ? [...pick, m.id] : pick.filter((x) => x !== m.id))} />{m.name} <span className="small muted">{ROLE[m.role]}</span></label>
          ))}
          <ErrorBox error={a.error} />
          <button className="btn primary block" disabled={a.busy || !pick.length} onClick={() => a.run(async () => { await post(`/groups/${groupId}/members`, { memberIds: pick }); onDone(); })}>Thêm {pick.length} người</button>
        </>
      )}
    </>
  );
}

function EditGroup({ g, isAdmin, members, onDone }: { g: any; isAdmin: boolean; members: any[]; onDone: (x: any) => void }) {
  const [name, setName] = useState(g.name); const [desc, setDesc] = useState(g.description || ''); const [mgr, setMgr] = useState(g.manager_member_id);
  const [leader, setLeader] = useState(g.leader_member_id || '');
  const [dept, setDept] = useState(g.department_id || '');
  const depts = useLoad(() => (isAdmin ? get('/company/departments') : Promise.resolve([])), [isAdmin]);
  const a = useAction();
  return (
    <>
      <Field label="Tên nhóm"><input value={name} onChange={(e) => setName(e.target.value)} /></Field>
      <Field label="Mô tả"><textarea value={desc} onChange={(e) => setDesc(e.target.value)} /></Field>
      <Field label="Trưởng nhóm" hint="Tổ chức thực hiện, xác nhận sản lượng/bàn giao, theo dõi phiên làm việc. Để trống: quản lý nhóm đảm nhận. Phụ cấp trưởng nhóm là chính sách nhân sự riêng."><Select value={leader} onChange={setLeader} options={(g.members || []).map((m: any) => [m.member_id, m.name])} placeholder="— Quản lý nhóm —" /></Field>
      {isAdmin && <Field label="Thuộc phòng ban" hint="Quản lý phòng ban giao việc & xem việc của các nhóm thuộc phòng mình"><Select value={dept} onChange={setDept} options={(depts.data || []).map((d: any) => [d.id, d.name])} placeholder="— Không thuộc phòng ban —" /></Field>}
      {isAdmin && <Field label="Quản lý chính"><Select value={mgr} onChange={setMgr} options={members.filter((m) => ['manager', 'admin', 'owner'].includes(m.role)).map((m) => [m.id, m.name])} /></Field>}
      <ErrorBox error={a.error} />
      <button className="btn primary block" disabled={a.busy} onClick={() => a.run(async () => onDone(await patch(`/groups/${g.id}`, { name, description: desc, leaderMemberId: leader || null, ...(isAdmin && dept !== (g.department_id || '') ? { departmentId: dept || null } : {}), ...(mgr !== g.manager_member_id ? { managerMemberId: mgr } : {}) })))}>Lưu</button>
    </>
  );
}
