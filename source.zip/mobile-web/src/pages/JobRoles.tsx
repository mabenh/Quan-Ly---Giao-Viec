import { useState } from 'react';
import { get, patch, post } from '../api';
import { isHRRole, useAuth } from '../auth';
import { Badge, Card, Empty, ErrorBox, Field, Header, Loading, Sheet, useAction, useLoad, Note } from '../ui';
import { Icon } from '../icons';

/** Mô tả công việc, nhiệm vụ cho từng vai trò — căn cứ phân loại việc trong vai trò / ngoài vai trò. */
export default function JobRoles() {
  const { me } = useAuth();
  const canEdit = isHRRole(me?.role);
  const { data, error, loading, reload } = useLoad(() => get('/company/job-roles'), []);
  const [edit, setEdit] = useState<any | null>(null);
  return (
    <>
      <Header title="Mô tả công việc" back="/hr" right={canEdit ? <button className="btn sm primary" onClick={() => setEdit({})}><Icon name="plus" size={16} />Vai trò</button> : undefined} />
      <div className="page">
        <Note>Mỗi nhân viên được gán một vai trò. Việc khớp nhiệm vụ của vai trò là <b>việc thường ngày</b>; việc ngoài danh sách là <b>việc ngoài vai trò</b> — khi được quản lý xác nhận sẽ được cộng điểm O và không làm giảm điểm người khác.</Note>
        <ErrorBox error={error} />
        {loading && !data && <Loading />}
        {data && data.length === 0 && <Empty>Chưa có vai trò</Empty>}
        {data?.map((r: any) => (
          <Card key={r.id} onClick={canEdit ? () => setEdit(r) : undefined}>
            <div className="row"><b style={{ flex: 1 }}>{r.name}</b>{!r.active && <Badge>Ngừng dùng</Badge>}<Badge tone="blue">{r.member_count} người</Badge></div>
            {r.description && <div className="small muted">{r.description}</div>}
            <ul className="small" style={{ margin: '6px 0 0', paddingLeft: 18 }}>{(r.duties || []).map((d: string, i: number) => <li key={i}>{d}</li>)}</ul>
            {r.keywords?.length > 0 && <div className="small muted" style={{ marginTop: 4 }}>Từ khóa nhận diện: {r.keywords.join(', ')}</div>}
          </Card>
        ))}
      </div>
      <Sheet open={!!edit} onClose={() => setEdit(null)} title={edit?.id ? 'Sửa vai trò' : 'Vai trò mới'}>
        {edit && <RoleForm r={edit} onDone={() => { setEdit(null); reload(); }} />}
      </Sheet>
    </>
  );
}

function RoleForm({ r, onDone }: { r: any; onDone: () => void }) {
  const [name, setName] = useState(r.name || '');
  const [desc, setDesc] = useState(r.description || '');
  const [duties, setDuties] = useState((r.duties || []).join('\n'));
  const [kw, setKw] = useState((r.keywords || []).join(', '));
  const [active, setActive] = useState(r.active !== false);
  const a = useAction();
  const body = () => ({
    name, description: desc || null, active,
    duties: duties.split('\n').map((x: string) => x.trim()).filter((x: string) => x.length >= 2),
    keywords: kw.split(',').map((x: string) => x.trim()).filter((x: string) => x.length >= 2),
  });
  return (
    <>
      <Field label="Tên vai trò" required><input value={name} onChange={(e) => setName(e.target.value)} /></Field>
      <Field label="Mô tả chung"><textarea value={desc} onChange={(e) => setDesc(e.target.value)} /></Field>
      <Field label="Nhiệm vụ trong vai trò" hint="Mỗi dòng một nhiệm vụ"><textarea rows={6} value={duties} onChange={(e) => setDuties(e.target.value)} /></Field>
      <Field label="Từ khóa nhận diện" hint="Phân cách bằng dấu phẩy — dùng để gợi ý việc trong vai trò khi nhân viên khai báo"><input value={kw} onChange={(e) => setKw(e.target.value)} /></Field>
      {r.id && <label className="check"><input type="checkbox" checked={active} onChange={(e) => setActive(e.target.checked)} /> Đang sử dụng</label>}
      <ErrorBox error={a.error} />
      <button className="btn primary block" disabled={a.busy || name.trim().length < 2} onClick={() => a.run(async () => { await (r.id ? patch(`/company/job-roles/${r.id}`, body()) : post('/company/job-roles', body())); onDone(); })}>Lưu</button>
    </>
  );
}
