import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { get, post } from '../api';
import { useAuth } from '../auth';
import { ErrorBox, Field, Header, Select, useAction, useLoad } from '../ui';
import { fromLocalInput, toLocalInput } from '../labels';

/**
 * Ghi nhận giờ làm / tăng ca ngoại lệ: máy chấm công không hoạt động hoặc làm việc ngoài công ty (xưởng, công trình).
 * Người yêu cầu (người ghi nhận) phải có chức vụ/vị trí cao hơn người được ghi nhận. Không có hàng chờ xác nhận —
 * app không tính lương, đây là tham số tính hiệu suất.
 */
export default function OvertimeException() {
  const nav = useNavigate();
  const { me } = useAuth();
  const members = useLoad(() => get('/company/members?status=active'), []);
  const tasks = useLoad(() => get('/tasks?limit=100&status=not_started,in_progress,revision_requested'), []);
  const now = new Date(); now.setMinutes(0, 0, 0);
  const [f, setF] = useState<any>({ kind: 'timeclock_down', place: '', memberIds: [] as string[], startAt: toLocalInput(new Date(now.getTime() - 2 * 3600000)), endAt: toLocalInput(now), workMinutes: '', cause: '', taskId: '' });
  const [done, setDone] = useState<string | null>(null);
  const a = useAction();
  const up = (p: any) => setF((x: any) => ({ ...x, ...p }));
  const mins = Math.round((new Date(f.endAt).getTime() - new Date(f.startAt).getTime()) / 60000);
  const list = (members.data || []).filter((m: any) => m.id !== me?.member_id);
  return (
    <>
      <Header title="Ghi nhận giờ làm ngoài máy chấm công" back />
      <div className="page">
        <p className="small muted">Dùng khi máy chấm công không hoạt động hoặc nhân viên làm việc ngoài công ty (xưởng, công trình). Người ghi nhận là người yêu cầu và phải có chức vụ/vị trí cao hơn người được ghi nhận. App không tính lương — số giờ này chỉ là tham số hiệu suất.</p>
        <div className="seg">
          <button className={f.kind === 'timeclock_down' ? 'on' : ''} onClick={() => up({ kind: 'timeclock_down' })}>Máy chấm công không hoạt động</button>
          <button className={f.kind === 'offsite' ? 'on' : ''} onClick={() => up({ kind: 'offsite' })}>Làm việc ngoài công ty / xưởng</button>
        </div>
        {f.kind === 'offsite' && <Field label="Nơi làm việc" required><input value={f.place} onChange={(e) => up({ place: e.target.value })} placeholder="VD: Xưởng đối tác Bình Dương" /></Field>}
        <Field label="Người được ghi nhận" required hint="Chỉ chọn người có chức vụ/vị trí thấp hơn bạn (cấp dưới, thành viên nhóm bạn phụ trách)">
          <div style={{ maxHeight: 220, overflow: 'auto' }}>{list.map((m: any) => (
            <label key={m.id} className="check"><input type="checkbox" checked={f.memberIds.includes(m.id)} onChange={(e) => up({ memberIds: e.target.checked ? [...f.memberIds, m.id] : f.memberIds.filter((x: string) => x !== m.id) })} /> {m.name}{m.title ? ` — ${m.title}` : ''}</label>
          ))}</div>
        </Field>
        <div className="grid2">
          <Field label="Tăng ca từ" required><input type="datetime-local" value={f.startAt} onChange={(e) => up({ startAt: e.target.value })} /></Field>
          <Field label="Đến" required><input type="datetime-local" value={f.endAt} onChange={(e) => up({ endAt: e.target.value })} /></Field>
        </div>
        <div className="small muted">Thời gian tăng ca: {mins > 0 ? `${Math.floor(mins / 60)} giờ ${mins % 60} phút` : 'không hợp lệ'}</div>
        <Field label="Giờ làm việc thường trong ngày (phút, nếu máy chấm công không ghi được)"><input type="number" min={0} value={f.workMinutes} onChange={(e) => up({ workMinutes: e.target.value })} placeholder="VD: 480" /></Field>
        <Field label="Nhiệm vụ liên quan (tùy chọn)"><Select value={f.taskId} onChange={(v) => up({ taskId: v })} options={(tasks.data?.items || []).map((t: any) => [t.id, `${t.code} - ${t.title}`])} placeholder="— Không —" /></Field>
        <Field label="Lý do / nội dung công việc" required><textarea value={f.cause} onChange={(e) => up({ cause: e.target.value })} /></Field>
        <ErrorBox error={a.error} />
        {done && <div className="alert ok">{done}</div>}
        <button className="btn primary block" disabled={a.busy || !f.memberIds.length || mins <= 0 || f.cause.trim().length < 5} onClick={() => a.run(async () => {
          const r = await post('/overtime-records/exception', { memberIds: f.memberIds, kind: f.kind, place: f.place || undefined, startAt: fromLocalInput(f.startAt), endAt: fromLocalInput(f.endAt),
            workMinutes: f.workMinutes === '' ? undefined : Number(f.workMinutes), cause: f.cause, taskId: f.taskId || undefined });
          setDone(`Đã ghi nhận cho ${r.ids.length} người. Người được ghi nhận nhận được thông báo.`);
          setTimeout(() => nav(-1), 1500);
        })}>Ghi nhận</button>
      </div>
    </>
  );
}
