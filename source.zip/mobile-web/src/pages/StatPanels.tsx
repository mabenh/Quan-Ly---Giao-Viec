import { Link } from 'react-router-dom';
import { get } from '../api';
import { isManagerRole, useAuth } from '../auth';
import { useLoad } from '../ui';
import { Icon, IconChip } from '../icons';

/** v19: ô số liệu trực quan dùng chung (Trang chủ, Công việc). */
export type Tile = [number, string, string, ('warn' | 'attn')?, string?];
export const Stat = ({ t: [n, l, to, tone, ic], onClick }: { t: Tile; onClick?: () => void }) => {
  const body = <>
    <IconChip name={ic || 'list'} tone={tone === 'warn' ? 'red' : tone === 'attn' ? 'amber' : 'blue'} size={19} />
    <div style={{ minWidth: 0 }}><div className="n">{n}</div><div className="l">{l}</div></div>
  </>;
  return onClick ? <button type="button" className={`stat ${n > 0 && tone ? tone : ''}`} onClick={onClick}>{body}</button>
    : <Link to={to} className={`stat ${n > 0 && tone ? tone : ''}`}>{body}</Link>;
};

export function manageTilesOf(g: any, mgr: boolean): Tile[] {
  return ([
    [g.tasks_pending_review, 'Việc chờ tôi nghiệm thu', '/work?tab=tasks&status=pending_review', 'attn', 'ok'],
    [g.tasks_to_approve || 0, 'Giao việc liên nhóm chờ tôi duyệt', '/work?tab=tasks&status=pending_approval', 'warn', 'assign'],
    [g.decisions_to_confirm, 'Bàn giao chờ tôi xác nhận', '/hr/decisions', 'warn', 'decision'],
    [g.permits_to_decide, 'Giấy phép chờ phòng ban cấp', '/work?tab=permits&scope=handling&status=pending', 'warn', 'permit'],
    [g.permits_to_review, 'Giấy phép khai báo cần hậu kiểm', '/work?tab=permits&scope=handling&review=pending', 'attn', 'permit'],
    [g.work_records_to_review.n, `Bản ghi cần xác nhận${g.work_records_to_review.overdue ? ` (${g.work_records_to_review.overdue} quá hạn)` : ''}`, '/work?tab=records&scope=review', 'warn', 'record'],
    [g.leaves_to_approve, 'Đơn nghỉ cần duyệt', '/work?tab=leaves&scope=approve', 'warn', 'leave'],
    [g.members_pending_hr, 'Thành viên chờ nhân sự duyệt', '/admin/members', 'warn', 'userCog'],
    [g.appeals_to_resolve, 'Khiếu nại cần giải quyết', '/work?tab=records&scope=review', 'warn', 'warn'],
    [g.reports_holding.n, `Trở ngại đang giữ${g.reports_holding.near_due ? ` · ${g.reports_holding.near_due} gần hạn` : ''}`, '/reports?scope=handling', 'attn', 'alert'],
    [g.reports_holding.overdue, 'Trở ngại quá SLA', '/reports?scope=handling', 'warn', 'alert'],
    [g.escalations_open, 'Chuyển cấp đến tôi', '/escalations', 'warn', 'promote'],
    [mgr ? g.team_tasks.overdue : 0, 'Việc nhóm quá hạn', '/work?tab=tasks&overdue=true', 'warn', 'clock'],
  ] as Tile[]).filter((t) => t[0] > 0);
}

/** Công việc › Tổng quan: "Cần tôi xử lý" — gộp việc cần duyệt/xác nhận và nhắc nhở đơn hàng. */
export function TodoPanel({ go }: { go: (s: string) => void }) {
  const { me } = useAuth();
  const mgr = isManagerRole(me?.role) || me?.role === 'reviewer';
  const d = useLoad(() => get('/dashboard'), []);
  const o = useLoad(() => get('/dash/order-alerts'), []);
  const manage = d.data ? manageTilesOf(d.data.manage, mgr) : [];
  const a = o.data || {};
  const orders: Tile[] = ([
    [a.overdue || 0, 'Đơn hàng quá hạn', '/chains', 'warn', 'route'],
    [a.at_risk || 0, 'Đơn hàng có rủi ro', '/chains', 'attn', 'alert'],
    [a.bottlenecks || 0, 'Công đoạn đang nghẽn', '/chains', 'warn', 'layers'],
    [a.due_soon || 0, 'Đơn hàng đến hạn trong 3 ngày', '/chains', 'attn', 'timer'],
    [a.pending_approval || 0, 'Đơn hàng chờ duyệt', '/work?s=tasks&status=pending_approval', 'warn', 'ok'],
  ] as Tile[]).filter((t) => t[0] > 0);
  const totalTodo = manage.reduce((s, t) => s + t[0], 0);
  return (
    <>
      <div className="section-title">Cần tôi xử lý</div>
      <div className="stats">
        <Stat t={[a.running || 0, 'Đơn hàng đang chạy', '/chains', undefined, 'route']} />
        <Stat t={[totalTodo, 'Hồ sơ cần xử lý', '', totalTodo ? 'attn' : undefined, 'ok']} onClick={() => go('todo')} />
        {orders.map((t) => <Stat key={t[1]} t={t} />)}
        {manage.map((t) => <Stat key={t[1]} t={t} />)}
      </div>
      {d.data && o.data && !orders.length && !manage.length && <div className="empty small">Không có mục nào cần bạn xử lý lúc này</div>}
    </>
  );
}

/** Trang chủ: thống kê nhân sự – công việc – phòng ban (phạm vi theo quyền). */
export function StatsPanel() {
  const { data: s } = useLoad(() => get('/dash/home-stats'), []);
  if (!s || s.scope === 'none') return null;
  const p = s.people; const t = s.tasks; const d = s.departments;
  const max = Math.max(1, ...d.top.map((x: any) => x.open));
  return (
    <>
      <div className="row" style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
        <div className="section-title" style={{ flex: 1 }}>Thống kê {s.scope === 'company' ? 'công ty' : 'phạm vi phụ trách'}</div>
        <Link to="/team" className="btn sm"><Icon name="calendar" size={16} />Tình trạng nhân sự tuần</Link>
      </div>
      <div className="stat-group"><Icon name="users" size={15} />Nhân sự</div>
      <div className="stats">
        <Stat t={[p.total, 'Đang làm việc tại công ty', '/admin/members', undefined, 'users']} />
        <Stat t={[p.working, 'Đang trong phiên làm việc', '/team-live', undefined, 'timer']} />
        <Stat t={[p.on_leave, 'Nghỉ hôm nay', '/team', p.on_leave ? 'attn' : undefined, 'leave']} />
        {s.scope === 'company' ? <Stat t={[p.pending_hr, 'Chờ nhân sự duyệt', '/admin/members', p.pending_hr ? 'warn' : undefined, 'userCog']} />
          : <Stat t={[p.new_month, 'Mới trong tháng', '/admin/members', undefined, 'assign']} />}
      </div>
      <div className="stat-group"><Icon name="tasks" size={15} />Công việc</div>
      <div className="stats">
        <Stat t={[t.open, 'Đang mở', '/work?s=tasks', undefined, 'tasks']} />
        <Stat t={[t.overdue, 'Quá hạn', '/work?s=tasks&overdue=true', 'warn', 'clock']} />
        <Stat t={[t.due_today, 'Đến hạn hôm nay', '/work?s=tasks', 'attn', 'timer']} />
        <Stat t={[t.done_week, 'Hoàn thành tuần này', '/work?s=tasks&status=completed', undefined, 'ok']} />
      </div>
      <div className="stat-group"><Icon name="company" size={15} />Phòng ban · {d.count}{d.with_overdue ? <span className="badge red" style={{ marginLeft: 6 }}>{d.with_overdue} có việc quá hạn</span> : null}</div>
      <div className="card dept-bars">
        {d.top.map((x: any) => (
          <div key={x.id} className="dept-bar">
            <span className="dn ellipsis">{x.name}</span>
            <span className="track"><span className="open" style={{ width: `${(x.open / max) * 100}%` }} /><span className="over" style={{ width: `${(x.overdue / max) * 100}%` }} /></span>
            <span className="dv">{x.open}{x.overdue ? <b> · {x.overdue}</b> : ''}</span>
            <span className="dm small muted"><Icon name="users" size={12} />{x.members}</span>
          </div>
        ))}
        {!d.top.length && <div className="small muted">Chưa có phòng ban</div>}
        <div className="legend small muted"><span className="lg open" />Việc đang mở <span className="lg over" />Quá hạn</div>
      </div>
    </>
  );
}
