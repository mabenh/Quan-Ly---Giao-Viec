import { useState } from 'react';
import { Link, useNavigate, useParams, useSearchParams } from 'react-router-dom';
import { get, post } from '../api';
import { tierOf, useAuth } from '../auth';
import { Badge, Card, Empty, ErrorBox, Field, Header, KV, Loading, Select, useAction, useLoad, Note } from '../ui';
import { Icon } from '../icons';
import { fmtDT } from '../labels';

export const MR_CATEGORY: Record<string, string> = {
  falsified_result: 'Gian dối về kết quả', left_post: 'Tự ý rời vị trí công việc', attire: 'Không đúng tác phong – trang phục',
  food_in_production: 'Mang đồ ăn – thức uống vào khu vực sản xuất', support_unrecorded: 'Hỗ trợ không được ghi nhận', safety: 'Vi phạm an toàn', other: 'Khác',
};
const ST: Record<string, [string, string]> = { open: ['Chờ xử lý', 'amber'], resolved: ['Đã kết luận', 'green'], dismissed: ['Không xác nhận', 'gray'] };

/** Gửi báo cáo / phản ánh về nhiệm vụ, công việc trong nhóm/phòng — công khai tên hoặc ẩn danh hoàn toàn. */
export function MemberReportForm() {
  const nav = useNavigate();
  const [sp] = useSearchParams();
  const taskId = sp.get('taskId') || '';
  const task = useLoad(() => (taskId ? get(`/tasks/${taskId}`) : Promise.resolve(null)), [taskId]);
  const groups = useLoad(() => get('/groups'), []);
  const [f, setF] = useState({ category: sp.get('category') || 'left_post', description: '', anonymous: true, groupId: '' });
  const [done, setDone] = useState<any>(null);
  const a = useAction();
  if (done) return (
    <>
      <Header title="Đã gửi phản ánh" back />
      <div className="page">
        <div className="alert ok">{done.message}</div>
        {done.count > 1 && <p className="small">Đã có {done.count} người phản ánh cùng nội dung này.</p>}
        <button className="btn block" onClick={() => nav(-1)}>Quay lại</button>
      </div>
    </>
  );
  return (
    <>
      <Header title="Báo cáo / phản ánh" back />
      <div className="page">
        {task.data && <div className="alert info small">Về nhiệm vụ <b>{task.data.code} - {task.data.title}</b> · người phụ trách {task.data.owner_name}</div>}
        <Field label="Lý do phản ánh" required><Select value={f.category} onChange={(v) => setF({ ...f, category: v })} options={MR_CATEGORY} /></Field>
        {f.category === 'support_unrecorded' && !taskId && <div className="alert warn small">Mở nhiệm vụ bạn đã hỗ trợ rồi bấm "Báo cáo / phản ánh" để chọn đúng nhiệm vụ.</div>}
        {!taskId && <Field label="Nhóm / công việc trong nhóm"><Select value={f.groupId} onChange={(v) => setF({ ...f, groupId: v })} options={(groups.data || []).map((g: any) => [g.id, g.name])} placeholder="— Nhóm của tôi —" /></Field>}
        <Field label="Nội dung (thời gian, địa điểm, sự việc)" required><textarea value={f.description} onChange={(e) => setF({ ...f, description: e.target.value })} placeholder="VD: Khoảng 10h, ca sáng rời vị trí máy đóng gói 40 phút không báo trưởng ca" /></Field>
        <div className="seg">
          <button className={f.anonymous ? 'on' : ''} onClick={() => setF({ ...f, anonymous: true })}>Ẩn danh</button>
          <button className={!f.anonymous ? 'on' : ''} onClick={() => setF({ ...f, anonymous: false })}>Công bố tên</button>
        </div>
        <Note>{f.anonymous ? 'Ẩn danh hoàn toàn: hệ thống KHÔNG lưu danh tính của bạn — cả người phụ trách và quản lý đều không thấy tên. Bạn sẽ không nhận được kết quả xử lý qua thông báo.' : 'Người phụ trách thấy tên bạn và bạn nhận được thông báo khi có kết luận.'} Phản ánh được gửi tới người phụ trách (trưởng phòng/tầng 5) kèm thời gian và nội dung.</Note>
        <ErrorBox error={a.error} />
        <button className="btn primary block" disabled={a.busy || f.description.trim().length < 10} onClick={() => a.run(async () => {
          setDone(await post('/member-reports', { taskId: taskId || undefined, groupId: f.groupId || undefined, category: f.category, description: f.description, anonymous: f.anonymous }));
        })}><Icon name="shield" size={18} />Gửi phản ánh</button>
      </div>
    </>
  );
}

/** Danh sách hồ sơ phản ánh (Cần xử lý › Báo cáo). */
export function MemberReportList() {
  const { me } = useAuth();
  const lead = tierOf(me) <= 5;
  const [scope, setScope] = useState(lead ? 'handling' : 'mine');
  const { data, error, loading } = useLoad(() => get(`/member-reports?scope=${scope}`), [scope]);
  return (
    <>
      <div className="quick"><Link className="btn primary" to="/member-reports/new"><Icon name="shield" size={18} />Gửi phản ánh</Link><span /></div>
      {lead && <div className="seg"><button className={scope === 'handling' ? 'on' : ''} onClick={() => setScope('handling')}>Tôi phụ trách</button><button className={scope === 'mine' ? 'on' : ''} onClick={() => setScope('mine')}>Tôi gửi (công khai tên)</button>{tierOf(me) <= 4 && <button className={scope === 'all' ? 'on' : ''} onClick={() => setScope('all')}>Toàn đơn vị</button>}</div>}
      <Note>{scope === 'handling' ? 'Phản ánh về công việc trong phòng/nhóm bạn phụ trách. Người báo ẩn danh không hiển thị tên. Nếu kết luận có ảnh hưởng tiến độ/chất lượng, hồ sơ được đưa vào dòng thời gian của nhiệm vụ.' : 'Phản ánh bạn gửi công khai tên. Phản ánh ẩn danh không thể tra lại.'}</Note>
      <ErrorBox error={error} />{loading && !data && <Loading />}
      {data && data.length === 0 && <Empty>Không có phản ánh</Empty>}
      {data?.map((c: any) => (
        <Card key={c.id} to={`/member-reports/${c.id}`} className={c.status === 'open' ? 'pinned' : ''}>
          <div className="row"><b style={{ flex: 1 }}>{c.code} · {c.category_label}</b><Badge tone={ST[c.status][1]}>{ST[c.status][0]}</Badge></div>
          <div className="small">{c.task_title ? `${c.task_code} - ${c.task_title}` : c.group_name || 'Công việc trong nhóm'}{c.task_owner_name ? ` · phụ trách: ${c.task_owner_name}` : ''}</div>
          <div className="small muted">{c.reporter_count} người báo cáo{c.anonymous_count ? ` (${c.anonymous_count} ẩn danh)` : ''} · gần nhất {fmtDT(c.last_reported_at)} · xử lý: {c.handler_name || '—'}</div>
        </Card>
      ))}
    </>
  );
}

export function MemberReportDetail() {
  const { id } = useParams();
  const { data: c, error, setData } = useLoad(() => get(`/member-reports/${id}`), [id]);
  const a = useAction();
  const [f, setF] = useState({ conclusion: '', actionTaken: '', affectsProgress: false, affectsQuality: false });
  if (!c) return <><Header title="Phản ánh" back /><div className="page"><ErrorBox error={error} />{!error && <Loading />}</div></>;
  return (
    <>
      <Header title={c.code} back />
      <div className="page">
        <h2>{c.category_label}</h2>
        <div className="chip-row"><Badge tone={ST[c.status][1]}>{ST[c.status][0]}</Badge><span className="small">{c.reporter_count} người báo cáo{c.anonymous_count ? ` · ${c.anonymous_count} ẩn danh` : ''}</span></div>
        <Card>
          <KV k="Công việc" v={c.task_title ? `${c.task_code} - ${c.task_title}` : c.group_name || '—'} />
          {c.task_owner_name && <KV k="Người phụ trách công việc" v={c.task_owner_name} />}
          <KV k="Người xử lý phản ánh" v={c.handler_name || '—'} />
          <KV k="Phòng ban" v={c.department_name || '—'} />
        </Card>
        <div className="section-title">Nội dung phản ánh</div>
        {c.reports.map((r: any) => (
          <Card key={r.id}><div className="small muted">{r.reporter_name || 'Ẩn danh'} · {fmtDT(r.created_at)}</div><div>{r.description}</div></Card>
        ))}
        {c.status !== 'open' && <Card><KV k="Kết luận" v={c.conclusion} />{c.action_taken && <KV k="Cách xử lý" v={c.action_taken} />}<KV k="Ảnh hưởng" v={[c.affects_progress && 'Tiến độ', c.affects_quality && 'Chất lượng'].filter(Boolean).join(', ') || 'Không'} /><KV k="Người kết luận" v={`${c.resolved_by_name} · ${fmtDT(c.resolved_at)}`} /></Card>}
        {c.permissions.can_resolve && (
          <Card>
            <b>Kết luận phản ánh</b>
            <Field label="Kết luận" required><textarea value={f.conclusion} onChange={(e) => setF({ ...f, conclusion: e.target.value })} /></Field>
            <Field label="Cách xử lý"><textarea value={f.actionTaken} onChange={(e) => setF({ ...f, actionTaken: e.target.value })} /></Field>
            <label className="check"><input type="checkbox" checked={f.affectsProgress} onChange={(e) => setF({ ...f, affectsProgress: e.target.checked })} /> Có ảnh hưởng tiến độ công việc</label>
            <label className="check"><input type="checkbox" checked={f.affectsQuality} onChange={(e) => setF({ ...f, affectsQuality: e.target.checked })} /> Có ảnh hưởng chất lượng công việc</label>
            <Note>Có ảnh hưởng → hồ sơ được đưa vào dòng thời gian/thống kê của nhiệm vụ.</Note>
            <div className="actions">
              <button className="btn primary" disabled={a.busy || f.conclusion.trim().length < 5} onClick={() => a.run(async () => setData(await post(`/member-reports/${id}/resolve`, { decision: 'resolved', ...f, actionTaken: f.actionTaken || undefined })))}>Xác nhận & kết luận</button>
              <button className="btn" disabled={a.busy || f.conclusion.trim().length < 5} onClick={() => a.run(async () => setData(await post(`/member-reports/${id}/resolve`, { decision: 'dismissed', conclusion: f.conclusion })))}>Không xác nhận</button>
            </div>
          </Card>
        )}
        <ErrorBox error={a.error} />
      </div>
    </>
  );
}
