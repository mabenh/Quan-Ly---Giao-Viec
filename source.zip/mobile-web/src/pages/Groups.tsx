import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { get, post } from '../api';
import { isAdminRole, isManagerRole, tierOf, useAuth } from '../auth';
import { Badge, Card, Empty, ErrorBox, Field, Loading, Select, Sheet, useAction, useLoad } from '../ui';
import { Icon } from '../icons';

export default function Groups() {
  const { me } = useAuth();
  const nav = useNavigate();
  const { data, error, loading } = useLoad(() => get('/groups'), []);
  const [open, setOpen] = useState(false);
  return (
    <div className="page">
      <div className="row" style={{ display: 'flex', alignItems: 'center' }}>
        <h1 style={{ flex: 1 }}>Nhóm</h1>
        {(isManagerRole(me?.role) || tierOf(me) <= 5) && <button className="btn primary sm" onClick={() => setOpen(true)}><Icon name="plus" size={16} />Tạo nhóm</button>}
      </div>
      <ErrorBox error={error} />
      {loading && !data && <Loading />}
      {data && data.length === 0 && <Empty>Bạn chưa thuộc nhóm nào</Empty>}
      {data?.map((g: any) => (
        <Card key={g.id} to={`/groups/${g.id}`}>
          <div className="row"><span className="title" style={{ flex: 1 }}>{g.name}</span>{g.is_manager && <Badge tone="blue">Bạn quản lý</Badge>}</div>
          <div className="small muted">Quản lý: {g.manager_name} · {g.member_count} thành viên</div>
          <div className="chip-row"><Badge tone="gray">{g.open_tasks} việc đang mở</Badge>{g.overdue_tasks > 0 && <Badge tone="red">{g.overdue_tasks} quá hạn</Badge>}</div>
        </Card>
      ))}
      <Sheet open={open} onClose={() => setOpen(false)} title="Tạo nhóm mới"><CreateGroup onDone={(id) => nav(`/groups/${id}`)} top={isAdminRole(me?.role) || tierOf(me) <= 4} myDept={me?.authority?.department_id || null} myDeptName={me?.authority?.department || ''} /></Sheet>
    </div>
  );
}

/**
 * Tạo nhóm (v10): tầng 3–4 chọn phòng ban trước (tự lọc thành viên của phòng), rồi chọn người quản lý và thành viên.
 * Tầng 5 mặc định phòng ban của mình, chỉ chọn người quản lý và thành viên.
 */
function CreateGroup({ onDone, top, myDept, myDeptName }: { onDone: (id: string) => void; top: boolean; myDept: string | null; myDeptName: string }) {
  const members = useLoad(() => get('/company/members'), []);
  const depts = useLoad(() => (top ? get('/company/departments') : Promise.resolve([])), [top]);
  const [dept, setDept] = useState(top ? '' : myDept || '');
  const [name, setName] = useState(''); const [desc, setDesc] = useState(''); const [mgr, setMgr] = useState(''); const [ids, setIds] = useState<string[]>([]);
  const a = useAction();
  const active = (members.data || []).filter((m: any) => m.status === 'active' && (!dept || m.department_id === dept || (!top && !m.department_id)));
  const ready = !top || !!dept;
  return (
    <>
      <Field label="Phòng ban" required>
        {top ? <Select value={dept} onChange={(v) => { setDept(v); setMgr(''); setIds([]); }} options={(depts.data || []).map((d: any) => [d.id, d.name])} placeholder="— Chọn phòng ban trước —" />
          : <input value={myDeptName || 'Phòng ban của tôi'} disabled />}
      </Field>
      <Field label="Tên nhóm" required><input value={name} onChange={(e) => setName(e.target.value)} /></Field>
      <Field label="Mô tả"><textarea value={desc} onChange={(e) => setDesc(e.target.value)} /></Field>
      {ready && <>
        <Field label="Người quản lý nhóm" hint="Mặc định là bạn"><Select value={mgr} onChange={(v) => { setMgr(v); setIds(ids.filter((x) => x !== v)); }} options={active.filter((m: any) => (m.tier ?? 7) <= 6 || ['manager', 'admin', 'owner', 'hr'].includes(m.role)).map((m: any) => [m.id, `${m.name}${m.position_name ? ` (${m.position_name})` : ''}`])} placeholder="— Tôi —" /></Field>
        <Field label={`Thành viên (${ids.length})`} hint={dept ? 'Đã lọc theo phòng ban' : undefined}>
          <div style={{ maxHeight: 240, overflowY: 'auto' }}>
            {active.filter((m: any) => m.id !== mgr).map((m: any) => (
              <label key={m.id} className="check"><input type="checkbox" checked={ids.includes(m.id)} onChange={(e) => setIds(e.target.checked ? [...ids, m.id] : ids.filter((x) => x !== m.id))} />{m.name} <span className="muted small">{m.position_name || m.title}</span></label>
            ))}
            {active.length === 0 && <div className="small muted">Phòng ban chưa có thành viên</div>}
          </div>
        </Field>
      </>}
      <ErrorBox error={a.error} />
      <button className="btn primary block" disabled={a.busy || !ready || name.trim().length < 2} onClick={() => a.run(async () => { const g = await post('/groups', { name, description: desc || undefined, managerMemberId: mgr || undefined, memberIds: ids, departmentId: dept || undefined }); onDone(g.id); })}>Tạo nhóm</button>
    </>
  );
}
