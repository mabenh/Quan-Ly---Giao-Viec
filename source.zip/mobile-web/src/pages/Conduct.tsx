import { useEffect, useState } from 'react';
import { Link, useNavigate, useParams, useSearchParams } from 'react-router-dom';
import { get, post, upload } from '../api';
import { isAdminRole, isHRRole, useAuth } from '../auth';
import { Badge, Card, Empty, ErrorBox, Field, Header, KV, Loading, Select, Sheet, Tabs, useAction, useLoad, Note } from '../ui';
import { AUDIT_ACTION, fmtDT, toLocalInput, fromLocalInput } from '../labels';
import { Files } from './TaskDetail';
import { Icon } from '../icons';

export const CATEGORY: Record<string, [string, string]> = {
  harassment: ['Quấy rối, xúc phạm hoặc đe dọa', 'Lời nói, tin nhắn, hành vi gây tổn thương, đe dọa, liên lạc lặp lại không mong muốn'],
  privacy_data: ['Quyền riêng tư / dữ liệu cá nhân', 'Xem, sao chép, chia sẻ hoặc dùng thông tin cá nhân không đúng'],
  power_abuse: ['Lạm dụng quyền hoặc trả đũa', 'Dùng công việc/đánh giá để gây áp lực, trả đũa vì đã báo cáo'],
  other: ['Nội dung khác', 'Hành vi khác cần được xem xét'],
  not_sure: ['Tôi không chắc', 'Bạn không cần tự phân loại — người xử lý sẽ giúp'],
};
export const SUBCODE: Record<string, [string, string][]> = {
  harassment: [['HAR-01', 'Lời nói xúc phạm, hạ nhục'], ['HAR-02', 'Đe dọa, uy hiếp'], ['HAR-03', 'Liên lạc lặp lại sau khi đã yêu cầu dừng'], ['HAR-04', 'Nội dung/hành vi tình dục không mong muốn'], ['HAR-05', 'Theo dõi, xâm nhập đời tư'], ['HAR-06', 'Phân biệt đối xử, làm nhục'], ['HAR-07', 'Ép buộc, gây áp lực']],
  power_abuse: [['POW-01', 'Xem dữ liệu ngoài phạm vi quản lý'], ['POW-02', 'Dùng nhiệm vụ/hạn chót để gây áp lực'], ['POW-03', 'Bất lợi vì đã báo cáo/làm chứng'], ['POW-04', 'Ép rút hoặc sửa báo cáo'], ['POW-05', 'Sửa/làm sai lịch sử công việc']],
  privacy_data: [['DAT-01', 'Truy cập dữ liệu không có quyền'], ['DAT-02', 'Thu thập hàng loạt'], ['DAT-03', 'Sao chép/chia sẻ trái phép'], ['DAT-04', 'Dùng thông tin ngoài mục đích'], ['DAT-05', 'Dùng tài khoản người khác'], ['DAT-06', 'Dò tìm thông tin bị ẩn'], ['DAT-07', 'Dùng công cụ tự động thu thập'], ['DAT-08', 'Tiết lộ dữ liệu nhạy cảm']],
};
export const CASE_STATUS: Record<string, [string, string]> = {
  received: ['Đã tiếp nhận', 'blue'], screening: ['Đang sàng lọc', 'blue'], needs_info: ['Cần bổ sung', 'amber'], investigating: ['Đang xác minh', 'blue'],
  resolved: ['Đã có kết quả', 'green'], insufficient: ['Chưa đủ cơ sở', 'gray'], referred: ['Chuyển đơn vị phù hợp', 'purple'], closed: ['Đã đóng', 'gray'], review_requested: ['Xem xét lại', 'amber'],
};
const SEVERITY: Record<string, string> = {
  S0: 'S0 — Chưa đủ cơ sở', S1: 'S1 — Rủi ro thấp', S2: 'S2 — Đáng quan tâm', S3: 'S3 — Nghiêm trọng', S4: 'S4 — Khẩn cấp',
};
const OBJ: Record<string, string> = { task: 'Nhiệm vụ', comment: 'Bình luận', file: 'Tệp', profile: 'Hồ sơ', access_log: 'Lịch sử truy cập', work_record: 'Bản ghi công việc', evaluation: 'Đánh giá', other: 'Khác' };
const EVENT: Record<string, string> = {
  status: 'Trạng thái', info_added: 'Bổ sung thông tin', request_info: 'Đề nghị bổ sung', request_explanation: 'Mời giải trình', explanation: 'Giải trình',
  severity: 'Mức ưu tiên', note_internal: 'Ghi chú nội bộ', retaliation_flag: 'Lo ngại bị trả đũa', retaliation_review: 'Rà soát trả đũa', outcome: 'Kết quả',
  handler: 'Phân công người xử lý', conflict: 'Khai báo xung đột lợi ích', review_request: 'Yêu cầu xem xét lại',
};

export function ConductList() {
  const { me } = useAuth();
  const [sp, setSp] = useSearchParams();
  const tabs: [string, string][] = [['mine', 'Tôi đã gửi'], ['explain', 'Mời tôi giải trình']];
  if (isHRRole(me?.role)) tabs.push(['handling', 'Tôi xử lý']);
  if (isAdminRole(me?.role)) tabs.push(['oversight', 'Sổ theo dõi']);
  const scope = sp.get('scope') || 'mine';
  const { data, error } = useLoad(() => get(`/conduct-cases?scope=${scope}`), [scope]);
  return (
    <>
      <Header title="Báo cáo hành vi" back="/me" right={<Link className="btn sm primary" to="/conduct/new"><Icon name="plus" size={16} />Báo cáo</Link>} />
      <div className="page">
        <Note>Báo cáo hành vi cần xem xét: quấy rối, xâm phạm quyền riêng tư, lạm dụng quyền hoặc trả đũa. Hồ sơ chỉ chia sẻ với người có nhiệm vụ xử lý; gửi báo cáo không tự động kết luận ai vi phạm.</Note>
        <Tabs value={scope} onChange={(v) => setSp({ scope: v }, { replace: true })} tabs={tabs} />
        <ErrorBox error={error} />
        {!data && !error && <Loading />}
        {data && data.length === 0 && <Empty>{scope === 'mine' ? 'Bạn chưa gửi báo cáo nào' : 'Không có hồ sơ'}</Empty>}
        {data?.map((c: any) => (
          <Card key={c.id} to={`/conduct/${c.id}`}>
            <div className="row"><b>{c.code}</b>{c.category && <span className="small muted" style={{ flex: 1 }}> · {CATEGORY[c.category]?.[0]}</span>}{!c.category && <span style={{ flex: 1 }} />}<Badge tone={CASE_STATUS[c.status][1]}>{CASE_STATUS[c.status][0]}</Badge></div>
            <div className="small muted">
              {fmtDT(c.created_at)}{c.severity ? ` · ưu tiên ${c.severity}` : ''}{c.current_risk === 'safety' ? ' · cần ưu tiên an toàn' : ''}{c.retaliation_flag ? ' · lo ngại trả đũa' : ''}
              {c.handler_name ? ` · xử lý: ${c.handler_name}` : ''}{c.stale ? ' · quá 7 ngày chưa có kết quả' : ''}
            </div>
          </Card>
        ))}
      </div>
    </>
  );
}

export function ConductForm() {
  const nav = useNavigate();
  const { me } = useAuth();
  const [sp] = useSearchParams();
  const company = useLoad(() => get('/company'), []);
  const members = useLoad(() => get('/company/members?status=active'), []);
  const [step, setStep] = useState(1);
  const [f, setF] = useState<any>({
    category: sp.get('category') || '', subcode: sp.get('subcode') || '', description: '', occurredAt: toLocalInput(new Date()),
    objectType: sp.get('objectType') || '', objectId: sp.get('objectId') || '', objectLabel: sp.get('objectLabel') || '', reportedMemberId: sp.get('reported') || '',
    currentRisk: 'none', safeContact: '', anonymity: 'to_reported',
  });
  const [file, setFile] = useState<File | null>(null);
  const [done, setDone] = useState<any>(null);
  const a = useAction();
  const up = (p: any) => setF((x: any) => ({ ...x, ...p }));
  const allowAnon = !!company.data?.settings?.privacy?.allowAnonymousToHandler;
  const reportedName = (members.data || []).find((m: any) => m.id === f.reportedMemberId)?.name;
  const ru = sp.get('reportedUser');
  useEffect(() => { if (ru && members.data) { const m = members.data.find((x: any) => x.user_id === ru); if (m) up({ reportedMemberId: m.id }); } }, [ru, members.data]);
  const submit = () => a.run(async () => {
    const r = await post('/conduct-cases', {
      category: f.category, subcode: f.subcode || undefined, description: f.description, occurredAt: fromLocalInput(f.occurredAt),
      objectType: f.objectType || undefined, objectId: f.objectId || undefined, objectLabel: f.objectLabel || undefined, reportedMemberId: f.reportedMemberId || undefined,
      currentRisk: f.currentRisk, safeContact: f.safeContact || undefined, anonymity: f.anonymity,
    });
    if (file) await upload('conduct_case', r.id, file).catch(() => {});
    setDone(r);
  });
  if (done) return (
    <>
      <Header title="Đã gửi báo cáo" back="/conduct" />
      <div className="page">
        <div className="alert ok">{done.message}</div>
        {done.safety && <div className="alert error"><b>Nếu bạn đang gặp nguy hiểm ngay lúc này:</b><div>{done.safety}</div><div className="small">Hồ sơ đã được đánh dấu cần ưu tiên an toàn.</div></div>}
        <p className="small">Bạn có thể theo dõi trạng thái, bổ sung thông tin nếu thấy an toàn, hoặc chọn "Tôi lo ngại bị trả đũa" trong hồ sơ.</p>
        <button className="btn primary block" onClick={() => nav(`/conduct/${done.id}`, { replace: true })}>Xem hồ sơ {done.code}</button>
      </div>
    </>
  );
  return (
    <>
      <Header title={`Báo cáo hành vi cần xem xét · ${step}/4`} back />
      <div className="page">
        {step === 1 && (
          <>
            <Note>Chọn nhóm vấn đề gần nhất. Bạn không cần dùng thuật ngữ pháp lý.</Note>
            {Object.entries(CATEGORY).map(([k, [l, d]]) => (
              <button key={k} className={`pick ${f.category === k ? 'sel' : ''}`} onClick={() => up({ category: k, subcode: '' })} aria-pressed={f.category === k}>
                <div className="main"><b>{l}</b><div className="small muted">{d}</div></div>
              </button>
            ))}
            {SUBCODE[f.category] && (
              <Field label="Cụ thể hơn (không bắt buộc)">
                <Select value={f.subcode} onChange={(v) => up({ subcode: v })} options={SUBCODE[f.category]} placeholder="— Không chọn —" />
              </Field>
            )}
            <button className="btn primary block" disabled={!f.category} onClick={() => setStep(2)}>Tiếp<Icon name="chevron" size={16} /></button>
          </>
        )}
        {step === 2 && (
          <>
            {f.objectLabel && <div className="alert info small">Đã gắn: {OBJ[f.objectType] || 'Nội dung'} — {f.objectLabel}</div>}
            <Field label="Chuyện gì đã xảy ra?" required hint="Ngắn gọn: chuyện gì, khi nào, ảnh hưởng ra sao. Không cần kể chi tiết nhạy cảm không cần thiết.">
              <textarea rows={5} value={f.description} onChange={(e) => up({ description: e.target.value })} />
            </Field>
            <Field label="Thời điểm (có thể sửa)"><input type="datetime-local" value={f.occurredAt} onChange={(e) => up({ occurredAt: e.target.value })} /></Field>
            <Field label="Người được báo cáo (không bắt buộc)">
              <Select value={f.reportedMemberId} onChange={(v) => up({ reportedMemberId: v })} options={(members.data || []).filter((m: any) => m.id !== me?.member_id).map((m: any) => [m.id, m.name])} placeholder="— Không chọn / không rõ —" />
            </Field>
            <Field label="Bằng chứng (không bắt buộc)" hint="Ảnh chụp, tệp… Hãy che thông tin của người khác không liên quan. Bạn có thể bổ sung sau.">
              <input type="file" accept="image/*,application/pdf,video/*,audio/*" onChange={(e) => setFile(e.target.files?.[0] || null)} />
            </Field>
            <div className="actions"><button className="btn" onClick={() => setStep(1)}><Icon name="back" size={16} />Quay lại</button><button className="btn primary" style={{ flex: 1 }} disabled={f.description.trim().length < 10} onClick={() => setStep(3)}>Tiếp<Icon name="chevron" size={16} /></button></div>
          </>
        )}
        {step === 3 && (
          <>
            <Field label="Bạn có đang lo ngại về an toàn hoặc bị trả đũa ngay lúc này không?">
              <Select value={f.currentRisk} onChange={(v) => up({ currentRisk: v })} options={{ none: 'Không', retaliation: 'Tôi lo ngại bị trả đũa', safety: 'Tôi lo ngại về an toàn của mình' }} />
            </Field>
            {f.currentRisk === 'safety' && <div className="alert error small">Nếu nguy hiểm đang diễn ra, hãy gọi ngay Công an 113 / Cấp cứu 115 hoặc bảo vệ công ty. Hồ sơ sẽ được ưu tiên.</div>}
            <Field label="Cách liên hệ an toàn với bạn (không bắt buộc)" hint="Ví dụ: chỉ nhắn trong ứng dụng, sau 17h. Thông báo không hiển thị nội dung báo cáo.">
              <input value={f.safeContact} onChange={(e) => up({ safeContact: e.target.value })} />
            </Field>
            <Field label="Ẩn danh">
              <Select value={f.anonymity} onChange={(v) => up({ anonymity: v })} options={allowAnon ? { to_reported: 'Ẩn danh với người được báo cáo', to_handler: 'Ẩn danh với cả người xử lý' } : { to_reported: 'Ẩn danh với người được báo cáo' }} />
            </Field>
            <Note>Danh tính của bạn không được tiết lộ cho người được báo cáo. {f.anonymity === 'to_handler' ? 'Người xử lý cũng không thấy tên bạn, nhưng có thể khó liên hệ để hỏi thêm. ' : 'Người xử lý biết bạn là ai để có thể hỏi thêm khi cần. '}Lưu ý: nội dung, vai trò hoặc bằng chứng vẫn có thể khiến người khác đoán ra — chúng tôi không thể hứa ẩn danh tuyệt đối.</Note>
            <div className="actions"><button className="btn" onClick={() => setStep(2)}><Icon name="back" size={16} />Quay lại</button><button className="btn primary" style={{ flex: 1 }} onClick={() => setStep(4)}>Tiếp<Icon name="chevron" size={16} /></button></div>
          </>
        )}
        {step === 4 && (
          <>
            <Card>
              <KV k="Nhóm vấn đề" v={CATEGORY[f.category][0]} />
              {f.subcode && <KV k="Cụ thể" v={SUBCODE[f.category]?.find((x) => x[0] === f.subcode)?.[1]} />}
              <KV k="Người được báo cáo" v={reportedName || '—'} />
              <KV k="Bằng chứng" v={file ? file.name : 'Không'} />
              <div className="crit small" style={{ marginTop: 6 }}>{f.description}</div>
            </Card>
            <div className="alert info small">
              Báo cáo của bạn sẽ được chuyển tới người có nhiệm vụ xử lý — không mặc định chuyển cho quản lý trực tiếp nếu người đó có liên quan. Việc gửi báo cáo không tự động kết luận người được báo cáo vi phạm.
              Người được báo cáo chỉ được biết nội dung đủ để giải trình khi người xử lý mời, không thấy danh tính của bạn hay bằng chứng.
            </div>
            <ErrorBox error={a.error} />
            <div className="actions"><button className="btn" onClick={() => setStep(3)}><Icon name="back" size={16} />Quay lại</button><button className="btn primary" style={{ flex: 1 }} disabled={a.busy} onClick={submit}>{a.busy ? 'Đang gửi…' : 'Gửi báo cáo'}</button></div>
          </>
        )}
      </div>
    </>
  );
}

export function ConductDetail() {
  const { id } = useParams();
  const nav = useNavigate();
  const { data: c, error, reload, setData } = useLoad(() => get(`/conduct-cases/${id}`), [id]);
  const [sheet, setSheet] = useState<string | null>(null);
  const a = useAction();
  const act = (fn: () => Promise<any>) => a.run(async () => { const r = await fn(); if (r?.id) setData(r); else await reload(); setSheet(null); });
  if (!c) return <><Header title="Hồ sơ" back="/conduct" /><div className="page"><ErrorBox error={error} />{!error && <Loading />}</div></>;
  const st = CASE_STATUS[c.status];
  const timeline = (c.events || []).map((e: any, i: number) => (
    <li key={i} className={e.kind === 'retaliation_flag' || e.kind === 'conflict' ? 'amber' : e.kind === 'outcome' ? 'green' : ''}>
      <div className="small"><b>{EVENT[e.kind] || e.kind}</b>{e.actor ? ` · ${e.actor}` : e.mine ? ' · Bạn' : ''}{e.visibility === 'handler' ? ' · nội bộ' : ''}</div>
      {e.body && <div className="small crit">{e.body}</div>}
      <div className="small muted">{fmtDT(e.created_at)}</div>
    </li>
  ));
  return (
    <>
      <Header title={c.code} back="/conduct" />
      <div className="page">
        <div className="chip-row"><Badge tone={st[1]}>{st[0]}</Badge>{c.severity && <Badge tone="gray">Ưu tiên {c.severity}</Badge>}{c.retaliation_flag && <Badge tone="amber">Lo ngại trả đũa</Badge>}{c.current_risk === 'safety' && <Badge tone="red">Cần ưu tiên an toàn</Badge>}</div>
        {c.status_message && c.my_role !== 'handler' && <div className="alert info small">{c.status_message}</div>}
        {c.note && <div className="alert warn small">{c.note}</div>}
        <ErrorBox error={a.error} />

        {c.my_role === 'oversight' && (
          <>
            <Card><KV k="Nhóm vấn đề" v={CATEGORY[c.category]?.[0]} /><KV k="Người xử lý" v={c.handler_name || '—'} /><KV k="Tạo lúc" v={fmtDT(c.created_at)} /><KV k="Cập nhật" v={fmtDT(c.updated_at)} /></Card>
            <button className="btn" onClick={() => setSheet('reassign')}>Phân công lại người xử lý</button>
          </>
        )}

        {c.my_role === 'reported' && (
          <>
            <div className="section-title">Nội dung cần giải trình</div>
            <Card><div className="crit">{c.explanation_summary}</div></Card>
            {c.outcome && <Card><b>Kết quả</b><div className="small crit">{c.outcome}</div></Card>}
            <div className="actions">
              {c.can_explain && <button className="btn primary" onClick={() => setSheet('explain')}>Gửi giải trình</button>}
              {c.can_request_review && <button className="btn" onClick={() => setSheet('review')}>Yêu cầu xem xét lại</button>}
            </div>
            <Files parentType="conduct_case" parentId={c.id} files={c.files} onDone={reload} canUpload={c.can_explain} />
          </>
        )}

        {c.my_role === 'reporter' && (
          <>
            <Card>
              <KV k="Nhóm vấn đề" v={`${CATEGORY[c.category]?.[0]}${c.subcode ? ` · ${c.subcode}` : ''}`} />
              {c.object_label && <KV k="Nội dung liên quan" v={c.object_label} />}
              <KV k="Người được báo cáo" v={c.reported_name || '—'} />
              <KV k="Người xử lý" v={c.handler_label} />
              <KV k="Ẩn danh" v={c.anonymity === 'to_handler' ? 'Với cả người xử lý' : 'Với người được báo cáo'} />
              <div className="crit small" style={{ marginTop: 6 }}>{c.description}</div>
            </Card>
            {c.outcome && <Card><b>Kết quả</b><div className="small crit">{c.outcome}</div></Card>}
            <div className="actions">
              {c.can_add_info && <button className="btn primary" onClick={() => setSheet('info')}>Bổ sung thông tin</button>}
              {!c.retaliation_flag && c.status !== 'closed' && <button className="btn" onClick={() => setSheet('retaliation')}>Tôi lo ngại bị trả đũa</button>}
              {c.can_request_review && <button className="btn" onClick={() => setSheet('review')}>Yêu cầu xem xét lại</button>}
            </div>
            <Files parentType="conduct_case" parentId={c.id} files={c.files} onDone={reload} canUpload={c.can_add_info} />
          </>
        )}

        {c.my_role === 'handler' && (
          <>
            <Card>
              <KV k="Nhóm vấn đề" v={`${CATEGORY[c.category]?.[0]}${c.subcode ? ` · ${c.subcode}` : ''}`} />
              <KV k="Người báo cáo" v={c.anonymous ? 'Ẩn danh' : c.reporter_name} />
              <KV k="Người được báo cáo" v={c.reported_name || '—'} />
              {c.object_label && <KV k="Nội dung liên quan" v={c.object_type === 'task' && c.object_id ? <Link to={`/tasks/${c.object_id}`}>{c.object_label}</Link> : c.object_label} />}
              <KV k="Thời điểm" v={fmtDT(c.occurred_at)} />
              {c.safe_contact && <KV k="Liên hệ an toàn" v={c.safe_contact} />}
              <div className="crit small" style={{ marginTop: 6 }}>{c.description}</div>
            </Card>
            <div className="actions">
              {['received', 'needs_info', 'review_requested'].includes(c.status) && <button className="btn" disabled={a.busy} onClick={() => act(() => post(`/conduct-cases/${id}/handle`, { action: 'screening' }))}>Bắt đầu sàng lọc</button>}
              {!['investigating', 'closed'].includes(c.status) && <button className="btn" disabled={a.busy} onClick={() => act(() => post(`/conduct-cases/${id}/handle`, { action: 'investigating' }))}>Chuyển sang xác minh</button>}
              {c.status !== 'closed' && <>
                <button className="btn" onClick={() => setSheet('request_info')}>Đề nghị bổ sung</button>
                {c.reported_member_id && <button className="btn" onClick={() => setSheet('request_explanation')}>Mời giải trình</button>}
                <button className="btn" onClick={() => setSheet('severity')}>Mức ưu tiên</button>
                <button className="btn" onClick={() => setSheet('note')}>Ghi chú nội bộ</button>
                <button className="btn primary" onClick={() => setSheet('outcome')}>Kết quả</button>
                <button className="btn danger" onClick={() => setSheet('conflict')}>Tôi có xung đột lợi ích</button>
              </>}
            </div>
            {c.related_changes?.length > 0 && (
              <>
                <div className="section-title">Thay đổi liên quan người báo cáo sau thời điểm báo cáo (rà soát trả đũa)</div>
                <Note>Do người được báo cáo thực hiện. Chỉ để rà soát — có thể là hoạt động quản lý bình thường; không tự động đảo ngược quyết định.</Note>
                {c.related_changes.map((x: any, i: number) => (
                  <Card key={i} to={x.entity_type === 'task' ? `/tasks/${x.entity_id}` : undefined}>
                    <div className="small"><b>{AUDIT_ACTION[x.action] || x.action}</b> · {x.title || x.entity_type} · {fmtDT(x.created_at)}</div>
                    {x.reason && <div className="small muted">Lý do ghi nhận: {x.reason}</div>}
                  </Card>
                ))}
              </>
            )}
            <Files parentType="conduct_case" parentId={c.id} files={c.files} onDone={reload} canUpload={c.status !== 'closed'} />
          </>
        )}

        {c.my_role !== 'oversight' && <>
          <div className="section-title">Diễn biến hồ sơ</div>
          <ul className="timeline">{timeline}</ul>
        </>}
      </div>

      <Sheet open={sheet === 'info'} onClose={() => setSheet(null)} title="Bổ sung thông tin"><TextForm label="Thông tin bổ sung" hint="Bạn có thể bổ sung nếu thấy an toàn và thuận tiện. Không bắt buộc cung cấp dữ liệu không liên quan." cta="Gửi" busy={a.busy} error={a.error} onSubmit={(t) => act(() => post(`/conduct-cases/${id}/info`, { body: t }))} /></Sheet>
      <Sheet open={sheet === 'retaliation'} onClose={() => setSheet(null)} title="Tôi lo ngại bị trả đũa"><TextForm label="Điều gì khiến bạn lo ngại? (không bắt buộc)" min={0} hint="Hồ sơ sẽ được đánh dấu để xem xét riêng; các thay đổi bất thường về công việc, đánh giá, lịch làm của bạn sẽ được rà soát." cta="Gửi" busy={a.busy} error={a.error} onSubmit={(t) => act(() => post(`/conduct-cases/${id}/retaliation`, { body: t || undefined }))} /></Sheet>
      <Sheet open={sheet === 'review'} onClose={() => setSheet(null)} title="Yêu cầu xem xét lại"><TextForm label="Lý do / thông tin mới" hint="Hồ sơ sẽ được chuyển tới người xem xét khác, độc lập với người xử lý trước." cta="Gửi yêu cầu" busy={a.busy} error={a.error} onSubmit={(t) => act(() => post(`/conduct-cases/${id}/review-request`, { reason: t }))} /></Sheet>
      <Sheet open={sheet === 'explain'} onClose={() => setSheet(null)} title="Gửi giải trình"><TextForm label="Nội dung giải trình" hint="Có thể đính kèm tài liệu ở mục Tệp. Vui lòng không liên hệ để gây áp lực với người liên quan." cta="Gửi giải trình" busy={a.busy} error={a.error} onSubmit={(t) => act(() => post(`/conduct-cases/${id}/explanation`, { body: t }))} /></Sheet>
      <Sheet open={sheet === 'request_info'} onClose={() => setSheet(null)} title="Đề nghị người báo cáo bổ sung"><TextForm label="Thông tin cần bổ sung" cta="Gửi" busy={a.busy} error={a.error} onSubmit={(t) => act(() => post(`/conduct-cases/${id}/handle`, { action: 'request_info', message: t }))} /></Sheet>
      <Sheet open={sheet === 'request_explanation'} onClose={() => setSheet(null)} title="Mời người được báo cáo giải trình"><TextForm label="Tóm tắt nội dung cần giải trình" hint="Người được báo cáo chỉ thấy phần tóm tắt này. Không nêu danh tính người báo cáo hoặc chi tiết có thể làm lộ danh tính." cta="Gửi lời mời" busy={a.busy} error={a.error} onSubmit={(t) => act(() => post(`/conduct-cases/${id}/handle`, { action: 'request_explanation', message: t }))} /></Sheet>
      <Sheet open={sheet === 'note'} onClose={() => setSheet(null)} title="Ghi chú nội bộ"><TextForm label="Ghi chú (chỉ người xử lý thấy)" cta="Lưu" busy={a.busy} error={a.error} onSubmit={(t) => act(() => post(`/conduct-cases/${id}/handle`, { action: 'note', message: t }))} /></Sheet>
      <Sheet open={sheet === 'conflict'} onClose={() => setSheet(null)} title="Khai báo xung đột lợi ích"><TextForm label="Lý do" hint="Hồ sơ sẽ được chuyển cho đầu mối khác; bạn sẽ không còn quyền xem." cta="Chuyển hồ sơ" busy={a.busy} error={a.error} onSubmit={(t) => a.run(async () => { await post(`/conduct-cases/${id}/conflict`, { reason: t }); nav('/conduct?scope=handling', { replace: true }); })} /></Sheet>
      <Sheet open={sheet === 'severity'} onClose={() => setSheet(null)} title="Mức ưu tiên xử lý"><SeverityForm cur={c.severity} busy={a.busy} onSubmit={(s, m) => act(() => post(`/conduct-cases/${id}/handle`, { action: 'severity', severity: s, message: m || undefined }))} /></Sheet>
      <Sheet open={sheet === 'outcome'} onClose={() => setSheet(null)} title="Kết quả xử lý"><OutcomeForm busy={a.busy} error={a.error} onSubmit={(b) => act(() => post(`/conduct-cases/${id}/outcome`, b))} /></Sheet>
      <Sheet open={sheet === 'reassign'} onClose={() => setSheet(null)} title="Phân công lại"><ReassignForm busy={a.busy} error={a.error} onSubmit={(b) => act(() => post(`/conduct-cases/${id}/reassign`, b))} /></Sheet>
    </>
  );
}

function TextForm({ label, hint, cta, busy, error, onSubmit, min = 5 }: { label: string; hint?: string; cta: string; busy: boolean; error: string | null; onSubmit: (t: string) => void; min?: number }) {
  const [t, setT] = useState('');
  return (<><Field label={label} hint={hint}><textarea rows={5} value={t} onChange={(e) => setT(e.target.value)} /></Field><ErrorBox error={error} /><button className="btn primary block" disabled={busy || t.trim().length < min} onClick={() => onSubmit(t.trim())}>{cta}</button></>);
}

function SeverityForm({ cur, busy, onSubmit }: { cur?: string; busy: boolean; onSubmit: (s: string, m: string) => void }) {
  const [s, setS] = useState(cur || 'S1'); const [m, setM] = useState('');
  return (
    <>
      <Note>Mức ưu tiên là thứ tự xử lý, không phải kết luận có vi phạm.</Note>
      <Field label="Mức"><Select value={s} onChange={setS} options={SEVERITY} /></Field>
      <Field label="Ghi chú (không bắt buộc)"><input value={m} onChange={(e) => setM(e.target.value)} /></Field>
      <button className="btn primary block" disabled={busy} onClick={() => onSubmit(s, m)}>Lưu</button>
    </>
  );
}

function OutcomeForm({ busy, error, onSubmit }: { busy: boolean; error: string | null; onSubmit: (b: any) => void }) {
  const members = useLoad(() => get('/company/members?status=active'), []);
  const [st, setSt] = useState('resolved'); const [o, setO] = useState(''); const [r, setR] = useState(''); const [to, setTo] = useState('');
  return (
    <>
      <Field label="Kết quả"><Select value={st} onChange={setSt} options={{ resolved: 'Đã có kết quả', insufficient: 'Chưa đủ cơ sở', referred: 'Chuyển đơn vị/người có thẩm quyền', closed: 'Đóng hồ sơ' }} /></Field>
      {st === 'referred' && <Field label="Chuyển tới"><Select value={to} onChange={setTo} options={(members.data || []).map((m: any) => [m.id, m.name])} placeholder="— Chọn —" /></Field>}
      <Field label="Kết quả chia sẻ với người liên quan" hint="Trung tính, không gắn nhãn; không tiết lộ dữ liệu của bên thứ ba. 'Chưa đủ cơ sở' không đồng nghĩa báo cáo sai."><textarea value={o} onChange={(e) => setO(e.target.value)} /></Field>
      <Field label="Căn cứ / ghi chú nội bộ"><textarea value={r} onChange={(e) => setR(e.target.value)} /></Field>
      <ErrorBox error={error} />
      <button className="btn primary block" disabled={busy || o.trim().length < 5 || (st === 'referred' && !to)} onClick={() => onSubmit({ status: st, outcome: o, reason: r || undefined, referToMemberId: to || undefined })}>Lưu kết quả</button>
    </>
  );
}

function ReassignForm({ busy, error, onSubmit }: { busy: boolean; error: string | null; onSubmit: (b: any) => void }) {
  const members = useLoad(() => get('/company/members?status=active'), []);
  const [m, setM] = useState(''); const [r, setR] = useState('');
  return (
    <>
      <Field label="Người xử lý mới"><Select value={m} onChange={setM} options={(members.data || []).filter((x: any) => ['hr', 'owner', 'admin', 'reviewer'].includes(x.role)).map((x: any) => [x.id, x.name])} placeholder="— Chọn —" /></Field>
      <Field label="Lý do"><input value={r} onChange={(e) => setR(e.target.value)} /></Field>
      <ErrorBox error={error} />
      <button className="btn primary block" disabled={busy || !m || r.trim().length < 5} onClick={() => onSubmit({ memberId: m, reason: r })}>Phân công</button>
    </>
  );
}
