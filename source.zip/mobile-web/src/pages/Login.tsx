import { FormEvent, useEffect, useState } from 'react';
import { get, post } from '../api';
import { useAuth } from '../auth';
import { ErrorBox, Field, Tabs, useAction } from '../ui';

const DEMO: [string, string][] = [
  ['0901000001', 'Chủ doanh nghiệp'], ['0901000002', 'Quản trị'], ['0901000003', 'Quản lý Vận hành'], ['0901000004', 'Quản lý Kinh doanh'],
  ['0901000007', 'Nhân viên 1'], ['0901000008', 'Nhân viên 2'], ['0901000012', 'Quản lý nhân sự'], ['0901000005', 'Trưởng Kỹ thuật'],
  ['0901000011', 'Reviewer độc lập'], ['0900000000', 'Quản trị nền tảng'],
];
const lastPhone = () => { try { return localStorage.getItem('last_phone') || ''; } catch { return ''; } };
const savePhone = (p: string) => { try { localStorage.setItem('last_phone', p.trim()); } catch { /* */ } };

/** Ô nhập mã OTP + nút gửi / gửi lại có đếm ngược. */
export function OtpInput({ code, setCode, onSend, disabled, label = 'Mã xác thực (OTP)' }: { code: string; setCode: (v: string) => void; onSend: () => Promise<any>; disabled?: boolean; label?: string }) {
  const [wait, setWait] = useState(0);
  const [info, setInfo] = useState<string | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  useEffect(() => { if (wait <= 0) return; const t = setTimeout(() => setWait(wait - 1), 1000); return () => clearTimeout(t); }, [wait]);
  const send = async () => {
    setErr(null); setBusy(true);
    try {
      const r = await onSend();
      setWait(r.resend_after || 60);
      setInfo(r.channel === 'sms' ? `Đã gửi mã qua SMS${r.phone_masked ? ` tới ${r.phone_masked}` : ''}. Mã có hiệu lực ${Math.round((r.expires_in || 300) / 60)} phút.`
        : 'Đã tạo mã. Hệ thống chưa bật gửi SMS — liên hệ quản trị Việc Đến để nhận mã.');
      if (r.dev_code) setCode(r.dev_code);
    } catch (e: any) { setErr(e.message); if (e.details?.retry_after) setWait(e.details.retry_after); } finally { setBusy(false); }
  };
  return (
    <Field label={label}>
      <div style={{ display: 'flex', gap: 8 }}>
        <input inputMode="numeric" autoComplete="one-time-code" maxLength={6} placeholder="6 số" value={code} onChange={(e) => setCode(e.target.value.replace(/\D/g, ''))} style={{ letterSpacing: 4, fontWeight: 600 }} />
        <button type="button" className="btn" style={{ whiteSpace: 'nowrap' }} disabled={disabled || busy || wait > 0} onClick={send}>{wait > 0 ? `Gửi lại (${wait}s)` : info ? 'Gửi lại mã' : 'Gửi mã'}</button>
      </div>
      {info && <div className="small muted" style={{ marginTop: 4 }}>{info}</div>}
      {err && <div className="small" style={{ color: 'var(--red)', marginTop: 4 }}>{err}</div>}
    </Field>
  );
}

export default function Login() {
  const { login, adopt } = useAuth();
  const [mode, setMode] = useState('login');
  const [method, setMethod] = useState<'password' | 'otp'>('password');
  const [phone, setPhone] = useState(lastPhone());
  const [name, setName] = useState('');
  const [password, setPassword] = useState('');
  const [password2, setPassword2] = useState('');
  const [code, setCode] = useState('');
  const [cfg, setCfg] = useState<any>(null);
  const a = useAction();
  useEffect(() => { get('/auth/otp/config').then(setCfg).catch(() => setCfg({ required_for_register: false, sms: false })); }, []);
  const otpOnRegister = !!cfg?.required_for_register;
  const sendOtp = (purpose: string) => () => { if (!phone.trim()) throw new Error('Nhập số điện thoại trước'); return post('/auth/otp/request', { phone: phone.trim(), purpose }); };
  const submit = (e: FormEvent) => {
    e.preventDefault();
    if ((mode === 'register' || mode === 'reset') && password !== password2) { a.setError('Mật khẩu nhập lại không khớp'); return; }
    savePhone(phone);
    a.run(async () => {
      if (mode === 'login' && method === 'password') return login(phone.trim(), password);
      if (mode === 'login') return adopt(await post('/auth/login-otp', { phone: phone.trim(), code }));
      if (mode === 'reset') return adopt(await post('/auth/reset-password', { phone: phone.trim(), code, newPassword: password }));
      return adopt(await post('/auth/register', { phone: phone.trim(), name: name.trim(), password, otpCode: code || undefined }));
    });
  };
  const go = (m: string) => { setMode(m); setCode(''); setPassword(''); setPassword2(''); a.setError(null); };
  const btn = mode === 'login' ? 'Đăng nhập' : mode === 'reset' ? 'Đặt mật khẩu mới & đăng nhập' : 'Tạo tài khoản';
  return (
    <div className="login">
      <img src="/logo.png" alt="Việc Đến — Quản lý & Giám sát việc" style={{ width: 200, display: 'block', margin: '0 auto 12px' }} />
      {mode !== 'reset' ? <Tabs value={mode} onChange={go} tabs={[['login', 'Đăng nhập'], ['register', 'Đăng ký']]} />
        : <div className="row" style={{ marginBottom: 8 }}><button className="btn sm" onClick={() => go('login')}>‹ Quay lại</button><b style={{ marginLeft: 8 }}>Quên mật khẩu</b></div>}
      {mode === 'login' && (
        <div className="seg" style={{ marginBottom: 8 }}>
          <button type="button" className={method === 'password' ? 'on' : ''} onClick={() => { setMethod('password'); a.setError(null); }}>Bằng mật khẩu</button>
          <button type="button" className={method === 'otp' ? 'on' : ''} onClick={() => { setMethod('otp'); a.setError(null); }}>Bằng mã OTP</button>
        </div>
      )}
      <form onSubmit={submit}>
        <Field label="Số điện thoại"><input type="tel" inputMode="tel" autoComplete="tel" placeholder="0912 345 678" value={phone} onChange={(e) => setPhone(e.target.value)} required /></Field>
        {mode === 'register' && <Field label="Họ và tên đầy đủ" hint="Tên này hiển thị với mọi người trong doanh nghiệp"><input autoComplete="name" value={name} onChange={(e) => setName(e.target.value)} required /></Field>}
        {((mode === 'login' && method === 'otp') || mode === 'reset' || (mode === 'register' && otpOnRegister)) &&
          <OtpInput code={code} setCode={setCode} disabled={!phone.trim()} onSend={sendOtp(mode === 'register' ? 'register' : mode === 'reset' ? 'reset' : 'login')} />}
        {!(mode === 'login' && method === 'otp') && (
          <Field label={mode === 'reset' ? 'Mật khẩu mới' : 'Mật khẩu'} hint={mode !== 'login' ? 'Tối thiểu 8 ký tự' : undefined}>
            <input type="password" autoComplete={mode === 'login' ? 'current-password' : 'new-password'} value={password} onChange={(e) => setPassword(e.target.value)} required />
          </Field>
        )}
        {(mode === 'register' || mode === 'reset') && <Field label="Nhập lại mật khẩu"><input type="password" autoComplete="new-password" value={password2} onChange={(e) => setPassword2(e.target.value)} required /></Field>}
        <ErrorBox error={a.error} />
        <button className="btn primary block" disabled={a.busy || (((mode === 'login' && method === 'otp') || mode === 'reset' || (mode === 'register' && otpOnRegister)) && code.length !== 6)}>{a.busy ? 'Đang xử lý…' : btn}</button>
        {mode === 'login' && <button type="button" className="btn block" style={{ marginTop: 8, border: 0, background: 'none', color: 'var(--primary)' }} onClick={() => go('reset')}>Quên mật khẩu?</button>}
        {mode === 'register' && <p className="small muted">Nếu doanh nghiệp đã thêm số điện thoại của bạn, hãy đăng ký bằng đúng số đó để vào thẳng công ty.</p>}
        {mode === 'reset' && <p className="small muted">Nhập số điện thoại đã đăng ký, bấm "Gửi mã" để nhận mã qua SMS, rồi đặt mật khẩu mới. Các thiết bị khác đang đăng nhập sẽ bị đăng xuất.</p>}
      </form>
      {import.meta.env.VITE_HIDE_DEMO !== 'true' && mode === 'login' && method === 'password' && (
        <>
          <div className="section-title">Tài khoản demo (mật khẩu Demo@123)</div>
          <div className="demo-accounts">
            {DEMO.map(([p, l]) => <button key={p} className="btn sm" onClick={() => { setPhone(p); setPassword('Demo@123'); }}>{l}<br /><span className="muted">{p}</span></button>)}
          </div>
        </>
      )}
    </div>
  );
}
