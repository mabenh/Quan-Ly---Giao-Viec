import { FormEvent, useState } from 'react';
import { useAuth } from '../auth';
import { ErrorBox, Field, useAction } from '../ui';

const DEMO: [string, string][] = [
  ['owner@demo.vn', 'Owner'], ['admin@demo.vn', 'Admin'], ['quanly1@demo.vn', 'Quản lý Vận hành'], ['quanly2@demo.vn', 'Quản lý Kinh doanh'],
  ['nv1@demo.vn', 'Nhân viên 1'], ['nv2@demo.vn', 'Nhân viên 2'], ['truongkt@demo.vn', 'Trưởng Kỹ thuật'], ['kythuat@demo.vn', 'Kỹ thuật viên'],
  ['reviewer@demo.vn', 'Reviewer độc lập'], ['nv4@demo.vn', 'Nhân viên KD'],
];

export default function Login() {
  const { login } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const a = useAction();
  const submit = (e: FormEvent) => { e.preventDefault(); a.run(() => login(email.trim(), password)); };
  return (
    <div className="login">
      <div className="logo" aria-hidden>✓</div>
      <h1>Quản lý nhóm & hiệu suất</h1>
      <p className="muted">Giao việc đơn giản · ghi nhận đầy đủ công việc thực tế · đánh giá công bằng.</p>
      <form onSubmit={submit}>
        <Field label="Email"><input type="email" autoComplete="username" value={email} onChange={(e) => setEmail(e.target.value)} required /></Field>
        <Field label="Mật khẩu"><input type="password" autoComplete="current-password" value={password} onChange={(e) => setPassword(e.target.value)} required /></Field>
        <ErrorBox error={a.error} />
        <button className="btn primary block" disabled={a.busy}>{a.busy ? 'Đang đăng nhập…' : 'Đăng nhập'}</button>
      </form>
      {import.meta.env.VITE_HIDE_DEMO !== 'true' && (
        <>
          <div className="section-title">Tài khoản demo (mật khẩu Demo@123)</div>
          <div className="demo-accounts">
            {DEMO.map(([e, l]) => <button key={e} className="btn sm" onClick={() => { setEmail(e); setPassword('Demo@123'); }}>{l}<br /><span className="muted">{e}</span></button>)}
          </div>
        </>
      )}
    </div>
  );
}
