import { Link } from 'react-router-dom';
import { Header } from '../ui';

type B = { x: number; y: number; w: number; h: number; lines: string[]; tone?: 'main' | 'side' | 'ok' | 'warn' };
function Box({ x, y, w, h, lines, tone = 'main' }: B) {
  const fill = tone === 'main' ? 'var(--primary-soft)' : tone === 'ok' ? 'var(--green-bg)' : tone === 'warn' ? 'var(--amber-bg)' : 'var(--surface-2)';
  const stroke = tone === 'main' ? 'var(--primary)' : tone === 'ok' ? 'var(--green)' : tone === 'warn' ? 'var(--amber)' : 'var(--border)';
  const lh = 13; const top = y + h / 2 - ((lines.length - 1) * lh) / 2 + 4;
  return (
    <g>
      <rect x={x} y={y} width={w} height={h} rx={10} fill={fill} stroke={stroke} strokeWidth={1.5} />
      {lines.map((l, i) => <text key={i} x={x + w / 2} y={top + i * lh} textAnchor="middle" fontSize={i === 0 ? 11.5 : 10.5} fontWeight={i === 0 ? 700 : 500} fill="var(--text)">{l}</text>)}
    </g>
  );
}
const Arrow = ({ d, dash }: { d: string; dash?: boolean }) => <path d={d} fill="none" stroke="var(--muted)" strokeWidth={1.5} markerEnd="url(#ah)" strokeDasharray={dash ? '4 3' : undefined} />;

/** Sơ đồ đường đi của quy trình giao việc trên Việc Đến. */
export default function AssignFlow() {
  const M = { x: 100, w: 160 };
  const rows = [10, 78, 146, 214, 300, 386, 462];
  return (
    <>
      <Header title="Sơ đồ quy trình giao việc" back="/hr" />
      <div className="page">
        <div className="card flow" role="img" aria-label="Sơ đồ quy trình giao việc từ xác định việc đến đánh giá">
          <svg viewBox="0 0 360 700">
            <defs><marker id="ah" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse"><path d="M0,0 L10,5 L0,10 z" fill="var(--muted)" /></marker></defs>
            <Box x={M.x} y={rows[0]} w={M.w} h={48} lines={['1. Xác định việc', '5W2H · chọn mẫu']} />
            <Box x={M.x} y={rows[1]} w={M.w} h={48} lines={['2. Tiêu chí đầu ra', 'SMART · lưu phiên bản']} />
            <Box x={M.x} y={rows[2]} w={M.w} h={48} lines={['3. Chọn người', 'nghỉ phép · bàn giao · tải việc']} />
            <Box x={M.x} y={rows[3]} w={M.w} h={56} lines={['4. Chuẩn bị giấy phép', 'ra vào cổng · thiết bị · xe', 'người giao chịu trách nhiệm']} />
            <Box x={270} y={200} w={86} h={38} tone="side" lines={['Chờ duyệt', 'bộ phận cấp']} />
            <Box x={270} y={244} w={86} h={38} tone="warn" lines={['Khai báo', 'hậu kiểm sau']} />
            <Box x={M.x} y={rows[4]} w={M.w} h={48} lines={['5. Giao việc trên app', 'nhân viên nhận thông báo']} />
            <Box x={4} y={292} w={86} h={64} tone="side" lines={['Giao qua', 'điện thoại/tin', '→ khai việc', 'nhanh']} />
            <Box x={M.x} y={rows[5]} w={M.w} h={48} lines={['6. Thực hiện', 'cập nhật tiến độ · bình luận']} />
            <Box x={270} y={370} w={86} h={38} tone="warn" lines={['Trở ngại', 'chuyển cấp']} />
            <Box x={270} y={416} w={86} h={30} tone="side" lines={['Tăng ca']} />
            <Box x={M.x} y={rows[6]} w={M.w} h={44} lines={['7. Bàn giao kết quả', 'kèm bằng chứng']} />
            <polygon points="180,530 262,572 180,614 98,572" fill="var(--surface)" stroke="var(--primary)" strokeWidth={1.5} />
            <text x={180} y={569} textAnchor="middle" fontSize={11.5} fontWeight={700} fill="var(--text)">8. Nghiệm thu</text>
            <text x={180} y={583} textAnchor="middle" fontSize={10.5} fill="var(--muted)">đạt tiêu chí?</text>
            <Box x={M.x} y={640} w={M.w} h={48} tone="ok" lines={['9. Hoàn thành & đánh giá', 'điểm có trọng số độ khó']} />
            {[0, 1, 2].map((i) => <Arrow key={i} d={`M180 ${rows[i] + 48} V${rows[i + 1] - 2}`} />)}
            <Arrow d={`M180 ${rows[3] + 56} V${rows[4] - 2}`} />
            <Arrow d={`M180 ${rows[4] + 48} V${rows[5] - 2}`} />
            <Arrow d={`M180 ${rows[5] + 48} V${rows[6] - 2}`} />
            <Arrow d={`M180 ${rows[6] + 44} V528`} />
            <Arrow d="M180 614 V638" />
            <text x={190} y={628} fontSize={10.5} fill="var(--green)" fontWeight={700}>Đạt</text>
            <Arrow d="M260 232 H268" /><Arrow d="M260 252 C 264 256, 264 262, 268 263" />
            <Arrow d="M90 324 H98" />
            <Arrow d="M260 404 H268" dash /><Arrow d="M260 418 C 264 422, 264 426, 268 429" dash />
            <path d="M98 572 H60 V410 H98" fill="none" stroke="var(--red)" strokeWidth={1.5} markerEnd="url(#ah)" />
            <text x={20} y={500} fontSize={10.5} fill="var(--red)" fontWeight={700} transform="rotate(-90 20 500)">Yêu cầu sửa</text>
          </svg>
        </div>
        <div className="legend">Khung xanh: bước chính · khung xám: nhánh phụ · khung vàng: cần theo dõi · đường đỏ: vòng chỉnh sửa</div>
        <div className="actions"><Link className="btn" to="/hr/guide">Hướng dẫn giao việc</Link><Link className="btn" to="/hr/procedures">Quy trình chi tiết</Link></div>
      </div>
    </>
  );
}
