import { useNavigate } from 'react-router-dom';
import { get, patch, post } from '../api';
import { Card, Empty, Header, Loading, useLoad } from '../ui';
import { fmtDT } from '../labels';

const ROUTE: Record<string, string> = { task: '/tasks/', work_record: '/work-records/', workplace_report: '/reports/', overtime: '/overtime/', group: '/groups/', quick_claim: '/quick/', leave: '/leaves/', decision: '/decisions/', permit: '/permits/', procedure: '/hr/procedures/' };

export default function Notifications() {
  const nav = useNavigate();
  const { data, loading, reload } = useLoad(() => get('/notifications?limit=100'), []);
  const open = async (n: any) => {
    if (!n.read_at) await patch(`/notifications/${n.id}/read`).catch(() => {});
    if (n.reference_type === 'member') nav('/admin/members');
    else if (n.reference_type && ROUTE[n.reference_type]) nav(ROUTE[n.reference_type] + n.reference_id); else reload();
  };
  return (
    <>
      <Header title="Thông báo" back right={<button className="btn sm" onClick={async () => { await post('/notifications/read-all'); reload(); }}>Đọc tất cả</button>} />
      <div className="page">
        {loading && !data && <Loading />}
        {data && data.items.length === 0 && <Empty>Chưa có thông báo</Empty>}
        {data?.items.map((n: any) => (
          <Card key={n.id} onClick={() => open(n)} className={`notif ${n.read_at ? '' : 'unread'}`}>
            <div className="main">
              <div className="title">{n.title}</div>
              {n.body && <div className="small muted ellipsis">{n.body}</div>}
              <div className="small muted">{fmtDT(n.created_at)}</div>
            </div>
          </Card>
        ))}
      </div>
    </>
  );
}
