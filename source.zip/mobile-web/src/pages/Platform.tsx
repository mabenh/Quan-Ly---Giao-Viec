import { useState } from 'react';
import { get, post, qs } from '../api';
import { Badge, Card, Empty, ErrorBox, Field, Header, Loading, Select, Tabs, useAction, useLoad, Note } from '../ui';
import { PLAN_NAME, fmtDT, vnd } from '../labels';
import { ConnectionDiag } from '../appstatus';

const SPECIAL = ['support', 'otp', 'diag'];
const PURPOSE: Record<string, string> = { register: 'Đăng ký', login: 'Đăng nhập', reset: 'Quên mật khẩu', change_password: 'Đổi mật khẩu' };

/** Nhật ký mã OTP: khi chưa cấu hình SMS (hoặc SMS lỗi), đọc mã cho khách SAU KHI đã xác minh đúng chủ số điện thoại. */
function OtpLog() {
  const [phone, setPhone] = useState('');
  const { data, error, reload } = useLoad(() => get('/platform/otp-log' + qs({ phone })), [phone]);
  return (
    <>
      <div className={`alert ${data?.provider ? 'ok' : 'warn'} small`}>{data?.provider ? `Đang gửi SMS qua: ${data.provider}. Mã chỉ hiện ở đây khi gửi SMS lỗi.` : 'Chưa cấu hình nhà cung cấp SMS (biến SMS_PROVIDER) — mã OTP hiện ở đây để hỗ trợ khách qua điện thoại. Chỉ đọc mã khi đã xác minh đúng chủ số.'}</div>
      <div style={{ display: 'flex', gap: 8 }}><input placeholder="Lọc theo số điện thoại" value={phone} onChange={(e) => setPhone(e.target.value)} /><button className="btn" onClick={reload}>Làm mới</button></div>
      <ErrorBox error={error} />
      {data?.items.map((o: any) => (
        <Card key={o.id}>
          <div className="row" style={{ display: 'flex', gap: 8 }}><b style={{ flex: 1 }}>{o.phone}</b><Badge>{PURPOSE[o.purpose] || o.purpose}</Badge>
            {o.consumed_at ? <Badge tone="green">Đã dùng</Badge> : new Date(o.expires_at) < new Date() ? <Badge tone="gray">Hết hạn</Badge> : <Badge tone="blue">Còn hiệu lực</Badge>}</div>
          {o.manual_code && <div className="join-code" style={{ fontSize: 22 }}>{o.manual_code}</div>}
          <div className="small muted">{fmtDT(o.created_at)} · {o.delivery || o.channel}{o.attempts ? ` · nhập sai ${o.attempts} lần` : ''}</div>
        </Card>
      ))}
    </>
  );
}

function SlowRequests() {
  const { data } = useLoad(() => get('/platform/client-errors?hours=24'), []);
  const list = data?.slow_requests || [];
  return (
    <>
      <div className="section-title">Yêu cầu chậm trên máy chủ (≥ 1,5 giây, từ lần khởi động gần nhất)</div>
      {list.length === 0 && <div className="alert ok small">Không có yêu cầu nào chậm.</div>}
      {list.map((r: any, i: number) => <div key={i} className="small" style={{ borderBottom: '1px solid var(--border)', padding: '4px 0' }}><b>{(r.ms / 1000).toFixed(1)}s</b> · {r.method} {r.path} · {r.status} · {new Date(r.at).toLocaleTimeString('vi-VN')}</div>)}
    </>
  );
}

export default function Platform() {
  const [status, setStatus] = useState('pending_payment');
  const { data, error, loading, reload } = useLoad(() => (SPECIAL.includes(status) ? Promise.resolve([]) : get('/platform/subscriptions' + qs({ status }))), [status]);
  const a = useAction();
  return (
    <>
      <Header title="Quản trị nền tảng" back />
      <div className="page">
        <Tabs value={status} onChange={setStatus} tabs={[['pending_payment', 'Chờ thanh toán'], ['active', 'Đã kích hoạt'], ['refund_pending', 'Chờ hoàn tiền'], ['rejected', 'Từ chối'], ['support', 'Hỗ trợ kỹ thuật'], ['otp', 'Mã OTP'], ['diag', 'Kết nối & tốc độ']]} />
        {status === 'otp' && <OtpLog />}
        {status === 'diag' && <><ConnectionDiag /><SlowRequests /></>}
        {status === 'support' && <SupportAccess />}
        <ErrorBox error={error || a.error} />
        {!SPECIAL.includes(status) && loading && !data && <Loading />}
        {!SPECIAL.includes(status) && data && data.length === 0 && <Empty>Không có yêu cầu</Empty>}
        {!SPECIAL.includes(status) && data?.map((s: any) => (
          <Card key={s.id}>
            <div className="row" style={{ display: 'flex', gap: 8 }}><b style={{ flex: 1 }}>{s.company_name}</b><Badge>{PLAN_NAME[s.plan]}</Badge></div>
            <div className="small">{s.user_name} · {s.phone} · {s.contact_email}</div>
            <div className="small muted">{({ new: 'Mua gói', renew: 'Gia hạn', change: 'Chuyển gói', addon: 'Gói cộng thêm', cancel: 'Hủy gói' } as any)[s.kind] || 'Mua gói'} · {Number(s.refund_vnd) > 0 ? `hoàn ${vnd(Number(s.refund_vnd))}` : vnd(Number(s.amount_vnd || s.price_vnd))} · {fmtDT(s.created_at)}{s.payment_ref ? ` · Mã GD: ${s.payment_ref}` : ''}{s.refund_ref ? ` · Mã hoàn: ${s.refund_ref}` : ''}</div>
            {s.status === 'refund_pending' && <button className="btn primary sm" disabled={a.busy} onClick={() => { const ref = prompt('Mã giao dịch hoàn tiền:'); if (ref) a.run(async () => { await post(`/platform/subscriptions/${s.id}/refunded`, { refundRef: ref }); reload(); }); }}>Đã hoàn tiền {vnd(Number(s.refund_vnd))}</button>}
            {s.status === 'pending_payment' && (
              <div className="actions">
                <button className="btn primary sm" disabled={a.busy} onClick={() => { const ref = prompt('Mã giao dịch thanh toán:'); if (ref) a.run(async () => { await post(`/platform/subscriptions/${s.id}/activate`, { paymentRef: ref }); reload(); }); }}>Xác nhận đã thanh toán</button>
                <button className="btn danger sm" disabled={a.busy} onClick={() => confirm('Từ chối yêu cầu này?') && a.run(async () => { await post(`/platform/subscriptions/${s.id}/reject`); reload(); })}>Từ chối</button>
              </div>
            )}
          </Card>
        ))}
      </div>
    </>
  );
}

const SCOPE: Record<string, string> = { company_settings: 'Cấu hình công ty', members_basic: 'Danh sách thành viên (tên, vai trò)', audit_logs: 'Nhật ký thay đổi' };
/** Hỗ trợ nền tảng không đọc dữ liệu khách hàng theo mặc định: xin quyền tạm thời, doanh nghiệp duyệt, mọi lần xem đều ghi nhật ký. */
function SupportAccess() {
  const subs = useLoad(() => get('/platform/subscriptions?status=active'), []);
  const mine = useLoad(() => get('/support/access-requests'), []);
  const [f, setF] = useState<any>({ companyId: '', scope: 'members_basic', reason: '', ticket: '', hours: 2, emergency: false });
  const [view, setView] = useState<any>(null);
  const a = useAction();
  const companies = Array.from(new Map<string, string>((subs.data || []).filter((x: any) => x.company_id).map((x: any) => [x.company_id, x.company_name])).entries());
  return (
    <>
      <Note>Mỗi yêu cầu phải nêu mục đích, phiếu hỗ trợ và thời hạn (tối đa 24 giờ). Chủ doanh nghiệp/Quản trị duyệt. Khẩn cấp: hiệu lực ngay 1 giờ, doanh nghiệp được thông báo để hậu kiểm.</Note>
      <Field label="Doanh nghiệp"><Select value={f.companyId} onChange={(v) => setF({ ...f, companyId: v })} options={companies} placeholder="— Chọn —" /></Field>
      <Field label="Phạm vi"><Select value={f.scope} onChange={(v) => setF({ ...f, scope: v })} options={SCOPE} /></Field>
      <Field label="Mục đích" required><input value={f.reason} onChange={(e) => setF({ ...f, reason: e.target.value })} /></Field>
      <div className="grid2">
        <Field label="Mã phiếu hỗ trợ"><input value={f.ticket} onChange={(e) => setF({ ...f, ticket: e.target.value })} /></Field>
        <Field label="Số giờ"><input type="number" min={1} max={24} value={f.hours} onChange={(e) => setF({ ...f, hours: Number(e.target.value) })} /></Field>
      </div>
      <label className="check"><input type="checkbox" checked={f.emergency} onChange={(e) => setF({ ...f, emergency: e.target.checked })} /> Khẩn cấp (sự cố đang diễn ra)</label>
      <ErrorBox error={a.error} />
      <button className="btn primary block" disabled={a.busy || !f.companyId || f.reason.trim().length < 10} onClick={() => a.run(async () => { await post('/support/access-requests', { ...f, ticket: f.ticket || undefined }); mine.reload(); setF({ ...f, reason: '', ticket: '' }); })}>Gửi yêu cầu</button>
      <div className="section-title">Yêu cầu của tôi</div>
      {mine.data?.map((p: any) => (
        <Card key={p.id}>
          <div className="row"><b style={{ flex: 1 }}>{p.company_name} · {SCOPE[p.scope]}</b><Badge tone={p.status === 'approved' ? 'green' : p.status === 'pending' ? 'amber' : 'gray'}>{p.status}</Badge></div>
          <div className="small muted">{p.reason} · {fmtDT(p.created_at)}{p.expires_at ? ` · hết hạn ${fmtDT(p.expires_at)}` : ''}</div>
          {p.status === 'approved' && <button className="btn sm" onClick={() => a.run(async () => setView(await get(`/support/companies/${p.company_id}/view?scope=${p.scope}`)))}>Xem (được ghi nhật ký)</button>}
        </Card>
      ))}
      {view && <Card><div className="small muted">Hiệu lực đến {fmtDT(view.expires_at)}</div><pre className="small" style={{ whiteSpace: 'pre-wrap', maxHeight: 300, overflow: 'auto' }}>{JSON.stringify(view.data, null, 1)}</pre></Card>}
    </>
  );
}
