import { useState } from 'react';
import { get, post, qs } from '../api';
import { Badge, Card, Empty, ErrorBox, Field, Header, Loading, Select, Tabs, useAction, useLoad } from '../ui';
import { PLAN_NAME, fmtDT, vnd } from '../labels';

export default function Platform() {
  const [status, setStatus] = useState('pending_payment');
  const { data, error, loading, reload } = useLoad(() => (status === 'support' ? Promise.resolve([]) : get('/platform/subscriptions' + qs({ status }))), [status]);
  const a = useAction();
  return (
    <>
      <Header title="Quản trị nền tảng" back />
      <div className="page">
        <Tabs value={status} onChange={setStatus} tabs={[['pending_payment', 'Chờ thanh toán'], ['active', 'Đã kích hoạt'], ['rejected', 'Từ chối'], ['support', 'Hỗ trợ kỹ thuật']]} />
        {status === 'support' && <SupportAccess />}
        <ErrorBox error={error || a.error} />
        {status !== 'support' && loading && !data && <Loading />}
        {status !== 'support' && data && data.length === 0 && <Empty>Không có yêu cầu</Empty>}
        {status !== 'support' && data?.map((s: any) => (
          <Card key={s.id}>
            <div className="row" style={{ display: 'flex', gap: 8 }}><b style={{ flex: 1 }}>{s.company_name}</b><Badge>{PLAN_NAME[s.plan]}</Badge></div>
            <div className="small">{s.user_name} · {s.phone} · {s.contact_email}</div>
            <div className="small muted">{vnd(Number(s.price_vnd))} · {fmtDT(s.created_at)}{s.payment_ref ? ` · Mã GD: ${s.payment_ref}` : ''}</div>
            {s.status === 'pending_payment' && (
              <div className="actions">
                <button className="btn primary sm" disabled={a.busy} onClick={() => { const ref = prompt('Mã giao dịch thanh toán:'); if (ref) a.run(async () => { await post(`/platform/subscriptions/${s.id}/activate`, { paymentRef: ref }); reload(); }); }}>Xác nhận đã thanh toán</button>
                <button className="btn danger sm" disabled={a.busy} onClick={() => confirm('Từ chối yêu cầu này?') && a.run(async () => { await post(`/platform/subscriptions/${s.id}/reject`); reload(); })}>Từ chối</button>
              </div>
            )}
          </Card>
        ))}
      </div>
    </>
  );
}

const SCOPE: Record<string, string> = { company_settings: 'Cấu hình công ty', members_basic: 'Danh sách thành viên (tên, vai trò)', audit_logs: 'Nhật ký thay đổi' };
/** Hỗ trợ nền tảng không đọc dữ liệu khách hàng theo mặc định: xin quyền tạm thời, doanh nghiệp duyệt, mọi lần xem đều ghi nhật ký. */
function SupportAccess() {
  const subs = useLoad(() => get('/platform/subscriptions?status=active'), []);
  const mine = useLoad(() => get('/support/access-requests'), []);
  const [f, setF] = useState<any>({ companyId: '', scope: 'members_basic', reason: '', ticket: '', hours: 2, emergency: false });
  const [view, setView] = useState<any>(null);
  const a = useAction();
  const companies = Array.from(new Map<string, string>((subs.data || []).filter((x: any) => x.company_id).map((x: any) => [x.company_id, x.company_name])).entries());
  return (
    <>
      <p className="small muted">Mỗi yêu cầu phải nêu mục đích, phiếu hỗ trợ và thời hạn (tối đa 24 giờ). Chủ doanh nghiệp/Quản trị duyệt. Khẩn cấp: hiệu lực ngay 1 giờ, doanh nghiệp được thông báo để hậu kiểm.</p>
      <Field label="Doanh nghiệp"><Select value={f.companyId} onChange={(v) => setF({ ...f, companyId: v })} options={companies} placeholder="— Chọn —" /></Field>
      <Field label="Phạm vi"><Select value={f.scope} onChange={(v) => setF({ ...f, scope: v })} options={SCOPE} /></Field>
      <Field label="Mục đích" required><input value={f.reason} onChange={(e) => setF({ ...f, reason: e.target.value })} /></Field>
      <div className="grid2">
        <Field label="Mã phiếu hỗ trợ"><input value={f.ticket} onChange={(e) => setF({ ...f, ticket: e.target.value })} /></Field>
        <Field label="Số giờ"><input type="number" min={1} max={24} value={f.hours} onChange={(e) => setF({ ...f, hours: Number(e.target.value) })} /></Field>
      </div>
      <label className="check"><input type="checkbox" checked={f.emergency} onChange={(e) => setF({ ...f, emergency: e.target.checked })} /> Khẩn cấp (sự cố đang diễn ra)</label>
      <ErrorBox error={a.error} />
      <button className="btn primary block" disabled={a.busy || !f.companyId || f.reason.trim().length < 10} onClick={() => a.run(async () => { await post('/support/access-requests', { ...f, ticket: f.ticket || undefined }); mine.reload(); setF({ ...f, reason: '', ticket: '' }); })}>Gửi yêu cầu</button>
      <div className="section-title">Yêu cầu của tôi</div>
      {mine.data?.map((p: any) => (
        <Card key={p.id}>
          <div className="row"><b style={{ flex: 1 }}>{p.company_name} · {SCOPE[p.scope]}</b><Badge tone={p.status === 'approved' ? 'green' : p.status === 'pending' ? 'amber' : 'gray'}>{p.status}</Badge></div>
          <div className="small muted">{p.reason} · {fmtDT(p.created_at)}{p.expires_at ? ` · hết hạn ${fmtDT(p.expires_at)}` : ''}</div>
          {p.status === 'approved' && <button className="btn sm" onClick={() => a.run(async () => setView(await get(`/support/companies/${p.company_id}/view?scope=${p.scope}`)))}>Xem (được ghi nhật ký)</button>}
        </Card>
      ))}
      {view && <Card><div className="small muted">Hiệu lực đến {fmtDT(view.expires_at)}</div><pre className="small" style={{ whiteSpace: 'pre-wrap', maxHeight: 300, overflow: 'auto' }}>{JSON.stringify(view.data, null, 1)}</pre></Card>}
    </>
  );
}
