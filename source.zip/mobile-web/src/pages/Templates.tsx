import { useState } from 'react';
import { get, patch, post } from '../api';
import { can, useAuth } from '../auth';
import { Badge, Card, Empty, ErrorBox, Field, Header, Loading, Select, Sheet, useAction, useLoad, Note } from '../ui';
import { Icon } from '../icons';
import { COMPLEXITY, REQ } from '../labels';

const FIELD_TYPE: Record<string, string> = { text: 'Chữ', textarea: 'Đoạn văn', number: 'Số', date: 'Ngày', datetime: 'Ngày giờ' };
const ICONS = ['work', 'record', 'tasks', 'users', 'book', 'calendar', 'chart', 'handshake', 'clipboard-check', 'forklift', 'wrench', 'settings', 'shield', 'sparkles', 'truck', 'boxes', 'package', 'cart'];
const slug = (s: string) => s.normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/đ/g, 'd').replace(/Đ/g, 'd').toLowerCase().replace(/[^a-z0-9]+/g, '_').replace(/^_|_$/g, '').slice(0, 40) || 'truong';

/**
 * Mẫu công việc theo phòng ban (v8). Quản lý phòng ban (tầng 5) tạo & chỉnh sửa mẫu cho phòng mình;
 * Ban điều hành/quản lý cấp cao quản lý mẫu mọi phòng ban. Người giao việc chỉ thấy mẫu của phòng ban mình được giao việc.
 */
export default function Templates() {
  const { me } = useAuth();
  const all = can(me, 'manage_templates_all');
  const { data, error, loading, reload } = useLoad(() => get('/company/task-templates?manage=true'), []);
  const depts = useLoad(() => get('/company/departments'), []);
  const types = useLoad(() => get('/company/task-types'), []);
  const [edit, setEdit] = useState<any>(null);
  const [dept, setDept] = useState('');
  const items = (data || []).filter((t: any) => !dept || (dept === 'shared' ? !t.department_id : t.department_id === dept));
  const blank = () => ({ name: '', description: '', icon: 'work', taskTypeId: types.data?.find((t: any) => t.active)?.id || '', complexity: 'simple', requirementLevel: 'normal', estimatedHours: 2,
    departmentId: all ? '' : me?.authority?.department_id || '', fields: [], criteria: [{ direction: 'output', criterion: '' }] });
  const open = (t: any) => setEdit({ id: t.id, name: t.name, description: t.description || '', icon: t.icon || 'work', taskTypeId: t.task_type_id, complexity: t.complexity, requirementLevel: t.requirement_level,
    estimatedHours: Number(t.estimated_hours), departmentId: t.department_id || '', fields: t.fields || [], criteria: t.criteria?.length ? t.criteria : [{ direction: 'output', criterion: '' }], active: t.active, system: !!t.system_key });
  const canCreate = all || can(me, 'manage_templates_dept');
  return (
    <>
      <Header title="Mẫu công việc của phòng ban" back />
      <div className="page">
        <Note>
          {all ? 'Bạn quản lý mẫu của mọi phòng ban. Mẫu không gắn phòng ban là mẫu dùng chung.' : `Mẫu của ${me?.authority?.department || 'phòng ban bạn'} — chỉ người giao việc trong phòng ban này thấy và dùng. Quản lý phòng ban là người tạo và chỉnh sửa mẫu.`}
          {' '}Đơn hàng (chuỗi sản xuất) không dùng mẫu.
        </Note>
        {canCreate ? <button className="btn primary block" onClick={() => setEdit(blank())}><Icon name="plus" size={18} />Tạo mẫu mới</button>
          : <div className="alert info small">Bạn không có quyền tạo mẫu. Liên hệ quản lý phòng ban.</div>}
        {all && <div className="filters"><Select value={dept} onChange={setDept} options={[['shared', 'Dùng chung'], ...(depts.data || []).map((d: any) => [d.id, d.name])] as [string, string][]} placeholder="Mọi phòng ban" aria-label="Phòng ban" /></div>}
        <ErrorBox error={error} />
        {loading && !data && <Loading />}
        {data && items.length === 0 && <Empty>Chưa có mẫu</Empty>}
        {items.map((t: any) => (
          <Card key={t.id} onClick={() => open(t)}>
            <div className="row"><span className="ichip blue" style={{ width: 34, height: 34 }}><Icon name={t.icon || 'work'} size={18} /></span>
              <div style={{ flex: 1, minWidth: 0 }}><b>{t.name}</b><div className="small muted ellipsis">{t.department_name || 'Dùng chung'} · {t.task_type_name} · {Number(t.estimated_hours)} giờ · {(t.fields || []).length} trường khai báo</div></div>
              {!t.active && <Badge tone="gray">Đã ẩn</Badge>}{t.system_key ? <Badge tone="gray">Thư viện</Badge> : <Badge tone="blue">Tự tạo</Badge>}</div>
          </Card>
        ))}
      </div>
      <Sheet open={!!edit} onClose={() => setEdit(null)} title={edit?.id ? 'Sửa mẫu công việc' : 'Mẫu công việc mới'}>
        {edit && <Editor t={edit} setT={setEdit} all={all} depts={depts.data || []} types={types.data || []} onDone={() => { setEdit(null); reload(); }} />}
      </Sheet>
    </>
  );
}

function Editor({ t, setT, all, depts, types, onDone }: { t: any; setT: (x: any) => void; all: boolean; depts: any[]; types: any[]; onDone: () => void }) {
  const a = useAction();
  const up = (p: any) => setT({ ...t, ...p });
  const setField = (i: number, p: any) => up({ fields: t.fields.map((x: any, j: number) => (j === i ? { ...x, ...p } : x)) });
  const setCrit = (i: number, p: any) => up({ criteria: t.criteria.map((x: any, j: number) => (j === i ? { ...x, ...p } : x)) });
  const save = (extra: any = {}) => a.run(async () => {
    const keys = new Set<string>();
    const fields = t.fields.filter((x: any) => x.label.trim()).map((x: any) => {
      let k = x.key || slug(x.label); while (keys.has(k)) k = (k + '_2').slice(0, 40); keys.add(k);
      return { key: k, label: x.label.trim(), type: x.type || 'text', required: !!x.required };
    });
    const body = { name: t.name, description: t.description || undefined, icon: t.icon, taskTypeId: t.taskTypeId, complexity: t.complexity, requirementLevel: t.requirementLevel,
      estimatedHours: Number(t.estimatedHours) || 1, fields, criteria: t.criteria.filter((c: any) => c.criterion.trim().length >= 2), ...(all ? { departmentId: t.departmentId || null } : {}), ...extra };
    if (t.id) await patch(`/company/task-templates/${t.id}`, body); else await post('/company/task-templates', body);
    onDone();
  });
  return (
    <>
      <Field label="Tên mẫu" required><input value={t.name} onChange={(e) => up({ name: e.target.value })} /></Field>
      <Field label="Mô tả"><textarea value={t.description} onChange={(e) => up({ description: e.target.value })} /></Field>
      {all && <Field label="Phòng ban sử dụng"><Select value={t.departmentId} onChange={(v) => up({ departmentId: v })} options={depts.map((d: any) => [d.id, d.name])} placeholder="— Dùng chung —" /></Field>}
      <div className="grid2">
        <Field label="Loại công việc" required><Select value={t.taskTypeId} onChange={(v) => up({ taskTypeId: v })} options={types.filter((x: any) => x.active).map((x: any) => [x.id, x.name])} /></Field>
        <Field label="Giờ dự kiến"><input type="number" min={0.5} step={0.5} value={t.estimatedHours} onChange={(e) => up({ estimatedHours: e.target.value })} /></Field>
      </div>
      <div className="grid2">
        <Field label="Độ phức tạp"><Select value={t.complexity} onChange={(v) => up({ complexity: v })} options={COMPLEXITY} /></Field>
        <Field label="Mức yêu cầu"><Select value={t.requirementLevel} onChange={(v) => up({ requirementLevel: v })} options={REQ} /></Field>
      </div>
      <Field label="Biểu tượng">
        <div className="chip-row">{ICONS.map((ic) => <button key={ic} type="button" className={`btn sm ${t.icon === ic ? 'primary' : ''}`} onClick={() => up({ icon: ic })} aria-label={ic}><Icon name={ic} size={16} /></button>)}</div>
      </Field>
      <div className="section-title">Trường khai báo khi giao việc</div>
      {t.fields.map((x: any, i: number) => (
        <div key={i} style={{ display: 'grid', gridTemplateColumns: '1fr 100px auto', gap: 6, marginBottom: 6, alignItems: 'center' }}>
          <input value={x.label} placeholder="Tên trường (VD: Mã lô)" onChange={(e) => setField(i, { label: e.target.value })} />
          <select value={x.type || 'text'} onChange={(e) => setField(i, { type: e.target.value })}>{Object.entries(FIELD_TYPE).map(([k, l]) => <option key={k} value={k}>{l}</option>)}</select>
          <button type="button" className="icon-btn" aria-label="Xóa" onClick={() => up({ fields: t.fields.filter((_: any, j: number) => j !== i) })}><Icon name="close" size={20} /></button>
          <label className="check" style={{ margin: 0, gridColumn: '1 / -1' }}><input type="checkbox" checked={!!x.required} onChange={(e) => setField(i, { required: e.target.checked })} /> Bắt buộc</label>
        </div>
      ))}
      {t.fields.length < 20 && <button type="button" className="btn sm" onClick={() => up({ fields: [...t.fields, { label: '', type: 'text', required: false }] })}><Icon name="plus" size={16} />Trường khai báo</button>}
      <div className="section-title">Tiêu chí nghiệm thu</div>
      {t.criteria.map((c: any, i: number) => (
        <div key={i} style={{ display: 'flex', gap: 6, marginBottom: 6 }}>
          <select style={{ width: 100 }} value={c.direction} onChange={(e) => setCrit(i, { direction: e.target.value })}><option value="input">Đầu vào</option><option value="output">Đầu ra</option></select>
          <input value={c.criterion} onChange={(e) => setCrit(i, { criterion: e.target.value })} />
          <button type="button" className="icon-btn" aria-label="Xóa" onClick={() => up({ criteria: t.criteria.filter((_: any, j: number) => j !== i) })}><Icon name="close" size={20} /></button>
        </div>
      ))}
      <button type="button" className="btn sm" onClick={() => up({ criteria: [...t.criteria, { direction: 'output', criterion: '' }] })}><Icon name="plus" size={16} />Tiêu chí</button>
      <ErrorBox error={a.error} />
      <div className="actions">
        {t.id && <button className="btn" disabled={a.busy} onClick={() => save({ active: !t.active })}>{t.active ? 'Ẩn mẫu' : 'Hiện lại'}</button>}
        <button className="btn primary" style={{ flex: 1 }} disabled={a.busy || t.name.trim().length < 2 || !t.taskTypeId} onClick={() => save()}>{a.busy ? 'Đang lưu…' : 'Lưu mẫu'}</button>
      </div>
    </>
  );
}
