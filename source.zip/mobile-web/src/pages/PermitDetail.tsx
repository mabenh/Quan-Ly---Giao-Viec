import { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import QRCode from 'qrcode';
import { get, post } from '../api';
import { Avatar, Badge, Card, ErrorBox, Field, Header, KV, Loading, useAction, useLoad } from '../ui';
import { Icon } from '../icons';
import { PERMIT_STATUS, PERMIT_TONE, fmtDT } from '../labels';

export default function PermitDetail() {
  const { id } = useParams();
  const { data: p, error, loading, setData } = useLoad(() => get(`/permits/${id}`), [id]);
  const [qr, setQr] = useState<string | null>(null);
  const [note, setNote] = useState('');
  const a = useAction();
  useEffect(() => { if (p) QRCode.toDataURL(`${window.location.origin}/permits/${p.id}`, { margin: 1, width: 256 }).then(setQr).catch(() => {}); }, [p?.id]);
  if (loading && !p) return <Loading />;
  if (!p) return <div className="page"><ErrorBox error={error} /></div>;
  const pm = p.permissions;
  const isGate = p.tracks === 'gate';
  const fields = (p.type_fields || []).filter((x: any) => p.data[x.key]);
  return (
    <>
      <Header title="Giấy phép" back />
      <div className="page">
        <div className={`pass ${p.is_valid_now ? '' : 'invalid'}`}>
          <div className="top">
            <span className="ichip" style={{ background: 'rgba(255,255,255,.18)', color: '#fff' }}><Icon name={p.type_icon || 'permit'} size={22} /></span>
            <div style={{ flex: 1, minWidth: 0 }}><div className="small" style={{ opacity: .85 }}>{p.type_name}</div><div className="code">{p.code}</div></div>
          </div>
          <div className="body">
            {qr && <img className="qr" src={qr} alt={`Mã QR giấy phép ${p.code}`} />}
            <div style={{ minWidth: 0 }}>
              <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}><Avatar userId={p.holder_user_id} name={p.holder_name} has={p.holder_has_avatar} size="sm" /><b>{p.holder_name}</b></div>
              <div className="small muted" style={{ marginTop: 4 }}>{fmtDT(p.valid_from)} → {fmtDT(p.valid_to)}</div>
              <div className="chip-row">
                <Badge tone={PERMIT_TONE[p.status]}>{PERMIT_STATUS[p.status]}</Badge>
                {p.is_valid_now ? <Badge tone="green">Đang hiệu lực</Badge> : p.expired ? <Badge tone="gray">Hết hiệu lực</Badge> : null}
                {p.review_status === 'ok' && <Badge tone="green">Hậu kiểm: hợp lệ</Badge>}
                {p.review_status === 'violation' && <Badge tone="red">Hậu kiểm: vi phạm</Badge>}
              </div>
            </div>
          </div>
        </div>
        {p.mode === 'declaration' && <div className="alert info small">Giấy phép cấp tự động theo đơn khai báo của {p.requester_name}. Bộ phận {p.department_name || 'phụ trách'} sẽ hậu kiểm; nếu quy trình sai, người lập giấy chịu trách nhiệm.</div>}
        <Card>
          <KV k="Người lập (người giao việc)" v={p.requester_name} />
          <KV k="Bộ phận xử lý" v={p.department_name || 'Quản trị công ty'} />
          {fields.map((x: any) => <KV key={x.key} k={x.label} v={p.data[x.key]} />)}
          {p.decision_by_name && <KV k={p.status === 'rejected' ? 'Từ chối bởi' : 'Cấp bởi'} v={`${p.decision_by_name} · ${fmtDT(p.decision_at)}`} />}
          {p.decision_note && <KV k="Ghi chú" v={p.decision_note} />}
          {p.out_at && <KV k={isGate ? 'Ra cổng' : 'Giao thiết bị'} v={`${fmtDT(p.out_at)} · ${p.out_by_name}`} />}
          {p.in_at && <KV k={isGate ? 'Vào lại' : 'Trả thiết bị'} v={`${fmtDT(p.in_at)} · ${p.in_by_name}`} />}
          {p.review_note && <KV k="Ghi chú hậu kiểm" v={`${p.review_note} (${p.reviewed_by_name})`} />}
        </Card>
        {p.task_id && (
          <Card to={`/tasks/${p.task_id}`}>
            <div className="small muted">Công việc liên quan</div>
            <b>{p.task_code} · {p.task_title}</b>
            <div className="small muted">{p.task_group_name} · hạn {fmtDT(p.task_due_at)}</div>
            {pm.is_handler && p.task_description && <div className="small crit" style={{ marginTop: 4 }}>{p.task_description.slice(0, 400)}</div>}
          </Card>
        )}
        <ErrorBox error={a.error} />
        {(pm.can_decide || pm.can_review) && <Field label="Ghi chú (bắt buộc khi từ chối / vi phạm)"><textarea value={note} onChange={(e) => setNote(e.target.value)} /></Field>}
        <div className="actions">
          {pm.can_decide && <button className="btn primary" disabled={a.busy} onClick={() => a.run(async () => setData(await post(`/permits/${id}/decide`, { decision: 'approve', note: note || undefined })))}><Icon name="ok" size={18} />Cấp phép</button>}
          {pm.can_decide && <button className="btn danger" disabled={a.busy} onClick={() => a.run(async () => setData(await post(`/permits/${id}/decide`, { decision: 'reject', note })))}>Từ chối</button>}
          {pm.can_track && !p.out_at && <button className="btn primary" disabled={a.busy || !p.is_valid_now} onClick={() => a.run(async () => setData(await post(`/permits/${id}/track`, { event: 'out' })))}>{isGate ? 'Ghi nhận ra cổng' : 'Ghi nhận giao thiết bị'}</button>}
          {pm.can_track && p.out_at && !p.in_at && <button className="btn primary" disabled={a.busy} onClick={() => a.run(async () => setData(await post(`/permits/${id}/track`, { event: 'in' })))}>{isGate ? 'Ghi nhận vào lại' : 'Ghi nhận trả thiết bị'}</button>}
          {pm.can_review && <button className="btn success" disabled={a.busy} onClick={() => a.run(async () => setData(await post(`/permits/${id}/review`, { result: 'ok', note: note || undefined })))}>Hậu kiểm: hợp lệ</button>}
          {pm.can_review && <button className="btn danger" disabled={a.busy} onClick={() => a.run(async () => setData(await post(`/permits/${id}/review`, { result: 'violation', note })))}>Hậu kiểm: sai quy trình</button>}
          {pm.can_cancel && <button className="btn" disabled={a.busy} onClick={() => confirm('Hủy giấy phép này?') && a.run(async () => setData(await post(`/permits/${id}/cancel`)))}>Hủy giấy phép</button>}
        </div>
        {pm.can_track && !p.is_valid_now && !p.out_at && <p className="small muted">Giấy phép chưa đến giờ hoặc đã hết hiệu lực — không cho ra cổng/giao thiết bị.</p>}
        <p className="small muted">Bảo vệ/thủ kho quét mã QR hoặc mở mã {p.code} để kiểm tra trước khi cho ra vào, giao thiết bị. <Link to="/hr/procedures">Xem quy trình</Link></p>
      </div>
    </>
  );
}
