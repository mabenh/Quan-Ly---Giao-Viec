import { useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { get, post, qs } from '../api';
import { isHRRole, tierOf, useAuth } from '../auth';
import { Badge, Card, Empty, ErrorBox, Loading, Select, Tabs, useLoad, Note } from '../ui';
import { Icon } from '../icons';
import { CHANNEL, CLAIM_STATUS, CLAIM_TONE, RP_STATUS, RP_TONE, WR_STATUS, WR_TONE, WR_TYPE, fmtD, fmtDT, hours } from '../labels';
import { CallLog } from './Comms';
import { AttendanceList } from './Attendance';
import { DecisionList } from './Decisions';
import { HandoverItems } from './Chains';
import { MemberReportList } from './MemberReports';
import { SR_STATUS } from './Support';
import { LeaveList, PermitList, ReportCard, TaskList } from './Work';

/** Trở ngại chưa xử lý xong (đang ở một khâu nào đó của quy trình). */
export const RP_OPEN = 'submitted,manager_review,assigned,acknowledged,in_progress,waiting,reopened,escalated,task_assigned';
/** Đã xử lý: đã khắc phục chờ người báo xác nhận, đã đóng, hoặc kết luận không khắc phục được. */
export const RP_DONE = 'resolved_pending,closed,cannot_fix';

/**
 * Phần Công việc (v9): bốn mục ngang hàng — Tổng quan · Nhiệm vụ · Khai báo công việc · Báo cáo trở ngại.
 * Trang chính (Tổng quan) là mô tả công việc của vai trò được giao, phòng ban đang ở, tin chính/thông báo của phòng
 * và bảng tin (trở ngại được báo, nhiệm vụ có yêu cầu hỗ trợ). Không tự chuyển sang mục khác.
 */
export default function WorkHub({ initial }: { initial?: { section?: string; view?: string } }) {
  const [sp, setSp] = useSearchParams();
  const section = sp.get('s') || initial?.section || 'overview';
  const set = (patch: Record<string, string | null>) => {
    const n = new URLSearchParams(sp);
    n.delete('tab');
    if (!n.get('s')) n.set('s', section);
    for (const [k, v] of Object.entries(patch)) (v === null || v === '' ? n.delete(k) : n.set(k, v));
    setSp(n, { replace: true });
  };
  const go = (v: string) => setSp(new URLSearchParams({ s: v }), { replace: true });
  return (
    <div className="page">
      <div className="tabs scroll">
        {([['overview', 'home', 'Tổng quan'], ['tasks', 'tasks', 'Nhiệm vụ'], ['todo', 'ok', 'Cần xử lý'], ['declare', 'record', 'Khai báo công việc'], ['issues', 'warn', 'Báo cáo trở ngại']] as [string, string, string][]).map(([k, ic, l]) => (
          <button key={k} role="tab" aria-selected={section === k} className={section === k ? 'active' : ''} onClick={() => go(k)}><Icon name={ic} size={15} /> {l}</button>
        ))}
      </div>
      {section === 'overview' && <Overview go={go} />}
      {section === 'tasks' && <TaskList sp={sp} set={set} />}
      {section === 'todo' && <Todo sp={sp} set={set} />}
      {section === 'declare' && <Declare sp={sp} set={set} initialView={initial?.view} />}
      {section === 'issues' && <Issues sp={sp} set={set} />}
    </div>
  );
}

const FN: Record<string, string> = { production: 'Sản xuất / vận hành', planning: 'Kế hoạch', sales: 'Kinh doanh', warehouse: 'Kho vận', qa: 'Chất lượng', hr: 'Nhân sự', admin: 'Hành chính',
  finance: 'Tài chính – Kế toán', it: 'Kỹ thuật – CNTT', marketing: 'Marketing', hse: 'An toàn – Môi trường', security: 'Bảo vệ', cs: 'Chăm sóc khách hàng', other: 'Khác' };
const TIER: Record<number, string> = { 3: 'Điều hành', 4: 'Quản lý cấp cao', 5: 'Quản lý trung gian', 6: 'Quản lý trực tiếp', 7: 'Nhân sự thực thi' };

/** Trang chính: vai trò & phòng ban, tin phòng, bảng tin trở ngại / yêu cầu hỗ trợ. */
function Overview({ go }: { go: (s: string) => void }) {
  const { data: d, error, reload } = useLoad(() => get('/work/overview'), []);
  const [post0, setPost] = useState<{ title: string; body: string; pinned: boolean } | null>(null);
  const [err, setErr] = useState<string | null>(null);
  if (!d) return <><ErrorBox error={error} />{!error && <Loading />}</>;
  const duties: string[] = Array.isArray(d.me.job_role_duties) ? d.me.job_role_duties : [];
  const savePost = async () => { try { await post('/department-posts', post0); setPost(null); reload(); } catch (e: any) { setErr(e.message); } };
  return (
    <>
      <Card>
        <div className="small muted">Vai trò được giao</div>
        <b style={{ fontSize: 17 }}>{d.me.position || d.me.title || 'Chưa gán chức vụ'}</b>
        <div className="small muted">Tầng {d.me.tier} · {TIER[d.me.tier]}{d.me.job_grade ? ` · ${d.me.job_grade}` : ''}{d.me.job_role_name ? ` · ${d.me.job_role_name}` : ''}</div>
        {d.me.job_role_description && <p className="small" style={{ marginBottom: 4 }}>{d.me.job_role_description}</p>}
        {duties.length > 0 && <ul className="small" style={{ margin: '4px 0 0', paddingLeft: 18 }}>{duties.slice(0, 6).map((x: any, i: number) => <li key={i}>{typeof x === 'string' ? x : x.title || x.name}</li>)}</ul>}
        {!d.me.job_role_description && duties.length === 0 && <p className="small muted">Chưa có mô tả công việc</p>}
      </Card>
      <Card>
        <div className="small muted">Phòng ban đang làm việc</div>
        {d.department ? <>
          <b style={{ fontSize: 16 }}>{d.department.name}</b>
          <div className="small muted">{FN[d.department.function] || ''} · Trưởng phòng: {d.department.head_name || '—'} · {d.department.member_count} người</div>
        </> : <div className="small">Chưa thuộc phòng ban</div>}
        {d.groups.length > 0 && <div className="small" style={{ marginTop: 4 }}>Nhóm: {d.groups.map((g: any) => `${g.name}${g.leader_name ? ` (trưởng nhóm ${g.leader_name})` : ''}`).join(' · ')}</div>}
        <div className="cnt-row" style={{ marginTop: 6 }}>
          <span onClick={() => go('tasks')} style={{ cursor: 'pointer' }}>Đang mở <b>{d.tasks.open}</b></span>
          <span>Quá hạn <b style={{ color: d.tasks.overdue ? 'var(--red)' : undefined }}>{d.tasks.overdue}</b></span>
          {d.tasks.on_hold > 0 && <span>Treo chờ duyệt <b>{d.tasks.on_hold}</b></span>}
        </div>
      </Card>
      <div className="quick">
        <Link className="btn primary" to="/support/new"><Icon name="users" size={18} />Yêu cầu hỗ trợ</Link>
        <Link className="btn" to="/reports/new"><Icon name="warn" size={18} />Báo trở ngại</Link>
      </div>
      <div className="quick">
        <Link className="btn" to="/member-reports/new"><Icon name="shield" size={18} />Báo cáo / phản ánh</Link>
        {tierOf(useAuth().me) <= 6 ? <Link className="btn" to="/support/new?call=1"><Icon name="users" size={18} />Kêu gọi hỗ trợ</Link> : <span />}
      </div>

      <div className="row" style={{ display: 'flex', alignItems: 'center' }}>
        <div className="section-title" style={{ flex: 1 }}>Tin chính của phòng</div>
        {d.can_post && !post0 && <button className="btn sm" onClick={() => setPost({ title: '', body: '', pinned: false })}><Icon name="plus" size={14} />Đăng tin</button>}
      </div>
      {post0 && (
        <Card>
          <input placeholder="Tiêu đề" value={post0.title} onChange={(e) => setPost({ ...post0, title: e.target.value })} />
          <textarea placeholder="Nội dung thông báo" value={post0.body} onChange={(e) => setPost({ ...post0, body: e.target.value })} style={{ marginTop: 6 }} />
          <label className="check"><input type="checkbox" checked={post0.pinned} onChange={(e) => setPost({ ...post0, pinned: e.target.checked })} /> Ghim lên đầu</label>
          <ErrorBox error={err} />
          <div className="actions"><button className="btn" onClick={() => setPost(null)}>Hủy</button><button className="btn primary" disabled={post0.title.trim().length < 3} onClick={savePost}>Đăng & thông báo cả phòng</button></div>
        </Card>
      )}
      {d.posts.length === 0 && <div className="empty">Chưa có tin của phòng</div>}
      {d.posts.map((p: any) => (
        <Card key={p.id} className={p.pinned ? 'pinned' : ''}>
          <div className="row"><b style={{ flex: 1 }}>{p.pinned ? '📌 ' : ''}{p.title}</b><span className="small muted">{fmtD(p.created_at)}</span></div>
          {p.body && <p className="small" style={{ whiteSpace: 'pre-wrap', margin: '4px 0' }}>{p.body}</p>}
          <div className="small muted">{p.author_name}{p.department_id ? '' : ' · toàn công ty'}</div>
        </Card>
      ))}

      <div className="section-title">Thông báo trong nhóm & phòng</div>
      <Note>Trở ngại vừa được báo và nhiệm vụ đang cần hỗ trợ. Bấm vào yêu cầu hỗ trợ để tiếp nhận.</Note>
      {d.feed.length === 0 && <div className="empty">Không có trở ngại hay yêu cầu hỗ trợ mới</div>}
      {d.feed.map((x: any) => (
        <Card key={x.kind + x.id} to={x.kind === 'report' ? `/reports/${x.id}` : `/support/${x.id}`} className={x.kind === 'support' && x.status === 'open' && !x.mine ? 'pinned' : ''}>
          <div className="row">
            <span className={`ichip ${x.kind === 'report' ? 'red' : 'teal'}`} style={{ width: 32, height: 32 }}><Icon name={x.kind === 'report' ? 'warn' : 'users'} size={16} /></span>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div className="ellipsis"><b>{x.kind === 'report' ? 'Báo trở ngại' : 'Cần hỗ trợ'}</b> · {x.title}</div>
              <div className="small muted">{x.who}{x.group ? ` · ${x.group}` : ''} · {fmtDT(x.at)}{x.task ? ` · ${x.task}` : ''}</div>
            </div>
            {x.kind === 'report' ? <Badge tone={RP_TONE[x.status]}>{RP_STATUS[x.status]}</Badge> : <Badge tone={SR_STATUS[x.status]?.[1]}>{x.helpers}/{x.needed} người</Badge>}
          </div>
        </Card>
      ))}
    </>
  );
}

type P = { sp: URLSearchParams; set: (p: Record<string, string | null>) => void };

/** Mô tả vai trò trong khai báo công việc, theo tầng và chức năng. */
function declareGuide(view: string, tier: number, hr: boolean): string {
  if (view === 'mine') {
    if (tier >= 7) return 'Khai báo việc bạn đã làm nhưng chưa có trong nhiệm vụ được giao: việc phát sinh, việc thường ngày, việc được giao miệng/qua điện thoại. Quản lý trực tiếp (trưởng nhóm/tổ trưởng) phải phản hồi trong thời hạn; quá hạn hệ thống tự chuyển cấp.';
    if (tier === 6) return 'Khai báo việc của chính bạn ngoài nhiệm vụ được giao. Bản khai của trưởng nhóm do quản lý phòng ban xác nhận. Việc bạn giao miệng cho tổ viên, hãy khai việc nhanh để có căn cứ.';
    if (tier === 5) return 'Khai báo việc phát sinh của bạn (làm việc với khách, xử lý sự cố ngoài kế hoạch…). Bản khai của quản lý phòng ban do quản lý cấp cao xác nhận.';
    return 'Khai báo việc phát sinh của bạn để lưu vết điều hành. Bản khai của cấp điều hành chỉ để ghi nhận, không cần xác nhận.';
  }
  if (view === 'review') {
    if (hr) return 'Bản khai của nhân viên phòng nhân sự cần bạn xác nhận. Khi đối soát chấm công, đối chiếu thời gian khai với phiên làm việc, nghỉ phép và tăng ca.';
    if (tier === 6) return 'Bản khai của tổ viên trong nhóm bạn phụ trách. Xác nhận đúng số giờ thực tế, từ chối phải ghi lý do và căn cứ; tổ viên có quyền khiếu nại lên cấp trên.';
    if (tier === 5) return 'Bản khai của trưởng nhóm trong phòng và các bản khai bị chuyển cấp do trưởng nhóm phản hồi quá hạn.';
    return 'Bản khai của quản lý phòng ban và các bản khai bị chuyển cấp lên bạn.';
  }
  if (hr) return 'Toàn bộ bản khai trong phạm vi phòng nhân sự — dùng để đối soát chấm công, không thay quyết định xác nhận của quản lý trực tiếp.';
  if (tier <= 4) return 'Giám sát khai báo toàn đơn vị: tỷ lệ phản hồi đúng hạn, bản khai bị chuyển cấp, bị từ chối liên tiếp.';
  return 'Khai báo của các nhóm thuộc phòng ban bạn quản lý — theo dõi trưởng nhóm phản hồi đúng hạn và công bằng.';
}

function Declare({ sp, set, initialView }: P & { initialView?: string }) {
  const { me } = useAuth();
  const tier = tierOf(me);
  const hr = !!me?.authority?.hr_scoped;
  const views: [string, string][] = [['mine', 'Của tôi'], ['attendance', 'Chấm công'], ['calls', 'Nhật ký liên lạc']];
  if (tier <= 6) views.push(['review', 'Cần tôi xác nhận']);
  if (tier <= 5) views.push(['all', tier <= 4 ? 'Toàn đơn vị' : hr ? 'Phòng nhân sự' : 'Phòng ban của tôi']);
  const view = sp.get('view') || initialView || 'mine';
  const skip = view === 'calls' || view === 'attendance';
  const recs = useLoad(() => (skip ? Promise.resolve([]) : get('/work-records' + qs({ scope: view }))), [view]);
  const claims = useLoad(() => (view === 'all' || skip ? Promise.resolve([]) : get('/quick-claims')), [view]);
  const myId = me?.member_id;
  const cl = (claims.data || []).filter((c: any) => (view === 'review' ? c.status === 'pending' && c.counterpart_id === myId : !(c.status === 'pending' && c.counterpart_id === myId)));
  const items = [
    ...(recs.data || []).map((r: any) => ({ kind: 'rec', at: r.work_date || r.created_at, r })),
    ...cl.map((c: any) => ({ kind: 'claim', at: c.occurred_at, r: c })),
  ].sort((a, b) => String(b.at).localeCompare(String(a.at)));
  const waiting = items.filter((x) => (x.kind === 'rec' ? ['submitted', 'disputed'].includes(x.r.status) : x.r.status === 'pending')).length;
  return (
    <>
      <div className="quick">
        <Link className="btn primary" to="/work-records/new"><Icon name="record" size={18} />Tự khai báo việc đã làm</Link>
        <Link className="btn" to="/contacts"><Icon name="phone" size={18} />Gọi / nhắn đồng nghiệp</Link>
      </div>
      {views.length > 1 && <Tabs value={view} onChange={(v) => set({ view: v })} tabs={views} />}
      {view === 'attendance' ? <AttendanceList /> : view === 'calls' ? <><Note>Cuộc gọi trong app với đồng nghiệp. Việc được giao trong cuộc gọi, bấm <b>Khai báo công việc</b> để tạo bản khai (kèm ghi âm nếu có). Nhật ký tự xóa sau 30 ngày.</Note><CallLog compact /></> : <>
      <Note>{declareGuide(view, tier, hr)}</Note>
      <ErrorBox error={recs.error || claims.error} />
      {(recs.loading || claims.loading) && !recs.data && <Loading />}
      {recs.data && <div className="small muted">{items.length} khai báo{waiting ? ` · ${waiting} đang chờ xác nhận` : ''}</div>}
      {recs.data && items.length === 0 && <Empty>{view === 'review' ? 'Không có khai báo nào chờ bạn xác nhận' : 'Chưa có khai báo'}</Empty>}
      {items.map((x) => (x.kind === 'rec' ? <RecCard key={'r' + x.r.id} r={x.r} showName={view !== 'mine'} /> : <ClaimCard key={'c' + x.r.id} c={x.r} myId={myId} />))}
      </>}
    </>
  );
}

function RecCard({ r, showName }: { r: any; showName: boolean }) {
  return (
    <Card to={`/work-records/${r.id}`}>
      <div className="row"><span className="title" style={{ flex: 1 }}>{r.title}</span><Badge tone={WR_TONE[r.status]}>{WR_STATUS[r.status]}</Badge></div>
      <div className="small muted" style={{ marginTop: 4 }}>{r.record_type === 'routine' ? 'Việc thường ngày' : 'Tự khai báo'} · {WR_TYPE[r.record_type]} · {fmtD(r.work_date)} · {hours(r.claimed_minutes)}{showName ? ` · ${r.employee_name}` : ''}</div>
      <div className="chip-row">
        {r.overdue && <Badge tone="red">Quá hạn phản hồi</Badge>}
        {r.escalation_level > 0 && <Badge tone="red">Đã chuyển cấp {r.escalation_level}</Badge>}
        {r.consecutive_rejections > 0 && <Badge tone="amber">Từ chối liên tiếp: {r.consecutive_rejections}</Badge>}
        {r.overlap_warning && <Badge tone="amber">Trùng thời gian</Badge>}
        {(r.status === 'submitted' || r.status === 'disputed') && <span className="small muted">Hạn phản hồi {fmtDT(r.review_due_at)} · {r.reviewer_name}</span>}
      </div>
    </Card>
  );
}

function ClaimCard({ c, myId }: { c: any; myId?: string | null }) {
  const needMe = c.status === 'pending' && c.counterpart_id === myId;
  return (
    <Card to={`/quick/${c.id}`} className={needMe ? 'pinned' : ''}>
      <div className="row"><span className="title" style={{ flex: 1 }}>{c.title}</span><Badge tone={CLAIM_TONE[c.status]}>{needMe ? 'Cần bạn xác nhận' : CLAIM_STATUS[c.status]}</Badge></div>
      <div className="small muted">Khai việc nhanh · {CHANNEL[c.channel]} · {fmtDT(c.occurred_at)} · {c.manager_name} → {c.assignee_name}</div>
    </Card>
  );
}

/** Mô tả vai trò trong xử lý trở ngại. */
function issueGuide(scope: string, done: boolean, tier: number, fn: string | null): string {
  if (scope === 'mine') return done
    ? 'Trở ngại bạn báo đã được xử lý. Mục "Đã xử lý, chờ xác nhận" cần bạn kiểm tra thực tế và xác nhận hoặc mở lại.'
    : 'Trở ngại bạn đã báo đang được xử lý. Theo dõi người đang giữ và hạn của từng khâu; quá hạn hệ thống tự chuyển cấp.';
  if (scope === 'oversight') return 'Quyết định xử lý của quản lý cấp dưới. Bạn có thể thay đổi (đổi phòng ban/đổi người xử lý); không thay đổi là mặc nhiên chấp nhận và bạn chịu trách nhiệm cuối cùng.';
  if (scope === 'all') return done ? 'Trở ngại đã xử lý trong toàn đơn vị — dùng để rà soát nguyên nhân lặp lại và thời gian khắc phục.' : 'Toàn bộ trở ngại đang mở trong đơn vị, ưu tiên mục quá hạn và có rủi ro an toàn.';
  if (done) return 'Trở ngại bạn đã tiếp nhận/xử lý xong — lưu làm căn cứ đánh giá thời gian phản hồi.';
  if (tier === 6) return 'Trở ngại do tổ viên báo lên. Trưởng nhóm tiếp nhận trước: tự giải quyết bằng cách giao việc, chuyển phòng ban hỗ trợ (kỹ thuật, kho, bảo trì…), hoặc chuyển lên quản lý phòng ban.';
  if (fn && ['it', 'warehouse', 'hse', 'qa', 'security'].includes(fn)) return 'Trở ngại được chuyển đến phòng ban của bạn. Xác nhận tiếp nhận, phân người xử lý và báo kết quả để người báo xác nhận.';
  return 'Trở ngại cần bạn quyết định: chuyển phòng ban chức năng, giao việc khắc phục hoặc chuyển lên cấp trên.';
}

function Issues({ sp, set }: P) {
  const { me } = useAuth();
  const tier = tierOf(me);
  const isMgr = me?.role !== 'employee' || tier <= 6;
  const st = sp.get('st') || 'open';
  const scopes: [string, string][] = isMgr ? [['handling', 'Cần tôi xử lý'], ...(tier <= 5 ? [['oversight', 'Cấp dưới đã quyết định'] as [string, string]] : []), ['mine', 'Tôi báo cáo'], ...(tier <= 4 ? [['all', 'Toàn đơn vị'] as [string, string]] : [])] : [['mine', 'Tôi báo cáo']];
  const scope = sp.get('view') || scopes[0][0];
  const open = useLoad(() => get('/workplace-reports' + qs({ scope, status: RP_OPEN })), [scope]);
  const done = useLoad(() => get('/workplace-reports' + qs({ scope, status: RP_DONE })), [scope]);
  const cur = st === 'open' ? open : done;
  const overdue = (open.data || []).filter((w: any) => w.is_overdue).length;
  return (
    <>
      <div className="quick">
        <Link className="btn primary" to="/reports/new"><Icon name="warn" size={18} />Báo trở ngại</Link>
        {isMgr ? <Link className="btn" to="/tech"><Icon name="wrench" size={18} />Bảng kỹ thuật</Link> : <Link className="btn" to="/conduct/new"><Icon name="shield" size={18} />Phản ánh hành vi</Link>}
      </div>
      {scopes.length > 1 && <div className="filters"><Select value={scope} onChange={(v) => set({ view: v })} options={scopes} aria-label="Phạm vi" /></div>}
      <Tabs value={st} onChange={(v) => set({ st: v })} tabs={[
        ['open', <>Chưa xử lý {open.data ? <Badge tone={overdue ? 'red' : 'blue'}>{open.data.length}</Badge> : null}</>],
        ['done', <>Đã xử lý {done.data ? <Badge tone="gray">{done.data.length}</Badge> : null}</>],
      ]} />
      <Note>{issueGuide(scope, st === 'done', tier, me?.authority?.dept_function || null)}</Note>
      {st === 'open' && overdue > 0 && <div className="alert warn small">{overdue} trở ngại đã quá hạn khâu hiện tại.</div>}
      <ErrorBox error={cur.error} />
      {cur.loading && !cur.data && <Loading />}
      {cur.data && cur.data.length === 0 && <Empty>{st === 'open' ? 'Không có trở ngại đang chờ xử lý' : 'Chưa có trở ngại đã xử lý'}</Empty>}
      {cur.data?.map((w: any) => <ReportCard key={w.id} w={w} />)}
    </>
  );
}

/** Cần tôi xử lý: ra quyết định, bàn giao (liên phòng ban & bên ngoài chờ duyệt), giấy phép, nghỉ phép. */
function Todo({ sp, set }: P) {
  const { me } = useAuth();
  const t = sp.get('t') || 'decision';
  const canIssue = isHRRole(me?.role) || tierOf(me) <= 4;
  const ex = useLoad(() => get('/handover-exceptions'), []);
  const sc = useLoad(() => get('/support-requests?scope=to_confirm'), []);
  return (
    <>
      <Tabs value={t} onChange={(v) => set({ t: v, scope: null, status: null, review: null })} tabs={[['decision', <>Quyết định {sc.data?.length ? <Badge tone="amber">{sc.data.length}</Badge> : null}</>], ['report', 'Báo cáo'], ['handover', <>Bàn giao {ex.data?.length ? <Badge tone="amber">{ex.data.length}</Badge> : null}</>], ['permit', 'Giấy phép'], ['leave', 'Nghỉ phép']]} />
      {t === 'decision' && <>
        <div className="quick">{canIssue ? <Link className="btn primary" to="/hr/decisions"><Icon name="decision" size={18} />Ra quyết định nhân sự</Link> : <span />}<span /></div>
        <Note>{canIssue ? 'Quyết định bạn đã ban hành và quyết định cần bạn xác nhận bàn giao.' : 'Quyết định cần bạn xác nhận bàn giao hoặc liên quan đến bạn.'}</Note>
        {sc.data && sc.data.length > 0 && <>
          <div className="section-title">Xác nhận hỗ trợ ({sc.data.length})</div>
          {sc.data.map((r: any) => (
            <Card key={r.id} to={`/support/${r.id}`} className="pinned">
              <div className="row"><b style={{ flex: 1 }}>{r.code} · {r.title}</b><Badge tone="amber">{r.responses.filter((x: any) => x.status === 'done').length} chờ xác nhận</Badge></div>
              <div className="small muted">{r.responses.filter((x: any) => x.status === 'done').map((x: any) => `${x.helper_name} (${x.minutes || 0}p)`).join(', ')}</div>
            </Card>
          ))}
          <div className="section-title">Quyết định nhân sự</div>
        </>}
        <DecisionList scope="manage" />
      </>}
      {t === 'report' && <MemberReportList />}
      {t === 'handover' && <>
        {ex.data && ex.data.length > 0 && <>
          <div className="section-title">Bàn giao bên ngoài chờ tôi duyệt giải trình ({ex.data.length})</div>
          {ex.data.map((e: any) => (
            <Card key={e.id} to={`/tasks/${e.task_id}`} className="pinned">
              <div className="row"><b style={{ flex: 1 }}>{e.task_code} - {e.task_title}</b><Badge tone={e.waiting_hours > 24 ? 'red' : 'amber'}>chờ {Math.round(e.waiting_hours)} giờ</Badge></div>
              <div className="small muted">{e.submitted_by_name} · người nhận {e.recipient_name}</div><div className="small">{e.reason}</div>
            </Card>
          ))}
        </>}
        <div className="section-title">Bàn giao liên phòng ban</div>
        <HandoverItems />
      </>}
      {t === 'permit' && <PermitList sp={sp} set={set} />}
      {t === 'leave' && <><div className="quick"><Link className="btn primary" to="/leaves/new"><Icon name="leave" size={18} />Xin nghỉ phép</Link><span /></div><LeaveList sp={sp} set={set} /></>}
    </>
  );
}
