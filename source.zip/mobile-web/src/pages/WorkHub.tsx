import { Link, useSearchParams } from 'react-router-dom';
import { get, qs } from '../api';
import { tierOf, useAuth } from '../auth';
import { Badge, Card, Empty, ErrorBox, Loading, Select, Tabs, useLoad } from '../ui';
import { Icon } from '../icons';
import { CHANNEL, CLAIM_STATUS, CLAIM_TONE, WR_STATUS, WR_TONE, WR_TYPE, fmtD, fmtDT, hours } from '../labels';
import { ReportCard } from './Work';

/** Trở ngại chưa xử lý xong (đang ở một khâu nào đó của quy trình). */
export const RP_OPEN = 'submitted,manager_review,assigned,acknowledged,in_progress,waiting,reopened,escalated,task_assigned';
/** Đã xử lý: đã khắc phục chờ người báo xác nhận, đã đóng, hoặc kết luận không khắc phục được. */
export const RP_DONE = 'resolved_pending,closed,cannot_fix';

/**
 * Phần Công việc (v8): hai mục chính.
 *  1. Khai báo công việc — thống nhất Tự khai báo, việc thường ngày và khai việc giao qua điện thoại/tin nhắn.
 *  2. Báo cáo trở ngại — hai tầng con Chưa xử lý / Đã xử lý.
 * Nội dung, phạm vi và mô tả thay đổi theo tầng vị trí (3–7) và chức năng phòng ban của người dùng.
 */
export default function WorkHub({ initial }: { initial?: { section?: string; view?: string } }) {
  const [sp, setSp] = useSearchParams();
  const section = sp.get('s') || initial?.section || 'declare';
  const set = (patch: Record<string, string | null>) => {
    const n = new URLSearchParams(sp);
    n.delete('tab');
    for (const [k, v] of Object.entries(patch)) (v === null || v === '' ? n.delete(k) : n.set(k, v));
    setSp(n, { replace: true });
  };
  return (
    <div className="page">
      <Tabs value={section} onChange={(v) => set({ s: v, view: null, st: null })}
        tabs={[['declare', <><Icon name="record" size={16} /> Khai báo công việc</>], ['issues', <><Icon name="warn" size={16} /> Báo cáo trở ngại</>]]} />
      {section === 'declare' ? <Declare sp={sp} set={set} initialView={initial?.view} /> : <Issues sp={sp} set={set} />}
      <div className="chip-row" style={{ marginTop: 16 }}>
        <span className="small muted">Mục khác:</span>
        <Link className="btn sm" to="/tasks"><Icon name="tasks" size={14} />Nhiệm vụ</Link>
        <Link className="btn sm" to="/tasks?tab=permits"><Icon name="permit" size={14} />Giấy phép</Link>
        <Link className="btn sm" to="/tasks?tab=leaves"><Icon name="leave" size={14} />Nghỉ phép</Link>
        <Link className="btn sm" to="/my-time"><Icon name="clock" size={14} />Thời gian của tôi</Link>
      </div>
    </div>
  );
}

type P = { sp: URLSearchParams; set: (p: Record<string, string | null>) => void };

/** Mô tả vai trò trong khai báo công việc, theo tầng và chức năng. */
function declareGuide(view: string, tier: number, hr: boolean): string {
  if (view === 'mine') {
    if (tier >= 7) return 'Khai báo việc bạn đã làm nhưng chưa có trong nhiệm vụ được giao: việc phát sinh, việc thường ngày, việc được giao miệng/qua điện thoại. Quản lý trực tiếp (trưởng nhóm/tổ trưởng) phải phản hồi trong thời hạn; quá hạn hệ thống tự chuyển cấp.';
    if (tier === 6) return 'Khai báo việc của chính bạn ngoài nhiệm vụ được giao. Bản khai của trưởng nhóm do quản lý phòng ban xác nhận. Việc bạn giao miệng cho tổ viên, hãy khai việc nhanh để có căn cứ.';
    if (tier === 5) return 'Khai báo việc phát sinh của bạn (làm việc với khách, xử lý sự cố ngoài kế hoạch…). Bản khai của quản lý phòng ban do quản lý cấp cao xác nhận.';
    return 'Khai báo việc phát sinh của bạn để lưu vết điều hành. Bản khai của cấp điều hành chỉ để ghi nhận, không cần xác nhận.';
  }
  if (view === 'review') {
    if (hr) return 'Bản khai của nhân viên phòng nhân sự cần bạn xác nhận. Khi đối soát chấm công, đối chiếu thời gian khai với phiên làm việc, nghỉ phép và tăng ca.';
    if (tier === 6) return 'Bản khai của tổ viên trong nhóm bạn phụ trách. Xác nhận đúng số giờ thực tế, từ chối phải ghi lý do và căn cứ; tổ viên có quyền khiếu nại lên cấp trên.';
    if (tier === 5) return 'Bản khai của trưởng nhóm trong phòng và các bản khai bị chuyển cấp do trưởng nhóm phản hồi quá hạn.';
    return 'Bản khai của quản lý phòng ban và các bản khai bị chuyển cấp lên bạn.';
  }
  if (hr) return 'Toàn bộ bản khai trong phạm vi phòng nhân sự — dùng để đối soát chấm công, không thay quyết định xác nhận của quản lý trực tiếp.';
  if (tier <= 4) return 'Giám sát khai báo toàn đơn vị: tỷ lệ phản hồi đúng hạn, bản khai bị chuyển cấp, bị từ chối liên tiếp.';
  return 'Khai báo của các nhóm thuộc phòng ban bạn quản lý — theo dõi trưởng nhóm phản hồi đúng hạn và công bằng.';
}

function Declare({ sp, set, initialView }: P & { initialView?: string }) {
  const { me } = useAuth();
  const tier = tierOf(me);
  const hr = !!me?.authority?.hr_scoped;
  const views: [string, string][] = [['mine', 'Của tôi']];
  if (tier <= 6) views.push(['review', 'Cần tôi xác nhận']);
  if (tier <= 5) views.push(['all', tier <= 4 ? 'Toàn đơn vị' : hr ? 'Phòng nhân sự' : 'Phòng ban của tôi']);
  const view = sp.get('view') || initialView || 'mine';
  const recs = useLoad(() => get('/work-records' + qs({ scope: view })), [view]);
  const claims = useLoad(() => (view === 'all' ? Promise.resolve([]) : get('/quick-claims')), [view]);
  const myId = me?.member_id;
  const cl = (claims.data || []).filter((c: any) => (view === 'review' ? c.status === 'pending' && c.counterpart_id === myId : !(c.status === 'pending' && c.counterpart_id === myId)));
  const items = [
    ...(recs.data || []).map((r: any) => ({ kind: 'rec', at: r.work_date || r.created_at, r })),
    ...cl.map((c: any) => ({ kind: 'claim', at: c.occurred_at, r: c })),
  ].sort((a, b) => String(b.at).localeCompare(String(a.at)));
  const waiting = items.filter((x) => (x.kind === 'rec' ? ['submitted', 'disputed'].includes(x.r.status) : x.r.status === 'pending')).length;
  return (
    <>
      <div className="quick">
        <Link className="btn primary" to="/work-records/new"><Icon name="record" size={18} />Tự khai báo việc đã làm</Link>
        <Link className="btn" to="/quick/new"><Icon name="headset" size={18} />Việc giao qua điện thoại</Link>
      </div>
      <div className="quick">
        <Link className="btn" to="/work-records/new?type=routine"><Icon name="list" size={18} />Việc thường ngày</Link>
        {tier <= 6 ? <Link className="btn" to="/overtime/new"><Icon name="timer" size={18} />Đề nghị tăng ca</Link> : <Link className="btn" to="/my-time"><Icon name="clock" size={18} />Giờ làm của tôi</Link>}
      </div>
      {views.length > 1 && <Tabs value={view} onChange={(v) => set({ view: v })} tabs={views} />}
      <p className="small muted">{declareGuide(view, tier, hr)}</p>
      <ErrorBox error={recs.error || claims.error} />
      {(recs.loading || claims.loading) && !recs.data && <Loading />}
      {recs.data && <div className="small muted">{items.length} khai báo{waiting ? ` · ${waiting} đang chờ xác nhận` : ''}</div>}
      {recs.data && items.length === 0 && <Empty>{view === 'review' ? 'Không có khai báo nào chờ bạn xác nhận' : 'Chưa có khai báo'}</Empty>}
      {items.map((x) => (x.kind === 'rec' ? <RecCard key={'r' + x.r.id} r={x.r} showName={view !== 'mine'} /> : <ClaimCard key={'c' + x.r.id} c={x.r} myId={myId} />))}
    </>
  );
}

function RecCard({ r, showName }: { r: any; showName: boolean }) {
  return (
    <Card to={`/work-records/${r.id}`}>
      <div className="row"><span className="title" style={{ flex: 1 }}>{r.title}</span><Badge tone={WR_TONE[r.status]}>{WR_STATUS[r.status]}</Badge></div>
      <div className="small muted" style={{ marginTop: 4 }}>{r.record_type === 'routine' ? 'Việc thường ngày' : 'Tự khai báo'} · {WR_TYPE[r.record_type]} · {fmtD(r.work_date)} · {hours(r.claimed_minutes)}{showName ? ` · ${r.employee_name}` : ''}</div>
      <div className="chip-row">
        {r.overdue && <Badge tone="red">Quá hạn phản hồi</Badge>}
        {r.escalation_level > 0 && <Badge tone="red">Đã chuyển cấp {r.escalation_level}</Badge>}
        {r.consecutive_rejections > 0 && <Badge tone="amber">Từ chối liên tiếp: {r.consecutive_rejections}</Badge>}
        {r.overlap_warning && <Badge tone="amber">Trùng thời gian</Badge>}
        {(r.status === 'submitted' || r.status === 'disputed') && <span className="small muted">Hạn phản hồi {fmtDT(r.review_due_at)} · {r.reviewer_name}</span>}
      </div>
    </Card>
  );
}

function ClaimCard({ c, myId }: { c: any; myId?: string | null }) {
  const needMe = c.status === 'pending' && c.counterpart_id === myId;
  return (
    <Card to={`/quick/${c.id}`} className={needMe ? 'pinned' : ''}>
      <div className="row"><span className="title" style={{ flex: 1 }}>{c.title}</span><Badge tone={CLAIM_TONE[c.status]}>{needMe ? 'Cần bạn xác nhận' : CLAIM_STATUS[c.status]}</Badge></div>
      <div className="small muted">Khai việc nhanh · {CHANNEL[c.channel]} · {fmtDT(c.occurred_at)} · {c.manager_name} → {c.assignee_name}</div>
    </Card>
  );
}

/** Mô tả vai trò trong xử lý trở ngại. */
function issueGuide(scope: string, done: boolean, tier: number, fn: string | null): string {
  if (scope === 'mine') return done
    ? 'Trở ngại bạn báo đã được xử lý. Mục "Đã xử lý, chờ xác nhận" cần bạn kiểm tra thực tế và xác nhận hoặc mở lại.'
    : 'Trở ngại bạn đã báo đang được xử lý. Theo dõi người đang giữ và hạn của từng khâu; quá hạn hệ thống tự chuyển cấp.';
  if (scope === 'oversight') return 'Quyết định xử lý của quản lý cấp dưới. Bạn có thể thay đổi (đổi bộ phận/đổi người xử lý); không thay đổi là mặc nhiên chấp nhận và bạn chịu trách nhiệm cuối cùng.';
  if (scope === 'all') return done ? 'Trở ngại đã xử lý trong toàn đơn vị — dùng để rà soát nguyên nhân lặp lại và thời gian khắc phục.' : 'Toàn bộ trở ngại đang mở trong đơn vị, ưu tiên mục quá hạn và có rủi ro an toàn.';
  if (done) return 'Trở ngại bạn đã tiếp nhận/xử lý xong — lưu làm căn cứ đánh giá thời gian phản hồi.';
  if (tier === 6) return 'Trở ngại do tổ viên báo lên. Trưởng nhóm tiếp nhận trước: tự giải quyết bằng cách giao việc, chuyển bộ phận hỗ trợ (kỹ thuật, kho, bảo trì…), hoặc chuyển lên quản lý phòng ban.';
  if (fn && ['it', 'warehouse', 'hse', 'qa', 'security'].includes(fn)) return 'Trở ngại được chuyển đến bộ phận của bạn. Xác nhận tiếp nhận, phân người xử lý và báo kết quả để người báo xác nhận.';
  return 'Trở ngại cần bạn quyết định: chuyển bộ phận chức năng, giao việc khắc phục hoặc chuyển lên cấp trên.';
}

function Issues({ sp, set }: P) {
  const { me } = useAuth();
  const tier = tierOf(me);
  const isMgr = me?.role !== 'employee' || tier <= 6;
  const st = sp.get('st') || 'open';
  const scopes: [string, string][] = isMgr ? [['handling', 'Cần tôi xử lý'], ...(tier <= 5 ? [['oversight', 'Cấp dưới đã quyết định'] as [string, string]] : []), ['mine', 'Tôi báo cáo'], ...(tier <= 4 ? [['all', 'Toàn đơn vị'] as [string, string]] : [])] : [['mine', 'Tôi báo cáo']];
  const scope = sp.get('view') || scopes[0][0];
  const open = useLoad(() => get('/workplace-reports' + qs({ scope, status: RP_OPEN })), [scope]);
  const done = useLoad(() => get('/workplace-reports' + qs({ scope, status: RP_DONE })), [scope]);
  const cur = st === 'open' ? open : done;
  const overdue = (open.data || []).filter((w: any) => w.is_overdue).length;
  return (
    <>
      <div className="quick">
        <Link className="btn primary" to="/reports/new"><Icon name="warn" size={18} />Báo trở ngại</Link>
        {isMgr ? <Link className="btn" to="/tech"><Icon name="wrench" size={18} />Bảng kỹ thuật</Link> : <Link className="btn" to="/conduct/new"><Icon name="shield" size={18} />Phản ánh hành vi</Link>}
      </div>
      {scopes.length > 1 && <div className="filters"><Select value={scope} onChange={(v) => set({ view: v })} options={scopes} aria-label="Phạm vi" /></div>}
      <Tabs value={st} onChange={(v) => set({ st: v })} tabs={[
        ['open', <>Chưa xử lý {open.data ? <Badge tone={overdue ? 'red' : 'blue'}>{open.data.length}</Badge> : null}</>],
        ['done', <>Đã xử lý {done.data ? <Badge tone="gray">{done.data.length}</Badge> : null}</>],
      ]} />
      <p className="small muted">{issueGuide(scope, st === 'done', tier, me?.authority?.dept_function || null)}</p>
      {st === 'open' && overdue > 0 && <div className="alert warn small">{overdue} trở ngại đã quá hạn khâu hiện tại.</div>}
      <ErrorBox error={cur.error} />
      {cur.loading && !cur.data && <Loading />}
      {cur.data && cur.data.length === 0 && <Empty>{st === 'open' ? 'Không có trở ngại đang chờ xử lý' : 'Chưa có trở ngại đã xử lý'}</Empty>}
      {cur.data?.map((w: any) => <ReportCard key={w.id} w={w} />)}
    </>
  );
}
