import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { get, qs } from '../api';
import { isHRRole, tierOf, useAuth } from '../auth';
import { Avatar, Badge, Card, Empty, ErrorBox, Header, Loading, Sheet, Tabs, useLoad, Note } from '../ui';
import { Icon } from '../icons';
import { DECISION_STATUS, DECISION_TONE, DECISION_TYPE, fmtD, fmtDT } from '../labels';
import { DecisionForm } from './AdminMembers';

const TIER_NAME: Record<number, string> = { 3: 'Điều hành', 4: 'Quản lý cấp cao', 5: 'Quản lý trung gian', 6: 'Quản lý trực tiếp', 7: 'Nhân sự thực thi' };

/** Danh sách quyết định (dùng ở trang Quyết định và mục "Cần tôi xử lý"). */
export function DecisionList({ scope }: { scope: string }) {
  const { data, error, loading } = useLoad(() => get('/decisions' + qs({ scope })), [scope]);
  return (
    <>
      <ErrorBox error={error} />
      {loading && !data && <Loading />}
      {data && data.length === 0 && <Empty>Chưa có quyết định</Empty>}
      {data?.map((d: any) => (
        <Card key={d.id} to={`/decisions/${d.id}`} className={['handover', 'pending_confirm'].includes(d.status) ? 'pinned' : ''}>
          <div className="row"><b>{d.code}</b><span style={{ flex: 1 }}> {d.member_name}</span><Badge tone={DECISION_TONE[d.status]}>{DECISION_STATUS[d.status]}</Badge></div>
          <div className="small">{DECISION_TYPE[d.decision_type]} · hiệu lực {fmtD(d.effective_date)}</div>
          <div className="small muted">Hạn bàn giao {fmtDT(d.handover_deadline)} · xác nhận: {d.confirmer_name}</div>
        </Card>
      ))}
    </>
  );
}

/**
 * Quyết định nhân sự (v10): trang chính là danh sách nhân sự theo các tầng và tính năng ra quyết định
 * (điều chuyển / thăng chức / thôi việc). Ban điều hành, quản lý cấp cao (tầng 3–4) và Quản lý nhân sự ra quyết định.
 */
export default function Decisions() {
  const { me } = useAuth();
  const nav = useNavigate();
  const canIssue = isHRRole(me?.role) || tierOf(me) <= 4;
  const [tab, setTab] = useState(canIssue ? 'people' : 'mine');
  const [q, setQ] = useState('');
  const [closed, setClosed] = useState<Record<number, boolean>>({});
  const [pick, setPick] = useState<any>(null);
  const [form, setForm] = useState<{ m: any; type: string } | null>(null);
  const members = useLoad(() => (canIssue ? get('/company/members') : Promise.resolve([])), [canIssue]);
  const depts = useLoad(() => (canIssue ? get('/company/departments') : Promise.resolve([])), [canIssue]);
  const active = (members.data || []).filter((m: any) => m.status === 'active');
  const tierOfM = (m: any) => m.tier || (m.role === 'owner' ? 3 : m.role === 'admin' ? 4 : m.role === 'employee' ? 7 : 5);
  const list = active.filter((m: any) => !q || m.name.toLowerCase().includes(q.toLowerCase()) || (m.department_name || '').toLowerCase().includes(q.toLowerCase()));
  const tabs: [string, string][] = canIssue ? [['people', 'Nhân sự các tầng'], ['manage', 'Quyết định đã ban hành'], ['mine', 'Của tôi']] : [['mine', 'Của tôi'], ['manage', 'Tôi xác nhận']];
  return (
    <>
      <Header title="Quyết định nhân sự" back />
      <div className="page">
        <Tabs value={tab} onChange={setTab} tabs={tabs} />
        {tab === 'people' && <>
          <Note>Chọn nhân sự để ra quyết định điều chuyển, thăng chức (đổi chức vụ/tầng) hoặc thôi việc. Người nhận quyết định bàn giao việc trước hạn; quyết định có hiệu lực khi người xác nhận duyệt bàn giao.</Note>
          <input placeholder="Tìm theo tên hoặc phòng ban…" value={q} onChange={(e) => setQ(e.target.value)} />
          <ErrorBox error={members.error} />{members.loading && !members.data && <Loading />}
          {[3, 4, 5, 6, 7].map((t) => {
            const items = list.filter((m: any) => tierOfM(m) === t);
            if (!items.length) return null;
            return (
              <div key={t}>
                <button className="grp-head" onClick={() => setClosed({ ...closed, [t]: !closed[t] })} aria-expanded={!closed[t]}>
                  <Icon name={closed[t] ? 'chevron' : 'down'} size={18} /><b>Tầng {t} · {TIER_NAME[t]}</b><span className="n">{items.length} người</span>
                </button>
                {!closed[t] && items.map((m: any) => (
                  <Card key={m.id} onClick={() => setPick(m)}>
                    <div className="row"><Avatar userId={m.user_id} name={m.name} has={m.has_avatar} />
                      <div style={{ flex: 1, minWidth: 0 }}><b>{m.name}</b><div className="small muted ellipsis">{m.position_name || m.title || '—'}{m.department_name ? ` · ${m.department_name}` : ''}</div></div>
                      <Icon name="decision" size={18} /></div>
                  </Card>
                ))}
              </div>
            );
          })}
        </>}
        {tab !== 'people' && <DecisionList scope={tab} />}
      </div>
      <Sheet open={!!pick} onClose={() => setPick(null)} title={pick?.name || ''}>
        {pick && <>
          <div className="small muted">{pick.position_name ? `Tầng ${pick.tier} · ${pick.position_name}` : pick.title}{pick.department_name ? ` · ${pick.department_name}` : ''}</div>
          {pick.id === me?.member_id || pick.role === 'owner' ? <div className="alert info small">Không ra quyết định cho chính mình hoặc Chủ doanh nghiệp.</div> : (
            <div className="actions stack">
              <button className="btn" onClick={() => setForm({ m: pick, type: 'transfer' })}><Icon name="transfer" size={18} />Điều chuyển</button>
              <button className="btn" onClick={() => setForm({ m: pick, type: 'promotion' })}><Icon name="promote" size={18} />Thăng chức / đổi chức vụ</button>
              <button className="btn danger" onClick={() => setForm({ m: pick, type: 'termination' })}><Icon name="terminate" size={18} />Thôi việc</button>
            </div>
          )}
        </>}
      </Sheet>
      <Sheet open={!!form} onClose={() => setForm(null)} title={form ? `${DECISION_TYPE[form.type]}: ${form.m.name}` : ''}>
        {form && <DecisionForm m={form.m} type={form.type} members={active} depts={depts.data || []} onDone={(id) => { setForm(null); setPick(null); nav(`/decisions/${id}`); }} />}
      </Sheet>
    </>
  );
}
