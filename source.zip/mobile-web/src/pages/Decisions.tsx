import { useState } from 'react';
import { get, qs } from '../api';
import { isHRRole, useAuth } from '../auth';
import { Badge, Card, Empty, ErrorBox, Header, Loading, Tabs, useLoad } from '../ui';
import { DECISION_STATUS, DECISION_TONE, DECISION_TYPE, fmtD, fmtDT } from '../labels';

export default function Decisions() {
  const { me } = useAuth();
  const [scope, setScope] = useState(isHRRole(me?.role) ? 'manage' : 'mine');
  const { data, error, loading } = useLoad(() => get('/decisions' + qs({ scope })), [scope]);
  return (
    <>
      <Header title="Quyết định nhân sự" back="/hr" />
      <div className="page">
        <Tabs value={scope} onChange={setScope} tabs={[['mine', 'Của tôi'], ['manage', isHRRole(me?.role) ? 'Toàn công ty' : 'Tôi xác nhận']]} />
        {isHRRole(me?.role) && <p className="small muted">Ra quyết định điều chuyển, thăng chức, thôi việc trong mục Thành viên (bấm vào từng người).</p>}
        <ErrorBox error={error} />
        {loading && !data && <Loading />}
        {data && data.length === 0 && <Empty>Chưa có quyết định</Empty>}
        {data?.map((d: any) => (
          <Card key={d.id} to={`/decisions/${d.id}`}>
            <div className="row"><b>{d.code}</b><span style={{ flex: 1 }}>{d.member_name}</span><Badge tone={DECISION_TONE[d.status]}>{DECISION_STATUS[d.status]}</Badge></div>
            <div className="small">{DECISION_TYPE[d.decision_type]} · hiệu lực {fmtD(d.effective_date)}</div>
            <div className="small muted">Hạn bàn giao {fmtDT(d.handover_deadline)} · xác nhận: {d.confirmer_name}</div>
          </Card>
        ))}
      </div>
    </>
  );
}
