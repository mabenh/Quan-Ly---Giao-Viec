export const ROLE: Record<string, string> = { owner: 'Chủ doanh nghiệp', admin: 'Quản trị', manager: 'Quản lý', employee: 'Nhân viên', handler: 'Bộ phận xử lý', reviewer: 'Reviewer độc lập', hr: 'Quản lý nhân sự' };
export const TASK_STATUS: Record<string, string> = { not_started: 'Chưa bắt đầu', in_progress: 'Đang thực hiện', pending_review: 'Chờ nghiệm thu', completed: 'Hoàn thành', revision_requested: 'Yêu cầu chỉnh sửa', cancelled: 'Đã hủy' };
export const TASK_TONE: Record<string, string> = { not_started: 'gray', in_progress: 'blue', pending_review: 'amber', completed: 'green', revision_requested: 'red', cancelled: 'gray' };
export const COMPLEXITY: Record<string, string> = { simple: 'Đơn giản', medium: 'Trung bình', complex: 'Phức tạp', very_complex: 'Rất phức tạp' };
export const REQ: Record<string, string> = { normal: 'Thông thường', high: 'Cao', very_high: 'Rất cao' };
export const PRIORITY: Record<string, string> = { low: 'Thấp', normal: 'Bình thường', high: 'Cao', urgent: 'Khẩn' };
export const UNEXPECTED_CAT: Record<string, string> = { ad_hoc: 'Đột xuất', urgent: 'Khẩn cấp', scope_addition: 'Phát sinh bổ sung', external_support: 'Hỗ trợ ngoài nhóm' };
export const REQ_STRUCT: Record<string, string> = { common: 'Yêu cầu chung', diverse: 'Yêu cầu đa dạng' };
export const UNEXPECTED_CAUSE: Record<string, string> = { incident: 'Sự cố', superior_request: 'Yêu cầu cấp trên', customer: 'Khách hàng', resource_shortage: 'Thiếu nguồn lực', support_other_dept: 'Hỗ trợ bộ phận khác', other: 'Khác' };
export const OT_TYPE: Record<string, string> = { planned: 'Có kế hoạch', ad_hoc: 'Đột xuất do yêu cầu bất thường', incident: 'Sự cố thiết bị/hệ thống/quy trình', workload: 'Khối lượng vượt khả năng', support: 'Phối hợp/hỗ trợ bộ phận khác' };
export const OT_STATUS: Record<string, string> = { pending: 'Chờ xác nhận', confirmed: 'Đã xác nhận', rejected: 'Bị từ chối' };
export const OT_TONE: Record<string, string> = { pending: 'amber', confirmed: 'green', rejected: 'red' };
export const WR_TYPE: Record<string, string> = { assigned_outside: 'Giao ngoài app', missing: 'Bị ghi thiếu', after_hours: 'Ngoài giờ', support: 'Hỗ trợ', other: 'Khác' };
export const WR_STATUS: Record<string, string> = { submitted: 'Đã gửi', needs_information: 'Cần bổ sung', accepted: 'Đã xác nhận', partially_accepted: 'Xác nhận một phần', rejected: 'Bị từ chối', disputed: 'Đang tranh chấp', appealed: 'Đã khiếu nại', resolved: 'Đã giải quyết' };
export const WR_TONE: Record<string, string> = { submitted: 'blue', needs_information: 'amber', accepted: 'green', partially_accepted: 'amber', rejected: 'red', disputed: 'red', appealed: 'purple', resolved: 'gray' };
export const WR_DECISION: Record<string, string> = { accept: 'Xác nhận', partial: 'Xác nhận một phần', reject: 'Từ chối', needs_info: 'Yêu cầu bổ sung' };
export const WR_RESPONSE: Record<string, string> = { accept: 'Chấp nhận kết quả', dispute: 'Không chấp nhận lý do', supplement: 'Bổ sung thông tin' };
export const FINAL: Record<string, string> = { accepted: 'Chấp nhận', partially_accepted: 'Chấp nhận một phần', rejected: 'Từ chối' };
export const RP_CAT: Record<string, string> = { equipment: 'Máy móc, thiết bị, công cụ', software: 'Phần mềm, hệ thống, mạng', facility: 'Cơ sở vật chất, môi trường', supplies: 'Vật tư, nguyên liệu, dụng cụ', process: 'Quy trình, phối hợp', other: 'Khác' };
export const SEVERITY: Record<string, string> = { low: 'Thấp', medium: 'Trung bình', high: 'Cao', critical: 'Nghiêm trọng' };
export const SEV_TONE: Record<string, string> = { low: 'gray', medium: 'blue', high: 'amber', critical: 'red' };
export const RP_STATUS: Record<string, string> = { submitted: 'Đã gửi', manager_review: 'Quản lý đang xem xét', assigned: 'Đã chuyển bộ phận', acknowledged: 'Bộ phận đã tiếp nhận', in_progress: 'Đang xử lý', waiting: 'Chờ thông tin/vật tư', resolved_pending: 'Đã xử lý, chờ xác nhận', closed: 'Đã đóng', reopened: 'Mở lại', escalated: 'Đã chuyển cấp', cannot_fix: 'Không khắc phục được', comment: 'Bình luận' };
export const RP_TONE: Record<string, string> = { submitted: 'blue', manager_review: 'blue', assigned: 'blue', acknowledged: 'blue', in_progress: 'blue', waiting: 'amber', resolved_pending: 'green', closed: 'gray', reopened: 'red', escalated: 'red' };
export const STAGE: Record<string, string> = { manager_review: 'Chờ quản lý tiếp nhận/chuyển', department_ack: 'Chờ bộ phận xác nhận tiếp nhận', resolution: 'Đang xử lý', reporter_confirm: 'Chờ người báo cáo xác nhận', closed: 'Đã đóng' };
export const ESC_STAGE: Record<string, string> = { manager_review: 'Tiếp nhận/chuyển', department_ack: 'Bộ phận tiếp nhận', resolution: 'Xử lý', review: 'Xác nhận bản ghi' };
export const EARLY_REASON: Record<string, string> = { conflict_of_interest: 'Xung đột lợi ích', pressure: 'Dấu hiệu gây sức ép', respondent_is_decider: 'Người bị khiếu nại là người có quyền xử lý trực tiếp', other: 'Khác' };
export const EVAL_LABEL: Record<string, string> = {
  output: 'Kết quả đầu ra/đáp ứng yêu cầu', quality: 'Chất lượng', schedule: 'Tiến độ', process: 'Quá trình, cập nhật, phối hợp',
  requirement: 'Đáp ứng yêu cầu và đầu ra', response: 'Tốc độ phản ứng', handling: 'Khả năng xử lý tình huống', coordination: 'Phối hợp và bàn giao',
};
export const EVAL_LABEL_UNEXPECTED_QUALITY = 'Chất lượng/độ chính xác';
export const COMP: Record<string, string> = { V: 'Khối lượng quy đổi', T: 'Tiến độ', Q: 'Chất lượng', D: 'Độ khó', R: 'Độ tin cậy' };
export const PERIOD: Record<string, string> = { month: 'Tháng', quarter: 'Quý', year: 'Năm' };
export const AUDIT_ACTION: Record<string, string> = {
  'task.created': 'Tạo nhiệm vụ', 'task.updated': 'Cập nhật', 'task.deadline_changed': 'Đổi deadline', 'task.status': 'Đổi trạng thái', 'task.submitted': 'Bàn giao',
  'task.approved': 'Nghiệm thu', 'task.revision_requested': 'Yêu cầu sửa', 'task.cancelled': 'Hủy', 'task.subitem_added': 'Thêm yêu cầu con', 'task.subitem_updated': 'Cập nhật yêu cầu con',
  'task.marked_unexpected': 'Đánh dấu đột xuất', 'file.uploaded': 'Tải tệp',
};

export const fmtDT = (s?: string | null) => (s ? new Date(s).toLocaleString('vi-VN', { hour: '2-digit', minute: '2-digit', day: '2-digit', month: '2-digit', year: 'numeric' }) : '—');
export const fmtD = (s?: string | null) => (s ? new Date(s).toLocaleDateString('vi-VN') : '—');
export const hours = (min?: number | null) => (min === null || min === undefined ? '—' : `${Math.round(min / 6) / 10} giờ`);
export const toLocalInput = (d: Date) => new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 16);
export const fromLocalInput = (s: string) => (s ? new Date(s).toISOString() : undefined);
export const relDue = (s: string) => {
  const diff = new Date(s).getTime() - Date.now();
  const h = Math.round(Math.abs(diff) / 3600000);
  const t = h >= 48 ? `${Math.round(h / 24)} ngày` : `${h} giờ`;
  return diff < 0 ? `quá hạn ${t}` : `còn ${t}`;
};

export const MEMBER_STATUS: Record<string, string> = { active: 'Đang hoạt động', inactive: 'Ngừng hoạt động', pending_hr: 'Chờ nhân sự duyệt', rejected: 'Bị từ chối' };
export const LEAVE_TYPE: Record<string, string> = { sudden: 'Nghỉ đột xuất', hourly: 'Nghỉ theo giờ', shift: 'Nghỉ theo ca', day: 'Nghỉ theo ngày' };
export const LEAVE_STATUS: Record<string, string> = { pending: 'Chờ duyệt', approved: 'Đã duyệt', rejected: 'Bị từ chối', cancelled: 'Đã hủy' };
export const LEAVE_TONE: Record<string, string> = { pending: 'amber', approved: 'green', rejected: 'red', cancelled: 'gray' };
export const CHANNEL: Record<string, string> = { call: 'Gọi điện', sms: 'Tin nhắn SMS', zalo: 'Zalo', chat: 'Tin nhắn khác', direct: 'Trao đổi trực tiếp' };
export const CLAIM_STATUS: Record<string, string> = { pending: 'Chờ xác nhận', confirmed: 'Đã xác nhận', rejected: 'Bị từ chối', cancelled: 'Đã hủy' };
export const CLAIM_TONE: Record<string, string> = { pending: 'amber', confirmed: 'green', rejected: 'red', cancelled: 'gray' };
export const AVAIL: Record<string, [string, string]> = {
  available: ['Sẵn sàng', 'green'], busy: ['Đang nhiều việc', 'red'], has_overdue: ['Có việc quá hạn', 'amber'],
  on_leave: ['Nghỉ phép trong thời gian này', 'teal'], leave_pending: ['Có đơn nghỉ chờ duyệt', 'amber'], handover: ['Đang bàn giao — không nhận việc mới', 'purple'],
};
export const PLAN_NAME: Record<string, string> = { small: 'Doanh nghiệp nhỏ', medium: 'Doanh nghiệp vừa', large: 'Doanh nghiệp lớn' };
export const vnd = (n: number) => n.toLocaleString('vi-VN') + ' đ';
export const isoDate = (d: Date) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
export const initials = (name?: string) => (name || '?').trim().split(/\s+/).slice(-2).map((w) => w[0]).join('').toUpperCase();

export const DECISION_TYPE: Record<string, string> = { transfer: 'Điều chuyển', promotion: 'Thăng chức / đổi vai trò', termination: 'Thôi việc' };
export const DECISION_STATUS: Record<string, string> = { handover: 'Đang bàn giao', pending_confirm: 'Chờ quản lý xác nhận bàn giao', completed: 'Đã có hiệu lực', cancelled: 'Đã hủy' };
export const DECISION_TONE: Record<string, string> = { handover: 'amber', pending_confirm: 'blue', completed: 'green', cancelled: 'gray' };
export const PERMIT_STATUS: Record<string, string> = { pending: 'Chờ cấp phép', approved: 'Đã cấp', rejected: 'Từ chối', auto_issued: 'Cấp tự động (khai báo)', cancelled: 'Đã hủy', closed: 'Đã hoàn tất' };
export const PERMIT_TONE: Record<string, string> = { pending: 'amber', approved: 'green', rejected: 'red', auto_issued: 'teal', cancelled: 'gray', closed: 'gray' };
export const REMINDER: Record<string, string> = { none: 'Không nhắc', daily: 'Hằng ngày', weekly: 'Hằng tuần (thứ Hai)', monthly: 'Hằng tháng (thứ Hai đầu tháng)' };
export const AUDIENCE: Record<string, string> = { all: 'Toàn công ty', managers: 'Cấp quản lý', department: 'Theo bộ phận' };
