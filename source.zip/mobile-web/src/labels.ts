export const ROLE: Record<string, string> = { owner: 'Chủ doanh nghiệp', admin: 'Quản trị', manager: 'Quản lý', employee: 'Nhân viên', handler: 'Bộ phận xử lý', reviewer: 'Reviewer độc lập', hr: 'Quản lý nhân sự' };
export const TASK_STATUS: Record<string, string> = { not_started: 'Chưa bắt đầu', in_progress: 'Đang thực hiện', pending_review: 'Chờ nghiệm thu', completed: 'Hoàn thành', revision_requested: 'Yêu cầu chỉnh sửa', cancelled: 'Đã hủy', waiting: 'Chờ giai đoạn trước', pending_approval: 'Chờ cấp trên duyệt giao việc', awaiting_handover: 'Chờ người nhận xác nhận bàn giao', pending_exception_review: 'Treo — chờ duyệt giải trình' };
export const TASK_TONE: Record<string, string> = { not_started: 'gray', in_progress: 'blue', pending_review: 'amber', completed: 'green', revision_requested: 'red', cancelled: 'gray', waiting: 'gray', pending_approval: 'amber', awaiting_handover: 'blue', pending_exception_review: 'amber' };
export const COMPLEXITY: Record<string, string> = { simple: 'Đơn giản', medium: 'Trung bình', complex: 'Phức tạp', very_complex: 'Rất phức tạp' };
export const REQ: Record<string, string> = { normal: 'Thông thường', high: 'Cao', very_high: 'Rất cao' };
export const PRIORITY: Record<string, string> = { low: 'Thấp', normal: 'Bình thường', high: 'Cao', urgent: 'Khẩn' };
export const UNEXPECTED_CAT: Record<string, string> = { ad_hoc: 'Đột xuất', urgent: 'Khẩn cấp', scope_addition: 'Phát sinh bổ sung', external_support: 'Hỗ trợ ngoài nhóm' };
export const REQ_STRUCT: Record<string, string> = { common: 'Yêu cầu chung', diverse: 'Yêu cầu đa dạng' };
export const UNEXPECTED_CAUSE: Record<string, string> = { incident: 'Sự cố', superior_request: 'Yêu cầu cấp trên', customer: 'Khách hàng', resource_shortage: 'Thiếu nguồn lực', support_other_dept: 'Hỗ trợ bộ phận khác', other: 'Khác' };
export const OT_TYPE: Record<string, string> = { planned: 'Có kế hoạch', ad_hoc: 'Đột xuất do yêu cầu bất thường', incident: 'Sự cố thiết bị/hệ thống/quy trình', workload: 'Khối lượng vượt khả năng', support: 'Phối hợp/hỗ trợ bộ phận khác' };
export const OT_STATUS: Record<string, string> = { pending: 'Chờ xác nhận', confirmed: 'Đã xác nhận', rejected: 'Bị từ chối' };
export const OT_TONE: Record<string, string> = { pending: 'amber', confirmed: 'green', rejected: 'red' };
export const WR_TYPE: Record<string, string> = { assigned_outside: 'Giao ngoài app', missing: 'Bị ghi thiếu', after_hours: 'Ngoài giờ', support: 'Hỗ trợ', other: 'Khác', routine: 'Việc thường ngày', outside_role: 'Việc ngoài vai trò', branch: 'Thêm vào nhánh việc' };
export const WR_STATUS: Record<string, string> = { submitted: 'Đã gửi', needs_information: 'Cần bổ sung', accepted: 'Đã xác nhận', partially_accepted: 'Xác nhận một phần', rejected: 'Bị từ chối', disputed: 'Đang tranh chấp', appealed: 'Đã khiếu nại', resolved: 'Đã giải quyết' };
export const WR_TONE: Record<string, string> = { submitted: 'blue', needs_information: 'amber', accepted: 'green', partially_accepted: 'amber', rejected: 'red', disputed: 'red', appealed: 'purple', resolved: 'gray' };
export const WR_DECISION: Record<string, string> = { accept: 'Xác nhận', partial: 'Xác nhận một phần', reject: 'Từ chối', needs_info: 'Yêu cầu bổ sung' };
export const WR_RESPONSE: Record<string, string> = { accept: 'Chấp nhận kết quả', dispute: 'Không chấp nhận lý do', supplement: 'Bổ sung thông tin' };
export const FINAL: Record<string, string> = { accepted: 'Chấp nhận', partially_accepted: 'Chấp nhận một phần', rejected: 'Từ chối' };
export const RP_CAT: Record<string, string> = { equipment: 'Máy móc, thiết bị, công cụ', software: 'Phần mềm, hệ thống, mạng', facility: 'Cơ sở vật chất, môi trường', supplies: 'Vật tư, nguyên liệu, dụng cụ', process: 'Quy trình, phối hợp', other: 'Khác' };
export const SEVERITY: Record<string, string> = { low: 'Thấp', medium: 'Trung bình', high: 'Cao', critical: 'Nghiêm trọng' };
export const SEV_TONE: Record<string, string> = { low: 'gray', medium: 'blue', high: 'amber', critical: 'red' };
export const RP_STATUS: Record<string, string> = { submitted: 'Đã gửi', manager_review: 'Quản lý đang xem xét', assigned: 'Đã chuyển bộ phận', acknowledged: 'Bộ phận đã tiếp nhận', in_progress: 'Đang xử lý', waiting: 'Chờ thông tin/vật tư', resolved_pending: 'Đã xử lý, chờ xác nhận', closed: 'Đã đóng', reopened: 'Mở lại', escalated: 'Đã chuyển cấp', cannot_fix: 'Không khắc phục được', comment: 'Bình luận', task_assigned: 'Đã giao việc xử lý', override: 'Cấp trên thay đổi quyết định' };
export const RP_TONE: Record<string, string> = { submitted: 'blue', manager_review: 'blue', assigned: 'blue', acknowledged: 'blue', in_progress: 'blue', waiting: 'amber', resolved_pending: 'green', closed: 'gray', reopened: 'red', escalated: 'red', task_assigned: 'blue' };
export const STAGE: Record<string, string> = { manager_review: 'Chờ quản lý tiếp nhận/chuyển', department_ack: 'Chờ bộ phận xác nhận tiếp nhận', resolution: 'Đang xử lý', reporter_confirm: 'Chờ người báo cáo xác nhận', closed: 'Đã đóng' };
export const ESC_STAGE: Record<string, string> = { manager_review: 'Tiếp nhận/chuyển', department_ack: 'Bộ phận tiếp nhận', resolution: 'Xử lý', review: 'Xác nhận bản ghi' };
export const EARLY_REASON: Record<string, string> = { conflict_of_interest: 'Xung đột lợi ích', pressure: 'Dấu hiệu gây sức ép', respondent_is_decider: 'Người bị khiếu nại là người có quyền xử lý trực tiếp', other: 'Khác' };
export const EVAL_LABEL: Record<string, string> = {
  output: 'Kết quả đầu ra/đáp ứng yêu cầu', quality: 'Chất lượng', schedule: 'Tiến độ', process: 'Quá trình, cập nhật, phối hợp',
  requirement: 'Đáp ứng yêu cầu và đầu ra', response: 'Tốc độ phản ứng', handling: 'Khả năng xử lý tình huống', coordination: 'Phối hợp và bàn giao',
};
export const EVAL_LABEL_UNEXPECTED_QUALITY = 'Chất lượng/độ chính xác';
export const COMP: Record<string, string> = { V: 'Khối lượng quy đổi', T: 'Tiến độ', Q: 'Chất lượng', D: 'Độ khó', R: 'Độ tin cậy', O: 'Việc ngoài vai trò (điểm cộng)' };
export const PERIOD: Record<string, string> = { month: 'Tháng', quarter: 'Quý', year: 'Năm' };
export const AUDIT_ACTION: Record<string, string> = {
  'task.created': 'Tạo nhiệm vụ', 'task.updated': 'Cập nhật', 'task.deadline_changed': 'Đổi deadline', 'task.status': 'Đổi trạng thái', 'task.submitted': 'Bàn giao',
  'task.approved': 'Nghiệm thu', 'task.revision_requested': 'Yêu cầu sửa', 'task.cancelled': 'Hủy', 'task.subitem_added': 'Thêm yêu cầu con', 'task.subitem_updated': 'Cập nhật yêu cầu con',
  'task.marked_unexpected': 'Đánh dấu đột xuất', 'file.uploaded': 'Tải tệp',
  'production.recorded': 'Ghi nhận sản lượng', 'production.adjusted': 'Điều chỉnh sản lượng', 'handover.accepted': 'Tiếp nhận bàn giao', 'handover.rejected': 'Từ chối bàn giao',
  'task.paused': 'Hoãn', 'session.switched': 'Chuyển việc', 'task.priority_changed': 'Đổi ưu tiên', 'task.early_start': 'Cho phép bắt đầu sớm', 'chain.scheduled': 'Tính deadline chuỗi', 'task.approval_approve': 'Duyệt giao việc', 'task.approval_reject': 'Không duyệt giao việc',
};

export const fmtDT = (s?: string | null) => (s ? new Date(s).toLocaleString('vi-VN', { hour: '2-digit', minute: '2-digit', day: '2-digit', month: '2-digit', year: 'numeric' }) : '—');
export const fmtD = (s?: string | null) => (s ? new Date(s).toLocaleDateString('vi-VN') : '—');
export const hours = (min?: number | null) => (min === null || min === undefined ? '—' : `${Math.round(min / 6) / 10} giờ`);
export const toLocalInput = (d: Date) => new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 16);
export const fromLocalInput = (s: string) => (s ? new Date(s).toISOString() : undefined);
export const relDue = (s: string) => {
  const diff = new Date(s).getTime() - Date.now();
  const h = Math.round(Math.abs(diff) / 3600000);
  const t = h >= 48 ? `${Math.round(h / 24)} ngày` : `${h} giờ`;
  return diff < 0 ? `quá hạn ${t}` : `còn ${t}`;
};

export const MEMBER_STATUS: Record<string, string> = { active: 'Đang hoạt động', inactive: 'Ngừng hoạt động', pending_hr: 'Chờ nhân sự duyệt', rejected: 'Bị từ chối' };
export const LEAVE_TYPE: Record<string, string> = { sudden: 'Nghỉ đột xuất', hourly: 'Nghỉ theo giờ', shift: 'Nghỉ theo ca', day: 'Nghỉ theo ngày' };
export const LEAVE_STATUS: Record<string, string> = { pending: 'Chờ duyệt', approved: 'Đã duyệt', rejected: 'Bị từ chối', cancelled: 'Đã hủy' };
export const LEAVE_TONE: Record<string, string> = { pending: 'amber', approved: 'green', rejected: 'red', cancelled: 'gray' };
export const CHANNEL: Record<string, string> = { call: 'Gọi điện', sms: 'Tin nhắn SMS', zalo: 'Zalo', chat: 'Tin nhắn khác', direct: 'Trao đổi trực tiếp' };
export const CLAIM_STATUS: Record<string, string> = { pending: 'Chờ xác nhận', confirmed: 'Đã xác nhận', rejected: 'Bị từ chối', cancelled: 'Đã hủy' };
export const CLAIM_TONE: Record<string, string> = { pending: 'amber', confirmed: 'green', rejected: 'red', cancelled: 'gray' };
export const AVAIL: Record<string, [string, string]> = {
  available: ['Sẵn sàng', 'green'], busy: ['Đang nhiều việc', 'red'], has_overdue: ['Có việc quá hạn', 'amber'],
  on_leave: ['Nghỉ phép trong thời gian này', 'teal'], leave_pending: ['Có đơn nghỉ chờ duyệt', 'amber'], handover: ['Đang bàn giao — không nhận việc mới', 'purple'],
};
export const PLAN_NAME: Record<string, string> = { small: 'Doanh nghiệp nhỏ', medium: 'Doanh nghiệp vừa', large: 'Doanh nghiệp lớn' };
export const vnd = (n: number) => n.toLocaleString('vi-VN') + ' đ';
export const isoDate = (d: Date) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
export const initials = (name?: string) => (name || '?').trim().split(/\s+/).slice(-2).map((w) => w[0]).join('').toUpperCase();

export const DECISION_TYPE: Record<string, string> = { transfer: 'Điều chuyển', promotion: 'Thăng chức / đổi vai trò', termination: 'Thôi việc' };
export const DECISION_STATUS: Record<string, string> = { handover: 'Đang bàn giao', pending_confirm: 'Chờ quản lý xác nhận bàn giao', completed: 'Đã có hiệu lực', cancelled: 'Đã hủy' };
export const DECISION_TONE: Record<string, string> = { handover: 'amber', pending_confirm: 'blue', completed: 'green', cancelled: 'gray' };
export const PERMIT_STATUS: Record<string, string> = { pending: 'Chờ cấp phép', approved: 'Đã cấp', rejected: 'Từ chối', auto_issued: 'Cấp tự động (khai báo)', cancelled: 'Đã hủy', closed: 'Đã hoàn tất' };
export const PERMIT_TONE: Record<string, string> = { pending: 'amber', approved: 'green', rejected: 'red', auto_issued: 'teal', cancelled: 'gray', closed: 'gray' };
export const REMINDER: Record<string, string> = { none: 'Không nhắc', daily: 'Hằng ngày', weekly: 'Hằng tuần (thứ Hai)', monthly: 'Hằng tháng (thứ Hai đầu tháng)' };
export const AUDIENCE: Record<string, string> = { all: 'Toàn công ty', managers: 'Cấp quản lý', department: 'Theo bộ phận' };

// v6: phiên làm việc, thời gian, rủi ro, sản lượng
export const TIME_CAT: Record<string, [string, string]> = {
  execution: ['Thực hiện', 'blue'], preparation: ['Chuẩn bị', 'teal'], changeover: ['Chuyển đổi', 'teal'], waiting: ['Chờ việc', 'amber'],
  objective_pause: ['Hoãn khách quan', 'purple'], subjective_pause: ['Hoãn chủ quan', 'red'], rest_internal: ['Nghỉ bổ sung (quỹ nghỉ)', 'green'],
  handover: ['Bàn giao', 'gray'], unknown: ['Chưa xác định', 'gray'], overtime: ['Tăng ca', 'amber'],
};
export const PAUSE_OPTS: Record<string, string> = {
  objective_pause: 'Hoãn khách quan (thiết bị, nguyên liệu, mất điện, chờ bộ phận khác…)', waiting: 'Chờ việc / chờ bàn giao / chờ nguồn lực',
  subjective_pause: 'Tạm dừng vì lý do cá nhân', preparation: 'Chuẩn bị', changeover: 'Chuyển đổi (đổi khuôn, vệ sinh máy…)', handover: 'Bàn giao',
};
export const RISK: Record<string, [string, string]> = { normal: ['Bình thường', 'green'], due_soon: ['Sắp hạn', 'amber'], at_risk: ['Nguy cơ trễ', 'red'], overdue: ['Quá hạn', 'red'], done: ['Hoàn thành', 'gray'] };
export const HO_STATUS: Record<string, [string, string]> = { submitted: ['Chờ tiếp nhận', 'amber'], accepted: ['Đã tiếp nhận', 'green'], rejected: ['Cần bổ sung', 'red'], cancelled: ['Đã hủy', 'gray'] };
export const IMPORTANCE: Record<string, string> = { normal: 'Thường', high: 'Quan trọng', critical: 'Rất quan trọng' };
export const LOC_KIND: Record<string, string> = { department: 'Phòng ban', machine_room: 'Phòng máy', raw_store: 'Kho nguyên liệu', cold_store: 'Kho lạnh', production_floor: 'Sàn sản xuất', packing: 'Khu đóng gói', office: 'Văn phòng', outside: 'Ngoài công ty', area: 'Khu vực khác' };
export const mins = (m?: number | null) => (m === null || m === undefined ? '—' : m >= 60 ? `${Math.floor(m / 60)}g${String(Math.round(m % 60)).padStart(2, '0')}` : `${Math.round(m)}p`);

/** Tên hiển thị kèm mã: "NV-00023 - Kiểm kê kho"; công đoạn đơn hàng: "DH-00001_NV-00043 - Nhập hàng"; phần việc con: "NV-00043.1 - ...". */
export const taskLabel = (t: any, chainCode?: string | null) => {
  const cc = chainCode ?? t?.root_chain_code ?? (t?.is_chain ? null : null);
  return `${cc ? `${cc}_` : ''}${t?.code ? `${t.code} - ` : ''}${t?.title ?? ''}`;
};
export const AUTO_START: Record<string, string> = { manual: 'Thủ công (người làm bấm bắt đầu)', on_handover: 'Tự động khi nhận bàn giao của công đoạn trước', scheduled: 'Tự động theo lịch đặt trước' };
export const HO_METHOD: Record<string, string> = { direct_inspection: 'Nghiệm thu trực tiếp', customer_confirmation: 'Xác nhận của khách hàng', document_check: 'Kiểm tra tài liệu', leader_confirmation: 'Xác nhận của trưởng nhóm', other: 'Khác' };
/** Trường mẫu là số phiếu/mã chứng từ: cho phép chọn "không có số phiếu". */
export const isTicketField = (x: any) => /^(so_phieu|ma_don|ma_khieu_nai|so_chung_tu)/.test(x?.key || '') || /số phiếu|mã đơn|chứng từ/i.test(x?.label || '');
