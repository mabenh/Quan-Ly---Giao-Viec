import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { get, isNetDegraded, post } from './api';
import { useAuth } from './auth';
import { ErrorBox, Field, Sheet, useAction } from './ui';
import { Icon } from './icons';
import { ROLE } from './labels';

/** Mã tệp JS chính của bản đang chạy (Vite gắn mã băm vào tên tệp). */
const currentBuild = () => (document.querySelector('script[type="module"][src*="/assets/"]') as HTMLScriptElement | null)?.getAttribute('src') || '';

/**
 * v13: banner trạng thái
 * - "Đã có phiên bản mới" khi máy chủ được cập nhật (so mã tệp JS của index.html mới nhất với bản đang chạy) → bấm để tải lại.
 * - "Mạng yếu – đang kết nối lại" khi nhiều yêu cầu liên tiếp lỗi mạng, tự ẩn khi kết nối lại.
 */
export function AppStatus() {
  const [update, setUpdate] = useState(false);
  const [degraded, setDegraded] = useState(isNetDegraded());
  const [offline, setOffline] = useState(!navigator.onLine);
  useEffect(() => {
    const mine = currentBuild();
    let alive = true;
    const check = async () => {
      if (!mine || document.hidden || !navigator.onLine) return;
      try {
        const html = await (await fetch('/index.html?v=' + Date.now(), { cache: 'no-store' })).text();
        const m = html.match(/<script[^>]+type="module"[^>]+src="([^"]*\/assets\/[^"]+)"/);
        if (alive && m && m[1] !== mine) setUpdate(true);
      } catch { /* bỏ qua */ }
    };
    const t = setInterval(check, 5 * 60000);
    const first = setTimeout(check, 15000);
    const onVis = () => { if (!document.hidden) check(); };
    document.addEventListener('visibilitychange', onVis);
    const onNet = (e: any) => setDegraded(!!e.detail?.degraded);
    const on = () => setOffline(false); const off = () => setOffline(true);
    window.addEventListener('net:status', onNet); window.addEventListener('online', on); window.addEventListener('offline', off);
    return () => { alive = false; clearInterval(t); clearTimeout(first); document.removeEventListener('visibilitychange', onVis); window.removeEventListener('net:status', onNet); window.removeEventListener('online', on); window.removeEventListener('offline', off); };
  }, []);
  return (
    <>
      {(offline || degraded) && <div className="net-banner" role="status">{offline ? '⚠ Điện thoại đang mất mạng — dữ liệu sẽ gửi khi có mạng lại' : '⟳ Mạng yếu — đang kết nối lại…'}</div>}
      {update && (
        <div className="update-banner" role="alert">
          <span style={{ flex: 1 }}>Đã có phiên bản mới của Việc Đến.</span>
          <button className="btn sm primary" onClick={() => location.reload()}>Cập nhật ngay</button>
          <button className="btn sm" aria-label="Để sau" onClick={() => setUpdate(false)}>✕</button>
        </div>
      )}
    </>
  );
}

/** v13: đổi doanh nghiệp / công ty ngay trên thanh trên cùng; gia nhập công ty khác bằng mã; mở doanh nghiệp mới. */
export function CompanySwitcher({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { me, switchCompany, reload } = useAuth();
  const nav = useNavigate();
  const [code, setCode] = useState('');
  const [preview, setPreview] = useState<string | null>(null);
  const [msg, setMsg] = useState<string | null>(null);
  const a = useAction();
  useEffect(() => { if (open) { reload(); setMsg(null); } }, [open]); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => {
    setPreview(null);
    const c = code.trim().toUpperCase();
    if (c.length < 8) return;
    const t = setTimeout(() => get(`/companies/lookup?code=${encodeURIComponent(c)}`).then((r) => setPreview(r.name)).catch(() => setPreview('')), 400);
    return () => clearTimeout(t);
  }, [code]);
  const ms = me?.memberships || [];
  const pending: any[] = (me as any)?.pending_memberships || [];
  return (
    <Sheet open={open} onClose={onClose} title="Doanh nghiệp của tôi">
      {me?.company_name && <div className="company-full"><div className="small muted">Đang làm việc tại</div><b>{me.company_name}</b></div>}
      <div className="small muted" style={{ marginBottom: 6 }}>Một tài khoản có thể làm việc ở nhiều công ty. Chọn công ty để chuyển — dữ liệu mỗi công ty tách biệt.</div>
      {ms.map((m) => (
        <button key={m.company_id} className={`company-item ${m.company_id === me?.company_id ? 'on' : ''}`} disabled={a.busy}
          onClick={() => m.company_id === me?.company_id ? onClose() : a.run(async () => { await switchCompany(m.company_id); onClose(); nav('/', { replace: true }); })}>
          <span className="ci-mark"><Icon name="company" size={18} /></span>
          <span style={{ flex: 1, minWidth: 0, textAlign: 'left' }}><b className="ellipsis" style={{ display: 'block' }}>{m.company_name}</b><span className="small muted">{ROLE[m.role] || m.role}</span></span>
          {m.company_id === me?.company_id ? <span className="small" style={{ color: 'var(--teal)' }}>✓ Đang dùng</span> : <span className="small">Chuyển ›</span>}
        </button>
      ))}
      {pending.map((p) => (
        <div key={p.id} className="company-item pending">
          <span className="ci-mark"><Icon name="clock" size={18} /></span>
          <span style={{ flex: 1, minWidth: 0 }}><b className="ellipsis" style={{ display: 'block' }}>{p.company_name}</b><span className="small muted">Đang chờ nhân sự duyệt</span></span>
          <button className="btn sm" disabled={a.busy} onClick={() => confirm(`Hủy yêu cầu gia nhập ${p.company_name}?`) && a.run(async () => { await post('/companies/join/cancel', { memberId: p.id }); await reload(); })}>Hủy</button>
        </div>
      ))}
      <div className="card" style={{ marginTop: 10 }}>
        <b>Gia nhập công ty khác</b>
        <Field label="Mã gia nhập" hint="Xin mã 8 ký tự từ phòng nhân sự của công ty đó"><input value={code} onChange={(e) => setCode(e.target.value.toUpperCase())} maxLength={12} placeholder="VD: K7M2QX9A" autoCapitalize="characters" /></Field>
        {preview && <div className="small">Công ty: <b>{preview}</b></div>}
        {preview === '' && <div className="small" style={{ color: 'var(--red)' }}>Không tìm thấy công ty với mã này</div>}
        {msg && <div className="alert ok small">{msg}</div>}
        <ErrorBox error={a.error} />
        <button className="btn primary block" disabled={a.busy || !preview} onClick={() => a.run(async () => { const r = await post('/companies/join', { code: code.trim() }); setMsg(r.message); setCode(''); await reload(); })}>Gửi yêu cầu gia nhập</button>
      </div>
      <button className="btn block" style={{ marginTop: 8 }} onClick={() => { onClose(); nav('/upgrade?new=1'); }}><Icon name="plus" size={16} />Mở doanh nghiệp mới</button>
    </Sheet>
  );
}

/** Mã gia nhập công ty (Ban quản trị / Nhân sự): gửi cho nhân viên đã có tài khoản Việc Đến ở công ty khác. */
export function JoinCodeCard() {
  const { me } = useAuth();
  const [code, setCode] = useState<string | null>(null);
  const [show, setShow] = useState(false);
  const a = useAction();
  useEffect(() => { if (show && !code) get('/company/join-code').then((r) => setCode(r.code)).catch(() => {}); }, [show, code]);
  const isAdm = me?.role === 'owner' || me?.role === 'admin';
  return (
    <div className="card">
      <div className="row"><Icon name="key" size={18} /><b style={{ flex: 1 }}>Mã gia nhập công ty</b><button className="btn sm" onClick={() => setShow(!show)}>{show ? 'Ẩn' : 'Xem mã'}</button></div>
      {show && <>
        <div className="join-code">{code || '…'}</div>
        <div className="small muted">Người đã có tài khoản Việc Đến (kể cả đang làm ở công ty khác) bấm tên công ty trên cùng → <b>Gia nhập công ty khác</b> → nhập mã. Yêu cầu sẽ chờ Nhân sự duyệt và xếp chức vụ, phòng ban.</div>
        <div className="chip-row" style={{ marginTop: 6 }}>
          {code && <button className="btn sm" onClick={() => { navigator.clipboard?.writeText(code).then(() => alert('Đã sao chép mã'), () => {}); }}>Sao chép</button>}
          {isAdm && <button className="btn sm" disabled={a.busy} onClick={() => confirm('Đổi mã mới? Mã cũ sẽ hết hiệu lực.') && a.run(async () => setCode((await post('/company/join-code/rotate')).code))}>Đổi mã</button>}
        </div>
        <ErrorBox error={a.error} />
      </>}
    </div>
  );
}

/** Chẩn đoán lỗi kết nối phía ứng dụng (24 giờ gần nhất). */
export function ConnectionDiag() {
  const [hours, setHours] = useState(24);
  const [d, setD] = useState<any>(null);
  const [err, setErr] = useState<string | null>(null);
  useEffect(() => { setD(null); get(`/platform/client-errors?hours=${hours}`).then(setD).catch((e) => setErr(e.message)); }, [hours]);
  const LBL: Record<string, string> = { NETWORK: 'Mất kết nối', TIMEOUT: 'Quá thời gian chờ', RATE_LIMITED: 'Bị giới hạn tần suất (429)', REFRESH_FAILED: 'Làm mới phiên lỗi' };
  return (
    <>
      <p className="small muted">Ứng dụng tự gửi về các lỗi kết nối (mất mạng, quá thời gian, lỗi máy chủ 5xx, 429) để tìm nguyên nhân "lỗi kết nối". Lưu 7 ngày.</p>
      <div className="seg">{[1, 24, 168].map((h) => <button key={h} className={hours === h ? 'on' : ''} onClick={() => setHours(h)}>{h === 168 ? '7 ngày' : `${h} giờ`}</button>)}</div>
      <ErrorBox error={err} />
      {d && d.summary.length === 0 && <div className="alert ok small">Không có lỗi kết nối nào được ghi nhận.</div>}
      {d?.summary.map((s: any, i: number) => (
        <div key={i} className="card"><div className="row"><b style={{ flex: 1 }}>{LBL[s.code] || s.code}</b><span className="badge red">{s.n} lần</span></div>
          <div className="small muted">{s.path || '—'} · {s.users} người · gần nhất {new Date(s.last_at).toLocaleString('vi-VN')}</div></div>
      ))}
      {d?.recent?.length > 0 && <details><summary className="small">100 lỗi gần nhất</summary>
        {d.recent.map((r: any, i: number) => <div key={i} className="small" style={{ borderBottom: '1px solid var(--line)', padding: '4px 0' }}>{new Date(r.created_at).toLocaleTimeString('vi-VN')} · {r.name || '?'} · {LBL[r.code] || r.code} · {r.path} · {r.app}{r.online === false ? ' · máy báo offline' : ''}</div>)}
      </details>}
    </>
  );
}
