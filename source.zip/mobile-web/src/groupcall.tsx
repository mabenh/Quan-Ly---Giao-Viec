import { createContext, ReactNode, useCallback, useContext, useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { api, post } from './api';
import { useAuth } from './auth';
import { Avatar } from './ui';
import { Icon } from './icons';
import { fmtSec, useComms } from './comms';

/**
 * v13: Gọi nhóm trong app (WebRTC dạng lưới — mỗi người kết nối trực tiếp với từng người, tối đa 8 người).
 * Báo hiệu qua HTTP polling như cuộc gọi 1-1; người có mã thành viên nhỏ hơn chủ động gửi "offer" để tránh xung đột.
 * Thời lượng tối đa theo thiết lập nhóm (mặc định 10 phút).
 */
interface Peer { pc: RTCPeerConnection; audio: HTMLAudioElement; pendingIce: any[]; state: string }
interface GCtx { joinRoomCall: (roomId: string) => Promise<void>; activeRoomId: string | null }
const C = createContext<GCtx>({ joinRoomCall: async () => {}, activeRoomId: null });
export const useGroupCall = () => useContext(C);

export function GroupCallProvider({ children }: { children: ReactNode }) {
  const { me } = useAuth();
  const nav = useNavigate();
  const { roomCalls, busy: oneToOneBusy } = useComms();
  const [call, setCall] = useState<any>(null);
  const [parts, setParts] = useState<any[]>([]);
  const [peerStates, setPeerStates] = useState<Record<string, string>>({});
  const [remaining, setRemaining] = useState(0);
  const [muted, setMuted] = useState(false);
  const [notice, setNotice] = useState<string | null>(null);
  const [dismissed, setDismissed] = useState<string[]>([]);
  const [mini, setMini] = useState(false);
  const peers = useRef<Record<string, Peer>>({});
  const local = useRef<MediaStream | null>(null);
  const since = useRef('0');
  const callRef = useRef<any>(null); callRef.current = call;
  const endsAt = useRef(0);

  const setPeerState = (id: string, st: string) => setPeerStates((s) => (s[id] === st ? s : { ...s, [id]: st }));
  const closePeer = (id: string) => {
    const p = peers.current[id]; if (!p) return;
    try { p.pc.close(); } catch { /* */ }
    p.audio.srcObject = null; delete peers.current[id];
    setPeerStates((s) => { const n = { ...s }; delete n[id]; return n; });
  };
  const cleanup = useCallback(() => {
    Object.keys(peers.current).forEach(closePeer);
    local.current?.getTracks().forEach((t) => t.stop()); local.current = null;
    setCall(null); setParts([]); setMuted(false); setMini(false); since.current = '0';
  }, []);

  const makePeer = (other: string, c: any): Peer => {
    closePeer(other);
    const pc = new RTCPeerConnection({ iceServers: c.ice_servers });
    const audio = new Audio(); audio.autoplay = true; (audio as any).playsInline = true;
    const peer: Peer = { pc, audio, pendingIce: [], state: 'connecting' };
    pc.onicecandidate = (e) => { if (e.candidate) post(`/room-calls/${c.id}/signal`, { to: other, type: 'ice', payload: e.candidate.toJSON() }).catch(() => {}); };
    pc.ontrack = (e) => { audio.srcObject = e.streams[0]; audio.play().catch(() => {}); };
    pc.onconnectionstatechange = () => {
      setPeerState(other, pc.connectionState);
      // Người chủ động tự kết nối lại khi đường truyền rớt
      if (pc.connectionState === 'failed' && me?.member_id && me.member_id < other && callRef.current) setTimeout(() => offerTo(other, callRef.current), 1000);
    };
    local.current?.getTracks().forEach((t) => pc.addTrack(t, local.current!));
    peers.current[other] = peer; setPeerState(other, 'connecting');
    return peer;
  };
  const offerTo = async (other: string, c: any) => {
    const p = makePeer(other, c);
    const offer = await p.pc.createOffer(); await p.pc.setLocalDescription(offer);
    await post(`/room-calls/${c.id}/signal`, { to: other, type: 'offer', payload: { type: offer.type, sdp: offer.sdp } }).catch(() => {});
  };
  const flush = async (p: Peer) => { for (const i of p.pendingIce.splice(0)) await p.pc.addIceCandidate(i).catch(() => {}); };

  const apply = async (st: any) => {
    const c = callRef.current; if (!c) return;
    since.current = st.since || since.current;
    setParts(st.participants);
    endsAt.current = Date.now() + st.remaining_seconds * 1000;
    if (st.status === 'ended') { setNotice('Cuộc gọi nhóm đã kết thúc'); cleanup(); return; }
    const present = new Set<string>(st.participants.map((p: any) => p.member_id));
    for (const id of Object.keys(peers.current)) if (!present.has(id)) closePeer(id);
    for (const s of st.signals) {
      const from = s.from_member_id;
      if (s.type === 'offer') {
        const p = makePeer(from, c);
        await p.pc.setRemoteDescription(s.payload); await flush(p);
        const ans = await p.pc.createAnswer(); await p.pc.setLocalDescription(ans);
        await post(`/room-calls/${c.id}/signal`, { to: from, type: 'answer', payload: { type: ans.type, sdp: ans.sdp } }).catch(() => {});
      } else if (s.type === 'answer') {
        const p = peers.current[from];
        if (p && !p.pc.currentRemoteDescription) { await p.pc.setRemoteDescription(s.payload).catch(() => {}); await flush(p); }
      } else if (s.type === 'ice') {
        const p = peers.current[from];
        if (p?.pc.remoteDescription) await p.pc.addIceCandidate(s.payload).catch(() => {}); else if (p) p.pendingIce.push(s.payload);
      }
    }
    // Người có mã nhỏ hơn chủ động kết nối tới người mới vào
    for (const p of st.participants) {
      const id = p.member_id;
      if (id !== me?.member_id && !peers.current[id] && me?.member_id && me.member_id < id) await offerTo(id, c);
    }
  };

  const joinRoomCall = useCallback(async (roomId: string) => {
    if (callRef.current) { if (callRef.current.room_id === roomId) return; alert('Bạn đang trong một cuộc gọi nhóm khác'); return; }
    if (oneToOneBusy) { alert('Bạn đang trong cuộc gọi khác'); return; }
    if (!navigator.mediaDevices?.getUserMedia) { alert('Thiết bị/trình duyệt không hỗ trợ gọi trong app (cần HTTPS và quyền micro).'); return; }
    setNotice(null);
    try {
      local.current = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true } });
    } catch { alert('Cần cho phép dùng micro để gọi nhóm.'); return; }
    try {
      const st = await post(`/rooms/${roomId}/calls`);
      since.current = '0';
      callRef.current = st; setCall(st);
      await apply(st);
    } catch (e: any) { local.current?.getTracks().forEach((t) => t.stop()); local.current = null; alert(e.message); }
  }, [oneToOneBusy]); // eslint-disable-line react-hooks/exhaustive-deps

  // Thăm dò báo hiệu khi đang trong cuộc gọi nhóm
  useEffect(() => {
    if (!call?.id) return;
    let alive = true; let busy = false;
    const tick = async () => {
      if (busy) return; busy = true;
      try { const st = await api<any>('GET', `/room-calls/${call.id}/poll?since=${since.current}`, undefined, { retries: 0 }); if (alive) await apply(st); }
      catch (e: any) { if (e?.code === 'INVALID_STATE' && alive) { setNotice('Bạn đã rời cuộc gọi nhóm (mất kết nối quá lâu)'); cleanup(); } }
      finally { busy = false; }
    };
    const t = setInterval(tick, 1200);
    return () => { alive = false; clearInterval(t); };
  }, [call?.id]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (!call?.id) return;
    const t = setInterval(() => {
      const left = Math.max(0, Math.round((endsAt.current - Date.now()) / 1000));
      setRemaining(left);
      if (left <= 0) { leave(); setNotice('Hết thời lượng cuộc gọi nhóm'); }
    }, 500);
    return () => clearInterval(t);
  }, [call?.id]); // eslint-disable-line react-hooks/exhaustive-deps

  const leave = async () => { const c = callRef.current; if (!c) return; cleanup(); await post(`/room-calls/${c.id}/leave`).catch(() => {}); };
  const toggleMute = () => { const m = !muted; local.current?.getAudioTracks().forEach((t) => (t.enabled = !m)); setMuted(m); };

  const banners = (roomCalls || []).filter((r: any) => !dismissed.includes(r.id) && r.room_id !== call?.room_id);
  const ST: Record<string, string> = { connecting: 'đang kết nối…', new: 'đang kết nối…', connected: 'đã kết nối', disconnected: 'mạng chập chờn…', failed: 'kết nối lại…' };
  return (
    <C.Provider value={{ joinRoomCall, activeRoomId: call?.room_id || null }}>
      {children}
      <div className="gc-float">
      {!call && banners.slice(0, 1).map((r: any) => (
        <div key={r.id} className="room-call-banner" role="alert">
          <Icon name="phone" size={18} />
          <div style={{ flex: 1, minWidth: 0 }} className="small"><b>{r.started_by_name}</b> đang gọi nhóm <b>{r.room_name}</b> · {r.count} người</div>
          <button className="btn sm primary" onClick={() => joinRoomCall(r.room_id)}>Tham gia</button>
          <button className="btn sm" aria-label="Bỏ qua" onClick={() => setDismissed((d) => [...d, r.id])}>✕</button>
        </div>
      ))}
      {notice && !call && <div className="room-call-banner" style={{ background: 'var(--gray-bg)', color: 'var(--gray)' }}><span style={{ flex: 1 }} className="small">{notice}</span><button className="btn sm" onClick={() => setNotice(null)}>✕</button></div>}
      {call && mini && (
        <div className="room-call-banner" role="status">
          <span className="live-dot" />
          <div style={{ flex: 1, minWidth: 0 }} className="small">Đang gọi nhóm <b>{call.room_name}</b> · {parts.length} người · còn {fmtSec(remaining)}</div>
          <button className="btn sm" onClick={toggleMute}>{muted ? 'Bật mic' : 'Tắt mic'}</button>
          <button className="btn sm primary" onClick={() => setMini(false)}>Mở</button>
        </div>
      )}
      </div>
      {call && !mini && (
        <div className="group-call" role="dialog" aria-label="Cuộc gọi nhóm">
          <div className="small" style={{ opacity: .75 }}>Gọi nhóm Việc Đến · không qua nhà mạng</div>
          <h2 style={{ margin: '4px 0 0' }}>{call.room_name}</h2>
          <div className="small"><span style={{ color: remaining <= 60 ? '#fbbf24' : undefined }}>Còn {fmtSec(remaining)}</span> · {parts.length}/8 người</div>
          <div className="gc-grid">
            {parts.map((p) => (
              <div key={p.member_id} className="gc-tile">
                <Avatar userId={p.user_id} name={p.name} has={false} />
                <b>{p.member_id === me?.member_id ? 'Bạn' : p.name}</b>
                <span className="gc-state">{p.member_id === me?.member_id ? (muted ? 'đã tắt mic' : 'mic đang bật') : ST[peerStates[p.member_id] || 'connecting'] || peerStates[p.member_id]}</span>
              </div>
            ))}
          </div>
          {parts.length <= 1 && <div className="small" style={{ textAlign: 'center', opacity: .8 }}>Đang chờ thành viên khác tham gia… (đã gửi thông báo cho cả nhóm)</div>}
          <div className="call-actions">
            <button className={`call-btn ${muted ? 'on' : ''}`} onClick={toggleMute} aria-label={muted ? 'Bật micro' : 'Tắt micro'}><Icon name="mic" size={24} /><span>{muted ? 'Bật mic' : 'Tắt mic'}</span></button>
            <button className="call-btn red" onClick={leave} aria-label="Rời cuộc gọi"><Icon name="phone" size={26} /><span>Rời</span></button>
            <button className="call-btn" onClick={() => { setMini(true); nav(`/rooms/${call.room_id}`); }} aria-label="Tin nhắn nhóm"><Icon name="message-alert" size={22} /><span>Tin nhắn</span></button>
          </div>
        </div>
      )}
    </C.Provider>
  );
}
