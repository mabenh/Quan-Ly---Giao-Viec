import { createContext, useCallback, useContext, useEffect, useState, ReactNode } from 'react';
import { get, post, tokenStore } from './api';

export interface Me {
  member_id: string | null; role: string; title?: string; company_id: string | null; company_name?: string; company_short_name?: string; timezone?: string; name: string; email?: string;
  phone?: string; user_id: string; department_id?: string; managed_groups: { id: string; name: string }[]; headed_departments: { id: string; name: string }[]; led_groups?: { id: string; name: string }[];
  memberships: { member_id: string; company_id: string; company_name: string; company_short_name?: string; role: string }[];
  pending_memberships: { id: string; company_name: string }[]; subscriptions: any[]; is_platform_admin?: boolean; has_avatar?: boolean;
  plan?: string; member_limit?: number;
  authority?: { tier: number; position: string | null; department_id: string | null; department: string | null; dept_function: string | null; hr_scoped: boolean; caps: string[] };
}

interface AuthCtx { me: Me | null; loading: boolean; bootError: string | null; adopt: (r: any) => Promise<void>; login: (e: string, p: string) => Promise<void>; register: (b: { phone: string; name: string; password: string }) => Promise<void>; logout: () => Promise<void>; reload: () => Promise<void>; switchCompany: (id: string) => Promise<void> }
const Ctx = createContext<AuthCtx>(null as any);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [me, setMe] = useState<Me | null>(null);
  const [loading, setLoading] = useState(true);
  const [bootError, setBootError] = useState<string | null>(null);
  // v14: lỗi mạng / máy chủ đang cập nhật KHÔNG làm mất đăng nhập — chỉ đăng xuất khi phiên thực sự hết hạn (401)
  const reload = useCallback(async () => {
    if (!tokenStore.access && !tokenStore.refresh) { setMe(null); setLoading(false); return; }
    try {
      const m = await get<Me>('/auth/me');
      if (m.member_id) localStorage.setItem('member_id', m.member_id); else localStorage.removeItem('member_id');
      try { localStorage.setItem('last_phone', (m as any).phone || ''); } catch { /* */ }
      setMe(m); setBootError(null); setLoading(false);
    } catch (e: any) {
      if (e?.status === 401 || !tokenStore.refresh) { setMe(null); setBootError(null); setLoading(false); }
      else setBootError(e?.status >= 500 ? 'Máy chủ tạm thời không phản hồi' : e?.message || 'Không kết nối được máy chủ');
    }
  }, []);
  useEffect(() => {
    if (!bootError) return;
    const t = setTimeout(reload, 4000);
    const on = () => reload();
    window.addEventListener('online', on);
    return () => { clearTimeout(t); window.removeEventListener('online', on); };
  }, [bootError, reload]);
  const adopt = async (r: any) => { tokenStore.set(r.access_token, r.refresh_token); await reload(); };
  useEffect(() => {
    reload();
    const h = () => setMe(null);
    window.addEventListener('auth:logout', h);
    return () => window.removeEventListener('auth:logout', h);
  }, [reload]);
  const login = async (identifier: string, password: string) => {
    const r = await post('/auth/login', { identifier, password });
    tokenStore.set(r.access_token, r.refresh_token);
    await reload();
  };
  const register = async (b: { phone: string; name: string; password: string }) => {
    const r = await post('/auth/register', b);
    tokenStore.set(r.access_token, r.refresh_token);
    await reload();
  };
  const logout = async () => {
    try { await post('/auth/logout', { refresh_token: tokenStore.refresh }); } catch { /* ignore */ }
    tokenStore.clear(); localStorage.removeItem('member_id'); setMe(null);
  };
  const switchCompany = async (companyId: string) => {
    const r = await post('/auth/switch-company', { companyId });
    tokenStore.set(r.access_token, r.refresh_token);
    await reload();
  };
  return <Ctx.Provider value={{ me, loading, bootError, adopt, login, register, logout, reload, switchCompany }}>{children}</Ctx.Provider>;
}

export const useAuth = () => useContext(Ctx);
export const isAdminRole = (r?: string) => r === 'owner' || r === 'admin';
export const isManagerRole = (r?: string) => isAdminRole(r) || r === 'manager';
export const isHRRole = (r?: string) => isAdminRole(r) || r === 'hr';
/** Quyền hạn v8 (theo chức vụ/tầng/phòng ban, cấu hình độc lập). */
export const can = (me: Me | null | undefined, cap: string) => !!me?.authority?.caps?.includes(cap);
export const tierOf = (me: Me | null | undefined) => me?.authority?.tier ?? (isAdminRole(me?.role) ? 4 : me?.role === 'employee' ? 7 : 5);
export const canAssignAny = (me: Me | null | undefined) => ['assign_all', 'assign_dept', 'assign_group'].some((c) => can(me, c));
