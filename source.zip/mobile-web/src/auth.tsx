import { createContext, useCallback, useContext, useEffect, useState, ReactNode } from 'react';
import { get, post, tokenStore } from './api';

export interface Me {
  member_id: string; role: string; title?: string; company_id: string; company_name: string; timezone: string; name: string; email: string;
  user_id: string; department_id?: string; managed_groups: { id: string; name: string }[]; headed_departments: { id: string; name: string }[];
  memberships: { member_id: string; company_id: string; company_name: string; role: string }[];
}

interface AuthCtx { me: Me | null; loading: boolean; login: (e: string, p: string) => Promise<void>; logout: () => Promise<void>; reload: () => Promise<void>; switchCompany: (id: string) => Promise<void> }
const Ctx = createContext<AuthCtx>(null as any);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [me, setMe] = useState<Me | null>(null);
  const [loading, setLoading] = useState(true);
  const reload = useCallback(async () => {
    if (!tokenStore.access) { setMe(null); setLoading(false); return; }
    try { const m = await get<Me>('/auth/me'); localStorage.setItem('member_id', m.member_id); setMe(m); } catch { setMe(null); } finally { setLoading(false); }
  }, []);
  useEffect(() => {
    reload();
    const h = () => setMe(null);
    window.addEventListener('auth:logout', h);
    return () => window.removeEventListener('auth:logout', h);
  }, [reload]);
  const login = async (email: string, password: string) => {
    const r = await post('/auth/login', { email, password });
    tokenStore.set(r.access_token, r.refresh_token);
    await reload();
  };
  const logout = async () => {
    try { await post('/auth/logout', { refresh_token: tokenStore.refresh }); } catch { /* ignore */ }
    tokenStore.clear(); localStorage.removeItem('member_id'); setMe(null);
  };
  const switchCompany = async (companyId: string) => {
    const r = await post('/auth/switch-company', { companyId });
    tokenStore.set(r.access_token, r.refresh_token);
    await reload();
  };
  return <Ctx.Provider value={{ me, loading, login, logout, reload, switchCompany }}>{children}</Ctx.Provider>;
}

export const useAuth = () => useContext(Ctx);
export const isAdminRole = (r?: string) => r === 'owner' || r === 'admin';
export const isManagerRole = (r?: string) => isAdminRole(r) || r === 'manager';
