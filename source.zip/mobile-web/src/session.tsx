import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { get, post, qs } from './api';
import { Badge, ErrorBox, Field, Select, Sheet, useAction, useLoad } from './ui';
import { Icon } from './icons';
import { PAUSE_OPTS, TIME_CAT, mins } from './labels';

function useTick(ms = 30000) { const [, set] = useState(0); useEffect(() => { const t = setInterval(() => set((x) => x + 1), ms); return () => clearInterval(t); }, [ms]); }
const since = (s: string) => Math.max(0, Math.round((Date.now() - new Date(s).getTime()) / 60000));

/** Phiên làm việc của tôi: mỗi người chỉ có 1 phiên đang chạy; chuyển việc tự đóng phiên cũ. */
export function SessionCard({ compact, onChange }: { compact?: boolean; onChange?: () => void }) {
  const { data: s, setData, error } = useLoad(() => get('/sessions/me'), []);
  const [sheet, setSheet] = useState<string | null>(null);
  const a = useAction();
  useTick();
  if (error || !s) return null;
  const act = (fn: () => Promise<any>) => a.run(async () => { setData(await fn()); setSheet(null); onChange?.(); });
  const open = s.open;
  const restOk = s.rest.enabled && open && ['objective_pause', 'waiting'].includes(open.category) && s.rest.balance > 0 && !s.rest.pending;
  if (!s.active && !open && compact) return (
    <div className="card session idle">
      <div className="row"><Icon name="timer" size={18} /><span style={{ flex: 1 }} className="small">Chưa bắt đầu phiên làm việc</span>
        <button className="btn sm primary" onClick={() => setSheet('switch')}>Bắt đầu</button></div>
      <Sheet open={sheet === 'switch'} onClose={() => setSheet(null)} title="Bắt đầu / chuyển việc"><SwitchForm busy={a.busy} error={a.error} onSubmit={(b) => act(() => post('/sessions/start', b))} /></Sheet>
    </div>
  );
  return (
    <div className={`card session ${s.active ? 'running' : open ? 'paused' : 'idle'}`}>
      {s.active && (
        <div className="row"><span className="live-dot" /><div style={{ flex: 1, minWidth: 0 }}>
          <div className="small muted">Đang thực hiện · {mins(since(s.active.started_at))}{s.active.location_name ? ` · ${s.active.location_name}` : ''}</div>
          <Link to={`/tasks/${s.active.task_id}`} className="title ellipsis" style={{ display: 'block' }}>{s.active.task_title}</Link></div></div>
      )}
      {open && (
        <div className="row"><Badge tone={TIME_CAT[open.category]?.[1]}>{TIME_CAT[open.category]?.[0]}</Badge>
          <span className="small" style={{ flex: 1 }}>{mins(since(open.started_at))}{open.task_title ? ` · ${open.task_title}` : ''}{open.reason ? ` — ${open.reason}` : ''}</span></div>
      )}
      {!s.active && !open && <div className="small muted">Chưa có phiên đang chạy.</div>}
      {s.rest.pending && <div className="small" style={{ color: 'var(--amber)' }}>Đang chờ trưởng nhóm duyệt nghỉ…</div>}
      <div className="actions" style={{ marginTop: 6 }}>
        {s.active && <button className="btn sm" onClick={() => setSheet('pause')}><Icon name="clock" size={16} />Hoãn / chờ</button>}
        <button className="btn sm" onClick={() => setSheet('switch')}><Icon name="route" size={16} />{s.active ? 'Chuyển việc' : 'Bắt đầu'}</button>
        {open && <button className="btn sm primary" disabled={a.busy} onClick={() => act(() => post('/sessions/resume'))}>▶ Tiếp tục</button>}
        {restOk && <button className="btn sm" disabled={a.busy} onClick={() => act(() => post('/rest/request', {}))}>Xin nghỉ (quỹ {s.rest.balance}p)</button>}
        {(s.active || open) && <button className="btn sm" disabled={a.busy} onClick={() => confirm('Kết thúc phiên làm việc?') && act(() => post('/sessions/end', { reason: 'end' }))}>Kết thúc</button>}
      </div>
      {!compact && s.today && (
        <div className="cnt-row">{Object.entries(s.today).filter(([, v]) => (v as number) > 0).map(([k, v]) => <span key={k}>{TIME_CAT[k]?.[0]} <b>{mins(v as number)}</b></span>)}
          {s.rest.enabled && <span>Quỹ nghỉ <b>{s.rest.balance}p</b></span>}</div>
      )}
      <ErrorBox error={a.error} />
      <Sheet open={sheet === 'pause'} onClose={() => setSheet(null)} title="Hoãn / tạm dừng"><PauseForm busy={a.busy} error={a.error} onSubmit={(b) => act(() => post('/sessions/pause', b))} /></Sheet>
      <Sheet open={sheet === 'switch'} onClose={() => setSheet(null)} title={s.active ? 'Chuyển sang việc khác' : 'Bắt đầu việc'}><SwitchForm busy={a.busy} error={a.error} current={s.active?.task_id} onSubmit={(b) => act(() => post('/sessions/start', b))} /></Sheet>
    </div>
  );
}

export function PauseForm({ busy, error, onSubmit }: { busy: boolean; error: string | null; onSubmit: (b: any) => void }) {
  const [c, setC] = useState('objective_pause'); const [r, setR] = useState(''); const [p, setP] = useState('');
  return (
    <>
      <Field label="Loại"><Select value={c} onChange={setC} options={PAUSE_OPTS} /></Field>
      <Field label="Lý do" required={['objective_pause', 'waiting', 'subjective_pause'].includes(c)}><input value={r} onChange={(e) => setR(e.target.value)} placeholder="VD: Máy hàn túi số 2 hỏng" /></Field>
      {['objective_pause', 'waiting'].includes(c) && <Field label="Bộ phận / người liên quan (nếu có)"><input value={p} onChange={(e) => setP(e.target.value)} /></Field>}
      <p className="small muted">Hoãn khách quan được tính riêng và không làm giảm hiệu suất của bạn; trưởng nhóm sẽ xác nhận. Không tự ý rời vị trí — nếu không có việc phù hợp, có thể xin dùng quỹ nghỉ bổ sung.</p>
      <ErrorBox error={error} />
      <button className="btn primary block" disabled={busy} onClick={() => onSubmit({ category: c, reason: r || undefined, relatedParty: p || undefined })}>Xác nhận</button>
    </>
  );
}

export function SwitchForm({ busy, error, current, onSubmit, presetTaskId }: { busy: boolean; error: string | null; current?: string; onSubmit: (b: any) => void; presetTaskId?: string }) {
  const tasks = useLoad(() => get('/tasks' + qs({ mine: 'any', status: 'not_started,in_progress,revision_requested', limit: 100 })), []);
  const locs = useLoad(() => get('/company/locations'), []);
  const [t, setT] = useState(presetTaskId || ''); const [loc, setLoc] = useState('');
  const items = (tasks.data?.items || []).filter((x: any) => x.id !== current && !(x.child_count > 0));
  const sel = items.find((x: any) => x.id === t);
  return (
    <>
      {!presetTaskId && <Field label="Nhiệm vụ"><Select value={t} onChange={setT} options={items.map((x: any) => [x.id, `${x.code} · ${x.title}`])} placeholder="— Chọn việc được giao —" /></Field>}
      <Field label={sel?.location_required ? 'Vị trí làm việc (bắt buộc với việc này)' : 'Vị trí làm việc (không bắt buộc)'}>
        <Select value={loc} onChange={setLoc} options={(locs.data || []).filter((l: any) => l.active).map((l: any) => [l.id, l.name])} placeholder={sel?.location_required ? '— Theo vị trí của nhiệm vụ —' : '— Không khai —'} />
      </Field>
      <p className="small muted">Phiên hiện tại (nếu có) sẽ được kết thúc và lưu lịch sử trước khi bắt đầu phiên mới.</p>
      <ErrorBox error={error} />
      <button className="btn primary block" disabled={busy || !t} onClick={() => onSubmit({ taskId: t, locationId: loc || undefined })}>Bắt đầu</button>
    </>
  );
}
