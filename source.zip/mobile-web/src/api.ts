// Lớp gọi API: tự làm mới token, gắn Idempotency-Key cho POST để retry khi mất mạng không tạo bản ghi trùng.
const BASE = (import.meta.env.VITE_API_URL as string) || '/api/v1';

export class ApiError extends Error {
  constructor(public code: string, message: string, public status: number, public details?: any) { super(message); }
}

const store = {
  get access() { return localStorage.getItem('access_token'); },
  get refresh() { return localStorage.getItem('refresh_token'); },
  set(a: string, r: string) { localStorage.setItem('access_token', a); localStorage.setItem('refresh_token', r); },
  clear() { localStorage.removeItem('access_token'); localStorage.removeItem('refresh_token'); },
};
export const tokenStore = store;

/** Kết quả làm mới phiên: ok | expired (phải đăng nhập lại) | network (lỗi tạm thời — KHÔNG đăng xuất). */
type RefreshResult = 'ok' | 'expired' | 'network';
let refreshing: Promise<RefreshResult> | null = null;
async function tryRefresh(): Promise<RefreshResult> {
  if (!store.refresh) return 'expired';
  refreshing ||= (async (): Promise<RefreshResult> => {
    const used = store.refresh;
    try {
      const r = await fetch(BASE + '/auth/refresh', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ refresh_token: used, memberId: localStorage.getItem('member_id') || undefined }) });
      if (r.status === 401) return store.refresh !== used ? 'ok' : 'expired';   // tab khác đã làm mới trước
      if (!r.ok) return 'network';
      const j = await r.json();
      store.set(j.access_token, j.refresh_token);
      return 'ok';
    } catch { return 'network'; } finally { setTimeout(() => (refreshing = null), 0); }
  })();
  return refreshing;
}

// ---------- v13: chẩn đoán lỗi kết nối + trạng thái mạng ----------
type DiagItem = { code: string; status?: number; path?: string; message?: string; online?: boolean; at: string };
const diagQueue: DiagItem[] = [];
let diagTimer: any = null;
let netFails = 0;
function netStatus(ok: boolean) {
  const before = netFails;
  netFails = ok ? 0 : netFails + 1;
  if ((before >= 2) !== (netFails >= 2)) window.dispatchEvent(new CustomEvent('net:status', { detail: { degraded: netFails >= 2 } }));
}
export const isNetDegraded = () => netFails >= 2;
function reportDiag(it: Omit<DiagItem, 'at' | 'online'>) {
  if (it.path?.startsWith('/diag/')) return;
  diagQueue.push({ ...it, path: it.path?.split('?')[0], online: navigator.onLine, at: new Date().toISOString() });
  if (diagQueue.length > 30) diagQueue.splice(0, diagQueue.length - 30);
  if (!diagTimer) diagTimer = setTimeout(flushDiag, 20000);
}
async function flushDiag() {
  diagTimer = null;
  if (!diagQueue.length || !store.access || !navigator.onLine) { if (diagQueue.length) diagTimer = setTimeout(flushDiag, 60000); return; }
  const items = diagQueue.splice(0, 30);
  const app = (window as any).Capacitor?.isNativePlatform?.() ? 'android-app' : 'web';
  try {
    const r = await fetch(BASE + '/diag/client-errors', { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${store.access}` },
      body: JSON.stringify({ items, app, ua: navigator.userAgent.slice(0, 200) }) });
    if (!r.ok && r.status >= 500) diagQueue.unshift(...items);
  } catch { diagQueue.unshift(...items); diagTimer = setTimeout(flushDiag, 60000); }
}
window.addEventListener('online', () => { netStatus(true); window.dispatchEvent(new CustomEvent('net:status', { detail: { degraded: false } })); });

const uuid = () => (crypto as any).randomUUID?.() || Math.random().toString(36).slice(2) + Date.now().toString(36);

export async function api<T = any>(method: string, path: string, body?: any, opts: { idempotencyKey?: string; raw?: boolean; retries?: number } = {}): Promise<T> {
  const key = method === 'POST' ? opts.idempotencyKey || uuid() : undefined;
  const isForm = body instanceof FormData;
  // v13: hủy yêu cầu treo quá 25 giây (mạng 4G chập chờn làm fetch treo vô hạn → app "đứng")
  const doFetch = () => {
    const ac = typeof AbortController !== 'undefined' ? new AbortController() : null;
    const t = ac ? setTimeout(() => ac.abort(), isForm ? 120000 : 25000) : null;
    return fetch(BASE + path, {
    method, signal: ac?.signal,
    headers: {
      ...(isForm ? {} : { 'Content-Type': 'application/json' }),
      ...(store.access ? { Authorization: `Bearer ${store.access}` } : {}),
      ...(key ? { 'Idempotency-Key': key } : {}),
    },
    body: body === undefined ? undefined : isForm ? body : JSON.stringify(body),
  }).finally(() => t && clearTimeout(t));
  };
  const tokenUsed = store.access;
  let res: Response | null = null;
  const retries = opts.retries ?? 2;
  for (let i = 0; i <= retries; i++) {
    try { res = await doFetch(); break; } catch (e: any) {
      if (i === retries) {
        netStatus(false);
        const timeout = e?.name === 'AbortError';
        reportDiag({ code: timeout ? 'TIMEOUT' : 'NETWORK', path, message: String(e?.message || '').slice(0, 200) });
        throw new ApiError('NETWORK', !navigator.onLine ? 'Điện thoại đang mất mạng. Vui lòng kiểm tra Wi-Fi/4G rồi thử lại.' : timeout ? 'Máy chủ phản hồi chậm. Vui lòng thử lại.' : 'Kết nối không ổn định. Vui lòng thử lại.', 0);
      }
      // chờ có mạng lại (tối đa 6 giây) rồi thử lại
      await new Promise<void>((r) => { const t = setTimeout(r, 700 * (i + 1) + (navigator.onLine ? 0 : 5000)); if (!navigator.onLine) window.addEventListener('online', () => { clearTimeout(t); r(); }, { once: true }); });
    }
  }
  netStatus(true);
  // Cổng nginx trả 502/503/504 khi máy chủ đang khởi động lại (cập nhật) → thử lại GET một lần sau 2 giây
  if ([502, 503, 504].includes(res!.status) && method === 'GET' && !(opts as any)._gw) {
    reportDiag({ code: 'HTTP_' + res!.status, status: res!.status, path });
    await new Promise((r) => setTimeout(r, 2000));
    return api(method, path, body, { ...opts, _gw: true } as any);
  }
  if (res!.status === 401 && path !== '/auth/login') {
    // Tab khác đã có token mới -> dùng lại ngay; nếu không thì làm mới phiên. Lỗi mạng khi làm mới: báo lỗi tạm thời, không đăng xuất.
    if (store.access && store.access !== tokenUsed) return api(method, path, body, { ...opts, idempotencyKey: key });
    const rr = await tryRefresh();
    if (rr === 'ok') return api(method, path, body, { ...opts, idempotencyKey: key });
    if (rr === 'network') { reportDiag({ code: 'REFRESH_FAILED', path }); throw new ApiError('NETWORK', 'Kết nối không ổn định. Vui lòng thử lại.', 0); }
  }
  if (res!.status === 429) reportDiag({ code: 'RATE_LIMITED', status: 429, path });
  if (res!.status >= 500) reportDiag({ code: 'HTTP_' + res!.status, status: res!.status, path });
  if (res!.status === 429) throw new ApiError('RATE_LIMITED', 'Hệ thống đang bận, vui lòng thử lại sau ít giây.', 429);
  if (opts.raw) return res as any;
  const j = await res!.json().catch(() => ({}));
  if (!res!.ok) {
    if (res!.status === 401) { store.clear(); window.dispatchEvent(new Event('auth:logout')); }
    throw new ApiError(j?.error?.code || 'HTTP_' + res!.status, j?.error?.message || 'Có lỗi xảy ra', res!.status, j?.error?.details);
  }
  return j;
}

export const get = <T = any>(p: string) => api<T>('GET', p);
export const post = <T = any>(p: string, b?: any) => api<T>('POST', p, b ?? {});
export const patch = <T = any>(p: string, b?: any) => api<T>('PATCH', p, b ?? {});
export const put = <T = any>(p: string, b?: any) => api<T>('PUT', p, b ?? {});
export const del = <T = any>(p: string, b?: any) => api<T>('DELETE', p, b);

export async function upload(parentType: string, parentId: string, file: File) {
  const fd = new FormData(); fd.append('file', file);
  return api('POST', `/files?parentType=${parentType}&parentId=${parentId}`, fd);
}

export async function download(path: string, filename: string) {
  const res: Response = await api('GET', path, undefined, { raw: true });
  if (!res.ok) { const j = await res.json().catch(() => ({})); throw new ApiError(j?.error?.code, j?.error?.message || 'Không tải được tệp', res.status); }
  const blob = await res.blob();
  const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = filename; a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 5000);
}

export function qs(o: Record<string, any>) {
  const p = Object.entries(o).filter(([, v]) => v !== undefined && v !== null && v !== '').map(([k, v]) => `${k}=${encodeURIComponent(v)}`);
  return p.length ? '?' + p.join('&') : '';
}
