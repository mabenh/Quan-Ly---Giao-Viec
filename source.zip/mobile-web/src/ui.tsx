import { ReactNode, useCallback, useEffect, useRef, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ApiError } from './api';

export function useLoad<T>(fn: () => Promise<T>, deps: any[] = []) {
  const [data, setData] = useState<T | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const fnRef = useRef(fn); fnRef.current = fn;
  const reload = useCallback(async () => {
    setLoading(true); setError(null);
    try { setData(await fnRef.current()); } catch (e: any) { setError(e?.message || 'Lỗi tải dữ liệu'); } finally { setLoading(false); }
  }, []);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  useEffect(() => { reload(); }, deps);
  return { data, error, loading, reload, setData };
}

/** Bọc thao tác có xác nhận lỗi dễ hiểu; chống bấm đúp khi đang gửi. */
export function useAction() {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const run = async <T,>(fn: () => Promise<T>): Promise<T | undefined> => {
    if (busy) return;
    setBusy(true); setError(null);
    try { return await fn(); } catch (e: any) {
      setError(e instanceof ApiError ? e.message : e?.message || 'Có lỗi xảy ra');
    } finally { setBusy(false); }
  };
  return { busy, error, setError, run };
}

export const Badge = ({ tone = 'gray', children }: { tone?: string; children: ReactNode }) => <span className={`badge ${tone}`}>{children}</span>;

export function Header({ title, back, right }: { title: string; back?: boolean | string; right?: ReactNode }) {
  const nav = useNavigate();
  return (
    <div className="page-head">
      {back && <button className="icon-btn" aria-label="Quay lại" onClick={() => (typeof back === 'string' ? nav(back) : nav(-1))}>‹</button>}
      <h1>{title}</h1>
      <div className="spacer" />
      {right}
    </div>
  );
}

export const Card = ({ children, className = '', to, onClick }: { children: ReactNode; className?: string; to?: string; onClick?: () => void }) =>
  to ? <Link to={to} className={`card link ${className}`}>{children}</Link> : <div className={`card ${className}`} onClick={onClick}>{children}</div>;

export const Loading = () => <div className="muted center pad">Đang tải…</div>;
export const ErrorBox = ({ error }: { error?: string | null }) => (error ? <div className="alert error" role="alert">{error}</div> : null);
export const Empty = ({ children }: { children: ReactNode }) => <div className="empty">{children}</div>;

export function Field({ label, hint, required, children }: { label: string; hint?: string; required?: boolean; children: ReactNode }) {
  return (
    <label className="field">
      <span className="label">{label}{required && <span className="req"> *</span>}</span>
      {children}
      {hint && <span className="hint">{hint}</span>}
    </label>
  );
}

export function Select({ value, onChange, options, placeholder, ...rest }: { value: any; onChange: (v: string) => void; options: Record<string, string> | [string, string][]; placeholder?: string; [k: string]: any }) {
  const opts = Array.isArray(options) ? options : Object.entries(options);
  return (
    <select value={value ?? ''} onChange={(e) => onChange(e.target.value)} {...rest}>
      {placeholder !== undefined && <option value="">{placeholder}</option>}
      {opts.map(([k, v]) => <option key={k} value={k}>{v}</option>)}
    </select>
  );
}

export function Tabs({ value, onChange, tabs }: { value: string; onChange: (v: string) => void; tabs: [string, ReactNode][] }) {
  return (
    <div className="tabs" role="tablist">
      {tabs.map(([k, l]) => <button key={k} role="tab" aria-selected={value === k} className={value === k ? 'active' : ''} onClick={() => onChange(k)}>{l}</button>)}
    </div>
  );
}

export function Sheet({ open, onClose, title, children }: { open: boolean; onClose: () => void; title: string; children: ReactNode }) {
  if (!open) return null;
  return (
    <div className="sheet-backdrop" onClick={onClose}>
      <div className="sheet" role="dialog" aria-label={title} onClick={(e) => e.stopPropagation()}>
        <div className="sheet-head"><h2>{title}</h2><button className="icon-btn" aria-label="Đóng" onClick={onClose}>✕</button></div>
        {children}
      </div>
    </div>
  );
}

export const KV = ({ k, v }: { k: string; v: ReactNode }) => <div className="kv"><span>{k}</span><b>{v ?? '—'}</b></div>;

export function Timeline({ items }: { items: { at: string; title: ReactNode; body?: ReactNode; tone?: string }[] }) {
  return (
    <ol className="timeline">
      {items.map((i, idx) => (
        <li key={idx} className={i.tone || ''}>
          <div className="tl-title">{i.title}</div>
          {i.body && <div className="tl-body">{i.body}</div>}
          <div className="tl-at">{new Date(i.at).toLocaleString('vi-VN')}</div>
        </li>
      ))}
    </ol>
  );
}

export function Score({ v }: { v: number | null | undefined }) {
  if (v === null || v === undefined) return <span className="muted">—</span>;
  const tone = v >= 80 ? 'green' : v >= 60 ? 'blue' : v >= 40 ? 'amber' : 'red';
  return <span className={`score ${tone}`}>{Math.round(v * 10) / 10}</span>;
}

export function Bar({ value, max = 100 }: { value: number | null; max?: number }) {
  return <div className="bar" aria-hidden><div style={{ width: `${Math.max(0, Math.min(100, ((value || 0) / max) * 100))}%` }} /></div>;
}
