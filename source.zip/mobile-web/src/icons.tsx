import {
  Forklift, PackagePlus, PackageMinus, FlaskConical, Truck, Boxes, ShieldCheck, MessageSquareWarning, PackageX, ClipboardCheck, Package, Wrench,
  Sparkles, ShoppingCart, Handshake, ChartColumn, DoorOpen, PackageCheck, Car, KeyRound, House, ListChecks, UserPlus, Network, CircleUserRound,
  Bell, CalendarDays, Phone, Palmtree, FileText, TriangleAlert, Stamp, Workflow, BookOpen, Route, ChartNoAxesCombined, Users, UserCog, Megaphone,
  QrCode, Timer, Pin, ScrollText, Building2, Settings, ArrowRightLeft, TrendingUp, UserMinus, Mic, Headset, GitBranch, LayoutGrid, ClipboardList,
  LucideIcon, ChevronRight, ChevronDown, Plus, Search, CheckCircle2, Clock, AlertCircle, Briefcase,
} from 'lucide-react';

/** Biểu tượng theo khóa (dùng cho mẫu việc, giấy phép, menu chức năng). */
export const ICONS: Record<string, LucideIcon> = {
  'package-plus': PackagePlus, 'package-minus': PackageMinus, flask: FlaskConical, truck: Truck, boxes: Boxes, shield: ShieldCheck,
  'message-alert': MessageSquareWarning, 'package-x': PackageX, 'clipboard-check': ClipboardCheck, package: Package, wrench: Wrench,
  sparkles: Sparkles, cart: ShoppingCart, handshake: Handshake, chart: ChartColumn, door: DoorOpen, 'package-check': PackageCheck, car: Car,
  forklift: Forklift, key: KeyRound, home: House, tasks: ListChecks, assign: UserPlus, hr: Network, me: CircleUserRound, bell: Bell,
  calendar: CalendarDays, phone: Phone, leave: Palmtree, record: FileText, alert: TriangleAlert, permit: Stamp, flow: Workflow, book: BookOpen,
  route: Route, perf: ChartNoAxesCombined, users: Users, userCog: UserCog, tip: Megaphone, qr: QrCode, timer: Timer, pin: Pin, decision: ScrollText,
  company: Building2, settings: Settings, transfer: ArrowRightLeft, promote: TrendingUp, terminate: UserMinus, mic: Mic, headset: Headset,
  tree: GitBranch, grid: LayoutGrid, list: ClipboardList, chevron: ChevronRight, down: ChevronDown, plus: Plus, search: Search, ok: CheckCircle2,
  clock: Clock, warn: AlertCircle, work: Briefcase,
};

export function Icon({ name, size = 20, className, strokeWidth = 2 }: { name: string; size?: number; className?: string; strokeWidth?: number }) {
  const C = ICONS[name] || Briefcase;
  return <C size={size} className={className} strokeWidth={strokeWidth} aria-hidden />;
}

/** Ô biểu tượng có nền màu (dùng cho tile chức năng). */
export function IconChip({ name, tone = 'blue', size = 22 }: { name: string; tone?: string; size?: number }) {
  return <span className={`ichip ${tone}`}><Icon name={name} size={size} /></span>;
}
