import { useEffect, useState } from 'react';
import { Link, NavLink, Navigate, Outlet, Route, Routes, useLocation } from 'react-router-dom';
import { useAuth } from './auth';
import { get } from './api';
import { Loading } from './ui';
import { ROLE } from './labels';
import Login from './pages/Login';
import Home from './pages/Home';
import Work from './pages/Work';
import TaskDetail from './pages/TaskDetail';
import TaskForm from './pages/TaskForm';
import WorkRecordForm from './pages/WorkRecordForm';
import WorkRecordDetail from './pages/WorkRecordDetail';
import OvertimeForm from './pages/OvertimeForm';
import OvertimeDetail from './pages/OvertimeDetail';
import ReportForm from './pages/ReportForm';
import ReportDetail from './pages/ReportDetail';
import Groups from './pages/Groups';
import GroupDetail from './pages/GroupDetail';
import Performance from './pages/Performance';
import Profile from './pages/Profile';
import Notifications from './pages/Notifications';
import Escalations from './pages/Escalations';
import AdminMembers from './pages/AdminMembers';
import AdminSettings from './pages/AdminSettings';
import TechBoard from './pages/TechBoard';
import ProfilePage from './pages/ProfilePage';
import PersonProfile from './pages/PersonProfile';
import Upgrade from './pages/Upgrade';
import Platform from './pages/Platform';
import NoCompanyHome from './pages/NoCompanyHome';
import QuickClaimForm from './pages/QuickClaimForm';
import QuickClaimDetail from './pages/QuickClaimDetail';
import LeaveForm from './pages/LeaveForm';
import LeaveDetail from './pages/LeaveDetail';
import TeamWeek from './pages/TeamWeek';
import ContactReturnPrompt from './pages/ContactReturnPrompt';
import { Avatar } from './ui';
import { Icon } from './icons';
import Assign from './pages/Assign';
import PermitDetail from './pages/PermitDetail';
import PermitForm from './pages/PermitForm';
import DecisionDetail from './pages/DecisionDetail';
import HrHub from './pages/HrHub';
import OrgChart from './pages/OrgChart';
import Decisions from './pages/Decisions';
import Procedures from './pages/Procedures';
import ProcedureDetail from './pages/ProcedureDetail';
import AssignFlow from './pages/AssignFlow';
import AssignGuide from './pages/AssignGuide';

function Layout() {
  const { me } = useAuth();
  const loc = useLocation();
  const [unread, setUnread] = useState(0);
  useEffect(() => {
    let alive = true;
    const tick = () => (me?.company_id ? get('/notifications?unread=true&limit=1').then((r) => alive && setUnread(r.unread)).catch(() => {}) : Promise.resolve());
    tick();
    const t = setInterval(tick, 30000);
    return () => { alive = false; clearInterval(t); };
  }, [loc.pathname]);
  const canAssign = ['owner', 'admin', 'manager', 'hr'].includes(me?.role || '');
  const nav: [string, string, string][] = me?.company_id ? [
    ['/', 'home', 'Trang chủ'], ['/work', 'tasks', 'Công việc'], canAssign ? ['/assign', 'assign', 'Giao việc'] : ['/groups', 'users', 'Nhóm'], ['/hr', 'hr', 'Nhân sự'], ['/me', 'me', 'Cá nhân'],
  ] : [['/', 'home', 'Trang chủ'], ['/profile', 'record', 'Hồ sơ'], ['/upgrade', 'company', 'Doanh nghiệp'], ['/me', 'me', 'Tài khoản']];
  return (
    <div className="app">
      <header className="topbar">
        <div className="brand-row">
          <img src="/logo-mark.png" alt="Việc Đến" />
          <div style={{ minWidth: 0 }}>
            <div className="brand">{me?.company_name || 'Việc Đến'}</div>
            <div className="sub">{me?.name}{me?.role ? ` · ${ROLE[me.role]}` : ''}</div>
          </div>
        </div>
        <Link to="/me" aria-label="Hồ sơ của tôi"><Avatar userId={me?.user_id} name={me?.name} has={!!me?.has_avatar} size="sm" /></Link>
        {me?.company_id && <Link to="/notifications" className="bell" aria-label={`Thông báo, ${unread} chưa đọc`}><Icon name="bell" size={21} />{unread > 0 && <span className="dot">{unread > 99 ? '99+' : unread}</span>}</Link>}
      </header>
      <main><Outlet /></main>
      {me?.company_id && <ContactReturnPrompt />}
      <nav className="bottom-nav" aria-label="Điều hướng chính">
        <div className="inner" style={{ gridTemplateColumns: `repeat(${nav.length}, 1fr)` }}>
          {nav.map(([to, ic, l]) => (
            <NavLink key={to} to={to} end={to === '/'} className={({ isActive }) => (isActive ? 'active' : '')}>
              <span className="ic" aria-hidden><Icon name={ic} size={21} /></span>{l}
            </NavLink>
          ))}
        </div>
      </nav>
    </div>
  );
}

export default function App() {
  const { me, loading } = useAuth();
  if (loading) return <Loading />;
  if (!me) return <Routes><Route path="*" element={<Login />} /></Routes>;
  if (!me.company_id) {
    return (
      <Routes>
        <Route element={<Layout />}>
          <Route index element={<NoCompanyHome />} />
          <Route path="profile" element={<ProfilePage />} />
          <Route path="upgrade" element={<Upgrade />} />
          <Route path="platform" element={<Platform />} />
          <Route path="me" element={<Profile />} />
          <Route path="*" element={<Navigate to="/" />} />
        </Route>
      </Routes>
    );
  }
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route index element={<Home />} />
        <Route path="work" element={<Work />} />
        <Route path="tasks/new" element={<TaskForm />} />
        <Route path="tasks/:id" element={<TaskDetail />} />
        <Route path="work-records/new" element={<WorkRecordForm />} />
        <Route path="work-records/:id" element={<WorkRecordDetail />} />
        <Route path="overtime/new" element={<OvertimeForm />} />
        <Route path="overtime/:id" element={<OvertimeDetail />} />
        <Route path="reports/new" element={<ReportForm />} />
        <Route path="reports/:id" element={<ReportDetail />} />
        <Route path="quick/new" element={<QuickClaimForm />} />
        <Route path="q" element={<QuickClaimForm />} />
        <Route path="quick/:id" element={<QuickClaimDetail />} />
        <Route path="leaves/new" element={<LeaveForm />} />
        <Route path="leaves/:id" element={<LeaveDetail />} />
        <Route path="team" element={<TeamWeek />} />
        <Route path="assign" element={<Assign />} />
        <Route path="permits/new" element={<PermitForm />} />
        <Route path="permits/:id" element={<PermitDetail />} />
        <Route path="decisions/:id" element={<DecisionDetail />} />
        <Route path="hr" element={<HrHub />} />
        <Route path="hr/org" element={<OrgChart />} />
        <Route path="hr/decisions" element={<Decisions />} />
        <Route path="hr/procedures" element={<Procedures />} />
        <Route path="hr/procedures/:id" element={<ProcedureDetail />} />
        <Route path="hr/flow" element={<AssignFlow />} />
        <Route path="hr/guide" element={<AssignGuide />} />
        <Route path="tech" element={<TechBoard />} />
        <Route path="groups" element={<Groups />} />
        <Route path="groups/:id" element={<GroupDetail />} />
        <Route path="performance" element={<Performance />} />
        <Route path="me" element={<Profile />} />
        <Route path="profile" element={<ProfilePage />} />
        <Route path="people/:userId" element={<PersonProfile />} />
        <Route path="upgrade" element={<Upgrade />} />
        <Route path="platform" element={<Platform />} />
        <Route path="notifications" element={<Notifications />} />
        <Route path="escalations" element={<Escalations />} />
        <Route path="admin/members" element={<AdminMembers />} />
        <Route path="admin/settings" element={<AdminSettings />} />
        <Route path="*" element={<Navigate to="/" />} />
      </Route>
    </Routes>
  );
}
