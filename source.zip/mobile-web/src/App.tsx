import React, { Suspense, lazy, useEffect, useState } from 'react';
import { Link, NavLink, Navigate, Outlet, Route, Routes, useLocation } from 'react-router-dom';
import { canAssignAny, useAuth } from './auth';
import { get } from './api';
import { Loading } from './ui';
import { ROLE } from './labels';
import { AppStatus, CompanySwitcher } from './appstatus';
import Login from './pages/Login';
import Home from './pages/Home';
import Work from './pages/Work';
/** Tải trang theo yêu cầu; nếu tệp cũ đã bị thay sau khi máy chủ cập nhật thì tải lại app một lần để lấy bản mới. */
function lz<T extends React.ComponentType<any>>(f: () => Promise<{ default: T }>) {
  return lazy(() => f().then((m) => { try { sessionStorage.removeItem('chunk-reload'); } catch { /* */ } return m; }).catch((e) => {
    let tried = false; try { tried = sessionStorage.getItem('chunk-reload') === '1'; sessionStorage.setItem('chunk-reload', '1'); } catch { /* */ }
    if (!tried) { location.reload(); return new Promise<{ default: T }>(() => {}); }
    throw e;
  }));
}
const TaskDetail = lz(() => import('./pages/TaskDetail'));
const TaskForm = lz(() => import('./pages/TaskForm'));
const WorkRecordForm = lz(() => import('./pages/WorkRecordForm'));
const WorkRecordDetail = lz(() => import('./pages/WorkRecordDetail'));
const OvertimeDetail = lz(() => import('./pages/OvertimeDetail'));
const ReportForm = lz(() => import('./pages/ReportForm'));
const ReportDetail = lz(() => import('./pages/ReportDetail'));
const Reports = lz(() => import('./pages/Reports'));
const JobRoles = lz(() => import('./pages/JobRoles'));
const Privacy = lz(() => import('./pages/Privacy'));
const OvertimeException = lz(() => import('./pages/OvertimeException'));
const BoardDash = lz(() => import('./pages/Dashboards').then((m) => ({ default: m.BoardDash })));
const FeedbackInbox = lz(() => import('./pages/Dashboards').then((m) => ({ default: m.FeedbackInbox })));
const MyTime = lz(() => import('./pages/Dashboards').then((m) => ({ default: m.MyTime })));
const ScopeDash = lz(() => import('./pages/Dashboards').then((m) => ({ default: m.ScopeDash })));
const TeamLive = lz(() => import('./pages/Dashboards').then((m) => ({ default: m.TeamLive })));
const ChainDetail = lz(() => import('./pages/Chains').then((m) => ({ default: m.ChainDetail })));
const ChainList = lz(() => import('./pages/Chains').then((m) => ({ default: m.ChainList })));
const HandoverList = lz(() => import('./pages/Chains').then((m) => ({ default: m.HandoverList })));
const ConductDetail = lz(() => import('./pages/Conduct').then((m) => ({ default: m.ConductDetail })));
const ConductForm = lz(() => import('./pages/Conduct').then((m) => ({ default: m.ConductForm })));
const ConductList = lz(() => import('./pages/Conduct').then((m) => ({ default: m.ConductList })));
const PrivacyRequests = lz(() => import('./pages/PrivacyAdmin').then((m) => ({ default: m.PrivacyRequests })));
const SecurityCenter = lz(() => import('./pages/PrivacyAdmin').then((m) => ({ default: m.SecurityCenter })));
const Groups = lz(() => import('./pages/Groups'));
const GroupDetail = lz(() => import('./pages/GroupDetail'));
const Performance = lz(() => import('./pages/Performance'));
const Profile = lz(() => import('./pages/Profile'));
const Notifications = lz(() => import('./pages/Notifications'));
const Escalations = lz(() => import('./pages/Escalations'));
const AdminMembers = lz(() => import('./pages/AdminMembers'));
const AdminSettings = lz(() => import('./pages/AdminSettings'));
const TechBoard = lz(() => import('./pages/TechBoard'));
const ProfilePage = lz(() => import('./pages/ProfilePage'));
const PersonProfile = lz(() => import('./pages/PersonProfile'));
const Upgrade = lz(() => import('./pages/Upgrade'));
const Platform = lz(() => import('./pages/Platform'));
import NoCompanyHome from './pages/NoCompanyHome';
const QuickClaimForm = lz(() => import('./pages/QuickClaimForm'));
const QuickClaimDetail = lz(() => import('./pages/QuickClaimDetail'));
const LeaveForm = lz(() => import('./pages/LeaveForm'));
const LeaveDetail = lz(() => import('./pages/LeaveDetail'));
const TeamWeek = lz(() => import('./pages/TeamWeek'));
import ContactReturnPrompt from './pages/ContactReturnPrompt';
import { Avatar } from './ui';
import { Icon } from './icons';
const Assign = lz(() => import('./pages/Assign'));
const Templates = lz(() => import('./pages/Templates'));
const AttendanceForm = lz(() => import('./pages/Attendance').then((m) => ({ default: m.AttendanceForm })));
const MemberReportDetail = lz(() => import('./pages/MemberReports').then((m) => ({ default: m.MemberReportDetail })));
const MemberReportForm = lz(() => import('./pages/MemberReports').then((m) => ({ default: m.MemberReportForm })));
import { CommsProvider, useComms } from './comms';
import { GroupCallProvider } from './groupcall';
const RoomChat = lz(() => import('./pages/Rooms').then((m) => ({ default: m.RoomChat })));
const Chat = lz(() => import('./pages/Comms').then((m) => ({ default: m.Chat })));
const Contacts = lz(() => import('./pages/Comms').then((m) => ({ default: m.Contacts })));
const SoundSettings = lz(() => import('./pages/Comms').then((m) => ({ default: m.SoundSettings })));
const SupportDetail = lz(() => import('./pages/Support').then((m) => ({ default: m.SupportDetail })));
const SupportForm = lz(() => import('./pages/Support').then((m) => ({ default: m.SupportForm })));
const AreaAdmin = lz(() => import('./pages/Qr').then((m) => ({ default: m.AreaAdmin })));
const MyArea = lz(() => import('./pages/Qr').then((m) => ({ default: m.MyArea })));
const ScanPage = lz(() => import('./pages/Qr').then((m) => ({ default: m.ScanPage })));
const HandoverExceptions = lz(() => import('./pages/Handover').then((m) => ({ default: m.HandoverExceptions })));
const HandoverPublic = lz(() => import('./pages/Handover').then((m) => ({ default: m.HandoverPublic })));
const PermitDetail = lz(() => import('./pages/PermitDetail'));
const PermitForm = lz(() => import('./pages/PermitForm'));
const DecisionDetail = lz(() => import('./pages/DecisionDetail'));
const HrHub = lz(() => import('./pages/HrHub'));
const OrgChart = lz(() => import('./pages/OrgChart'));
const Decisions = lz(() => import('./pages/Decisions'));
const Procedures = lz(() => import('./pages/Procedures'));
const ProcedureDetail = lz(() => import('./pages/ProcedureDetail'));
const AssignFlow = lz(() => import('./pages/AssignFlow'));
const AssignGuide = lz(() => import('./pages/AssignGuide'));

function Layout() {
  const { me } = useAuth();
  const loc = useLocation();
  const [unread, setUnread] = useState(0);
  const [switcher, setSwitcher] = useState(false);
  useEffect(() => {
    let alive = true;
    const tick = () => (me?.company_id ? get('/notifications?unread=true&limit=1').then((r) => alive && setUnread(r.unread)).catch(() => {}) : Promise.resolve());
    tick();
    // v14: không gọi lại mỗi lần chuyển trang; 45 giây/lần khi app đang mở, tạm dừng khi chạy nền
    const t = setInterval(() => { if (!document.hidden) tick(); }, 45000);
    const onVis = () => { if (!document.hidden) tick(); };
    document.addEventListener('visibilitychange', onVis);
    return () => { alive = false; clearInterval(t); document.removeEventListener('visibilitychange', onVis); };
  }, [me?.company_id]); // eslint-disable-line react-hooks/exhaustive-deps
  // Chuyển trang: chỉ cập nhật số thông báo nếu lần trước đã quá 15 giây (vào trang Thông báo thì cập nhật ngay)
  const lastNotif = React.useRef(0);
  useEffect(() => {
    if (!me?.company_id) return;
    if (loc.pathname !== '/notifications' && Date.now() - lastNotif.current < 15000) return;
    lastNotif.current = Date.now();
    get('/notifications?unread=true&limit=1').then((r) => setUnread(r.unread)).catch(() => {});
  }, [loc.pathname]); // eslint-disable-line react-hooks/exhaustive-deps
  // v8: tab Giao việc theo quyền hạn (Ban điều hành, quản lý phòng ban, trưởng nhóm/tổ trưởng)
  const canAssign = canAssignAny(me) || ['owner', 'admin', 'manager', 'hr'].includes(me?.role || '');
  const nav: [string, string, string][] = me?.company_id ? [
    ['/', 'home', 'Trang chủ'], ['/work', 'tasks', 'Công việc'], canAssign ? ['/assign', 'assign', 'Giao việc'] : ['/groups', 'users', 'Nhóm'], ['/hr', 'hr', 'Nhân sự'], ['/me', 'me', 'Cá nhân'],
  ] : [['/', 'home', 'Trang chủ'], ['/profile', 'record', 'Hồ sơ'], ['/upgrade', 'company', 'Doanh nghiệp'], ['/me', 'me', 'Tài khoản']];
  return (
    <CommsWrap on={!!me?.company_id}>
    <div className="app">
      <header className="topbar">
        <button className="brand-row company-switch" onClick={() => setSwitcher(true)} aria-label="Đổi doanh nghiệp / công ty">
          <img src="/logo-mark.png" alt="" />
          <div style={{ minWidth: 0, textAlign: 'left' }}>
            <div className="brand">{me?.company_name ? (me.company_short_name && me.company_short_name !== me.company_name ? <><span className="co-pre">Cty …</span>{me.company_short_name}</> : me.company_name) : 'Việc Đến'} <Icon name="down" size={14} className="caret" />{(me?.memberships?.length || 0) > 1 && <span className="co-count">{me!.memberships.length}</span>}</div>
            <div className="sub">{me?.name}{me?.role ? ` · ${ROLE[me.role]}` : ''}</div>
          </div>
        </button>
        <Link to="/me" aria-label="Hồ sơ của tôi"><Avatar userId={me?.user_id} name={me?.name} has={!!me?.has_avatar} size="sm" /></Link>
        {me?.company_id && <ChatBadge />}
        {me?.company_id && <Link to="/notifications" className="bell" aria-label={`Thông báo, ${unread} chưa đọc`}><Icon name="bell" size={21} />{unread > 0 && <span className="dot">{unread > 99 ? '99+' : unread}</span>}</Link>}
      </header>
      <AppStatus />
      <CompanySwitcher open={switcher} onClose={() => setSwitcher(false)} />
      <main><Suspense fallback={<Loading />}><Outlet /></Suspense></main>
      {me?.company_id && <ContactReturnPrompt />}
      <nav className="bottom-nav" aria-label="Điều hướng chính">
        {/* v15: màn hình rộng (máy tính, máy tính bảng ngang) và điện thoại xoay ngang: thanh điều hướng chuyển sang cạnh trái */}
        <div className="nav-brand" aria-hidden><img src="/logo-mark.png" alt="" /><span>Việc Đến</span></div>
        <div className="inner" style={{ ['--nav-n' as any]: nav.length }}>
          {nav.map(([to, ic, l]) => (
            <NavLink key={to} to={to} end={to === '/'} className={({ isActive }) => (isActive ? 'active' : '')}>
              <span className="ic" aria-hidden><Icon name={ic} size={21} /></span><span className="lbl">{l}</span>
            </NavLink>
          ))}
          {me?.company_id && <>
            <NavLink to="/contacts" className={({ isActive }) => `nav-extra ${isActive ? 'active' : ''}`}><span className="ic" aria-hidden><Icon name="phone" size={21} /></span><span className="lbl">Liên lạc</span></NavLink>
            <NavLink to="/notifications" className={({ isActive }) => `nav-extra ${isActive ? 'active' : ''}`}><span className="ic" aria-hidden><Icon name="bell" size={21} /></span><span className="lbl">Thông báo{unread > 0 ? ` (${unread > 99 ? '99+' : unread})` : ''}</span></NavLink>
          </>}
        </div>
      </nav>
    </div>
    </CommsWrap>
  );
}

// v14: tách mã theo trang — app mở nhanh hơn (chỉ tải trang đang xem)
export default function App() {
  return <Suspense fallback={<Loading />}><AppRoutes /></Suspense>;
}

function AppRoutes() {
  const { me, loading, bootError, reload } = useAuth();
  if (loading && bootError) return (
    <div className="login" style={{ textAlign: 'center' }}>
      <img src="/logo.png" alt="Việc Đến" style={{ width: 160, margin: '24px auto 12px', display: 'block' }} />
      <p><b>Đang kết nối lại máy chủ…</b></p>
      <p className="small muted">{bootError}. Bạn vẫn đang đăng nhập — app tự thử lại khi có mạng (có thể máy chủ đang cập nhật phiên bản mới).</p>
      <button className="btn primary" onClick={() => reload()}>Thử lại ngay</button>
    </div>
  );
  if (loading) return <Loading />;
  // Trang xác nhận bàn giao cho người nhận bên ngoài: không cần đăng nhập
  if (!me) return <Routes><Route path="/h/:token" element={<HandoverPublic />} /><Route path="*" element={<Login />} /></Routes>;
  if (!me.company_id) {
    return (
      <Routes>
        <Route element={<Layout />}>
          <Route index element={<NoCompanyHome />} />
          <Route path="profile" element={<ProfilePage />} />
          <Route path="upgrade" element={<Upgrade />} />
          <Route path="platform" element={<Platform />} />
          <Route path="me" element={<Profile />} />
          <Route path="privacy" element={<Privacy />} />
          <Route path="admin/security" element={<SecurityCenter />} />
          <Route path="*" element={<Navigate to="/" />} />
        </Route>
      </Routes>
    );
  }
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route index element={<Home />} />
        <Route path="work" element={<Work />} />
        <Route path="tasks" element={<Work />} />
        <Route path="tasks/new" element={<TaskForm />} />
        <Route path="tasks/:id" element={<TaskDetail />} />
        <Route path="work-records/new" element={<WorkRecordForm />} />
        <Route path="work-records/:id" element={<WorkRecordDetail />} />
        <Route path="overtime/new" element={<Navigate to="/attendance/new" replace />} />
        <Route path="overtime/:id" element={<OvertimeDetail />} />
        <Route path="reports" element={<Reports />} />
        <Route path="reports/new" element={<ReportForm />} />
        <Route path="reports/:id" element={<ReportDetail />} />
        <Route path="quick/new" element={<QuickClaimForm />} />
        <Route path="q" element={<QuickClaimForm />} />
        <Route path="quick/:id" element={<QuickClaimDetail />} />
        <Route path="leaves/new" element={<LeaveForm />} />
        <Route path="leaves/:id" element={<LeaveDetail />} />
        <Route path="team" element={<TeamWeek />} />
        <Route path="assign" element={<Assign />} />
        <Route path="templates" element={<Templates />} />
        <Route path="attendance/new" element={<AttendanceForm />} />
        <Route path="member-reports/new" element={<MemberReportForm />} />
        <Route path="member-reports/:id" element={<MemberReportDetail />} />
        <Route path="contacts" element={<Contacts />} />
        <Route path="messages/:memberId" element={<Chat />} />
        <Route path="rooms/:id" element={<RoomChat />} />
        <Route path="settings/sound" element={<SoundSettings />} />
        <Route path="support/new" element={<SupportForm />} />
        <Route path="support/:id" element={<SupportDetail />} />
        <Route path="scan" element={<ScanPage />} />
        <Route path="qr/a/:token" element={<ScanPage />} />
        <Route path="my-area" element={<MyArea />} />
        <Route path="admin/areas" element={<AreaAdmin />} />
        <Route path="handover-exceptions" element={<HandoverExceptions />} />
        <Route path="h/:token" element={<HandoverPublic />} />
        <Route path="permits/new" element={<PermitForm />} />
        <Route path="permits/:id" element={<PermitDetail />} />
        <Route path="decisions/:id" element={<DecisionDetail />} />
        <Route path="hr" element={<HrHub />} />
        <Route path="hr/org" element={<OrgChart />} />
        <Route path="hr/decisions" element={<Decisions />} />
        <Route path="hr/roles" element={<JobRoles />} />
        <Route path="hr/privacy-requests" element={<PrivacyRequests />} />
        <Route path="admin/security" element={<SecurityCenter />} />
        <Route path="privacy" element={<Privacy />} />
        <Route path="board" element={<BoardDash />} />
        <Route path="scope" element={<ScopeDash />} />
        <Route path="team-live" element={<TeamLive />} />
        <Route path="my-time" element={<MyTime />} />
        <Route path="chains" element={<ChainList />} />
        <Route path="chains/:id" element={<ChainDetail />} />
        <Route path="handovers" element={<HandoverList />} />
        <Route path="feedback" element={<FeedbackInbox />} />
        <Route path="conduct" element={<ConductList />} />
        <Route path="conduct/new" element={<ConductForm />} />
        <Route path="conduct/:id" element={<ConductDetail />} />
        <Route path="hr/procedures" element={<Procedures />} />
        <Route path="hr/procedures/:id" element={<ProcedureDetail />} />
        <Route path="hr/flow" element={<AssignFlow />} />
        <Route path="hr/guide" element={<AssignGuide />} />
        <Route path="tech" element={<TechBoard />} />
        <Route path="groups" element={<Groups />} />
        <Route path="groups/:id" element={<GroupDetail />} />
        <Route path="performance" element={<Performance />} />
        <Route path="me" element={<Profile />} />
        <Route path="profile" element={<ProfilePage />} />
        <Route path="people/:userId" element={<PersonProfile />} />
        <Route path="upgrade" element={<Upgrade />} />
        <Route path="platform" element={<Platform />} />
        <Route path="notifications" element={<Notifications />} />
        <Route path="escalations" element={<Escalations />} />
        <Route path="admin/members" element={<AdminMembers />} />
        <Route path="admin/settings" element={<AdminSettings />} />
        <Route path="*" element={<Navigate to="/" />} />
      </Route>
    </Routes>
  );
}

/** Lối tắt Liên lạc (gọi/nhắn trong app) kèm số tin nhắn chưa đọc. */
function ChatBadge() {
  const { unread: u1, roomUnread } = useComms();
  const unread = u1 + roomUnread;
  return (
    <Link to="/contacts" className="bell" aria-label={`Liên lạc${unread ? `, ${unread} tin nhắn chưa đọc` : ''}`}>
      <Icon name="phone" size={20} />{unread > 0 && <span className="dot">{unread > 99 ? '99+' : unread}</span>}
    </Link>
  );
}

function CommsWrap({ on, children }: { on: boolean; children: React.ReactNode }) {
  return on ? <CommsProvider><GroupCallProvider>{children}</GroupCallProvider></CommsProvider> : <>{children}</>;
}
