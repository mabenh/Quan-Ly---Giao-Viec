import React, { useEffect, useState } from 'react';
import { Link, NavLink, Navigate, Outlet, Route, Routes, useLocation } from 'react-router-dom';
import { canAssignAny, useAuth } from './auth';
import { get } from './api';
import { Loading } from './ui';
import { ROLE } from './labels';
import Login from './pages/Login';
import Home from './pages/Home';
import Work from './pages/Work';
import TaskDetail from './pages/TaskDetail';
import TaskForm from './pages/TaskForm';
import WorkRecordForm from './pages/WorkRecordForm';
import WorkRecordDetail from './pages/WorkRecordDetail';
import OvertimeDetail from './pages/OvertimeDetail';
import ReportForm from './pages/ReportForm';
import ReportDetail from './pages/ReportDetail';
import Reports from './pages/Reports';
import JobRoles from './pages/JobRoles';
import Privacy from './pages/Privacy';
import OvertimeException from './pages/OvertimeException';
import { BoardDash, FeedbackInbox, MyTime, ScopeDash, TeamLive } from './pages/Dashboards';
import { ChainDetail, ChainList, HandoverList } from './pages/Chains';
import { ConductDetail, ConductForm, ConductList } from './pages/Conduct';
import { PrivacyRequests, SecurityCenter } from './pages/PrivacyAdmin';
import Groups from './pages/Groups';
import GroupDetail from './pages/GroupDetail';
import Performance from './pages/Performance';
import Profile from './pages/Profile';
import Notifications from './pages/Notifications';
import Escalations from './pages/Escalations';
import AdminMembers from './pages/AdminMembers';
import AdminSettings from './pages/AdminSettings';
import TechBoard from './pages/TechBoard';
import ProfilePage from './pages/ProfilePage';
import PersonProfile from './pages/PersonProfile';
import Upgrade from './pages/Upgrade';
import Platform from './pages/Platform';
import NoCompanyHome from './pages/NoCompanyHome';
import QuickClaimForm from './pages/QuickClaimForm';
import QuickClaimDetail from './pages/QuickClaimDetail';
import LeaveForm from './pages/LeaveForm';
import LeaveDetail from './pages/LeaveDetail';
import TeamWeek from './pages/TeamWeek';
import ContactReturnPrompt from './pages/ContactReturnPrompt';
import { Avatar } from './ui';
import { Icon } from './icons';
import Assign from './pages/Assign';
import Templates from './pages/Templates';
import { AttendanceForm } from './pages/Attendance';
import { MemberReportDetail, MemberReportForm } from './pages/MemberReports';
import { CommsProvider, useComms } from './comms';
import { Chat, Contacts, SoundSettings } from './pages/Comms';
import { SupportDetail, SupportForm } from './pages/Support';
import { AreaAdmin, MyArea, ScanPage } from './pages/Qr';
import { HandoverExceptions, HandoverPublic } from './pages/Handover';
import PermitDetail from './pages/PermitDetail';
import PermitForm from './pages/PermitForm';
import DecisionDetail from './pages/DecisionDetail';
import HrHub from './pages/HrHub';
import OrgChart from './pages/OrgChart';
import Decisions from './pages/Decisions';
import Procedures from './pages/Procedures';
import ProcedureDetail from './pages/ProcedureDetail';
import AssignFlow from './pages/AssignFlow';
import AssignGuide from './pages/AssignGuide';

function Layout() {
  const { me } = useAuth();
  const loc = useLocation();
  const [unread, setUnread] = useState(0);
  useEffect(() => {
    let alive = true;
    const tick = () => (me?.company_id ? get('/notifications?unread=true&limit=1').then((r) => alive && setUnread(r.unread)).catch(() => {}) : Promise.resolve());
    tick();
    const t = setInterval(tick, 30000);
    return () => { alive = false; clearInterval(t); };
  }, [loc.pathname]);
  // v8: tab Giao việc theo quyền hạn (Ban điều hành, quản lý phòng ban, trưởng nhóm/tổ trưởng)
  const canAssign = canAssignAny(me) || ['owner', 'admin', 'manager', 'hr'].includes(me?.role || '');
  const nav: [string, string, string][] = me?.company_id ? [
    ['/', 'home', 'Trang chủ'], ['/work', 'tasks', 'Công việc'], canAssign ? ['/assign', 'assign', 'Giao việc'] : ['/groups', 'users', 'Nhóm'], ['/hr', 'hr', 'Nhân sự'], ['/me', 'me', 'Cá nhân'],
  ] : [['/', 'home', 'Trang chủ'], ['/profile', 'record', 'Hồ sơ'], ['/upgrade', 'company', 'Doanh nghiệp'], ['/me', 'me', 'Tài khoản']];
  return (
    <CommsWrap on={!!me?.company_id}>
    <div className="app">
      <header className="topbar">
        <div className="brand-row">
          <img src="/logo-mark.png" alt="Việc Đến" />
          <div style={{ minWidth: 0 }}>
            <div className="brand">{me?.company_name || 'Việc Đến'}</div>
            <div className="sub">{me?.name}{me?.role ? ` · ${ROLE[me.role]}` : ''}</div>
          </div>
        </div>
        <Link to="/me" aria-label="Hồ sơ của tôi"><Avatar userId={me?.user_id} name={me?.name} has={!!me?.has_avatar} size="sm" /></Link>
        {me?.company_id && <ChatBadge />}
        {me?.company_id && <Link to="/notifications" className="bell" aria-label={`Thông báo, ${unread} chưa đọc`}><Icon name="bell" size={21} />{unread > 0 && <span className="dot">{unread > 99 ? '99+' : unread}</span>}</Link>}
      </header>
      <main><Outlet /></main>
      {me?.company_id && <ContactReturnPrompt />}
      <nav className="bottom-nav" aria-label="Điều hướng chính">
        <div className="inner" style={{ gridTemplateColumns: `repeat(${nav.length}, 1fr)` }}>
          {nav.map(([to, ic, l]) => (
            <NavLink key={to} to={to} end={to === '/'} className={({ isActive }) => (isActive ? 'active' : '')}>
              <span className="ic" aria-hidden><Icon name={ic} size={21} /></span>{l}
            </NavLink>
          ))}
        </div>
      </nav>
    </div>
    </CommsWrap>
  );
}

export default function App() {
  const { me, loading } = useAuth();
  if (loading) return <Loading />;
  // Trang xác nhận bàn giao cho người nhận bên ngoài: không cần đăng nhập
  if (!me) return <Routes><Route path="/h/:token" element={<HandoverPublic />} /><Route path="*" element={<Login />} /></Routes>;
  if (!me.company_id) {
    return (
      <Routes>
        <Route element={<Layout />}>
          <Route index element={<NoCompanyHome />} />
          <Route path="profile" element={<ProfilePage />} />
          <Route path="upgrade" element={<Upgrade />} />
          <Route path="platform" element={<Platform />} />
          <Route path="me" element={<Profile />} />
          <Route path="privacy" element={<Privacy />} />
          <Route path="admin/security" element={<SecurityCenter />} />
          <Route path="*" element={<Navigate to="/" />} />
        </Route>
      </Routes>
    );
  }
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route index element={<Home />} />
        <Route path="work" element={<Work />} />
        <Route path="tasks" element={<Work />} />
        <Route path="tasks/new" element={<TaskForm />} />
        <Route path="tasks/:id" element={<TaskDetail />} />
        <Route path="work-records/new" element={<WorkRecordForm />} />
        <Route path="work-records/:id" element={<WorkRecordDetail />} />
        <Route path="overtime/new" element={<Navigate to="/attendance/new" replace />} />
        <Route path="overtime/:id" element={<OvertimeDetail />} />
        <Route path="reports" element={<Reports />} />
        <Route path="reports/new" element={<ReportForm />} />
        <Route path="reports/:id" element={<ReportDetail />} />
        <Route path="quick/new" element={<QuickClaimForm />} />
        <Route path="q" element={<QuickClaimForm />} />
        <Route path="quick/:id" element={<QuickClaimDetail />} />
        <Route path="leaves/new" element={<LeaveForm />} />
        <Route path="leaves/:id" element={<LeaveDetail />} />
        <Route path="team" element={<TeamWeek />} />
        <Route path="assign" element={<Assign />} />
        <Route path="templates" element={<Templates />} />
        <Route path="attendance/new" element={<AttendanceForm />} />
        <Route path="member-reports/new" element={<MemberReportForm />} />
        <Route path="member-reports/:id" element={<MemberReportDetail />} />
        <Route path="contacts" element={<Contacts />} />
        <Route path="messages/:memberId" element={<Chat />} />
        <Route path="settings/sound" element={<SoundSettings />} />
        <Route path="support/new" element={<SupportForm />} />
        <Route path="support/:id" element={<SupportDetail />} />
        <Route path="scan" element={<ScanPage />} />
        <Route path="qr/a/:token" element={<ScanPage />} />
        <Route path="my-area" element={<MyArea />} />
        <Route path="admin/areas" element={<AreaAdmin />} />
        <Route path="handover-exceptions" element={<HandoverExceptions />} />
        <Route path="h/:token" element={<HandoverPublic />} />
        <Route path="permits/new" element={<PermitForm />} />
        <Route path="permits/:id" element={<PermitDetail />} />
        <Route path="decisions/:id" element={<DecisionDetail />} />
        <Route path="hr" element={<HrHub />} />
        <Route path="hr/org" element={<OrgChart />} />
        <Route path="hr/decisions" element={<Decisions />} />
        <Route path="hr/roles" element={<JobRoles />} />
        <Route path="hr/privacy-requests" element={<PrivacyRequests />} />
        <Route path="admin/security" element={<SecurityCenter />} />
        <Route path="privacy" element={<Privacy />} />
        <Route path="board" element={<BoardDash />} />
        <Route path="scope" element={<ScopeDash />} />
        <Route path="team-live" element={<TeamLive />} />
        <Route path="my-time" element={<MyTime />} />
        <Route path="chains" element={<ChainList />} />
        <Route path="chains/:id" element={<ChainDetail />} />
        <Route path="handovers" element={<HandoverList />} />
        <Route path="feedback" element={<FeedbackInbox />} />
        <Route path="conduct" element={<ConductList />} />
        <Route path="conduct/new" element={<ConductForm />} />
        <Route path="conduct/:id" element={<ConductDetail />} />
        <Route path="hr/procedures" element={<Procedures />} />
        <Route path="hr/procedures/:id" element={<ProcedureDetail />} />
        <Route path="hr/flow" element={<AssignFlow />} />
        <Route path="hr/guide" element={<AssignGuide />} />
        <Route path="tech" element={<TechBoard />} />
        <Route path="groups" element={<Groups />} />
        <Route path="groups/:id" element={<GroupDetail />} />
        <Route path="performance" element={<Performance />} />
        <Route path="me" element={<Profile />} />
        <Route path="profile" element={<ProfilePage />} />
        <Route path="people/:userId" element={<PersonProfile />} />
        <Route path="upgrade" element={<Upgrade />} />
        <Route path="platform" element={<Platform />} />
        <Route path="notifications" element={<Notifications />} />
        <Route path="escalations" element={<Escalations />} />
        <Route path="admin/members" element={<AdminMembers />} />
        <Route path="admin/settings" element={<AdminSettings />} />
        <Route path="*" element={<Navigate to="/" />} />
      </Route>
    </Routes>
  );
}

/** Lối tắt Liên lạc (gọi/nhắn trong app) kèm số tin nhắn chưa đọc. */
function ChatBadge() {
  const { unread } = useComms();
  return (
    <Link to="/contacts" className="bell" aria-label={`Liên lạc${unread ? `, ${unread} tin nhắn chưa đọc` : ''}`}>
      <Icon name="phone" size={20} />{unread > 0 && <span className="dot">{unread > 99 ? '99+' : unread}</span>}
    </Link>
  );
}

function CommsWrap({ on, children }: { on: boolean; children: React.ReactNode }) {
  return on ? <CommsProvider>{children}</CommsProvider> : <>{children}</>;
}
