import { Icon } from './icons';

/** Dấu hiệu màu thay cho chữ: ghim = gấp, đỏ = quá hạn, vàng = chờ nghiệm thu, xanh lá = hoàn thành,
 *  xanh lam = đang thực hiện, tím = đột xuất, đen = hủy. Xám = chưa bắt đầu / chờ giai đoạn / chờ duyệt. */
export const MARK: Record<string, { label: string; cls: string }> = {
  pin: { label: 'Việc gấp (ghim)', cls: 'pin' },
  overdue: { label: 'Quá hạn', cls: 'red' },
  pending_review: { label: 'Đang chờ nghiệm thu', cls: 'yellow' },
  completed: { label: 'Hoàn thành', cls: 'green' },
  in_progress: { label: 'Đang thực hiện', cls: 'blue' },
  unexpected: { label: 'Đột xuất', cls: 'purple' },
  cancelled: { label: 'Đã hủy', cls: 'black' },
  revision_requested: { label: 'Yêu cầu chỉnh sửa', cls: 'orange' },
  not_started: { label: 'Chưa bắt đầu', cls: 'gray' },
  waiting: { label: 'Chờ giai đoạn trước', cls: 'hollow' },
  pending_approval: { label: 'Chờ cấp trên duyệt giao việc', cls: 'hollow amber' },
};

export function taskMarks(t: any): string[] {
  const m: string[] = [];
  if (t.pinned) m.push('pin');
  if (t.is_overdue) m.push('overdue');
  if (!(t.is_overdue && ['not_started', 'in_progress'].includes(t.status))) m.push(MARK[t.status] ? t.status : 'not_started');
  if (t.is_unexpected) m.push('unexpected');
  return m;
}

export function Dot({ k, size = 12 }: { k: string; size?: number }) {
  const d = MARK[k] || MARK.not_started;
  if (k === 'pin') return <span className="mk pin" title={d.label} aria-label={d.label}><Icon name="pin" size={size + 2} /></span>;
  return <span className={`mk dot ${d.cls}`} style={{ width: size, height: size }} title={d.label} aria-label={d.label} role="img" />;
}

export function TaskMarks({ t, size }: { t: any; size?: number }) {
  return <span className="mks">{taskMarks(t).map((k) => <Dot key={k} k={k} size={size} />)}</span>;
}

/** Hàng chọn lọc thu nhỏ: chỉ dấu màu, chạm để bật/tắt; giữ chú giải ngắn bên dưới. */
export const FILTER_MARKS = ['pin', 'overdue', 'pending_review', 'in_progress', 'completed', 'unexpected', 'cancelled'] as const;
export function MarkFilter({ active, onToggle, showLegend = true }: { active: string[]; onToggle: (k: string) => void; showLegend?: boolean }) {
  return (
    <div className="mk-filter">
      <div className="mk-row" role="group" aria-label="Lọc theo dấu hiệu">
        {FILTER_MARKS.map((k) => (
          <button key={k} type="button" className={`mk-btn ${active.includes(k) ? 'on' : ''}`} aria-pressed={active.includes(k)} title={MARK[k].label} aria-label={MARK[k].label} onClick={() => onToggle(k)}>
            <Dot k={k} size={14} />
          </button>
        ))}
      </div>
      {showLegend && <div className="mk-legend">{FILTER_MARKS.map((k) => <span key={k}><Dot k={k} size={8} />{MARK[k].label.replace(' (ghim)', '').replace('Đang chờ ', 'Chờ ')}</span>)}</div>}
    </div>
  );
}
