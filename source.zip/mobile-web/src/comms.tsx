import { createContext, ReactNode, useCallback, useContext, useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { api, get, post, put } from './api';
import { useAuth } from './auth';
import { Avatar } from './ui';
import { Icon } from './icons';

/**
 * Liên lạc trong app (v9): gọi thoại WebRTC (không qua nhà mạng, không hiện số), báo hiệu qua HTTP polling.
 * - Giới hạn 3 phút/cuộc (máy chủ quyết định, app đếm ngược và tự kết thúc).
 * - Ghi âm trộn cả hai phía (MediaRecorder), lưu kèm nhật ký để làm tài liệu khai việc; bên kia được báo "đang ghi âm".
 * - Chuông/rung theo Cài đặt âm thanh & thông báo (giờ yên lặng, tắt tiếng cuộc gọi).
 */
type Phase = 'idle' | 'outgoing' | 'incoming' | 'active' | 'ended';
interface CallState { id: string; other_id: string; other_name: string; other_user_id?: string; limit: number; answered_at?: string | null; direction: 'in' | 'out'; ice: any[] }
interface Ctx { startCall: (memberId: string, name: string) => void; unread: number; roomUnread: number; roomCalls: any[]; prefs: any; setPrefs: (p: any) => Promise<void>; busy: boolean }
const CallCtx = createContext<Ctx>({ startCall: () => {}, unread: 0, roomUnread: 0, roomCalls: [], prefs: null, setPrefs: async () => {}, busy: false });
export const useComms = () => useContext(CallCtx);

const inQuiet = (p: any) => {
  if (!p?.quietHours?.enabled) return false;
  const now = new Date(); const m = now.getHours() * 60 + now.getMinutes();
  const [sh, sm] = p.quietHours.start.split(':').map(Number); const [eh, em] = p.quietHours.end.split(':').map(Number);
  const s = sh * 60 + sm, e = eh * 60 + em;
  return s <= e ? m >= s && m < e : m >= s || m < e;
};
export const fmtSec = (s: number) => `${Math.floor(s / 60)}:${String(Math.max(0, s % 60)).padStart(2, '0')}`;

/** Chuông tổng hợp bằng WebAudio (không cần tệp âm thanh). */
function makeRinger() {
  let ctx: AudioContext | null = null; let timer: any = null;
  const beep = (vol: number, f1: number, f2: number, dur = 0.35) => {
    if (!ctx) return;
    const o = ctx.createOscillator(); const o2 = ctx.createOscillator(); const g = ctx.createGain();
    o.frequency.value = f1; o2.frequency.value = f2; g.gain.value = vol * 0.25;
    o.connect(g); o2.connect(g); g.connect(ctx.destination); o.start(); o2.start();
    o.stop(ctx.currentTime + dur); o2.stop(ctx.currentTime + dur);
  };
  return {
    start(vol: number, vibrate: boolean) {
      try { ctx = ctx || new (window.AudioContext || (window as any).webkitAudioContext)(); } catch { ctx = null; }
      const tick = () => { beep(vol, 440, 480); setTimeout(() => beep(vol, 440, 480), 450); if (vibrate && navigator.vibrate) navigator.vibrate([300, 150, 300]); };
      tick(); timer = setInterval(tick, 2500);
    },
    stop() { clearInterval(timer); timer = null; if (navigator.vibrate) navigator.vibrate(0); },
    ping(vol: number) { try { ctx = ctx || new AudioContext(); beep(vol, 880, 880, 0.15); } catch { /* */ } },
  };
}

export function CommsProvider({ children }: { children: ReactNode }) {
  const { me } = useAuth();
  const nav = useNavigate();
  const [phase, setPhase] = useState<Phase>('idle');
  const [call, setCall] = useState<CallState | null>(null);
  const [unread, setUnread] = useState(0);
  const [roomUnread, setRoomUnread] = useState(0);
  const [roomCalls, setRoomCalls] = useState<any[]>([]);
  const lastRoomCalls = useRef<string>('');
  const [prefs, setPrefsState] = useState<any>(null);
  const [remaining, setRemaining] = useState(180);
  const [muted, setMuted] = useState(false);
  const [recording, setRecording] = useState(false);
  const [otherRecording, setOtherRecording] = useState(false);
  const [notice, setNotice] = useState<string | null>(null);
  const [summary, setSummary] = useState<any>(null);
  const since = useRef('');
  const pc = useRef<RTCPeerConnection | null>(null);
  const local = useRef<MediaStream | null>(null);
  const remote = useRef<MediaStream | null>(null);
  const audioEl = useRef<HTMLAudioElement | null>(null);
  const pendingOffer = useRef<Record<string, any>>({});
  const pendingIce = useRef<any[]>([]);
  const rec = useRef<{ r: MediaRecorder; chunks: Blob[]; ctx: AudioContext } | null>(null);
  const ringer = useRef(makeRinger());
  const callRef = useRef<CallState | null>(null); callRef.current = call;
  const phaseRef = useRef<Phase>('idle'); phaseRef.current = phase;
  const prefsRef = useRef<any>(null); prefsRef.current = prefs;
  const lastUnread = useRef(-1); // -1: chưa có lượt đầu — không phát âm báo ngay khi mở app

  useEffect(() => { if (me?.company_id) get('/me/prefs').then(setPrefsState).catch(() => {}); }, [me?.company_id]);
  const setPrefs = async (p: any) => setPrefsState(await put('/me/prefs', p));

  const cleanup = useCallback(() => {
    ringer.current.stop();
    try { pc.current?.close(); } catch { /* */ }
    pc.current = null;
    local.current?.getTracks().forEach((t) => t.stop()); local.current = null; remote.current = null;
    pendingIce.current = []; setMuted(false); setOtherRecording(false);
  }, []);

  const stopRecording = useCallback(async (callId: string) => {
    const r = rec.current; if (!r) return null;
    rec.current = null; setRecording(false);
    await new Promise<void>((res) => { r.r.onstop = () => res(); try { r.r.stop(); } catch { res(); } });
    try { r.ctx.close(); } catch { /* */ }
    const blob = new Blob(r.chunks, { type: 'audio/webm' });
    if (blob.size < 200) return null;
    const fd = new FormData(); fd.append('file', blob, 'ghi-am.webm');
    try { await api('POST', `/calls/${callId}/recording`, fd); return 'saved'; } catch (e: any) { return e.code === 'CONSENT_REQUIRED' ? 'consent' : 'error'; }
  }, []);

  const finishLocal = useCallback(async (reason: string, notifyServer: boolean) => {
    const c = callRef.current; if (!c) return;
    const recResult = await stopRecording(c.id);
    if (notifyServer) await post(`/calls/${c.id}/end`, { reason }).catch(() => {});
    cleanup();
    const detail = await get(`/calls/${c.id}`).catch(() => null);
    setSummary({ ...(detail || {}), recResult, reason });
    setPhase('ended');
  }, [cleanup, stopRecording]);

  const sendIce = (callId: string) => (e: RTCPeerConnectionIceEvent) => { if (e.candidate) post(`/calls/${callId}/signal`, { type: 'ice', payload: e.candidate.toJSON() }).catch(() => {}); };

  const makePc = async (c: CallState) => {
    const p = new RTCPeerConnection({ iceServers: c.ice });
    p.onicecandidate = sendIce(c.id);
    p.ontrack = (e) => { remote.current = e.streams[0]; if (audioEl.current) { audioEl.current.srcObject = e.streams[0]; audioEl.current.play().catch(() => {}); } };
    p.onconnectionstatechange = () => { if (p.connectionState === 'failed') { setNotice('Không kết nối được âm thanh (mạng chặn). Quản trị có thể cấu hình máy chủ TURN.'); } };
    const s = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true } });
    local.current = s; s.getTracks().forEach((t) => p.addTrack(t, s));
    pc.current = p;
    return p;
  };
  const flushIce = async () => { const p = pc.current; if (!p?.remoteDescription) return; for (const c of pendingIce.current.splice(0)) await p.addIceCandidate(c).catch(() => {}); };

  const startCall = useCallback(async (memberId: string, name: string) => {
    if (phaseRef.current !== 'idle' && phaseRef.current !== 'ended') return;
    setSummary(null); setNotice(null);
    if (!navigator.mediaDevices?.getUserMedia) { alert('Thiết bị/trình duyệt không hỗ trợ gọi trong app (cần HTTPS và quyền micro).'); return; }
    try {
      const r = await post('/calls', { calleeId: memberId });
      const c: CallState = { id: r.id, other_id: memberId, other_name: name, other_user_id: r.other_user_id, limit: r.limit_seconds, direction: 'out', ice: r.ice_servers };
      setCall(c); setRemaining(c.limit); setPhase('outgoing');
      const p = await makePc(c);
      const offer = await p.createOffer(); await p.setLocalDescription(offer);
      await post(`/calls/${c.id}/signal`, { type: 'offer', payload: { type: offer.type, sdp: offer.sdp } });
    } catch (e: any) {
      cleanup(); setPhase('idle'); setCall(null);
      alert(e?.name === 'NotAllowedError' ? 'Cần cho phép dùng micro để gọi.' : e?.message || 'Không gọi được');
    }
  }, [cleanup]);

  const accept = async () => {
    const c = callRef.current; if (!c) return;
    ringer.current.stop();
    try {
      const r = await post(`/calls/${c.id}/answer`);
      const cc = { ...c, answered_at: r.answered_at, limit: r.limit_seconds, ice: r.ice_servers };
      setCall(cc); setRemaining(r.remaining_seconds);
      const p = await makePc(cc);
      let offer = pendingOffer.current[c.id];
      if (!offer) { const all = await get('/calls-poll?since=0'); offer = all.signals.find((s: any) => s.call_id === c.id && s.type === 'offer')?.payload;
        for (const s of all.signals.filter((x: any) => x.call_id === c.id && x.type === 'ice')) pendingIce.current.push(s.payload); }
      if (!offer) throw new Error('Không nhận được tín hiệu cuộc gọi, vui lòng gọi lại');
      await p.setRemoteDescription(offer); await flushIce();
      const ans = await p.createAnswer(); await p.setLocalDescription(ans);
      await post(`/calls/${c.id}/signal`, { type: 'answer', payload: { type: ans.type, sdp: ans.sdp } });
      setPhase('active');
    } catch (e: any) { setNotice(e?.name === 'NotAllowedError' ? 'Cần cho phép dùng micro.' : e?.message || 'Không nhận được cuộc gọi'); await finishLocal('error', true); }
  };
  const decline = async () => { const c = callRef.current; ringer.current.stop(); if (c) await post(`/calls/${c.id}/decline`).catch(() => {}); cleanup(); setPhase('idle'); setCall(null); };
  const hangup = () => finishLocal(phaseRef.current === 'outgoing' ? 'cancelled' : 'hangup', true);

  // Thăm dò: cuộc gọi đến, tín hiệu, tin nhắn chưa đọc
  useEffect(() => {
    if (!me?.company_id) return;
    let alive = true;
    const tick = async () => {
      try {
        // v11: tạm dừng khi app chạy nền (trừ lúc đang gọi); không thử lại tự động để tránh dồn yêu cầu khi mạng yếu
        if (document.hidden && phaseRef.current === 'idle') return;
        const r = await api<any>('GET', `/calls-poll${since.current ? `?since=${since.current}` : ''}`, undefined, { retries: 0 });
        if (!alive) return;
        since.current = r.since;
        if (lastUnread.current >= 0 && r.unread_messages > lastUnread.current && prefsRef.current?.messageSound && !prefsRef.current?.mute?.messages && !inQuiet(prefsRef.current)) ringer.current.ping((prefsRef.current?.ringVolume ?? 80) / 100);
        lastUnread.current = r.unread_messages; setUnread(r.unread_messages);
        setRoomUnread(r.unread_room_messages || 0);
        const rc = r.room_calls || []; const key = rc.map((x: any) => x.id + ':' + x.count).join(',');
        if (key !== lastRoomCalls.current) {
          // chuông ngắn khi có cuộc gọi nhóm mới
          if (rc.some((x: any) => !lastRoomCalls.current.includes(x.id)) && !prefsRef.current?.mute?.calls && !inQuiet(prefsRef.current)) ringer.current.ping((prefsRef.current?.ringVolume ?? 80) / 100);
          lastRoomCalls.current = key; setRoomCalls(rc);
        }
        if (r.incoming && (phaseRef.current === 'idle' || phaseRef.current === 'ended') && callRef.current?.id !== r.incoming.id) {
          const d = await get(`/calls/${r.incoming.id}`);
          setSummary(null); setNotice(null);
          setCall({ id: d.id, other_id: d.other_id, other_name: d.other_name, other_user_id: d.other_user_id, limit: d.limit_seconds, direction: 'in', ice: d.ice_servers });
          setRemaining(d.limit_seconds); setPhase('incoming');
          const p = prefsRef.current;
          if (p?.ringtone !== false && !p?.mute?.calls && !inQuiet(p)) ringer.current.start((p?.ringVolume ?? 80) / 100, p?.vibrate !== false);
        }
        for (const s of r.signals) {
          const c = callRef.current;
          if (s.type === 'offer') { pendingOffer.current[s.call_id] = s.payload; continue; }
          if (!c || s.call_id !== c.id) continue;
          if (s.type === 'answer' && pc.current && !pc.current.currentRemoteDescription) {
            await pc.current.setRemoteDescription(s.payload); await flushIce();
            const d = await get(`/calls/${c.id}`); setCall({ ...c, answered_at: d.answered_at }); setRemaining(d.remaining_seconds); setPhase('active');
          } else if (s.type === 'ice') {
            if (pc.current?.remoteDescription) await pc.current.addIceCandidate(s.payload).catch(() => {}); else pendingIce.current.push(s.payload);
          } else if (s.type === 'hangup') {
            const reason = s.payload?.reason;
            if (phaseRef.current === 'incoming') { cleanup(); setPhase('idle'); setCall(null); }
            else await finishLocal(reason === 'declined' ? 'declined' : reason === 'limit' ? 'limit' : 'remote', false);
          } else if (s.type === 'recording') { setOtherRecording(true); }
        }
      } catch { /* bỏ qua lượt lỗi mạng */ }
    };
    tick();
    const t = setInterval(tick, phaseRef.current === 'idle' ? 4000 : 1200);
    const onVis = () => { if (!document.hidden) tick(); };
    document.addEventListener('visibilitychange', onVis);
    return () => { alive = false; clearInterval(t); document.removeEventListener('visibilitychange', onVis); };
  }, [me?.company_id, phase, cleanup, finishLocal]);

  // Đếm ngược 3 phút; cảnh báo 30 giây cuối; hết giờ tự kết thúc
  useEffect(() => {
    if (phase !== 'active' || !call?.answered_at) return;
    const t = setInterval(() => {
      const left = call.limit - Math.floor((Date.now() - new Date(call.answered_at!).getTime()) / 1000);
      setRemaining(Math.max(0, left));
      if (left === 30) ringer.current.ping(0.6);
      if (left <= 0) { clearInterval(t); finishLocal('limit', true); }
    }, 500);
    return () => clearInterval(t);
  }, [phase, call?.answered_at, call?.limit, finishLocal]);

  const toggleMute = () => { const m = !muted; local.current?.getAudioTracks().forEach((t) => (t.enabled = !m)); setMuted(m); };
  const toggleRecord = async () => {
    const c = callRef.current; if (!c) return;
    if (rec.current) {
      if (recording) { try { rec.current.r.pause(); } catch { /* */ } setRecording(false); } else { try { rec.current.r.resume(); } catch { /* */ } setRecording(true); }
      return;
    }
    try {
      const ac = new AudioContext(); const dest = ac.createMediaStreamDestination();
      if (local.current) ac.createMediaStreamSource(local.current).connect(dest);
      if (remote.current) ac.createMediaStreamSource(remote.current).connect(dest);
      const mime = MediaRecorder.isTypeSupported('audio/webm;codecs=opus') ? 'audio/webm;codecs=opus' : 'audio/webm';
      const r = new MediaRecorder(dest.stream, { mimeType: mime }); const chunks: Blob[] = [];
      r.ondataavailable = (e) => e.data.size && chunks.push(e.data); r.start(1000);
      rec.current = { r, chunks, ctx: ac }; setRecording(true);
      post(`/calls/${c.id}/signal`, { type: 'recording', payload: { by: 'other' } }).catch(() => {});
    } catch { setNotice('Thiết bị không hỗ trợ ghi âm cuộc gọi'); }
  };

  const showOverlay = phase === 'outgoing' || phase === 'incoming' || phase === 'active' || (phase === 'ended' && summary);
  return (
    <CallCtx.Provider value={{ startCall, unread, roomUnread, roomCalls, prefs, setPrefs, busy: phase !== 'idle' && phase !== 'ended' }}>
      {children}
      <audio ref={audioEl} autoPlay playsInline />
      {showOverlay && call && (
        <div className="call-screen" role="dialog" aria-label="Cuộc gọi">
          <div className="call-top small">{phase === 'ended' ? 'Cuộc gọi đã kết thúc' : 'Cuộc gọi Việc Đến · không qua nhà mạng'}</div>
          <Avatar userId={call.other_user_id} name={call.other_name} has={false} size="lg" />
          <h2>{call.other_name}</h2>
          <div className="call-status">
            {phase === 'outgoing' && 'Đang gọi…'}
            {phase === 'incoming' && 'đang gọi cho bạn'}
            {phase === 'active' && <><span className={remaining <= 30 ? 'warn' : ''}>Còn {fmtSec(remaining)}</span><span className="small"> / tối đa {fmtSec(call.limit)}</span></>}
            {phase === 'ended' && summary && <>{summary.duration_seconds ? `Thời lượng ${fmtSec(summary.duration_seconds)}` : summary.status === 'declined' ? 'Người nhận từ chối' : summary.status === 'missed' ? 'Không trả lời' : 'Đã hủy'}{summary.end_reason === 'limit' ? ' · hết 3 phút' : ''}</>}
          </div>
          {(recording || otherRecording) && phase === 'active' && <div className="call-rec"><span className="live-dot" /> {recording ? 'Bạn đang ghi âm cuộc gọi' : 'Bên kia đang ghi âm cuộc gọi này'}</div>}
          {phase === 'active' && remaining <= 30 && <div className="small" style={{ color: '#fbbf24' }}>Sắp hết thời lượng — cuộc gọi tự kết thúc để không ảnh hưởng công việc.</div>}
          {notice && <div className="small" style={{ color: '#fca5a5' }}>{notice}</div>}
          <div className="call-actions">
            {phase === 'incoming' && <>
              <button className="call-btn red" onClick={decline} aria-label="Từ chối"><Icon name="phone" size={26} /></button>
              <button className="call-btn green" onClick={accept} aria-label="Nghe"><Icon name="phone" size={26} /></button>
            </>}
            {(phase === 'outgoing' || phase === 'active') && <>
              {phase === 'active' && <button className={`call-btn ${muted ? 'on' : ''}`} onClick={toggleMute} aria-label={muted ? 'Bật micro' : 'Tắt micro'}><Icon name="mic" size={24} /><span>{muted ? 'Bật mic' : 'Tắt mic'}</span></button>}
              <button className="call-btn red" onClick={hangup} aria-label="Kết thúc"><Icon name="phone" size={26} /><span>Kết thúc</span></button>
              {phase === 'active' && <button className={`call-btn ${recording ? 'rec' : ''}`} onClick={toggleRecord} aria-label="Ghi âm"><span className="dot" /><span>{recording ? 'Dừng ghi' : 'Ghi âm'}</span></button>}
            </>}
          </div>
          {phase === 'ended' && summary && (
            <div className="call-summary">
              {summary.recResult === 'saved' && <div className="small"><Icon name="check" size={16} />Đã lưu ghi âm vào nhật ký liên lạc (lưu 30 ngày; khai báo công việc sẽ giữ lại ghi âm làm tài liệu).</div>}
              {summary.recResult === 'consent' && <div className="small" style={{ color: '#fbbf24' }}>Chưa lưu ghi âm: cần đồng ý mục đích "Ghi âm cuộc gọi khai việc" trong Cá nhân → Quyền riêng tư.</div>}
              {summary.status === 'ended' && <button className="btn primary block" onClick={() => { setPhase('idle'); setCall(null); nav(`/work-records/new?callId=${summary.id}`); }}><Icon name="record" size={18} />Khai báo công việc từ cuộc gọi</button>}
              <button className="btn block" style={{ marginTop: 8 }} onClick={() => { setPhase('idle'); setCall(null); setSummary(null); }}>Đóng</button>
            </div>
          )}
        </div>
      )}
    </CallCtx.Provider>
  );
}

/** Nút liên lạc thay cho số điện thoại: gọi trong app, nhắn tin, Zalo (máy chủ chuyển hướng, không hiện số). */
export function ContactButtons({ memberId, name, zalo = true, size = 'sm', compact = false }: { memberId: string; name: string; zalo?: boolean; size?: 'sm' | ''; compact?: boolean }) {
  const { startCall } = useComms();
  const nav = useNavigate();
  const { me } = useAuth();
  if (!memberId || memberId === me?.member_id) return null;
  const openZalo = async () => {
    const w = window.open('about:blank', '_blank');
    try { const r = await post(`/contacts/${memberId}/zalo`); if (w) w.location.href = r.url; else window.location.href = r.url; } catch (e: any) { w?.close(); alert(e.message); }
  };
  // v16: dạng gọn — nút tròn chỉ có biểu tượng, đặt cuối dòng
  if (compact) return (
    <div className="contact-icons">
      <button className="round-btn" aria-label={`Gọi ${name}`} title="Gọi qua app" onClick={() => startCall(memberId, name)}><Icon name="phone" size={18} /></button>
      <button className="round-btn" aria-label={`Nhắn tin ${name}`} title="Nhắn tin" onClick={() => nav(`/messages/${memberId}`)}><Icon name="chat" size={18} /></button>
      {zalo && <button className="round-btn zalo" aria-label={`Zalo ${name}`} title="Zalo" onClick={openZalo}>Z</button>}
    </div>
  );
  return (
    <div className="chip-row" style={{ marginTop: 6 }}>
      <button className={`btn ${size}`} onClick={() => startCall(memberId, name)}><Icon name="phone" size={16} />Gọi qua app</button>
      <button className={`btn ${size}`} onClick={() => nav(`/messages/${memberId}`)}><Icon name="chat" size={16} />Nhắn tin</button>
      {zalo && <button className={`btn ${size}`} onClick={openZalo}>Zalo</button>}
    </div>
  );
}
