/* Kiểm thử tính năng v2 (Việc Đến): SĐT, gói doanh nghiệp, HR duyệt, hồ sơ, lịch, ghim, khai việc nhanh, nghỉ phép. */
process.env.DATABASE_URL = process.env.TEST_DATABASE_URL || 'postgresql://app:app@localhost:5432/teamapp_test';
process.env.DISABLE_SCHEDULER = 'true';
process.env.UPLOAD_DIR = '/tmp/teamapp-test-uploads';

import { INestApplication } from '@nestjs/common';
import { closePool, q, q1 } from '../src/db/db';
import { createApp } from '../src/main';
import { resetDb, seed } from '../src/db/seed';
import { runSchedulerOnce } from '../src/modules/scheduler.service';

let app: INestApplication;
let url = '';
const tok: Record<string, string> = {};
const ids: Record<string, string> = {};

async function call(who: string, method: string, path: string, body?: any) {
  const r = await fetch(url + path, {
    method, headers: { 'Content-Type': 'application/json', ...(tok[who] ? { Authorization: `Bearer ${tok[who]}` } : {}) },
    body: body ? JSON.stringify(body) : undefined,
  });
  return { status: r.status, body: (await r.json().catch(() => ({}))) as any };
}
async function ok(who: string, method: string, path: string, body?: any) {
  const r = await call(who, method, path, body);
  if (r.status >= 300) throw new Error(`${method} ${path} -> ${r.status} ${JSON.stringify(r.body)}`);
  return r.body;
}
const PH: Record<string, string> = { owner: '0901000001', admin: '0901000002', m1: '0901000003', m2: '0901000004', e1: '0901000007', e2: '0901000008', e3: '0901000009', hr: '0901000012' };

beforeAll(async () => {
  await resetDb();
  app = await createApp();
  await app.listen(0);
  url = `http://127.0.0.1:${(app.getHttpServer().address() as any).port}/api/v1`;
  await seed(url);
  for (const [k, p] of Object.entries(PH)) {
    tok[k] = (await ok('', 'POST', '/auth/login', { phone: p, password: 'Demo@123' })).access_token;
    ids[k] = (await q1(`SELECT cm.id FROM company_members cm JOIN users u ON u.id=cm.user_id WHERE u.phone=$1`, [p])).id;
  }
  ids.g1 = (await q1(`SELECT id FROM groups WHERE name='Nhóm Vận hành'`)).id;
});
afterAll(async () => { await app.close(); await closePool(); });

describe('Tài khoản SĐT & gói doanh nghiệp', () => {
  test('Đăng nhập bằng SĐT ở nhiều định dạng', async () => {
    for (const p of ['0901 000 007', '+84901000007', '84901000007']) {
      expect((await call('', 'POST', '/auth/login', { phone: p, password: 'Demo@123' })).status).toBe(201);
    }
    expect((await call('', 'POST', '/auth/login', { phone: '0901000007', password: 'sai' })).status).toBe(401);
  });

  test('Đăng ký cá nhân -> chưa có doanh nghiệp -> mua gói -> thành Owner', async () => {
    const r = await ok('', 'POST', '/auth/register', { phone: '0988111222', name: 'Trần Văn Chủ', password: 'Matkhau123' });
    expect(r.member_id).toBeNull();
    tok.new = r.access_token;
    const me = await ok('new', 'GET', '/auth/me');
    expect(me.name).toBe('Trần Văn Chủ');
    expect(me.company_id).toBeNull();
    expect((await call('new', 'GET', '/tasks')).status).toBe(401);
    expect((await call('', 'POST', '/auth/register', { phone: '0988111222', name: 'Người Khác', password: 'Matkhau123' })).status).toBe(409);
    const s = await ok('new', 'POST', '/subscriptions', { plan: 'small', companyName: 'Cửa hàng Chủ Mới', contactEmail: 'lienhe@chumoi.vn' });
    expect(s.subscription.status).toBe('active');
    const sw = await ok('new', 'POST', '/auth/switch-company', { companyId: s.company_id });
    tok.new = sw.access_token;
    const me2 = await ok('new', 'GET', '/auth/me');
    expect(me2.role).toBe('owner');
    expect(me2.plan).toBe('small');
    expect(me2.member_limit).toBe(20);
  });

  test('Quản lý thêm thành viên bằng SĐT -> chờ HR duyệt; người đó đăng ký bằng SĐT để kích hoạt', async () => {
    const r = await ok('m1', 'POST', '/company/members', { phone: '0977 333 444', name: 'Lâm Thị Mới', groupId: ids.g1 });
    expect(r.status).toBe('pending_hr');
    expect(r.invited).toBe(true);
    expect((await call('m1', 'POST', '/company/members', { phone: '0977333445', name: 'Quản Lý Giả', role: 'manager' })).status).toBe(403);
    const n = await ok('hr', 'GET', '/notifications');
    expect(n.items.some((i: any) => i.type === 'member.pending_hr' && i.reference_id === r.id)).toBe(true);
    expect((await call('m1', 'POST', `/company/members/${r.id}/hr-review`, { decision: 'approve' })).status).toBe(403);
    await ok('hr', 'POST', `/company/members/${r.id}/hr-review`, { decision: 'approve' });
    // chưa kích hoạt -> không đăng nhập được, phải đăng ký
    expect((await call('', 'POST', '/auth/login', { phone: '0977333444', password: 'x' })).status).toBe(401);
    const reg = await ok('', 'POST', '/auth/register', { phone: '0977333444', name: 'Lâm Thị Mới', password: 'Matkhau123' });
    expect(reg.member_id).toBe(r.id);
    const g = await ok('m1', 'GET', `/groups/${ids.g1}`);
    expect(g.members.some((m: any) => m.member_id === r.id)).toBe(true);
  });

  test('Vượt hạn mức thành viên của gói', async () => {
    const cid = (await q1(`SELECT company_id FROM company_members WHERE id=$1`, [ids.owner])).company_id;
    const cnt = (await q1(`SELECT count(*)::int AS n FROM company_members WHERE company_id=$1 AND status IN ('active','pending_hr')`, [cid])).n;
    await q(`UPDATE companies SET member_limit=$2 WHERE id=$1`, [cid, cnt]);
    const r = await call('admin', 'POST', '/company/members', { phone: '0966000111', name: 'Người Vượt Gói' });
    expect(r.status).toBe(402);
    expect(r.body.error.code).toBe('PLAN_LIMIT');
    await q(`UPDATE companies SET member_limit=100 WHERE id=$1`, [cid]);
  });
});

describe('Hồ sơ & ảnh đại diện', () => {
  test('Nhân viên điền hồ sơ; quản lý xem được kèm lịch sử tự động; người ngoài công ty không xem được', async () => {
    await ok('e1', 'PUT', '/profile/me', { dob: '1995-03-02', education: 'Cao đẳng Logistics', years_experience: 4, skills: 'Kiểm kê, Excel', id_number: '012345678' });
    await ok('e1', 'POST', '/profile/me/history', { company_name: 'Kho Vận ABC', position: 'Thủ kho', start_date: '2019-01', end_date: '2022-06' });
    const uid = (await q1(`SELECT user_id FROM company_members WHERE id=$1`, [ids.e1])).user_id;
    const v = await ok('m1', 'GET', `/profiles/${uid}`);
    expect(v.profile.education).toBe('Cao đẳng Logistics');
    expect(v.profile.id_number).toBeUndefined();
    expect(v.work_history[0].company_name).toBe('Kho Vận ABC');
    expect(v.auto_history[0].tasks_completed).toBeGreaterThan(0);
    expect((await call('e2', 'GET', `/profiles/${uid}`)).status).toBe(403);
    expect((await call('new', 'GET', `/profiles/${uid}`)).status).toBe(404);
  });

  test('Ảnh đại diện chụp từ camera', async () => {
    const png = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==';
    await ok('e1', 'PUT', '/profile/me/avatar', { dataUrl: png, capturedLive: true, faceDetected: true });
    const uid = (await q1(`SELECT user_id FROM company_members WHERE id=$1`, [ids.e1])).user_id;
    const r = await fetch(`${url}/users/${uid}/avatar`, { headers: { Authorization: `Bearer ${tok.m1}` } });
    expect(r.status).toBe(200);
    expect(r.headers.get('content-type')).toBe('image/png');
    expect((await fetch(`${url}/users/${uid}/avatar`, { headers: { Authorization: `Bearer ${tok.new}` } })).status).toBe(404);
  });
});

describe('Lịch, ghim việc gấp, tự chuyển việc sang ngày sau', () => {
  test('Ghim việc: chỉ quản lý; nhân viên nhận thông báo; việc ghim lên đầu danh sách', async () => {
    const t = await q1(`SELECT t.id FROM tasks t JOIN task_assignees ta ON ta.task_id=t.id AND ta.company_member_id=$1 AND ta.assignment_type='owner'
                         WHERE t.status IN ('not_started','in_progress') AND NOT t.pinned ORDER BY t.due_at DESC LIMIT 1`, [ids.e1]);
    expect((await call('e1', 'POST', `/tasks/${t.id}/pin`, { pinned: true })).status).toBe(403);
    const d = await ok('m1', 'POST', `/tasks/${t.id}/pin`, { pinned: true });
    expect(d.pinned).toBe(true);
    expect(d.urgent).toBe(true);
    const list = await ok('e1', 'GET', '/tasks?mine=any');
    expect(list.items[0].pinned).toBe(true);
    const n = await ok('e1', 'GET', '/notifications');
    expect(n.items.some((i: any) => i.type === 'task.pinned' && i.reference_id === t.id)).toBe(true);
    await ok('m1', 'POST', `/tasks/${t.id}/pin`, { pinned: false, urgent: false });
    const n2 = await ok('e1', 'GET', '/notifications');
    expect(n2.items.some((i: any) => i.type === 'task.unpinned' && i.reference_id === t.id)).toBe(true);
  });

  test('Việc chưa hoàn thành hết ngày tự chuyển sang hôm sau; việc đã xong giữ nguyên', async () => {
    const open = await q1(`SELECT id FROM tasks WHERE status='in_progress' LIMIT 1`);
    const done = await q1(`SELECT id, plan_date FROM tasks WHERE status='completed' LIMIT 1`);
    await q(`UPDATE tasks SET plan_date=current_date - 2, carry_count=0 WHERE id = ANY($1::uuid[])`, [[open.id, done.id]]);
    await runSchedulerOnce(new Date());
    await runSchedulerOnce(new Date());
    const o = await q1(`SELECT to_char(plan_date,'YYYY-MM-DD') AS d, carry_count FROM tasks WHERE id=$1`, [open.id]);
    const today = new Date().toLocaleDateString('en-CA', { timeZone: 'Asia/Ho_Chi_Minh' });
    expect(o.d).toBe(today);
    expect(o.carry_count).toBe(1);
    const dn = await q1(`SELECT to_char(plan_date,'YYYY-MM-DD') AS d FROM tasks WHERE id=$1`, [done.id]);
    expect(dn.d).not.toBe(today);
  });

  test('Lịch tuần trả về số việc theo ngày và danh sách việc trong ngày', async () => {
    const today = new Date().toLocaleDateString('en-CA', { timeZone: 'Asia/Ho_Chi_Minh' });
    const from = new Date(Date.now() - 3 * 86400000).toISOString().slice(0, 10);
    const to = new Date(Date.now() + 10 * 86400000).toISOString().slice(0, 10);
    const cal = await ok('e2', 'GET', `/calendar?from=${from}&to=${to}`);
    expect(cal.today).toBe(today);
    const d = cal.days.find((x: any) => x.date === today);
    expect(d.planned).toBeGreaterThan(0);
    const list = await ok('e2', 'GET', `/tasks?mine=any&planDate=${today}`);
    expect(list.items.length).toBe(d.planned);
  });
});

describe('Khai việc nhanh qua gọi điện / tin nhắn', () => {
  test('Quản lý khai trước -> nhân viên không khai trùng, chỉ cần xác nhận -> tạo nhiệm vụ', async () => {
    const at = new Date().toISOString();
    const c = await ok('m1', 'POST', '/quick-claims', { counterpartId: ids.e1, channel: 'call', occurredAt: at, title: 'Chuẩn bị 20 pallet cho chuyến 15h' });
    expect(c.manager_id).toBe(ids.m1);
    expect(c.assignee_id).toBe(ids.e1);
    const dup = await call('e1', 'POST', '/quick-claims', { counterpartId: ids.m1, channel: 'call', occurredAt: at, title: 'Chuẩn bị pallet' });
    expect(dup.status).toBe(409);
    expect(dup.body.error.code).toBe('CLAIM_EXISTS');
    expect(dup.body.error.details.id).toBe(c.id);
    const chk = await ok('e1', 'GET', `/quick-claims/check?counterpartId=${ids.m1}`);
    expect(chk.existing.id).toBe(c.id);
    expect((await call('m1', 'POST', `/quick-claims/${c.id}/confirm`, {})).status).toBe(403);
    const done = await ok('e1', 'POST', `/quick-claims/${c.id}/confirm`, {});
    expect(done.status).toBe('confirmed');
    const t = await ok('e1', 'GET', `/tasks/${done.task_id}`);
    expect(t.owner_id).toBe(ids.e1);
    expect(t.created_by).toBe(ids.m1);
  });

  test('Nhân viên khai, quản lý từ chối -> chuyển thành bản ghi tự khai báo (có quyền tranh chấp)', async () => {
    const c = await ok('e2', 'POST', '/quick-claims', { counterpartId: ids.m1, channel: 'sms', occurredAt: new Date(Date.now() - 86400000 * 3).toISOString(), title: 'Dọn kho lạnh theo tin nhắn', estimatedHours: 2 });
    expect((await call('m1', 'POST', `/quick-claims/${c.id}/reject`, { reason: 'ngắn' })).status).toBe(422);
    await ok('m1', 'POST', `/quick-claims/${c.id}/reject`, { reason: 'Không có tin nhắn giao việc này' });
    const r = await ok('e2', 'POST', `/quick-claims/${c.id}/to-work-record`);
    const wr = await ok('e2', 'GET', `/work-records/${r.work_record_id}`);
    expect(wr.claimed_minutes).toBe(120);
    expect(wr.reviewer_member_id).toBe(ids.m1);
  });

  test('Không khai việc giữa hai nhân viên ngang cấp', async () => {
    const r = await call('e1', 'POST', '/quick-claims', { counterpartId: ids.e2, channel: 'call', occurredAt: new Date().toISOString(), title: 'Việc ngang cấp' });
    expect(r.status).toBe(422);
  });
});

describe('Nghỉ phép', () => {
  test('Xin nghỉ theo ca -> quản lý duyệt -> xuất đơn PDF, gửi Nhân sự; trạng thái hiện khi giao việc', async () => {
    const d = new Date(Date.now() + 9 * 86400000).toISOString().slice(0, 10);
    const l = await ok('e2', 'POST', '/leaves', { leaveType: 'shift', date: d, shift: 'morning', reason: 'Làm thủ tục hành chính' });
    expect(l.approver_id).toBe(ids.m1);
    expect(l.minutes).toBe(240);
    expect(l.late_notice).toBe(false);
    expect((await call('e2', 'POST', `/leaves/${l.id}/decide`, { decision: 'approve' })).status).toBe(403);
    expect((await call('m1', 'POST', `/leaves/${l.id}/decide`, { decision: 'reject' })).status).toBe(422);
    const a = await ok('m1', 'POST', `/leaves/${l.id}/decide`, { decision: 'approve' });
    expect(a.status).toBe('approved');
    expect(a.pdf_file_id).toBeTruthy();
    expect(a.hr_email_status).toMatch(/^skipped/);
    const n = await ok('hr', 'GET', '/notifications');
    expect(n.items.some((i: any) => i.type === 'leave.hr' && i.reference_id === l.id)).toBe(true);
    const pdf = await fetch(`${url}/leaves/${l.id}/pdf`, { headers: { Authorization: `Bearer ${tok.hr}` } });
    expect(pdf.status).toBe(200);
    expect((await pdf.arrayBuffer()).byteLength).toBeGreaterThan(5000);
    const av = await ok('m1', 'GET', `/team/availability?from=${d}&to=${d}&groupId=${ids.g1}`);
    expect(av.members.find((m: any) => m.member_id === ids.e2).status).toBe('on_leave');
    expect((await call('e1', 'GET', `/team/availability?from=${d}&to=${d}`)).status).toBe(403);
    // trùng thời gian
    expect((await call('e2', 'POST', '/leaves', { leaveType: 'day', startDate: d, endDate: d, reason: 'Trùng đơn cũ' })).status).toBe(409);
  });

  test('Nghỉ theo giờ báo trước quá ngắn bị gắn cờ; nghỉ đột xuất không cần báo trước', async () => {
    const s = new Date(Date.now() + 3600000);
    const l = await ok('e3', 'POST', '/leaves', { leaveType: 'hourly', startAt: s.toISOString(), endAt: new Date(s.getTime() + 2 * 3600000).toISOString(), reason: 'Đón con ốm' });
    expect(l.late_notice).toBe(true);
    const sd = await ok('e1', 'POST', '/leaves', { leaveType: 'sudden', startAt: new Date(Date.now() - 1800000).toISOString(), endAt: new Date(Date.now() + 3 * 3600000).toISOString(), reason: 'Ốm đột xuất' });
    expect(sd.late_notice).toBe(false);
  });
});
