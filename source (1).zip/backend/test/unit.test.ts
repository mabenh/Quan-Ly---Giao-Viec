import { addWorkingMinutes, slaDue, workingMinutesBetween } from '../src/common/calendar';
import { DEFAULT_PERFORMANCE, DEFAULT_SETTINGS } from '../src/common/defaults';
import { scoreMembers, TaskRow } from '../src/modules/performance.service';

const cal = DEFAULT_SETTINGS.calendar; // T2-T6, 08-12, 13-17, lễ 02/09
const tz = 'Asia/Ho_Chi_Minh';
const vn = (s: string) => new Date(s + '+07:00');

describe('Lịch làm việc (deadline/SLA theo giờ làm việc)', () => {
  test('cộng phút vượt qua nghỉ trưa', () => {
    expect(addWorkingMinutes(vn('2026-11-12T11:00:00'), 120, cal, tz).toISOString()).toBe(vn('2026-11-12T14:00:00').toISOString());
  });
  test('báo cáo gửi tối thứ Sáu -> tính từ sáng thứ Hai', () => {
    expect(addWorkingMinutes(vn('2026-11-13T20:00:00'), 60, cal, tz).toISOString()).toBe(vn('2026-11-16T09:00:00').toISOString());
  });
  test('bỏ qua ngày lễ', () => {
    // 01/09/2026 là thứ Ba; 02/09 nghỉ lễ
    expect(addWorkingMinutes(vn('2026-09-01T16:00:00'), 120, cal, tz).toISOString()).toBe(vn('2026-09-03T09:00:00').toISOString());
  });
  test('1 ngày làm việc = 480 phút', () => {
    expect(addWorkingMinutes(vn('2026-11-12T08:00:00'), 480, cal, tz).toISOString()).toBe(vn('2026-11-12T17:00:00').toISOString());
  });
  test('đếm phút làm việc giữa hai thời điểm (qua cuối tuần)', () => {
    expect(workingMinutesBetween(vn('2026-11-13T16:00:00'), vn('2026-11-16T09:00:00'), cal, tz)).toBe(120);
  });
  test('mức nghiêm trọng dùng thời gian thực 24/7', () => {
    expect(slaDue(vn('2026-11-14T23:00:00'), 15, 'critical', cal, tz).toISOString()).toBe(vn('2026-11-14T23:15:00').toISOString());
  });
});

describe('Bộ máy tính điểm (mục 9)', () => {
  const base = { n_collab: 0, is_unexpected: false, requirement_structure: null, status: 'completed', revision_count: 0, impediment_confirmed: false,
    due_at: new Date('2026-11-10'), first_submitted_at: new Date('2026-11-09'), completed_at: new Date('2026-11-09'), scores: { process: 80 } } as any;
  test('P = Σ(điểm×W)/ΣW với W = hệ số phức tạp × hệ số yêu cầu', () => {
    const rows: TaskRow[] = [
      { ...base, task_id: 'a', member_id: 'm', assignment_type: 'owner', complexity: 'simple', requirement_level: 'normal', total_score: 60 },
      { ...base, task_id: 'b', member_id: 'm', assignment_type: 'owner', complexity: 'very_complex', requirement_level: 'high', total_score: 90 },
    ];
    const { scores } = scoreMembers(rows, [{ member_id: 'm', role: 'employee' }], DEFAULT_PERFORMANCE);
    const W1 = 1.0, W2 = 2.2 * 1.1;
    expect(scores.m.P).toBeCloseTo((60 * W1 + 90 * W2) / (W1 + W2), 2);
    expect(scores.m.T).toBe(100);
    expect(scores.m.E).not.toBeNull();
  });
  test('cộng tác viên không nhân đôi điểm toàn phần', () => {
    const rows: TaskRow[] = [
      { ...base, task_id: 'a', member_id: 'o', assignment_type: 'owner', n_collab: 2, complexity: 'medium', requirement_level: 'normal', total_score: 80 },
      { ...base, task_id: 'a', member_id: 'c1', assignment_type: 'collaborator', n_collab: 2, complexity: 'medium', requirement_level: 'normal', total_score: 80 },
      { ...base, task_id: 'a', member_id: 'c2', assignment_type: 'collaborator', n_collab: 2, complexity: 'medium', requirement_level: 'normal', total_score: 80 },
    ];
    const { scores } = scoreMembers(rows, ['o', 'c1', 'c2'].map((m) => ({ member_id: m, role: 'employee' })), DEFAULT_PERFORMANCE);
    const total = scores.o.v_raw + scores.c1.v_raw + scores.c2.v_raw;
    expect(total).toBeCloseTo(1.3, 2); // đúng bằng W của 1 nhiệm vụ
    expect(scores.o.v_raw).toBeCloseTo(1.3 * 0.6, 2);
  });
  test('trễ hạn có trở ngại đã xác nhận không trừ điểm tiến độ; hủy không tính', () => {
    const rows: TaskRow[] = [
      { ...base, task_id: 'a', member_id: 'm', assignment_type: 'owner', complexity: 'simple', requirement_level: 'normal', total_score: 80,
        first_submitted_at: new Date('2026-11-12'), impediment_confirmed: true },
      { ...base, task_id: 'b', member_id: 'm', assignment_type: 'owner', complexity: 'simple', requirement_level: 'normal', total_score: 80 },
      { ...base, task_id: 'c', member_id: 'm', assignment_type: 'owner', complexity: 'simple', requirement_level: 'normal', total_score: null, status: 'cancelled', first_submitted_at: null },
    ];
    const { scores } = scoreMembers(rows, [{ member_id: 'm', role: 'employee' }], DEFAULT_PERFORMANCE);
    expect(scores.m.T).toBe(100);
    expect(scores.m.excused_late).toBe(1);
    expect(scores.m.completed_count).toBe(2);
  });
  test('tách điểm việc đột xuất và thường xuyên', () => {
    const rows: TaskRow[] = [
      { ...base, task_id: 'a', member_id: 'm', assignment_type: 'owner', complexity: 'simple', requirement_level: 'normal', total_score: 70 },
      { ...base, task_id: 'b', member_id: 'm', assignment_type: 'owner', complexity: 'simple', requirement_level: 'normal', total_score: 90, is_unexpected: true, requirement_structure: 'diverse', scores: { coordination: 90 } },
    ];
    const { scores } = scoreMembers(rows, [{ member_id: 'm', role: 'employee' }], DEFAULT_PERFORMANCE);
    expect(scores.m.regular.P).toBe(70);
    expect(scores.m.unexpected.P).toBe(90);
    expect(scores.m.unexpected.diverse).toBe(1);
  });
});
