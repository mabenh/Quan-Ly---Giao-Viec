/* Kiểm thử nghiệm thu MVP (mục 16) và tình huống biên (16.1) trên PostgreSQL thật. */
process.env.DATABASE_URL = process.env.TEST_DATABASE_URL || 'postgresql://app:app@localhost:5432/teamapp_test';
process.env.DISABLE_SCHEDULER = 'true';
process.env.UPLOAD_DIR = '/tmp/teamapp-test-uploads';

import { INestApplication } from '@nestjs/common';
import { closePool, q, q1 } from '../src/db/db';
import { createApp } from '../src/main';
import { resetDb, seed } from '../src/db/seed';
import { runSchedulerOnce } from '../src/modules/scheduler.service';
import { createCompanyWithOwner } from '../src/modules/auth.controller';

let app: INestApplication;
let url = '';
const tok: Record<string, string> = {};
const ids: Record<string, string> = {};

async function call(who: string, method: string, path: string, body?: any, headers: any = {}) {
  const r = await fetch(url + path, {
    method, headers: { 'Content-Type': 'application/json', ...(tok[who] ? { Authorization: `Bearer ${tok[who]}` } : {}), ...headers },
    body: body ? JSON.stringify(body) : undefined,
  });
  const j: any = await r.json().catch(() => ({}));
  return { status: r.status, body: j };
}
async function ok(who: string, method: string, path: string, body?: any, headers?: any) {
  const r = await call(who, method, path, body, headers);
  if (r.status >= 300) throw new Error(`${method} ${path} -> ${r.status} ${JSON.stringify(r.body)}`);
  return r.body;
}
async function login(who: string, email: string) {
  tok[who] = (await ok('', 'POST', '/auth/login', { email, password: 'Demo@123' })).access_token;
}
const memberId = async (email: string) => (await q1(`SELECT cm.id FROM company_members cm JOIN users u ON u.id=cm.user_id WHERE u.email=$1`, [email])).id;

beforeAll(async () => {
  await resetDb();
  app = await createApp();
  await app.listen(0);
  url = `http://127.0.0.1:${(app.getHttpServer().address() as any).port}/api/v1`;
  await seed(url);
  for (const [k, e] of Object.entries({ owner: 'owner@demo.vn', admin: 'admin@demo.vn', m1: 'quanly1@demo.vn', m2: 'quanly2@demo.vn', kt1: 'truongkt@demo.vn',
    kt2: 'kythuat@demo.vn', e1: 'nv1@demo.vn', e2: 'nv2@demo.vn', e3: 'nv3@demo.vn', e4: 'nv4@demo.vn', rv: 'reviewer@demo.vn' })) {
    await login(k, e);
    ids[k] = await memberId(e);
  }
  ids.g1 = (await q1(`SELECT id FROM groups WHERE name='Nhóm Vận hành'`)).id;
  ids.g2 = (await q1(`SELECT id FROM groups WHERE name='Nhóm Kinh doanh'`)).id;
  ids.tt = (await q1(`SELECT id FROM task_types WHERE name='Vận hành'`)).id;
  ids.kt = (await q1(`SELECT id FROM departments WHERE name LIKE 'Kỹ thuật%'`)).id;
});

afterAll(async () => {
  await app.close();
  await closePool();
});

const newTask = (who: string, groupId: string, owner: string, extra: any = {}) => ok(who, 'POST', '/tasks', {
  title: 'Nhiệm vụ kiểm thử', description: 'Mô tả phạm vi kiểm thử', groupId, ownerMemberId: owner, taskTypeId: ids.tt,
  complexity: 'medium', requirementLevel: 'normal', estimatedHours: 8, dueAt: new Date(Date.now() + 86400000).toISOString(),
  criteria: [{ direction: 'output', criterion: 'Đạt tiêu chí' }], ...extra,
});

const newRecord = (who: string, extra: any = {}) => ok(who, 'POST', '/work-records', {
  title: 'Việc được giao ngoài app', groupId: ids.g1, requesterMemberId: ids.m1,
  startAt: '2026-11-02T01:00:00Z', endAt: '2026-11-02T03:00:00Z', recordType: 'assigned_outside',
  result: 'Đã hoàn thành', reasonNotInSystem: 'Giao qua điện thoại', ...extra,
});

describe('Tạo nhóm & phân quyền', () => {
  test('Employee không tạo được nhóm; Manager tạo được và là quản lý chính', async () => {
    expect((await call('e1', 'POST', '/groups', { name: 'Nhóm X' })).status).toBe(403);
    const g = await ok('m2', 'POST', '/groups', { name: 'Nhóm Y' });
    expect(g.manager_member_id).toBe(ids.m2);
  });

  test('Không xem được dữ liệu công ty khác (cách ly ở backend)', async () => {
    await createCompanyWithOwner({ companyName: 'Công ty B', name: 'Chủ B', email: 'ownerb@test.vn', password: 'Demo@123' });
    const lb = await ok('', 'POST', '/auth/login', { email: 'ownerb@test.vn', password: 'Demo@123' });
    tok.ob = lb.access_token;
    const t = await q1(`SELECT id FROM tasks LIMIT 1`);
    expect((await call('ob', 'GET', `/tasks/${t.id}`)).status).toBe(404);
    expect((await call('ob', 'GET', `/groups/${ids.g1}`)).status).toBe(404);
    const list = await ok('ob', 'GET', '/tasks');
    expect(list.total).toBe(0);
  });

  test('Quản lý chỉ giao việc trong nhóm mình quản lý (D03)', async () => {
    const r = await call('m2', 'POST', '/tasks', {
      title: 'Giao chéo', description: 'Thử giao chéo nhóm', groupId: ids.g1, ownerMemberId: ids.e1, taskTypeId: ids.tt, complexity: 'simple',
      requirementLevel: 'normal', estimatedHours: 2, dueAt: new Date().toISOString(), criteria: [{ direction: 'output', criterion: 'Đạt' }],
    });
    expect(r.status).toBe(403);
  });

  test('Tài khoản bị khóa mất quyền truy cập ngay', async () => {
    await ok('admin', 'PATCH', `/company/members/${ids.e4}`, { lockUser: true });
    expect((await call('e4', 'GET', '/dashboard')).status).toBe(401);
    await ok('admin', 'PATCH', `/company/members/${ids.e4}`, { lockUser: false });
  });
});

describe('Giao việc & nghiệm thu', () => {
  test('Bắt buộc tiêu chí đầu ra; nhân viên không tự hủy; luồng bàn giao/yêu cầu sửa/nghiệm thu có lịch sử', async () => {
    const bad = await call('m1', 'POST', '/tasks', {
      title: 'Thiếu tiêu chí', description: 'Mô tả đầy đủ', groupId: ids.g1, ownerMemberId: ids.e1, taskTypeId: ids.tt, complexity: 'simple',
      requirementLevel: 'normal', estimatedHours: 2, dueAt: new Date().toISOString(), criteria: [{ direction: 'input', criterion: 'Chỉ đầu vào' }],
    });
    expect(bad.status).toBe(422);
    const t = await newTask('m1', ids.g1, ids.e1);
    expect((await call('e1', 'POST', `/tasks/${t.id}/cancel`, { reason: 'Không muốn làm nữa' })).status).toBe(403);
    await ok('e1', 'POST', `/tasks/${t.id}/start`);
    // Deadline đổi sau khi đã bắt đầu: bắt buộc lý do, lưu vết
    expect((await call('m1', 'PATCH', `/tasks/${t.id}`, { dueAt: new Date(Date.now() + 3 * 86400000).toISOString() })).status).toBe(422);
    await ok('m1', 'PATCH', `/tasks/${t.id}`, { dueAt: new Date(Date.now() + 3 * 86400000).toISOString(), reason: 'Khách hàng lùi lịch' });
    await ok('m1', 'PATCH', `/tasks/${t.id}`, { criteria: [{ direction: 'output', criterion: 'Tiêu chí mới v2' }], reason: 'Bổ sung phạm vi' });
    await ok('e1', 'POST', `/tasks/${t.id}/submit`, { outputDescription: 'Kết quả lần 1' });
    expect((await call('e1', 'POST', `/tasks/${t.id}/review`, { decision: 'approve', scores: {} })).status).toBe(403);
    await ok('m1', 'POST', `/tasks/${t.id}/review`, { decision: 'revision', comment: 'Cần bổ sung số liệu' });
    await ok('e1', 'POST', `/tasks/${t.id}/start`);
    await ok('e1', 'POST', `/tasks/${t.id}/submit`, { outputDescription: 'Kết quả lần 2' });
    const done = await ok('m1', 'POST', `/tasks/${t.id}/review`, { decision: 'approve', scores: { output: 80, quality: 90, schedule: 100, process: 70 } });
    expect(done.status).toBe('completed');
    expect(Number(done.evaluations[0].total_score)).toBeCloseTo(0.4 * 80 + 0.3 * 90 + 0.2 * 100 + 0.1 * 70, 2);
    expect(done.criteria_version).toBe(2);
    expect(done.criteria_history.length).toBe(2);
    const actions = done.activities.map((a: any) => a.action);
    expect(actions).toEqual(expect.arrayContaining(['task.created', 'task.deadline_changed', 'task.revision_requested', 'task.approved']));
    expect(done.activities.find((a: any) => a.action === 'task.deadline_changed').reason).toBe('Khách hàng lùi lịch');
  });

  test('Việc đột xuất yêu cầu đa dạng: nhiều yêu cầu con và phiên bản phạm vi', async () => {
    const t = await newTask('m1', ids.g1, ids.e2, {
      unexpected: { category: 'ad_hoc', requirementStructure: 'diverse', cause: 'superior_request' },
      subitems: [{ title: 'Yêu cầu A' }],
    });
    const d = await ok('m1', 'POST', `/tasks/${t.id}/subitems`, { title: 'Yêu cầu B', extraHours: 2, requestedBy: ids.admin });
    expect(d.subitems.length).toBe(2);
    expect(d.scope_version).toBe(2);
    expect(d.estimated_hours).toBe(10);
    expect(d.unexpected.requirement_structure).toBe('diverse');
  });

  test('Idempotency-Key: retry không tạo bản ghi trùng', async () => {
    const before = (await q1(`SELECT count(*)::int AS n FROM overtime_records`)).n;
    const body = { startAt: '2026-11-03T11:00:00Z', endAt: '2026-11-03T13:00:00Z', otType: 'ad_hoc', cause: 'Thử retry mất mạng' };
    const a = await ok('e3', 'POST', '/overtime-records', body, { 'Idempotency-Key': 'k-123' });
    const b = await ok('e3', 'POST', '/overtime-records', body, { 'Idempotency-Key': 'k-123' });
    expect(a.id).toBe(b.id);
    expect((await q1(`SELECT count(*)::int AS n FROM overtime_records`)).n).toBe(before + 1);
  });

  test('Tăng ca: từ chối phải có lý do, không bị xóa khi chưa duyệt', async () => {
    const o = await ok('e1', 'POST', '/overtime-records', { startAt: '2026-11-04T11:00:00Z', endAt: '2026-11-04T12:30:00Z', otType: 'incident', cause: 'Mất điện kho', groupId: ids.g1 });
    expect(o.minutes).toBe(90);
    expect(o.approval_status).toBe('pending');
    expect((await call('e1', 'POST', `/overtime-records/${o.id}/review`, { decision: 'confirm' })).status).toBe(403);
    expect((await call('m1', 'POST', `/overtime-records/${o.id}/review`, { decision: 'reject' })).status).toBe(422);
    const r = await ok('m1', 'POST', `/overtime-records/${o.id}/review`, { decision: 'reject', reason: 'Không có yêu cầu tăng ca' });
    expect(r.approval_status).toBe('rejected');
  });
});

describe('Tự khai báo, bắt buộc phản hồi, tranh chấp và khiếu nại', () => {
  test('Từ chối phải có lý do; xác nhận một phần phải nêu phạm vi', async () => {
    const r = await newRecord('e3', { startAt: '2026-11-05T01:00:00Z', endAt: '2026-11-05T02:00:00Z' });
    expect((await call('m1', 'POST', `/work-records/${r.id}/reviews`, { decision: 'reject' })).status).toBe(422);
    expect((await call('m1', 'POST', `/work-records/${r.id}/reviews`, { decision: 'partial', reason: 'Chỉ chấp nhận một phần thời gian', acceptedMinutes: 30 })).status).toBe(422);
    const d = await ok('m1', 'POST', `/work-records/${r.id}/reviews`, { decision: 'partial', reason: 'Chỉ chấp nhận một phần thời gian', acceptedMinutes: 30, acceptedScope: '30 phút đầu', rejectedScope: '30 phút sau trùng họp' });
    expect(d.status).toBe('partially_accepted');
    expect(d.accepted_minutes).toBe(30);
  });

  test('Khai báo trùng thời gian được gắn cảnh báo', async () => {
    await newRecord('e3', { title: 'Việc 1', startAt: '2026-11-06T01:00:00Z', endAt: '2026-11-06T03:00:00Z' });
    const b = await newRecord('e3', { title: 'Việc 2', startAt: '2026-11-06T02:00:00Z', endAt: '2026-11-06T04:00:00Z' });
    expect(b.overlap_warning).toBe(true);
    expect(b.overlaps.length).toBe(1);
  });

  test('Yêu cầu bổ sung không tính là từ chối; từ lần từ chối thứ 4 mới được khiếu nại; người bị khiếu nại không quyết định', async () => {
    const r = await newRecord('e1', { startAt: '2026-11-07T01:00:00Z', endAt: '2026-11-07T02:00:00Z' });
    for (let i = 0; i < 3; i++) {
      await ok('m1', 'POST', `/work-records/${r.id}/reviews`, { decision: 'needs_info', reason: 'Bổ sung ảnh chụp tin nhắn giao việc' });
      await ok('e1', 'POST', `/work-records/${r.id}/disputes`, { response: 'supplement', comment: 'Đã bổ sung ảnh' });
    }
    let d = await ok('e1', 'GET', `/work-records/${r.id}`);
    expect(d.consecutive_rejections).toBe(0);
    for (let i = 1; i <= 3; i++) {
      await ok('m1', 'POST', `/work-records/${r.id}/reviews`, { decision: 'reject', reason: `Lý do từ chối lần ${i} chi tiết`, basis: 'Nhật ký ca' });
      await ok('e1', 'POST', `/work-records/${r.id}/disputes`, { response: 'dispute', comment: 'Tôi không đồng ý, có bằng chứng.' });
    }
    d = await ok('e1', 'GET', `/work-records/${r.id}`);
    expect(d.consecutive_rejections).toBe(3);
    expect(d.permissions.can_appeal_by_count).toBe(false);
    const early = await call('e1', 'POST', `/work-records/${r.id}/appeals`, { reason: 'Muốn khiếu nại lên cấp trên ngay' });
    expect(early.status).toBe(409);
    expect(early.body.error.code).toBe('APPEAL_THRESHOLD_NOT_MET');
    // Lần từ chối thứ 4
    await ok('m1', 'POST', `/work-records/${r.id}/reviews`, { decision: 'reject', reason: 'Lý do từ chối lần 4 chi tiết', basis: 'Nhật ký ca' });
    d = await ok('e1', 'GET', `/work-records/${r.id}`);
    expect(d.permissions.can_appeal_by_count).toBe(true);
    const a = await ok('e1', 'POST', `/work-records/${r.id}/appeals`, { reason: 'Đã 4 lần bị từ chối không có căn cứ xác đáng' });
    expect(a.status).toBe('appealed');
    expect(a.consecutive_rejections).toBe(4);
    const appeal = a.appeals[0];
    expect(appeal.respondent_id).toBe(ids.m1);
    expect(appeal.reviewer_id).toBe(ids.admin); // cấp trên của quản lý bị khiếu nại
    expect((await call('m1', 'POST', `/work-records/${r.id}/appeals/${appeal.id}/resolve`, { decision: 'reject', reason: 'Tôi giữ nguyên quyết định' })).status).toBe(403);
    const fin = await ok('admin', 'POST', `/work-records/${r.id}/appeals/${appeal.id}/resolve`, { decision: 'accept', reason: 'Bằng chứng tin nhắn hợp lệ' });
    expect(fin.status).toBe('resolved');
    expect(fin.final_decision).toBe('accepted');
    // Lịch sử từ chối bất biến
    await expect(q(`UPDATE work_record_reviews SET reason='sửa' WHERE work_record_id=$1`, [r.id])).rejects.toThrow(/IMMUTABLE_RECORD/);
    await expect(q(`DELETE FROM work_record_reviews WHERE work_record_id=$1`, [r.id])).rejects.toThrow(/IMMUTABLE_RECORD/);
  });

  test('Khiếu nại sớm khi xung đột lợi ích; người bị khiếu nại là cấp cao nhất -> reviewer độc lập', async () => {
    // Admin tự khai báo; người xác nhận là Owner (cấp cao nhất)
    const r = await ok('admin', 'POST', '/work-records', {
      title: 'Họp với đối tác ngoài giờ', requesterMemberId: ids.owner, startAt: '2026-11-08T12:00:00Z', endAt: '2026-11-08T14:00:00Z',
      recordType: 'after_hours', result: 'Đã ký biên bản', reasonNotInSystem: 'Owner yêu cầu trực tiếp',
    });
    expect(r.reviewer_member_id).toBe(ids.owner);
    await ok('owner', 'POST', `/work-records/${r.id}/reviews`, { decision: 'reject', reason: 'Cuộc họp không được phê duyệt', basis: 'Lịch công tác' });
    const a = await ok('admin', 'POST', `/work-records/${r.id}/appeals`, {
      reason: 'Người từ chối là người trực tiếp yêu cầu tôi đi họp', early: true, earlyReason: 'respondent_is_decider', earlyDetail: 'Owner vừa yêu cầu vừa từ chối xác nhận',
    });
    expect(a.status).toBe('appealed');
    expect(a.appeals[0].early).toBe(true);
    expect(a.appeals[0].reviewer_id).toBe(ids.rv);
  });

  test('Quá SLA: nhắc + chuyển cấp, không coi im lặng là đồng ý/từ chối, không tạo chuyển cấp trùng', async () => {
    const r = await newRecord('e2', { startAt: '2026-11-09T01:00:00Z', endAt: '2026-11-09T02:00:00Z' });
    await q(`UPDATE employee_work_records SET review_due_at=now() - interval '1 minute' WHERE id=$1`, [r.id]);
    await runSchedulerOnce(new Date());
    await runSchedulerOnce(new Date());
    const d = await ok('e2', 'GET', `/work-records/${r.id}`);
    expect(d.status).toBe('submitted');
    expect(d.overdue).toBe(true);
    expect(d.escalation_level).toBe(1);
    expect(d.escalations.length).toBe(1);
    expect(d.escalations[0].to_member_id).toBe(ids.admin);
    // cấp trên nhận chuyển cấp có thể xác nhận
    const v = await ok('admin', 'POST', `/work-records/${r.id}/reviews`, { decision: 'accept' });
    expect(v.status).toBe('accepted');
    expect(v.escalations[0].status).toBe('resolved');
  });
});

describe('Báo cáo trở ngại & chuyển cấp SLA', () => {
  test('Luồng: gửi -> quản lý chuyển kỹ thuật -> kỹ thuật cập nhật -> người báo cáo mở lại -> đóng', async () => {
    const w = await ok('e1', 'POST', '/workplace-reports', {
      category: 'equipment', severity: 'medium', description: 'Máy quét mã vạch số 2 không đọc được mã', detectedAt: new Date().toISOString(), groupId: ids.g1,
    });
    expect(w.code).toMatch(/^BC-/);
    expect(w.manager_member_id).toBe(ids.m1);
    expect((await call('e1', 'POST', `/workplace-reports/${w.id}/assign`, { departmentId: ids.kt })).status).toBe(403);
    await ok('m1', 'POST', `/workplace-reports/${w.id}/assign`, { departmentId: ids.kt });
    await ok('kt1', 'POST', `/workplace-reports/${w.id}/acknowledge`, { assigneeId: ids.kt2 });
    expect((await call('kt2', 'POST', `/workplace-reports/${w.id}/updates`, { status: 'waiting', comment: 'Chờ linh kiện' })).status).toBe(422);
    await ok('kt2', 'POST', `/workplace-reports/${w.id}/updates`, { status: 'resolved_pending', comment: 'Đã thay đầu đọc' });
    let d = await ok('e1', 'POST', `/workplace-reports/${w.id}/confirm`, { decision: 'reopen', comment: 'Vẫn lỗi với mã QR cỡ nhỏ' });
    expect(d.status).toBe('reopened');
    expect(d.reopen_count).toBe(1);
    await ok('kt2', 'POST', `/workplace-reports/${w.id}/updates`, { status: 'resolved_pending', comment: 'Đã cập nhật firmware' });
    d = await ok('e1', 'POST', `/workplace-reports/${w.id}/confirm`, { decision: 'close' });
    expect(d.status).toBe('closed');
  });

  test('Quản lý không tiếp nhận đúng hạn -> chuyển cấp đúng tuyến, không trùng; quá tiếp -> lên cấp tiếp theo', async () => {
    const w = await ok('e2', 'POST', '/workplace-reports', {
      category: 'facility', severity: 'low', description: 'Đèn khu vực kho B bị chập chờn', detectedAt: new Date().toISOString(), groupId: ids.g1,
    });
    await q(`UPDATE workplace_reports SET stage_due_at=now() - interval '1 minute' WHERE id=$1`, [w.id]);
    await runSchedulerOnce(new Date());
    await runSchedulerOnce(new Date());
    let d = await ok('e2', 'GET', `/workplace-reports/${w.id}`);
    expect(d.status).toBe('escalated');
    expect(d.escalations.length).toBe(1);
    expect(d.escalations[0].to_member_id).toBe(ids.admin); // cấp trên của quản lý nhóm
    await q(`UPDATE workplace_reports SET stage_due_at=now() - interval '1 minute' WHERE id=$1`, [w.id]);
    await runSchedulerOnce(new Date());
    d = await ok('e2', 'GET', `/workplace-reports/${w.id}`);
    expect(d.escalations.length).toBe(2);
    expect(d.escalations[1].to_member_id).toBe(ids.owner);
    // Người nhận chuyển cấp có quyền chuyển bộ phận
    const a = await ok('admin', 'POST', `/workplace-reports/${w.id}/assign`, { departmentId: ids.kt });
    expect(a.stage).toBe('department_ack');
    expect(a.escalations.every((e: any) => e.status === 'resolved')).toBe(true);
  });

  test('Kênh độc lập: quản lý trực tiếp không xem được báo cáo', async () => {
    const w = await ok('e1', 'POST', '/workplace-reports', {
      category: 'process', severity: 'medium', description: 'Quản lý ca yêu cầu bỏ qua bước kiểm tra an toàn',
      detectedAt: new Date().toISOString(), groupId: ids.g1, independentChannel: true, independentReason: 'Phản ánh liên quan quản lý trực tiếp',
    });
    expect(w.manager_member_id).toBe(ids.rv);
    expect((await call('m1', 'GET', `/workplace-reports/${w.id}`)).status).toBe(404);
  });

  test('Nhiệm vụ bị ảnh hưởng bởi trở ngại đã xác nhận được gắn cờ', async () => {
    const t = await q1(`SELECT affected_task_id FROM workplace_reports WHERE affected_task_id IS NOT NULL AND impact_confirmed LIMIT 1`);
    const d = await ok('m1', 'GET', `/tasks/${t.affected_task_id}`);
    expect(d.impediment_confirmed).toBe(true);
  });
});

describe('Đánh giá & báo cáo', () => {
  test('Nhân viên chỉ xem báo cáo cá nhân; quản lý xem nhóm mình', async () => {
    expect((await call('e1', 'GET', '/performance/live?scopeType=company')).status).toBe(403);
    expect((await call('e1', 'GET', `/performance/live?scopeType=member&scopeId=${ids.e2}`)).status).toBe(403);
    expect((await call('m2', 'GET', `/performance/live?scopeType=group&scopeId=${ids.g1}`)).status).toBe(403);
    const g = await ok('m1', 'GET', `/performance/live?scopeType=group&scopeId=${ids.g1}`);
    expect(g.groups.length).toBe(1);
    const me = await ok('e1', 'GET', '/performance/me');
    expect(me.members.length).toBe(1);
    expect(me.members[0].member_id).toBe(ids.e1);
  });

  test('Snapshot giữ nguyên sau khi cấu hình công thức thay đổi; xuất PDF/Excel', async () => {
    const s = await ok('admin', 'POST', '/performance/reports/finalize', { periodType: 'month', scopeType: 'company' });
    const before = await ok('admin', 'GET', `/performance/reports/${s.id}`);
    await ok('admin', 'POST', '/company/performance-config', { employeeWeights: { V: 0.2, T: 0.2, Q: 0.4, D: 0.1, R: 0.1 } });
    const after = await ok('admin', 'GET', `/performance/reports/${s.id}`);
    expect(after.members).toEqual(before.members);
    expect(after.meta.formula_version).toBe(1);
    const live = await ok('admin', 'GET', '/performance/live?periodType=month&scopeType=company');
    expect(live.meta.formula_version).toBe(2);
    await expect(q(`UPDATE performance_reports SET snapshot='{}' WHERE id=$1`, [s.id])).rejects.toThrow(/IMMUTABLE_RECORD/);
    for (const f of ['pdf', 'xlsx']) {
      const r = await fetch(`${url}/performance/export?format=${f}&snapshotId=${s.id}`, { headers: { Authorization: `Bearer ${tok.admin}` } });
      expect(r.status).toBe(200);
      expect((await r.arrayBuffer()).byteLength).toBeGreaterThan(1000);
    }
  });

  test('Thông báo có liên kết đúng bản ghi và không gửi trùng', async () => {
    const n = await ok('e1', 'GET', '/notifications');
    expect(n.items.length).toBeGreaterThan(0);
    expect(n.items.every((i: any) => !i.reference_type || i.reference_id)).toBe(true);
    const dup = await q1(`SELECT count(*)::int AS n FROM (SELECT member_id, dedupe_key FROM notifications WHERE dedupe_key IS NOT NULL GROUP BY 1,2 HAVING count(*)>1) x`);
    expect(dup.n).toBe(0);
  });
});
