-- Schema MVP: Ứng dụng quản lý nhóm, giao việc và đánh giá hiệu suất
-- Quy tắc: UUID khóa chính, mọi dữ liệu nghiệp vụ có company_id, thời gian lưu UTC (timestamptz).
CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE IF NOT EXISTS companies (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  timezone text NOT NULL DEFAULT 'Asia/Ho_Chi_Minh',
  settings jsonb NOT NULL DEFAULT '{}'::jsonb,
  report_seq int NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  email text NOT NULL UNIQUE,
  phone text,
  password_hash text NOT NULL,
  auth_provider text NOT NULL DEFAULT 'password',
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active','locked')),
  failed_logins int NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS refresh_tokens (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id),
  token_hash text NOT NULL UNIQUE,
  expires_at timestamptz NOT NULL,
  revoked_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS departments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id uuid NOT NULL REFERENCES companies(id),
  name text NOT NULL,
  head_member_id uuid,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS company_members (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id uuid NOT NULL REFERENCES companies(id),
  user_id uuid NOT NULL REFERENCES users(id),
  role text NOT NULL CHECK (role IN ('owner','admin','manager','employee','handler','reviewer')),
  title text,
  department_id uuid REFERENCES departments(id),
  supervisor_member_id uuid REFERENCES company_members(id),
  can_cross_group_assign boolean NOT NULL DEFAULT false,
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active','inactive')),
  joined_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (company_id, user_id)
);
ALTER TABLE departments DROP CONSTRAINT IF EXISTS departments_head_fk;
ALTER TABLE departments ADD CONSTRAINT departments_head_fk FOREIGN KEY (head_member_id) REFERENCES company_members(id);

CREATE TABLE IF NOT EXISTS groups (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id uuid NOT NULL REFERENCES companies(id),
  name text NOT NULL,
  description text,
  manager_member_id uuid NOT NULL REFERENCES company_members(id),
  created_by uuid NOT NULL REFERENCES company_members(id),
  created_at timestamptz NOT NULL DEFAULT now(),
  deleted_at timestamptz
);

CREATE TABLE IF NOT EXISTS group_members (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  group_id uuid NOT NULL REFERENCES groups(id),
  company_member_id uuid NOT NULL REFERENCES company_members(id),
  joined_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (group_id, company_member_id)
);

CREATE TABLE IF NOT EXISTS task_types (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id uuid NOT NULL REFERENCES companies(id),
  name text NOT NULL,
  category text,
  active boolean NOT NULL DEFAULT true
);

CREATE TABLE IF NOT EXISTS task_templates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id uuid NOT NULL REFERENCES companies(id),
  name text NOT NULL,
  task_type_id uuid REFERENCES task_types(id),
  description text,
  complexity text NOT NULL DEFAULT 'simple',
  requirement_level text NOT NULL DEFAULT 'normal',
  estimated_hours numeric NOT NULL DEFAULT 4,
  criteria jsonb NOT NULL DEFAULT '[]'::jsonb,
  active boolean NOT NULL DEFAULT true
);

CREATE TABLE IF NOT EXISTS tasks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id uuid NOT NULL REFERENCES companies(id),
  group_id uuid NOT NULL REFERENCES groups(id),
  code text,
  title text NOT NULL,
  description text NOT NULL,
  status text NOT NULL DEFAULT 'not_started'
    CHECK (status IN ('not_started','in_progress','pending_review','completed','revision_requested','cancelled')),
  priority text NOT NULL DEFAULT 'normal',
  task_type_id uuid NOT NULL REFERENCES task_types(id),
  complexity text NOT NULL CHECK (complexity IN ('simple','medium','complex','very_complex')),
  requirement_level text NOT NULL CHECK (requirement_level IN ('normal','high','very_high')),
  estimated_hours numeric NOT NULL CHECK (estimated_hours > 0),
  due_at timestamptz NOT NULL,
  resources text,
  is_unexpected boolean NOT NULL DEFAULT false,
  scope_version int NOT NULL DEFAULT 1,
  revision_count int NOT NULL DEFAULT 0,
  cancel_reason text,
  cancelled_by uuid REFERENCES company_members(id),
  cancel_is_business_decision boolean,
  started_at timestamptz,
  first_submitted_at timestamptz,
  submitted_at timestamptz,
  completed_at timestamptz,
  created_by uuid NOT NULL REFERENCES company_members(id),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS tasks_company_status ON tasks(company_id, status);
CREATE INDEX IF NOT EXISTS tasks_group ON tasks(group_id);

CREATE TABLE IF NOT EXISTS task_assignees (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  task_id uuid NOT NULL REFERENCES tasks(id),
  company_member_id uuid NOT NULL REFERENCES company_members(id),
  assignment_type text NOT NULL CHECK (assignment_type IN ('owner','collaborator')),
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS task_one_owner ON task_assignees(task_id) WHERE assignment_type = 'owner' AND active;

CREATE TABLE IF NOT EXISTS task_criteria (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  task_id uuid NOT NULL REFERENCES tasks(id),
  version int NOT NULL,
  direction text NOT NULL CHECK (direction IN ('input','output')),
  criterion text NOT NULL,
  weight numeric,
  created_by uuid NOT NULL REFERENCES company_members(id),
  created_at timestamptz NOT NULL DEFAULT now()
);

-- Đầu việc con / yêu cầu thành phần (yêu cầu đa dạng)
CREATE TABLE IF NOT EXISTS task_subitems (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  task_id uuid NOT NULL REFERENCES tasks(id),
  title text NOT NULL,
  requested_by uuid REFERENCES company_members(id),
  extra_hours numeric NOT NULL DEFAULT 0,
  scope_version int NOT NULL,
  done boolean NOT NULL DEFAULT false,
  created_by uuid NOT NULL REFERENCES company_members(id),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS task_comments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  task_id uuid NOT NULL REFERENCES tasks(id),
  member_id uuid NOT NULL REFERENCES company_members(id),
  content text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS task_submissions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  task_id uuid NOT NULL REFERENCES tasks(id),
  submitted_by uuid NOT NULL REFERENCES company_members(id),
  output_description text NOT NULL,
  completion_percent int NOT NULL DEFAULT 100,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS task_evaluations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  task_id uuid NOT NULL REFERENCES tasks(id),
  evaluator_id uuid NOT NULL REFERENCES company_members(id),
  decision text NOT NULL CHECK (decision IN ('approved','revision_requested')),
  kind text NOT NULL DEFAULT 'regular' CHECK (kind IN ('regular','unexpected')),
  scores jsonb,
  total_score numeric,
  config_version int,
  comment text,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS unexpected_tasks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  task_id uuid NOT NULL UNIQUE REFERENCES tasks(id),
  category text NOT NULL CHECK (category IN ('ad_hoc','urgent','scope_addition','external_support')),
  requirement_structure text NOT NULL CHECK (requirement_structure IN ('common','diverse')),
  cause text NOT NULL CHECK (cause IN ('incident','superior_request','customer','resource_shortage','support_other_dept','other')),
  cause_detail text,
  requester_member_id uuid REFERENCES company_members(id),
  requested_at timestamptz NOT NULL DEFAULT now(),
  actual_hours numeric,
  impact text
);

CREATE TABLE IF NOT EXISTS overtime_records (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id uuid NOT NULL REFERENCES companies(id),
  member_id uuid NOT NULL REFERENCES company_members(id),
  group_id uuid REFERENCES groups(id),
  task_id uuid REFERENCES tasks(id),
  report_id uuid,
  start_at timestamptz NOT NULL,
  end_at timestamptz NOT NULL,
  minutes int NOT NULL,
  ot_type text NOT NULL CHECK (ot_type IN ('planned','ad_hoc','incident','workload','support')),
  cause text NOT NULL,
  requested_by_member_id uuid REFERENCES company_members(id),
  notified_in_advance boolean NOT NULL DEFAULT false,
  impact text,
  approval_status text NOT NULL DEFAULT 'pending' CHECK (approval_status IN ('pending','confirmed','rejected')),
  reviewer_id uuid REFERENCES company_members(id),
  review_reason text,
  reviewed_at timestamptz,
  created_by uuid NOT NULL REFERENCES company_members(id),
  created_at timestamptz NOT NULL DEFAULT now(),
  CHECK (end_at > start_at)
);

CREATE TABLE IF NOT EXISTS employee_work_records (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id uuid NOT NULL REFERENCES companies(id),
  employee_id uuid NOT NULL REFERENCES company_members(id),
  group_id uuid REFERENCES groups(id),
  title text NOT NULL,
  description text,
  requester_member_id uuid REFERENCES company_members(id),
  requester_unknown_note text,
  work_date date NOT NULL,
  start_at timestamptz NOT NULL,
  end_at timestamptz NOT NULL,
  is_estimated boolean NOT NULL DEFAULT false,
  claimed_minutes int NOT NULL,
  record_type text NOT NULL CHECK (record_type IN ('assigned_outside','missing','after_hours','support','other')),
  result text NOT NULL,
  completion_status text NOT NULL DEFAULT 'done' CHECK (completion_status IN ('done','partial','in_progress')),
  reason_not_in_system text NOT NULL,
  related_task_id uuid REFERENCES tasks(id),
  reviewer_member_id uuid REFERENCES company_members(id),
  status text NOT NULL DEFAULT 'submitted' CHECK (status IN ('submitted','needs_information','accepted','partially_accepted','rejected','disputed','appealed','resolved')),
  review_due_at timestamptz,
  overdue boolean NOT NULL DEFAULT false,
  sla_cycle int NOT NULL DEFAULT 0,
  escalation_level int NOT NULL DEFAULT 0,
  chain_no int NOT NULL DEFAULT 1,
  consecutive_rejections int NOT NULL DEFAULT 0,
  accepted_minutes int,
  overlap_warning boolean NOT NULL DEFAULT false,
  final_decision text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CHECK (end_at > start_at)
);
CREATE INDEX IF NOT EXISTS ewr_company_status ON employee_work_records(company_id, status);

-- Bản ghi bất biến: không update/delete
CREATE TABLE IF NOT EXISTS work_record_reviews (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  work_record_id uuid NOT NULL REFERENCES employee_work_records(id),
  reviewer_id uuid NOT NULL REFERENCES company_members(id),
  decision text NOT NULL CHECK (decision IN ('accept','partial','reject','needs_info')),
  reason text,
  basis text,
  related_period text,
  accepted_minutes int,
  accepted_scope text,
  rejected_scope text,
  chain_no int NOT NULL,
  rejection_no int,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS work_record_disputes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  work_record_id uuid NOT NULL REFERENCES employee_work_records(id),
  employee_id uuid NOT NULL REFERENCES company_members(id),
  review_id uuid REFERENCES work_record_reviews(id),
  response text NOT NULL CHECK (response IN ('accept','dispute','supplement')),
  comment text,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS work_record_appeals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  work_record_id uuid NOT NULL REFERENCES employee_work_records(id),
  appellant_id uuid NOT NULL REFERENCES company_members(id),
  respondent_id uuid REFERENCES company_members(id),
  reviewer_id uuid NOT NULL REFERENCES company_members(id),
  reason text NOT NULL,
  early boolean NOT NULL DEFAULT false,
  early_reason text,
  decision text CHECK (decision IN ('accept','partial','reject')),
  decision_reason text,
  accepted_minutes int,
  status text NOT NULL DEFAULT 'open' CHECK (status IN ('open','resolved')),
  created_at timestamptz NOT NULL DEFAULT now(),
  resolved_at timestamptz
);

CREATE TABLE IF NOT EXISTS files (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id uuid NOT NULL REFERENCES companies(id),
  parent_type text NOT NULL,
  parent_id uuid NOT NULL,
  filename text NOT NULL,
  mime text NOT NULL,
  size int NOT NULL,
  storage_key text NOT NULL,
  uploaded_by uuid NOT NULL REFERENCES company_members(id),
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS files_parent ON files(parent_type, parent_id);

CREATE TABLE IF NOT EXISTS sla_configs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id uuid NOT NULL REFERENCES companies(id),
  severity text NOT NULL CHECK (severity IN ('low','medium','high','critical')),
  manager_review_minutes int NOT NULL,
  acknowledge_minutes int NOT NULL,
  resolve_minutes int NOT NULL,
  UNIQUE (company_id, severity)
);

CREATE TABLE IF NOT EXISTS workplace_reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id uuid NOT NULL REFERENCES companies(id),
  code text NOT NULL,
  reporter_id uuid NOT NULL REFERENCES company_members(id),
  group_id uuid REFERENCES groups(id),
  category text NOT NULL CHECK (category IN ('equipment','software','facility','supplies','process','other')),
  subcategory text,
  severity text NOT NULL CHECK (severity IN ('low','medium','high','critical')),
  description text NOT NULL,
  detected_at timestamptz NOT NULL,
  affected_task_id uuid REFERENCES tasks(id),
  asset text,
  location text,
  temp_measure text,
  safety_risk boolean NOT NULL DEFAULT false,
  independent_channel boolean NOT NULL DEFAULT false,
  status text NOT NULL DEFAULT 'submitted' CHECK (status IN ('submitted','manager_review','assigned','acknowledged','in_progress','waiting','resolved_pending','closed','reopened','escalated')),
  stage text NOT NULL DEFAULT 'manager_review' CHECK (stage IN ('manager_review','department_ack','resolution','reporter_confirm','closed')),
  impact_confirmed boolean NOT NULL DEFAULT false,
  manager_member_id uuid REFERENCES company_members(id),
  department_id uuid REFERENCES departments(id),
  assignee_id uuid REFERENCES company_members(id),
  current_holder_id uuid REFERENCES company_members(id),
  stage_due_at timestamptz,
  stage_window_minutes int,
  sla_cycle int NOT NULL DEFAULT 0,
  escalation_level int NOT NULL DEFAULT 0,
  reopen_count int NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  closed_at timestamptz,
  UNIQUE (company_id, code)
);

CREATE TABLE IF NOT EXISTS report_assignments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  report_id uuid NOT NULL REFERENCES workplace_reports(id),
  department_id uuid REFERENCES departments(id),
  assignee_id uuid REFERENCES company_members(id),
  assigned_by uuid NOT NULL REFERENCES company_members(id),
  assigned_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS report_updates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  report_id uuid NOT NULL REFERENCES workplace_reports(id),
  actor_id uuid REFERENCES company_members(id),
  status text NOT NULL,
  comment text,
  new_due_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- Chuyển cấp chung cho báo cáo trở ngại / bản ghi công việc
CREATE TABLE IF NOT EXISTS escalations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id uuid NOT NULL REFERENCES companies(id),
  parent_type text NOT NULL CHECK (parent_type IN ('workplace_report','work_record')),
  parent_id uuid NOT NULL,
  stage text NOT NULL,
  cycle int NOT NULL DEFAULT 0,
  level int NOT NULL,
  from_member_id uuid REFERENCES company_members(id),
  to_member_id uuid NOT NULL REFERENCES company_members(id),
  reason text NOT NULL,
  auto boolean NOT NULL DEFAULT true,
  new_due_at timestamptz,
  status text NOT NULL DEFAULT 'open' CHECK (status IN ('open','resolved')),
  resolution text,
  resolved_by uuid REFERENCES company_members(id),
  resolved_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (parent_type, parent_id, stage, cycle, level)
);

CREATE TABLE IF NOT EXISTS performance_configs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id uuid NOT NULL REFERENCES companies(id),
  version int NOT NULL,
  config jsonb NOT NULL,
  effective_from timestamptz NOT NULL DEFAULT now(),
  created_by uuid REFERENCES company_members(id),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (company_id, version)
);

CREATE TABLE IF NOT EXISTS performance_reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id uuid NOT NULL REFERENCES companies(id),
  period_type text NOT NULL CHECK (period_type IN ('month','quarter','year')),
  period_start date NOT NULL,
  period_end date NOT NULL,
  scope_type text NOT NULL CHECK (scope_type IN ('company','group','member')),
  scope_id uuid,
  formula_version int NOT NULL,
  snapshot jsonb NOT NULL,
  created_by uuid NOT NULL REFERENCES company_members(id),
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id uuid NOT NULL REFERENCES companies(id),
  member_id uuid NOT NULL REFERENCES company_members(id),
  type text NOT NULL,
  title text NOT NULL,
  body text,
  reference_type text,
  reference_id uuid,
  dedupe_key text,
  push_status text NOT NULL DEFAULT 'skipped',
  read_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS notifications_dedupe ON notifications(member_id, dedupe_key) WHERE dedupe_key IS NOT NULL;
CREATE INDEX IF NOT EXISTS notifications_member ON notifications(member_id, created_at DESC);

CREATE TABLE IF NOT EXISTS audit_logs (
  id bigserial PRIMARY KEY,
  company_id uuid NOT NULL REFERENCES companies(id),
  entity_type text NOT NULL,
  entity_id uuid NOT NULL,
  actor_id uuid REFERENCES company_members(id),
  action text NOT NULL,
  old_value jsonb,
  new_value jsonb,
  reason text,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS audit_entity ON audit_logs(entity_type, entity_id);

CREATE TABLE IF NOT EXISTS idempotency_keys (
  member_id uuid NOT NULL,
  key text NOT NULL,
  route text NOT NULL,
  status_code int,
  response jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (member_id, key, route)
);

-- Bảo vệ bất biến cho lịch sử quyết định / audit
CREATE OR REPLACE FUNCTION forbid_mutation() RETURNS trigger AS $$
BEGIN
  RAISE EXCEPTION 'IMMUTABLE_RECORD: % không được sửa/xóa', TG_TABLE_NAME;
END; $$ LANGUAGE plpgsql;

DO $$
DECLARE t text;
BEGIN
  FOREACH t IN ARRAY ARRAY['work_record_reviews','work_record_disputes','audit_logs','performance_reports','report_updates'] LOOP
    EXECUTE format('DROP TRIGGER IF EXISTS %I_immutable ON %I', t, t);
    EXECUTE format('CREATE TRIGGER %I_immutable BEFORE UPDATE OR DELETE ON %I FOR EACH ROW EXECUTE FUNCTION forbid_mutation()', t, t);
  END LOOP;
END $$;

-- =====================================================================
-- v2: Việc Đến — đăng nhập SĐT, hồ sơ, gói doanh nghiệp, lịch, ghim việc,
--     khai việc nhanh, nghỉ phép. Các lệnh idempotent để nâng cấp DB cũ.
-- =====================================================================
ALTER TABLE users ALTER COLUMN email DROP NOT NULL;
ALTER TABLE users ALTER COLUMN password_hash DROP NOT NULL;
ALTER TABLE users ADD COLUMN IF NOT EXISTS is_platform_admin boolean NOT NULL DEFAULT false;
ALTER TABLE users DROP CONSTRAINT IF EXISTS users_status_check;
ALTER TABLE users ADD CONSTRAINT users_status_check CHECK (status IN ('active','locked','invited'));
CREATE UNIQUE INDEX IF NOT EXISTS users_phone_unique ON users(phone) WHERE phone IS NOT NULL;

ALTER TABLE company_members DROP CONSTRAINT IF EXISTS company_members_role_check;
ALTER TABLE company_members ADD CONSTRAINT company_members_role_check CHECK (role IN ('owner','admin','manager','employee','handler','reviewer','hr'));
ALTER TABLE company_members DROP CONSTRAINT IF EXISTS company_members_status_check;
ALTER TABLE company_members ADD CONSTRAINT company_members_status_check CHECK (status IN ('active','inactive','pending_hr','rejected'));
ALTER TABLE company_members ADD COLUMN IF NOT EXISTS added_by uuid REFERENCES company_members(id);
ALTER TABLE company_members ADD COLUMN IF NOT EXISTS hr_reviewed_by uuid REFERENCES company_members(id);
ALTER TABLE company_members ADD COLUMN IF NOT EXISTS hr_reviewed_at timestamptz;
ALTER TABLE company_members ADD COLUMN IF NOT EXISTS hr_note text;
ALTER TABLE company_members ADD COLUMN IF NOT EXISTS left_at timestamptz;

ALTER TABLE companies ADD COLUMN IF NOT EXISTS plan text;
ALTER TABLE companies ADD COLUMN IF NOT EXISTS member_limit int;
ALTER TABLE companies ADD COLUMN IF NOT EXISTS contact_email text;
ALTER TABLE companies ADD COLUMN IF NOT EXISTS plan_expires_at timestamptz;

-- Ảnh đại diện (ảnh quét gương mặt), lưu nhỏ gọn trong DB
CREATE TABLE IF NOT EXISTS user_avatars (
  user_id uuid PRIMARY KEY REFERENCES users(id),
  mime text NOT NULL,
  data bytea NOT NULL,
  captured_live boolean NOT NULL DEFAULT false,
  face_detected boolean,
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- Hồ sơ xin việc
CREATE TABLE IF NOT EXISTS user_profiles (
  user_id uuid PRIMARY KEY REFERENCES users(id),
  dob date,
  gender text,
  address text,
  contact_email text,
  id_number text,
  education text,
  desired_position text,
  summary text,
  years_experience numeric,
  field text,
  skills text,
  certificates text,
  share_auto_history boolean NOT NULL DEFAULT false,
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS user_work_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id),
  company_name text NOT NULL,
  position text,
  start_date date,
  end_date date,
  description text,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- Gói doanh nghiệp
CREATE TABLE IF NOT EXISTS subscriptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id),
  company_id uuid REFERENCES companies(id),
  plan text NOT NULL CHECK (plan IN ('small','medium','large')),
  company_name text NOT NULL,
  contact_email text NOT NULL,
  member_limit int NOT NULL,
  price_vnd bigint NOT NULL,
  months int NOT NULL DEFAULT 12,
  status text NOT NULL DEFAULT 'pending_payment' CHECK (status IN ('pending_payment','active','rejected','cancelled')),
  payment_ref text,
  activated_by uuid REFERENCES users(id),
  activated_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- Lịch & ghim việc gấp
ALTER TABLE tasks ADD COLUMN IF NOT EXISTS plan_date date;
ALTER TABLE tasks ADD COLUMN IF NOT EXISTS original_plan_date date;
ALTER TABLE tasks ADD COLUMN IF NOT EXISTS carry_count int NOT NULL DEFAULT 0;
ALTER TABLE tasks ADD COLUMN IF NOT EXISTS pinned boolean NOT NULL DEFAULT false;
ALTER TABLE tasks ADD COLUMN IF NOT EXISTS pinned_at timestamptz;
ALTER TABLE tasks ADD COLUMN IF NOT EXISTS pinned_by uuid REFERENCES company_members(id);
ALTER TABLE tasks ADD COLUMN IF NOT EXISTS urgent boolean NOT NULL DEFAULT false;
ALTER TABLE tasks ADD COLUMN IF NOT EXISTS source_claim_id uuid;
UPDATE tasks SET plan_date = (created_at AT TIME ZONE 'Asia/Ho_Chi_Minh')::date WHERE plan_date IS NULL;
CREATE INDEX IF NOT EXISTS tasks_plan_date ON tasks(company_id, plan_date);

-- Khai việc nhanh qua gọi điện / tin nhắn
CREATE TABLE IF NOT EXISTS quick_claims (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id uuid NOT NULL REFERENCES companies(id),
  group_id uuid REFERENCES groups(id),
  creator_id uuid NOT NULL REFERENCES company_members(id),
  counterpart_id uuid NOT NULL REFERENCES company_members(id),
  manager_id uuid NOT NULL REFERENCES company_members(id),
  assignee_id uuid NOT NULL REFERENCES company_members(id),
  channel text NOT NULL CHECK (channel IN ('call','sms','chat','zalo','direct')),
  occurred_at timestamptz NOT NULL,
  title text NOT NULL,
  description text,
  due_at timestamptz,
  estimated_hours numeric,
  already_done boolean NOT NULL DEFAULT false,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','confirmed','rejected','cancelled')),
  response_reason text,
  responded_at timestamptz,
  task_id uuid REFERENCES tasks(id),
  work_record_id uuid REFERENCES employee_work_records(id),
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS quick_claims_pair ON quick_claims(company_id, manager_id, assignee_id, status);

-- Nghỉ phép
CREATE TABLE IF NOT EXISTS leave_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id uuid NOT NULL REFERENCES companies(id),
  code text NOT NULL,
  member_id uuid NOT NULL REFERENCES company_members(id),
  leave_type text NOT NULL CHECK (leave_type IN ('sudden','hourly','shift','day')),
  start_at timestamptz NOT NULL,
  end_at timestamptz NOT NULL,
  shift text,
  minutes int NOT NULL,
  reason text NOT NULL,
  handover text,
  notice_minutes int NOT NULL,
  late_notice boolean NOT NULL DEFAULT false,
  approver_id uuid REFERENCES company_members(id),
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','approved','rejected','cancelled')),
  decision_reason text,
  decided_by uuid REFERENCES company_members(id),
  decided_at timestamptz,
  pdf_file_id uuid REFERENCES files(id),
  hr_notified_at timestamptz,
  hr_email_status text,
  created_at timestamptz NOT NULL DEFAULT now(),
  CHECK (end_at > start_at)
);
CREATE INDEX IF NOT EXISTS leave_member_time ON leave_requests(member_id, start_at);
ALTER TABLE companies ADD COLUMN IF NOT EXISTS leave_seq int NOT NULL DEFAULT 0;
