import { Pool, PoolClient, types } from 'pg';

// numeric -> number, bigint -> number
types.setTypeParser(1700, (v) => (v === null ? null : parseFloat(v)));
types.setTypeParser(20, (v) => (v === null ? null : parseInt(v, 10)));
// date (không có giờ) giữ nguyên dạng chuỗi YYYY-MM-DD
types.setTypeParser(1082, (v) => v);

export type Queryable = Pool | PoolClient;

let pool: Pool | null = null;

export function getPool(): Pool {
  if (!pool) {
    pool = new Pool({ connectionString: process.env.DATABASE_URL || 'postgresql://app:app@localhost:5432/teamapp', max: 10 });
  }
  return pool;
}

export async function closePool() {
  if (pool) await pool.end();
  pool = null;
}

export async function q<T = any>(sql: string, params: any[] = [], db: Queryable = getPool()): Promise<T[]> {
  const r = await db.query(sql, params);
  return r.rows as T[];
}

export async function q1<T = any>(sql: string, params: any[] = [], db: Queryable = getPool()): Promise<T | null> {
  const rows = await q<T>(sql, params, db);
  return rows[0] ?? null;
}

export async function tx<T>(fn: (c: PoolClient) => Promise<T>): Promise<T> {
  const c = await getPool().connect();
  try {
    await c.query('BEGIN');
    const out = await fn(c);
    await c.query('COMMIT');
    return out;
  } catch (e) {
    await c.query('ROLLBACK');
    throw e;
  } finally {
    c.release();
  }
}
