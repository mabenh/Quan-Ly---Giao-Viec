import 'reflect-metadata';
import { NestFactory } from '@nestjs/core';
import { NestExpressApplication } from '@nestjs/platform-express';
import { existsSync } from 'fs';
import { join } from 'path';
import { AppModule } from './app.module';
import { migrate } from './db/migrate';

export async function createApp() {
  const app = await NestFactory.create<NestExpressApplication>(AppModule, { logger: ['error', 'warn', 'log'] });
  app.setGlobalPrefix('api/v1');
  app.enableCors({ origin: process.env.CORS_ORIGIN?.split(',') || true });
  app.useBodyParser('json', { limit: '2mb' });
  // Phục vụ client PWA đã build (nếu có) ở cùng origin
  const web = process.env.WEB_DIR || join(__dirname, '..', '..', 'mobile-web', 'dist');
  if (existsSync(web)) {
    app.useStaticAssets(web);
    const index = join(web, 'index.html');
    app.getHttpAdapter().getInstance().get(/^(?!\/api\/).*/, (_req: any, res: any) => res.sendFile(index));
  }
  return app;
}

async function bootstrap() {
  if (process.env.AUTO_MIGRATE !== 'false') await migrate();
  const app = await createApp();
  const port = Number(process.env.PORT || 3000);
  await app.listen(port, '0.0.0.0');
  console.log(`API: http://localhost:${port}/api/v1`);
}

if (require.main === module) bootstrap();
