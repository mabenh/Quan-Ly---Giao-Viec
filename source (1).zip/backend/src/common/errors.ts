import { HttpException } from '@nestjs/common';

/** Lỗi nghiệp vụ có mã ổn định để mobile hiển thị thông điệp dễ hiểu (mục 13.1). */
export class AppError extends HttpException {
  constructor(public code: string, message: string, status = 400, public details?: any) {
    super({ error: { code, message, details } }, status);
  }
}

export const Errors = {
  unauthorized: (m = 'Chưa đăng nhập hoặc phiên đã hết hạn') => new AppError('UNAUTHORIZED', m, 401),
  forbidden: (m = 'Bạn không có quyền thực hiện thao tác này') => new AppError('FORBIDDEN', m, 403),
  notFound: (what = 'Bản ghi') => new AppError('NOT_FOUND', `${what} không tồn tại hoặc bạn không có quyền xem`, 404),
  invalidState: (m: string) => new AppError('INVALID_STATE', m, 409),
  validation: (m: string, details?: any) => new AppError('VALIDATION_ERROR', m, 422, details),
  reasonRequired: (m = 'Thao tác này bắt buộc phải có lý do') => new AppError('REASON_REQUIRED', m, 422),
};
