import { Queryable, q, q1, getPool } from '../db/db';
import { Ctx, isAdmin } from './context';
import { Errors } from './errors';
import { CompanySettings, mergeSettings } from './defaults';

export async function getCompany(companyId: string, db: Queryable = getPool()) {
  const c = await q1(`SELECT * FROM companies WHERE id=$1`, [companyId], db);
  if (!c) throw Errors.notFound('Công ty');
  return { ...c, settings: mergeSettings(c.settings) as CompanySettings };
}

export async function getMember(ctx: Ctx, memberId: string, db: Queryable = getPool()) {
  const m = await q1(
    `SELECT cm.*, u.name, u.email FROM company_members cm JOIN users u ON u.id=cm.user_id
      WHERE cm.id=$1 AND cm.company_id=$2`, [memberId, ctx.companyId], db);
  if (!m) throw Errors.notFound('Thành viên');
  return m;
}

export async function getGroup(ctx: Ctx, groupId: string, db: Queryable = getPool()) {
  const g = await q1(`SELECT * FROM groups WHERE id=$1 AND company_id=$2 AND deleted_at IS NULL`, [groupId, ctx.companyId], db);
  if (!g) throw Errors.notFound('Nhóm');
  return g;
}

export async function memberGroupIds(memberId: string, db: Queryable = getPool()): Promise<string[]> {
  const rows = await q(
    `SELECT g.id FROM groups g LEFT JOIN group_members gm ON gm.group_id=g.id AND gm.company_member_id=$1
      WHERE g.deleted_at IS NULL AND (gm.id IS NOT NULL OR g.manager_member_id=$1)`, [memberId], db);
  return rows.map((r) => r.id);
}

export async function managedGroupIds(memberId: string, db: Queryable = getPool()): Promise<string[]> {
  const rows = await q(`SELECT id FROM groups WHERE manager_member_id=$1 AND deleted_at IS NULL`, [memberId], db);
  return rows.map((r) => r.id);
}

/** Quản lý nhóm hoặc Admin/Owner. */
export async function canManageGroup(ctx: Ctx, groupId: string, db: Queryable = getPool()) {
  if (isAdmin(ctx)) return true;
  const g = await q1(`SELECT manager_member_id FROM groups WHERE id=$1 AND company_id=$2`, [groupId, ctx.companyId], db);
  return !!g && g.manager_member_id === ctx.memberId;
}

/** Danh sách cấp trên theo tuyến: supervisor -> supervisor ... -> Admin/Owner (D07), chống vòng lặp. */
export async function escalationChain(companyId: string, fromMemberId: string | null, db: Queryable = getPool()): Promise<string[]> {
  const chain: string[] = [];
  const seen = new Set<string>(fromMemberId ? [fromMemberId] : []);
  let cur = fromMemberId;
  for (let i = 0; i < 10 && cur; i++) {
    const m = await q1(`SELECT supervisor_member_id FROM company_members WHERE id=$1 AND company_id=$2`, [cur, companyId], db);
    const sup = m?.supervisor_member_id;
    if (!sup || seen.has(sup)) break;
    const active = await q1(`SELECT id FROM company_members WHERE id=$1 AND status='active'`, [sup], db);
    if (active) chain.push(sup);
    seen.add(sup);
    cur = sup;
  }
  const tops = await q(
    `SELECT id FROM company_members WHERE company_id=$1 AND status='active' AND role IN ('admin','owner')
      ORDER BY CASE role WHEN 'admin' THEN 0 ELSE 1 END, joined_at`, [companyId], db);
  for (const t of tops) if (!seen.has(t.id) && !chain.includes(t.id)) chain.push(t.id);
  return chain;
}

/** Cấp trên trực tiếp để xử lý khi người được giao là chính mình hoặc không có. */
export async function companyAdmins(companyId: string, db: Queryable = getPool()): Promise<string[]> {
  const rows = await q(`SELECT id FROM company_members WHERE company_id=$1 AND status='active' AND role IN ('owner','admin')`, [companyId], db);
  return rows.map((r) => r.id);
}

export function assertCompany(row: any, ctx: Ctx, what = 'Bản ghi') {
  if (!row || row.company_id !== ctx.companyId) throw Errors.notFound(what);
}
