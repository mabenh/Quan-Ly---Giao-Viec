import { Errors } from './errors';

/** Chuẩn hóa SĐT Việt Nam về dạng 0xxxxxxxxx. */
export function normalizePhone(input: string): string {
  let s = (input || '').replace(/[\s.\-()]/g, '');
  if (s.startsWith('+84')) s = '0' + s.slice(3);
  else if (/^84\d{9,10}$/.test(s)) s = '0' + s.slice(2);
  if (!/^0\d{9,10}$/.test(s)) throw Errors.validation('Số điện thoại không hợp lệ (ví dụ 0912345678)');
  return s;
}

export const isPhoneLike = (s: string) => /^[+\d][\d\s.\-()]{8,}$/.test((s || '').trim());
