import { createParamDecorator, ExecutionContext } from '@nestjs/common';

export type Role = 'owner' | 'admin' | 'manager' | 'employee' | 'handler' | 'reviewer' | 'hr';

export interface Ctx {
  userId: string;
  memberId: string;
  companyId: string;
  role: Role;
  name: string;
  isPlatformAdmin?: boolean;
}

export const CurrentCtx = createParamDecorator((_d: unknown, ec: ExecutionContext): Ctx => {
  return ec.switchToHttp().getRequest().ctx;
});

export const isAdmin = (ctx: Ctx) => ctx.role === 'owner' || ctx.role === 'admin';
/** Người có quyền nhân sự: duyệt thành viên, nhận đơn nghỉ, xem hồ sơ. */
export const isHR = (ctx: Ctx) => isAdmin(ctx) || ctx.role === 'hr';
export const isManagerial = (ctx: Ctx) => isAdmin(ctx) || ctx.role === 'manager' || ctx.role === 'reviewer';
