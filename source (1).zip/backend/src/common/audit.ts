import { Queryable, q } from '../db/db';
import { Ctx } from './context';

export async function audit(
  db: Queryable,
  ctx: Pick<Ctx, 'companyId' | 'memberId'> | { companyId: string; memberId: string | null },
  entityType: string,
  entityId: string,
  action: string,
  oldValue?: any,
  newValue?: any,
  reason?: string | null,
) {
  await q(
    `INSERT INTO audit_logs(company_id, entity_type, entity_id, actor_id, action, old_value, new_value, reason)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8)`,
    [ctx.companyId, entityType, entityId, ctx.memberId, action,
     oldValue === undefined ? null : JSON.stringify(oldValue),
     newValue === undefined ? null : JSON.stringify(newValue), reason ?? null],
    db,
  );
}
