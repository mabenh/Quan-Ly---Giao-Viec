import { CanActivate, ExecutionContext, Injectable, SetMetadata } from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import * as jwt from 'jsonwebtoken';
import { q1 } from '../db/db';
import { Errors } from './errors';
import { Role } from './context';

export const PUBLIC = 'isPublic';
export const Public = () => SetMetadata(PUBLIC, true);
export const ROLES = 'roles';
export const Roles = (...roles: Role[]) => SetMetadata(ROLES, roles);

/** Cho phép tài khoản cá nhân chưa thuộc doanh nghiệp (ctx.memberId/companyId = null). */
export const NO_COMPANY = 'allowNoCompany';
export const AllowNoCompany = () => SetMetadata(NO_COMPANY, true);

export const jwtSecret = () => process.env.JWT_SECRET || 'dev-secret-change-me';

@Injectable()
export class AuthGuard implements CanActivate {
  constructor(private reflector: Reflector) {}

  async canActivate(ec: ExecutionContext): Promise<boolean> {
    const isPublic = this.reflector.getAllAndOverride<boolean>(PUBLIC, [ec.getHandler(), ec.getClass()]);
    if (isPublic) return true;
    const req = ec.switchToHttp().getRequest();
    const h: string = req.headers.authorization || '';
    const token = h.startsWith('Bearer ') ? h.slice(7) : (req.query?.access_token as string);
    if (!token) throw Errors.unauthorized();
    let payload: any;
    try {
      payload = jwt.verify(token, jwtSecret());
    } catch {
      throw Errors.unauthorized();
    }
    const allowNoCompany = this.reflector.getAllAndOverride<boolean>(NO_COMPANY, [ec.getHandler(), ec.getClass()]);
    const u = await q1(`SELECT id, name, status, is_platform_admin FROM users WHERE id=$1`, [payload.sub]);
    if (!u || u.status !== 'active') throw Errors.unauthorized('Tài khoản đã bị khóa');
    // Kiểm tra lại membership mỗi request để khóa tài khoản/thu hồi quyền có hiệu lực ngay.
    const m = payload.mid ? await q1(
      `SELECT cm.id, cm.company_id, cm.role, cm.status FROM company_members cm WHERE cm.id = $1 AND cm.user_id = $2`,
      [payload.mid, payload.sub],
    ) : null;
    if (!m || m.status !== 'active') {
      if (!allowNoCompany) throw Errors.unauthorized(payload.mid ? 'Tài khoản không còn thuộc công ty' : 'Bạn chưa thuộc doanh nghiệp nào');
      req.ctx = { userId: u.id, memberId: null, companyId: null, role: null, name: u.name, isPlatformAdmin: u.is_platform_admin };
      return true;
    }
    req.ctx = { userId: u.id, memberId: m.id, companyId: m.company_id, role: m.role, name: u.name, isPlatformAdmin: u.is_platform_admin };
    const roles = this.reflector.getAllAndOverride<Role[]>(ROLES, [ec.getHandler(), ec.getClass()]);
    if (roles && !roles.includes(m.role)) throw Errors.forbidden();
    return true;
  }
}
