import { Queryable, q } from '../db/db';

export interface NotifyInput {
  companyId: string;
  memberIds: (string | null | undefined)[];
  type: string;
  title: string;
  body?: string;
  refType?: string;
  refId?: string;
  /** Khóa chống gửi trùng (theo người nhận) */
  dedupeKey?: string;
  excludeMemberId?: string;
}

/**
 * Tạo bản ghi thông báo (in-app). Push FCM: nếu cấu hình FCM_SERVER_KEY thì đánh dấu 'queued'
 * để worker gửi; MVP mặc định 'skipped'. Lịch sử gửi lưu ở cột push_status.
 */
export async function notify(db: Queryable, n: NotifyInput): Promise<number> {
  const ids = [...new Set(n.memberIds.filter((x): x is string => !!x && x !== n.excludeMemberId))];
  let count = 0;
  for (const mid of ids) {
    const r = await q(
      `INSERT INTO notifications(company_id, member_id, type, title, body, reference_type, reference_id, dedupe_key, push_status)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)
       ON CONFLICT (member_id, dedupe_key) WHERE dedupe_key IS NOT NULL DO NOTHING RETURNING id`,
      [n.companyId, mid, n.type, n.title, n.body ?? null, n.refType ?? null, n.refId ?? null, n.dedupeKey ?? null,
       process.env.FCM_SERVER_KEY ? 'queued' : 'skipped'],
      db,
    );
    count += r.length;
  }
  return count;
}
