import { z, ZodTypeAny } from 'zod';
import { Errors } from './errors';

export function parse<T extends ZodTypeAny>(schema: T, data: unknown): z.infer<T> {
  const r = schema.safeParse(data ?? {});
  if (!r.success) {
    const issues = r.error.issues.map((i) => ({ field: i.path.join('.'), message: i.message }));
    throw Errors.validation('Dữ liệu không hợp lệ: ' + issues.map((i) => `${i.field} (${i.message})`).join('; '), issues);
  }
  return r.data;
}

export const zReason = z.string().trim().min(5, 'Lý do cần tối thiểu 5 ký tự');
export const zUuid = z.string().uuid();
export const zDate = z.coerce.date();
export { z };
