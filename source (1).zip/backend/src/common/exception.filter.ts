import { ArgumentsHost, Catch, ExceptionFilter, HttpException, Logger } from '@nestjs/common';

@Catch()
export class AllExceptionsFilter implements ExceptionFilter {
  private log = new Logger('Error');
  catch(err: any, host: ArgumentsHost) {
    const res = host.switchToHttp().getResponse();
    if (err instanceof HttpException) {
      const body: any = err.getResponse();
      if (body?.error?.code) return res.status(err.getStatus()).json(body);
      const msg = typeof body === 'string' ? body : body?.message;
      const status = err.getStatus();
      const code = status === 404 ? 'NOT_FOUND' : status === 413 ? 'FILE_TOO_LARGE' : 'HTTP_' + status;
      return res.status(status).json({ error: { code, message: Array.isArray(msg) ? msg.join('; ') : msg || 'Lỗi' } });
    }
    if (typeof err?.message === 'string' && err.message.includes('IMMUTABLE_RECORD')) {
      return res.status(409).json({ error: { code: 'IMMUTABLE_RECORD', message: 'Bản ghi lịch sử/quyết định không được sửa hoặc xóa' } });
    }
    if (err?.code === '22P02') return res.status(404).json({ error: { code: 'NOT_FOUND', message: 'Mã định danh không hợp lệ' } });
    if (err?.code === '23505') return res.status(409).json({ error: { code: 'DUPLICATE', message: 'Dữ liệu bị trùng' } });
    this.log.error(err?.stack || err);
    return res.status(500).json({ error: { code: 'INTERNAL_ERROR', message: 'Đã có lỗi hệ thống, vui lòng thử lại' } });
  }
}
