import { DateTime } from 'luxon';
import { WorkCalendar } from './defaults';

function hm(s: string) {
  const [h, m] = s.split(':').map(Number);
  return { hour: h, minute: m };
}

function daySegments(day: DateTime, cal: WorkCalendar): [DateTime, DateTime][] {
  if (!cal.workdays.includes(day.weekday)) return [];
  if (cal.holidays.includes(day.toISODate()!)) return [];
  const s = day.set({ ...hm(cal.start), second: 0, millisecond: 0 });
  const e = day.set({ ...hm(cal.end), second: 0, millisecond: 0 });
  if (cal.breakStart && cal.breakEnd) {
    const bs = day.set({ ...hm(cal.breakStart), second: 0, millisecond: 0 });
    const be = day.set({ ...hm(cal.breakEnd), second: 0, millisecond: 0 });
    return [[s, bs], [be, e]].filter(([a, b]) => b > a) as [DateTime, DateTime][];
  }
  return [[s, e]];
}

/** Cộng số phút làm việc theo lịch công ty (bỏ qua ngoài giờ, nghỉ trưa, cuối tuần, ngày lễ). */
export function addWorkingMinutes(start: Date, minutes: number, cal: WorkCalendar, tz: string): Date {
  let cursor = DateTime.fromJSDate(start, { zone: tz });
  let remaining = Math.max(0, minutes);
  for (let i = 0; i < 3660; i++) {
    const day = cursor.startOf('day');
    for (const [a, b] of daySegments(day, cal)) {
      if (cursor >= b) continue;
      const from = cursor > a ? cursor : a;
      const avail = b.diff(from, 'minutes').minutes;
      if (remaining <= avail) {
        if (remaining === 0 && i === 0 && cursor < a) return a.toJSDate();
        return from.plus({ minutes: remaining }).toJSDate();
      }
      remaining -= avail;
    }
    cursor = day.plus({ days: 1 });
  }
  throw new Error('Không tìm thấy ngày làm việc trong lịch (kiểm tra cấu hình lịch làm việc)');
}

/** Số phút làm việc giữa hai thời điểm. */
export function workingMinutesBetween(a: Date, b: Date, cal: WorkCalendar, tz: string): number {
  if (b <= a) return 0;
  let cursor = DateTime.fromJSDate(a, { zone: tz });
  const end = DateTime.fromJSDate(b, { zone: tz });
  let total = 0;
  for (let i = 0; i < 3660 && cursor < end; i++) {
    const day = cursor.startOf('day');
    for (const [s, e] of daySegments(day, cal)) {
      const from = cursor > s ? cursor : s;
      const to = end < e ? end : e;
      if (to > from) total += to.diff(from, 'minutes').minutes;
    }
    cursor = day.plus({ days: 1 });
  }
  return Math.round(total);
}

export function isWorkingTime(t: Date, cal: WorkCalendar, tz: string): boolean {
  const dt = DateTime.fromJSDate(t, { zone: tz });
  return daySegments(dt.startOf('day'), cal).some(([a, b]) => dt >= a && dt < b);
}

/** Tính hạn SLA: mức nghiêm trọng dùng thời gian thực 24/7 (không chờ giờ làm việc). */
export function slaDue(start: Date, minutes: number, severity: string | null, cal: WorkCalendar, tz: string): Date {
  if (severity === 'critical') return new Date(start.getTime() + minutes * 60000);
  return addWorkingMinutes(start, minutes, cal, tz);
}
