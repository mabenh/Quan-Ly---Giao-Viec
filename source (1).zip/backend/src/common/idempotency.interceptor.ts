import { CallHandler, ExecutionContext, Injectable, NestInterceptor } from '@nestjs/common';
import { Observable, from, of, switchMap, tap } from 'rxjs';
import { q, q1 } from '../db/db';
import { AppError } from './errors';

/**
 * Header `Idempotency-Key` cho các POST: retry khi mất mạng không tạo bản ghi trùng (mục 16.1).
 * Lần đầu: giữ chỗ khóa rồi lưu phản hồi; lần sau cùng khóa: trả lại phản hồi đã lưu.
 */
@Injectable()
export class IdempotencyInterceptor implements NestInterceptor {
  intercept(ec: ExecutionContext, next: CallHandler): Observable<any> {
    const req = ec.switchToHttp().getRequest();
    const key = req.headers['idempotency-key'];
    if (req.method !== 'POST' || !key || !req.ctx) return next.handle();
    const route = req.route?.path || req.path;
    const memberId = req.ctx.memberId || req.ctx.userId; // tài khoản chưa thuộc doanh nghiệp dùng userId
    return from(this.reserve(memberId, String(key).slice(0, 200), route)).pipe(
      switchMap((saved) => {
        if (saved) {
          if (saved.response === null) throw new AppError('REQUEST_IN_PROGRESS', 'Yêu cầu đang được xử lý, vui lòng thử lại sau giây lát', 409);
          ec.switchToHttp().getResponse().status(saved.status_code || 200);
          return of(saved.response);
        }
        return next.handle().pipe(
          tap({
            next: (body) => { q(`UPDATE idempotency_keys SET response=$4, status_code=201 WHERE member_id=$1 AND key=$2 AND route=$3`, [memberId, key, route, JSON.stringify(body ?? null)]).catch(() => {}); },
            error: () => { q(`DELETE FROM idempotency_keys WHERE member_id=$1 AND key=$2 AND route=$3`, [memberId, key, route]).catch(() => {}); },
          }),
        );
      }),
    );
  }

  private async reserve(memberId: string, key: string, route: string) {
    const ins = await q(`INSERT INTO idempotency_keys(member_id, key, route) VALUES ($1,$2,$3) ON CONFLICT DO NOTHING RETURNING key`, [memberId, key, route]);
    if (ins.length) return null;
    return q1(`SELECT response, status_code FROM idempotency_keys WHERE member_id=$1 AND key=$2 AND route=$3`, [memberId, key, route]);
  }
}
