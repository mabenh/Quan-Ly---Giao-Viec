import { PoolClient } from 'pg';
import { q, q1 } from '../db/db';
import { escalationChain } from '../common/access';
import { notify } from '../common/notify';
import { audit } from '../common/audit';

export interface EscalateInput {
  companyId: string;
  parentType: 'workplace_report' | 'work_record';
  parentId: string;
  stage: string;
  cycle: number;
  /** Người đang giữ việc ở cấp hiện tại (bị chuyển cấp) */
  fromMemberId: string | null;
  /** Gốc tuyến: người giữ việc ban đầu của giai đoạn — tuyến cấp trên tính từ người này */
  baseMemberId: string | null;
  level: number; // cấp chuyển mới (1 = cấp trên đầu tiên)
  reason: string;
  newDueAt: Date | null;
  /** Không chuyển cho những người này (người báo cáo, người bị khiếu nại...) */
  exclude?: string[];
  actorId?: string | null; // null = hệ thống
  title: string;
  notifyAlso?: string[];
}

/**
 * Tạo bản ghi chuyển cấp idempotent (unique parent/stage/cycle/level) — không tạo bản chuyển cấp trùng,
 * chống vòng lặp (bỏ qua người đã có trong tuyến), lưu người chuyển, người nhận, thời điểm, lý do, SLA mới.
 * Trả về người nhận hoặc null nếu đã hết tuyến hoặc đã tồn tại.
 */
export async function escalate(c: PoolClient, e: EscalateInput): Promise<{ toMemberId: string; id: string } | null> {
  const exclude = new Set([...(e.exclude || []), ...(e.fromMemberId ? [e.fromMemberId] : [])]);
  const chain = (await escalationChain(e.companyId, e.baseMemberId, c)).filter((m) => !exclude.has(m));
  // các người nhận ở cấp trước của cùng chu kỳ cũng bị loại để tránh vòng lặp
  const prev = await q(`SELECT to_member_id FROM escalations WHERE parent_type=$1 AND parent_id=$2 AND stage=$3 AND cycle=$4`,
    [e.parentType, e.parentId, e.stage, e.cycle], c);
  const used = new Set(prev.map((p) => p.to_member_id));
  const target = chain.find((m) => !used.has(m));
  if (!target) return null;
  const row = await q1(
    `INSERT INTO escalations(company_id, parent_type, parent_id, stage, cycle, level, from_member_id, to_member_id, reason, auto, new_due_at)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)
     ON CONFLICT (parent_type, parent_id, stage, cycle, level) DO NOTHING RETURNING id`,
    [e.companyId, e.parentType, e.parentId, e.stage, e.cycle, e.level, e.fromMemberId, target, e.reason, !e.actorId, e.newDueAt], c);
  if (!row) return null;
  await audit(c, { companyId: e.companyId, memberId: e.actorId ?? null }, e.parentType, e.parentId, 'escalated', null,
    { stage: e.stage, level: e.level, from: e.fromMemberId, to: target, new_due_at: e.newDueAt }, e.reason);
  await notify(c, {
    companyId: e.companyId, memberIds: [target], type: 'escalation.received', title: e.title, body: e.reason,
    refType: e.parentType, refId: e.parentId, dedupeKey: `esc-${row.id}`,
  });
  if (e.notifyAlso?.length) {
    await notify(c, {
      companyId: e.companyId, memberIds: e.notifyAlso, type: 'escalation.notice', title: `Đã chuyển cấp: ${e.title}`, body: e.reason,
      refType: e.parentType, refId: e.parentId, dedupeKey: `esc-${row.id}-cc`,
    });
  }
  return { toMemberId: target, id: row.id };
}

export async function openEscalationTargets(parentType: string, parentId: string, db: any): Promise<string[]> {
  const rows = await q(`SELECT DISTINCT to_member_id FROM escalations WHERE parent_type=$1 AND parent_id=$2 AND status='open'`, [parentType, parentId], db);
  return rows.map((r) => r.to_member_id);
}

export async function resolveOpenEscalations(c: PoolClient, parentType: string, parentId: string, memberId: string | null, resolution: string, stage?: string) {
  await q(`UPDATE escalations SET status='resolved', resolution=$4, resolved_by=$3, resolved_at=now()
            WHERE parent_type=$1 AND parent_id=$2 AND status='open' AND ($5::text IS NULL OR stage=$5)`,
    [parentType, parentId, memberId, resolution, stage ?? null], c);
}
