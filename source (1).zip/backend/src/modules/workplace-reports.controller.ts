import { Body, Controller, Get, Param, Post, Query } from '@nestjs/common';
import { PoolClient } from 'pg';
import { getPool, q, q1, tx } from '../db/db';
import { CurrentCtx, Ctx, isAdmin } from '../common/context';
import { AppError, Errors } from '../common/errors';
import { parse, z } from '../common/validate';
import { companyAdmins, escalationChain, getCompany, getGroup, getMember } from '../common/access';
import { audit } from '../common/audit';
import { notify } from '../common/notify';
import { slaDue } from '../common/calendar';
import { escalate, openEscalationTargets, resolveOpenEscalations } from './escalation';

export const SAFETY_NOTICE = 'Sự cố có nguy cơ gây thương tích, cháy nổ hoặc nguy hiểm: kích hoạt ngay quy trình an toàn ngoài ứng dụng (gọi bộ phận an toàn/cứu hỏa 114/cấp cứu 115), không chờ SLA.';

const SELECT = `
  SELECT w.*, ru.name AS reporter_name, mu.name AS manager_name, d.name AS department_name, au.name AS assignee_name,
         hu.name AS holder_name, g.name AS group_name, t.title AS affected_task_title,
         (w.stage_due_at IS NOT NULL AND w.stage_due_at < now() AND w.stage NOT IN ('closed','reporter_confirm')) AS is_overdue
    FROM workplace_reports w
    JOIN company_members rcm ON rcm.id=w.reporter_id JOIN users ru ON ru.id=rcm.user_id
    LEFT JOIN company_members mcm ON mcm.id=w.manager_member_id LEFT JOIN users mu ON mu.id=mcm.user_id
    LEFT JOIN departments d ON d.id=w.department_id
    LEFT JOIN company_members acm ON acm.id=w.assignee_id LEFT JOIN users au ON au.id=acm.user_id
    LEFT JOIN company_members hcm ON hcm.id=w.current_holder_id LEFT JOIN users hu ON hu.id=hcm.user_id
    LEFT JOIN groups g ON g.id=w.group_id LEFT JOIN tasks t ON t.id=w.affected_task_id`;

export async function stageDue(c: PoolClient | any, companyId: string, severity: string, kind: 'manager_review_minutes' | 'acknowledge_minutes' | 'resolve_minutes', from = new Date()) {
  const company = await getCompany(companyId, c);
  const sla = await q1(`SELECT * FROM sla_configs WHERE company_id=$1 AND severity=$2`, [companyId, severity], c);
  const minutes = sla?.[kind] ?? 480;
  return { due: slaDue(from, minutes, severity, company.settings.calendar, company.timezone), minutes };
}

@Controller('workplace-reports')
export class WorkplaceReportsController {
  private async load(ctx: Ctx, id: string, db: any = getPool()) {
    const w = await q1(`${SELECT} WHERE w.id=$1 AND w.company_id=$2`, [id, ctx.companyId], db);
    if (!w) throw Errors.notFound('Báo cáo trở ngại');
    return w;
  }

  private async perms(ctx: Ctx, w: any, db: any = getPool()) {
    const esc = await openEscalationTargets('workplace_report', w.id, db);
    const allEsc = (await q(`SELECT DISTINCT to_member_id FROM escalations WHERE parent_type='workplace_report' AND parent_id=$1`, [w.id], db)).map((r) => r.to_member_id);
    const me = await q1(`SELECT department_id, role FROM company_members WHERE id=$1`, [ctx.memberId], db);
    const dept = w.department_id ? await q1(`SELECT head_member_id FROM departments WHERE id=$1`, [w.department_id], db) : null;
    const isDeptHead = !!dept && dept.head_member_id === ctx.memberId;
    const inDept = !!w.department_id && me?.department_id === w.department_id;
    const isEsc = esc.includes(ctx.memberId);
    const admin = isAdmin(ctx);
    const isReporter = w.reporter_id === ctx.memberId;
    let groupMgr = false;
    if (w.group_id && !w.independent_channel) {
      const g = await q1(`SELECT manager_member_id FROM groups WHERE id=$1`, [w.group_id], db);
      groupMgr = g?.manager_member_id === ctx.memberId;
    }
    const canView = admin || isReporter || w.manager_member_id === ctx.memberId || inDept || isDeptHead || w.assignee_id === ctx.memberId || allEsc.includes(ctx.memberId) || groupMgr;
    return {
      canView,
      canManagerAct: (w.stage === 'manager_review') && !isReporter && (w.manager_member_id === ctx.memberId || isEsc || admin),
      canAck: w.stage === 'department_ack' && !isReporter && (isDeptHead || inDept || isEsc || admin),
      canUpdate: w.stage === 'resolution' && (w.assignee_id === ctx.memberId || isDeptHead || isEsc || admin),
      canConfirm: w.stage === 'reporter_confirm' && isReporter,
      canEscalate: w.stage !== 'closed' && (isReporter || w.current_holder_id === ctx.memberId || isEsc || admin),
      canReassign: w.stage !== 'closed' && !isReporter && (isDeptHead || isEsc || admin || w.manager_member_id === ctx.memberId),
    };
  }

  @Get()
  async list(@CurrentCtx() ctx: Ctx, @Query() qs: any) {
    const f = parse(z.object({
      scope: z.enum(['mine', 'handling', 'all']).default('mine'), status: z.string().optional(), severity: z.string().optional(),
      category: z.string().optional(), departmentId: z.string().uuid().optional(), overdue: z.enum(['true', 'false']).optional(),
    }), qs);
    const params: any[] = [ctx.companyId, ctx.memberId];
    const where = ['w.company_id=$1', '$2::uuid IS NOT NULL'];
    const handling = `(w.current_holder_id=$2 OR w.manager_member_id=$2 OR w.assignee_id=$2
        OR EXISTS (SELECT 1 FROM departments dd WHERE dd.id=w.department_id AND dd.head_member_id=$2)
        OR EXISTS (SELECT 1 FROM company_members me WHERE me.id=$2 AND me.department_id=w.department_id)
        OR EXISTS (SELECT 1 FROM escalations e WHERE e.parent_type='workplace_report' AND e.parent_id=w.id AND e.to_member_id=$2))`;
    if (f.scope === 'mine') where.push('w.reporter_id=$2');
    else if (f.scope === 'handling') where.push(handling);
    else if (!isAdmin(ctx)) where.push(`(w.reporter_id=$2 OR ${handling} OR (NOT w.independent_channel AND EXISTS (SELECT 1 FROM groups gg WHERE gg.id=w.group_id AND gg.manager_member_id=$2)))`);
    if (f.status) { params.push(f.status.split(',')); where.push(`w.status = ANY($${params.length}::text[])`); }
    if (f.severity) { params.push(f.severity.split(',')); where.push(`w.severity = ANY($${params.length}::text[])`); }
    if (f.category) { params.push(f.category); where.push(`w.category = $${params.length}`); }
    if (f.departmentId) { params.push(f.departmentId); where.push(`w.department_id = $${params.length}`); }
    if (f.overdue === 'true') where.push(`w.stage_due_at < now() AND w.stage NOT IN ('closed','reporter_confirm')`);
    return q(`${SELECT} WHERE ${where.join(' AND ')}
      ORDER BY (w.stage='closed'), array_position(ARRAY['critical','high','medium','low'], w.severity), w.stage_due_at NULLS LAST LIMIT 500`, params);
  }

  @Post()
  async create(@Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({
      category: z.enum(['equipment', 'software', 'facility', 'supplies', 'process', 'other']), subcategory: z.string().optional(),
      severity: z.enum(['low', 'medium', 'high', 'critical']), description: z.string().trim().min(10, 'Mô tả cần tối thiểu 10 ký tự'),
      detectedAt: z.coerce.date(), groupId: z.string().uuid().optional().nullable(), affectedTaskId: z.string().uuid().optional().nullable(),
      asset: z.string().optional(), location: z.string().optional(), tempMeasure: z.string().optional(),
      safetyRisk: z.boolean().default(false), independentChannel: z.boolean().default(false),
      independentReason: z.string().optional(),
    }), body);
    if (b.groupId) await getGroup(ctx, b.groupId);
    if (b.affectedTaskId) {
      const t = await q1(`SELECT id, group_id FROM tasks WHERE id=$1 AND company_id=$2`, [b.affectedTaskId, ctx.companyId]);
      if (!t) throw Errors.notFound('Nhiệm vụ bị ảnh hưởng');
      b.groupId = b.groupId || t.group_id;
    }
    if (b.independentChannel && (!b.independentReason || b.independentReason.length < 10)) {
      throw Errors.validation('Gửi kênh độc lập cần nêu lý do (quản lý trực tiếp bị phản ánh/xung đột lợi ích)');
    }
    const id = await tx(async (c) => {
      // Xác định quản lý tiếp nhận
      let manager: string | null = null;
      const me = await q1(`SELECT supervisor_member_id FROM company_members WHERE id=$1`, [ctx.memberId], c);
      if (b.independentChannel) {
        const direct = new Set<string>([me?.supervisor_member_id].filter(Boolean) as string[]);
        if (b.groupId) direct.add((await q1(`SELECT manager_member_id FROM groups WHERE id=$1`, [b.groupId], c)).manager_member_id);
        const indep = await q(`SELECT id FROM company_members WHERE company_id=$1 AND status='active' AND role IN ('reviewer','admin','owner') AND id<>$2
                                ORDER BY array_position(ARRAY['reviewer','admin','owner'], role), joined_at`, [ctx.companyId, ctx.memberId], c);
        manager = indep.map((x) => x.id).find((x) => !direct.has(x)) ?? null;
        if (!manager) throw new AppError('NO_INDEPENDENT_CHANNEL', 'Chưa cấu hình kênh/cấp xử lý độc lập', 422);
      } else {
        if (b.groupId) {
          const g = await q1(`SELECT manager_member_id FROM groups WHERE id=$1`, [b.groupId], c);
          if (g.manager_member_id !== ctx.memberId) manager = g.manager_member_id;
        }
        if (!manager) manager = (await escalationChain(ctx.companyId, ctx.memberId, c)).find((x) => x !== ctx.memberId) ?? null;
        if (!manager) throw new AppError('NO_MANAGER', 'Không xác định được quản lý tiếp nhận báo cáo', 422);
      }
      const seq = await q1(`UPDATE companies SET report_seq=report_seq+1 WHERE id=$1 RETURNING report_seq`, [ctx.companyId], c);
      const code = `BC-${String(seq.report_seq).padStart(6, '0')}`;
      const { due, minutes } = await stageDue(c, ctx.companyId, b.severity, 'manager_review_minutes');
      const w = await q1(
        `INSERT INTO workplace_reports(company_id, code, reporter_id, group_id, category, subcategory, severity, description, detected_at, affected_task_id,
           asset, location, temp_measure, safety_risk, independent_channel, manager_member_id, current_holder_id, stage_due_at, stage_window_minutes)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$16,$17,$18) RETURNING id`,
        [ctx.companyId, code, ctx.memberId, b.groupId ?? null, b.category, b.subcategory ?? null, b.severity, b.description, b.detectedAt,
         b.affectedTaskId ?? null, b.asset ?? null, b.location ?? null, b.tempMeasure ?? null, b.safetyRisk, b.independentChannel, manager, due, minutes], c);
      await q(`INSERT INTO report_updates(report_id, actor_id, status, comment, new_due_at) VALUES ($1,$2,'submitted',$3,$4)`,
        [w.id, ctx.memberId, b.independentChannel ? `Gửi kênh độc lập: ${b.independentReason}` : null, due], c);
      await audit(c, ctx, 'workplace_report', w.id, 'report.submitted', null, { code, severity: b.severity, manager, independent: b.independentChannel });
      await notify(c, { companyId: ctx.companyId, memberIds: [manager], type: 'report.submitted',
        title: `[${code}] Báo cáo trở ngại mới (${b.severity})`, body: b.description.slice(0, 160), refType: 'workplace_report', refId: w.id });
      if (b.safetyRisk || b.severity === 'critical') {
        await notify(c, { companyId: ctx.companyId, memberIds: await companyAdmins(ctx.companyId, c), type: 'report.safety',
          title: `⚠ [${code}] Sự cố ${b.safetyRisk ? 'có nguy cơ an toàn' : 'nghiêm trọng'}`, body: SAFETY_NOTICE, refType: 'workplace_report', refId: w.id, dedupeKey: `safety-${w.id}` });
      }
      return w.id;
    });
    return this.detail(id, ctx);
  }

  @Get(':id')
  async detail(@Param('id') id: string, @CurrentCtx() ctx: Ctx) {
    const w = await this.load(ctx, id);
    const p = await this.perms(ctx, w);
    if (!p.canView) throw Errors.notFound('Báo cáo trở ngại');
    const [updates, assignments, escalations, files] = await Promise.all([
      q(`SELECT ru.*, u.name AS actor_name FROM report_updates ru LEFT JOIN company_members cm ON cm.id=ru.actor_id LEFT JOIN users u ON u.id=cm.user_id
          WHERE ru.report_id=$1 ORDER BY ru.created_at`, [id]),
      q(`SELECT ra.*, d.name AS department_name, u.name AS assignee_name, bu.name AS assigned_by_name FROM report_assignments ra
           LEFT JOIN departments d ON d.id=ra.department_id LEFT JOIN company_members cm ON cm.id=ra.assignee_id LEFT JOIN users u ON u.id=cm.user_id
           JOIN company_members b ON b.id=ra.assigned_by JOIN users bu ON bu.id=b.user_id WHERE ra.report_id=$1 ORDER BY ra.assigned_at`, [id]),
      q(`SELECT e.*, fu.name AS from_name, tu.name AS to_name FROM escalations e
           LEFT JOIN company_members f ON f.id=e.from_member_id LEFT JOIN users fu ON fu.id=f.user_id
           JOIN company_members t ON t.id=e.to_member_id JOIN users tu ON tu.id=t.user_id
          WHERE e.parent_type='workplace_report' AND e.parent_id=$1 ORDER BY e.created_at`, [id]),
      q(`SELECT id, filename, mime, size, created_at FROM files WHERE parent_type='workplace_report' AND parent_id=$1 ORDER BY created_at`, [id]),
    ]);
    return { ...w, updates, assignments, escalations, files, permissions: p, safety_notice: w.safety_risk || w.severity === 'critical' ? SAFETY_NOTICE : null };
  }

  /** Quản lý tiếp nhận xem xét. */
  @Post(':id/review')
  async startReview(@Param('id') id: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({ comment: z.string().optional() }), body);
    await tx(async (c) => {
      const w = await this.load(ctx, id, c);
      const p = await this.perms(ctx, w, c);
      if (!p.canManagerAct) throw Errors.forbidden();
      await q(`UPDATE workplace_reports SET status='manager_review' WHERE id=$1`, [id], c);
      await q(`INSERT INTO report_updates(report_id, actor_id, status, comment) VALUES ($1,$2,'manager_review',$3)`, [id, ctx.memberId, b.comment ?? 'Quản lý đang xem xét'], c);
      await audit(c, ctx, 'workplace_report', id, 'report.manager_review', { status: w.status }, { status: 'manager_review' });
    });
    return this.detail(id, ctx);
  }

  /** Quản lý xác nhận mức độ ảnh hưởng và chuyển bộ phận kỹ thuật/bộ phận chịu trách nhiệm. */
  @Post(':id/assign')
  async assign(@Param('id') id: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({
      departmentId: z.string().uuid(), severity: z.enum(['low', 'medium', 'high', 'critical']).optional(),
      impactConfirmed: z.boolean().default(true), assigneeId: z.string().uuid().optional().nullable(), comment: z.string().optional(),
    }), body);
    await tx(async (c) => {
      await c.query(`SELECT 1 FROM workplace_reports WHERE id=$1 FOR UPDATE`, [id]);
      const w = await this.load(ctx, id, c);
      const p = await this.perms(ctx, w, c);
      if (!p.canManagerAct && !p.canReassign) throw Errors.forbidden('Chỉ quản lý tiếp nhận/cấp chuyển được chuyển bộ phận xử lý');
      const dept = await q1(`SELECT * FROM departments WHERE id=$1 AND company_id=$2`, [b.departmentId, ctx.companyId], c);
      if (!dept) throw Errors.notFound('Bộ phận');
      if (b.assigneeId) {
        const a = await getMember(ctx, b.assigneeId, c);
        if (a.department_id !== b.departmentId && dept.head_member_id !== b.assigneeId) throw Errors.validation('Người xử lý phải thuộc bộ phận được chọn');
      }
      const severity = b.severity || w.severity;
      const holder = dept.head_member_id || b.assigneeId;
      if (!holder) throw new AppError('DEPARTMENT_NO_HEAD', 'Bộ phận chưa có trưởng bộ phận để tiếp nhận; hãy chọn người xử lý', 422);
      const { due, minutes } = await stageDue(c, ctx.companyId, severity, 'acknowledge_minutes');
      await q(`UPDATE workplace_reports SET status='assigned', stage='department_ack', severity=$2, impact_confirmed=$3, department_id=$4,
                 assignee_id=$5, current_holder_id=$6, stage_due_at=$7, stage_window_minutes=$8, sla_cycle=sla_cycle+1, escalation_level=0 WHERE id=$1`,
        [id, severity, b.impactConfirmed, b.departmentId, b.assigneeId ?? null, holder, due, minutes], c);
      await q(`INSERT INTO report_assignments(report_id, department_id, assignee_id, assigned_by) VALUES ($1,$2,$3,$4)`, [id, b.departmentId, b.assigneeId ?? null, ctx.memberId], c);
      await q(`INSERT INTO report_updates(report_id, actor_id, status, comment, new_due_at) VALUES ($1,$2,'assigned',$3,$4)`,
        [id, ctx.memberId, `Chuyển ${dept.name}${b.severity && b.severity !== w.severity ? `; điều chỉnh mức độ ${w.severity} → ${b.severity}` : ''}${b.comment ? ': ' + b.comment : ''}`, due], c);
      await resolveOpenEscalations(c, 'workplace_report', id, ctx.memberId, 'Đã chuyển bộ phận xử lý');
      await audit(c, ctx, 'workplace_report', id, 'report.assigned', { status: w.status, severity: w.severity, department: w.department_id },
        { status: 'assigned', severity, department: b.departmentId, impact_confirmed: b.impactConfirmed });
      const handlers = await q(`SELECT id FROM company_members WHERE department_id=$1 AND status='active'`, [b.departmentId], c);
      await notify(c, { companyId: ctx.companyId, memberIds: [holder, b.assigneeId, ...handlers.map((h) => h.id)], excludeMemberId: ctx.memberId,
        type: 'report.assigned', title: `[${w.code}] Yêu cầu xử lý mới cho ${dept.name} (${severity})`, body: w.description.slice(0, 160), refType: 'workplace_report', refId: id });
      await notify(c, { companyId: ctx.companyId, memberIds: [w.reporter_id], type: 'report.status', title: `[${w.code}] Đã chuyển đến ${dept.name}`, refType: 'workplace_report', refId: id });
    });
    return this.detail(id, ctx);
  }

  /** Bộ phận xử lý xác nhận tiếp nhận, chỉ định người phụ trách và thời hạn dự kiến. */
  @Post(':id/acknowledge')
  async acknowledge(@Param('id') id: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({ assigneeId: z.string().uuid().optional(), eta: z.coerce.date().optional(), comment: z.string().optional() }), body);
    await tx(async (c) => {
      await c.query(`SELECT 1 FROM workplace_reports WHERE id=$1 FOR UPDATE`, [id]);
      const w = await this.load(ctx, id, c);
      const p = await this.perms(ctx, w, c);
      if (!p.canAck) throw Errors.forbidden('Chỉ bộ phận được giao mới xác nhận tiếp nhận');
      const assignee = b.assigneeId || w.assignee_id || ctx.memberId;
      if (assignee !== ctx.memberId) await getMember(ctx, assignee, c);
      const { due, minutes } = await stageDue(c, ctx.companyId, w.severity, 'resolve_minutes');
      const target = b.eta && b.eta < due ? b.eta : due; // không cho kéo dài vượt SLA khi tiếp nhận
      await q(`UPDATE workplace_reports SET status='acknowledged', stage='resolution', assignee_id=$2, current_holder_id=$2, stage_due_at=$3,
                 stage_window_minutes=$4, sla_cycle=sla_cycle+1, escalation_level=0 WHERE id=$1`, [id, assignee, target, minutes], c);
      await q(`INSERT INTO report_updates(report_id, actor_id, status, comment, new_due_at) VALUES ($1,$2,'acknowledged',$3,$4)`, [id, ctx.memberId, b.comment ?? null, target], c);
      await resolveOpenEscalations(c, 'workplace_report', id, ctx.memberId, 'Bộ phận đã tiếp nhận');
      await audit(c, ctx, 'workplace_report', id, 'report.acknowledged', { status: w.status }, { status: 'acknowledged', assignee, due: target });
      await notify(c, { companyId: ctx.companyId, memberIds: [w.reporter_id, w.manager_member_id, assignee], excludeMemberId: ctx.memberId,
        type: 'report.status', title: `[${w.code}] Bộ phận xử lý đã tiếp nhận`, refType: 'workplace_report', refId: id });
    });
    return this.detail(id, ctx);
  }

  /** Người xử lý cập nhật tiến độ, phương án, kết quả. */
  @Post(':id/updates')
  async update(@Param('id') id: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({
      status: z.enum(['in_progress', 'waiting', 'resolved_pending', 'cannot_fix', 'comment']),
      comment: z.string().trim().optional(), newDueAt: z.coerce.date().optional(), tempMeasure: z.string().trim().optional(),
    }), body);
    await tx(async (c) => {
      await c.query(`SELECT 1 FROM workplace_reports WHERE id=$1 FOR UPDATE`, [id]);
      const w = await this.load(ctx, id, c);
      const p = await this.perms(ctx, w, c);
      if (b.status === 'comment') {
        if (!p.canView) throw Errors.forbidden();
        if (!b.comment) throw Errors.validation('Nội dung bình luận là bắt buộc');
        await q(`INSERT INTO report_updates(report_id, actor_id, status, comment) VALUES ($1,$2,'comment',$3)`, [id, ctx.memberId, b.comment], c);
        await notify(c, { companyId: ctx.companyId, memberIds: [w.reporter_id, w.current_holder_id, w.assignee_id], excludeMemberId: ctx.memberId,
          type: 'report.comment', title: `[${w.code}] ${ctx.name} bình luận`, body: b.comment.slice(0, 140), refType: 'workplace_report', refId: id });
        return;
      }
      if (!p.canUpdate) throw Errors.forbidden('Chỉ người xử lý/bộ phận phụ trách được cập nhật');
      if (b.status === 'waiting') {
        if (!b.comment || b.comment.length < 5 || !b.newDueAt) throw Errors.validation('Chờ thông tin/vật tư phải nêu lý do và thời hạn mới');
        if (b.newDueAt <= new Date()) throw Errors.validation('Thời hạn mới phải ở tương lai');
        await q(`UPDATE workplace_reports SET status='waiting', stage_due_at=$2, sla_cycle=sla_cycle+1, escalation_level=0 WHERE id=$1`, [id, b.newDueAt], c);
      } else if (b.status === 'in_progress') {
        await q(`UPDATE workplace_reports SET status='in_progress' WHERE id=$1`, [id], c);
      } else if (b.status === 'resolved_pending') {
        if (!b.comment || b.comment.length < 5) throw Errors.validation('Cần mô tả kết quả xử lý');
        await q(`UPDATE workplace_reports SET status='resolved_pending', stage='reporter_confirm', current_holder_id=reporter_id, stage_due_at=NULL WHERE id=$1`, [id], c);
        await resolveOpenEscalations(c, 'workplace_report', id, ctx.memberId, 'Đã xử lý, chờ người báo cáo xác nhận');
      } else if (b.status === 'cannot_fix') {
        if (!b.comment || b.comment.length < 10 || !b.tempMeasure) throw Errors.validation('Không khắc phục được: phải nêu lý do và phương án tạm thời');
        await q(`UPDATE workplace_reports SET status='escalated', temp_measure=$2, escalation_level=escalation_level+1 WHERE id=$1`, [id, b.tempMeasure], c);
        const dept = w.department_id ? await q1(`SELECT head_member_id FROM departments WHERE id=$1`, [w.department_id], c) : null;
        const lvl = await q1(`SELECT COALESCE(max(level),0)+1 AS l FROM escalations WHERE parent_type='workplace_report' AND parent_id=$1 AND stage='resolution' AND cycle=$2`, [id, w.sla_cycle], c);
        const r = await escalate(c, {
          companyId: ctx.companyId, parentType: 'workplace_report', parentId: id, stage: 'resolution', cycle: w.sla_cycle, level: lvl.l,
          fromMemberId: ctx.memberId, baseMemberId: dept?.head_member_id && dept.head_member_id !== ctx.memberId ? dept.head_member_id : ctx.memberId,
          reason: `Không khắc phục được: ${b.comment}. Phương án tạm thời: ${b.tempMeasure}`, newDueAt: null,
          exclude: [w.reporter_id], actorId: ctx.memberId, title: `[${w.code}] Chuyển cấp chuyên môn: không khắc phục được`, notifyAlso: [w.reporter_id, w.manager_member_id],
        });
        if (!r) throw new AppError('ESCALATION_CHAIN_EXHAUSTED', 'Không còn cấp chuyên môn cao hơn trong tuyến chuyển cấp', 409);
      }
      const nd = await q1(`SELECT stage_due_at FROM workplace_reports WHERE id=$1`, [id], c);
      await q(`INSERT INTO report_updates(report_id, actor_id, status, comment, new_due_at) VALUES ($1,$2,$3,$4,$5)`,
        [id, ctx.memberId, b.status, b.comment ?? null, b.status === 'waiting' ? nd.stage_due_at : null], c);
      await audit(c, ctx, 'workplace_report', id, 'report.update.' + b.status, { status: w.status }, { status: b.status, due: nd.stage_due_at }, b.comment ?? null);
      await notify(c, { companyId: ctx.companyId, memberIds: [w.reporter_id, w.manager_member_id], excludeMemberId: ctx.memberId,
        type: b.status === 'resolved_pending' ? 'report.resolved' : 'report.status',
        title: b.status === 'resolved_pending' ? `[${w.code}] Đã xử lý — vui lòng xác nhận` : `[${w.code}] Cập nhật xử lý: ${b.status}`,
        body: b.comment, refType: 'workplace_report', refId: id });
    });
    return this.detail(id, ctx);
  }

  /** Người báo cáo xác nhận đã khắc phục (đóng) hoặc mở lại. */
  @Post(':id/confirm')
  async confirm(@Param('id') id: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({ decision: z.enum(['close', 'reopen']), comment: z.string().trim().optional() }), body);
    await tx(async (c) => {
      await c.query(`SELECT 1 FROM workplace_reports WHERE id=$1 FOR UPDATE`, [id]);
      const w = await this.load(ctx, id, c);
      if (w.reporter_id !== ctx.memberId) throw Errors.forbidden('Chỉ người báo cáo được xác nhận đóng/mở lại');
      if (b.decision === 'close') {
        if (w.stage !== 'reporter_confirm') throw Errors.invalidState('Báo cáo chưa ở bước chờ xác nhận');
        await q(`UPDATE workplace_reports SET status='closed', stage='closed', current_holder_id=NULL, stage_due_at=NULL, closed_at=now() WHERE id=$1`, [id], c);
        await resolveOpenEscalations(c, 'workplace_report', id, ctx.memberId, 'Đã đóng');
      } else {
        if (!['reporter_confirm', 'closed'].includes(w.stage)) throw Errors.invalidState('Chỉ mở lại báo cáo đã xử lý/đã đóng');
        if (!b.comment || b.comment.length < 10) throw Errors.reasonRequired('Mở lại phải nêu lý do vấn đề chưa được giải quyết');
        const holder = w.assignee_id || (await q1(`SELECT head_member_id FROM departments WHERE id=$1`, [w.department_id], c))?.head_member_id;
        const { due, minutes } = await stageDue(c, ctx.companyId, w.severity, 'resolve_minutes');
        await q(`UPDATE workplace_reports SET status='reopened', stage='resolution', current_holder_id=$2, stage_due_at=$3, stage_window_minutes=$4,
                   sla_cycle=sla_cycle+1, escalation_level=0, reopen_count=reopen_count+1, closed_at=NULL WHERE id=$1`, [id, holder, due, minutes], c);
        await notify(c, { companyId: ctx.companyId, memberIds: [holder, w.manager_member_id], type: 'report.reopened',
          title: `[${w.code}] Báo cáo bị mở lại`, body: b.comment, refType: 'workplace_report', refId: id });
      }
      await q(`INSERT INTO report_updates(report_id, actor_id, status, comment) VALUES ($1,$2,$3,$4)`, [id, ctx.memberId, b.decision === 'close' ? 'closed' : 'reopened', b.comment ?? null], c);
      await audit(c, ctx, 'workplace_report', id, 'report.' + (b.decision === 'close' ? 'closed' : 'reopened'), { status: w.status }, null, b.comment ?? null);
      if (b.decision === 'close') {
        await notify(c, { companyId: ctx.companyId, memberIds: [w.assignee_id, w.manager_member_id], excludeMemberId: ctx.memberId,
          type: 'report.closed', title: `[${w.code}] Người báo cáo đã xác nhận đóng`, refType: 'workplace_report', refId: id });
      }
    });
    return this.detail(id, ctx);
  }

  /** Chuyển cấp thủ công (người báo cáo hoặc người đang giữ việc). */
  @Post(':id/escalate')
  async manualEscalate(@Param('id') id: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({ reason: z.string().trim().min(10, 'Lý do chuyển cấp cần tối thiểu 10 ký tự') }), body);
    await tx(async (c) => {
      await c.query(`SELECT 1 FROM workplace_reports WHERE id=$1 FOR UPDATE`, [id]);
      const w = await this.load(ctx, id, c);
      const p = await this.perms(ctx, w, c);
      if (!p.canEscalate) throw Errors.forbidden();
      const lvl = await q1(`SELECT COALESCE(max(level),0)+1 AS l FROM escalations WHERE parent_type='workplace_report' AND parent_id=$1 AND stage=$2 AND cycle=$3`, [id, w.stage, w.sla_cycle], c);
      const base = w.stage === 'manager_review' ? w.manager_member_id : w.current_holder_id;
      const r = await escalate(c, {
        companyId: ctx.companyId, parentType: 'workplace_report', parentId: id, stage: w.stage, cycle: w.sla_cycle, level: lvl.l,
        fromMemberId: w.current_holder_id, baseMemberId: base, reason: `[Thủ công bởi ${ctx.name}] ${b.reason}`, newDueAt: w.stage_due_at,
        exclude: [w.reporter_id], actorId: ctx.memberId, title: `[${w.code}] Báo cáo trở ngại được chuyển cấp`, notifyAlso: [w.reporter_id],
      });
      if (!r) throw new AppError('ESCALATION_CHAIN_EXHAUSTED', 'Đã chuyển đến cấp cao nhất trong tuyến', 409);
      await q(`UPDATE workplace_reports SET status='escalated', escalation_level=$2 WHERE id=$1`, [id, lvl.l], c);
      await q(`INSERT INTO report_updates(report_id, actor_id, status, comment) VALUES ($1,$2,'escalated',$3)`, [id, ctx.memberId, b.reason], c);
    });
    return this.detail(id, ctx);
  }
}
