import { Body, Controller, Get, Param, Post, Query, Res } from '@nestjs/common';
import { Response } from 'express';
import { join } from 'path';
import { existsSync, createReadStream } from 'fs';
import { DateTime } from 'luxon';
import PDFDocument from 'pdfkit';
import nodemailer from 'nodemailer';
import { getPool, q, q1, tx } from '../db/db';
import { CurrentCtx, Ctx, isAdmin, isHR } from '../common/context';
import { AppError, Errors } from '../common/errors';
import { parse, z } from '../common/validate';
import { escalationChain, getCompany } from '../common/access';
import { audit } from '../common/audit';
import { notify } from '../common/notify';
import { workingMinutesBetween } from '../common/calendar';
import { saveGeneratedFile, storage } from './files.controller';
import { OPEN_STATUSES } from './tasks.controller';

export const LEAVE_TYPE: Record<string, string> = { sudden: 'Nghỉ đột xuất', hourly: 'Nghỉ theo giờ', shift: 'Nghỉ theo ca', day: 'Nghỉ theo ngày' };
const DAY = /^\d{4}-\d\d-\d\d$/;

const SELECT = `
  SELECT l.*, u.name AS member_name, u.phone AS member_phone, cm.title AS member_title, d.name AS department_name,
         au.name AS approver_name, du.name AS decided_by_name
    FROM leave_requests l
    JOIN company_members cm ON cm.id=l.member_id JOIN users u ON u.id=cm.user_id
    LEFT JOIN departments d ON d.id=cm.department_id
    LEFT JOIN company_members acm ON acm.id=l.approver_id LEFT JOIN users au ON au.id=acm.user_id
    LEFT JOIN company_members dcm ON dcm.id=l.decided_by LEFT JOIN users du ON du.id=dcm.user_id`;

/** Người duyệt đơn: cấp trên trực tiếp (có vai trò quản lý) -> quản lý nhóm -> Admin/Owner. */
async function pickApprover(companyId: string, memberId: string, db: any): Promise<string> {
  const sup = await q1(`SELECT s.id FROM company_members m JOIN company_members s ON s.id=m.supervisor_member_id
                         WHERE m.id=$1 AND s.status='active' AND s.role<>'employee'`, [memberId], db);
  if (sup) return sup.id;
  const g = await q1(`SELECT g.manager_member_id AS id FROM group_members gm JOIN groups g ON g.id=gm.group_id
                       WHERE gm.company_member_id=$1 AND g.deleted_at IS NULL AND g.manager_member_id<>$1 ORDER BY g.created_at LIMIT 1`, [memberId], db);
  if (g) return g.id;
  const chain = await escalationChain(companyId, memberId, db);
  if (!chain.length) throw new AppError('NO_APPROVER', 'Chưa có người duyệt đơn nghỉ (cấp trên/quản lý nhóm)', 422);
  return chain[0];
}

async function canDecide(ctx: Ctx, l: any, db: any) {
  if (l.member_id === ctx.memberId) return false;
  if (l.approver_id === ctx.memberId || isAdmin(ctx)) return true;
  const sup = await q1(`SELECT 1 FROM company_members WHERE id=$1 AND supervisor_member_id=$2`, [l.member_id, ctx.memberId], db);
  const mgr = await q1(`SELECT 1 FROM group_members gm JOIN groups g ON g.id=gm.group_id WHERE gm.company_member_id=$1 AND g.manager_member_id=$2 AND g.deleted_at IS NULL`, [l.member_id, ctx.memberId], db);
  return !!(sup || mgr);
}

function leavePdf(l: any, company: any): Promise<Buffer> {
  return new Promise((resolve) => {
    const doc = new PDFDocument({ size: 'A4', margin: 56 });
    const fonts = join(__dirname, '..', '..', 'assets', 'fonts');
    doc.registerFont('R', join(fonts, 'DejaVuSans.ttf')); doc.registerFont('B', join(fonts, 'DejaVuSans-Bold.ttf'));
    const chunks: Buffer[] = [];
    doc.on('data', (c) => chunks.push(c)); doc.on('end', () => resolve(Buffer.concat(chunks)));
    const tz = company.timezone;
    const f = (s: any) => DateTime.fromJSDate(new Date(s), { zone: tz }).toFormat('HH:mm dd/MM/yyyy');
    doc.font('B').fontSize(11).text('CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM', { align: 'center' });
    doc.font('B').fontSize(10).text('Độc lập - Tự do - Hạnh phúc', { align: 'center' }).moveDown(0.3);
    doc.font('R').text('———————', { align: 'center' }).moveDown(1);
    doc.font('B').fontSize(16).text('ĐƠN XIN NGHỈ PHÉP', { align: 'center' });
    doc.font('R').fontSize(10).text(`Số: ${l.code}`, { align: 'center' }).moveDown(1.2);
    doc.fontSize(11).text(`Kính gửi: Ban lãnh đạo ${company.name} và Phòng Nhân sự`).moveDown(0.6);
    const row = (k: string, v: string) => { doc.font('B').text(`${k}: `, { continued: true }).font('R').text(v || '—'); doc.moveDown(0.25); };
    row('Họ và tên', l.member_name); row('Số điện thoại', l.member_phone); row('Chức danh', l.member_title); row('Bộ phận', l.department_name);
    row('Hình thức nghỉ', `${LEAVE_TYPE[l.leave_type]}${l.shift ? ` (${l.shift_label || l.shift})` : ''}`);
    row('Thời gian nghỉ', `Từ ${f(l.start_at)} đến ${f(l.end_at)}`);
    row('Thời lượng (giờ làm việc)', `${Math.round(l.minutes / 6) / 10} giờ`);
    row('Báo trước', l.notice_minutes > 0 ? `${Math.round(l.notice_minutes / 60)} giờ${l.late_notice ? ' (ít hơn quy định)' : ''}` : 'Không (nghỉ đột xuất)');
    row('Lý do', l.reason);
    row('Bàn giao công việc', l.handover);
    doc.moveDown(0.8);
    doc.font('B').text('XÁC NHẬN PHÊ DUYỆT').moveDown(0.3);
    row('Người duyệt', l.decided_by_name); row('Thời điểm duyệt', f(l.decided_at)); if (l.decision_reason) row('Ghi chú', l.decision_reason);
    doc.moveDown(1.5);
    doc.font('R').fontSize(9).fillColor('#555').text(`Đơn được lập và phê duyệt điện tử trên ứng dụng Việc Đến lúc ${f(new Date())}. Mã đơn ${l.code} — tra cứu trong mục Nghỉ phép.`);
    doc.end();
  });
}

async function sendHrEmail(to: string[], subject: string, text: string, pdf: Buffer, filename: string): Promise<string> {
  if (!process.env.SMTP_URL) return 'skipped: chưa cấu hình SMTP_URL';
  if (!to.length) return 'skipped: nhân sự chưa có email';
  try {
    const t = nodemailer.createTransport(process.env.SMTP_URL);
    await t.sendMail({ from: process.env.SMTP_FROM || 'Việc Đến <no-reply@viecden.vn>', to: to.join(','), subject, text, attachments: [{ filename, content: pdf }] });
    return 'sent';
  } catch (e: any) { return 'failed: ' + (e?.message || 'lỗi gửi mail').slice(0, 200); }
}

@Controller('leaves')
export class LeavesController {
  private async load(ctx: Ctx, id: string, db: any = getPool()) {
    const l = await q1(`${SELECT} WHERE l.id=$1 AND l.company_id=$2`, [id, ctx.companyId], db);
    if (!l) throw Errors.notFound('Đơn nghỉ');
    return l;
  }

  @Get()
  async list(@CurrentCtx() ctx: Ctx, @Query() qs: any) {
    const f = parse(z.object({ scope: z.enum(['mine', 'approve', 'hr']).default('mine'), status: z.string().optional() }), qs);
    const params: any[] = [ctx.companyId, ctx.memberId];
    const where = ['l.company_id=$1', '$2::uuid IS NOT NULL'];
    if (f.scope === 'mine') where.push('l.member_id=$2');
    else if (f.scope === 'approve') {
      where.push(`l.member_id<>$2 AND (l.approver_id=$2 OR cm.supervisor_member_id=$2 OR ${isAdmin(ctx)}
        OR EXISTS (SELECT 1 FROM group_members gm JOIN groups g ON g.id=gm.group_id WHERE gm.company_member_id=l.member_id AND g.manager_member_id=$2))`);
    } else {
      if (!isHR(ctx)) throw Errors.forbidden();
      where.push(`l.status='approved'`);
    }
    if (f.status) { params.push(f.status.split(',')); where.push(`l.status = ANY($${params.length}::text[])`); }
    return q(`${SELECT} WHERE ${where.join(' AND ')} ORDER BY (l.status='pending') DESC, l.start_at DESC LIMIT 300`, params);
  }

  @Post()
  async create(@Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({
      leaveType: z.enum(['sudden', 'hourly', 'shift', 'day']), reason: z.string().trim().min(5, 'Nêu lý do nghỉ'), handover: z.string().trim().optional(),
      startAt: z.coerce.date().optional(), endAt: z.coerce.date().optional(),
      date: z.string().regex(DAY).optional(), shift: z.string().optional(),
      startDate: z.string().regex(DAY).optional(), endDate: z.string().regex(DAY).optional(),
    }), body);
    const company = await getCompany(ctx.companyId);
    const tz = company.timezone; const cal = company.settings.calendar;
    let start: Date; let end: Date; let shiftLabel: string | null = null;
    if (b.leaveType === 'day') {
      if (!b.startDate) throw Errors.validation('Chọn ngày bắt đầu nghỉ');
      const ed = b.endDate || b.startDate;
      start = DateTime.fromISO(`${b.startDate}T${cal.start}`, { zone: tz }).toJSDate();
      end = DateTime.fromISO(`${ed}T${cal.end}`, { zone: tz }).toJSDate();
    } else if (b.leaveType === 'shift') {
      const sh = (cal.shifts || []).find((s) => s.key === b.shift);
      if (!b.date || !sh) throw Errors.validation('Chọn ngày và ca nghỉ');
      shiftLabel = sh.label;
      start = DateTime.fromISO(`${b.date}T${sh.start}`, { zone: tz }).toJSDate();
      end = DateTime.fromISO(`${b.date}T${sh.end}`, { zone: tz }).toJSDate();
    } else {
      if (!b.startAt || !b.endAt) throw Errors.validation('Chọn thời gian bắt đầu và kết thúc');
      start = b.startAt; end = b.endAt;
    }
    if (end <= start) throw Errors.validation('Thời gian kết thúc phải sau thời gian bắt đầu');
    const now = new Date();
    if (b.leaveType !== 'sudden' && start < new Date(now.getTime() - 3600000)) throw Errors.validation('Thời gian nghỉ đã qua — hãy chọn "Nghỉ đột xuất"');
    const notice = Math.max(0, Math.round((start.getTime() - now.getTime()) / 60000));
    const need = b.leaveType === 'sudden' ? 0 : (company.settings.policies.leaveNoticeHours as any)[b.leaveType] * 60;
    let minutes = workingMinutesBetween(start, end, cal, tz);
    if (!minutes) minutes = Math.round((end.getTime() - start.getTime()) / 60000);
    const id = await tx(async (c) => {
      const overlap = await q1(`SELECT code FROM leave_requests WHERE member_id=$1 AND status IN ('pending','approved') AND tstzrange(start_at,end_at) && tstzrange($2,$3)`, [ctx.memberId, start, end], c);
      if (overlap) throw new AppError('LEAVE_OVERLAP', `Trùng thời gian với đơn ${overlap.code}`, 409);
      const approver = await pickApprover(ctx.companyId, ctx.memberId, c);
      const seq = await q1(`UPDATE companies SET leave_seq=leave_seq+1 WHERE id=$1 RETURNING leave_seq`, [ctx.companyId], c);
      const l = await q1(
        `INSERT INTO leave_requests(company_id, code, member_id, leave_type, start_at, end_at, shift, minutes, reason, handover, notice_minutes, late_notice, approver_id)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13) RETURNING id`,
        [ctx.companyId, `NP-${String(seq.leave_seq).padStart(5, '0')}`, ctx.memberId, b.leaveType, start, end, b.leaveType === 'shift' ? b.shift : null,
         minutes, b.reason, b.handover ?? null, notice, notice < need, approver], c);
      await audit(c, ctx, 'leave', l.id, 'leave.submitted', null, { type: b.leaveType, start, end, notice, approver });
      await notify(c, { companyId: ctx.companyId, memberIds: [approver], type: 'leave.pending',
        title: `${ctx.name} xin ${LEAVE_TYPE[b.leaveType].toLowerCase()}${shiftLabel ? ' (' + shiftLabel + ')' : ''}`,
        body: `${DateTime.fromJSDate(start, { zone: tz }).toFormat('HH:mm dd/MM')} → ${DateTime.fromJSDate(end, { zone: tz }).toFormat('HH:mm dd/MM')} · ${b.reason}`,
        refType: 'leave', refId: l.id });
      return l.id;
    });
    return this.detail(id, ctx);
  }

  @Get(':id')
  async detail(@Param('id') id: string, @CurrentCtx() ctx: Ctx) {
    const l = await this.load(ctx, id);
    const decide = await canDecide(ctx, l, getPool());
    if (l.member_id !== ctx.memberId && !decide && !isHR(ctx)) throw Errors.notFound('Đơn nghỉ');
    const company = await getCompany(ctx.companyId);
    const conflicts = await q(
      `SELECT t.id, t.code, t.title, t.due_at, t.plan_date, t.pinned FROM tasks t JOIN task_assignees ta ON ta.task_id=t.id AND ta.active AND ta.company_member_id=$1
        WHERE t.status IN ${OPEN_STATUSES} AND (t.due_at BETWEEN $2 AND $3 OR t.plan_date BETWEEN ($2 AT TIME ZONE $4)::date AND ($3 AT TIME ZONE $4)::date)
        ORDER BY t.due_at`, [l.member_id, l.start_at, l.end_at, company.timezone]);
    const shift = (company.settings.calendar.shifts || []).find((s) => s.key === l.shift);
    return {
      ...l, type_label: LEAVE_TYPE[l.leave_type], shift_label: shift?.label ?? null, conflicts,
      notice_required_hours: l.leave_type === 'sudden' ? 0 : (company.settings.policies.leaveNoticeHours as any)[l.leave_type],
      permissions: {
        can_decide: decide && l.status === 'pending',
        can_cancel: l.member_id === ctx.memberId && (l.status === 'pending' || (l.status === 'approved' && new Date(l.start_at) > new Date())),
        can_download: !!l.pdf_file_id,
      },
    };
  }

  /** Quản lý duyệt/từ chối. Khi duyệt: xuất đơn PDF và gửi tự động sang Phòng nhân sự (thông báo trong app + email nếu cấu hình SMTP). */
  @Post(':id/decide')
  async decide(@Param('id') id: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({ decision: z.enum(['approve', 'reject']), reason: z.string().trim().optional() }), body);
    if (b.decision === 'reject' && (!b.reason || b.reason.length < 5)) throw Errors.reasonRequired('Từ chối đơn nghỉ phải có lý do');
    let emailJob: (() => Promise<void>) | null = null;
    await tx(async (c) => {
      await c.query(`SELECT 1 FROM leave_requests WHERE id=$1 FOR UPDATE`, [id]);
      const l = await this.load(ctx, id, c);
      if (!(await canDecide(ctx, l, c))) throw Errors.forbidden('Bạn không có quyền duyệt đơn này');
      if (l.status !== 'pending') throw Errors.invalidState('Đơn đã được xử lý');
      const status = b.decision === 'approve' ? 'approved' : 'rejected';
      await q(`UPDATE leave_requests SET status=$2, decision_reason=$3, decided_by=$4, decided_at=now() WHERE id=$1`, [id, status, b.reason ?? null, ctx.memberId], c);
      await audit(c, ctx, 'leave', id, 'leave.' + status, { status: 'pending' }, { status }, b.reason ?? null);
      await notify(c, { companyId: ctx.companyId, memberIds: [l.member_id], type: 'leave.' + status,
        title: status === 'approved' ? `Đơn nghỉ ${l.code} đã được duyệt` : `Đơn nghỉ ${l.code} bị từ chối`, body: b.reason, refType: 'leave', refId: id });
      if (status === 'approved') {
        const company = await getCompany(ctx.companyId, c);
        const fresh = await this.load(ctx, id, c);
        const shift = (company.settings.calendar.shifts || []).find((s) => s.key === fresh.shift);
        const pdf = await leavePdf({ ...fresh, shift_label: shift?.label }, company);
        const file = await saveGeneratedFile(c, ctx.companyId, 'leave', id, `Don-nghi-phep-${fresh.code}.pdf`, 'application/pdf', pdf, ctx.memberId);
        const hr = await q(`SELECT cm.id, u.email FROM company_members cm JOIN users u ON u.id=cm.user_id WHERE cm.company_id=$1 AND cm.status='active' AND cm.role='hr'`, [ctx.companyId], c);
        const recipients = hr.length ? hr : await q(`SELECT cm.id, u.email FROM company_members cm JOIN users u ON u.id=cm.user_id WHERE cm.company_id=$1 AND cm.status='active' AND cm.role IN ('admin','owner')`, [ctx.companyId], c);
        await notify(c, { companyId: ctx.companyId, memberIds: recipients.map((r) => r.id), type: 'leave.hr',
          title: `📄 Đơn nghỉ phép ${fresh.code} — ${fresh.member_name} (đã duyệt)`,
          body: `${LEAVE_TYPE[fresh.leave_type]} · ${Math.round(fresh.minutes / 6) / 10} giờ · duyệt bởi ${ctx.name}`, refType: 'leave', refId: id });
        await q(`UPDATE leave_requests SET pdf_file_id=$2, hr_notified_at=now(), hr_email_status='pending' WHERE id=$1`, [id, file.id], c);
        const emails = recipients.map((r) => r.email).filter(Boolean);
        if (!emails.length && company.contact_email) emails.push(company.contact_email);
        emailJob = async () => {
          const st = await sendHrEmail(emails, `[Việc Đến] Đơn nghỉ phép ${fresh.code} - ${fresh.member_name}`,
            `Đơn nghỉ phép ${fresh.code} của ${fresh.member_name} đã được ${ctx.name} duyệt. File đơn đính kèm.`, pdf, `Don-nghi-phep-${fresh.code}.pdf`);
          await q(`UPDATE leave_requests SET hr_email_status=$2 WHERE id=$1`, [id, st]);
        };
      }
    });
    if (emailJob) await (emailJob as () => Promise<void>)();
    return this.detail(id, ctx);
  }

  @Post(':id/cancel')
  async cancel(@Param('id') id: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    const l = await this.load(ctx, id);
    const d = await this.detail(id, ctx);
    if (!d.permissions.can_cancel) throw Errors.invalidState('Không thể hủy đơn này');
    await tx(async (c) => {
      await q(`UPDATE leave_requests SET status='cancelled' WHERE id=$1`, [id], c);
      await audit(c, ctx, 'leave', id, 'leave.cancelled', { status: l.status }, { status: 'cancelled' }, body?.reason ?? null);
      await notify(c, { companyId: ctx.companyId, memberIds: [l.approver_id, l.decided_by], excludeMemberId: ctx.memberId, type: 'leave.cancelled',
        title: `${ctx.name} đã hủy đơn nghỉ ${l.code}`, refType: 'leave', refId: id });
    });
    return this.detail(id, ctx);
  }

  @Get(':id/pdf')
  async pdf(@Param('id') id: string, @CurrentCtx() ctx: Ctx, @Res() res: Response) {
    const d = await this.detail(id, ctx);
    if (!d.pdf_file_id) throw Errors.notFound('Đơn PDF');
    const f = await q1(`SELECT * FROM files WHERE id=$1`, [d.pdf_file_id]);
    const p = storage.path(f.storage_key);
    if (!existsSync(p)) throw Errors.notFound('Đơn PDF');
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename="${f.filename}"`);
    createReadStream(p).pipe(res);
  }
}

