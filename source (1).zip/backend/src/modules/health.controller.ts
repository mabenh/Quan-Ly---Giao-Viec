import { Controller, Get } from '@nestjs/common';
import { q1 } from '../db/db';
import { Public } from '../common/auth.guard';

@Controller('health')
export class HealthController {
  @Public()
  @Get()
  async health() {
    await q1('SELECT 1');
    return { ok: true, time: new Date().toISOString() };
  }
}
