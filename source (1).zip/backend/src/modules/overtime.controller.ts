import { Body, Controller, Get, Param, Post, Query } from '@nestjs/common';
import { q, q1, tx } from '../db/db';
import { CurrentCtx, Ctx, isAdmin } from '../common/context';
import { Errors } from '../common/errors';
import { parse, z } from '../common/validate';
import { getMember, getGroup } from '../common/access';
import { audit } from '../common/audit';
import { notify } from '../common/notify';

/** Người có quyền xác nhận tăng ca của một nhân viên: quản lý nhóm liên quan, cấp trên trực tiếp, Admin/Owner. */
async function canReviewMember(ctx: Ctx, memberId: string, groupId: string | null): Promise<boolean> {
  if (memberId === ctx.memberId) return false;
  if (isAdmin(ctx)) return true;
  const m = await q1(`SELECT supervisor_member_id FROM company_members WHERE id=$1`, [memberId]);
  if (m?.supervisor_member_id === ctx.memberId) return true;
  const r = await q1(
    `SELECT 1 FROM groups g WHERE g.manager_member_id=$1 AND g.deleted_at IS NULL AND (
        ($3::uuid IS NOT NULL AND g.id=$3) OR ($3::uuid IS NULL AND EXISTS (SELECT 1 FROM group_members gm WHERE gm.group_id=g.id AND gm.company_member_id=$2)))`,
    [ctx.memberId, memberId, groupId]);
  return !!r;
}

const SELECT = `
  SELECT o.*, u.name AS member_name, ru.name AS requested_by_name, rv.name AS reviewer_name, t.title AS task_title, g.name AS group_name
    FROM overtime_records o
    JOIN company_members cm ON cm.id=o.member_id JOIN users u ON u.id=cm.user_id
    LEFT JOIN company_members rcm ON rcm.id=o.requested_by_member_id LEFT JOIN users ru ON ru.id=rcm.user_id
    LEFT JOIN company_members vcm ON vcm.id=o.reviewer_id LEFT JOIN users rv ON rv.id=vcm.user_id
    LEFT JOIN tasks t ON t.id=o.task_id LEFT JOIN groups g ON g.id=o.group_id`;

@Controller('overtime-records')
export class OvertimeController {
  @Get()
  async list(@CurrentCtx() ctx: Ctx, @Query() qs: any) {
    const f = parse(z.object({
      memberId: z.string().uuid().optional(), status: z.enum(['pending', 'confirmed', 'rejected']).optional(),
      from: z.coerce.date().optional(), to: z.coerce.date().optional(), scope: z.enum(['mine', 'team']).default('mine'),
    }), qs);
    const params: any[] = [ctx.companyId, ctx.memberId];
    const where = ['o.company_id=$1', '$2::uuid IS NOT NULL'];
    if (f.scope === 'mine') where.push('o.member_id=$2');
    else if (!isAdmin(ctx)) {
      where.push(`(o.member_id=$2 OR cm.supervisor_member_id=$2 OR EXISTS (SELECT 1 FROM groups g2 WHERE g2.manager_member_id=$2 AND
                  (g2.id=o.group_id OR EXISTS (SELECT 1 FROM group_members gm WHERE gm.group_id=g2.id AND gm.company_member_id=o.member_id))))`);
    }
    if (f.memberId) { params.push(f.memberId); where.push(`o.member_id=$${params.length}`); }
    if (f.status) { params.push(f.status); where.push(`o.approval_status=$${params.length}`); }
    if (f.from) { params.push(f.from); where.push(`o.start_at >= $${params.length}`); }
    if (f.to) { params.push(f.to); where.push(`o.start_at < $${params.length}`); }
    return q(`${SELECT} WHERE ${where.join(' AND ')} ORDER BY o.start_at DESC LIMIT 500`, params);
  }

  @Get(':id')
  async get(@Param('id') id: string, @CurrentCtx() ctx: Ctx) {
    const o = await q1(`${SELECT} WHERE o.id=$1 AND o.company_id=$2`, [id, ctx.companyId]);
    if (!o) throw Errors.notFound('Bản ghi tăng ca');
    const reviewer = await canReviewMember(ctx, o.member_id, o.group_id);
    if (o.member_id !== ctx.memberId && !reviewer && !isAdmin(ctx)) throw Errors.notFound('Bản ghi tăng ca');
    const history = await q(`SELECT a.action, a.reason, a.new_value, a.created_at, u.name AS actor_name FROM audit_logs a
       LEFT JOIN company_members cm ON cm.id=a.actor_id LEFT JOIN users u ON u.id=cm.user_id
       WHERE a.entity_type='overtime' AND a.entity_id=$1 ORDER BY a.id`, [id]);
    return { ...o, history, can_review: reviewer && o.approval_status === 'pending' };
  }

  @Post()
  async create(@Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({
      memberId: z.string().uuid().optional(), groupId: z.string().uuid().optional().nullable(),
      taskId: z.string().uuid().optional().nullable(), reportId: z.string().uuid().optional().nullable(),
      startAt: z.coerce.date(), endAt: z.coerce.date(),
      otType: z.enum(['planned', 'ad_hoc', 'incident', 'workload', 'support']),
      cause: z.string().trim().min(5, 'Nguyên nhân tăng ca là bắt buộc'),
      requestedByMemberId: z.string().uuid().optional().nullable(), notifiedInAdvance: z.boolean().default(false),
      impact: z.string().optional(),
    }), body);
    if (b.endAt <= b.startAt) throw Errors.validation('Giờ kết thúc phải sau giờ bắt đầu');
    const minutes = Math.round((b.endAt.getTime() - b.startAt.getTime()) / 60000);
    if (minutes > 24 * 60) throw Errors.validation('Một bản ghi tăng ca không vượt quá 24 giờ; hãy tách thành nhiều bản ghi');
    const memberId = b.memberId || ctx.memberId;
    if (memberId !== ctx.memberId && !(await canReviewMember(ctx, memberId, b.groupId ?? null))) throw Errors.forbidden('Bạn chỉ có thể ghi nhận tăng ca cho bản thân hoặc thành viên mình quản lý');
    if (b.groupId) await getGroup(ctx, b.groupId);
    if (b.requestedByMemberId) await getMember(ctx, b.requestedByMemberId);
    if (b.taskId) {
      const t = await q1(`SELECT id, group_id FROM tasks WHERE id=$1 AND company_id=$2`, [b.taskId, ctx.companyId]);
      if (!t) throw Errors.notFound('Nhiệm vụ');
      b.groupId = b.groupId || t.group_id;
    }
    if (b.reportId) {
      const r = await q1(`SELECT id FROM workplace_reports WHERE id=$1 AND company_id=$2`, [b.reportId, ctx.companyId]);
      if (!r) throw Errors.notFound('Báo cáo trở ngại');
    }
    const id = await tx(async (c) => {
      const o = await q1(
        `INSERT INTO overtime_records(company_id, member_id, group_id, task_id, report_id, start_at, end_at, minutes, ot_type, cause,
                                      requested_by_member_id, notified_in_advance, impact, created_by)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14) RETURNING id`,
        [ctx.companyId, memberId, b.groupId ?? null, b.taskId ?? null, b.reportId ?? null, b.startAt, b.endAt, minutes, b.otType, b.cause,
         b.requestedByMemberId ?? null, b.notifiedInAdvance, b.impact ?? null, ctx.memberId], c);
      await audit(c, ctx, 'overtime', o.id, 'overtime.created', null, { minutes, ot_type: b.otType });
      // người xác nhận: quản lý nhóm + cấp trên trực tiếp
      const recips: string[] = [];
      if (b.groupId) { const g = await q1(`SELECT manager_member_id FROM groups WHERE id=$1`, [b.groupId], c); recips.push(g.manager_member_id); }
      const sup = await q1(`SELECT supervisor_member_id FROM company_members WHERE id=$1`, [memberId], c);
      if (sup?.supervisor_member_id) recips.push(sup.supervisor_member_id);
      await notify(c, { companyId: ctx.companyId, memberIds: recips, excludeMemberId: memberId, type: 'overtime.submitted',
        title: `Bản ghi tăng ca ${Math.round(minutes / 6) / 10} giờ chờ xác nhận`, body: b.cause, refType: 'overtime', refId: o.id });
      return o.id;
    });
    return this.get(id, ctx);
  }

  @Post(':id/review')
  async review(@Param('id') id: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({ decision: z.enum(['confirm', 'reject']), reason: z.string().trim().optional() }), body);
    const o = await q1(`SELECT * FROM overtime_records WHERE id=$1 AND company_id=$2`, [id, ctx.companyId]);
    if (!o) throw Errors.notFound('Bản ghi tăng ca');
    if (!(await canReviewMember(ctx, o.member_id, o.group_id))) throw Errors.forbidden('Bạn không có quyền xác nhận bản ghi tăng ca này');
    if (o.approval_status !== 'pending') throw Errors.invalidState('Bản ghi đã được xử lý');
    if (b.decision === 'reject' && (!b.reason || b.reason.length < 5)) throw Errors.reasonRequired('Từ chối tăng ca phải có lý do cụ thể');
    const status = b.decision === 'confirm' ? 'confirmed' : 'rejected';
    await tx(async (c) => {
      await q(`UPDATE overtime_records SET approval_status=$2, reviewer_id=$3, review_reason=$4, reviewed_at=now() WHERE id=$1`, [id, status, ctx.memberId, b.reason ?? null], c);
      await audit(c, ctx, 'overtime', id, 'overtime.' + status, { approval_status: 'pending' }, { approval_status: status }, b.reason ?? null);
      await notify(c, { companyId: ctx.companyId, memberIds: [o.member_id], type: 'overtime.' + status,
        title: status === 'confirmed' ? 'Bản ghi tăng ca đã được xác nhận' : 'Bản ghi tăng ca bị từ chối', body: b.reason, refType: 'overtime', refId: id });
    });
    return this.get(id, ctx);
  }
}
