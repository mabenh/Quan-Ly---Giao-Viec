import { Controller, Get, Param, Patch, Post, Query } from '@nestjs/common';
import { q, q1 } from '../db/db';
import { CurrentCtx, Ctx } from '../common/context';
import { Errors } from '../common/errors';

@Controller('notifications')
export class NotificationsController {
  @Get()
  async list(@CurrentCtx() ctx: Ctx, @Query('unread') unread?: string, @Query('limit') limit = '50', @Query('before') before?: string) {
    const items = await q(
      `SELECT id, type, title, body, reference_type, reference_id, read_at, created_at FROM notifications
        WHERE member_id=$1 AND ($2::boolean IS NOT TRUE OR read_at IS NULL) AND ($4::timestamptz IS NULL OR created_at < $4)
        ORDER BY created_at DESC LIMIT $3`, [ctx.memberId, unread === 'true', Math.min(Number(limit) || 50, 200), before || null]);
    const c = await q1(`SELECT count(*)::int AS n FROM notifications WHERE member_id=$1 AND read_at IS NULL`, [ctx.memberId]);
    return { items, unread: c.n };
  }

  @Patch(':id/read')
  async read(@Param('id') id: string, @CurrentCtx() ctx: Ctx) {
    const r = await q1(`UPDATE notifications SET read_at=COALESCE(read_at, now()) WHERE id=$1 AND member_id=$2 RETURNING id`, [id, ctx.memberId]);
    if (!r) throw Errors.notFound('Thông báo');
    return { ok: true };
  }

  @Post('read-all')
  async readAll(@CurrentCtx() ctx: Ctx) {
    await q(`UPDATE notifications SET read_at=now() WHERE member_id=$1 AND read_at IS NULL`, [ctx.memberId]);
    return { ok: true };
  }
}
