import { Body, Controller, Get, Param, Post, Query } from '@nestjs/common';
import { PoolClient } from 'pg';
import { q, q1, tx } from '../db/db';
import { AllowNoCompany, Public } from '../common/auth.guard';
import { CurrentCtx, Ctx } from '../common/context';
import { AppError, Errors } from '../common/errors';
import { parse, z } from '../common/validate';
import { audit } from '../common/audit';
import { notify } from '../common/notify';
import { PLANS, activationMode } from './plans';
import { createCompanyForUser } from './auth.controller';

async function activate(c: PoolClient, subId: string, byUserId: string | null, paymentRef?: string) {
  const s = await q1(`SELECT * FROM subscriptions WHERE id=$1 FOR UPDATE`, [subId], c);
  if (!s) throw Errors.notFound('Yêu cầu nâng cấp');
  if (s.status !== 'pending_payment') throw Errors.invalidState('Yêu cầu đã được xử lý');
  let companyId = s.company_id;
  if (companyId) {
    const used = await q1(`SELECT count(*)::int AS n FROM company_members WHERE company_id=$1 AND status IN ('active','pending_hr')`, [companyId], c);
    if (used.n > s.member_limit) throw new AppError('PLAN_TOO_SMALL', `Công ty đang có ${used.n} thành viên, vượt hạn mức gói (${s.member_limit})`, 409);
    await q(`UPDATE companies SET plan=$2, member_limit=$3, contact_email=$4, name=$5, plan_expires_at=GREATEST(COALESCE(plan_expires_at, now()), now()) + make_interval(months => $6) WHERE id=$1`,
      [companyId, s.plan, s.member_limit, s.contact_email, s.company_name, s.months], c);
  } else {
    companyId = (await createCompanyForUser(c, s.user_id, { companyName: s.company_name, contactEmail: s.contact_email, plan: s.plan })).companyId;
  }
  await q(`UPDATE subscriptions SET status='active', company_id=$2, activated_by=$3, activated_at=now(), payment_ref=COALESCE($4, payment_ref) WHERE id=$1`,
    [subId, companyId, byUserId, paymentRef ?? null], c);
  return companyId;
}

@Controller()
export class SubscriptionsController {
  @Public()
  @Get('plans')
  plans() {
    return { plans: Object.values(PLANS), activation: activationMode(), payment_instructions: process.env.PAYMENT_INSTRUCTIONS || null };
  }

  /** Chủ doanh nghiệp mua gói: tên công ty, email liên hệ. Nâng cấp công ty hiện có nếu truyền companyId (phải là Owner). */
  @AllowNoCompany()
  @Post('subscriptions')
  async create(@Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({
      plan: z.enum(['small', 'medium', 'large']), companyName: z.string().trim().min(2, 'Nhập tên công ty'),
      contactEmail: z.string().email('Email liên hệ không hợp lệ'), companyId: z.string().uuid().optional(),
    }), body);
    if (b.companyId) {
      const own = await q1(`SELECT 1 FROM company_members WHERE company_id=$1 AND user_id=$2 AND role='owner' AND status='active'`, [b.companyId, ctx.userId]);
      if (!own) throw Errors.forbidden('Chỉ chủ doanh nghiệp (Owner) được nâng cấp gói');
    }
    const p = PLANS[b.plan];
    return tx(async (c) => {
      const pend = await q1(`SELECT id FROM subscriptions WHERE user_id=$1 AND status='pending_payment'`, [ctx.userId], c);
      if (pend) throw new AppError('SUBSCRIPTION_PENDING', 'Bạn đang có một yêu cầu nâng cấp chờ thanh toán', 409, { id: pend.id });
      const s = await q1(
        `INSERT INTO subscriptions(user_id, company_id, plan, company_name, contact_email, member_limit, price_vnd, months)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *`,
        [ctx.userId, b.companyId ?? null, b.plan, b.companyName, b.contactEmail, p.member_limit, p.price_vnd, p.months], c);
      let companyId: string | null = null;
      if (activationMode() === 'auto') companyId = await activate(c, s.id, null, 'TRIAL-AUTO');
      const out = await q1(`SELECT * FROM subscriptions WHERE id=$1`, [s.id], c);
      return { subscription: out, company_id: companyId, activation: activationMode() };
    });
  }

  @AllowNoCompany()
  @Get('subscriptions/mine')
  async mine(@CurrentCtx() ctx: Ctx) {
    return q(`SELECT * FROM subscriptions WHERE user_id=$1 ORDER BY created_at DESC`, [ctx.userId]);
  }

  @AllowNoCompany()
  @Post('subscriptions/:id/cancel')
  async cancel(@Param('id') id: string, @CurrentCtx() ctx: Ctx) {
    const r = await q1(`UPDATE subscriptions SET status='cancelled' WHERE id=$1 AND user_id=$2 AND status='pending_payment' RETURNING id`, [id, ctx.userId]);
    if (!r) throw Errors.invalidState('Không thể hủy yêu cầu này');
    return { ok: true };
  }

  // ---------- Quản trị nền tảng (xác nhận thanh toán) ----------
  private assertPlatform(ctx: Ctx) { if (!ctx.isPlatformAdmin) throw Errors.forbidden('Chỉ quản trị nền tảng Việc Đến'); }

  @AllowNoCompany()
  @Get('platform/subscriptions')
  async list(@CurrentCtx() ctx: Ctx, @Query('status') status?: string) {
    this.assertPlatform(ctx);
    return q(`SELECT s.*, u.name AS user_name, u.phone FROM subscriptions s JOIN users u ON u.id=s.user_id
               WHERE ($1::text IS NULL OR s.status=$1) ORDER BY s.created_at DESC LIMIT 300`, [status || null]);
  }

  @AllowNoCompany()
  @Post('platform/subscriptions/:id/activate')
  async activateSub(@Param('id') id: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    this.assertPlatform(ctx);
    const b = parse(z.object({ paymentRef: z.string().trim().min(2, 'Nhập mã giao dịch thanh toán') }), body);
    const companyId = await tx(async (c) => {
      const cid = await activate(c, id, ctx.userId, b.paymentRef);
      const s = await q1(`SELECT user_id FROM subscriptions WHERE id=$1`, [id], c);
      const owner = await q1(`SELECT id FROM company_members WHERE company_id=$1 AND user_id=$2`, [cid, s.user_id], c);
      if (owner) await notify(c, { companyId: cid, memberIds: [owner.id], type: 'subscription.active', title: 'Gói doanh nghiệp đã được kích hoạt' });
      await audit(c, { companyId: cid, memberId: null }, 'company', cid, 'subscription.activated', null, { subscription: id, payment_ref: b.paymentRef });
      return cid;
    });
    return { ok: true, company_id: companyId };
  }

  @AllowNoCompany()
  @Post('platform/subscriptions/:id/reject')
  async reject(@Param('id') id: string, @CurrentCtx() ctx: Ctx) {
    this.assertPlatform(ctx);
    const r = await q1(`UPDATE subscriptions SET status='rejected' WHERE id=$1 AND status='pending_payment' RETURNING id`, [id]);
    if (!r) throw Errors.invalidState('Không thể từ chối yêu cầu này');
    return { ok: true };
  }
}
