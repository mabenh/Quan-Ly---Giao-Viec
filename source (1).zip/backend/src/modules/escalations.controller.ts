import { Body, Controller, Get, Param, Post, Query } from '@nestjs/common';
import { q, q1, tx } from '../db/db';
import { CurrentCtx, Ctx, isAdmin } from '../common/context';
import { Errors } from '../common/errors';
import { parse, z } from '../common/validate';
import { audit } from '../common/audit';

@Controller('escalations')
export class EscalationsController {
  @Get()
  async list(@CurrentCtx() ctx: Ctx, @Query('status') status = 'open', @Query('scope') scope = 'mine') {
    return q(
      `SELECT e.*, fu.name AS from_name, tu.name AS to_name,
              COALESCE(w.code, NULL) AS report_code, COALESCE(w.description, r.title) AS subject
         FROM escalations e
         LEFT JOIN company_members f ON f.id=e.from_member_id LEFT JOIN users fu ON fu.id=f.user_id
         JOIN company_members t ON t.id=e.to_member_id JOIN users tu ON tu.id=t.user_id
         LEFT JOIN workplace_reports w ON e.parent_type='workplace_report' AND w.id=e.parent_id
         LEFT JOIN employee_work_records r ON e.parent_type='work_record' AND r.id=e.parent_id
        WHERE e.company_id=$1 AND ($2='all' OR e.status=$2) AND (($3='all' AND $4::boolean) OR e.to_member_id=$5)
        ORDER BY e.created_at DESC LIMIT 300`, [ctx.companyId, status, scope, isAdmin(ctx), ctx.memberId]);
  }

  /** Người nhận chuyển cấp ghi nhận cách xử lý (việc xử lý nghiệp vụ thực hiện trên hồ sơ gốc). */
  @Post(':id/resolve')
  async resolve(@Param('id') id: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({ resolution: z.string().trim().min(5, 'Cần mô tả cách xử lý') }), body);
    return tx(async (c) => {
      const e = await q1(`SELECT * FROM escalations WHERE id=$1 AND company_id=$2 FOR UPDATE`, [id, ctx.companyId], c);
      if (!e) throw Errors.notFound('Chuyển cấp');
      if (e.to_member_id !== ctx.memberId && !isAdmin(ctx)) throw Errors.forbidden();
      if (e.status !== 'open') throw Errors.invalidState('Chuyển cấp đã được xử lý');
      await q(`UPDATE escalations SET status='resolved', resolution=$2, resolved_by=$3, resolved_at=now() WHERE id=$1`, [id, b.resolution, ctx.memberId], c);
      await audit(c, ctx, e.parent_type, e.parent_id, 'escalation.resolved', null, { escalation: id }, b.resolution);
      return { ok: true };
    });
  }
}
