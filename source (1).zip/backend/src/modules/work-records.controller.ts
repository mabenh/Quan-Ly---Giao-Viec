import { Body, Controller, Get, Param, Post, Query } from '@nestjs/common';
import { PoolClient } from 'pg';
import { DateTime } from 'luxon';
import { getPool, q, q1, tx } from '../db/db';
import { CurrentCtx, Ctx, isAdmin } from '../common/context';
import { AppError, Errors } from '../common/errors';
import { parse, z } from '../common/validate';
import { escalationChain, getCompany, getGroup, getMember } from '../common/access';
import { audit } from '../common/audit';
import { notify } from '../common/notify';
import { addWorkingMinutes } from '../common/calendar';
import { openEscalationTargets, resolveOpenEscalations } from './escalation';

const SELECT = `
  SELECT r.*, u.name AS employee_name, ru.name AS requester_name, vu.name AS reviewer_name, g.name AS group_name
    FROM employee_work_records r
    JOIN company_members cm ON cm.id=r.employee_id JOIN users u ON u.id=cm.user_id
    LEFT JOIN company_members rcm ON rcm.id=r.requester_member_id LEFT JOIN users ru ON ru.id=rcm.user_id
    LEFT JOIN company_members vcm ON vcm.id=r.reviewer_member_id LEFT JOIN users vu ON vu.id=vcm.user_id
    LEFT JOIN groups g ON g.id=r.group_id`;

const AWAITING_REVIEW = ['submitted', 'disputed'];

async function reviewDue(companyId: string, db: any): Promise<Date> {
  const c = await getCompany(companyId, db);
  return addWorkingMinutes(new Date(), c.settings.policies.workRecordReviewMinutes, c.settings.calendar, c.timezone);
}

/** Người xác nhận mặc định: quản lý nhóm liên quan -> cấp trên trực tiếp -> Admin/Owner. */
async function defaultReviewer(ctx: Ctx, employeeId: string, groupId: string | null, db: any): Promise<string> {
  if (groupId) {
    const g = await q1(`SELECT manager_member_id FROM groups WHERE id=$1`, [groupId], db);
    if (g && g.manager_member_id !== employeeId) return g.manager_member_id;
  }
  const chain = await escalationChain(ctx.companyId, employeeId, db);
  const first = chain.find((m) => m !== employeeId);
  if (!first) throw new AppError('NO_REVIEWER', 'Chưa cấu hình người xác nhận (quản lý/cấp trên) cho nhân viên này', 422);
  return first;
}

@Controller('work-records')
export class WorkRecordsController {
  private async load(ctx: Ctx, id: string, db: any = getPool()) {
    const r = await q1(`${SELECT} WHERE r.id=$1 AND r.company_id=$2`, [id, ctx.companyId], db);
    if (!r) throw Errors.notFound('Bản ghi công việc');
    return r;
  }

  private async roles(ctx: Ctx, r: any, db: any = getPool()) {
    const escalated = await openEscalationTargets('work_record', r.id, db);
    const appeal = await q1(`SELECT * FROM work_record_appeals WHERE work_record_id=$1 AND status='open' ORDER BY created_at DESC LIMIT 1`, [r.id], db);
    const isEmployee = r.employee_id === ctx.memberId;
    const isReviewer = !isEmployee && (r.reviewer_member_id === ctx.memberId || escalated.includes(ctx.memberId) || isAdmin(ctx));
    const isAppealReviewer = !!appeal && (appeal.reviewer_id === ctx.memberId || (isAdmin(ctx) && appeal.respondent_id !== ctx.memberId && !isEmployee));
    let isGroupManager = false;
    if (r.group_id) {
      const g = await q1(`SELECT manager_member_id FROM groups WHERE id=$1`, [r.group_id], db);
      isGroupManager = g?.manager_member_id === ctx.memberId;
    }
    const pastAppeal = await q1(`SELECT 1 FROM work_record_appeals WHERE work_record_id=$1 AND (reviewer_id=$2 OR respondent_id=$2)`, [r.id, ctx.memberId], db);
    const canView = isEmployee || isReviewer || isAppealReviewer || isGroupManager || !!pastAppeal;
    return { isEmployee, isReviewer, isAppealReviewer, appeal, canView };
  }

  @Get()
  async list(@CurrentCtx() ctx: Ctx, @Query() qs: any) {
    const f = parse(z.object({ scope: z.enum(['mine', 'review', 'all']).default('mine'), status: z.string().optional(), employeeId: z.string().uuid().optional() }), qs);
    const params: any[] = [ctx.companyId, ctx.memberId];
    const where = ['r.company_id=$1', '$2::uuid IS NOT NULL'];
    if (f.scope === 'mine') where.push('r.employee_id=$2');
    else if (f.scope === 'review') {
      where.push(`r.employee_id<>$2 AND (r.reviewer_member_id=$2
        OR EXISTS (SELECT 1 FROM escalations e WHERE e.parent_type='work_record' AND e.parent_id=r.id AND e.to_member_id=$2 AND e.status='open')
        OR EXISTS (SELECT 1 FROM work_record_appeals a WHERE a.work_record_id=r.id AND a.reviewer_id=$2 AND a.status='open'))`);
    } else if (!isAdmin(ctx)) {
      where.push(`(r.employee_id=$2 OR r.reviewer_member_id=$2 OR EXISTS (SELECT 1 FROM groups g2 WHERE g2.id=r.group_id AND g2.manager_member_id=$2)
        OR EXISTS (SELECT 1 FROM escalations e WHERE e.parent_type='work_record' AND e.parent_id=r.id AND e.to_member_id=$2)
        OR EXISTS (SELECT 1 FROM work_record_appeals a WHERE a.work_record_id=r.id AND (a.reviewer_id=$2 OR a.respondent_id=$2)))`);
    }
    if (f.status) { params.push(f.status.split(',')); where.push(`r.status = ANY($${params.length}::text[])`); }
    if (f.employeeId) { params.push(f.employeeId); where.push(`r.employee_id=$${params.length}`); }
    return q(`${SELECT} WHERE ${where.join(' AND ')} ORDER BY r.created_at DESC LIMIT 500`, params);
  }

  @Post()
  async create(@Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({
      title: z.string().trim().min(3, 'Tên/nội dung công việc là bắt buộc'), description: z.string().optional(),
      groupId: z.string().uuid().optional().nullable(),
      requesterMemberId: z.string().uuid().optional().nullable(), requesterUnknownNote: z.string().trim().optional(),
      startAt: z.coerce.date(), endAt: z.coerce.date(), isEstimated: z.boolean().default(false),
      recordType: z.enum(['assigned_outside', 'missing', 'after_hours', 'support', 'other']),
      result: z.string().trim().min(3, 'Kết quả đã thực hiện là bắt buộc'), completionStatus: z.enum(['done', 'partial', 'in_progress']).default('done'),
      reasonNotInSystem: z.string().trim().min(5, 'Lý do chưa có trên hệ thống là bắt buộc'),
      relatedTaskId: z.string().uuid().optional().nullable(),
    }), body);
    if (b.endAt <= b.startAt) throw Errors.validation('Giờ kết thúc phải sau giờ bắt đầu');
    if (!b.requesterMemberId && (!b.requesterUnknownNote || b.requesterUnknownNote.length < 3)) {
      throw Errors.validation('Chọn người giao/yêu cầu, hoặc chọn "không rõ" và giải thích');
    }
    if (b.requesterMemberId) await getMember(ctx, b.requesterMemberId);
    if (b.groupId) await getGroup(ctx, b.groupId);
    if (b.relatedTaskId) {
      const t = await q1(`SELECT id FROM tasks WHERE id=$1 AND company_id=$2`, [b.relatedTaskId, ctx.companyId]);
      if (!t) throw Errors.notFound('Nhiệm vụ liên quan');
    }
    const company = await getCompany(ctx.companyId);
    const minutes = Math.round((b.endAt.getTime() - b.startAt.getTime()) / 60000);
    const workDate = DateTime.fromJSDate(b.startAt, { zone: company.timezone }).toISODate();
    const id = await tx(async (c) => {
      const reviewer = await defaultReviewer(ctx, ctx.memberId, b.groupId ?? null, c);
      const due = await reviewDue(ctx.companyId, c);
      // Phát hiện khai báo trùng thời gian với bản ghi khác của chính nhân viên
      const overlaps = await q(
        `SELECT id FROM employee_work_records WHERE employee_id=$1 AND tstzrange(start_at,end_at) && tstzrange($2,$3)
            AND NOT (status='resolved' AND final_decision='rejected')`, [ctx.memberId, b.startAt, b.endAt], c);
      const r = await q1(
        `INSERT INTO employee_work_records(company_id, employee_id, group_id, title, description, requester_member_id, requester_unknown_note,
            work_date, start_at, end_at, is_estimated, claimed_minutes, record_type, result, completion_status, reason_not_in_system, related_task_id,
            reviewer_member_id, review_due_at, overlap_warning)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20) RETURNING id`,
        [ctx.companyId, ctx.memberId, b.groupId ?? null, b.title, b.description ?? null, b.requesterMemberId ?? null, b.requesterUnknownNote ?? null,
         workDate, b.startAt, b.endAt, b.isEstimated, minutes, b.recordType, b.result, b.completionStatus, b.reasonNotInSystem, b.relatedTaskId ?? null,
         reviewer, due, overlaps.length > 0], c);
      if (overlaps.length) await q(`UPDATE employee_work_records SET overlap_warning=true WHERE id = ANY($1::uuid[])`, [overlaps.map((o) => o.id)], c);
      await audit(c, ctx, 'work_record', r.id, 'work_record.submitted', null, { minutes, reviewer, overlap: overlaps.length > 0 });
      await notify(c, { companyId: ctx.companyId, memberIds: [reviewer], type: 'work_record.submitted',
        title: `${ctx.name} gửi bản ghi công việc cần xác nhận`, body: b.title, refType: 'work_record', refId: r.id });
      return r.id;
    });
    return this.detail(id, ctx);
  }

  @Get(':id')
  async detail(@Param('id') id: string, @CurrentCtx() ctx: Ctx) {
    const r = await this.load(ctx, id);
    const roles = await this.roles(ctx, r);
    if (!roles.canView && !isAdmin(ctx)) throw Errors.notFound('Bản ghi công việc');
    const [reviews, disputes, appeals, escalations, files, overlaps] = await Promise.all([
      q(`SELECT v.*, u.name AS reviewer_name FROM work_record_reviews v JOIN company_members cm ON cm.id=v.reviewer_id JOIN users u ON u.id=cm.user_id
          WHERE v.work_record_id=$1 ORDER BY v.created_at`, [id]),
      q(`SELECT d.*, u.name AS employee_name FROM work_record_disputes d JOIN company_members cm ON cm.id=d.employee_id JOIN users u ON u.id=cm.user_id
          WHERE d.work_record_id=$1 ORDER BY d.created_at`, [id]),
      q(`SELECT a.*, ru.name AS reviewer_name, pu.name AS respondent_name FROM work_record_appeals a
           JOIN company_members rcm ON rcm.id=a.reviewer_id JOIN users ru ON ru.id=rcm.user_id
           LEFT JOIN company_members pcm ON pcm.id=a.respondent_id LEFT JOIN users pu ON pu.id=pcm.user_id
          WHERE a.work_record_id=$1 ORDER BY a.created_at`, [id]),
      q(`SELECT e.*, fu.name AS from_name, tu.name AS to_name FROM escalations e
           LEFT JOIN company_members f ON f.id=e.from_member_id LEFT JOIN users fu ON fu.id=f.user_id
           JOIN company_members t ON t.id=e.to_member_id JOIN users tu ON tu.id=t.user_id
          WHERE e.parent_type='work_record' AND e.parent_id=$1 ORDER BY e.created_at`, [id]),
      q(`SELECT id, filename, mime, size, created_at FROM files WHERE parent_type='work_record' AND parent_id=$1 ORDER BY created_at`, [id]),
      r.overlap_warning ? q(`SELECT id, title, start_at, end_at, status FROM employee_work_records WHERE employee_id=$1 AND id<>$2
          AND tstzrange(start_at,end_at) && tstzrange($3,$4)`, [r.employee_id, id, r.start_at, r.end_at]) : Promise.resolve([]),
    ]);
    const company = await getCompany(ctx.companyId);
    const threshold = company.settings.policies.appealThreshold;
    const lastReview = reviews[reviews.length - 1];
    const pendingResponse = ['rejected', 'partially_accepted'].includes(r.status);
    const canAppealByCount = (r.status === 'disputed' && r.consecutive_rejections >= threshold)
      || (pendingResponse && r.consecutive_rejections + 1 >= threshold);
    const timeline = [
      ...reviews.map((x) => ({ type: 'review', at: x.created_at, ...x })),
      ...disputes.map((x) => ({ type: 'response', at: x.created_at, ...x })),
      ...appeals.map((x) => ({ type: 'appeal', at: x.created_at, ...x })),
      ...escalations.map((x) => ({ type: 'escalation', at: x.created_at, ...x })),
    ].sort((a, b) => new Date(a.at).getTime() - new Date(b.at).getTime());
    return {
      ...r, reviews, disputes, appeals, escalations, files, overlaps, timeline, appeal_threshold: threshold,
      last_review: lastReview ?? null,
      permissions: {
        can_review: roles.isReviewer && AWAITING_REVIEW.includes(r.status),
        can_respond: roles.isEmployee && (pendingResponse || r.status === 'needs_information'),
        can_appeal: roles.isEmployee && (pendingResponse || r.status === 'disputed'),
        can_appeal_by_count: roles.isEmployee && canAppealByCount,
        can_resolve_appeal: roles.isAppealReviewer && r.status === 'appealed',
        open_appeal_id: roles.appeal?.id ?? null,
      },
    };
  }

  // ---------- Quản lý xác nhận / xác nhận một phần / từ chối / yêu cầu bổ sung ----------
  @Post(':id/reviews')
  async review(@Param('id') id: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({
      decision: z.enum(['accept', 'partial', 'reject', 'needs_info']),
      reason: z.string().trim().optional(), basis: z.string().trim().optional(), relatedPeriod: z.string().trim().optional(),
      acceptedMinutes: z.number().int().min(0).optional(), acceptedScope: z.string().trim().optional(), rejectedScope: z.string().trim().optional(),
    }), body);
    return tx(async (c) => {
      await c.query(`SELECT 1 FROM employee_work_records WHERE id=$1 FOR UPDATE`, [id]);
      const r = await this.load(ctx, id, c);
      const roles = await this.roles(ctx, r, c);
      if (!roles.isReviewer) throw Errors.forbidden('Bạn không phải người xác nhận bản ghi này');
      if (!AWAITING_REVIEW.includes(r.status)) throw Errors.invalidState('Bản ghi không ở trạng thái chờ xác nhận');
      let status: string; let acceptedMinutes: number | null = null; let rejectionNo: number | null = null;
      switch (b.decision) {
        case 'accept':
          status = 'accepted'; acceptedMinutes = r.claimed_minutes; break;
        case 'partial':
          if (!b.reason || b.reason.length < 10) throw Errors.reasonRequired('Xác nhận một phần phải nêu lý do cụ thể (≥10 ký tự)');
          if (b.acceptedMinutes === undefined || b.acceptedMinutes <= 0 || b.acceptedMinutes >= r.claimed_minutes) {
            throw Errors.validation('Số phút được chấp nhận phải lớn hơn 0 và nhỏ hơn thời lượng khai báo');
          }
          if (!b.acceptedScope || !b.rejectedScope) throw Errors.validation('Phải nêu rõ phần được chấp nhận và phần bị từ chối');
          status = 'partially_accepted'; acceptedMinutes = b.acceptedMinutes; rejectionNo = r.consecutive_rejections + 1; break;
        case 'reject':
          if (!b.reason || b.reason.length < 10) throw Errors.reasonRequired('Từ chối bắt buộc có lý do cụ thể (≥10 ký tự)');
          if (!b.basis || b.basis.length < 3) throw Errors.validation('Từ chối phải nêu căn cứ (dữ liệu/quy định xác minh)');
          status = 'rejected'; acceptedMinutes = 0; rejectionNo = r.consecutive_rejections + 1; break;
        case 'needs_info':
          if (!b.reason || b.reason.length < 10) throw Errors.reasonRequired('Yêu cầu bổ sung phải nêu rõ thông tin còn thiếu');
          status = 'needs_information'; break;
      }
      const v = await q1(
        `INSERT INTO work_record_reviews(work_record_id, reviewer_id, decision, reason, basis, related_period, accepted_minutes, accepted_scope, rejected_scope, chain_no, rejection_no)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11) RETURNING id`,
        [id, ctx.memberId, b.decision, b.reason ?? null, b.basis ?? null, b.relatedPeriod ?? null, acceptedMinutes, b.acceptedScope ?? null,
         b.rejectedScope ?? null, r.chain_no, rejectionNo], c);
      const final = status === 'accepted';
      await q(`UPDATE employee_work_records SET status=$2, accepted_minutes=COALESCE($3, accepted_minutes), review_due_at=NULL, overdue=false,
                 final_decision=CASE WHEN $4 THEN 'accepted' ELSE final_decision END,
                 consecutive_rejections=CASE WHEN $4 THEN 0 ELSE consecutive_rejections END, updated_at=now() WHERE id=$1`,
        [id, status, acceptedMinutes, final], c);
      await resolveOpenEscalations(c, 'work_record', id, ctx.memberId, `Đã phản hồi: ${b.decision}`);
      await audit(c, ctx, 'work_record', id, 'work_record.review.' + b.decision, { status: r.status }, { status, accepted_minutes: acceptedMinutes, review_id: v.id }, b.reason ?? null);
      const titles: Record<string, string> = {
        accept: 'Bản ghi công việc đã được xác nhận', partial: 'Bản ghi công việc được xác nhận một phần',
        reject: 'Bản ghi công việc bị từ chối', needs_info: 'Quản lý yêu cầu bổ sung thông tin cho bản ghi công việc',
      };
      await notify(c, { companyId: ctx.companyId, memberIds: [r.employee_id], type: 'work_record.review.' + b.decision,
        title: titles[b.decision], body: `${r.title}${b.reason ? ' — ' + b.reason : ''}`, refType: 'work_record', refId: id });
      return { id: v.id, status };
    }).then(() => this.detail(id, ctx));
  }

  // ---------- Nhân viên phản hồi: chấp nhận / không chấp nhận (tranh chấp) / bổ sung thông tin ----------
  @Post(':id/disputes')
  async respond(@Param('id') id: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({ response: z.enum(['accept', 'dispute', 'supplement']), comment: z.string().trim().optional() }), body);
    await tx(async (c) => {
      await c.query(`SELECT 1 FROM employee_work_records WHERE id=$1 FOR UPDATE`, [id]);
      const r = await this.load(ctx, id, c);
      if (r.employee_id !== ctx.memberId) throw Errors.forbidden('Chỉ nhân viên tạo bản ghi được phản hồi');
      const last = await q1(`SELECT * FROM work_record_reviews WHERE work_record_id=$1 ORDER BY created_at DESC LIMIT 1`, [id], c);
      const company = await getCompany(ctx.companyId, c);
      let next: any = {};
      if (b.response === 'supplement') {
        if (r.status !== 'needs_information') throw Errors.invalidState('Chỉ bổ sung khi quản lý yêu cầu bổ sung thông tin');
        if (!b.comment || b.comment.length < 5) throw Errors.validation('Nội dung bổ sung là bắt buộc');
        next = { status: 'submitted', review_due_at: await reviewDue(ctx.companyId, c), sla_inc: 1 };
      } else {
        if (!['rejected', 'partially_accepted'].includes(r.status)) throw Errors.invalidState('Không có quyết định từ chối nào đang chờ bạn phản hồi');
        if (b.response === 'accept') {
          next = { status: 'resolved', final_decision: r.status === 'rejected' ? 'rejected' : 'partially_accepted',
            consecutive_rejections: company.settings.policies.resetChainOnAccept ? 0 : r.consecutive_rejections };
        } else {
          if (!b.comment || b.comment.length < 10) throw Errors.validation('Khi không chấp nhận lý do, hãy nêu ý kiến/bằng chứng (≥10 ký tự)');
          // Chỉ tăng bộ đếm khi quản lý thực sự từ chối (kể cả một phần) và nhân viên không chấp nhận
          next = { status: 'disputed', consecutive_rejections: r.consecutive_rejections + 1, review_due_at: await reviewDue(ctx.companyId, c), sla_inc: 1 };
        }
      }
      await q(`INSERT INTO work_record_disputes(work_record_id, employee_id, review_id, response, comment) VALUES ($1,$2,$3,$4,$5)`,
        [id, ctx.memberId, last?.id ?? null, b.response, b.comment ?? null], c);
      await q(`UPDATE employee_work_records SET status=$2, final_decision=COALESCE($3, final_decision),
                 consecutive_rejections=COALESCE($4, consecutive_rejections), review_due_at=$5, sla_cycle=sla_cycle+$6, overdue=false,
                 escalation_level=CASE WHEN $6>0 THEN 0 ELSE escalation_level END, updated_at=now() WHERE id=$1`,
        [id, next.status, next.final_decision ?? null, next.consecutive_rejections ?? null, next.review_due_at ?? null, next.sla_inc ?? 0], c);
      await audit(c, ctx, 'work_record', id, 'work_record.response.' + b.response, { status: r.status, rejections: r.consecutive_rejections },
        { status: next.status, rejections: next.consecutive_rejections ?? r.consecutive_rejections }, b.comment ?? null);
      if (next.status !== 'resolved') {
        const threshold = company.settings.policies.appealThreshold;
        const extra = next.status === 'disputed' && next.consecutive_rejections >= threshold ? ` (đã ${next.consecutive_rejections} lần từ chối liên tiếp — nhân viên có quyền khiếu nại)` : '';
        await notify(c, { companyId: ctx.companyId, memberIds: [r.reviewer_member_id, ...(await openEscalationTargets('work_record', id, c))],
          excludeMemberId: ctx.memberId, type: 'work_record.' + next.status,
          title: b.response === 'supplement' ? `${ctx.name} đã bổ sung thông tin bản ghi công việc` : `${ctx.name} không chấp nhận lý do từ chối${extra}`,
          body: b.comment, refType: 'work_record', refId: id });
      }
    });
    return this.detail(id, ctx);
  }

  // ---------- Khiếu nại lên cấp cao hơn ----------
  @Post(':id/appeals')
  async appeal(@Param('id') id: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({
      reason: z.string().trim().min(10, 'Nội dung khiếu nại cần tối thiểu 10 ký tự'),
      early: z.boolean().default(false),
      earlyReason: z.enum(['conflict_of_interest', 'pressure', 'respondent_is_decider', 'other']).optional(),
      earlyDetail: z.string().trim().optional(),
    }), body);
    await tx(async (c) => {
      await c.query(`SELECT 1 FROM employee_work_records WHERE id=$1 FOR UPDATE`, [id]);
      const r = await this.load(ctx, id, c);
      if (r.employee_id !== ctx.memberId) throw Errors.forbidden('Chỉ nhân viên tạo bản ghi được khiếu nại');
      const company = await getCompany(ctx.companyId, c);
      const threshold = company.settings.policies.appealThreshold;
      const pending = ['rejected', 'partially_accepted'].includes(r.status);
      if (!pending && r.status !== 'disputed') throw Errors.invalidState('Chỉ khiếu nại khi có quyết định từ chối/xác nhận một phần đang tranh chấp');
      // Từ chối đang chờ phản hồi: việc khiếu nại đồng nghĩa không chấp nhận -> tính vào bộ đếm
      const effectiveCount = pending ? r.consecutive_rejections + 1 : r.consecutive_rejections;
      if (effectiveCount < threshold) {
        if (!b.early || !b.earlyReason) {
          throw new AppError('APPEAL_THRESHOLD_NOT_MET',
            `Quyền khiếu nại mở từ lần từ chối thứ ${threshold} liên tiếp (hiện tại ${effectiveCount}). Có thể khiếu nại sớm nếu có xung đột lợi ích/gây sức ép.`, 409);
        }
        if (!b.earlyDetail || b.earlyDetail.length < 10) throw Errors.validation('Khiếu nại sớm phải mô tả căn cứ (xung đột lợi ích/gây sức ép...)');
      }
      const last = await q1(`SELECT reviewer_id FROM work_record_reviews WHERE work_record_id=$1 AND decision IN ('reject','partial') ORDER BY created_at DESC LIMIT 1`, [id], c);
      const respondent = last?.reviewer_id ?? r.reviewer_member_id;
      const reviewer = await this.pickAppealReviewer(c, ctx.companyId, respondent, r.employee_id);
      if (pending) {
        const lr = await q1(`SELECT id FROM work_record_reviews WHERE work_record_id=$1 ORDER BY created_at DESC LIMIT 1`, [id], c);
        await q(`INSERT INTO work_record_disputes(work_record_id, employee_id, review_id, response, comment) VALUES ($1,$2,$3,'dispute',$4)`,
          [id, ctx.memberId, lr?.id ?? null, b.reason], c);
      }
      const a = await q1(
        `INSERT INTO work_record_appeals(work_record_id, appellant_id, respondent_id, reviewer_id, reason, early, early_reason)
         VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING id`,
        [id, ctx.memberId, respondent, reviewer, b.reason, effectiveCount < threshold, effectiveCount < threshold ? `${b.earlyReason}: ${b.earlyDetail}` : null], c);
      await q(`UPDATE employee_work_records SET status='appealed', consecutive_rejections=$2, review_due_at=NULL, overdue=false, updated_at=now() WHERE id=$1`,
        [id, effectiveCount], c);
      await resolveOpenEscalations(c, 'work_record', id, ctx.memberId, 'Chuyển sang khiếu nại');
      await audit(c, ctx, 'work_record', id, 'work_record.appealed', { status: r.status }, { status: 'appealed', appeal_id: a.id, reviewer, respondent, rejections: effectiveCount }, b.reason);
      await notify(c, { companyId: ctx.companyId, memberIds: [reviewer], type: 'work_record.appeal',
        title: `Khiếu nại cần giải quyết: ${r.title}`, body: b.reason, refType: 'work_record', refId: id });
      await notify(c, { companyId: ctx.companyId, memberIds: [respondent], excludeMemberId: reviewer, type: 'work_record.appeal_notice',
        title: `Nhân viên đã chuyển khiếu nại: ${r.title}`, refType: 'work_record', refId: id });
    });
    return this.detail(id, ctx);
  }

  /** Cấp giải quyết phải cao hơn người bị khiếu nại; người bị khiếu nại không ra quyết định cuối cùng. */
  private async pickAppealReviewer(c: PoolClient, companyId: string, respondent: string, employeeId: string): Promise<string> {
    const chain = await escalationChain(companyId, respondent, c);
    const pick = chain.find((m) => m !== respondent && m !== employeeId);
    if (pick) return pick;
    // Người bị khiếu nại là cấp cao nhất -> reviewer độc lập hoặc Owner khác
    const indep = await q1(`SELECT id FROM company_members WHERE company_id=$1 AND status='active' AND id<>ALL($2::uuid[])
                              ORDER BY CASE role WHEN 'reviewer' THEN 0 WHEN 'owner' THEN 1 WHEN 'admin' THEN 2 ELSE 9 END, joined_at LIMIT 1`,
      [companyId, [respondent, employeeId]], c);
    if (!indep || !(await q1(`SELECT 1 FROM company_members WHERE id=$1 AND role IN ('reviewer','owner','admin')`, [indep.id], c))) {
      throw new AppError('NO_INDEPENDENT_REVIEWER', 'Chưa có reviewer độc lập/Owner khác để giải quyết khiếu nại. Admin cần bổ sung thành viên vai trò Reviewer.', 422);
    }
    return indep.id;
  }

  @Post(':id/appeals/:appealId/resolve')
  async resolveAppeal(@Param('id') id: string, @Param('appealId') appealId: string, @Body() body: any, @CurrentCtx() ctx: Ctx) {
    const b = parse(z.object({ decision: z.enum(['accept', 'partial', 'reject']), reason: z.string().trim().min(10, 'Quyết định giải quyết phải có lý do (≥10 ký tự)'), acceptedMinutes: z.number().int().min(0).optional() }), body);
    await tx(async (c) => {
      await c.query(`SELECT 1 FROM employee_work_records WHERE id=$1 FOR UPDATE`, [id]);
      const r = await this.load(ctx, id, c);
      const a = await q1(`SELECT * FROM work_record_appeals WHERE id=$1 AND work_record_id=$2`, [appealId, id], c);
      if (!a) throw Errors.notFound('Khiếu nại');
      if (a.status !== 'open') throw Errors.invalidState('Khiếu nại đã được giải quyết');
      if (a.respondent_id === ctx.memberId) throw Errors.forbidden('Người bị khiếu nại không có quyền ra quyết định cuối cùng');
      if (a.reviewer_id !== ctx.memberId && !(isAdmin(ctx) && ctx.memberId !== r.employee_id)) throw Errors.forbidden('Bạn không phải cấp giải quyết khiếu nại này');
      let accepted = 0;
      if (b.decision === 'accept') accepted = r.claimed_minutes;
      if (b.decision === 'partial') {
        if (b.acceptedMinutes === undefined || b.acceptedMinutes <= 0 || b.acceptedMinutes >= r.claimed_minutes) throw Errors.validation('Số phút chấp nhận một phần không hợp lệ');
        accepted = b.acceptedMinutes;
      }
      const final = b.decision === 'accept' ? 'accepted' : b.decision === 'partial' ? 'partially_accepted' : 'rejected';
      await q(`UPDATE work_record_appeals SET decision=$2, decision_reason=$3, accepted_minutes=$4, status='resolved', resolved_at=now() WHERE id=$1`,
        [appealId, b.decision, b.reason, accepted], c);
      await q(`UPDATE employee_work_records SET status='resolved', final_decision=$2, accepted_minutes=$3, updated_at=now() WHERE id=$1`, [id, final, accepted], c);
      await audit(c, ctx, 'work_record', id, 'work_record.appeal_resolved', { status: 'appealed' }, { status: 'resolved', final_decision: final, accepted_minutes: accepted }, b.reason);
      await notify(c, { companyId: ctx.companyId, memberIds: [r.employee_id, a.respondent_id], excludeMemberId: ctx.memberId, type: 'work_record.appeal_resolved',
        title: `Khiếu nại "${r.title}" đã có quyết định cuối cùng`, body: b.reason, refType: 'work_record', refId: id });
    });
    return this.detail(id, ctx);
  }
}
