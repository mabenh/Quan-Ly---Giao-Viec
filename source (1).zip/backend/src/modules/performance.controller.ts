import { Body, Controller, Get, Param, Post, Query, Res } from '@nestjs/common';
import { Response } from 'express';
import { join } from 'path';
import ExcelJS from 'exceljs';
import PDFDocument from 'pdfkit';
import { getPool, q, q1 } from '../db/db';
import { CurrentCtx, Ctx, isAdmin } from '../common/context';
import { Errors } from '../common/errors';
import { parse, z } from '../common/validate';
import { getCompany, getGroup, getMember } from '../common/access';
import { audit } from '../common/audit';
import { buildReport, resolvePeriod, ReportScope } from './performance.service';

const QS = z.object({
  periodType: z.enum(['month', 'quarter', 'year']).default('month'),
  period: z.string().optional(),
  scopeType: z.enum(['company', 'group', 'member']).default('member'),
  scopeId: z.string().uuid().optional(),
});

const OT_LABEL: Record<string, string> = { planned: 'Có kế hoạch', ad_hoc: 'Đột xuất', incident: 'Sự cố', workload: 'Quá tải khối lượng', support: 'Hỗ trợ bộ phận khác' };
const fmt = (x: any) => (x === null || x === undefined ? '—' : String(x));

async function assertScopeAccess(ctx: Ctx, scope: ReportScope) {
  if (isAdmin(ctx)) return;
  if (scope.type === 'company') throw Errors.forbidden('Chỉ Admin/Owner xem báo cáo toàn công ty');
  if (scope.type === 'group') {
    const g = await getGroup(ctx, scope.id!);
    if (g.manager_member_id !== ctx.memberId) throw Errors.forbidden('Bạn chỉ xem báo cáo nhóm mình quản lý');
    return;
  }
  if (scope.id === ctx.memberId) return;
  const m = await getMember(ctx, scope.id!);
  if (m.supervisor_member_id === ctx.memberId) return;
  const managed = await q1(`SELECT 1 FROM groups g JOIN group_members gm ON gm.group_id=g.id
                             WHERE g.manager_member_id=$1 AND gm.company_member_id=$2 AND g.deleted_at IS NULL`, [ctx.memberId, scope.id]);
  if (!managed) throw Errors.forbidden('Nhân viên chỉ xem báo cáo cá nhân của mình');
}

@Controller('performance')
export class PerformanceController {
  private async resolve(ctx: Ctx, qs: any) {
    const f = parse(QS, qs);
    const scope: ReportScope = { type: f.scopeType, id: f.scopeType === 'company' ? null : f.scopeId || (f.scopeType === 'member' ? ctx.memberId : undefined) };
    if (scope.type === 'group' && !scope.id) throw Errors.validation('Cần scopeId của nhóm');
    await assertScopeAccess(ctx, scope);
    const company = await getCompany(ctx.companyId);
    return { period: resolvePeriod(f.periodType, f.period, company.timezone), scope };
  }

  @Get('me')
  async me(@CurrentCtx() ctx: Ctx, @Query() qs: any) {
    const { period } = await this.resolve(ctx, { ...qs, scopeType: 'member', scopeId: ctx.memberId });
    return buildReport(ctx.companyId, period, { type: 'member', id: ctx.memberId });
  }

  @Get('live')
  async live(@CurrentCtx() ctx: Ctx, @Query() qs: any) {
    const { period, scope } = await this.resolve(ctx, qs);
    return buildReport(ctx.companyId, period, scope);
  }

  /** Danh sách snapshot báo cáo đã chốt. */
  @Get('reports')
  async reports(@CurrentCtx() ctx: Ctx) {
    const rows = await q(
      `SELECT p.id, p.period_type, p.period_start, p.period_end, p.scope_type, p.scope_id, p.formula_version, p.created_at, u.name AS created_by_name,
              p.snapshot->'meta'->'period'->>'label' AS label, COALESCE(g.name, su.name) AS scope_name
         FROM performance_reports p JOIN company_members cm ON cm.id=p.created_by JOIN users u ON u.id=cm.user_id
         LEFT JOIN groups g ON p.scope_type='group' AND g.id=p.scope_id
         LEFT JOIN company_members sm ON p.scope_type='member' AND sm.id=p.scope_id LEFT JOIN users su ON su.id=sm.user_id
        WHERE p.company_id=$1 ORDER BY p.created_at DESC LIMIT 200`, [ctx.companyId]);
    const out: any[] = [];
    for (const r of rows) {
      try { await assertScopeAccess(ctx, { type: r.scope_type, id: r.scope_id }); out.push(r); } catch { /* không có quyền */ }
    }
    return out;
  }

  @Get('reports/:id')
  async report(@Param('id') id: string, @CurrentCtx() ctx: Ctx) {
    const r = await q1(`SELECT * FROM performance_reports WHERE id=$1 AND company_id=$2`, [id, ctx.companyId]);
    if (!r) throw Errors.notFound('Báo cáo');
    await assertScopeAccess(ctx, { type: r.scope_type, id: r.scope_id });
    return { ...r.snapshot, snapshot: { id: r.id, created_at: r.created_at, formula_version: r.formula_version } };
  }

  /** Chốt kỳ: lưu snapshot + phiên bản công thức để báo cáo lịch sử không đổi khi cấu hình thay đổi. */
  @Post('reports/finalize')
  async finalize(@Body() body: any, @CurrentCtx() ctx: Ctx) {
    if (!isAdmin(ctx) && ctx.role !== 'manager') throw Errors.forbidden();
    const { period, scope } = await this.resolve(ctx, body);
    const data = await buildReport(ctx.companyId, period, scope);
    const r = await q1(
      `INSERT INTO performance_reports(company_id, period_type, period_start, period_end, scope_type, scope_id, formula_version, snapshot, created_by)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING id, created_at`,
      [ctx.companyId, period.type, period.startDate, period.endDate, scope.type, scope.id ?? null, data.meta.formula_version, JSON.stringify(data), ctx.memberId]);
    await audit(getPool(), ctx, 'performance_report', r.id, 'report.finalized', null, { period: period.key, scope });
    return { id: r.id, created_at: r.created_at };
  }

  @Get('export')
  async export(@CurrentCtx() ctx: Ctx, @Query() qs: any, @Res() res: Response) {
    const format = qs.format === 'pdf' ? 'pdf' : 'xlsx';
    let data: any;
    if (qs.snapshotId) data = await this.report(qs.snapshotId, ctx);
    else { const { period, scope } = await this.resolve(ctx, qs); data = await buildReport(ctx.companyId, period, scope); }
    const name = `bao-cao-${data.meta.scope.type}-${data.meta.period.key}`;
    if (format === 'xlsx') {
      const buf = await toExcel(data);
      res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      res.setHeader('Content-Disposition', `attachment; filename="${name}.xlsx"`);
      res.end(Buffer.from(buf));
    } else {
      res.setHeader('Content-Type', 'application/pdf');
      res.setHeader('Content-Disposition', `attachment; filename="${name}.pdf"`);
      toPdf(data, res);
    }
  }
}

export async function toExcel(d: any) {
  const wb = new ExcelJS.Workbook();
  wb.creator = 'Team Performance App';
  const s0 = wb.addWorksheet('Tổng quan');
  s0.addRows([
    ['Báo cáo', `${d.meta.period.label} — ${d.meta.company}`], ['Phạm vi', d.meta.scope.type], ['Phiên bản công thức', d.meta.formula_version],
    ['Thời điểm tạo', d.meta.generated_at], [],
    ['Nhiệm vụ được giao', d.summary.tasks.assigned], ['Hoàn thành', d.summary.tasks.completed], ['Hủy', d.summary.tasks.cancelled],
    ['Quá hạn', d.summary.tasks.overdue], ['Đang xử lý', d.summary.tasks.in_progress], ['Điểm hiệu suất TB', d.summary.avg_E],
    ['Việc đột xuất - yêu cầu chung (SL / điểm)', `${d.summary.unexpected.common.count} / ${fmt(d.summary.unexpected.common.P)}`],
    ['Việc đột xuất - yêu cầu đa dạng (SL / điểm)', `${d.summary.unexpected.diverse.count} / ${fmt(d.summary.unexpected.diverse.P)}`],
    ['Tổng giờ tăng ca', Math.round(d.summary.overtime_minutes / 6) / 10], ['Báo cáo trở ngại', d.summary.workplace_reports],
    ['Bản ghi tự khai báo (gửi/chấp nhận/một phần/từ chối/tranh chấp/khiếu nại/chưa giải quyết)',
      ['submitted', 'accepted', 'partially_accepted', 'rejected', 'disputed', 'appealed', 'unresolved'].map((k) => d.summary.work_records[k]).join(' / ')],
    [], ['Ghi chú'], ...d.meta.notes.map((n: string) => ['', n]),
  ]);
  s0.getColumn(1).width = 50; s0.getColumn(2).width = 60;
  const s1 = wb.addWorksheet('Nhân viên');
  s1.addRow(['Nhân viên', 'Vai trò', 'E', 'V', 'T', 'Q', 'D', 'R', 'Hoàn thành', 'Điểm việc thường xuyên', 'Điểm việc đột xuất', 'Tỷ lệ đạt lần đầu %', 'Giờ tăng ca', 'Báo cáo trở ngại', 'Bản ghi chưa giải quyết', 'Thiếu dữ liệu']);
  for (const m of d.members) s1.addRow([m.name, m.role, m.E, m.V, m.T, m.Q, m.D, m.R, m.completed_count, m.regular?.P, m.unexpected?.P, m.first_pass_rate,
    Math.round(m.overtime_minutes / 6) / 10, m.workplace_reports, m.work_records.unresolved, m.insufficient_data ? 'Có' : '']);
  s1.getRow(1).font = { bold: true }; s1.columns.forEach((c) => (c.width = 14)); s1.getColumn(1).width = 26;
  if (d.groups?.length) {
    const s2 = wb.addWorksheet('Nhóm');
    s2.addRow(['Nhóm', 'Thành viên', 'Hoàn thành', 'Khối lượng có trọng số', 'Tồn đọng', 'Quá hạn', 'Điểm TB', 'Giờ tăng ca', 'Báo cáo trở ngại']);
    for (const g of d.groups) s2.addRow([g.name, g.member_count, g.completed, g.weighted_volume, g.backlog, g.overdue, g.avg_E, Math.round(g.overtime_minutes / 6) / 10, g.workplace_reports]);
    s2.getRow(1).font = { bold: true }; s2.columns.forEach((c) => (c.width = 16));
  }
  const s3 = wb.addWorksheet('Tăng ca');
  s3.addRow(['Nguyên nhân', 'Giờ']);
  for (const c of d.overtime.by_cause) s3.addRow([OT_LABEL[c.ot_type] || c.ot_type, Math.round(c.minutes / 6) / 10]);
  s3.addRow([]); s3.addRow(['Người yêu cầu', 'Giờ']);
  for (const c of d.overtime.by_requester) s3.addRow([c.requester, Math.round(c.minutes / 6) / 10]);
  s3.getColumn(1).width = 30;
  const s4 = wb.addWorksheet('Trở ngại');
  s4.addRow(['Theo mức độ']); for (const [k, v] of Object.entries(d.workplace.by_severity)) s4.addRow([k, v]);
  s4.addRow(['Theo bộ phận']); for (const [k, v] of Object.entries(d.workplace.by_department)) s4.addRow([k, v]);
  s4.addRow(['Theo trạng thái']); for (const [k, v] of Object.entries(d.workplace.by_status)) s4.addRow([k, v]);
  s4.addRow(['Vi phạm SLA (giai đoạn / bộ phận / người giữ)']); for (const b of d.workplace.sla_breaches) s4.addRow([b.stage, b.department, b.from_name, b.n]);
  s4.getColumn(1).width = 34;
  const s5 = wb.addWorksheet('Điểm nghẽn');
  s5.addRow(['Loại', 'Vấn đề', 'Chi tiết', 'Hành động đề xuất']);
  for (const b of d.bottlenecks) s5.addRow([b.type, b.title, b.detail, b.action]);
  if (d.comparison) { s5.addRow([]); s5.addRow(['So sánh kỳ trước', d.comparison.previous_period.label]); for (const i of d.comparison.items) s5.addRow([i.label, i.previous, i.current, i.pct !== null ? `${i.pct}%` : '']); for (const n of d.comparison.notes) s5.addRow(['', n]); }
  s5.columns.forEach((c) => (c.width = 30));
  return wb.xlsx.writeBuffer();
}

export function toPdf(d: any, stream: NodeJS.WritableStream) {
  const doc = new PDFDocument({ size: 'A4', margin: 40 });
  const fonts = join(__dirname, '..', '..', 'assets', 'fonts');
  doc.registerFont('R', join(fonts, 'DejaVuSans.ttf'));
  doc.registerFont('B', join(fonts, 'DejaVuSans-Bold.ttf'));
  doc.pipe(stream);
  const h = (t: string) => { doc.moveDown(0.6).font('B').fontSize(12).text(t).moveDown(0.2).font('R').fontSize(9); };
  doc.font('B').fontSize(16).text(`Báo cáo hiệu suất — ${d.meta.period.label}`);
  doc.font('R').fontSize(9).text(`${d.meta.company} · Phạm vi: ${d.meta.scope.type} · Công thức v${d.meta.formula_version} · Tạo lúc ${d.meta.generated_at}`);
  h('Tổng quan');
  const t = d.summary.tasks;
  doc.text(`Nhiệm vụ: giao ${t.assigned} · hoàn thành ${t.completed} · hủy ${t.cancelled} · quá hạn ${t.overdue} · đang xử lý ${t.in_progress}`);
  doc.text(`Điểm hiệu suất trung bình: ${fmt(d.summary.avg_E)}`);
  doc.text(`Việc đột xuất: yêu cầu chung ${d.summary.unexpected.common.count} (điểm ${fmt(d.summary.unexpected.common.P)}) · đa dạng ${d.summary.unexpected.diverse.count} (điểm ${fmt(d.summary.unexpected.diverse.P)})`);
  doc.text(`Tăng ca: ${Math.round(d.summary.overtime_minutes / 6) / 10} giờ · Báo cáo trở ngại: ${d.summary.workplace_reports}`);
  const w = d.summary.work_records;
  doc.text(`Bản ghi tự khai báo: ${w.submitted} gửi · ${w.accepted} chấp nhận · ${w.partially_accepted} một phần · ${w.rejected} từ chối · ${w.disputed} tranh chấp · ${w.appealed} khiếu nại · ${w.unresolved} chưa giải quyết`);
  h('Hiệu suất cá nhân (E = 0.25V + 0.20T + 0.30Q + 0.15D + 0.10R)');
  const cols = [150, 40, 40, 40, 40, 40, 40, 55, 60];
  const row = (cells: any[], bold = false) => {
    const y = doc.y; let x = 40;
    doc.font(bold ? 'B' : 'R');
    cells.forEach((c, i) => { doc.text(fmt(c), x, y, { width: cols[i] - 4, lineBreak: false, ellipsis: true }); x += cols[i]; });
    doc.moveDown(0.3); doc.x = 40;
    if (doc.y > 780) doc.addPage();
  };
  row(['Nhân viên', 'E', 'V', 'T', 'Q', 'D', 'R', 'Hoàn thành', 'Tăng ca (h)'], true);
  for (const m of d.members) row([m.name, m.E, m.V, m.T, m.Q, m.D, m.R, m.completed_count, Math.round(m.overtime_minutes / 6) / 10]);
  if (d.groups?.length) {
    h('Nhóm');
    for (const g of d.groups) doc.text(`${g.name}: hoàn thành ${g.completed}, khối lượng ${fmt(g.weighted_volume)}, tồn đọng ${g.backlog}, quá hạn ${g.overdue}, điểm TB ${fmt(g.avg_E)}, tăng ca ${Math.round(g.overtime_minutes / 6) / 10}h`);
  }
  h('Tăng ca theo nguyên nhân');
  for (const c of d.overtime.by_cause) doc.text(`• ${OT_LABEL[c.ot_type] || c.ot_type}: ${Math.round(c.minutes / 6) / 10} giờ`);
  h('Báo cáo trở ngại');
  doc.text(`Mức độ: ${Object.entries(d.workplace.by_severity).map(([k, v]) => `${k} ${v}`).join(', ') || '—'}`);
  doc.text(`Bộ phận: ${Object.entries(d.workplace.by_department).map(([k, v]) => `${k} ${v}`).join(', ') || '—'}`);
  doc.text(`Đang mở: ${d.workplace.open} · quá SLA: ${d.workplace.overdue_open}`);
  h('Điểm nghẽn vận hành & hành động đề xuất');
  if (!d.bottlenecks.length) doc.text('Không phát hiện điểm nghẽn đáng kể.');
  for (const b of d.bottlenecks) doc.text(`• ${b.title} — ${b.detail}. Đề xuất: ${b.action}`);
  if (d.comparison) {
    h(`So sánh với ${d.comparison.previous_period.label}`);
    for (const i of d.comparison.items) doc.text(`• ${i.label}: ${fmt(i.previous)} → ${fmt(i.current)}${i.pct !== null ? ` (${i.pct > 0 ? '+' : ''}${i.pct}%)` : ''}`);
    for (const n of d.comparison.notes) doc.text(`  ${n}`);
  }
  h('Lưu ý');
  for (const n of d.meta.notes) doc.text(`• ${n}`);
  doc.end();
}
