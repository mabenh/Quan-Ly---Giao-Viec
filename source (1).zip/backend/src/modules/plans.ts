/** Gói doanh nghiệp. Hạn mức & giá có thể cấu hình qua biến môi trường (giá mặc định chỉ là giá minh họa). */
const num = (k: string, d: number) => (process.env[k] ? Number(process.env[k]) : d);

export const PLANS: Record<string, { plan: string; name: string; member_limit: number; price_vnd: number; months: number }> = {
  small: { plan: 'small', name: 'Doanh nghiệp nhỏ', member_limit: num('PLAN_SMALL_LIMIT', 20), price_vnd: num('PLAN_SMALL_PRICE', 1_200_000), months: 12 },
  medium: { plan: 'medium', name: 'Doanh nghiệp vừa', member_limit: num('PLAN_MEDIUM_LIMIT', 100), price_vnd: num('PLAN_MEDIUM_PRICE', 4_800_000), months: 12 },
  large: { plan: 'large', name: 'Doanh nghiệp lớn', member_limit: num('PLAN_LARGE_LIMIT', 500), price_vnd: num('PLAN_LARGE_PRICE', 12_000_000), months: 12 },
};

/** 'auto' = kích hoạt ngay (dùng thử); 'manual' = chờ quản trị nền tảng xác nhận thanh toán. */
export const activationMode = () => (process.env.PLAN_ACTIVATION === 'manual' ? 'manual' : 'auto');
