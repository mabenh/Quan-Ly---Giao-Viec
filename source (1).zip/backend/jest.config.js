module.exports = {
  preset: 'ts-jest',
  testEnvironment: 'node',
  roots: ['<rootDir>/test'],
  testTimeout: 30000,
  transform: { '^.+\\.ts$': ['ts-jest', { diagnostics: false }] },
};
