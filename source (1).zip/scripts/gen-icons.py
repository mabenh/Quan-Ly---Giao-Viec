"""Sinh biểu tượng app Việc Đến từ resources/logo-source.png (cần Pillow).
Chạy: python3 scripts/gen-icons.py  (từ thư mục gốc dự án)"""
from PIL import Image, ImageDraw
import os

ROOT = os.path.join(os.path.dirname(__file__), '..', 'mobile-web')
src = Image.open(os.path.join(ROOT, 'resources', 'logo-source.png')).convert('RGB')
W_MARK = src.crop((470, 100, 940, 450))          # biểu tượng chữ W
LOCKUP = src.crop((420, 95, 1000, 690))           # W + chữ VIỆC ĐẾN + khẩu hiệu
WHITE = (255, 255, 255)

def on_canvas(img, size, scale, bg=WHITE):
    c = Image.new('RGB', (size, size), bg)
    w = int(size * scale); h = int(img.height * w / img.width)
    if h > size * scale: h = int(size * scale); w = int(img.width * h / img.height)
    c.paste(img.resize((w, h), Image.LANCZOS), ((size - w) // 2, (size - h) // 2))
    return c

def round_mask(img):
    m = Image.new('L', img.size, 0); ImageDraw.Draw(m).ellipse((0, 0, img.width - 1, img.height - 1), fill=255)
    out = Image.new('RGBA', img.size, (0, 0, 0, 0)); out.paste(img, (0, 0), m); return out

pub = os.path.join(ROOT, 'public')
for s in (192, 512):
    on_canvas(W_MARK, s, 0.78).save(os.path.join(pub, f'icon-{s}.png'))
on_canvas(W_MARK, 512, 0.62).save(os.path.join(pub, 'icon-maskable-512.png'))
on_canvas(W_MARK, 180, 0.78).save(os.path.join(pub, 'apple-touch-icon.png'))
on_canvas(W_MARK, 64, 0.9).save(os.path.join(pub, 'favicon.png'))
lk = LOCKUP.copy(); lk.thumbnail((640, 640), Image.LANCZOS); lk.save(os.path.join(pub, 'logo.png'))
W_MARK.copy().resize((200, int(200 * W_MARK.height / W_MARK.width)), Image.LANCZOS).save(os.path.join(pub, 'logo-mark.png'))

res = os.path.join(ROOT, 'resources', 'android', 'res')
dens = {'mdpi': 1, 'hdpi': 1.5, 'xhdpi': 2, 'xxhdpi': 3, 'xxxhdpi': 4}
for d, k in dens.items():
    p = os.path.join(res, f'mipmap-{d}'); os.makedirs(p, exist_ok=True)
    s = int(48 * k)
    on_canvas(W_MARK, s, 0.82).save(os.path.join(p, 'ic_launcher.png'))
    round_mask(on_canvas(W_MARK, s, 0.7)).save(os.path.join(p, 'ic_launcher_round.png'))
    on_canvas(W_MARK, int(108 * k), 0.5).save(os.path.join(p, 'ic_launcher_foreground.png'))
splash = {'drawable': (480, 320)}
for d, (pw, ph) in {'mdpi': (320, 480), 'hdpi': (480, 800), 'xhdpi': (720, 1280), 'xxhdpi': (960, 1600), 'xxxhdpi': (1280, 1920)}.items():
    splash[f'drawable-port-{d}'] = (pw, ph); splash[f'drawable-land-{d}'] = (ph, pw)
for folder, (w, h) in splash.items():
    p = os.path.join(res, folder); os.makedirs(p, exist_ok=True)
    c = Image.new('RGB', (w, h), WHITE)
    t = LOCKUP.copy(); t.thumbnail((int(min(w, h) * 0.6), int(min(w, h) * 0.6)), Image.LANCZOS)
    c.paste(t, ((w - t.width) // 2, (h - t.height) // 2)); c.save(os.path.join(p, 'splash.png'))
v = os.path.join(res, 'values'); os.makedirs(v, exist_ok=True)
open(os.path.join(v, 'ic_launcher_background.xml'), 'w').write('<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <color name="ic_launcher_background">#FFFFFF</color>\n</resources>\n')
print('OK')
