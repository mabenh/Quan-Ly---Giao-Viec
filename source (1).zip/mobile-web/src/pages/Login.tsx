import { FormEvent, useState } from 'react';
import { useAuth } from '../auth';
import { ErrorBox, Field, Tabs, useAction } from '../ui';

const DEMO: [string, string][] = [
  ['0901000001', 'Chủ doanh nghiệp'], ['0901000002', 'Quản trị'], ['0901000003', 'Quản lý Vận hành'], ['0901000004', 'Quản lý Kinh doanh'],
  ['0901000007', 'Nhân viên 1'], ['0901000008', 'Nhân viên 2'], ['0901000012', 'Quản lý nhân sự'], ['0901000005', 'Trưởng Kỹ thuật'],
  ['0901000011', 'Reviewer độc lập'], ['0900000000', 'Quản trị nền tảng'],
];

export default function Login() {
  const { login, register } = useAuth();
  const [mode, setMode] = useState('login');
  const [phone, setPhone] = useState('');
  const [name, setName] = useState('');
  const [password, setPassword] = useState('');
  const [password2, setPassword2] = useState('');
  const a = useAction();
  const submit = (e: FormEvent) => {
    e.preventDefault();
    if (mode === 'register' && password !== password2) { a.setError('Mật khẩu nhập lại không khớp'); return; }
    a.run(() => (mode === 'login' ? login(phone.trim(), password) : register({ phone: phone.trim(), name: name.trim(), password })));
  };
  return (
    <div className="login">
      <img src="/logo.png" alt="Việc Đến — Quản lý & Giám sát việc" style={{ width: 200, display: 'block', margin: '0 auto 12px' }} />
      <Tabs value={mode} onChange={(m) => { setMode(m); a.setError(null); }} tabs={[['login', 'Đăng nhập'], ['register', 'Đăng ký']]} />
      <form onSubmit={submit}>
        <Field label="Số điện thoại"><input type="tel" inputMode="tel" autoComplete="tel" placeholder="0912 345 678" value={phone} onChange={(e) => setPhone(e.target.value)} required /></Field>
        {mode === 'register' && <Field label="Họ và tên đầy đủ" hint="Tên này hiển thị với mọi người trong doanh nghiệp"><input autoComplete="name" value={name} onChange={(e) => setName(e.target.value)} required /></Field>}
        <Field label="Mật khẩu" hint={mode === 'register' ? 'Tối thiểu 8 ký tự' : undefined}><input type="password" autoComplete={mode === 'login' ? 'current-password' : 'new-password'} value={password} onChange={(e) => setPassword(e.target.value)} required /></Field>
        {mode === 'register' && <Field label="Nhập lại mật khẩu"><input type="password" autoComplete="new-password" value={password2} onChange={(e) => setPassword2(e.target.value)} required /></Field>}
        <ErrorBox error={a.error} />
        <button className="btn primary block" disabled={a.busy}>{a.busy ? 'Đang xử lý…' : mode === 'login' ? 'Đăng nhập' : 'Tạo tài khoản'}</button>
        {mode === 'register' && <p className="small muted">Nếu doanh nghiệp đã thêm số điện thoại của bạn, hãy đăng ký bằng đúng số đó để vào thẳng công ty.</p>}
      </form>
      {import.meta.env.VITE_HIDE_DEMO !== 'true' && mode === 'login' && (
        <>
          <div className="section-title">Tài khoản demo (mật khẩu Demo@123)</div>
          <div className="demo-accounts">
            {DEMO.map(([p, l]) => <button key={p} className="btn sm" onClick={() => { setPhone(p); setPassword('Demo@123'); }}>{l}<br /><span className="muted">{p}</span></button>)}
          </div>
        </>
      )}
    </div>
  );
}
