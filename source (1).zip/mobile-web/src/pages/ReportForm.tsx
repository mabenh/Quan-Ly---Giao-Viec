import { useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { get, post, upload } from '../api';
import { ErrorBox, Field, Header, Select, useAction, useLoad } from '../ui';
import { RP_CAT, SEVERITY, fromLocalInput, toLocalInput } from '../labels';

export default function ReportForm() {
  const nav = useNavigate();
  const [sp] = useSearchParams();
  const a = useAction();
  const groups = useLoad(() => get('/groups'), []);
  const tasks = useLoad(() => get('/tasks?limit=100&status=not_started,in_progress,pending_review,revision_requested'), []);
  const [f, setF] = useState<any>({
    category: 'equipment', subcategory: '', severity: 'medium', description: '', detectedAt: toLocalInput(new Date()),
    groupId: sp.get('groupId') || '', affectedTaskId: sp.get('taskId') || '', asset: '', location: '', tempMeasure: '',
    safetyRisk: false, independentChannel: false, independentReason: '',
  });
  const [file, setFile] = useState<File | null>(null);
  const up = (p: any) => setF((x: any) => ({ ...x, ...p }));
  const submit = () => a.run(async () => {
    const r = await post('/workplace-reports', {
      ...f, detectedAt: fromLocalInput(f.detectedAt), groupId: f.groupId || undefined, affectedTaskId: f.affectedTaskId || undefined,
      subcategory: f.subcategory || undefined, asset: f.asset || undefined, location: f.location || undefined, tempMeasure: f.tempMeasure || undefined,
      independentReason: f.independentChannel ? f.independentReason : undefined,
    });
    if (file) await upload('workplace_report', r.id, file).catch(() => {});
    nav(`/reports/${r.id}`, { replace: true });
  });
  return (
    <>
      <Header title="Báo cáo trở ngại" back />
      <div className="page">
        {(f.safetyRisk || f.severity === 'critical') && (
          <div className="alert error"><b>⚠ Nguy cơ an toàn:</b> nếu có nguy cơ thương tích, cháy nổ hoặc nguy hiểm — kích hoạt ngay quy trình an toàn ngoài ứng dụng (bộ phận an toàn, 114, 115). Không chờ SLA.</div>
        )}
        <Field label="Danh mục vấn đề" required><Select value={f.category} onChange={(v) => up({ category: v })} options={RP_CAT} /></Field>
        <Field label="Danh mục con"><input value={f.subcategory} onChange={(e) => up({ subcategory: e.target.value })} /></Field>
        <Field label="Mức độ ảnh hưởng" required><Select value={f.severity} onChange={(v) => up({ severity: v })} options={SEVERITY} /></Field>
        <label className="check"><input type="checkbox" checked={f.safetyRisk} onChange={(e) => up({ safetyRisk: e.target.checked })} /> Có nguy cơ mất an toàn</label>
        <Field label="Mô tả" required><textarea value={f.description} onChange={(e) => up({ description: e.target.value })} /></Field>
        <Field label="Thời điểm phát hiện" required><input type="datetime-local" value={f.detectedAt} onChange={(e) => up({ detectedAt: e.target.value })} /></Field>
        <Field label="Nhóm bị ảnh hưởng"><Select value={f.groupId} onChange={(v) => up({ groupId: v })} options={(groups.data || []).map((g: any) => [g.id, g.name])} placeholder="— Không —" /></Field>
        <Field label="Nhiệm vụ bị ảnh hưởng" hint="Khi quản lý xác nhận ảnh hưởng, nhiệm vụ được gắn cờ và không tự động bị trừ điểm tiến độ">
          <Select value={f.affectedTaskId} onChange={(v) => up({ affectedTaskId: v })} options={(tasks.data?.items || []).map((t: any) => [t.id, `${t.code} ${t.title}`])} placeholder="— Không —" />
        </Field>
        <div className="grid2">
          <Field label="Mã tài sản/thiết bị"><input value={f.asset} onChange={(e) => up({ asset: e.target.value })} /></Field>
          <Field label="Vị trí/bộ phận"><input value={f.location} onChange={(e) => up({ location: e.target.value })} /></Field>
        </div>
        <Field label="Biện pháp tạm thời đã áp dụng"><input value={f.tempMeasure} onChange={(e) => up({ tempMeasure: e.target.value })} /></Field>
        <Field label="Bằng chứng (ảnh/video/tài liệu)"><input type="file" accept="image/*,video/*,application/pdf" onChange={(e) => setFile(e.target.files?.[0] || null)} /></Field>
        <label className="check"><input type="checkbox" checked={f.independentChannel} onChange={(e) => up({ independentChannel: e.target.checked })} /> Gửi kênh độc lập (quản lý trực tiếp bị phản ánh / xung đột lợi ích)</label>
        {f.independentChannel && <Field label="Lý do dùng kênh độc lập" required><textarea value={f.independentReason} onChange={(e) => up({ independentReason: e.target.value })} /></Field>}
        <ErrorBox error={a.error} />
        <button className="btn primary block" disabled={a.busy} onClick={submit}>Gửi báo cáo</button>
      </div>
    </>
  );
}
