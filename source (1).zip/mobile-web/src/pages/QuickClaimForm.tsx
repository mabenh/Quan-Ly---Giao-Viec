import { useEffect, useState } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { ApiError, get, post, qs, upload } from '../api';
import { useAuth } from '../auth';
import { Avatar, Card, ErrorBox, Field, Header, Select, useAction, useLoad } from '../ui';
import AudioRecorder from '../AudioRecorder';
import { CHANNEL, ROLE, fromLocalInput, toLocalInput } from '../labels';
import { claimLink, rememberContact, smsHref, telHref, zaloHref } from '../contact';

export default function QuickClaimForm() {
  const { me } = useAuth();
  const nav = useNavigate();
  const [sp] = useSearchParams();
  const members = useLoad(() => get('/company/members?status=active'), []);
  const [cp, setCp] = useState(sp.get('c') || '');
  const [f, setF] = useState<any>({
    channel: sp.get('ch') || 'call', occurredAt: toLocalInput(sp.get('t') ? new Date(sp.get('t')!) : new Date()),
    title: sp.get('title') || '', description: '', dueAt: '', estimatedHours: '', alreadyDone: false,
  });
  const [audio, setAudio] = useState<File | null>(null);
  const [existing, setExisting] = useState<any>(null);
  const [copied, setCopied] = useState(false);
  const [different, setDifferent] = useState(false);
  const a = useAction();
  const up = (p: any) => setF((x: any) => ({ ...x, ...p }));
  const person = (members.data || []).find((m: any) => m.id === cp);

  useEffect(() => {
    if (!cp) { setExisting(null); return; }
    get('/quick-claims/check' + qs({ counterpartId: cp, occurredAt: fromLocalInput(f.occurredAt) })).then((r) => setExisting(r.existing)).catch(() => setExisting(null));
  }, [cp, f.occurredAt]);

  const contact = (channel: string) => { if (person) rememberContact({ memberId: person.id, name: person.name, channel, at: new Date().toISOString() }); up({ channel, occurredAt: toLocalInput(new Date()) }); };
  const link = me?.member_id ? claimLink(me.member_id, 'sms', f.title || undefined) : '';
  const smsBody = `${f.title ? f.title + '\n' : ''}Khai việc nhanh trên Việc Đến: ${link}`;

  const submit = () => a.run(async () => {
    try {
      const r = await post('/quick-claims', {
        counterpartId: cp, channel: f.channel, occurredAt: fromLocalInput(f.occurredAt), title: f.title, description: f.description || undefined,
        dueAt: fromLocalInput(f.dueAt), estimatedHours: f.estimatedHours ? Number(f.estimatedHours) : undefined, alreadyDone: f.alreadyDone,
        notDuplicateOf: different && existing ? existing.id : undefined,
      });
      if (audio) await upload('quick_claim', r.id, audio).catch(() => {});
      nav(`/quick/${r.id}`, { replace: true });
    } catch (e) {
      if (e instanceof ApiError && e.code === 'CLAIM_EXISTS' && e.details?.id) { nav(`/quick/${e.details.id}`, { replace: true }); return; }
      throw e;
    }
  });

  return (
    <>
      <Header title="Khai việc nhanh" back />
      <div className="page">
        <p className="small muted">Ghi nhận việc được giao qua gọi điện, tin nhắn hoặc trao đổi trực tiếp. Ai khai trước thì người kia chỉ cần bấm xác nhận.</p>
        <Field label="Người trao đổi với bạn" required>
          <Select value={cp} onChange={setCp} options={(members.data || []).filter((m: any) => m.id !== me?.member_id).map((m: any) => [m.id, `${m.name} — ${m.title || ROLE[m.role]}`])} placeholder="— Chọn người —" />
        </Field>
        {person && (
          <Card>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <Avatar userId={person.user_id} name={person.name} has={person.has_avatar} />
              <div style={{ flex: 1 }}><b>{person.name}</b><div className="small muted">{person.phone}</div></div>
            </div>
            <div className="actions">
              <a className="btn sm" href={telHref(person.phone)} onClick={() => contact('call')}>📞 Gọi</a>
              <a className="btn sm" href={smsHref(person.phone, smsBody)} onClick={() => contact('sms')}>💬 SMS kèm link</a>
              <a className="btn sm" href={zaloHref(person.phone)} target="_blank" rel="noreferrer" onClick={() => contact('zalo')}>Zalo</a>
              <button className="btn sm" onClick={async () => { try { await navigator.clipboard.writeText(smsBody); setCopied(true); setTimeout(() => setCopied(false), 2000); } catch { prompt('Sao chép nội dung:', smsBody); } }}>{copied ? '✓ Đã chép' : '🔗 Chép link khai việc'}</button>
            </div>
            <p className="small muted">Gửi link qua Zalo/Messenger: người nhận bấm vào sẽ mở mẫu khai việc đã điền sẵn tên bạn. Sau khi gọi xong và quay lại app, Việc Đến sẽ gợi ý khai việc.</p>
          </Card>
        )}
        {existing && (
          <div className={`alert ${existing.mine ? 'info' : 'warn'}`}>
            {existing.mine ? 'Bạn đã khai việc với người này quanh thời điểm này, đang chờ xác nhận.' : `Người kia đã khai việc "${existing.title}" — bạn chỉ cần xác nhận, không cần khai thêm.`}
            {' '}<Link to={`/quick/${existing.id}`}>Mở khai việc</Link>
            <label className="check"><input type="checkbox" checked={different} onChange={(e) => setDifferent(e.target.checked)} /> Đây là một việc khác, tôi vẫn muốn khai</label>
          </div>
        )}
        <div className="grid2">
          <Field label="Hình thức"><Select value={f.channel} onChange={(v) => up({ channel: v })} options={CHANNEL} /></Field>
          <Field label="Thời điểm trao đổi"><input type="datetime-local" value={f.occurredAt} onChange={(e) => up({ occurredAt: e.target.value })} /></Field>
        </div>
        <Field label="Nội dung công việc" required><input value={f.title} onChange={(e) => up({ title: e.target.value })} placeholder="VD: Giao 20 thùng hàng cho khách Hòa Bình trước 15h" /></Field>
        <Field label="Chi tiết / yêu cầu"><textarea value={f.description} onChange={(e) => up({ description: e.target.value })} /></Field>
        <div className="grid2">
          <Field label="Hạn hoàn thành"><input type="datetime-local" value={f.dueAt} onChange={(e) => up({ dueAt: e.target.value })} /></Field>
          <Field label="Thời lượng dự kiến (giờ)"><input type="number" min={0.25} step={0.25} value={f.estimatedHours} onChange={(e) => up({ estimatedHours: e.target.value })} /></Field>
        </div>
        <label className="check"><input type="checkbox" checked={f.alreadyDone} onChange={(e) => up({ alreadyDone: e.target.checked })} /> Việc đã làm xong (khi xác nhận sẽ chuyển thẳng sang chờ nghiệm thu)</label>
        <Field label="Ghi âm / bằng chứng"><AudioRecorder value={audio} onChange={setAudio} /></Field>
        <ErrorBox error={a.error} />
        <button className="btn primary block" disabled={a.busy || !cp || (!!existing && !different)} onClick={submit}>{a.busy ? 'Đang gửi…' : 'Gửi khai việc'}</button>
      </div>
    </>
  );
}
