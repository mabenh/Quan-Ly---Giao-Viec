import { useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { get, post } from '../api';
import { ErrorBox, Field, Header, Select, useAction, useLoad } from '../ui';
import { OT_TYPE, fromLocalInput, toLocalInput } from '../labels';

export default function OvertimeForm() {
  const nav = useNavigate();
  const [sp] = useSearchParams();
  const a = useAction();
  const members = useLoad(() => get('/company/members'), []);
  const groups = useLoad(() => get('/groups'), []);
  const tasks = useLoad(() => get('/tasks?mine=any&limit=100'), []);
  const end = new Date(); end.setMinutes(0, 0, 0);
  const [f, setF] = useState<any>({
    startAt: toLocalInput(new Date(end.getTime() - 2 * 3600000)), endAt: toLocalInput(end), otType: 'ad_hoc', cause: '', groupId: '',
    taskId: sp.get('taskId') || '', reportId: sp.get('reportId') || '', requestedByMemberId: '', notifiedInAdvance: false, impact: '',
  });
  const up = (p: any) => setF((x: any) => ({ ...x, ...p }));
  const mins = Math.round((new Date(f.endAt).getTime() - new Date(f.startAt).getTime()) / 60000);
  const submit = () => a.run(async () => {
    const r = await post('/overtime-records', {
      startAt: fromLocalInput(f.startAt), endAt: fromLocalInput(f.endAt), otType: f.otType, cause: f.cause, groupId: f.groupId || undefined,
      taskId: f.taskId || undefined, reportId: f.reportId || undefined, requestedByMemberId: f.requestedByMemberId || undefined,
      notifiedInAdvance: f.notifiedInAdvance, impact: f.impact || undefined,
    });
    nav(`/overtime/${r.id}`, { replace: true });
  });
  return (
    <>
      <Header title="Ghi nhận tăng ca" back />
      <div className="page">
        <p className="small muted">Có thể ghi nhận cả tăng ca chưa được duyệt trước — dữ liệu không bị xóa vì chưa phê duyệt. Ứng dụng không tự tính lương/phụ cấp.</p>
        <div className="grid2">
          <Field label="Bắt đầu" required><input type="datetime-local" value={f.startAt} onChange={(e) => up({ startAt: e.target.value })} /></Field>
          <Field label="Kết thúc" required><input type="datetime-local" value={f.endAt} onChange={(e) => up({ endAt: e.target.value })} /></Field>
        </div>
        <div className="small muted">Tổng: {mins > 0 ? `${Math.floor(mins / 60)} giờ ${mins % 60} phút` : 'không hợp lệ'}</div>
        <Field label="Phân loại tăng ca" required><Select value={f.otType} onChange={(v) => up({ otType: v })} options={OT_TYPE} /></Field>
        <Field label="Nguyên nhân" required><textarea value={f.cause} onChange={(e) => up({ cause: e.target.value })} /></Field>
        <Field label="Người yêu cầu"><Select value={f.requestedByMemberId} onChange={(v) => up({ requestedByMemberId: v })} options={(members.data || []).map((m: any) => [m.id, m.name])} placeholder="— Không có / tự thực hiện —" /></Field>
        <label className="check"><input type="checkbox" checked={f.notifiedInAdvance} onChange={(e) => up({ notifiedInAdvance: e.target.checked })} /> Có được thông báo trước</label>
        <Field label="Nhiệm vụ liên quan"><Select value={f.taskId} onChange={(v) => up({ taskId: v })} options={(tasks.data?.items || []).map((t: any) => [t.id, `${t.code} ${t.title}`])} placeholder="— Không —" /></Field>
        <Field label="Nhóm"><Select value={f.groupId} onChange={(v) => up({ groupId: v })} options={(groups.data || []).map((g: any) => [g.id, g.name])} placeholder="— Theo nhiệm vụ / không —" /></Field>
        <Field label="Ảnh hưởng đến công việc thường xuyên"><textarea value={f.impact} onChange={(e) => up({ impact: e.target.value })} /></Field>
        <ErrorBox error={a.error} />
        <button className="btn primary block" disabled={a.busy} onClick={submit}>Gửi ghi nhận</button>
      </div>
    </>
  );
}
