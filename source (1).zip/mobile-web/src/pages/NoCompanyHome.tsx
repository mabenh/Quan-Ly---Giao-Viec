import { Link } from 'react-router-dom';
import { useAuth } from '../auth';
import { Card } from '../ui';

export default function NoCompanyHome() {
  const { me, reload } = useAuth();
  if (!me) return null;
  return (
    <div className="page">
      <h1 style={{ margin: '6px 0' }}>Xin chào, {me.name} 👋</h1>
      <p className="muted">Tài khoản của bạn chưa thuộc doanh nghiệp nào.</p>
      {me.pending_memberships?.length > 0 && (
        <div className="alert info">Bạn đã được đề nghị vào {me.pending_memberships.map((p) => p.company_name).join(', ')} — đang chờ bộ phận nhân sự duyệt. <button className="btn sm" onClick={reload}>Kiểm tra lại</button></div>
      )}
      <Card>
        <h3>👷 Bạn là nhân viên?</h3>
        <p className="small">Đưa số điện thoại <b>{me.phone}</b> cho quản lý để được thêm vào doanh nghiệp. Trong lúc chờ, hãy hoàn thiện hồ sơ xin việc để nhà tuyển dụng xem.</p>
        <Link className="btn primary block" to="/profile">📄 Hoàn thiện hồ sơ</Link>
      </Card>
      <Card>
        <h3>🏢 Bạn là chủ doanh nghiệp?</h3>
        <p className="small">Nâng cấp lên gói Doanh nghiệp để tạo công ty, thêm thành viên bằng số điện thoại, phân vai trò quản lý và bắt đầu giao việc.</p>
        <Link className="btn block" to="/upgrade">Nâng cấp tài khoản doanh nghiệp</Link>
      </Card>
      {me.is_platform_admin && <Link className="btn block" to="/platform">🛠 Quản trị nền tảng (xác nhận thanh toán)</Link>}
    </div>
  );
}
