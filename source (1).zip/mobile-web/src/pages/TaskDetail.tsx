import { useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { download, get, patch, post, upload } from '../api';
import { useAuth } from '../auth';
import { Badge, Card, ErrorBox, Field, Header, KV, Loading, Select, Sheet, Timeline, useAction, useLoad } from '../ui';
import {
  AUDIT_ACTION, COMPLEXITY, EVAL_LABEL, PRIORITY, REQ, REQ_STRUCT, RP_STATUS, SEVERITY, TASK_STATUS, TASK_TONE, UNEXPECTED_CAT, UNEXPECTED_CAUSE,
  OT_STATUS, fmtDT, hours, relDue, toLocalInput, fromLocalInput,
} from '../labels';

const REGULAR = ['output', 'quality', 'schedule', 'process'];
const UNEXP = ['requirement', 'response', 'handling', 'quality', 'coordination'];
const W: Record<string, number> = { output: 40, quality: 30, schedule: 20, process: 10, requirement: 35, response: 20, handling: 20, coordination: 10 };
const WU: Record<string, number> = { quality: 15 };

export default function TaskDetail() {
  const { id } = useParams();
  const { me } = useAuth();
  const { data: t, error, loading, reload, setData } = useLoad(() => get(`/tasks/${id}`), [id]);
  const [sheet, setSheet] = useState<string | null>(null);
  const [showHistory, setShowHistory] = useState(false);
  const a = useAction();
  const act = (fn: () => Promise<any>) => a.run(async () => { const r = await fn(); if (r?.id) setData(r); else await reload(); setSheet(null); });
  if (loading && !t) return <Loading />;
  if (!t) return <div className="page"><ErrorBox error={error} /></div>;
  const p = t.permissions;
  const outputs = t.criteria.filter((c: any) => c.direction === 'output');
  const inputs = t.criteria.filter((c: any) => c.direction === 'input');
  const collabs = t.assignees.filter((x: any) => x.assignment_type === 'collaborator' && x.active);

  return (
    <>
      <Header title={t.code || 'Nhiệm vụ'} back="/work?tab=tasks" />
      <div className="page">
        <h2>{t.title}</h2>
        <div className="chip-row">
          <Badge tone={TASK_TONE[t.status]}>{TASK_STATUS[t.status]}</Badge>
          {t.pinned && <Badge tone="red">📌 Việc gấp được ghim</Badge>}
          {!t.pinned && t.urgent && <Badge tone="red">Gấp</Badge>}
          {t.carry_count > 0 && <Badge tone="amber">↪ Chuyển từ {new Date(t.original_plan_date).toLocaleDateString('vi-VN')} ({t.carry_count} ngày)</Badge>}
          {t.is_overdue && <Badge tone="red">⏰ Quá hạn ({relDue(t.due_at)})</Badge>}
          {t.submitted_late && <Badge tone="amber">Bàn giao trễ hạn</Badge>}
          {t.is_unexpected && <Badge tone="purple">⚡ {UNEXPECTED_CAT[t.unexpected?.category]} · {REQ_STRUCT[t.unexpected?.requirement_structure]}</Badge>}
          {t.impediment_confirmed && <Badge tone="amber">🛑 Có trở ngại đã xác nhận — không tự động trừ điểm tiến độ</Badge>}
        </div>
        <ErrorBox error={a.error} />
        <div className="actions">
          {p.can_start && <button className="btn primary" disabled={a.busy} onClick={() => act(() => post(`/tasks/${id}/start`))}>▶ {t.status === 'revision_requested' ? 'Tiếp tục chỉnh sửa' : 'Bắt đầu'}</button>}
          {p.can_submit && <button className="btn primary" onClick={() => setSheet('submit')}>📤 Bàn giao kết quả</button>}
          {p.can_review && <button className="btn primary" onClick={() => setSheet('review')}>✔ Nghiệm thu</button>}
          {p.can_manage && !['completed', 'cancelled'].includes(t.status) && <button className="btn" onClick={() => setSheet('edit')}>✎ Điều chỉnh</button>}
          {p.can_manage && !['completed', 'cancelled'].includes(t.status) && (t.pinned
            ? <button className="btn" onClick={() => setSheet('unpin')}>Gỡ ghim</button>
            : <button className="btn danger" disabled={a.busy} onClick={() => act(() => post(`/tasks/${id}/pin`, { pinned: true }))}>📌 Ghim việc gấp</button>)}
          {(p.can_manage || t.owner_id === me?.member_id) && !['completed', 'cancelled'].includes(t.status) && <button className="btn" onClick={() => setSheet('plan')}>📅 Đổi ngày làm</button>}
          {p.can_cancel && <button className="btn danger" onClick={() => setSheet('cancel')}>Hủy nhiệm vụ</button>}
          <Link className="btn" to={`/reports/new?taskId=${t.id}&groupId=${t.group_id}`}>⚠️ Báo trở ngại</Link>
          <Link className="btn" to={`/overtime/new?taskId=${t.id}`}>⏱ Ghi tăng ca</Link>
        </div>

        <Card>
          <KV k="Nhóm" v={t.group_name} />
          <KV k="Người chịu trách nhiệm" v={t.owner_name} />
          <KV k="Cộng tác viên" v={collabs.map((c: any) => c.name).join(', ') || '—'} />
          <KV k="Loại công việc" v={t.task_type_name} />
          <KV k="Độ phức tạp / Mức yêu cầu" v={`${COMPLEXITY[t.complexity]} / ${REQ[t.requirement_level]}`} />
          <KV k="Thời lượng dự kiến" v={`${t.estimated_hours} giờ`} />
          <KV k="Deadline" v={fmtDT(t.due_at)} />
          <KV k="Ngày làm (lịch)" v={t.plan_date ? new Date(t.plan_date).toLocaleDateString('vi-VN') : '—'} />
          <KV k="Ưu tiên" v={PRIORITY[t.priority]} />
          <KV k="Phiên bản phạm vi" v={`v${t.scope_version} · tiêu chí v${t.criteria_version}`} />
          {t.resources && <KV k="Nguồn lực/phụ thuộc" v={t.resources} />}
          {t.cancel_reason && <KV k="Lý do hủy" v={t.cancel_reason} />}
        </Card>

        <div className="section-title">Mô tả / phạm vi</div>
        <Card><div className="crit">{t.description}</div></Card>

        <div className="section-title">Đầu vào & tiêu chí nghiệm thu (v{t.criteria_version})</div>
        <Card>
          {inputs.length > 0 && <><b className="small">Đầu vào</b><ul>{inputs.map((c: any) => <li key={c.id}>{c.criterion}</li>)}</ul></>}
          <b className="small">Tiêu chí đầu ra</b><ul>{outputs.map((c: any) => <li key={c.id}>{c.criterion}</li>)}</ul>
          {t.criteria_history.some((c: any) => c.version < t.criteria_version) && (
            <button className="btn sm" onClick={() => setShowHistory(!showHistory)}>{showHistory ? 'Ẩn' : 'Xem'} các phiên bản trước</button>
          )}
          {showHistory && t.criteria_history.filter((c: any) => c.version < t.criteria_version).map((c: any) => (
            <div key={c.id} className="small muted">v{c.version} · {c.direction === 'output' ? 'Đầu ra' : 'Đầu vào'}: {c.criterion} ({c.created_by_name}, {fmtDT(c.created_at)})</div>
          ))}
        </Card>

        {t.unexpected && (
          <>
            <div className="section-title">Thông tin phát sinh</div>
            <Card>
              <KV k="Nguyên nhân" v={`${UNEXPECTED_CAUSE[t.unexpected.cause]}${t.unexpected.cause_detail ? ' — ' + t.unexpected.cause_detail : ''}`} />
              <KV k="Người yêu cầu" v={t.unexpected.requester_name} />
              <KV k="Thời điểm yêu cầu" v={fmtDT(t.unexpected.requested_at)} />
              {t.unexpected.impact && <KV k="Ảnh hưởng" v={t.unexpected.impact} />}
            </Card>
          </>
        )}

        {(t.subitems.length > 0 || (p.can_manage && t.is_unexpected)) && <SubItems t={t} onChange={setData} />}

        {t.evaluations.length > 0 && (
          <>
            <div className="section-title">Nghiệm thu & đánh giá</div>
            {t.evaluations.map((e: any) => (
              <Card key={e.id}>
                <div className="row"><b>{e.decision === 'approved' ? `Đạt — ${e.total_score} điểm` : 'Yêu cầu chỉnh sửa'}</b><span className="spacer" /><span className="small muted">{e.evaluator_name} · {fmtDT(e.created_at)}</span></div>
                {e.scores && <div className="small">{Object.entries(e.scores).map(([k, v]) => `${EVAL_LABEL[k] || k}: ${v}`).join(' · ')}</div>}
                {e.comment && <div className="small">{e.comment}</div>}
              </Card>
            ))}
          </>
        )}

        {t.submissions.length > 0 && (
          <>
            <div className="section-title">Bàn giao</div>
            {t.submissions.map((s: any) => <Card key={s.id}><div className="small muted">{s.name} · {fmtDT(s.created_at)} · {s.completion_percent}%</div><div className="crit">{s.output_description}</div></Card>)}
          </>
        )}

        {t.reports.length > 0 && (
          <>
            <div className="section-title">Báo cáo trở ngại liên quan</div>
            {t.reports.map((r: any) => (
              <Card key={r.id} to={`/reports/${r.id}`}>
                <div className="row"><b>{r.code}</b><Badge tone="amber">{SEVERITY[r.severity]}</Badge><span className="spacer" />{RP_STATUS[r.status]}{r.impact_confirmed && <Badge tone="amber">Đã xác nhận ảnh hưởng</Badge>}</div>
                <div className="small ellipsis">{r.description}</div>
              </Card>
            ))}
          </>
        )}
        {t.overtime.length > 0 && (
          <>
            <div className="section-title">Tăng ca liên quan</div>
            {t.overtime.map((o: any) => <Card key={o.id} to={`/overtime/${o.id}`}><span>{o.name} · {hours(o.minutes)} · {fmtDT(o.start_at)}</span> <Badge>{OT_STATUS[o.approval_status]}</Badge></Card>)}
          </>
        )}

        <Files parentType="task" parentId={t.id} files={t.files} onDone={reload} />
        <Comments t={t} onChange={setData} />

        <div className="section-title">Lịch sử thay đổi</div>
        <Timeline items={t.activities.map((x: any) => ({
          at: x.created_at, title: `${AUDIT_ACTION[x.action] || x.action} · ${x.actor_name || 'Hệ thống'}`,
          body: [x.reason ? `Lý do: ${x.reason}` : '', x.new_value?.status ? `→ ${TASK_STATUS[x.new_value.status] || x.new_value.status}` : '', x.new_value?.due_at ? `Deadline mới: ${fmtDT(x.new_value.due_at)}` : ''].filter(Boolean).join(' · ') || undefined,
        }))} />
      </div>

      <Sheet open={sheet === 'unpin'} onClose={() => setSheet(null)} title="Gỡ ghim việc gấp">
        <p className="small">Người thực hiện sẽ nhận được thông báo.</p>
        <div className="actions stack">
          <button className="btn" disabled={a.busy} onClick={() => act(() => post(`/tasks/${id}/pin`, { pinned: false, urgent: true }))}>Gỡ ghim, vẫn giữ là việc gấp</button>
          <button className="btn primary" disabled={a.busy} onClick={() => act(() => post(`/tasks/${id}/pin`, { pinned: false, urgent: false }))}>Gỡ ghim, không còn gấp</button>
        </div>
      </Sheet>
      <Sheet open={sheet === 'plan'} onClose={() => setSheet(null)} title="Đổi ngày làm trong lịch">
        <PlanForm t={t} busy={a.busy} onSubmit={(d) => act(() => post(`/tasks/${id}/plan`, { planDate: d }))} />
      </Sheet>
      <Sheet open={sheet === 'submit'} onClose={() => setSheet(null)} title="Bàn giao kết quả"><SubmitForm busy={a.busy} error={a.error} onSubmit={(b) => act(() => post(`/tasks/${id}/submit`, b))} /></Sheet>
      <Sheet open={sheet === 'review'} onClose={() => setSheet(null)} title="Nghiệm thu nhiệm vụ"><ReviewForm t={t} busy={a.busy} error={a.error} onSubmit={(b) => act(() => post(`/tasks/${id}/review`, b))} /></Sheet>
      <Sheet open={sheet === 'cancel'} onClose={() => setSheet(null)} title="Hủy nhiệm vụ"><CancelForm busy={a.busy} error={a.error} onSubmit={(b) => act(() => post(`/tasks/${id}/cancel`, b))} /></Sheet>
      <Sheet open={sheet === 'edit'} onClose={() => setSheet(null)} title="Điều chỉnh nhiệm vụ"><EditForm t={t} busy={a.busy} error={a.error} onSubmit={(b) => act(() => patch(`/tasks/${id}`, b))} /></Sheet>
    </>
  );
}

function PlanForm({ t, busy, onSubmit }: { t: any; busy: boolean; onSubmit: (d: string) => void }) {
  const [d, setD] = useState(t.plan_date?.slice(0, 10) || '');
  return (<><Field label="Ngày làm"><input type="date" value={d} onChange={(e) => setD(e.target.value)} /></Field><button className="btn primary block" disabled={busy || !d} onClick={() => onSubmit(d)}>Lưu</button></>);
}

function SubmitForm({ onSubmit, busy, error }: { onSubmit: (b: any) => void; busy: boolean; error: string | null }) {
  const [d, setD] = useState(''); const [pct, setPct] = useState(100);
  return (
    <>
      <Field label="Kết quả thực tế / sản phẩm bàn giao" required><textarea value={d} onChange={(e) => setD(e.target.value)} /></Field>
      <Field label={`Mức độ hoàn thành: ${pct}%`}><input type="range" min={0} max={100} step={5} value={pct} onChange={(e) => setPct(+e.target.value)} /></Field>
      <p className="small muted">Đính kèm bằng chứng ở mục Tệp đính kèm của nhiệm vụ.</p>
      <ErrorBox error={error} />
      <button className="btn primary block" disabled={busy} onClick={() => onSubmit({ outputDescription: d, completionPercent: pct })}>Bàn giao</button>
    </>
  );
}

function ReviewForm({ t, onSubmit, busy, error }: { t: any; onSubmit: (b: any) => void; busy: boolean; error: string | null }) {
  const keys = t.is_unexpected ? UNEXP : REGULAR;
  const [s, setS] = useState<Record<string, number>>(() => Object.fromEntries(keys.map((k) => [k, k === 'schedule' && t.suggested_schedule_score !== null ? t.suggested_schedule_score : 80])));
  const [comment, setComment] = useState('');
  const weights = (k: string) => (t.is_unexpected ? WU[k] ?? W[k] : W[k]);
  const total = keys.reduce((a, k) => a + (weights(k) / 100) * (s[k] || 0), 0);
  return (
    <>
      <p className="small muted">Chấm theo tiêu chí đã xác định trước khi thực hiện (thang 0–100 mỗi tiêu chí). {t.is_unexpected ? 'Công việc đột xuất dùng bộ tiêu chí riêng.' : ''}</p>
      <Card><b className="small">Tiêu chí đầu ra</b><ul>{t.criteria.filter((c: any) => c.direction === 'output').map((c: any) => <li key={c.id}>{c.criterion}</li>)}</ul></Card>
      {keys.map((k) => (
        <Field key={k} label={`${t.is_unexpected && k === 'quality' ? 'Chất lượng/độ chính xác' : EVAL_LABEL[k]} (${weights(k)}%): ${s[k]}`}
          hint={k === 'schedule' && t.suggested_schedule_score !== null ? `Gợi ý theo thời điểm bàn giao: ${t.suggested_schedule_score}${t.impediment_confirmed ? ' (có trở ngại đã xác nhận)' : ''}` : undefined}>
          <input type="range" min={0} max={100} step={5} value={s[k]} onChange={(e) => setS({ ...s, [k]: +e.target.value })} />
        </Field>
      ))}
      <div className="alert info">Tổng điểm nhiệm vụ: <b>{Math.round(total * 10) / 10}</b>/100</div>
      <Field label="Nhận xét (bắt buộc khi yêu cầu sửa)"><textarea value={comment} onChange={(e) => setComment(e.target.value)} /></Field>
      <ErrorBox error={error} />
      <div className="actions">
        <button className="btn primary" disabled={busy} onClick={() => onSubmit({ decision: 'approve', scores: s, comment: comment || undefined })}>✔ Xác nhận hoàn thành</button>
        <button className="btn danger" disabled={busy} onClick={() => onSubmit({ decision: 'revision', comment })}>↩ Yêu cầu chỉnh sửa</button>
      </div>
    </>
  );
}

function CancelForm({ onSubmit, busy, error }: { onSubmit: (b: any) => void; busy: boolean; error: string | null }) {
  const [reason, setReason] = useState(''); const [biz, setBiz] = useState(true);
  return (
    <>
      <Field label="Lý do hủy" required><textarea value={reason} onChange={(e) => setReason(e.target.value)} /></Field>
      <label className="check"><input type="checkbox" checked={biz} onChange={(e) => setBiz(e.target.checked)} /> Hủy do quyết định của doanh nghiệp (không tính là thất bại của nhân viên)</label>
      <ErrorBox error={error} />
      <button className="btn danger block" disabled={busy} onClick={() => onSubmit({ reason, businessDecision: biz })}>Xác nhận hủy</button>
    </>
  );
}

function EditForm({ t, onSubmit, busy, error }: { t: any; onSubmit: (b: any) => void; busy: boolean; error: string | null }) {
  const group = useLoad(() => get(`/groups/${t.group_id}`), [t.group_id]);
  const [due, setDue] = useState(toLocalInput(new Date(t.due_at)));
  const [est, setEst] = useState(String(t.estimated_hours));
  const [owner, setOwner] = useState(t.owner_id);
  const [outputs, setOutputs] = useState<string>(t.criteria.filter((c: any) => c.direction === 'output').map((c: any) => c.criterion).join('\n'));
  const [reason, setReason] = useState('');
  const people: [string, string][] = group.data ? [[group.data.manager_member_id, group.data.manager_name], ...group.data.members.map((m: any) => [m.member_id, m.name] as [string, string])] : [];
  const submit = () => {
    const body: any = { reason: reason || undefined };
    if (fromLocalInput(due) !== new Date(t.due_at).toISOString()) body.dueAt = fromLocalInput(due);
    if (Number(est) !== t.estimated_hours) body.estimatedHours = Number(est);
    if (owner !== t.owner_id) body.ownerMemberId = owner;
    const curOut = t.criteria.filter((c: any) => c.direction === 'output').map((c: any) => c.criterion).join('\n');
    if (outputs.trim() !== curOut) {
      body.criteria = [...t.criteria.filter((c: any) => c.direction === 'input').map((c: any) => ({ direction: 'input', criterion: c.criterion })),
        ...outputs.split('\n').map((x) => x.trim()).filter(Boolean).map((criterion) => ({ direction: 'output', criterion }))];
    }
    onSubmit(body);
  };
  return (
    <>
      <p className="small muted">Thay đổi phạm vi/deadline/người phụ trách sau khi đã giao được lưu phiên bản và bắt buộc có lý do.</p>
      <Field label="Deadline"><input type="datetime-local" value={due} onChange={(e) => setDue(e.target.value)} /></Field>
      <Field label="Thời lượng dự kiến (giờ)"><input type="number" value={est} onChange={(e) => setEst(e.target.value)} /></Field>
      <Field label="Người chịu trách nhiệm"><Select value={owner} onChange={setOwner} options={people} /></Field>
      <Field label="Tiêu chí đầu ra (mỗi dòng một tiêu chí — tạo phiên bản mới)"><textarea value={outputs} onChange={(e) => setOutputs(e.target.value)} /></Field>
      <Field label="Lý do điều chỉnh" required={t.status !== 'not_started'}><textarea value={reason} onChange={(e) => setReason(e.target.value)} /></Field>
      <ErrorBox error={error} />
      <button className="btn primary block" disabled={busy} onClick={submit}>Lưu thay đổi</button>
    </>
  );
}

function SubItems({ t, onChange }: { t: any; onChange: (x: any) => void }) {
  const [title, setTitle] = useState(''); const [extra, setExtra] = useState('0');
  const a = useAction();
  return (
    <>
      <div className="section-title">Yêu cầu thành phần (phạm vi v{t.scope_version})</div>
      <Card>
        {t.subitems.map((s: any) => (
          <label key={s.id} className="check" style={{ alignItems: 'flex-start' }}>
            <input type="checkbox" checked={s.done} onChange={(e) => a.run(async () => onChange(await patch(`/tasks/${t.id}/subitems/${s.id}`, { done: e.target.checked })))} />
            <span>{s.title}<br /><span className="small muted">v{s.scope_version} · {s.requested_by_name} · {fmtDT(s.created_at)}{s.extra_hours ? ` · +${s.extra_hours}h` : ''}</span></span>
          </label>
        ))}
        {t.permissions.can_manage && !['completed', 'cancelled'].includes(t.status) && (
          <div style={{ display: 'flex', gap: 6, marginTop: 8 }}>
            <input placeholder="Yêu cầu bổ sung" value={title} onChange={(e) => setTitle(e.target.value)} />
            <input style={{ width: 80 }} type="number" min={0} value={extra} onChange={(e) => setExtra(e.target.value)} aria-label="Giờ thêm" title="Giờ phát sinh thêm" />
            <button className="btn sm" disabled={a.busy || !title} onClick={() => a.run(async () => { onChange(await post(`/tasks/${t.id}/subitems`, { title, extraHours: Number(extra) })); setTitle(''); setExtra('0'); })}>Thêm</button>
          </div>
        )}
        <ErrorBox error={a.error} />
      </Card>
    </>
  );
}

function Comments({ t, onChange }: { t: any; onChange: (x: any) => void }) {
  const [c, setC] = useState(''); const a = useAction();
  return (
    <>
      <div className="section-title">Bình luận ({t.comments.length})</div>
      {t.comments.map((x: any) => <Card key={x.id}><div className="small muted">{x.name} · {fmtDT(x.created_at)}</div><div className="crit">{x.content}</div></Card>)}
      <div style={{ display: 'flex', gap: 6 }}>
        <input placeholder="Viết bình luận…" value={c} onChange={(e) => setC(e.target.value)} />
        <button className="btn" disabled={a.busy || !c.trim()} onClick={() => a.run(async () => { onChange(await post(`/tasks/${t.id}/comments`, { content: c })); setC(''); })}>Gửi</button>
      </div>
      <ErrorBox error={a.error} />
    </>
  );
}

export function Files({ parentType, parentId, files, onDone, canUpload = true }: { parentType: string; parentId: string; files: any[]; onDone: () => void; canUpload?: boolean }) {
  const a = useAction();
  return (
    <>
      <div className="section-title">Tệp đính kèm / bằng chứng ({files.length})</div>
      {files.map((f) => (
        <Card key={f.id} onClick={() => a.run(() => download(`/files/${f.id}`, f.filename))}>
          <div className="row"><span>📎 {f.filename}</span><span className="spacer" /><span className="small muted">{Math.round(f.size / 1024)} KB</span></div>
        </Card>
      ))}
      {canUpload && (
        <label className="btn sm" style={{ marginTop: 4 }}>
          {a.busy ? 'Đang tải lên…' : '＋ Tải tệp (ảnh/video/tài liệu, ≤20MB)'}
          <input type="file" hidden accept="image/*,video/*,application/pdf,.doc,.docx,.xls,.xlsx,.txt" onChange={(e) => { const f = e.target.files?.[0]; if (f) a.run(async () => { await upload(parentType, parentId, f); onDone(); }); e.target.value = ''; }} />
        </label>
      )}
      <ErrorBox error={a.error} />
    </>
  );
}
