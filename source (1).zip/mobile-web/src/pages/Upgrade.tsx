import { useState } from 'react';
import { get, post } from '../api';
import { useAuth } from '../auth';
import { Badge, Card, ErrorBox, Field, Header, Loading, useAction, useLoad } from '../ui';
import { PLAN_NAME, fmtDT, vnd } from '../labels';

const SUB_STATUS: Record<string, [string, string]> = { pending_payment: ['Chờ thanh toán', 'amber'], active: ['Đã kích hoạt', 'green'], rejected: ['Bị từ chối', 'red'], cancelled: ['Đã hủy', 'gray'] };

export default function Upgrade() {
  const { me, reload, switchCompany } = useAuth();
  const plans = useLoad(() => get('/plans'), []);
  const mine = useLoad(() => get('/subscriptions/mine'), []);
  const isOwner = me?.role === 'owner';
  const [plan, setPlan] = useState('small');
  const [name, setName] = useState(isOwner ? me?.company_name || '' : '');
  const [email, setEmail] = useState(me?.email || '');
  const a = useAction();
  const pending = (mine.data || []).find((s: any) => s.status === 'pending_payment');
  const submit = () => a.run(async () => {
    const r = await post('/subscriptions', { plan, companyName: name, contactEmail: email, companyId: isOwner ? me?.company_id : undefined });
    mine.reload();
    if (r.company_id) { if (r.company_id !== me?.company_id) await switchCompany(r.company_id); else await reload(); }
  });
  if (!plans.data) return <Loading />;
  return (
    <>
      <Header title={isOwner ? 'Gói doanh nghiệp' : 'Nâng cấp tài khoản doanh nghiệp'} back />
      <div className="page">
        {isOwner && <div className="alert info">Gói hiện tại: <b>{PLAN_NAME[me?.plan || ''] || 'Chưa có'}</b> · hạn mức {me?.member_limit ?? '—'} thành viên.</div>}
        {me?.company_id && !isOwner && <div className="alert warn">Chỉ chủ doanh nghiệp mới nâng cấp gói cho công ty hiện tại. Bạn vẫn có thể tạo doanh nghiệp riêng.</div>}
        <div className="section-title">Chọn gói</div>
        {plans.data.plans.map((p: any) => (
          <div key={p.plan} className={`plan-card ${plan === p.plan ? 'sel' : ''}`} onClick={() => setPlan(p.plan)} role="radio" aria-checked={plan === p.plan}>
            <div className="row" style={{ display: 'flex', alignItems: 'center' }}><b style={{ flex: 1 }}>{p.name}</b><span className="price">{vnd(p.price_vnd)}</span></div>
            <div className="small muted">Tối đa {p.member_limit} thành viên · {p.months} tháng · phân vai trò quản lý, nhân sự, báo cáo hiệu suất</div>
          </div>
        ))}
        <Field label="Tên công ty" required><input value={name} onChange={(e) => setName(e.target.value)} /></Field>
        <Field label="Email liên hệ" required hint="Dùng để nhận hóa đơn và đơn từ gửi nhân sự khi chưa có email nhân sự"><input type="email" value={email} onChange={(e) => setEmail(e.target.value)} /></Field>
        <ErrorBox error={a.error} />
        <button className="btn primary block" disabled={a.busy || !!pending} onClick={submit}>{plans.data.activation === 'auto' ? 'Kích hoạt (dùng thử)' : 'Gửi yêu cầu nâng cấp'}</button>
        {plans.data.activation === 'auto' && <p className="small muted">Bản thử nghiệm: gói được kích hoạt ngay, chưa thu phí.</p>}
        {(mine.data || []).length > 0 && <div className="section-title">Yêu cầu của tôi</div>}
        {(mine.data || []).map((s: any) => (
          <Card key={s.id}>
            <div className="row" style={{ display: 'flex', gap: 8, alignItems: 'center' }}><b style={{ flex: 1 }}>{PLAN_NAME[s.plan]} · {s.company_name}</b><Badge tone={SUB_STATUS[s.status][1]}>{SUB_STATUS[s.status][0]}</Badge></div>
            <div className="small muted">{vnd(Number(s.price_vnd))} · {s.member_limit} thành viên · {fmtDT(s.created_at)}</div>
            {s.status === 'pending_payment' && (
              <>
                <div className="alert warn small">{plans.data.payment_instructions || 'Vui lòng chuyển khoản theo hướng dẫn của Việc Đến, ghi nội dung là số điện thoại của bạn. Gói được kích hoạt sau khi xác nhận thanh toán.'}</div>
                <button className="btn sm" onClick={() => a.run(async () => { await post(`/subscriptions/${s.id}/cancel`); mine.reload(); })}>Hủy yêu cầu</button>
              </>
            )}
          </Card>
        ))}
      </div>
    </>
  );
}
