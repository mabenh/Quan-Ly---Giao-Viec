import { useState } from 'react';
import { Link } from 'react-router-dom';
import { post } from '../api';
import { isAdminRole, isHRRole, useAuth } from '../auth';
import { Card, ErrorBox, Field, KV, Sheet, useAction } from '../ui';
import { ROLE } from '../labels';

export default function Profile() {
  const { me, logout, switchCompany } = useAuth();
  const [pw, setPw] = useState(false);
  if (!me) return null;
  return (
    <div className="page">
      <h1>Cá nhân</h1>
      <Card>
        <KV k="Họ tên" v={me.name} />
        <KV k="Số điện thoại" v={me.phone} />
        <KV k="Email" v={me.email} />
        <KV k="Vai trò" v={ROLE[me.role] || 'Tài khoản cá nhân'} />
        <KV k="Chức danh" v={me.title} />
        <KV k="Công ty" v={me.company_name || 'Chưa thuộc doanh nghiệp'} />
        <KV k="Nhóm quản lý" v={me.managed_groups?.map((g) => g.name).join(', ') || '—'} />
        <KV k="Bộ phận phụ trách" v={me.headed_departments?.map((g) => g.name).join(', ') || '—'} />
      </Card>
      {me.memberships.length > 1 && (
        <Card>
          <b>Chuyển công ty</b>
          {me.memberships.map((m) => (
            <button key={m.company_id} className="btn block sm" style={{ marginTop: 6 }} disabled={m.company_id === me.company_id} onClick={() => switchCompany(m.company_id)}>
              {m.company_name} · {ROLE[m.role]}
            </button>
          ))}
        </Card>
      )}
      <div className="section-title">Tiện ích</div>
      <div className="actions stack">
        <Link className="btn primary" to="/profile">📄 Hồ sơ cá nhân & ảnh đại diện</Link>
        {me.company_id && <Link className="btn" to="/work?tab=leaves">🌴 Nghỉ phép</Link>}
        {me.company_id && <Link className="btn" to="/work?tab=claims">📞 Khai việc nhanh</Link>}
        {(me.role === 'owner' || !me.company_id) && <Link className="btn" to="/upgrade">🏢 {me.role === 'owner' ? 'Gói doanh nghiệp' : 'Nâng cấp tài khoản doanh nghiệp'}</Link>}
        {me.is_platform_admin && <Link className="btn" to="/platform">🛠 Quản trị nền tảng</Link>}
        {me.company_id && <>
          <Link className="btn" to="/notifications">🔔 Thông báo</Link>
          <Link className="btn" to="/escalations">⤴ Chuyển cấp đến tôi</Link>
          <Link className="btn" to="/work?tab=records">📝 Bản ghi tự khai báo của tôi</Link>
          {me.role !== 'employee' && <Link className="btn" to="/team">👥 Tình trạng nhân sự tuần</Link>}
          {(me.role === 'handler' || me.headed_departments.length > 0) && <Link className="btn" to="/tech">🛠 Bảng điều khiển kỹ thuật</Link>}
        </>}
      </div>
      {isHRRole(me.role) && !isAdminRole(me.role) && (
        <><div className="section-title">Nhân sự</div><div className="actions stack"><Link className="btn" to="/admin/members">👥 Thành viên & kiểm duyệt</Link><Link className="btn" to="/work?tab=leaves&scope=hr">📄 Đơn nghỉ đã duyệt</Link></div></>
      )}
      {isAdminRole(me.role) && (
        <>
          <div className="section-title">Quản trị công ty</div>
          <div className="actions stack">
            <Link className="btn" to="/admin/members">👥 Thành viên, vai trò & kiểm duyệt</Link>
            <Link className="btn" to="/admin/settings">⚙️ Cấu hình: lịch làm việc, chính sách, SLA, trọng số, danh mục</Link>
          </div>
        </>
      )}
      <div className="section-title">Tài khoản</div>
      <div className="actions stack">
        <button className="btn" onClick={() => setPw(true)}>Đổi mật khẩu</button>
        <button className="btn danger" onClick={logout}>Đăng xuất</button>
      </div>
      <Sheet open={pw} onClose={() => setPw(false)} title="Đổi mật khẩu"><ChangePw onDone={() => { setPw(false); logout(); }} /></Sheet>
    </div>
  );
}

function ChangePw({ onDone }: { onDone: () => void }) {
  const [o, setO] = useState(''); const [n, setN] = useState('');
  const a = useAction();
  return (
    <>
      <Field label="Mật khẩu hiện tại"><input type="password" value={o} onChange={(e) => setO(e.target.value)} /></Field>
      <Field label="Mật khẩu mới" hint="Tối thiểu 8 ký tự. Mọi phiên đăng nhập khác sẽ bị thu hồi."><input type="password" value={n} onChange={(e) => setN(e.target.value)} /></Field>
      <ErrorBox error={a.error} />
      <button className="btn primary block" disabled={a.busy} onClick={() => a.run(async () => { await post('/auth/change-password', { oldPassword: o, newPassword: n }); onDone(); })}>Cập nhật</button>
    </>
  );
}
