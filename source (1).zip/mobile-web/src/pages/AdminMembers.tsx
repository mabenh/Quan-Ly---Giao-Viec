import { useState } from 'react';
import { Link } from 'react-router-dom';
import { get, patch, post } from '../api';
import { isAdminRole, useAuth } from '../auth';
import { Avatar, Badge, Card, ErrorBox, Field, Header, Loading, Select, Sheet, useAction, useLoad } from '../ui';
import { MEMBER_STATUS, PLAN_NAME, ROLE } from '../labels';

export default function AdminMembers() {
  const { me } = useAuth();
  const [search, setSearch] = useState('');
  const { data, error, loading, reload } = useLoad(() => get(`/company/members?q=${encodeURIComponent(search)}`), [search]);
  const depts = useLoad(() => get('/company/departments'), []);
  const [edit, setEdit] = useState<any>(null);
  const [invite, setInvite] = useState(false);
  const [review, setReview] = useState<any>(null);
  const admin = isAdminRole(me?.role);
  const roles = me?.role === 'owner' ? ROLE : Object.fromEntries(Object.entries(ROLE).filter(([k]) => k !== 'owner'));
  const pending = (data || []).filter((m: any) => m.status === 'pending_hr');
  const active = (data || []).filter((m: any) => m.status !== 'pending_hr');
  const used = (data || []).filter((m: any) => ['active', 'pending_hr'].includes(m.status)).length;
  return (
    <>
      <Header title="Thành viên" back="/me" right={<button className="btn primary sm" onClick={() => setInvite(true)}>＋ Thêm bằng SĐT</button>} />
      <div className="page">
        {me?.plan && <div className="small muted">Gói {PLAN_NAME[me.plan]}: {used}/{me.member_limit} thành viên{me.role === 'owner' && <> · <Link to="/upgrade">Nâng cấp gói</Link></>}</div>}
        <input placeholder="Tìm theo tên / SĐT" value={search} onChange={(e) => setSearch(e.target.value)} />
        <ErrorBox error={error} />
        {loading && !data && <Loading />}
        {pending.length > 0 && (
          <>
            <div className="section-title">Chờ nhân sự kiểm duyệt ({pending.length})</div>
            {pending.map((m: any) => (
              <Card key={m.id} className="pinned" onClick={() => setReview(m)}>
                <div className="row"><Avatar userId={m.user_id} name={m.name} has={m.has_avatar} /><div style={{ flex: 1 }}><b>{m.name}</b><div className="small muted">{m.phone} · đề nghị bởi {m.added_by_name || '—'}</div></div><Badge tone="amber">Chờ duyệt</Badge></div>
              </Card>
            ))}
          </>
        )}
        <div className="section-title">Thành viên ({active.length})</div>
        {active.map((m: any) => (
          <Card key={m.id} onClick={() => admin ? setEdit(m) : undefined}>
            <div className="row">
              <Avatar userId={m.user_id} name={m.name} has={m.has_avatar} />
              <div style={{ flex: 1, minWidth: 0 }}><b>{m.name}</b><div className="small muted">{m.phone || m.email} · {m.title || '—'}{m.department_name ? ` · ${m.department_name}` : ''}</div></div>
              <Badge tone="blue">{ROLE[m.role]}</Badge>
            </div>
            <div className="chip-row">
              {m.user_status === 'invited' && <Badge tone="amber">Chưa kích hoạt (chờ đăng ký bằng SĐT)</Badge>}
              {m.user_status === 'locked' && <Badge tone="red">Bị khóa</Badge>}
              {m.status === 'inactive' && <Badge tone="gray">Ngừng hoạt động</Badge>}
              <span className="small">Cấp trên: {m.supervisor_name || '—'}</span>
              <Link className="small" to={`/people/${m.user_id}`} onClick={(e) => e.stopPropagation()}>Xem hồ sơ</Link>
            </div>
          </Card>
        ))}
      </div>
      <Sheet open={!!edit} onClose={() => setEdit(null)} title={edit?.name || ''}>
        {edit && <MemberForm m={edit} roles={roles} members={active} depts={depts.data || []} onDone={() => { setEdit(null); reload(); }} />}
      </Sheet>
      <Sheet open={invite} onClose={() => setInvite(false)} title="Thêm thành viên bằng số điện thoại">
        {invite && <InviteForm roles={admin ? roles : { employee: ROLE.employee }} members={active} depts={depts.data || []} onDone={() => reload()} />}
      </Sheet>
      <Sheet open={!!review} onClose={() => setReview(null)} title="Kiểm duyệt thành viên">
        {review && <ReviewForm m={review} canReview={['owner', 'admin', 'hr'].includes(me?.role || '')} onDone={() => { setReview(null); reload(); }} />}
      </Sheet>
    </>
  );
}

function ReviewForm({ m, canReview, onDone }: { m: any; canReview: boolean; onDone: () => void }) {
  const [note, setNote] = useState('');
  const a = useAction();
  return (
    <>
      <div className="row" style={{ display: 'flex', gap: 10, alignItems: 'center' }}><Avatar userId={m.user_id} name={m.name} has={m.has_avatar} size="lg" /><div><b>{m.name}</b><div className="small muted">{m.phone}</div><div className="small">Đề nghị bởi {m.added_by_name}{m.hr_note ? ` · ${m.hr_note}` : ''}</div></div></div>
      <Link className="btn block" style={{ margin: '10px 0' }} to={`/people/${m.user_id}`}>📄 Xem hồ sơ xin việc</Link>
      {canReview ? (
        <>
          <Field label="Ghi chú (bắt buộc khi từ chối)"><textarea value={note} onChange={(e) => setNote(e.target.value)} /></Field>
          <ErrorBox error={a.error} />
          <div className="actions">
            <button className="btn primary" disabled={a.busy} onClick={() => a.run(async () => { await post(`/company/members/${m.id}/hr-review`, { decision: 'approve', note: note || undefined }); onDone(); })}>✔ Duyệt</button>
            <button className="btn danger" disabled={a.busy} onClick={() => a.run(async () => { await post(`/company/members/${m.id}/hr-review`, { decision: 'reject', note }); onDone(); })}>Từ chối</button>
          </div>
        </>
      ) : <div className="alert info small">Chỉ thành viên vai trò Quản lý nhân sự (hoặc Chủ doanh nghiệp/Quản trị) được kiểm duyệt.</div>}
    </>
  );
}

function InviteForm({ roles, members, depts, onDone }: { roles: Record<string, string>; members: any[]; depts: any[]; onDone: () => void }) {
  const [f, setF] = useState<any>({ phone: '', name: '', role: 'employee', title: '', departmentId: '', supervisorMemberId: '' });
  const [msg, setMsg] = useState<string | null>(null);
  const a = useAction();
  const up = (p: any) => setF((x: any) => ({ ...x, ...p }));
  return (
    <>
      <Field label="Số điện thoại" required><input type="tel" inputMode="tel" value={f.phone} onChange={(e) => up({ phone: e.target.value })} /></Field>
      <Field label="Họ và tên đầy đủ" hint="Bắt buộc nếu số này chưa có tài khoản"><input value={f.name} onChange={(e) => up({ name: e.target.value })} /></Field>
      <Field label="Vai trò"><Select value={f.role} onChange={(v) => up({ role: v })} options={roles} /></Field>
      <Field label="Chức danh"><input value={f.title} onChange={(e) => up({ title: e.target.value })} /></Field>
      <Field label="Bộ phận"><Select value={f.departmentId} onChange={(v) => up({ departmentId: v })} options={depts.map((d) => [d.id, d.name])} placeholder="— Không —" /></Field>
      <Field label="Cấp trên trực tiếp"><Select value={f.supervisorMemberId} onChange={(v) => up({ supervisorMemberId: v })} options={members.map((x) => [x.id, `${x.name} (${ROLE[x.role]})`])} placeholder="— Không —" /></Field>
      {msg && <div className="alert ok small">{msg}</div>}
      <ErrorBox error={a.error} />
      <button className="btn primary block" disabled={a.busy || !f.phone} onClick={() => a.run(async () => {
        const r = await post('/company/members', { phone: f.phone, name: f.name || undefined, role: f.role, title: f.title || undefined, departmentId: f.departmentId || undefined, supervisorMemberId: f.supervisorMemberId || undefined });
        setMsg(`Đã ${r.status === 'pending_hr' ? 'gửi nhân sự duyệt' : 'thêm'} ${r.name}.${r.message ? ' ' + r.message : ''}`);
        setF({ ...f, phone: '', name: '' }); onDone();
      })}>Thêm</button>
    </>
  );
}

function MemberForm({ m, roles, members, depts, onDone }: { m: any; roles: Record<string, string>; members: any[]; depts: any[]; onDone: () => void }) {
  const [f, setF] = useState<any>({
    role: m.role, title: m.title || '', departmentId: m.department_id || '', supervisorMemberId: m.supervisor_member_id || '',
    canCrossGroupAssign: !!m.can_cross_group_assign, status: m.status,
  });
  const a = useAction();
  const up = (p: any) => setF((x: any) => ({ ...x, ...p }));
  return (
    <>
      <p className="small muted">{m.phone} · {MEMBER_STATUS[m.status]}</p>
      <Field label="Vai trò" hint="Nâng cấp thành viên lên Quản lý / Quản lý nhân sự / Quản trị"><Select value={f.role} onChange={(v) => up({ role: v })} options={roles} /></Field>
      <Field label="Chức danh"><input value={f.title} onChange={(e) => up({ title: e.target.value })} /></Field>
      <Field label="Bộ phận"><Select value={f.departmentId} onChange={(v) => up({ departmentId: v })} options={depts.map((d) => [d.id, d.name])} placeholder="— Không —" /></Field>
      <Field label="Cấp trên trực tiếp" hint="Dùng cho duyệt nghỉ phép, chuyển cấp và khiếu nại"><Select value={f.supervisorMemberId} onChange={(v) => up({ supervisorMemberId: v })} options={members.filter((x) => x.id !== m.id).map((x) => [x.id, `${x.name} (${ROLE[x.role]})`])} placeholder="— Không —" /></Field>
      <label className="check"><input type="checkbox" checked={f.canCrossGroupAssign} onChange={(e) => up({ canCrossGroupAssign: e.target.checked })} /> Được giao việc chéo nhóm</label>
      <Field label="Trạng thái"><Select value={f.status} onChange={(v) => up({ status: v })} options={{ active: 'Hoạt động', inactive: 'Ngừng hoạt động' }} /></Field>
      <ErrorBox error={a.error} />
      <button className="btn primary block" disabled={a.busy} onClick={() => a.run(async () => {
        await patch(`/company/members/${m.id}`, { role: f.role, title: f.title || null, departmentId: f.departmentId || null, supervisorMemberId: f.supervisorMemberId || null, canCrossGroupAssign: f.canCrossGroupAssign, status: f.status });
        onDone();
      })}>Lưu</button>
      <div className="actions">
        <Link className="btn" to={`/people/${m.user_id}`}>Xem hồ sơ</Link>
        <button className="btn danger" disabled={a.busy} onClick={() => a.run(async () => { await patch(`/company/members/${m.id}`, { lockUser: m.user_status !== 'locked' }); onDone(); })}>
          {m.user_status === 'locked' ? 'Mở khóa tài khoản' : 'Khóa tài khoản & thu hồi phiên'}
        </button>
      </div>
    </>
  );
}
