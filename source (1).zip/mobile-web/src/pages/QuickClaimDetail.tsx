import { useEffect, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { api, get, post } from '../api';
import { Badge, Card, ErrorBox, Field, Header, KV, Loading, Sheet, useAction, useLoad } from '../ui';
import { CHANNEL, CLAIM_STATUS, CLAIM_TONE, fmtDT, toLocalInput, fromLocalInput } from '../labels';
import { Files } from './TaskDetail';

export function AudioFile({ id, name }: { id: string; name: string }) {
  const [src, setSrc] = useState<string | null>(null);
  useEffect(() => { let u: string | null = null; api('GET', `/files/${id}`, undefined, { raw: true }).then(async (r: Response) => { if (r.ok) { u = URL.createObjectURL(await r.blob()); setSrc(u); } }); return () => { if (u) URL.revokeObjectURL(u); }; }, [id]);
  return <div><div className="small">🎙 {name}</div>{src ? <audio controls src={src} style={{ width: '100%' }} /> : <span className="small muted">Đang tải…</span>}</div>;
}

export default function QuickClaimDetail() {
  const { id } = useParams();
  const nav = useNavigate();
  const { data: c, error, loading, reload, setData } = useLoad(() => get(`/quick-claims/${id}`), [id]);
  const [sheet, setSheet] = useState<string | null>(null);
  const [reason, setReason] = useState('');
  const [due, setDue] = useState('');
  const a = useAction();
  if (loading && !c) return <Loading />;
  if (!c) return <div className="page"><ErrorBox error={error} /></div>;
  const p = c.permissions;
  const audios = c.files.filter((f: any) => f.mime.startsWith('audio/'));
  return (
    <>
      <Header title="Khai việc nhanh" back="/work?tab=claims" />
      <div className="page">
        <h2>{c.title}</h2>
        <Badge tone={CLAIM_TONE[c.status]}>{CLAIM_STATUS[c.status]}</Badge>
        {p.can_confirm && <div className="alert warn"><b>{c.creator_name}</b> đã khai việc này. Bạn chỉ cần xác nhận, không cần khai thêm.</div>}
        <Card>
          <KV k="Hình thức" v={`${CHANNEL[c.channel]} · ${fmtDT(c.occurred_at)}`} />
          <KV k="Người giao" v={c.manager_name} />
          <KV k="Người thực hiện" v={c.assignee_name} />
          <KV k="Người khai" v={c.creator_name} />
          <KV k="Nhóm" v={c.group_name} />
          {c.due_at && <KV k="Hạn hoàn thành" v={fmtDT(c.due_at)} />}
          {c.estimated_hours && <KV k="Thời lượng dự kiến" v={`${c.estimated_hours} giờ`} />}
          {c.already_done && <KV k="Trạng thái việc" v="Đã làm xong" />}
          {c.response_reason && <KV k={c.status === 'rejected' ? 'Lý do từ chối' : 'Ghi chú'} v={c.response_reason} />}
        </Card>
        {c.description && <Card><div className="crit">{c.description}</div></Card>}
        {audios.map((f: any) => <Card key={f.id}><AudioFile id={f.id} name={f.filename} /></Card>)}
        <ErrorBox error={a.error} />
        <div className="actions">
          {p.can_confirm && <button className="btn primary" onClick={() => { setDue(c.due_at ? toLocalInput(new Date(c.due_at)) : ''); setSheet('confirm'); }}>✔ Xác nhận</button>}
          {p.can_confirm && <button className="btn danger" onClick={() => setSheet('reject')}>Không đúng</button>}
          {p.can_cancel && <button className="btn" disabled={a.busy} onClick={() => a.run(async () => setData(await post(`/quick-claims/${id}/cancel`)))}>Hủy khai việc</button>}
          {p.can_convert && <button className="btn primary" disabled={a.busy} onClick={() => a.run(async () => { const r = await post(`/quick-claims/${id}/to-work-record`); nav(`/work-records/${r.work_record_id}`); })}>Chuyển thành bản ghi tự khai báo</button>}
          {c.task_id && <Link className="btn" to={`/tasks/${c.task_id}`}>Mở nhiệm vụ đã tạo</Link>}
          {c.work_record_id && <Link className="btn" to={`/work-records/${c.work_record_id}`}>Mở bản ghi tự khai báo</Link>}
        </div>
        {p.can_convert && <p className="small muted">Nếu bạn chắc chắn đã được giao việc, chuyển sang bản ghi tự khai báo để có quy trình phản hồi, tranh chấp và khiếu nại.</p>}
        <Files parentType="quick_claim" parentId={c.id} files={c.files.filter((f: any) => !f.mime.startsWith('audio/'))} onDone={reload} canUpload={c.status === 'pending'} />
      </div>
      <Sheet open={sheet === 'confirm'} onClose={() => setSheet(null)} title="Xác nhận khai việc">
        <p className="small">Xác nhận sẽ tạo nhiệm vụ chính thức cho <b>{c.assignee_name}</b>{c.already_done ? ', chuyển thẳng sang chờ nghiệm thu' : ''}.</p>
        <Field label="Hạn hoàn thành (có thể chỉnh)"><input type="datetime-local" value={due} onChange={(e) => setDue(e.target.value)} /></Field>
        <button className="btn primary block" disabled={a.busy} onClick={() => a.run(async () => { setData(await post(`/quick-claims/${id}/confirm`, { dueAt: fromLocalInput(due) })); setSheet(null); })}>Xác nhận</button>
      </Sheet>
      <Sheet open={sheet === 'reject'} onClose={() => setSheet(null)} title="Không xác nhận">
        <Field label="Lý do cụ thể" required><textarea value={reason} onChange={(e) => setReason(e.target.value)} /></Field>
        <ErrorBox error={a.error} />
        <button className="btn danger block" disabled={a.busy} onClick={() => a.run(async () => { setData(await post(`/quick-claims/${id}/reject`, { reason })); setSheet(null); })}>Gửi</button>
      </Sheet>
    </>
  );
}
