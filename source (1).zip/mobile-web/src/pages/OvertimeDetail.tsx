import { useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { get, post } from '../api';
import { Badge, Card, ErrorBox, Field, Header, KV, Loading, Timeline, useAction, useLoad } from '../ui';
import { OT_STATUS, OT_TONE, OT_TYPE, fmtDT, hours } from '../labels';
import { Files } from './TaskDetail';

export default function OvertimeDetail() {
  const { id } = useParams();
  const { data: o, error, loading, reload, setData } = useLoad(() => get(`/overtime-records/${id}`), [id]);
  const [reason, setReason] = useState('');
  const a = useAction();
  if (loading && !o) return <Loading />;
  if (!o) return <div className="page"><ErrorBox error={error} /></div>;
  return (
    <>
      <Header title="Tăng ca" back="/work?tab=overtime" />
      <div className="page">
        <h2>{hours(o.minutes)} · {o.member_name}</h2>
        <Badge tone={OT_TONE[o.approval_status]}>{OT_STATUS[o.approval_status]}</Badge>
        <Card>
          <KV k="Thời gian" v={`${fmtDT(o.start_at)} → ${fmtDT(o.end_at)}`} />
          <KV k="Phân loại" v={OT_TYPE[o.ot_type]} />
          <KV k="Nguyên nhân" v={o.cause} />
          <KV k="Người yêu cầu" v={o.requested_by_name} />
          <KV k="Thông báo trước" v={o.notified_in_advance ? 'Có' : 'Không'} />
          <KV k="Nhiệm vụ" v={o.task_id ? <Link to={`/tasks/${o.task_id}`}>{o.task_title}</Link> : '—'} />
          <KV k="Báo cáo trở ngại" v={o.report_id ? <Link to={`/reports/${o.report_id}`}>Xem</Link> : '—'} />
          {o.impact && <KV k="Ảnh hưởng" v={o.impact} />}
          {o.reviewer_name && <KV k="Người xác nhận" v={`${o.reviewer_name} · ${fmtDT(o.reviewed_at)}`} />}
          {o.review_reason && <KV k="Lý do" v={o.review_reason} />}
        </Card>
        {o.can_review && (
          <Card>
            <Field label="Lý do (bắt buộc khi từ chối)"><textarea value={reason} onChange={(e) => setReason(e.target.value)} /></Field>
            <ErrorBox error={a.error} />
            <div className="actions">
              <button className="btn primary" disabled={a.busy} onClick={() => a.run(async () => setData(await post(`/overtime-records/${id}/review`, { decision: 'confirm', reason: reason || undefined })))}>Xác nhận</button>
              <button className="btn danger" disabled={a.busy} onClick={() => a.run(async () => setData(await post(`/overtime-records/${id}/review`, { decision: 'reject', reason })))}>Từ chối</button>
            </div>
          </Card>
        )}
        <Files parentType="overtime" parentId={o.id} files={[]} onDone={reload} />
        <div className="section-title">Lịch sử</div>
        <Timeline items={o.history.map((h: any) => ({ at: h.created_at, title: `${h.action} · ${h.actor_name || ''}`, body: h.reason }))} />
      </div>
    </>
  );
}
