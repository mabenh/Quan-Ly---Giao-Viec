import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { get, post } from '../api';
import { isAdminRole, isManagerRole, useAuth } from '../auth';
import { Badge, Card, Empty, ErrorBox, Field, Loading, Select, Sheet, useAction, useLoad } from '../ui';

export default function Groups() {
  const { me } = useAuth();
  const nav = useNavigate();
  const { data, error, loading } = useLoad(() => get('/groups'), []);
  const [open, setOpen] = useState(false);
  return (
    <div className="page">
      <div className="row" style={{ display: 'flex', alignItems: 'center' }}>
        <h1 style={{ flex: 1 }}>Nhóm</h1>
        {isManagerRole(me?.role) && <button className="btn primary sm" onClick={() => setOpen(true)}>＋ Tạo nhóm</button>}
      </div>
      <ErrorBox error={error} />
      {loading && !data && <Loading />}
      {data && data.length === 0 && <Empty>Bạn chưa thuộc nhóm nào</Empty>}
      {data?.map((g: any) => (
        <Card key={g.id} to={`/groups/${g.id}`}>
          <div className="row"><span className="title" style={{ flex: 1 }}>{g.name}</span>{g.is_manager && <Badge tone="blue">Bạn quản lý</Badge>}</div>
          <div className="small muted">Quản lý: {g.manager_name} · {g.member_count} thành viên</div>
          <div className="chip-row"><Badge tone="gray">{g.open_tasks} việc đang mở</Badge>{g.overdue_tasks > 0 && <Badge tone="red">{g.overdue_tasks} quá hạn</Badge>}</div>
        </Card>
      ))}
      <Sheet open={open} onClose={() => setOpen(false)} title="Tạo nhóm mới"><CreateGroup onDone={(id) => nav(`/groups/${id}`)} isAdmin={isAdminRole(me?.role)} /></Sheet>
    </div>
  );
}

function CreateGroup({ onDone, isAdmin }: { onDone: (id: string) => void; isAdmin: boolean }) {
  const members = useLoad(() => get('/company/members'), []);
  const [name, setName] = useState(''); const [desc, setDesc] = useState(''); const [mgr, setMgr] = useState(''); const [ids, setIds] = useState<string[]>([]);
  const a = useAction();
  const active = (members.data || []).filter((m: any) => m.status === 'active');
  return (
    <>
      <Field label="Tên nhóm" required><input value={name} onChange={(e) => setName(e.target.value)} /></Field>
      <Field label="Mô tả"><textarea value={desc} onChange={(e) => setDesc(e.target.value)} /></Field>
      {isAdmin && <Field label="Quản lý chính" hint="Mặc định là bạn"><Select value={mgr} onChange={setMgr} options={active.filter((m: any) => ['manager', 'admin', 'owner'].includes(m.role)).map((m: any) => [m.id, m.name])} placeholder="— Tôi —" /></Field>}
      <Field label="Thành viên">
        <div style={{ maxHeight: 240, overflowY: 'auto' }}>
          {active.map((m: any) => (
            <label key={m.id} className="check"><input type="checkbox" checked={ids.includes(m.id)} onChange={(e) => setIds(e.target.checked ? [...ids, m.id] : ids.filter((x) => x !== m.id))} />{m.name} <span className="muted small">{m.title}</span></label>
          ))}
        </div>
      </Field>
      <ErrorBox error={a.error} />
      <button className="btn primary block" disabled={a.busy} onClick={() => a.run(async () => { const g = await post('/groups', { name, description: desc || undefined, managerMemberId: mgr || undefined, memberIds: ids }); onDone(g.id); })}>Tạo nhóm</button>
    </>
  );
}
