import { useState } from 'react';
import { Link } from 'react-router-dom';
import { get, qs } from '../api';
import { isHRRole, isManagerRole, useAuth } from '../auth';
import { Badge, Card, ErrorBox, Loading, Tabs, useLoad } from '../ui';
import Calendar from '../Calendar';
import { LEAVE_TYPE, TASK_STATUS, TASK_TONE, fmtD, isoDate, relDue } from '../labels';

type Tile = [number, string, string, ('warn' | 'attn')?];
const Stat = ({ t: [n, l, to, tone] }: { t: Tile }) => (
  <Link to={to} className={`stat ${n > 0 && tone ? tone : ''}`}><div className="n">{n}</div><div className="l">{l}</div></Link>
);

export function TaskRow({ t, showOwner }: { t: any; showOwner?: boolean }) {
  return (
    <Card to={`/tasks/${t.id}`} className={t.pinned ? 'pinned' : ''}>
      <div className="row">{t.pinned && <span className="pin" title="Việc gấp được ghim">📌</span>}<span className="title" style={{ flex: 1 }}>{t.title}</span><Badge tone={TASK_TONE[t.status]}>{TASK_STATUS[t.status]}</Badge></div>
      <div className="row small muted" style={{ marginTop: 4 }}>
        <span>{t.code} · {t.group_name}{showOwner && t.owner_name ? ` · ${t.owner_name}` : ''}</span><span className="spacer" />
        {t.is_overdue ? <Badge tone="red">⏰ {relDue(t.due_at)}</Badge> : <span>Hạn: {relDue(t.due_at)}</span>}
      </div>
      {(t.urgent || t.carry_count > 0) && (
        <div className="chip-row">
          {t.urgent && <Badge tone="red">Gấp</Badge>}
          {t.carry_count > 0 && <Badge tone="amber">↪ Chuyển từ {fmtD(t.original_plan_date)} ({t.carry_count} ngày)</Badge>}
        </div>
      )}
    </Card>
  );
}

export default function Home() {
  const { me } = useAuth();
  const [day, setDay] = useState(isoDate(new Date()));
  const [today, setToday] = useState(isoDate(new Date()));
  const [picked, setPicked] = useState(false);
  const mgr = isManagerRole(me?.role) || me?.role === 'reviewer';
  const [scope, setScope] = useState<'mine' | 'team'>('mine');
  const { data: d, error, loading } = useLoad(() => get('/dashboard'), []);
  const dayList = useLoad(() => get('/tasks' + qs({ planDate: day, mine: scope === 'mine' ? 'any' : undefined, limit: 100 })), [day, scope]);
  const cal = useLoad(() => get('/calendar' + qs({ from: day, to: day, scope })), [day, scope]);
  if (loading && !d) return <Loading />;
  if (!d) return <div className="page"><ErrorBox error={error} /></div>;
  const m = d.me; const g = d.manage;
  const isToday = day === today;
  const myTiles: Tile[] = ([
    [m.tasks.pinned, 'Việc gấp được ghim', '/work?tab=tasks&mine=any&pinned=true', 'warn'],
    [m.tasks.overdue, 'Quá hạn', '/work?tab=tasks&mine=any&overdue=true', 'warn'],
    [m.tasks.revision, 'Cần chỉnh sửa', '/work?tab=tasks&mine=any&status=revision_requested', 'warn'],
    [m.tasks.due_soon, 'Sắp đến hạn (48h)', '/work?tab=tasks&mine=any', 'attn'],
    [g.claims_to_confirm, 'Khai việc chờ tôi xác nhận', '/work?tab=claims', 'warn'],
    [m.work_records.need_response, 'Bản ghi cần tôi phản hồi', '/work?tab=records', 'warn'],
    [m.reports.need_confirm, 'Trở ngại chờ tôi xác nhận', '/work?tab=reports', 'attn'],
    [m.claims_waiting, 'Khai việc chờ người kia xác nhận', '/work?tab=claims'],
    [m.work_records.waiting_manager, 'Bản ghi chờ quản lý xác nhận', '/work?tab=records'],
    [m.leaves.pending, 'Đơn nghỉ chờ duyệt', '/work?tab=leaves'],
    [m.reports.open, 'Trở ngại tôi báo đang mở', '/work?tab=reports'],
  ] as Tile[]).filter((t) => t[0] > 0);
  const manageTiles: Tile[] = ([
    [g.tasks_pending_review, 'Việc chờ nghiệm thu', '/work?tab=tasks&status=pending_review', 'attn'],
    [g.work_records_to_review.n, `Bản ghi cần xác nhận${g.work_records_to_review.overdue ? ` (${g.work_records_to_review.overdue} quá hạn)` : ''}`, '/work?tab=records&scope=review', 'warn'],
    [g.leaves_to_approve, 'Đơn nghỉ cần duyệt', '/work?tab=leaves&scope=approve', 'warn'],
    [g.members_pending_hr, 'Thành viên chờ nhân sự duyệt', '/admin/members', 'warn'],
    [g.overtime_pending, 'Tăng ca chờ xác nhận', '/work?tab=overtime&scope=team', 'attn'],
    [g.appeals_to_resolve, 'Khiếu nại cần giải quyết', '/work?tab=records&scope=review', 'warn'],
    [g.reports_holding.n, `Trở ngại đang giữ${g.reports_holding.near_due ? ` · ${g.reports_holding.near_due} gần hạn` : ''}`, '/work?tab=reports&scope=handling', 'attn'],
    [g.reports_holding.overdue, 'Trở ngại quá SLA', '/work?tab=reports&scope=handling', 'warn'],
    [g.escalations_open, 'Chuyển cấp đến tôi', '/escalations', 'warn'],
    [mgr ? g.team_tasks.overdue : 0, 'Việc nhóm quá hạn', '/work?tab=tasks&overdue=true', 'warn'],
  ] as Tile[]).filter((t) => t[0] > 0);
  const leaves = cal.data?.days?.[0]?.leaves || [];
  const dueToday = cal.data?.days?.[0]?.due_open || 0;

  return (
    <div className="page">
      {mgr && <Tabs value={scope} onChange={(v) => setScope(v as any)} tabs={[['mine', 'Lịch của tôi'], ['team', 'Lịch nhóm tôi quản lý']]} />}
      <Calendar selected={day} onSelect={(d) => { setPicked(true); setDay(d); }} scope={scope} refreshKey={scope} onToday={(t) => { setToday(t); if (!picked) setDay(t); }} />

      <div className="row" style={{ display: 'flex', alignItems: 'center', marginTop: 4 }}>
        <div className="section-title" style={{ flex: 1, margin: '10px 0 4px' }}>{isToday ? 'Việc hôm nay' : `Việc ngày ${fmtD(day)}`} ({dayList.data?.items.length ?? 0})</div>
        {dueToday > 0 && <Badge tone="amber">{dueToday} hạn chót</Badge>}
      </div>
      {leaves.length > 0 && <div className="alert info small">🌴 Nghỉ phép: {leaves.map((l: any) => `${l.name} (${LEAVE_TYPE[l.leave_type].toLowerCase()}${l.status === 'pending' ? ', chờ duyệt' : ''})`).join('; ')}</div>}
      {dayList.data && dayList.data.items.length === 0 && <div className="empty">Không có việc trong ngày này 🎉</div>}
      {dayList.data?.items.map((t: any) => <TaskRow key={t.id} t={t} showOwner={scope === 'team'} />)}
      {isToday && <p className="small muted">Việc chưa được xác nhận hoàn thành sẽ tự chuyển sang danh sách ngày hôm sau.</p>}

      <div className="quick">
        <Link className="btn" to="/quick/new">📞 Khai việc nhanh</Link>
        <Link className="btn" to="/leaves/new">🌴 Xin nghỉ phép</Link>
        <Link className="btn" to="/work-records/new">📝 Ghi nhận công việc</Link>
        <Link className="btn" to="/reports/new">⚠️ Báo cáo trở ngại</Link>
      </div>

      {myTiles.length > 0 && <><div className="section-title">Việc của tôi</div><div className="stats">{myTiles.map((t) => <Stat key={t[1]} t={t} />)}</div></>}
      {manageTiles.length > 0 && <><div className="section-title">Cần tôi xử lý</div><div className="stats">{manageTiles.map((t) => <Stat key={t[1]} t={t} />)}</div></>}
      {myTiles.length === 0 && manageTiles.length === 0 && <div className="empty">Không có mục nào cần bạn xử lý lúc này ✅</div>}
      <div className="actions">
        {mgr && <Link to="/team" className="btn">👥 Tình trạng nhân sự tuần</Link>}
        {(me?.role === 'handler' || (me?.headed_departments?.length ?? 0) > 0) && <Link to="/tech" className="btn">🛠 Bảng kỹ thuật</Link>}
        {isHRRole(me?.role) && g.members_pending_hr > 0 && <Link to="/admin/members" className="btn">✅ Duyệt thành viên</Link>}
      </div>
    </div>
  );
}
