import { useState } from 'react';
import { Link } from 'react-router-dom';
import { get, qs } from '../api';
import { isAdminRole, isHRRole, useAuth } from '../auth';
import { Avatar, Badge, Card, Empty, ErrorBox, Header, Loading, Select, useLoad } from '../ui';
import { AVAIL, LEAVE_TYPE, isoDate } from '../labels';

const monday = (d: Date) => { const x = new Date(d); x.setDate(x.getDate() - ((x.getDay() + 6) % 7)); return x; };
const DOW = ['T2', 'T3', 'T4', 'T5', 'T6', 'T7', 'CN'];

export default function TeamWeek() {
  const { me } = useAuth();
  const [start, setStart] = useState(monday(new Date()));
  const groups = useLoad(() => get('/groups'), []);
  const [groupId, setGroupId] = useState('');
  const days = Array.from({ length: 7 }, (_, i) => { const d = new Date(start); d.setDate(d.getDate() + i); return d; });
  const from = isoDate(days[0]); const to = isoDate(days[6]);
  const { data, error, loading } = useLoad(() => get('/team/availability' + qs({ from, to, groupId })), [from, groupId]);
  const managed = (groups.data || []).filter((g: any) => g.is_manager || isAdminRole(me?.role) || isHRRole(me?.role));
  const shift = (n: number) => { const d = new Date(start); d.setDate(d.getDate() + 7 * n); setStart(d); };
  const cell = (m: any, d: Date) => {
    const k = isoDate(d);
    const lv = m.leaves.find((l: any) => isoDate(new Date(l.start_at)) <= k && isoDate(new Date(l.end_at)) >= k);
    if (lv) return <div className={`c ${lv.status === 'approved' ? 'leave' : 'pend'}`} title={`${LEAVE_TYPE[lv.leave_type]}${lv.status === 'pending' ? ' (chờ duyệt)' : ''}`}>{lv.leave_type === 'day' ? 'Nghỉ' : '½'}</div>;
    const n = m.planned_by_day[k] || 0;
    return <div className={`c ${n >= 4 ? 'heavy' : ''}`} title={`${n} việc`}>{n || ''}</div>;
  };
  return (
    <>
      <Header title="Tình trạng nhân sự tuần" back />
      <div className="page">
        <div className="filters">
          <button className="btn sm" onClick={() => shift(-1)}>‹ Tuần trước</button>
          <b style={{ flex: 1, textAlign: 'center' }}>{days[0].toLocaleDateString('vi-VN')} – {days[6].toLocaleDateString('vi-VN')}</b>
          <button className="btn sm" onClick={() => shift(1)}>Tuần sau ›</button>
        </div>
        <Select value={groupId} onChange={setGroupId} options={managed.map((g: any) => [g.id, g.name])} placeholder="Tất cả thành viên tôi quản lý" aria-label="Nhóm" />
        <ErrorBox error={error} />
        {loading && !data && <Loading />}
        {data && data.members.length === 0 && <Empty>Không có thành viên</Empty>}
        {data && data.members.length > 0 && (
          <>
            <div className="table-wrap card" style={{ padding: 8 }}>
              <div className="week-grid">
                <div className="h" />{days.map((d, i) => <div key={i} className="h">{DOW[i]}<br />{d.getDate()}</div>)}
                {data.members.map((m: any) => [
                  <div key={m.member_id} className="nm">{m.name}</div>,
                  ...days.map((d, i) => <div key={m.member_id + i}>{cell(m, d)}</div>),
                ])}
              </div>
            </div>
            <div className="legend">Số = việc trong ngày · <span style={{ color: 'var(--teal)' }}>Nghỉ</span> = nghỉ phép đã duyệt · ½ = nghỉ theo ca/giờ · ô vàng = đơn chờ duyệt · ô đỏ = nhiều việc</div>
            <div className="section-title">Chi tiết</div>
            {data.members.map((m: any) => (
              <Card key={m.member_id}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                  <Avatar userId={m.user_id} name={m.name} has={m.has_avatar} />
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <Link to={`/people/${m.user_id}`}><b>{m.name}</b></Link><div className="small muted">{m.title || ''}</div>
                  </div>
                  <Badge tone={AVAIL[m.status][1]}>{AVAIL[m.status][0]}</Badge>
                </div>
                <div className="small" style={{ marginTop: 6 }}>{m.open_tasks} việc đang mở · {m.open_hours} giờ dự kiến · {m.due_in_range} đến hạn trong tuần{m.overdue ? ` · ${m.overdue} quá hạn` : ''}{m.pinned ? ` · ${m.pinned} việc gấp` : ''}</div>
              </Card>
            ))}
          </>
        )}
      </div>
    </>
  );
}
