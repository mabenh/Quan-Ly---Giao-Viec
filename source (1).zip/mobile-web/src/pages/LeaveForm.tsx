import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { get, post } from '../api';
import { ErrorBox, Field, Header, Select, Tabs, useAction, useLoad } from '../ui';
import { LEAVE_TYPE, fromLocalInput, isoDate, toLocalInput } from '../labels';

export default function LeaveForm() {
  const nav = useNavigate();
  const company = useLoad(() => get('/company'), []);
  const tomorrow = isoDate(new Date(Date.now() + 86400000));
  const [type, setType] = useState('day');
  const [f, setF] = useState<any>({
    startDate: tomorrow, endDate: tomorrow, date: tomorrow, shift: 'morning',
    startAt: toLocalInput(new Date(Date.now() + 86400000)), endAt: toLocalInput(new Date(Date.now() + 86400000 + 2 * 3600000)),
    reason: '', handover: '',
  });
  const a = useAction();
  const up = (p: any) => setF((x: any) => ({ ...x, ...p }));
  const notice = company.data?.settings?.policies?.leaveNoticeHours || {};
  const shifts = company.data?.settings?.calendar?.shifts || [];
  const startIso = type === 'day' ? f.startDate : type === 'shift' ? f.date : f.startAt;
  const hoursAhead = startIso ? Math.round((new Date(type === 'day' || type === 'shift' ? startIso + 'T08:00' : startIso).getTime() - Date.now()) / 3600000) : 0;
  const need = type === 'sudden' ? 0 : notice[type] || 0;
  const submit = () => a.run(async () => {
    const body: any = { leaveType: type, reason: f.reason, handover: f.handover || undefined };
    if (type === 'day') Object.assign(body, { startDate: f.startDate, endDate: f.endDate });
    else if (type === 'shift') Object.assign(body, { date: f.date, shift: f.shift });
    else Object.assign(body, { startAt: fromLocalInput(f.startAt), endAt: fromLocalInput(f.endAt) });
    const l = await post('/leaves', body);
    nav(`/leaves/${l.id}`, { replace: true });
  });
  return (
    <>
      <Header title="Xin nghỉ phép" back />
      <div className="page">
        <Tabs value={type} onChange={(t) => { setType(t); if (t === 'sudden') up({ startAt: toLocalInput(new Date()), endAt: toLocalInput(new Date(Date.now() + 4 * 3600000)) }); }}
          tabs={[['day', 'Theo ngày'], ['shift', 'Theo ca'], ['hourly', 'Theo giờ'], ['sudden', 'Đột xuất']]} />
        {type === 'day' && (
          <div className="grid2">
            <Field label="Từ ngày" required><input type="date" value={f.startDate} onChange={(e) => up({ startDate: e.target.value, endDate: e.target.value > f.endDate ? e.target.value : f.endDate })} /></Field>
            <Field label="Đến ngày" required><input type="date" value={f.endDate} min={f.startDate} onChange={(e) => up({ endDate: e.target.value })} /></Field>
          </div>
        )}
        {type === 'shift' && (
          <div className="grid2">
            <Field label="Ngày" required><input type="date" value={f.date} onChange={(e) => up({ date: e.target.value })} /></Field>
            <Field label="Ca" required><Select value={f.shift} onChange={(v) => up({ shift: v })} options={shifts.map((s: any) => [s.key, `${s.label} (${s.start}–${s.end})`])} /></Field>
          </div>
        )}
        {(type === 'hourly' || type === 'sudden') && (
          <div className="grid2">
            <Field label="Bắt đầu" required><input type="datetime-local" value={f.startAt} onChange={(e) => up({ startAt: e.target.value })} /></Field>
            <Field label="Kết thúc" required><input type="datetime-local" value={f.endAt} onChange={(e) => up({ endAt: e.target.value })} /></Field>
          </div>
        )}
        {type === 'sudden'
          ? <div className="alert info small">Nghỉ đột xuất (ốm, việc gấp…) không yêu cầu báo trước. Quản lý sẽ được thông báo ngay.</div>
          : <div className={`alert small ${hoursAhead < need ? 'warn' : 'ok'}`}>Báo trước: khoảng {Math.max(0, hoursAhead)} giờ. Quy định tối thiểu cho {LEAVE_TYPE[type].toLowerCase()}: {need} giờ.{hoursAhead < need ? ' Đơn vẫn gửi được nhưng sẽ được ghi nhận là báo trước muộn.' : ''}</div>}
        <Field label="Lý do" required><textarea value={f.reason} onChange={(e) => up({ reason: e.target.value })} /></Field>
        <Field label="Bàn giao công việc" hint="Ai xử lý thay, việc nào cần lưu ý"><textarea value={f.handover} onChange={(e) => up({ handover: e.target.value })} /></Field>
        <ErrorBox error={a.error} />
        <button className="btn primary block" disabled={a.busy} onClick={submit}>Gửi đơn</button>
        <p className="small muted">Khi quản lý duyệt, đơn được xuất PDF và tự động gửi sang bộ phận nhân sự.</p>
      </div>
    </>
  );
}
