import { useMemo, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { download, get, post, qs } from '../api';
import { isAdminRole, isManagerRole, useAuth } from '../auth';
import { Bar, Card, Empty, ErrorBox, Loading, Score, Select, Tabs, useAction, useLoad } from '../ui';
import { COMP, OT_TYPE, PERIOD, RP_CAT, ROLE, SEVERITY, fmtDT, hours } from '../labels';

function periodOptions(type: string): [string, string][] {
  const now = new Date(); const out: [string, string][] = [];
  if (type === 'month') for (let i = 0; i < 12; i++) { const d = new Date(now.getFullYear(), now.getMonth() - i, 1); const k = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`; out.push([k, `Tháng ${String(d.getMonth() + 1).padStart(2, '0')}/${d.getFullYear()}`]); }
  if (type === 'quarter') { let y = now.getFullYear(); let q = Math.floor(now.getMonth() / 3) + 1; for (let i = 0; i < 8; i++) { out.push([`${y}-Q${q}`, `Quý ${q}/${y}`]); q--; if (q === 0) { q = 4; y--; } } }
  if (type === 'year') for (let i = 0; i < 4; i++) out.push([`${now.getFullYear() - i}`, `Năm ${now.getFullYear() - i}`]);
  return out;
}

export default function Performance() {
  const { me } = useAuth();
  const [sp, setSp] = useSearchParams();
  const groups = useLoad(() => get('/groups'), []);
  const periodType = sp.get('periodType') || 'month';
  const period = sp.get('period') || periodOptions(periodType)[0][0];
  const scopeType = sp.get('scopeType') || 'member';
  const managed = (groups.data || []).filter((g: any) => g.is_manager || isAdminRole(me?.role));
  const scopeId = sp.get('scopeId') || (scopeType === 'member' ? me?.member_id : scopeType === 'group' ? managed[0]?.id : '') || '';
  const snapshotId = sp.get('snapshotId') || '';
  const set = (p: Record<string, string | null>) => { const n = new URLSearchParams(sp); for (const [k, v] of Object.entries(p)) (v ? n.set(k, v) : n.delete(k)); setSp(n, { replace: true }); };
  const params = { periodType, period, scopeType, scopeId: scopeType === 'company' ? undefined : scopeId };
  const waiting = scopeType === 'group' && !scopeId;
  const { data: d, error, loading, reload } = useLoad(() => (snapshotId ? get(`/performance/reports/${snapshotId}`) : waiting ? Promise.resolve(null) : get('/performance/live' + qs(params))), [periodType, period, scopeType, scopeId, snapshotId]);
  const snaps = useLoad(() => get('/performance/reports'), []);
  const a = useAction();
  const scopeOpts: [string, string][] = [['member', 'Cá nhân tôi'], ...(managed.length ? [['group', 'Nhóm'] as [string, string]] : []), ...(isAdminRole(me?.role) ? [['company', 'Toàn công ty'] as [string, string]] : [])];
  const exp = (format: string) => a.run(() => download('/performance/export' + qs(snapshotId ? { format, snapshotId } : { ...params, format }), `bao-cao-${scopeType}-${period}.${format}`));
  const self = d?.members?.find((m: any) => m.member_id === (scopeType === 'member' ? scopeId : me?.member_id));

  return (
    <div className="page">
      <h1>Đánh giá & báo cáo</h1>
      <Tabs value={periodType} onChange={(v) => set({ periodType: v, period: null, snapshotId: null })} tabs={Object.entries(PERIOD) as [string, string][]} />
      <div className="filters">
        <Select value={period} onChange={(v) => set({ period: v, snapshotId: null })} options={periodOptions(periodType)} aria-label="Kỳ" />
        <Select value={scopeType} onChange={(v) => set({ scopeType: v, scopeId: v === 'group' ? managed[0]?.id : null, snapshotId: null })} options={scopeOpts} aria-label="Phạm vi" />
        {scopeType === 'group' && <Select value={scopeId} onChange={(v) => set({ scopeId: v, snapshotId: null })} options={managed.map((g: any) => [g.id, g.name])} aria-label="Nhóm" />}
      </div>
      {snapshotId && <div className="alert info">Đang xem snapshot đã chốt lúc {fmtDT(d?.snapshot?.created_at)} (công thức v{d?.snapshot?.formula_version}). <button className="btn sm" onClick={() => set({ snapshotId: null })}>Xem số liệu hiện tại</button></div>}
      <div className="actions">
        <button className="btn sm" disabled={a.busy} onClick={() => exp('pdf')}>⬇ PDF</button>
        <button className="btn sm" disabled={a.busy} onClick={() => exp('xlsx')}>⬇ Excel</button>
        {!snapshotId && isManagerRole(me?.role) && <button className="btn sm" disabled={a.busy} onClick={() => confirm('Chốt báo cáo kỳ này? Snapshot sẽ giữ nguyên kể cả khi công thức thay đổi.') && a.run(async () => { const r = await post('/performance/reports/finalize', params); snaps.reload(); set({ snapshotId: r.id }); })}>🔒 Chốt kỳ (snapshot)</button>}
        {!snapshotId && <button className="btn sm" onClick={reload}>↻</button>}
      </div>
      <ErrorBox error={error || a.error} />
      {loading && !d && <Loading />}
      {d && (
        <>
          {scopeType === 'member' && self && <MemberCard m={self} cfg={d.meta.config} />}
          {scopeType !== 'member' && <Summary d={d} />}
          {scopeType !== 'member' && <MemberTable members={d.members} />}
          {d.groups?.length > 0 && scopeType !== 'member' && <GroupTable groups={d.groups} />}
          <Breakdown d={d} />
          {d.comparison && (
            <>
              <div className="section-title">So sánh với {d.comparison.previous_period.label}</div>
              <Card>
                {d.comparison.items.map((i: any) => (
                  <div className="kv" key={i.label}><span>{i.label}</span><b>{i.previous ?? '—'} → {i.current ?? '—'} {i.pct !== null && <span className={i.significant ? 'score amber' : 'muted'}>({i.pct > 0 ? '+' : ''}{i.pct}%)</span>}</b></div>
                ))}
                {d.comparison.notes.map((n: string) => <div key={n} className="small">• {n}</div>)}
              </Card>
            </>
          )}
          <div className="section-title">Lưu ý</div>
          <Card>{d.meta.notes.map((n: string) => <div key={n} className="small">• {n}</div>)}</Card>
        </>
      )}
      {snaps.data?.length > 0 && (
        <>
          <div className="section-title">Báo cáo đã chốt</div>
          {snaps.data.slice(0, 10).map((s: any) => (
            <Card key={s.id} onClick={() => set({ snapshotId: s.id, periodType: s.period_type })}>
              <div className="row"><b>{s.label}</b><span className="muted small">· {s.scope_type === 'company' ? 'Công ty' : s.scope_name}</span><span className="spacer" /><span className="small muted">{fmtDT(s.created_at)} · v{s.formula_version}</span></div>
            </Card>
          ))}
        </>
      )}
    </div>
  );
}

function MemberCard({ m, cfg }: { m: any; cfg: any }) {
  const w = cfg.employeeWeights;
  const expl: Record<string, string> = {
    V: `Khối lượng có trọng số ${m.v_raw ?? 0} (hệ số phức tạp × yêu cầu), chuẩn hóa theo vai trò`,
    T: `${m.on_time}/${m.timeliness_considered} việc đúng hạn${m.excused_late ? `; ${m.excused_late} việc trễ có trở ngại đã xác nhận không bị tính` : ''}`,
    Q: `Điểm nghiệm thu TB ${m.P ?? '—'}; tỷ lệ đạt lần đầu ${m.first_pass_rate ?? '—'}%`,
    D: 'Mức độ đảm nhận nhiệm vụ phức tạp (trung bình hệ số W)',
    R: 'Điểm quá trình/cập nhật/phối hợp từ người nghiệm thu',
  };
  return (
    <>
      <Card>
        <div className="row"><b style={{ flex: 1 }}>{m.name}</b><span className="muted small">{ROLE[m.role]}</span></div>
        <div style={{ display: 'flex', alignItems: 'baseline', gap: 8, margin: '8px 0' }}>
          <span style={{ fontSize: 40 }}><Score v={m.E} /></span><span className="muted">/100 điểm hiệu suất (E)</span>
        </div>
        {m.insufficient_data && <div className="alert warn">Chưa đủ dữ liệu cho mọi thành phần — điểm tính trên các thành phần có dữ liệu.</div>}
        <div className="comp-grid">
          {(['V', 'T', 'Q', 'D', 'R'] as const).map((k) => <div className="c" key={k}><div className="k">{k} · {Math.round(w[k] * 100)}%</div><div className="v"><Score v={m[k]} /></div></div>)}
        </div>
      </Card>
      <div className="section-title">Điểm được hình thành như thế nào</div>
      <Card>
        {(['V', 'T', 'Q', 'D', 'R'] as const).map((k) => (
          <div key={k} style={{ margin: '6px 0' }}>
            <div className="row"><b>{k} — {COMP[k]}</b><span className="spacer" /><Score v={m[k]} /></div>
            <Bar value={m[k]} /><div className="small muted">{expl[k]}</div>
          </div>
        ))}
        <div className="divider" />
        <div className="kv"><span>Việc thường xuyên hoàn thành</span><b>{m.regular.count} · điểm {m.regular.P ?? '—'}</b></div>
        <div className="kv"><span>Việc đột xuất (chung/đa dạng)</span><b>{m.unexpected.count} ({m.unexpected.common}/{m.unexpected.diverse}) · điểm {m.unexpected.P ?? '—'}</b></div>
        {m.contribution_share && <div className="kv"><span>Tỷ trọng đóng góp thường xuyên / đột xuất</span><b>{m.contribution_share.regular}% / {m.contribution_share.unexpected}%</b></div>}
        <div className="kv"><span>Giờ tăng ca (không tính điểm)</span><b>{hours(m.overtime_minutes)}</b></div>
        <div className="kv"><span>Báo cáo trở ngại đã gửi</span><b>{m.workplace_reports}</b></div>
        <div className="kv"><span>Bản ghi tự khai báo (gửi / chấp nhận / chưa giải quyết)</span><b>{m.work_records.submitted} / {m.work_records.accepted + m.work_records.partially_accepted} / {m.work_records.unresolved}</b></div>
        <p className="small muted">Bạn có quyền phản hồi về điểm: dùng bình luận trên nhiệm vụ liên quan hoặc liên hệ quản lý. Điểm chỉ mang tính tham khảo.</p>
      </Card>
    </>
  );
}

function Summary({ d }: { d: any }) {
  const t = d.summary.tasks;
  return (
    <>
      <div className="section-title">Tổng quan — {d.meta.period.label}</div>
      <div className="stats">
        <div className="stat"><div className="n">{t.assigned}</div><div className="l">Được giao</div></div>
        <div className="stat"><div className="n">{t.completed}</div><div className="l">Hoàn thành</div></div>
        <div className="stat warn"><div className="n">{t.overdue}</div><div className="l">Quá hạn</div></div>
        <div className="stat"><div className="n">{t.in_progress}</div><div className="l">Đang xử lý</div></div>
        <div className="stat"><div className="n">{t.cancelled}</div><div className="l">Hủy</div></div>
        <div className="stat"><div className="n"><Score v={d.summary.avg_E} /></div><div className="l">Điểm hiệu suất TB</div></div>
        <div className="stat"><div className="n">{Math.round(d.summary.overtime_minutes / 6) / 10}</div><div className="l">Giờ tăng ca</div></div>
        <div className="stat"><div className="n">{d.summary.workplace_reports}</div><div className="l">Báo cáo trở ngại</div></div>
      </div>
    </>
  );
}

function MemberTable({ members }: { members: any[] }) {
  const [sort, setSort] = useState('E');
  const rows = useMemo(() => [...members].sort((a, b) => (b[sort] ?? -1) - (a[sort] ?? -1)), [members, sort]);
  if (!members.length) return <Empty>Không có dữ liệu thành viên</Empty>;
  return (
    <>
      <div className="section-title">Hiệu suất thành viên</div>
      <div className="legend">E = 0.25V + 0.20T + 0.30Q + 0.15D + 0.10R · Chạm tiêu đề cột để sắp xếp</div>
      <div className="table-wrap card" style={{ padding: 6 }}>
        <table>
          <thead><tr><th>Nhân viên</th>{['E', 'V', 'T', 'Q', 'D', 'R'].map((k) => <th key={k} className="num" style={{ cursor: 'pointer' }} onClick={() => setSort(k)}>{k}{sort === k ? ' ▾' : ''}</th>)}<th className="num">HT</th><th className="num">Tăng ca</th><th className="num">Chưa GQ</th></tr></thead>
          <tbody>
            {rows.map((m) => (
              <tr key={m.member_id}>
                <td>{m.name}{m.insufficient_data && <span className="muted"> *</span>}</td>
                {['E', 'V', 'T', 'Q', 'D', 'R'].map((k) => <td key={k} className="num"><Score v={m[k]} /></td>)}
                <td className="num">{m.completed_count}</td><td className="num">{hours(m.overtime_minutes)}</td><td className="num">{m.work_records.unresolved}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div className="legend">* chưa đủ dữ liệu. Không xếp hạng theo giờ tăng ca. Bản ghi tranh chấp hiển thị riêng (Chưa GQ).</div>
    </>
  );
}

function GroupTable({ groups }: { groups: any[] }) {
  return (
    <>
      <div className="section-title">Nhóm</div>
      {groups.map((g) => (
        <Card key={g.id}>
          <div className="row"><b style={{ flex: 1 }}>{g.name}</b><span>Điểm TB <Score v={g.avg_E} /></span></div>
          <div className="small muted">{g.member_count} thành viên · hoàn thành {g.completed} · khối lượng có trọng số {g.weighted_volume} · tồn đọng {g.backlog} · quá hạn {g.overdue} · tăng ca {hours(g.overtime_minutes)} · trở ngại {g.workplace_reports}</div>
          {g.distribution.length > 0 && <div className="small" style={{ marginTop: 4 }}>Phân bổ: {g.distribution.map((x: any) => `${x.name.split(' ').slice(-1)[0]} ${x.completed}`).join(' · ')}</div>}
        </Card>
      ))}
    </>
  );
}

function Breakdown({ d }: { d: any }) {
  const [tab, setTab] = useState('bottleneck');
  const w = d.summary.work_records;
  return (
    <>
      <div className="section-title">Phân tích</div>
      <Tabs value={tab} onChange={setTab} tabs={[['bottleneck', `Điểm nghẽn (${d.bottlenecks.length})`], ['unexpected', 'Đột xuất'], ['overtime', 'Tăng ca'], ['reports', 'Trở ngại'], ['records', 'Tự khai báo']]} />
      <Card>
        {tab === 'bottleneck' && (d.bottlenecks.length ? d.bottlenecks.map((b: any, i: number) => (
          <div key={i} style={{ margin: '8px 0' }}><b>{b.title}</b><div className="small">{b.detail}</div><div className="small muted">→ {b.action}</div></div>
        )) : <div className="muted">Không phát hiện điểm nghẽn đáng kể.</div>)}
        {tab === 'unexpected' && (<>
          <div className="kv"><span>Yêu cầu chung</span><b>{d.summary.unexpected.common.count} việc · điểm {d.summary.unexpected.common.P ?? '—'}</b></div>
          <div className="kv"><span>Yêu cầu đa dạng</span><b>{d.summary.unexpected.diverse.count} việc · điểm {d.summary.unexpected.diverse.P ?? '—'}</b></div>
          <div className="small muted">Điểm việc đột xuất được tính và hiển thị riêng, không gộp lẫn với việc thường xuyên.</div>
        </>)}
        {tab === 'overtime' && (<>
          <div className="kv"><span>Tổng</span><b>{hours(d.overtime.total_minutes)} (chưa xác nhận {hours(d.overtime.unconfirmed_minutes)})</b></div>
          {d.overtime.by_cause.map((c: any) => <div className="kv" key={c.ot_type}><span>{OT_TYPE[c.ot_type]}</span><b>{hours(c.minutes)}</b></div>)}
          <div className="divider" /><b className="small">Theo người yêu cầu</b>
          {d.overtime.by_requester.map((c: any) => <div className="kv" key={c.requester}><span>{c.requester}</span><b>{hours(c.minutes)}</b></div>)}
        </>)}
        {tab === 'reports' && (<>
          <div className="kv"><span>Tổng / đang mở / quá SLA</span><b>{d.workplace.total} / {d.workplace.open} / {d.workplace.overdue_open}</b></div>
          {Object.entries(d.workplace.by_severity).map(([k, v]: any) => <div className="kv" key={k}><span>Mức {SEVERITY[k]}</span><b>{v}</b></div>)}
          {Object.entries(d.workplace.by_category).map(([k, v]: any) => <div className="kv" key={k}><span>{RP_CAT[k]}</span><b>{v}</b></div>)}
          {Object.entries(d.workplace.by_department).map(([k, v]: any) => <div className="kv" key={k}><span>Bộ phận: {k}</span><b>{v}</b></div>)}
          {d.workplace.sla_breaches.map((b: any, i: number) => <div className="kv" key={i}><span>Vi phạm SLA {b.stage} · {b.department || '—'} · {b.from_name || '—'}</span><b>{b.n}</b></div>)}
        </>)}
        {tab === 'records' && (<>
          {[['Đã gửi', w.submitted], ['Chấp nhận', w.accepted], ['Chấp nhận một phần', w.partially_accepted], ['Từ chối', w.rejected], ['Đang tranh chấp', w.disputed], ['Đang khiếu nại', w.appealed], ['Chưa giải quyết', w.unresolved], ['Quá hạn phản hồi', w.overdue]].map(([k, v]) => <div className="kv" key={k as string}><span>{k}</span><b>{v}</b></div>)}
          <div className="kv"><span>Thời lượng khai báo / được chấp nhận</span><b>{hours(w.claimed_minutes)} / {hours(w.accepted_minutes)}</b></div>
        </>)}
      </Card>
    </>
  );
}
