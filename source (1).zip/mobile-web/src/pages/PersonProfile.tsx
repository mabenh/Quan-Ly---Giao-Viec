import { useParams } from 'react-router-dom';
import { get } from '../api';
import { Avatar, Card, ErrorBox, Header, KV, Loading, useLoad } from '../ui';
import { ROLE, fmtD } from '../labels';

export function AutoHistory({ items }: { items: any[] }) {
  if (!items?.length) return <div className="empty">Chưa có dữ liệu — sẽ tự cập nhật khi làm việc trong doanh nghiệp dùng Việc Đến.</div>;
  return (
    <>
      {items.map((h, i) => (
        <Card key={i}>
          <div className="row" style={{ display: 'flex', gap: 8 }}><b style={{ flex: 1 }}>{h.company_name}</b><span className="small muted">{fmtD(h.joined_at)} → {h.status === 'active' ? 'nay' : fmtD(h.left_at)}</span></div>
          <div className="small muted">{ROLE[h.role]}{h.title ? ` · ${h.title}` : ''}{h.department ? ` · ${h.department}` : ''}{h.groups.length ? ` · Nhóm: ${h.groups.join(', ')}` : ''}</div>
          <KV k="Nhiệm vụ hoàn thành" v={`${h.tasks_completed} (đúng hạn ${h.on_time_rate ?? '—'}%)`} />
          <KV k="Điểm nghiệm thu trung bình" v={h.avg_task_score ?? '—'} />
          <KV k="Việc phức tạp / đột xuất" v={`${h.complex_completed} / ${h.unexpected_completed}`} />
          <KV k="Việc tự khai được xác nhận" v={`${h.accepted_self_reports} (${h.accepted_self_report_hours} giờ)`} />
          <KV k="Tăng ca đã xác nhận" v={`${h.confirmed_overtime_hours} giờ`} />
          <KV k="Nghỉ phép đã duyệt" v={`${h.approved_leave_hours} giờ (đột xuất: ${h.sudden_leaves})`} />
          {h.finalized_scores.length > 0 && <KV k="Điểm hiệu suất đã chốt" v={h.finalized_scores.map((s: any) => `${s.period}: ${s.E}`).join(' · ')} />}
        </Card>
      ))}
    </>
  );
}

export default function PersonProfile() {
  const { userId } = useParams();
  const { data: d, error, loading } = useLoad(() => get(`/profiles/${userId}`), [userId]);
  if (loading && !d) return <Loading />;
  if (!d) return <div className="page"><ErrorBox error={error} /></div>;
  const p = d.profile;
  return (
    <>
      <Header title="Hồ sơ nhân sự" back />
      <div className="page">
        <Card>
          <div style={{ display: 'flex', gap: 14, alignItems: 'center' }}>
            <Avatar userId={d.user.id} name={d.user.name} has={d.user.has_avatar} size="lg" />
            <div><h2>{d.user.name}</h2><div className="small muted">{d.user.phone}{d.user.email ? ` · ${d.user.email}` : ''}</div>{p.desired_position && <div className="small">Mong muốn: {p.desired_position}</div>}</div>
          </div>
        </Card>
        <div className="section-title">Thông tin cá nhân</div>
        <Card>
          <KV k="Ngày sinh" v={fmtD(p.dob)} /><KV k="Giới tính" v={p.gender} /><KV k="Địa chỉ" v={p.address} />
          <KV k="Email liên hệ" v={p.contact_email} />{p.id_number !== undefined && <KV k="CCCD" v={p.id_number} />}<KV k="Học vấn" v={p.education} />
          {p.summary && <div className="crit small" style={{ marginTop: 6 }}>{p.summary}</div>}
        </Card>
        <div className="section-title">Kinh nghiệm</div>
        <Card><KV k="Số năm" v={p.years_experience} /><KV k="Lĩnh vực" v={p.field} /><KV k="Kỹ năng" v={p.skills} /><KV k="Chứng chỉ" v={p.certificates} /></Card>
        <div className="section-title">Lịch sử làm việc (tự khai)</div>
        {d.work_history.length === 0 && <div className="empty">Chưa khai</div>}
        {d.work_history.map((h: any) => <Card key={h.id}><b>{h.position || '—'}</b> · {h.company_name}<div className="small muted">{h.start_date?.slice(0, 7) || '?'} → {h.end_date?.slice(0, 7) || 'nay'}</div>{h.description && <div className="small">{h.description}</div>}</Card>)}
        <div className="section-title">Quá trình làm việc do Việc Đến ghi nhận</div>
        {d.other_companies_hidden && <p className="small muted">Người này chưa đồng ý chia sẻ lịch sử ở doanh nghiệp khác; chỉ hiện dữ liệu tại doanh nghiệp của bạn.</p>}
        <AutoHistory items={d.auto_history} />
      </div>
    </>
  );
}
