import { useState } from 'react';
import { Link } from 'react-router-dom';
import { get, post, qs } from '../api';
import { isAdminRole, useAuth } from '../auth';
import { Badge, Card, Empty, ErrorBox, Header, Loading, Tabs, useAction, useLoad } from '../ui';
import { ESC_STAGE, fmtDT } from '../labels';

export default function Escalations() {
  const { me } = useAuth();
  const [status, setStatus] = useState('open');
  const [scope, setScope] = useState('mine');
  const { data, error, loading, reload } = useLoad(() => get('/escalations' + qs({ status, scope })), [status, scope]);
  const a = useAction();
  return (
    <>
      <Header title="Chuyển cấp" back />
      <div className="page">
        <Tabs value={status} onChange={setStatus} tabs={[['open', 'Đang mở'], ['resolved', 'Đã xử lý'], ['all', 'Tất cả']]} />
        {isAdminRole(me?.role) && <Tabs value={scope} onChange={setScope} tabs={[['mine', 'Đến tôi'], ['all', 'Toàn công ty']]} />}
        <ErrorBox error={error || a.error} />
        {loading && !data && <Loading />}
        {data && data.length === 0 && <Empty>Không có chuyển cấp</Empty>}
        {data?.map((e: any) => (
          <Card key={e.id}>
            <div className="row"><Badge tone={e.status === 'open' ? 'red' : 'gray'}>{e.status === 'open' ? 'Đang mở' : 'Đã xử lý'}</Badge><Badge tone="purple">Cấp {e.level} · {ESC_STAGE[e.stage] || e.stage}</Badge>{e.auto && <Badge>Tự động</Badge>}</div>
            <div style={{ marginTop: 6 }}>
              <Link to={e.parent_type === 'workplace_report' ? `/reports/${e.parent_id}` : `/work-records/${e.parent_id}`}>
                <b>{e.report_code ? `${e.report_code}: ` : 'Bản ghi công việc: '}</b>{(e.subject || '').slice(0, 90)}
              </Link>
            </div>
            <div className="small muted">{e.from_name || '—'} → {e.to_name} · {fmtDT(e.created_at)}{e.new_due_at ? ` · SLA mới ${fmtDT(e.new_due_at)}` : ''}</div>
            <div className="small">{e.reason}</div>
            {e.resolution && <div className="small">✓ {e.resolution}</div>}
            {e.status === 'open' && (
              <button className="btn sm" style={{ marginTop: 6 }} disabled={a.busy} onClick={() => { const r = prompt('Ghi nhận cách xử lý chuyển cấp:'); if (r) a.run(async () => { await post(`/escalations/${e.id}/resolve`, { resolution: r }); reload(); }); }}>Ghi nhận đã xử lý</button>
            )}
          </Card>
        ))}
      </div>
    </>
  );
}
