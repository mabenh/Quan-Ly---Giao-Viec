import { useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { get, post } from '../api';
import { useAuth } from '../auth';
import { Badge, Card, ErrorBox, Field, Header, KV, Loading, Select, Sheet, Timeline, useAction, useLoad } from '../ui';
import { ESC_STAGE, RP_CAT, RP_STATUS, RP_TONE, SEVERITY, SEV_TONE, STAGE, fmtDT, relDue, fromLocalInput, toLocalInput } from '../labels';
import { Files } from './TaskDetail';

export default function ReportDetail() {
  const { id } = useParams();
  const { me } = useAuth();
  const { data: w, error, loading, reload, setData } = useLoad(() => get(`/workplace-reports/${id}`), [id]);
  const [sheet, setSheet] = useState<string | null>(null);
  const a = useAction();
  const act = (fn: () => Promise<any>) => a.run(async () => { setData(await fn()); setSheet(null); });
  if (loading && !w) return <Loading />;
  if (!w) return <div className="page"><ErrorBox error={error} /></div>;
  const p = w.permissions;
  const timeline = [
    ...w.updates.map((u: any) => ({ at: u.created_at, title: `${RP_STATUS[u.status] || u.status} · ${u.actor_name || 'Hệ thống'}`, body: [u.comment, u.new_due_at && `Hạn mới: ${fmtDT(u.new_due_at)}`].filter(Boolean).join('\n'), tone: u.status === 'escalated' || u.status === 'reopened' ? 'red' : u.status === 'closed' ? 'green' : '' })),
    ...w.escalations.map((e: any) => ({ at: e.created_at, tone: 'purple', title: `Chuyển cấp ${e.level} (${ESC_STAGE[e.stage] || e.stage}): ${e.from_name || '—'} → ${e.to_name}`, body: `${e.reason}${e.new_due_at ? `\nSLA mới: ${fmtDT(e.new_due_at)}` : ''}${e.status === 'resolved' ? `\n✓ ${e.resolution}` : ''}` })),
  ].sort((x, y) => new Date(x.at).getTime() - new Date(y.at).getTime());
  return (
    <>
      <Header title={w.code} back="/work?tab=reports" />
      <div className="page">
        <div className="chip-row">
          <Badge tone={SEV_TONE[w.severity]}>Mức độ: {SEVERITY[w.severity]}</Badge>
          <Badge tone={RP_TONE[w.status]}>{RP_STATUS[w.status]}</Badge>
          {w.impact_confirmed && <Badge tone="amber">Đã xác nhận ảnh hưởng</Badge>}
          {w.independent_channel && <Badge tone="purple">Kênh độc lập</Badge>}
        </div>
        {w.safety_notice && <div className="alert error">⚠ {w.safety_notice}</div>}
        <Card>
          <KV k="Bước hiện tại" v={STAGE[w.stage]} />
          <KV k="Đang giữ việc" v={w.holder_name} />
          {w.stage_due_at && w.stage !== 'closed' && <KV k="Hạn SLA" v={<span>{fmtDT(w.stage_due_at)} {w.is_overdue ? <Badge tone="red">Quá hạn {relDue(w.stage_due_at)}</Badge> : <span className="muted">({relDue(w.stage_due_at)})</span>}</span>} />}
          <KV k="Danh mục" v={`${RP_CAT[w.category]}${w.subcategory ? ' / ' + w.subcategory : ''}`} />
          <KV k="Người báo cáo" v={w.reporter_name} />
          <KV k="Quản lý tiếp nhận" v={w.manager_name} />
          <KV k="Bộ phận / người xử lý" v={[w.department_name, w.assignee_name].filter(Boolean).join(' / ') || '—'} />
          <KV k="Phát hiện lúc" v={fmtDT(w.detected_at)} />
          {w.affected_task_id && <KV k="Nhiệm vụ bị ảnh hưởng" v={<Link to={`/tasks/${w.affected_task_id}`}>{w.affected_task_title}</Link>} />}
          {w.asset && <KV k="Tài sản" v={w.asset} />}
          {w.location && <KV k="Vị trí" v={w.location} />}
          {w.temp_measure && <KV k="Biện pháp tạm thời" v={w.temp_measure} />}
          {w.reopen_count > 0 && <KV k="Số lần mở lại" v={w.reopen_count} />}
        </Card>
        <Card><div className="crit">{w.description}</div></Card>
        <ErrorBox error={a.error} />
        <div className="actions">
          {p.canManagerAct && w.status === 'submitted' && <button className="btn" disabled={a.busy} onClick={() => act(() => post(`/workplace-reports/${id}/review`, {}))}>Tiếp nhận xem xét</button>}
          {(p.canManagerAct || (p.canReassign && w.stage !== 'reporter_confirm')) && <button className="btn primary" onClick={() => setSheet('assign')}>{w.department_id ? 'Chuyển lại bộ phận' : 'Chuyển bộ phận xử lý'}</button>}
          {p.canAck && <button className="btn primary" onClick={() => setSheet('ack')}>Xác nhận tiếp nhận</button>}
          {p.canUpdate && <button className="btn primary" onClick={() => setSheet('update')}>Cập nhật xử lý</button>}
          {p.canConfirm && <button className="btn success" disabled={a.busy} onClick={() => act(() => post(`/workplace-reports/${id}/confirm`, { decision: 'close' }))}>✔ Đã khắc phục — đóng</button>}
          {['reporter_confirm', 'closed'].includes(w.stage) && w.reporter_id === me?.member_id && <button className="btn danger" onClick={() => setSheet('reopen')}>Mở lại</button>}
          {p.canEscalate && <button className="btn" onClick={() => setSheet('escalate')}>Chuyển cấp</button>}
          {w.stage !== 'closed' && <Link className="btn" to={`/overtime/new?reportId=${w.id}`}>⏱ Ghi tăng ca do sự cố</Link>}
        </div>
        <Files parentType="workplace_report" parentId={w.id} files={w.files} onDone={reload} />
        <Comment id={w.id} onDone={setData} />
        <div className="section-title">Lịch sử xử lý & chuyển cấp</div>
        <Timeline items={timeline} />
      </div>

      <Sheet open={sheet === 'assign'} onClose={() => setSheet(null)} title="Chuyển bộ phận xử lý"><AssignForm w={w} busy={a.busy} error={a.error} onSubmit={(b) => act(() => post(`/workplace-reports/${id}/assign`, b))} /></Sheet>
      <Sheet open={sheet === 'ack'} onClose={() => setSheet(null)} title="Xác nhận tiếp nhận"><AckForm w={w} busy={a.busy} error={a.error} onSubmit={(b) => act(() => post(`/workplace-reports/${id}/acknowledge`, b))} /></Sheet>
      <Sheet open={sheet === 'update'} onClose={() => setSheet(null)} title="Cập nhật xử lý"><UpdateForm busy={a.busy} error={a.error} onSubmit={(b) => act(() => post(`/workplace-reports/${id}/updates`, b))} /></Sheet>
      <Sheet open={sheet === 'reopen'} onClose={() => setSheet(null)} title="Mở lại báo cáo"><ReasonForm label="Vấn đề chưa được giải quyết như thế nào?" cta="Mở lại" busy={a.busy} error={a.error} onSubmit={(c) => act(() => post(`/workplace-reports/${id}/confirm`, { decision: 'reopen', comment: c }))} /></Sheet>
      <Sheet open={sheet === 'escalate'} onClose={() => setSheet(null)} title="Chuyển cấp thủ công"><ReasonForm label="Lý do chuyển cấp" cta="Chuyển cấp" busy={a.busy} error={a.error} onSubmit={(c) => act(() => post(`/workplace-reports/${id}/escalate`, { reason: c }))} /></Sheet>
    </>
  );
}

type FP = { busy: boolean; error: string | null; onSubmit: (b: any) => void };

function AssignForm({ w, busy, error, onSubmit }: FP & { w: any }) {
  const depts = useLoad(() => get('/company/departments'), []);
  const members = useLoad(() => get('/company/members'), []);
  const [d, setD] = useState(w.department_id || ''); const [sev, setSev] = useState(w.severity); const [imp, setImp] = useState(true);
  const [assignee, setAssignee] = useState(''); const [c, setC] = useState('');
  const inDept = (members.data || []).filter((m: any) => m.department_id === d);
  return (
    <>
      <Field label="Xác nhận mức độ ảnh hưởng"><Select value={sev} onChange={setSev} options={SEVERITY} /></Field>
      <label className="check"><input type="checkbox" checked={imp} onChange={(e) => setImp(e.target.checked)} /> Xác nhận trở ngại ảnh hưởng công việc (nhiệm vụ liên quan được gắn cờ)</label>
      <Field label="Bộ phận chịu trách nhiệm" required><Select value={d} onChange={setD} options={(depts.data || []).map((x: any) => [x.id, `${x.name}${x.head_name ? ' — ' + x.head_name : ''}`])} placeholder="— Chọn bộ phận —" /></Field>
      {inDept.length > 0 && <Field label="Người xử lý (tùy chọn)"><Select value={assignee} onChange={setAssignee} options={inDept.map((m: any) => [m.id, m.name])} placeholder="— Để bộ phận phân công —" /></Field>}
      <Field label="Ghi chú"><textarea value={c} onChange={(e) => setC(e.target.value)} /></Field>
      <ErrorBox error={error} />
      <button className="btn primary block" disabled={busy || !d} onClick={() => onSubmit({ departmentId: d, severity: sev, impactConfirmed: imp, assigneeId: assignee || undefined, comment: c || undefined })}>Chuyển</button>
    </>
  );
}

function AckForm({ w, busy, error, onSubmit }: FP & { w: any }) {
  const members = useLoad(() => get('/company/members'), []);
  const [assignee, setAssignee] = useState(w.assignee_id || ''); const [eta, setEta] = useState(''); const [c, setC] = useState('');
  const inDept = (members.data || []).filter((m: any) => m.department_id === w.department_id);
  return (
    <>
      <Field label="Người phụ trách"><Select value={assignee} onChange={setAssignee} options={inDept.map((m: any) => [m.id, m.name])} placeholder="— Tôi phụ trách —" /></Field>
      <Field label="Thời hạn dự kiến" hint="Không vượt quá SLA xử lý theo mức độ"><input type="datetime-local" value={eta} min={toLocalInput(new Date())} onChange={(e) => setEta(e.target.value)} /></Field>
      <Field label="Ghi chú"><textarea value={c} onChange={(e) => setC(e.target.value)} /></Field>
      <ErrorBox error={error} />
      <button className="btn primary block" disabled={busy} onClick={() => onSubmit({ assigneeId: assignee || undefined, eta: fromLocalInput(eta), comment: c || undefined })}>Xác nhận tiếp nhận</button>
    </>
  );
}

function UpdateForm({ busy, error, onSubmit }: FP) {
  const [s, setS] = useState('in_progress'); const [c, setC] = useState(''); const [due, setDue] = useState(''); const [tm, setTm] = useState('');
  return (
    <>
      <Field label="Cập nhật"><Select value={s} onChange={setS} options={{ in_progress: 'Đang xử lý', waiting: 'Chờ thông tin/vật tư', resolved_pending: 'Đã xử lý — chờ người báo cáo xác nhận', cannot_fix: 'Không khắc phục được — chuyển cấp chuyên môn' }} /></Field>
      <Field label={s === 'resolved_pending' ? 'Kết quả/phương án đã thực hiện' : s === 'waiting' ? 'Lý do chờ' : s === 'cannot_fix' ? 'Lý do không khắc phục được' : 'Tiến độ/phương án'} required={s !== 'in_progress'}><textarea value={c} onChange={(e) => setC(e.target.value)} /></Field>
      {s === 'waiting' && <Field label="Thời hạn mới" required><input type="datetime-local" value={due} onChange={(e) => setDue(e.target.value)} /></Field>}
      {s === 'cannot_fix' && <Field label="Phương án tạm thời" required><input value={tm} onChange={(e) => setTm(e.target.value)} /></Field>}
      <p className="small muted">Đính kèm ảnh/biên bản bằng chứng ở mục Tệp đính kèm.</p>
      <ErrorBox error={error} />
      <button className="btn primary block" disabled={busy} onClick={() => onSubmit({ status: s, comment: c || undefined, newDueAt: fromLocalInput(due), tempMeasure: tm || undefined })}>Cập nhật</button>
    </>
  );
}

function ReasonForm({ label, cta, busy, error, onSubmit }: { label: string; cta: string; busy: boolean; error: string | null; onSubmit: (c: string) => void }) {
  const [c, setC] = useState('');
  return (<><Field label={label} required><textarea value={c} onChange={(e) => setC(e.target.value)} /></Field><ErrorBox error={error} /><button className="btn danger block" disabled={busy} onClick={() => onSubmit(c)}>{cta}</button></>);
}

function Comment({ id, onDone }: { id: string; onDone: (x: any) => void }) {
  const [c, setC] = useState(''); const a = useAction();
  return (
    <div style={{ display: 'flex', gap: 6, marginTop: 10 }}>
      <input placeholder="Bình luận / trao đổi…" value={c} onChange={(e) => setC(e.target.value)} />
      <button className="btn" disabled={a.busy || !c.trim()} onClick={() => a.run(async () => { onDone(await post(`/workplace-reports/${id}/updates`, { status: 'comment', comment: c })); setC(''); })}>Gửi</button>
    </div>
  );
}
