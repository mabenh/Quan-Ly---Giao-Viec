import { useState } from 'react';
import { useParams } from 'react-router-dom';
import { get, post } from '../api';
import { Badge, Card, ErrorBox, Field, Header, KV, Loading, Select, Sheet, Timeline, useAction, useLoad } from '../ui';
import { EARLY_REASON, ESC_STAGE, FINAL, WR_DECISION, WR_RESPONSE, WR_STATUS, WR_TONE, WR_TYPE, fmtDT, hours } from '../labels';
import { Files } from './TaskDetail';

export default function WorkRecordDetail() {
  const { id } = useParams();
  const { data: r, error, loading, reload, setData } = useLoad(() => get(`/work-records/${id}`), [id]);
  const [sheet, setSheet] = useState<string | null>(null);
  const a = useAction();
  const act = (fn: () => Promise<any>) => a.run(async () => { setData(await fn()); setSheet(null); });
  if (loading && !r) return <Loading />;
  if (!r) return <div className="page"><ErrorBox error={error} /></div>;
  const p = r.permissions;
  const lr = r.last_review;
  const items = r.timeline.map((x: any) => {
    if (x.type === 'review') return { at: x.at, tone: x.decision === 'accept' ? 'green' : x.decision === 'needs_info' ? 'amber' : 'red',
      title: `${x.reviewer_name}: ${WR_DECISION[x.decision]}${x.rejection_no ? ` (lần từ chối thứ ${x.rejection_no})` : ''}`,
      body: [x.reason, x.basis && `Căn cứ: ${x.basis}`, x.accepted_minutes !== null && x.decision === 'partial' && `Chấp nhận ${hours(x.accepted_minutes)}`,
        x.accepted_scope && `Phần chấp nhận: ${x.accepted_scope}`, x.rejected_scope && `Phần từ chối: ${x.rejected_scope}`].filter(Boolean).join('\n') };
    if (x.type === 'response') return { at: x.at, tone: x.response === 'dispute' ? 'red' : 'green', title: `${x.employee_name}: ${WR_RESPONSE[x.response]}`, body: x.comment };
    if (x.type === 'appeal') return { at: x.at, tone: 'purple', title: `Khiếu nại${x.early ? ' sớm' : ''} → ${x.reviewer_name} giải quyết (người bị khiếu nại: ${x.respondent_name || '—'})`,
      body: [x.reason, x.early_reason && `Căn cứ khiếu nại sớm: ${x.early_reason}`, x.status === 'resolved' && `Quyết định: ${WR_DECISION[x.decision]} — ${x.decision_reason}`].filter(Boolean).join('\n') };
    return { at: x.at, tone: 'red', title: `Chuyển cấp ${x.level}: ${x.from_name || '—'} → ${x.to_name} (${ESC_STAGE[x.stage] || x.stage})`, body: `${x.reason}${x.status === 'resolved' ? ` · Đã xử lý: ${x.resolution}` : ''}` };
  });
  return (
    <>
      <Header title="Bản ghi công việc" back="/work?tab=records" />
      <div className="page">
        <h2>{r.title}</h2>
        <div className="chip-row">
          <Badge tone={WR_TONE[r.status]}>{WR_STATUS[r.status]}</Badge>
          {r.final_decision && <Badge tone="gray">Kết quả: {FINAL[r.final_decision]}</Badge>}
          {r.overdue && <Badge tone="red">Quá hạn phản hồi</Badge>}
          {r.escalation_level > 0 && <Badge tone="red">Đã chuyển cấp {r.escalation_level}</Badge>}
          <Badge tone={r.consecutive_rejections >= r.appeal_threshold ? 'red' : 'amber'}>Từ chối liên tiếp: {r.consecutive_rejections}/{r.appeal_threshold}</Badge>
        </div>
        {(r.status === 'submitted' || r.status === 'disputed') && <div className="alert info">Đang chờ <b>{r.reviewer_name}</b> phản hồi trước <b>{fmtDT(r.review_due_at)}</b>. Quá hạn sẽ tự động chuyển cấp; im lặng không được coi là đồng ý hay từ chối.</div>}
        {r.overlap_warning && <div className="alert warn">⚠ Thời gian khai báo trùng với bản ghi khác: {r.overlaps.map((o: any) => `"${o.title}" (${fmtDT(o.start_at)}–${fmtDT(o.end_at)})`).join('; ')}</div>}
        <ErrorBox error={a.error} />
        <div className="actions">
          {p.can_review && <button className="btn primary" onClick={() => setSheet('review')}>Phản hồi bản ghi</button>}
          {p.can_respond && r.status === 'needs_information' && <button className="btn primary" onClick={() => setSheet('supplement')}>Bổ sung thông tin</button>}
          {p.can_respond && r.status !== 'needs_information' && <button className="btn primary" onClick={() => setSheet('respond')}>Phản hồi quyết định</button>}
          {p.can_appeal && <button className="btn danger" onClick={() => setSheet('appeal')}>{p.can_appeal_by_count ? 'Chuyển khiếu nại lên cấp trên' : 'Khiếu nại sớm (xung đột lợi ích)'}</button>}
          {p.can_resolve_appeal && <button className="btn primary" onClick={() => setSheet('resolve')}>Giải quyết khiếu nại</button>}
        </div>
        <Card>
          <KV k="Nhân viên" v={r.employee_name} />
          <KV k="Loại ghi nhận" v={WR_TYPE[r.record_type]} />
          <KV k="Người giao/yêu cầu" v={r.requester_name || `Không rõ — ${r.requester_unknown_note}`} />
          <KV k="Thời gian" v={`${fmtDT(r.start_at)} → ${fmtDT(r.end_at)}${r.is_estimated ? ' (ước tính)' : ''}`} />
          <KV k="Thời lượng khai báo" v={hours(r.claimed_minutes)} />
          {r.accepted_minutes !== null && <KV k="Thời lượng được chấp nhận" v={hours(r.accepted_minutes)} />}
          <KV k="Nhóm" v={r.group_name} />
          <KV k="Người xác nhận" v={r.reviewer_name} />
        </Card>
        <Card>
          <b className="small">Kết quả đã thực hiện</b><div className="crit">{r.result}</div>
          <div className="divider" />
          <b className="small">Lý do chưa có trên hệ thống</b><div className="crit">{r.reason_not_in_system}</div>
          {r.description && <><div className="divider" /><div className="crit">{r.description}</div></>}
        </Card>
        <Files parentType="work_record" parentId={r.id} files={r.files} onDone={reload} />
        <div className="section-title">Chuỗi quyết định & phản hồi (không thể xóa)</div>
        <Timeline items={[{ at: r.created_at, title: `${r.employee_name} gửi bản ghi`, tone: '' }, ...items]} />
      </div>

      <Sheet open={sheet === 'review'} onClose={() => setSheet(null)} title="Phản hồi bản ghi công việc">
        <ReviewForm r={r} busy={a.busy} error={a.error} onSubmit={(b) => act(() => post(`/work-records/${id}/reviews`, b))} />
      </Sheet>
      <Sheet open={sheet === 'respond'} onClose={() => setSheet(null)} title="Phản hồi quyết định">
        <RespondForm lr={lr} r={r} busy={a.busy} error={a.error} onSubmit={(b) => act(() => post(`/work-records/${id}/disputes`, b))} />
      </Sheet>
      <Sheet open={sheet === 'supplement'} onClose={() => setSheet(null)} title="Bổ sung thông tin">
        <Supplement lr={lr} busy={a.busy} error={a.error} onSubmit={(b) => act(() => post(`/work-records/${id}/disputes`, b))} />
      </Sheet>
      <Sheet open={sheet === 'appeal'} onClose={() => setSheet(null)} title="Khiếu nại lên cấp cao hơn">
        <AppealForm byCount={p.can_appeal_by_count} busy={a.busy} error={a.error} onSubmit={(b) => act(() => post(`/work-records/${id}/appeals`, b))} />
      </Sheet>
      <Sheet open={sheet === 'resolve'} onClose={() => setSheet(null)} title="Quyết định giải quyết khiếu nại">
        <ResolveForm r={r} busy={a.busy} error={a.error} onSubmit={(b) => act(() => post(`/work-records/${id}/appeals/${p.open_appeal_id}/resolve`, b))} />
      </Sheet>
    </>
  );
}

type FP = { busy: boolean; error: string | null; onSubmit: (b: any) => void };

function ReviewForm({ r, busy, error, onSubmit }: FP & { r: any }) {
  const [d, setD] = useState('accept');
  const [reason, setReason] = useState(''); const [basis, setBasis] = useState(''); const [period, setPeriod] = useState('');
  const [acc, setAcc] = useState(Math.round(r.claimed_minutes / 2)); const [accS, setAccS] = useState(''); const [rejS, setRejS] = useState('');
  return (
    <>
      <p className="small muted">Bạn bắt buộc phải phản hồi: xác nhận, xác nhận một phần, từ chối (kèm lý do & căn cứ) hoặc yêu cầu bổ sung. Không thể bỏ qua hoặc xóa bản ghi.</p>
      <Field label="Quyết định"><Select value={d} onChange={setD} options={WR_DECISION} /></Field>
      {d !== 'accept' && <Field label={d === 'needs_info' ? 'Thông tin còn thiếu' : 'Lý do cụ thể'} required><textarea value={reason} onChange={(e) => setReason(e.target.value)} /></Field>}
      {(d === 'reject' || d === 'partial') && (
        <>
          <Field label="Căn cứ / dữ liệu xác minh" required={d === 'reject'} hint="Ví dụ: nhật ký cổng, lịch ca, quy định nghỉ trưa 30 phút — không tự động khấu trừ"><input value={basis} onChange={(e) => setBasis(e.target.value)} /></Field>
          <Field label="Thời gian liên quan"><input value={period} onChange={(e) => setPeriod(e.target.value)} placeholder="VD: 12:00–13:00 ngày 05/11" /></Field>
        </>
      )}
      {d === 'partial' && (
        <>
          <Field label={`Thời lượng chấp nhận: ${hours(acc)} / ${hours(r.claimed_minutes)}`}><input type="range" min={15} max={r.claimed_minutes - 15} step={15} value={acc} onChange={(e) => setAcc(+e.target.value)} /></Field>
          <Field label="Phần được chấp nhận" required><input value={accS} onChange={(e) => setAccS(e.target.value)} /></Field>
          <Field label="Phần bị từ chối" required><input value={rejS} onChange={(e) => setRejS(e.target.value)} /></Field>
        </>
      )}
      <ErrorBox error={error} />
      <button className={`btn block ${d === 'reject' ? 'danger' : 'primary'}`} disabled={busy}
        onClick={() => onSubmit({ decision: d, reason: reason || undefined, basis: basis || undefined, relatedPeriod: period || undefined, ...(d === 'partial' ? { acceptedMinutes: acc, acceptedScope: accS, rejectedScope: rejS } : {}) })}>
        Gửi phản hồi
      </button>
    </>
  );
}

function RespondForm({ lr, r, busy, error, onSubmit }: FP & { lr: any; r: any }) {
  const [c, setC] = useState('');
  const next = r.consecutive_rejections + 1;
  return (
    <>
      {lr && <Card><b>{WR_DECISION[lr.decision]}</b><div className="crit">{lr.reason}</div>{lr.basis && <div className="small muted">Căn cứ: {lr.basis}</div>}</Card>}
      <p className="small">Bạn có quyền chấp nhận hoặc không chấp nhận lý do. Nếu không chấp nhận, hãy bổ sung ý kiến và bằng chứng (tải tệp ở mục Tệp đính kèm).</p>
      <p className="small muted">Đây là lần từ chối thứ {next} liên tiếp. Từ lần thứ {r.appeal_threshold}, bạn có quyền chuyển khiếu nại lên cấp cao hơn.</p>
      <Field label="Ý kiến của bạn"><textarea value={c} onChange={(e) => setC(e.target.value)} /></Field>
      <ErrorBox error={error} />
      <div className="actions">
        <button className="btn success" disabled={busy} onClick={() => onSubmit({ response: 'accept', comment: c || undefined })}>Chấp nhận kết quả</button>
        <button className="btn danger" disabled={busy} onClick={() => onSubmit({ response: 'dispute', comment: c })}>Không chấp nhận lý do</button>
      </div>
    </>
  );
}

function Supplement({ lr, busy, error, onSubmit }: FP & { lr: any }) {
  const [c, setC] = useState('');
  return (
    <>
      {lr && <div className="alert warn">Quản lý yêu cầu: {lr.reason}</div>}
      <Field label="Nội dung bổ sung" required><textarea value={c} onChange={(e) => setC(e.target.value)} /></Field>
      <ErrorBox error={error} />
      <button className="btn primary block" disabled={busy} onClick={() => onSubmit({ response: 'supplement', comment: c })}>Gửi bổ sung</button>
    </>
  );
}

function AppealForm({ byCount, busy, error, onSubmit }: FP & { byCount: boolean }) {
  const [reason, setReason] = useState(''); const [er, setEr] = useState('conflict_of_interest'); const [ed, setEd] = useState('');
  return (
    <>
      <p className="small muted">Khiếu nại được chuyển đến cấp cao hơn người bị khiếu nại. Người bị khiếu nại không có quyền ra quyết định cuối cùng.</p>
      {!byCount && <div className="alert warn">Chưa đủ số lần từ chối liên tiếp. Chỉ khiếu nại sớm khi có xung đột lợi ích, dấu hiệu gây sức ép hoặc người bị khiếu nại là người có quyền xử lý trực tiếp.</div>}
      <Field label="Nội dung khiếu nại" required><textarea value={reason} onChange={(e) => setReason(e.target.value)} /></Field>
      {!byCount && (
        <>
          <Field label="Căn cứ khiếu nại sớm" required><Select value={er} onChange={setEr} options={EARLY_REASON} /></Field>
          <Field label="Mô tả căn cứ" required><textarea value={ed} onChange={(e) => setEd(e.target.value)} /></Field>
        </>
      )}
      <ErrorBox error={error} />
      <button className="btn danger block" disabled={busy} onClick={() => onSubmit(byCount ? { reason } : { reason, early: true, earlyReason: er, earlyDetail: ed })}>Gửi khiếu nại</button>
    </>
  );
}

function ResolveForm({ r, busy, error, onSubmit }: FP & { r: any }) {
  const [d, setD] = useState('accept'); const [reason, setReason] = useState(''); const [acc, setAcc] = useState(Math.round(r.claimed_minutes / 2));
  return (
    <>
      <p className="small muted">Xem đầy đủ chuỗi quyết định, phản hồi và bằng chứng trước khi ra quyết định cuối cùng.</p>
      <Field label="Quyết định"><Select value={d} onChange={setD} options={{ accept: 'Chấp nhận toàn bộ', partial: 'Chấp nhận một phần', reject: 'Giữ nguyên từ chối' }} /></Field>
      {d === 'partial' && <Field label={`Thời lượng chấp nhận: ${hours(acc)}`}><input type="range" min={15} max={r.claimed_minutes - 15} step={15} value={acc} onChange={(e) => setAcc(+e.target.value)} /></Field>}
      <Field label="Lý do quyết định" required><textarea value={reason} onChange={(e) => setReason(e.target.value)} /></Field>
      <ErrorBox error={error} />
      <button className="btn primary block" disabled={busy} onClick={() => onSubmit({ decision: d, reason, ...(d === 'partial' ? { acceptedMinutes: acc } : {}) })}>Ra quyết định cuối cùng</button>
    </>
  );
}
