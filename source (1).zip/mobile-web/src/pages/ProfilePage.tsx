import { useEffect, useState } from 'react';
import { del, get, patch, post, put } from '../api';
import { useAuth } from '../auth';
import { Avatar, Card, ErrorBox, Field, Header, Loading, Select, Sheet, clearAvatarCache, useAction, useLoad } from '../ui';
import FaceCapture from '../FaceCapture';
import { AutoHistory } from './PersonProfile';

const F: [string, string, string?][] = [
  ['dob', 'Ngày sinh', 'date'], ['gender', 'Giới tính'], ['address', 'Địa chỉ'], ['contact_email', 'Email liên hệ'], ['id_number', 'Số CCCD (chỉ nhân sự xem)'],
  ['education', 'Trình độ học vấn'], ['desired_position', 'Vị trí mong muốn'],
];

export default function ProfilePage() {
  const { me, reload } = useAuth();
  const { data, loading, setData } = useLoad(() => get('/profile/me'), []);
  const [f, setF] = useState<any>(null);
  const [cam, setCam] = useState(false);
  const [hist, setHist] = useState<any>(null);
  const [ok, setOk] = useState(false);
  const a = useAction();
  useEffect(() => { if (data) setF({ name: data.user.name, ...data.profile, dob: data.profile.dob?.slice(0, 10) || '' }); }, [data]);
  if (loading || !data || !f) return <Loading />;
  const up = (p: any) => setF({ ...f, ...p });
  const save = () => a.run(async () => {
    const body: any = { name: f.name };
    for (const k of ['dob', 'gender', 'address', 'contact_email', 'id_number', 'education', 'desired_position', 'summary', 'years_experience', 'field', 'skills', 'certificates', 'share_auto_history']) body[k] = f[k] === undefined ? null : f[k];
    if (body.years_experience === '' || body.years_experience === null) body.years_experience = null; else body.years_experience = Number(body.years_experience);
    setData(await put('/profile/me', body)); await reload(); setOk(true); setTimeout(() => setOk(false), 2500);
  });
  const saveAvatar = (r: any) => a.run(async () => { await put('/profile/me/avatar', r); clearAvatarCache(me?.user_id); setCam(false); await reload(); setData(await get('/profile/me')); });
  return (
    <>
      <Header title="Hồ sơ của tôi" back />
      <div className="page">
        <Card>
          <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
            <Avatar userId={me?.user_id} name={data.user.name} has={data.user.has_avatar} size="lg" />
            <div style={{ flex: 1 }}>
              <b>{data.user.name}</b><div className="small muted">{data.user.phone}</div>
              {data.avatar && <div className="small muted">{data.avatar.captured_live ? 'Ảnh quét trực tiếp từ camera' : 'Ảnh tải lên'}{data.avatar.face_detected ? ' · đã nhận diện gương mặt' : ''}</div>}
              <button className="btn sm" style={{ marginTop: 6 }} onClick={() => setCam(true)}>{data.user.has_avatar ? 'Quét lại gương mặt' : '📸 Quét gương mặt làm ảnh đại diện'}</button>
            </div>
          </div>
        </Card>

        <div className="section-title">Thông tin cá nhân</div>
        <Field label="Họ và tên đầy đủ" required><input value={f.name || ''} onChange={(e) => up({ name: e.target.value })} /></Field>
        {F.map(([k, l, t]) => k === 'gender'
          ? <Field key={k} label={l}><Select value={f.gender || ''} onChange={(v) => up({ gender: v })} options={{ 'Nam': 'Nam', 'Nữ': 'Nữ', 'Khác': 'Khác' }} placeholder="—" /></Field>
          : <Field key={k} label={l}><input type={t || 'text'} value={f[k] || ''} onChange={(e) => up({ [k]: e.target.value })} /></Field>)}
        <Field label="Giới thiệu bản thân"><textarea value={f.summary || ''} onChange={(e) => up({ summary: e.target.value })} /></Field>

        <div className="section-title">Kinh nghiệm</div>
        <div className="grid2">
          <Field label="Số năm kinh nghiệm"><input type="number" min={0} step={0.5} value={f.years_experience ?? ''} onChange={(e) => up({ years_experience: e.target.value })} /></Field>
          <Field label="Lĩnh vực"><input value={f.field || ''} onChange={(e) => up({ field: e.target.value })} /></Field>
        </div>
        <Field label="Kỹ năng"><textarea value={f.skills || ''} onChange={(e) => up({ skills: e.target.value })} /></Field>
        <Field label="Chứng chỉ"><textarea value={f.certificates || ''} onChange={(e) => up({ certificates: e.target.value })} /></Field>
        <label className="check"><input type="checkbox" checked={!!f.share_auto_history} onChange={(e) => up({ share_auto_history: e.target.checked })} /> Cho phép nhà tuyển dụng (doanh nghiệp mới) xem lịch sử làm việc do app ghi nhận ở doanh nghiệp cũ</label>
        <ErrorBox error={a.error} />{ok && <div className="alert ok">Đã lưu hồ sơ</div>}
        <button className="btn primary block" disabled={a.busy} onClick={save}>Lưu hồ sơ</button>

        <div className="section-title">Lịch sử làm việc (tự khai)</div>
        {data.work_history.map((h: any) => (
          <Card key={h.id} onClick={() => setHist(h)}>
            <b>{h.position || '—'}</b> · {h.company_name}
            <div className="small muted">{h.start_date?.slice(0, 7) || '?'} → {h.end_date?.slice(0, 7) || 'nay'}</div>
            {h.description && <div className="small">{h.description}</div>}
          </Card>
        ))}
        <button className="btn sm" onClick={() => setHist({})}>＋ Thêm nơi làm việc</button>

        <div className="section-title">Quá trình làm việc do Việc Đến tự cập nhật</div>
        <p className="small muted">Phần này app tự ghi nhận trong quá trình bạn làm việc (không sửa được), giúp nhà tuyển dụng rà soát hồ sơ.</p>
        <AutoHistory items={data.auto_history} />
      </div>
      <Sheet open={cam} onClose={() => setCam(false)} title="Quét gương mặt">{cam && <FaceCapture onDone={saveAvatar} onCancel={() => setCam(false)} />}<ErrorBox error={a.error} /></Sheet>
      <Sheet open={!!hist} onClose={() => setHist(null)} title={hist?.id ? 'Sửa nơi làm việc' : 'Thêm nơi làm việc'}>
        {hist && <HistoryForm h={hist} onDone={(d) => { setData(d); setHist(null); }} />}
      </Sheet>
    </>
  );
}

function HistoryForm({ h, onDone }: { h: any; onDone: (d: any) => void }) {
  const [f, setF] = useState({ company_name: h.company_name || '', position: h.position || '', start_date: h.start_date?.slice(0, 7) || '', end_date: h.end_date?.slice(0, 7) || '', description: h.description || '' });
  const a = useAction();
  return (
    <>
      <Field label="Công ty" required><input value={f.company_name} onChange={(e) => setF({ ...f, company_name: e.target.value })} /></Field>
      <Field label="Vị trí"><input value={f.position} onChange={(e) => setF({ ...f, position: e.target.value })} /></Field>
      <div className="grid2">
        <Field label="Từ (tháng)"><input type="month" value={f.start_date} onChange={(e) => setF({ ...f, start_date: e.target.value })} /></Field>
        <Field label="Đến (để trống nếu đang làm)"><input type="month" value={f.end_date} onChange={(e) => setF({ ...f, end_date: e.target.value })} /></Field>
      </div>
      <Field label="Mô tả công việc"><textarea value={f.description} onChange={(e) => setF({ ...f, description: e.target.value })} /></Field>
      <ErrorBox error={a.error} />
      <div className="actions">
        <button className="btn primary" disabled={a.busy} onClick={() => a.run(async () => onDone(h.id ? await patch(`/profile/me/history/${h.id}`, f) : await post('/profile/me/history', f)))}>Lưu</button>
        {h.id && <button className="btn danger" disabled={a.busy} onClick={() => a.run(async () => onDone(await del(`/profile/me/history/${h.id}`)))}>Xóa</button>}
      </div>
    </>
  );
}
