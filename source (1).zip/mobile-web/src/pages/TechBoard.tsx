import { useState } from 'react';
import { get, qs } from '../api';
import { Empty, ErrorBox, Header, Loading, Select, Tabs, useLoad } from '../ui';
import { SEVERITY } from '../labels';
import { ReportCard } from './Work';

export default function TechBoard() {
  const [tab, setTab] = useState('open');
  const [sev, setSev] = useState('');
  const status = tab === 'open' ? 'submitted,manager_review,assigned,acknowledged,in_progress,waiting,reopened,escalated' : tab === 'confirm' ? 'resolved_pending' : 'closed';
  const { data, error, loading } = useLoad(() => get('/workplace-reports' + qs({ scope: 'handling', status, severity: sev })), [tab, sev]);
  const overdue = (data || []).filter((w: any) => w.is_overdue).length;
  return (
    <>
      <Header title="Bảng điều khiển kỹ thuật" back />
      <div className="page">
        <Tabs value={tab} onChange={setTab} tabs={[['open', 'Đang mở'], ['confirm', 'Chờ xác nhận'], ['closed', 'Đã đóng']]} />
        <div className="filters"><Select value={sev} onChange={setSev} options={SEVERITY} placeholder="Mọi mức độ" aria-label="Mức độ" /></div>
        {data && <div className="small muted">{data.length} yêu cầu{overdue ? ` · ${overdue} quá SLA` : ''} · sắp xếp theo mức độ & hạn SLA</div>}
        <ErrorBox error={error} />
        {loading && !data && <Loading />}
        {data && data.length === 0 && <Empty>Không có yêu cầu</Empty>}
        {data?.map((w: any) => <ReportCard key={w.id} w={w} />)}
      </div>
    </>
  );
}
