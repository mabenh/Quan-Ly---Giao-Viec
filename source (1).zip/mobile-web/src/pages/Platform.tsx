import { useState } from 'react';
import { get, post, qs } from '../api';
import { Badge, Card, Empty, ErrorBox, Header, Loading, Tabs, useAction, useLoad } from '../ui';
import { PLAN_NAME, fmtDT, vnd } from '../labels';

export default function Platform() {
  const [status, setStatus] = useState('pending_payment');
  const { data, error, loading, reload } = useLoad(() => get('/platform/subscriptions' + qs({ status })), [status]);
  const a = useAction();
  return (
    <>
      <Header title="Quản trị nền tảng" back />
      <div className="page">
        <Tabs value={status} onChange={setStatus} tabs={[['pending_payment', 'Chờ thanh toán'], ['active', 'Đã kích hoạt'], ['rejected', 'Từ chối']]} />
        <ErrorBox error={error || a.error} />
        {loading && !data && <Loading />}
        {data && data.length === 0 && <Empty>Không có yêu cầu</Empty>}
        {data?.map((s: any) => (
          <Card key={s.id}>
            <div className="row" style={{ display: 'flex', gap: 8 }}><b style={{ flex: 1 }}>{s.company_name}</b><Badge>{PLAN_NAME[s.plan]}</Badge></div>
            <div className="small">{s.user_name} · {s.phone} · {s.contact_email}</div>
            <div className="small muted">{vnd(Number(s.price_vnd))} · {fmtDT(s.created_at)}{s.payment_ref ? ` · Mã GD: ${s.payment_ref}` : ''}</div>
            {s.status === 'pending_payment' && (
              <div className="actions">
                <button className="btn primary sm" disabled={a.busy} onClick={() => { const ref = prompt('Mã giao dịch thanh toán:'); if (ref) a.run(async () => { await post(`/platform/subscriptions/${s.id}/activate`, { paymentRef: ref }); reload(); }); }}>Xác nhận đã thanh toán</button>
                <button className="btn danger sm" disabled={a.busy} onClick={() => confirm('Từ chối yêu cầu này?') && a.run(async () => { await post(`/platform/subscriptions/${s.id}/reject`); reload(); })}>Từ chối</button>
              </div>
            )}
          </Card>
        ))}
      </div>
    </>
  );
}
