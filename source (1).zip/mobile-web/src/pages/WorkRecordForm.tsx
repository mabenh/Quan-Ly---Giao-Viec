import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { get, post, upload } from '../api';
import { ErrorBox, Field, Header, Select, useAction, useLoad } from '../ui';
import { WR_TYPE, fromLocalInput, toLocalInput } from '../labels';

export default function WorkRecordForm() {
  const nav = useNavigate();
  const a = useAction();
  const groups = useLoad(() => get('/groups'), []);
  const members = useLoad(() => get('/company/members'), []);
  const now = new Date(); now.setMinutes(0, 0, 0);
  const [f, setF] = useState<any>({
    title: '', description: '', groupId: '', requesterMemberId: '', unknown: false, requesterUnknownNote: '',
    startAt: toLocalInput(new Date(now.getTime() - 2 * 3600000)), endAt: toLocalInput(now), isEstimated: false,
    recordType: 'assigned_outside', result: '', completionStatus: 'done', reasonNotInSystem: '',
  });
  const [file, setFile] = useState<File | null>(null);
  const up = (p: any) => setF((x: any) => ({ ...x, ...p }));
  const mins = Math.round((new Date(f.endAt).getTime() - new Date(f.startAt).getTime()) / 60000);
  const submit = () => a.run(async () => {
    const r = await post('/work-records', {
      title: f.title, description: f.description || undefined, groupId: f.groupId || undefined,
      requesterMemberId: f.unknown ? undefined : f.requesterMemberId || undefined, requesterUnknownNote: f.unknown ? f.requesterUnknownNote : undefined,
      startAt: fromLocalInput(f.startAt), endAt: fromLocalInput(f.endAt), isEstimated: f.isEstimated, recordType: f.recordType,
      result: f.result, completionStatus: f.completionStatus, reasonNotInSystem: f.reasonNotInSystem,
    });
    if (file) await upload('work_record', r.id, file).catch(() => {});
    nav(`/work-records/${r.id}`, { replace: true });
  });
  return (
    <>
      <Header title="Ghi nhận công việc" back />
      <div className="page">
        <p className="small muted">Ghi nhận việc được giao ngoài app, việc bị ghi thiếu, việc ngoài giờ hoặc hỗ trợ. Quản lý bắt buộc phản hồi; im lặng quá hạn sẽ tự động chuyển cấp.</p>
        <Field label="Tên/nội dung công việc" required><input value={f.title} onChange={(e) => up({ title: e.target.value })} /></Field>
        <Field label="Loại ghi nhận" required><Select value={f.recordType} onChange={(v) => up({ recordType: v })} options={WR_TYPE} /></Field>
        <Field label="Nhóm liên quan" hint="Quản lý nhóm sẽ là người xác nhận; để trống thì gửi cấp trên trực tiếp">
          <Select value={f.groupId} onChange={(v) => up({ groupId: v })} options={(groups.data || []).map((g: any) => [g.id, g.name])} placeholder="— Không chọn —" />
        </Field>
        <Field label="Người giao / người yêu cầu" required>
          {!f.unknown && <Select value={f.requesterMemberId} onChange={(v) => up({ requesterMemberId: v })} options={(members.data || []).map((m: any) => [m.id, `${m.name}${m.title ? ' — ' + m.title : ''}`])} placeholder="— Chọn người —" />}
          <label className="check"><input type="checkbox" checked={f.unknown} onChange={(e) => up({ unknown: e.target.checked })} /> Không rõ người giao</label>
          {f.unknown && <input placeholder="Giải thích vì sao không rõ" value={f.requesterUnknownNote} onChange={(e) => up({ requesterUnknownNote: e.target.value })} />}
        </Field>
        <div className="grid2">
          <Field label="Bắt đầu" required><input type="datetime-local" value={f.startAt} onChange={(e) => up({ startAt: e.target.value })} /></Field>
          <Field label="Kết thúc" required><input type="datetime-local" value={f.endAt} onChange={(e) => up({ endAt: e.target.value })} /></Field>
        </div>
        <div className="small muted">Thời lượng: {mins > 0 ? `${Math.floor(mins / 60)} giờ ${mins % 60} phút` : 'không hợp lệ'}</div>
        <label className="check"><input type="checkbox" checked={f.isEstimated} onChange={(e) => up({ isEstimated: e.target.checked })} /> Thời gian là ước tính (không xác định chính xác)</label>
        <Field label="Kết quả đã thực hiện" required><textarea value={f.result} onChange={(e) => up({ result: e.target.value })} /></Field>
        <Field label="Trạng thái hoàn thành"><Select value={f.completionStatus} onChange={(v) => up({ completionStatus: v })} options={{ done: 'Đã hoàn thành', partial: 'Hoàn thành một phần', in_progress: 'Đang làm' }} /></Field>
        <Field label="Lý do chưa có trên hệ thống" required><textarea value={f.reasonNotInSystem} onChange={(e) => up({ reasonNotInSystem: e.target.value })} /></Field>
        <Field label="Mô tả thêm"><textarea value={f.description} onChange={(e) => up({ description: e.target.value })} /></Field>
        <Field label="Bằng chứng (khuyến nghị)" hint="Ảnh tin nhắn, tài liệu, ảnh hiện trường… Có thể bổ sung thêm sau."><input type="file" accept="image/*,application/pdf,video/*" onChange={(e) => setFile(e.target.files?.[0] || null)} /></Field>
        <ErrorBox error={a.error} />
        <button className="btn primary block" disabled={a.busy} onClick={submit}>{a.busy ? 'Đang gửi…' : 'Gửi bản ghi'}</button>
      </div>
    </>
  );
}
