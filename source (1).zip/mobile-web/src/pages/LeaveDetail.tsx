import { useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { download, get, post } from '../api';
import { Badge, Card, ErrorBox, Field, Header, KV, Loading, useAction, useLoad } from '../ui';
import { LEAVE_STATUS, LEAVE_TONE, fmtDT, hours } from '../labels';

export default function LeaveDetail() {
  const { id } = useParams();
  const { data: l, error, loading, setData } = useLoad(() => get(`/leaves/${id}`), [id]);
  const [reason, setReason] = useState('');
  const a = useAction();
  if (loading && !l) return <Loading />;
  if (!l) return <div className="page"><ErrorBox error={error} /></div>;
  const p = l.permissions;
  return (
    <>
      <Header title={`Đơn nghỉ ${l.code}`} back="/work?tab=leaves" />
      <div className="page">
        <div className="chip-row"><Badge tone={LEAVE_TONE[l.status]}>{LEAVE_STATUS[l.status]}</Badge>{l.late_notice && <Badge tone="amber">Báo trước ít hơn quy định ({l.notice_required_hours} giờ)</Badge>}</div>
        <Card>
          <KV k="Người xin nghỉ" v={`${l.member_name}${l.member_title ? ' · ' + l.member_title : ''}`} />
          <KV k="Hình thức" v={`${l.type_label}${l.shift_label ? ' · ' + l.shift_label : ''}`} />
          <KV k="Thời gian" v={`${fmtDT(l.start_at)} → ${fmtDT(l.end_at)}`} />
          <KV k="Thời lượng" v={hours(l.minutes)} />
          <KV k="Báo trước" v={l.leave_type === 'sudden' ? 'Đột xuất' : hours(l.notice_minutes)} />
          <KV k="Người duyệt" v={l.approver_name} />
          {l.decided_by_name && <KV k="Đã xử lý bởi" v={`${l.decided_by_name} · ${fmtDT(l.decided_at)}`} />}
          {l.decision_reason && <KV k="Ghi chú duyệt" v={l.decision_reason} />}
          {l.hr_notified_at && <KV k="Đã gửi Nhân sự" v={`${fmtDT(l.hr_notified_at)}${l.hr_email_status === 'sent' ? ' · đã gửi email' : ''}`} />}
        </Card>
        <Card><b className="small">Lý do</b><div className="crit">{l.reason}</div>{l.handover && <><div className="divider" /><b className="small">Bàn giao</b><div className="crit">{l.handover}</div></>}</Card>
        {l.conflicts.length > 0 && (
          <>
            <div className="section-title">Việc trùng thời gian nghỉ ({l.conflicts.length})</div>
            {l.conflicts.map((t: any) => <Card key={t.id} to={`/tasks/${t.id}`}>{t.pinned ? '📌 ' : ''}{t.code} · {t.title}<div className="small muted">Hạn {fmtDT(t.due_at)}</div></Card>)}
          </>
        )}
        <ErrorBox error={a.error} />
        {p.can_decide && (
          <Card>
            <Field label="Ghi chú (bắt buộc khi từ chối)"><textarea value={reason} onChange={(e) => setReason(e.target.value)} /></Field>
            <div className="actions">
              <button className="btn primary" disabled={a.busy} onClick={() => a.run(async () => setData(await post(`/leaves/${id}/decide`, { decision: 'approve', reason: reason || undefined })))}>✔ Duyệt & gửi Nhân sự</button>
              <button className="btn danger" disabled={a.busy} onClick={() => a.run(async () => setData(await post(`/leaves/${id}/decide`, { decision: 'reject', reason })))}>Từ chối</button>
            </div>
          </Card>
        )}
        <div className="actions">
          {p.can_download && <button className="btn" disabled={a.busy} onClick={() => a.run(() => download(`/leaves/${id}/pdf`, `Don-nghi-phep-${l.code}.pdf`))}>⬇ Tải đơn PDF</button>}
          {p.can_cancel && <button className="btn danger" disabled={a.busy} onClick={() => confirm('Hủy đơn nghỉ này?') && a.run(async () => setData(await post(`/leaves/${id}/cancel`, {})))}>Hủy đơn</button>}
          <Link className="btn" to="/team">Tình trạng nhân sự tuần</Link>
        </div>
      </div>
    </>
  );
}
