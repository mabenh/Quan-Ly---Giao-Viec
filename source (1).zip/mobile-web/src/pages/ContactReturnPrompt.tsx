import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Sheet } from '../ui';
import { CHANNEL } from '../labels';
import { PendingContact, clearContact, readContact } from '../contact';

/** Khi người dùng quay lại app sau khi gọi/nhắn tin từ app: gợi ý khai việc nhanh đã điền sẵn. */
export default function ContactReturnPrompt() {
  const nav = useNavigate();
  const [c, setC] = useState<PendingContact | null>(null);
  useEffect(() => {
    const check = () => {
      if (document.visibilityState !== 'visible') return;
      const p = readContact();
      if (!p) return;
      const age = Date.now() - new Date(p.at).getTime();
      if (age > 3 * 3600000) { clearContact(); return; }
      if (age > 4000) setC(p);
    };
    document.addEventListener('visibilitychange', check);
    window.addEventListener('focus', check);
    return () => { document.removeEventListener('visibilitychange', check); window.removeEventListener('focus', check); };
  }, []);
  if (!c) return null;
  const close = () => { clearContact(); setC(null); };
  return (
    <Sheet open onClose={close} title="Khai việc nhanh?">
      <p>Bạn vừa liên hệ <b>{c.name}</b> qua <b>{CHANNEL[c.channel]?.toLowerCase()}</b> lúc {new Date(c.at).toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' })}. Có giao/nhận việc trong cuộc trao đổi này không?</p>
      <div className="actions">
        <button className="btn primary" onClick={() => { close(); nav(`/quick/new?c=${c.memberId}&ch=${c.channel}&t=${encodeURIComponent(c.at)}`); }}>Khai việc ngay</button>
        <button className="btn" onClick={close}>Không có việc</button>
      </div>
    </Sheet>
  );
}
