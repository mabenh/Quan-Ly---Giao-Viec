import { useEffect, useRef, useState } from 'react';

/** Ghi âm bằng micro của máy (trao đổi trực tiếp/loa ngoài) hoặc đính kèm file ghi âm cuộc gọi có sẵn. */
export default function AudioRecorder({ value, onChange }: { value: File | null; onChange: (f: File | null) => void }) {
  const [rec, setRec] = useState<MediaRecorder | null>(null);
  const [sec, setSec] = useState(0);
  const [err, setErr] = useState<string | null>(null);
  const [url, setUrl] = useState<string | null>(null);
  const chunks = useRef<Blob[]>([]);
  useEffect(() => { if (!value) { setUrl(null); return; } const u = URL.createObjectURL(value); setUrl(u); return () => URL.revokeObjectURL(u); }, [value]);
  useEffect(() => { if (!rec) return; const t = setInterval(() => setSec((s) => s + 1), 1000); return () => clearInterval(t); }, [rec]);
  const start = async () => {
    setErr(null);
    try {
      const s = await navigator.mediaDevices.getUserMedia({ audio: true });
      const type = ['audio/webm', 'audio/mp4', 'audio/ogg'].find((t) => (window as any).MediaRecorder?.isTypeSupported?.(t)) || '';
      const r = new MediaRecorder(s, type ? { mimeType: type } : undefined);
      chunks.current = [];
      r.ondataavailable = (e) => e.data.size && chunks.current.push(e.data);
      r.onstop = () => {
        s.getTracks().forEach((t) => t.stop());
        const mime = (r.mimeType || 'audio/webm').split(';')[0];
        const ext = mime.includes('mp4') ? 'm4a' : mime.includes('ogg') ? 'ogg' : 'webm';
        onChange(new File(chunks.current, `ghi-am-${new Date().toISOString().slice(0, 16).replace(/[:T]/g, '-')}.${ext}`, { type: mime }));
        setRec(null);
      };
      r.start(); setSec(0); setRec(r);
    } catch { setErr('Không truy cập được micro. Hãy cấp quyền micro, hoặc đính kèm file ghi âm có sẵn.'); }
  };
  return (
    <div>
      <div className="actions">
        {!rec && <button type="button" className="btn" onClick={start}>🎙 Ghi âm</button>}
        {rec && <button type="button" className="btn danger" onClick={() => rec.stop()}><span className="rec"><span className="dot" />Dừng ({Math.floor(sec / 60)}:{String(sec % 60).padStart(2, '0')})</span></button>}
        <label className="btn">📎 Đính kèm file ghi âm cuộc gọi<input type="file" accept="audio/*,.m4a,.amr,.3gp,.mp3,.wav" hidden onChange={(e) => onChange(e.target.files?.[0] || null)} /></label>
        {value && <button type="button" className="btn sm" onClick={() => onChange(null)}>Bỏ</button>}
      </div>
      {url && <audio controls src={url} style={{ width: '100%' }} />}
      {value && <div className="small muted">{value.name} · {Math.round(value.size / 1024)} KB</div>}
      {err && <div className="alert warn small">{err}</div>}
      <p className="small muted">Lưu ý: hệ điều hành không cho ứng dụng tự ghi âm cuộc gọi điện thoại. Nếu máy bạn có tính năng ghi âm cuộc gọi sẵn, hãy đính kèm file đó; hoặc bật loa ngoài và bấm Ghi âm.</p>
    </div>
  );
}
