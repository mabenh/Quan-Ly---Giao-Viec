// Ghi nhớ lần liên hệ (gọi/nhắn) để khi quay lại app thì gợi ý khai việc nhanh đã điền sẵn.
export interface PendingContact { memberId: string; name: string; channel: string; at: string }
const KEY = 'pending_contact';
export function rememberContact(c: PendingContact) { try { localStorage.setItem(KEY, JSON.stringify(c)); } catch { /* */ } }
export function readContact(): PendingContact | null { try { const v = localStorage.getItem(KEY); return v ? JSON.parse(v) : null; } catch { return null; } }
export function clearContact() { try { localStorage.removeItem(KEY); } catch { /* */ } }

/** Link khai việc nhanh gửi kèm tin nhắn: người nhận bấm vào sẽ mở mẫu khai việc với người gửi đã điền sẵn. */
export function claimLink(senderMemberId: string, channel: string, title?: string) {
  const u = new URL('/q', (import.meta.env.VITE_PUBLIC_URL as string) || window.location.origin);
  u.searchParams.set('c', senderMemberId); u.searchParams.set('ch', channel); u.searchParams.set('t', new Date().toISOString());
  if (title) u.searchParams.set('title', title);
  return u.toString();
}
export const telHref = (phone: string) => `tel:${phone}`;
export const smsHref = (phone: string, body: string) => `sms:${phone}${/iPhone|iPad/.test(navigator.userAgent) ? '&' : '?'}body=${encodeURIComponent(body)}`;
export const zaloHref = (phone: string) => `https://zalo.me/${phone}`;
