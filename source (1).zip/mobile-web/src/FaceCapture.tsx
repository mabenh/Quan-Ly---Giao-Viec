import { useEffect, useRef, useState } from 'react';

/**
 * Chụp ảnh đại diện bằng camera trước với khung gương mặt.
 * Nếu trình duyệt hỗ trợ FaceDetector (Shape Detection API) thì kiểm tra có gương mặt trong khung trước khi chụp.
 */
export default function FaceCapture({ onDone, onCancel }: { onDone: (r: { dataUrl: string; capturedLive: boolean; faceDetected: boolean | null }) => void; onCancel: () => void }) {
  const video = useRef<HTMLVideoElement>(null);
  const [err, setErr] = useState<string | null>(null);
  const [face, setFace] = useState<boolean | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const detector = useRef<any>(null);

  useEffect(() => {
    let timer: any;
    (async () => {
      try {
        const s = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user', width: { ideal: 720 }, height: { ideal: 960 } }, audio: false });
        streamRef.current = s;
        if (video.current) { video.current.srcObject = s; await video.current.play(); }
        const FD = (window as any).FaceDetector;
        if (FD) {
          detector.current = new FD({ fastMode: true, maxDetectedFaces: 1 });
          timer = setInterval(async () => {
            try { const f = await detector.current.detect(video.current); setFace(f.length === 1); } catch { /* bỏ qua */ }
          }, 600);
        }
      } catch {
        setErr('Không mở được camera. Hãy cấp quyền camera cho ứng dụng, hoặc dùng nút "Chụp bằng ứng dụng camera" bên dưới.');
      }
    })();
    return () => { clearInterval(timer); streamRef.current?.getTracks().forEach((t) => t.stop()); };
  }, []);

  const toSquare = (src: CanvasImageSource, w: number, h: number, mirror: boolean) => {
    const size = Math.min(w, h * 0.75);
    const c = document.createElement('canvas'); c.width = c.height = 480;
    const ctx = c.getContext('2d')!;
    if (mirror) { ctx.translate(480, 0); ctx.scale(-1, 1); }
    ctx.drawImage(src, (w - size) / 2, Math.max(0, h * 0.42 - size / 2), size, size, 0, 0, 480, 480);
    return c.toDataURL('image/jpeg', 0.85);
  };

  const shoot = () => {
    const v = video.current!;
    onDone({ dataUrl: toSquare(v, v.videoWidth, v.videoHeight, true), capturedLive: true, faceDetected: detector.current ? !!face : null });
  };

  const fromFile = (f: File) => {
    const img = new Image();
    img.onload = () => onDone({ dataUrl: toSquare(img, img.naturalWidth, img.naturalHeight, false), capturedLive: false, faceDetected: null });
    img.src = URL.createObjectURL(f);
  };

  return (
    <div>
      {!err && (
        <div className="cam">
          <video ref={video} playsInline muted />
          <div className={`oval ${face ? 'ok' : ''}`} />
          <div className="hint">{face === null ? 'Đưa gương mặt vào khung, nhìn thẳng' : face ? 'Đã nhận diện gương mặt ✓' : 'Chưa thấy gương mặt trong khung'}</div>
        </div>
      )}
      {err && <div className="alert warn">{err}</div>}
      <div className="actions">
        {!err && <button className="btn primary" disabled={face === false} onClick={shoot}>📸 Chụp ảnh</button>}
        <label className="btn">📷 Chụp bằng ứng dụng camera<input type="file" accept="image/*" capture="user" hidden onChange={(e) => e.target.files?.[0] && fromFile(e.target.files[0])} /></label>
        <button className="btn" onClick={onCancel}>Hủy</button>
      </div>
    </div>
  );
}
