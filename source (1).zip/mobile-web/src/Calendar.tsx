import { useEffect, useMemo, useState } from 'react';
import { get, qs } from './api';
import { isoDate } from './labels';

const DOW = ['T2', 'T3', 'T4', 'T5', 'T6', 'T7', 'CN'];
const MONTHS = (d: Date) => `Tháng ${d.getMonth() + 1}/${d.getFullYear()}`;
const mondayOf = (d: Date) => { const x = new Date(d); const k = (x.getDay() + 6) % 7; x.setDate(x.getDate() - k); x.setHours(0, 0, 0, 0); return x; };
const add = (d: Date, n: number) => { const x = new Date(d); x.setDate(x.getDate() + n); return x; };

/** Lịch tuần (thu nhỏ) / tháng (mở rộng). Chấm: việc trong ngày, hạn chót, việc ghim, nghỉ phép. */
export default function Calendar({ selected, onSelect, scope, refreshKey, onToday }: { selected: string; onSelect: (d: string) => void; scope: 'mine' | 'team'; refreshKey?: any; onToday?: (d: string) => void }) {
  const [expanded, setExpanded] = useState(() => localStorage.getItem('cal_expanded') === '1');
  const [anchor, setAnchor] = useState(() => new Date(selected));
  const [days, setDays] = useState<Record<string, any>>({});
  const [today, setToday] = useState(isoDate(new Date()));
  useEffect(() => { try { localStorage.setItem('cal_expanded', expanded ? '1' : '0'); } catch { /* */ } }, [expanded]);

  const cells = useMemo(() => {
    if (!expanded) { const m = mondayOf(anchor); return Array.from({ length: 7 }, (_, i) => add(m, i)); }
    const first = new Date(anchor.getFullYear(), anchor.getMonth(), 1);
    const start = mondayOf(first);
    const n = Math.ceil(((first.getDay() + 6) % 7 + new Date(anchor.getFullYear(), anchor.getMonth() + 1, 0).getDate()) / 7) * 7;
    return Array.from({ length: n }, (_, i) => add(start, i));
  }, [expanded, anchor]);

  useEffect(() => {
    let on = true;
    get('/calendar' + qs({ from: isoDate(cells[0]), to: isoDate(cells[cells.length - 1]), scope }))
      .then((r) => { if (!on) return; if (r.today !== today) { setToday(r.today); onToday?.(r.today); } setDays(Object.fromEntries(r.days.map((d: any) => [d.date, d]))); }).catch(() => {});
    return () => { on = false; };
  }, [cells, scope, refreshKey]);

  const move = (dir: number) => setAnchor(expanded ? new Date(anchor.getFullYear(), anchor.getMonth() + dir, 1) : add(anchor, 7 * dir));
  const goToday = () => { setAnchor(new Date(today)); onSelect(today); };

  return (
    <div className="cal" aria-label="Lịch công việc">
      <div className="cal-head">
        <button className="icon-btn" aria-label={expanded ? 'Tháng trước' : 'Tuần trước'} onClick={() => move(-1)}>‹</button>
        <div className="t">{MONTHS(expanded ? anchor : cells[3])}</div>
        <button className="btn sm" onClick={goToday}>Hôm nay</button>
        <button className="icon-btn" aria-label={expanded ? 'Tháng sau' : 'Tuần sau'} onClick={() => move(1)}>›</button>
        <button className="icon-btn" aria-label={expanded ? 'Thu nhỏ về lịch tuần' : 'Mở rộng lịch tháng'} title={expanded ? 'Thu nhỏ' : 'Mở rộng'} onClick={() => setExpanded(!expanded)}>{expanded ? '⌃' : '⌄'}</button>
      </div>
      <div className="cal-grid">
        {DOW.map((d) => <div key={d} className="cal-dow">{d}</div>)}
        {cells.map((d) => {
          const k = isoDate(d); const info = days[k];
          const cls = ['cal-day', k === today ? 'today' : '', k === selected ? 'sel' : '', expanded && d.getMonth() !== anchor.getMonth() ? 'other' : ''].join(' ');
          const label = `${d.getDate()}/${d.getMonth() + 1}: ${info?.planned_open || 0} việc${info?.due_open ? `, ${info.due_open} hạn chót` : ''}${info?.leaves?.length ? `, ${info.leaves.length} nghỉ phép` : ''}`;
          return (
            <button key={k} className={cls} onClick={() => onSelect(k)} aria-label={label} aria-pressed={k === selected}>
              <span className="n">{d.getDate()}</span>
              <span className="dots">
                {info?.planned_open > 0 && <i className="dot-task" />}
                {info?.due_open > 0 && <i className="dot-due" />}
                {info?.pinned > 0 && <i className="dot-pin" />}
                {info?.leaves?.length > 0 && <i className="dot-leave" />}
              </span>
            </button>
          );
        })}
      </div>
      {expanded && <div className="cal-legend"><span><i className="dot-task" />Việc trong ngày</span><span><i className="dot-due" />Hạn chót</span><span><i className="dot-pin" />Việc gấp</span><span><i className="dot-leave" />Nghỉ phép</span></div>}
    </div>
  );
}
