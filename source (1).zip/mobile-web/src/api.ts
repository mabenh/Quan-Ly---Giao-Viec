// Lớp gọi API: tự làm mới token, gắn Idempotency-Key cho POST để retry khi mất mạng không tạo bản ghi trùng.
const BASE = (import.meta.env.VITE_API_URL as string) || '/api/v1';

export class ApiError extends Error {
  constructor(public code: string, message: string, public status: number, public details?: any) { super(message); }
}

const store = {
  get access() { return localStorage.getItem('access_token'); },
  get refresh() { return localStorage.getItem('refresh_token'); },
  set(a: string, r: string) { localStorage.setItem('access_token', a); localStorage.setItem('refresh_token', r); },
  clear() { localStorage.removeItem('access_token'); localStorage.removeItem('refresh_token'); },
};
export const tokenStore = store;

let refreshing: Promise<boolean> | null = null;
async function tryRefresh(): Promise<boolean> {
  if (!store.refresh) return false;
  refreshing ||= (async () => {
    try {
      const r = await fetch(BASE + '/auth/refresh', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ refresh_token: store.refresh, memberId: localStorage.getItem('member_id') || undefined }) });
      if (!r.ok) return false;
      const j = await r.json();
      store.set(j.access_token, j.refresh_token);
      return true;
    } catch { return false; } finally { setTimeout(() => (refreshing = null), 0); }
  })();
  return refreshing;
}

const uuid = () => (crypto as any).randomUUID?.() || Math.random().toString(36).slice(2) + Date.now().toString(36);

export async function api<T = any>(method: string, path: string, body?: any, opts: { idempotencyKey?: string; raw?: boolean; retries?: number } = {}): Promise<T> {
  const key = method === 'POST' ? opts.idempotencyKey || uuid() : undefined;
  const isForm = body instanceof FormData;
  const doFetch = () => fetch(BASE + path, {
    method,
    headers: {
      ...(isForm ? {} : { 'Content-Type': 'application/json' }),
      ...(store.access ? { Authorization: `Bearer ${store.access}` } : {}),
      ...(key ? { 'Idempotency-Key': key } : {}),
    },
    body: body === undefined ? undefined : isForm ? body : JSON.stringify(body),
  });
  let res: Response | null = null;
  const retries = opts.retries ?? (method === 'GET' ? 1 : 2);
  for (let i = 0; i <= retries; i++) {
    try { res = await doFetch(); break; } catch (e) {
      if (i === retries) throw new ApiError('NETWORK', 'Mất kết nối mạng. Dữ liệu chưa được gửi, vui lòng thử lại.', 0);
      await new Promise((r) => setTimeout(r, 800 * (i + 1)));
    }
  }
  if (res!.status === 401 && path !== '/auth/login' && (await tryRefresh())) return api(method, path, body, { ...opts, idempotencyKey: key });
  if (opts.raw) return res as any;
  const j = await res!.json().catch(() => ({}));
  if (!res!.ok) {
    if (res!.status === 401) { store.clear(); window.dispatchEvent(new Event('auth:logout')); }
    throw new ApiError(j?.error?.code || 'HTTP_' + res!.status, j?.error?.message || 'Có lỗi xảy ra', res!.status, j?.error?.details);
  }
  return j;
}

export const get = <T = any>(p: string) => api<T>('GET', p);
export const post = <T = any>(p: string, b?: any) => api<T>('POST', p, b ?? {});
export const patch = <T = any>(p: string, b?: any) => api<T>('PATCH', p, b ?? {});
export const put = <T = any>(p: string, b?: any) => api<T>('PUT', p, b ?? {});
export const del = <T = any>(p: string, b?: any) => api<T>('DELETE', p, b);

export async function upload(parentType: string, parentId: string, file: File) {
  const fd = new FormData(); fd.append('file', file);
  return api('POST', `/files?parentType=${parentType}&parentId=${parentId}`, fd);
}

export async function download(path: string, filename: string) {
  const res: Response = await api('GET', path, undefined, { raw: true });
  if (!res.ok) { const j = await res.json().catch(() => ({})); throw new ApiError(j?.error?.code, j?.error?.message || 'Không tải được tệp', res.status); }
  const blob = await res.blob();
  const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = filename; a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 5000);
}

export function qs(o: Record<string, any>) {
  const p = Object.entries(o).filter(([, v]) => v !== undefined && v !== null && v !== '').map(([k, v]) => `${k}=${encodeURIComponent(v)}`);
  return p.length ? '?' + p.join('&') : '';
}
